<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require_once "vendor/autoload.php";

$mail = new PHPMailer;
$mail->isSMTP;                                   
$mail->Host = "";
$mail->SMTPDebug = "";
$mail->SMTPAuth = "";
$mail->Port = "";
$file = fopen("../mail/200k.txt", "r") or die("Unable to open file");
$line = fgets($file);
$list($to,"") = explode();
$mail->From = "snub.com@gmail.com";
$mail->FromName = "Full Name";
$mail->addAddress("snub.com@gmail.com", "Recepient Name");
$mail->isHTML(true);
$mail->Subject = "Subject Text";
$mail->MsgHTML(file_get_contents('../letter/a.html'));
$mail->AltBody = "This is the plain text version of the email content";

if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
} 
else 
{
    echo "Message has been sent successfully";
}
