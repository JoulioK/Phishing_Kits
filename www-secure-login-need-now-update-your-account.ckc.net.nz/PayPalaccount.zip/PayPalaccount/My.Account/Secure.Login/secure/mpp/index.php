<?
$src="update";
header("location:$src");
?>
