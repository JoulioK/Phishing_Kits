<title>Send Money, &#929;ay Online or Set Up a Merchant Account - &#929;ay&#929;al</title>
        <meta charset="utf-8" />
  	<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7" />
  	<meta name="application-name" content="" />
	<meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=1024" />
        <link rel="shortcut icon" href="../img/paypal-icon.png" />
	  	<link rel="apple-touch-icon" href="./files/apple-touch-icon.png" />
        <meta charset="UTF-8" />
        <meta name="msapplication-task" content="action-uri=./img/favicon.ico" />
        
            
       
        <link rel="shortcut icon" type="image/x-icon" href="../img/favicon.ico" />
     
        


        <link rel="stylesheet" href="./css/49f3ba73cb4381b8a067b32dbaa5ae8142537c.css" rel="stylesheet" type="text/css" />
        
        
        
        
        <link rel="stylesheet" href="./css/63/93981ae2c5a9e7f0d20e5ec05c663f0d7381f8.css" rel="stylesheet" type="text/css" />
        
        
        
        
    <link rel="stylesheet" href="./css/a317abc3f3a6fac10f317d828c78522a51528b.css" rel="stylesheet" type="text/css" />

        
        
       
         <script src="./js/c1e55b749b95682923839530db6520b2ca221a.js"></script> 