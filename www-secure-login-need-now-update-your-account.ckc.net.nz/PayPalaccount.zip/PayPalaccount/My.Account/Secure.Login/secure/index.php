<?
$src="mpp";
header("location:$src");
?>
