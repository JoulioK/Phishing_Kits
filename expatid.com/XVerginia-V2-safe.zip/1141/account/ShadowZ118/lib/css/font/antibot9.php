<?php
echo "try to bybas me another time noob hahahaha";
?>