<?php
  	include '../../prevents/shadow1.php';
    include '../../prevents/shadow2.php';
    include '../../prevents/shadow3.php';
    include '../../prevents/shadow4.php';
    include '../../prevents/shadow5.php';
    include '../../prevents/shadow6.php';
    include '../../prevents/shadow7.php';
    include '../../prevents/shadow8.php';
	exit(header("Location: ../index.php"));
?>
