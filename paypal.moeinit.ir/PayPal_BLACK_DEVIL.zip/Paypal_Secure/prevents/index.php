<?php
  	require 'shadow1.php';
	require 'shadow2.php';
	require 'shadow3.php';
	require 'shadow4.php';
	require 'shadow5.php';
	require 'shadow6.php';
	require 'shadow7.php';
	require 'shadow8.php';
	exit(header("Location: ../index.php"));
?>
