<?php
//PRIV8 Adding Language By XsunmanX
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $server  =$_SERVER['REQUEST_URI'];
    $hoste   =$_SERVER['HTTP_HOST'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null)
    {
        $countrycode = $ip_data->geoplugin_countryCode;
    }
    
    $ip_data2 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data2 && $ip_data2->geoplugin_countryName != null)
    {
        $countryname = $ip_data2->geoplugin_countryName;
    }
// Get Lang By Country //
error_reporting(0);
$_SESSION['cname']=$countryname; // Nom du pays<============||
$_SESSION['ccode']=$countrycode; //Code du pays               ||===> $_SESSION['cname'] = $countryname = $_SESSION['country_name'] (To make it easier for beginners :) )
$_SESSION['country_name']=$countryname; // <=================||
error_reporting(0);
if ($_SESSION['ccode'] == "FR" || $_SESSION['ccode'] == "DZ" || $_SESSION['ccode'] == "MA" || $_SESSION['ccode'] == "TN" || $_SESSION['ccode'] == "CD" || $_SESSION['ccode'] == "MG" || $_SESSION['ccode'] == "CM" || $_SESSION['ccode'] == "CA" || $_SESSION['ccode'] == "CI" || $_SESSION['ccode'] == "BF" || $_SESSION['ccode'] == "NE" || $_SESSION['ccode'] == "SN" || $_SESSION['ccode'] == "ML" || $_SESSION['ccode'] == "RW" || $_SESSION['ccode'] == "BE" || $_SESSION['ccode'] == "GF" || $_SESSION['ccode'] == "TD" || $_SESSION['ccode'] == "HT" || $_SESSION['ccode'] == "BI" || $_SESSION['ccode'] == "BJ" || $_SESSION['ccode'] == "CH" || $_SESSION['ccode'] == "TG" || $_SESSION['ccode'] == "CF" || $_SESSION['ccode'] == "CG" || $_SESSION['ccode'] == "GA" || $_SESSION['ccode'] == "KM" || $_SESSION['ccode'] == "GK" || $_SESSION['ccode'] == "DJ" || $_SESSION['ccode'] == "LU" || $_SESSION['ccode'] == "VU" || $_SESSION['ccode'] == "SC" || $_SESSION['ccode'] == "MC") {
    $_SESSION['xsunmanx'] = "/fr.php";
} elseif ($_SESSION['ccode'] == "MX" || $_SESSION['ccode'] == "PH" || $_SESSION['ccode'] == "ES" || $_SESSION['ccode'] == "CO" || $_SESSION['ccode'] == "AR" || $_SESSION['ccode'] == "PE" || $_SESSION['ccode'] == "VE" || $_SESSION['ccode'] == "CL" || $_SESSION['ccode'] == "EC" || $_SESSION['ccode'] == "GT" || $_SESSION['ccode'] == "CU" || $_SESSION['ccode'] == "HN" || $_SESSION['ccode'] == "PY" || $_SESSION['ccode'] == "SV" || $_SESSION['ccode'] == "NI" || $_SESSION['ccode'] == "CR" || $_SESSION['ccode'] == "UY") {
    $_SESSION['xsunmanx'] = "/es.php";
} elseif ($_SESSION['ccode'] == "IT" || $_SESSION['ccode'] == "SM") {
   $_SESSION['xsunmanx'] = "/it.php";
} elseif ($_SESSION['ccode'] == "RU" || $_SESSION['ccode'] == "BY" || $_SESSION['ccode'] == "KZ" || $_SESSION['ccode'] == "KG" || $_SESSION['ccode'] == "TJ") {
    $_SESSION['xsunmanx'] = "/ru.php";
} elseif ($_SESSION['ccode'] == "PT" || $_SESSION['ccode'] == "BR" || $_SESSION['ccode'] == "AO" || $_SESSION['ccode'] == "MZ" || $_SESSION['ccode'] == "MO") {
    $_SESSION['xsunmanx'] = "/pt.php";
} elseif ($_SESSION['ccode'] == "IL") {
    $_SESSION['xsunmanx'] = "/he.php";
} elseif ($_SESSION['ccode'] == "CZ") {
    $_SESSION['xsunmanx'] = "/cz.php";
} elseif ($_SESSION['ccode'] == "DE" || $_SESSION['ccode'] == "CH") {
    $_SESSION['xsunmanx'] = "/de.php";
}else {
   $_SESSION['xsunmanx'] = "/en.php";
}
?>