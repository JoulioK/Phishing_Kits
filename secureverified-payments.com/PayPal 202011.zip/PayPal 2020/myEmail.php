<?php

$myEmail = "jamesreeves19@protonmail.com"; //////// YOUR EMAIL GOES HERE

///////Coded by PHISHER



?>