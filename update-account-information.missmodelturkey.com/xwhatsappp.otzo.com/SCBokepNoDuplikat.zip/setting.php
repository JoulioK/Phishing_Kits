<?php
$username = 'Arul';
$password = 'SPG';
?>