<!-- TIDAK DI JUAL -->
<?php
$emailku = 'arulganz120305@gmail.com';
?>