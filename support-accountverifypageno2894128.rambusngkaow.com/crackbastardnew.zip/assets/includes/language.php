<?php
$ip    = $_SERVER['REMOTE_ADDR'];
$getip = 'http://extreme-ip-lookup.com/json/' . $ip;
$curl  = curl_init();
curl_setopt($curl, CURLOPT_URL, $getip);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
@curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
$content = curl_exec($curl);
curl_close($curl);
$details      = json_decode($content);
$country_name = $details->countryCode;
switch ($lang) {
    default:
        $lang_file = 'lang.other.php';

        if ($country_name == "AU") {
            $lang_file = 'lang.au.php';
            //echo "Australia";
        }
        if ($country_name == "JP") {
            $lang_file = 'lang.jp.php';
            //echo "Japan";
        }
        if ($country_name == "GB") {
            $lang_file = 'lang.gb.php';
            //echo "United Kingdom";
        }
        if ($country_name == "US") {
            $lang_file = 'lang.usa.php';
            //echo "United States";
        }
        if ($country_name == "HK") {
            $lang_file = 'lang.hk.php';
            //echo "Hong Kong";
        }
        if ($country_name == "CA") {
            $lang_file = 'lang.ca.php';
            //echo "Canada";
        }
        if ($country_name == "IE") {
            $lang_file = 'lang.ie.php';
            //echo "Ireland";
        }
        if ($country_name == "TH") {
            $lang_file = 'lang.th.php';
            //echo "Thailand";
        }
         if ($country_name == "IN") {
            $lang_file = 'lang.in.php';
            //echo "India";
        }
         if ($country_name == "KW") {
            $lang_file = 'lang.kw.php';
            //echo "Kuwait";
        }
         if ($country_name == "GR") {
            $lang_file = 'lang.gr.php';
            //echo "Greece";
        }
        if ($country_name == "CY") {
            $lang_file = 'lang.cy.php';
            //echo "Cyprus";
        }
        if ($country_name == "SA") {
            $lang_file = 'lang.sa.php';
            //echo "Saudi Arabia";
        }
        if ($country_name == "NZ") {
            $lang_file = 'lang.nz.php';
            //echo "New Zealand";
        }
        if ($country_name == "QA") {
            $lang_file = 'lang.qa.php';
            //echo "Qatar";
        }
}

include_once 'languages/' . $lang_file;