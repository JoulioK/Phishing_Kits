<?php


$youremail = 'iq96999@gmail.com';

$passwrd_admim = 'doniq';



?>