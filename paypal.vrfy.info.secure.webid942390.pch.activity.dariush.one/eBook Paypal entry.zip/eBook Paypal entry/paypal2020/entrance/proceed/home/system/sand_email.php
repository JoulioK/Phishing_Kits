<?php


$youremail = 'megan007qt@outlook.com';

$passwrd_admim = 'doniq';



?>