<?php
include('block1.php');
include('block2.php');


header('Location: Recover');

?>