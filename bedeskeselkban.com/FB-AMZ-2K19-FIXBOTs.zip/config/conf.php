<?php
error_reporting(0);
//write a username (Temo by default)
$name = "admin";
 
 
//write your scama password (12345 by default)
$password = "FB-AMZ-2K19-KHXFB091201OKLZ";
 
 
//---------------------  Don't touch it !!! --------------------------------
$wrong_password_Error = "Invallid Token Bitch!!!!!";
$help = "Check your email <b>( $your_email )</b> , to find your password .";
$permession_Error = "You have no permission to access to this file/page .";
$account_is_onn = "admin/panel.php?account=on";
$account_is_off = "admin/panel.php?account=off";
//--------------------------------------------------------------------------
?>