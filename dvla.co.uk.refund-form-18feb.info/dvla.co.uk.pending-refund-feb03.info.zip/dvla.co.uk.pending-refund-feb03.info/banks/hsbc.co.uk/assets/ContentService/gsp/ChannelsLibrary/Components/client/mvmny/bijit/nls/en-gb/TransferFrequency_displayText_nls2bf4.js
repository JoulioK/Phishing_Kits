define({
	'Select' : '',
	'lastdayofthemonth' : 'Last day of the month',
	'lastworkdayofthemonth' : 'Last working day of the month',
	'weekly' : 'Weekly',
	'everyTwoWeeks' : 'Fortnightly',
	'fourweekly' : 'Four weekly',
	'monthly' : 'Monthly',
	'quarterly' : 'Quarterly',
	'halfyearly' : 'Every 6 months',
	'annually' : 'Annually',
	'daily' : 'Daily'
});