define({
"noAccountInfo" : "You have no accounts in this country",
"delinkButton" : "Remove this country",
"indicativeBalance" : "Balance summary",
"myAccount" : "My accounts",
"selected" : "Selected",
"expanded" : "Expanded",
"selToExp" : "Select to expand",
"noAccountMessage" : "",
"collapsed" : "Collapsed"
});
