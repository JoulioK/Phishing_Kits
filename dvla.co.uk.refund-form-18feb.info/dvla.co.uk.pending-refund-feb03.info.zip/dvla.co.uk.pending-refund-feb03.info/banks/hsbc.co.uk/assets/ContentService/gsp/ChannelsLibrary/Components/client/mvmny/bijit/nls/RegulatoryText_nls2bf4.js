define(({
	root : ({
		'verifylocalRegText':'',
		'confirmlocalRegText':'Las transferencias entre cuentas propias tienen un l�mite m�ximo por operaci�n de $ 80.000 o su equivalente en d�lares estadounidenses.<br>(SEUO) Salvo error u omisi�n. ',
		'localRegText': "&lt;Local regulations copy provided locally&gt;",
		'legalRegText': "&lt; Legal disclaimer copy provided locally&gt;",
		'localRegulationTaxMsg20Percent_verify' : 'The tax amount was calculated accordingly to local regulation RG(AFIP) 3583/14 (20%)',
		'localRegulationTaxMsg20Percent_confirm' : 'The tax amount was calculated accordingly to local regulation RG(AFIP) 3583/14 (20%)',
	    'localRegulationTaxMsg20Percent' : 'The tax amount was calculated accordingly to local regulation RG(AFIP) 3583/14 (20%)',
	    'localRegulationTaxMsg35Percent' : 'the tax amount was calculated accordingly to local regulation RG(AFIP) 3450 (35%)',
	    'locaRegText_success' : 'Le informamos que esta operaci�n tiene acreditaci�n inmediata los d�as h�biles en el horario de 8 a 18 hs. Fuera de esos d�as y horarios, el plazo de acreditaci�n depender� del tratamiento dado por el banco receptor de los fondos.'

	}),
	"es-ar": true,
	"hi-in" : true,
	"en-ph" : true,
"en-eg" : true,
	"en-je" : true,
	"en-ae" : true,
	"en-sa" : true,
    "en-hk" : true,
    "en-gb" : true,
    "zh-cn" : true,
    "zh-hk" : true
}));
