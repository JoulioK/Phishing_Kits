define({
    root: ({
        currentStep: "current",
        step: "Step",
        completedStep: "Completed ",
        accessibleFormat: "Step {currentStep} out of {totalSteps}",
        firstStep: 1
    }),
    "es-ar": true
});
