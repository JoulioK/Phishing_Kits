define({
	"availableLimit" : "Available balance: ",
	"overdraftLimit" : "Overdraft limit:",
	"termUnit" : {
		"000001" : "Days",
		"000002" : "Months",
		"000003" : "Years"
	},
	"DD" : {
		"availBal" : "Funds available",
		"odLimitAmt" : "Overdraft"
	},
	"LOAN" : {
		"nextPymtDt" : "Next payment",
		"ovdueAmt" : "Overdue balance"
	},
	"TD" : {
		"term" : "Term",
		"mturDt" : "Maturity Date",
		"intRate" : "Interest Rate",
		"intAmt" : "Interest At Maturity"
	},
	"CC" : {
		"creditLimit" : "Credit limit",
		"availCreditAmt" : "Available credit",
		"lastStmtMinPymtAmt" : "Minimum payment"
	}

});
