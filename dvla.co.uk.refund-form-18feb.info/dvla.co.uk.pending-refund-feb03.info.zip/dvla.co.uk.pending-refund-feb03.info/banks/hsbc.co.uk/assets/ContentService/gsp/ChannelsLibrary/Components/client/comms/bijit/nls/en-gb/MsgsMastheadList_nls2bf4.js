define({

		//BP_11.3 Start
		'messages' : 'Messages',
		'messageForAccessibility' : 'Message',
		'readMessage':'Read',
		'unReadMessage':'Unread',
		'alertMessage':'Alert',
		'viewAllMessages' : 'View all messages',
		'noMessages': 'You have no messages',
		'compose' : 'Send a message',
		'new' : 'New',
		'hiphen' : '-',
		'loading' : 'Loading...',
		'unreadMessageCount':'Unread message count',
		'stepUpToolTipMsg':"<h3>What's this?</h3><p>You will need to step to a higher level of security</p>",
		'errorMessage' : 'This service is currently unavailable',
		'selected':'selected',
		'view':'view',
		'expandMsg' : 'Press enter or down arrow to open'
		//BP_11.3 end
});
