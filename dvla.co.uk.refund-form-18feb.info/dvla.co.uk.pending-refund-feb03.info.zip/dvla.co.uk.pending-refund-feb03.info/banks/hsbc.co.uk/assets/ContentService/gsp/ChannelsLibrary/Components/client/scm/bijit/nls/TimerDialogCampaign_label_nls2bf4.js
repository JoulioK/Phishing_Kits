define({
    root: {
        timeoutTitle: "Time out warning",
        timeoutMessage: "You will be automatically logged off in <span class='seconds'>${seconds}</span>.",
        stayLoggedOn: 'Stay logged on',
        logOff: 'Log off'
    },
	"es-ar" : true,
	"pt-br" : true,
    "hi-in" : true,
    "en-hk" : true,
    "en-gb" : true,
	"zh-cn" : true,
	"zh-hk" : true
});