define({
    root : ({
		"page" : "Page",
		"of" : "Of",
		"previous" : "Previous",
		"play" : "Play",
		"pause" : "Pause",
		"next" : "Next"
	}),
	"zh-hk" : true,
	"en-hk" : true,
	"zh-cn" : true
});