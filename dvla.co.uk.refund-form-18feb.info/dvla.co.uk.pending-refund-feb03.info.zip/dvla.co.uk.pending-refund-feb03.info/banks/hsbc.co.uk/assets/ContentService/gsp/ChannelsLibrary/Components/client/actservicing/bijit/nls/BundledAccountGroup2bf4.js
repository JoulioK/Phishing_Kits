define({
root : ({
"payment" : "Payment",
"transfer" : "Transfer",
"viewRecentTransactionsFor" : "View Recent transactions for:",
"indicativeBalance" : "Indicative Balance",
"hyphen" : " - "
}),
"es-ar" : true,
"hi-in" : true,
"en-gb" : true,
"zh-cn" : true,
"it" : true
});
