define({
	site_pws_keyMatch: "uk",
	numberOfTopResultToDisplay: "2",
	keyMatchServiceIndicator: "on",
	numOfCommonResultToDisplay: "4",
	max: "4",
	ssid: "EGGHSBC001",
	site_pws: "EGGHSBC001",
	site_pib: "EGGHSBC001",
	client: "default_frontend",
	access: "p",
	format: "rich",
	num_of_results: "10",
	output: "xml"
});