define({
	root: ({
		"0" : "N/A",
		"1" : "Active",
        "2" : "Dormant",
        "3" : "Unclaimed",
        "4" : "Closing",
        "5" : "Closed",
        "6" : "Blocked",
        "7" : "Deceased"
		}),
"es-ar": true,
"ar-sa" : true,
    "hi-in" : true,
    "ar-ae" : true,
    "en-hk":true
});
