define(({
	root : ({
			"select" : 'Select',
			"iPay" : 'I pay charge',
			"youPay" : 'You pay charge'
	}),
	"zh-cn": true,
	"zh-hk": true,
	"es-ar": true,
	"hi-in" : true,
	"en-gb" : true,
	"en-hk" : true,
	"en-je" : true
}));
