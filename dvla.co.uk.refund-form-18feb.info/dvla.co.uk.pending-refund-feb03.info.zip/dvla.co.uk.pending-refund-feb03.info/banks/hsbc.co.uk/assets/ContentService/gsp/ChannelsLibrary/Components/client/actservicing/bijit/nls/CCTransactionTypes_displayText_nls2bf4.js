define({
	root: ({
"Unbilled" : "Unbilled Transactions",
"Billed" : "Billed Transactions"
}),
"es-ar" : true,
"ar-sa" : true,
"hi-in" : true,
"ar-ae" : true,
"en-hk" : true
});
