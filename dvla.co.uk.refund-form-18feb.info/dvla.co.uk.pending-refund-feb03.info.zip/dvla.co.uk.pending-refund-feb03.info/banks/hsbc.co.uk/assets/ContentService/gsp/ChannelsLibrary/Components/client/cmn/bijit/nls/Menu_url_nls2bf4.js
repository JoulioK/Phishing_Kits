/**
 *
 */
define({
	root : ({
		"yearRoundOffers" : "http://www.personal.hsbc.com.hk/1/2/hk/cards/yro/generic?pwscmd=lrh_home",
		"hsbcInsight" : "{LEGACY_URL2}/1/2/special/investments/horizons-c",
		"mycardRewards" : "{LEGACY_URL2}/1/2/hk/cards/rewards/e-shop"
	}),
	'en-hk' : true,
	'zh-hk' : true,
	'zh-cn' : true
});
