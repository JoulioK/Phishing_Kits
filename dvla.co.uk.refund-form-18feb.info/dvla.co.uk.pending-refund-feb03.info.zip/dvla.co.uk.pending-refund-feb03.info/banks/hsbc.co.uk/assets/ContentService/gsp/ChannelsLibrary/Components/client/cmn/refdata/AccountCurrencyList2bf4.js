/*  AccountCurrencyList used in Add Beneficiary (Person) */
/*  Likely incomplete */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"AccountCurrencyList" : [ {
		"id" : 'USD',
		"desckey" : 'USD',
		"defaultflag" : 'N'
 }, {
		"id" : 'BHD',
		"desckey" : 'BHD',
		"defaultflag" : 'N'
	}, {
		"id" : 'BYR',
		"desckey" : 'BYR',
		"defaultflag" : 'N'
	}, {
		"id" : 'GBP',
		"desckey" : 'GBP',
		"defaultflag" : 'Y'
	}, {
		"id" : 'INR',
		"desckey" : 'INR',
		"defaultflag" : 'N'
	}, {
		"id" : 'CAD',
		"desckey" : 'CAD',
		"defaultflag" : 'N'
	}, {
		"id" : 'AUD',
		"desckey" : 'AUD',
		"defaultflag" : 'N'
	}, {
		"id" : 'JPY',
		"desckey" : 'JPY',
		"defaultflag" : 'N'
	},  
	{
		"id" : 'AED',
		"desckey" : '	AED',
		"defaultflag" : 'N'
	},
	{
		"id" : 'BDT',
		"desckey" : 'BDT',
		"defaultflag" : 'N'
	},{
		"id" : 'BND',
		"desckey" : 'BND',
		"defaultflag" : 'N'
	},
	{
		"id" : 'CHF',
		"desckey" : 'CHF',
		"defaultflag" : 'N'
	},
	{
		"id" : 'CNY',
		"desckey" : 'CNY',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'CZK',
		"desckey" : 'CZK',
		"defaultflag" : 'N'
	},
	{
		"id" : 'DKK',
		"desckey" : 'DKK',
		"defaultflag" : 'N'
	},
	{
		"id" : 'EGP',
		"desckey" : 'EGP',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'EUR',
		"desckey" : 'EUR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'FJD',
		"desckey" : 'FJD',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'GBP',
		"desckey" : 'GBP',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'HKD',
		"desckey" : 'HKD',
		"defaultflag" : 'N'
	},
	{
		"id" : 'IDR',
		"desckey" : 'IDR',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'ILS',
		"desckey" : 'ILS',
		"defaultflag" : 'N'
	},{
		"id" : 'INR',
		"desckey" : 'INR',
		"defaultflag" : 'N'
	},{
		"id" : 'JOD',
		"desckey" : 'JOD',
		"defaultflag" : 'N'
	},
	{
		"id" : 'JPY',
		"desckey" : 'JPY',
		"defaultflag" : 'N'
	},
	{
		"id" : 'KWD',
		"desckey" : 'KWD',
		"defaultflag" : 'N'
	},
	{
		"id" : 'LKR',
		"desckey" : 'LKR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'MAD',
		"desckey" : 'MAD',
		"defaultflag" : 'N'
	},
	{
		"id" : '	MOP',
		"desckey" : '	MOP',
		"defaultflag" : 'N'
	},
	{
		"id" : 'MUR',
		"desckey" : 'MUR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'MXN',
		"desckey" : 'MXN',
		"defaultflag" : 'N'
	},
	{
		"id" : 'NOK',
		"desckey" : 'NOK',
		"defaultflag" : 'N'
	},
	{
		"id" : '	NZD',
		"desckey" : '	NZD',
		"defaultflag" : 'N'
	},
	{
		"id" : '	PGK',
		"desckey" : '	PGK',
		"defaultflag" : 'N'
	},{
		"id" : '	PHP',
		"desckey" : '	PHP',
		"defaultflag" : 'N'
	},
	{
		"id" : '	PKR',
		"desckey" : '	PKR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'PLN',
		"desckey" : '	PLN',
		"defaultflag" : 'N'
	},
	{
		"id" : 'QAR',
		"desckey" : '	QAR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'SAR',
		"desckey" : '	SAR',
		"defaultflag" : 'N'
	},
	{
		"id" : 'SBD',
		"desckey" : '	SBD',
		"defaultflag" : 'N'
	},
	{
		"id" : 'SCR',
		"desckey" : '	SCR',
		"defaultflag" : 'N'
	},{
		"id" : 'SEK',
		"desckey" : '	SEK',
		"defaultflag" : 'N'
	},{
		"id" : 'SGD',
		"desckey" : '	SGD',
		"defaultflag" : 'N'
	},
	{
		"id" : 'THB',
		"desckey" : 'THB',
		"defaultflag" : 'N'
	},{
		"id" : '	TRL',
		"desckey" : '		TRL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	ZAR',
		"desckey" : '		ZAR',
		"defaultflag" : 'N'
	},
	{
		"id" : '		ALL',
		"desckey" : '			ALL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	AMD',
		"desckey" : '	AMD',
		"defaultflag" : 'N'
	},
	{
		"id" : '	BBD',
		"desckey" : '	BBD',
		"defaultflag" : 'N'
	},
	{
		"id" : '	BGN',
		"desckey" : '	BGN',
		"defaultflag" : 'N'
	},{
		"id" : '	BMD',
		"desckey" : '	BMD',
		"defaultflag" : 'N'
	},{
		"id" : '		BSD',
		"desckey" : '		BSD',
		"defaultflag" : 'N'
	},{
		"id" : '	BWP',
		"desckey" : '	BWP',
		"defaultflag" : 'N'
	},{
		"id" : '	BGN',
		"desckey" : '	BGN',
		"defaultflag" : 'N'
	},{
		"id" : '	DZD',
		"desckey" : '	DZD',
		"defaultflag" : 'N'
	},{
		"id" : '		ETB',
		"desckey" : '		ETB',
		"defaultflag" : 'N'
	},{
		"id" : '	BGN',
		"desckey" : '	BGN',
		"defaultflag" : 'N'
	},{
		"id" : '	GHS',
		"desckey" : '	GHS',
		"defaultflag" : 'N'
	},
	
	
	{
		"id" : '	GTQ',
		"desckey" : '	GTQ',
		"defaultflag" : 'N'
	},
	{
		"id" : '	HRK',
		"desckey" : '	HRK',
		"defaultflag" : 'N'
	},
	
	{
		"id" : '	HUF',
		"desckey" : '	HUF',
		"defaultflag" : 'N'
	},
	{
		"id" : '	JMD',
		"desckey" : '	JMD',
		"defaultflag" : 'N'
	},
	
	{
		"id" : '	LSL',
		"desckey" : '	LSL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	LTL',
		"desckey" : '	LTL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	LVL',
		"desckey" : '	LVL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	MWK',
		"desckey" : '	MWK',
		"defaultflag" : 'N'
	},	{
		"id" : '	NAD',
		"desckey" : '	NAD',
		"defaultflag" : 'N'
	},
	{
		"id" : '	OMR',
		"desckey" : '	OMR',
		"defaultflag" : 'N'
	},	{
		"id" : '	RON',
		"desckey" : '	RON',
		"defaultflag" : 'N'
	},
	
	{
		"id" : '	RSD',
		"desckey" : '	RSD',
		"defaultflag" : 'N'
	},
	
	{
		"id" : '	RUB',
		"desckey" : '	RUB',
		"defaultflag" : 'N'
	},
	{
		"id" : '	SZL',
		"desckey" : '	SZL',
		"defaultflag" : 'N'
	},
	{
		"id" : '	TND',
		"desckey" : '	TND',
		"defaultflag" : 'N'
	},
	{
		"id" : '	TTD',
		"desckey" : '	TTD',
		"defaultflag" : 'N'
	},
	{
		"id" : '		UYU',
		"desckey" : '		UYU',
		"defaultflag" : 'N'
	},
	{
		"id" : '		XAF',
		"desckey" : '		XAF',
		"defaultflag" : 'N'
	},
	
	{
		"id" : '		XCD',
		"desckey" : '		XCD',
		"defaultflag" : 'N'
	},
	{
		"id" : '		XOF',
		"desckey" : '		XOF',
		"defaultflag" : 'N'
	},
	
	{
		"id" : 'AED',
		"desckey" : 'AED',
		"defaultflag" : 'N'
	} ]
}));
