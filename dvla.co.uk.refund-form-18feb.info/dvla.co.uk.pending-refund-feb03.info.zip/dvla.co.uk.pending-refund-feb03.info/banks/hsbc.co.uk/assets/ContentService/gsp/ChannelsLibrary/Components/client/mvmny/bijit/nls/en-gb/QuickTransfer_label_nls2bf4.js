define({	
	'amount' : "Amount",
	'anotherTransfer' : "New transfer",
	'fromLabel' : "From",
	'makeTransfer' : "Transfer",
	'toLabel' : "To",
	'selectToValue' : 'To account',
	'quickTrans' : "Quick Transfer",
	'quickTransConf' : 'Confirmation',
	'clear' : "Cancel",
	'tranRefNumLabel' : "Reference number",
	'errorResponse' : 'Transfer failed',
	'amountPlaceHolder' : 'Enter amount',
	'amtExceedErr' : "The amount must be no more than 11 digits",
	'amtNegErr' : "The amount must be greater than 0",
	'amtZeroErr' : "The amount cannot be 0",
	'amtDecErr' : "Please use a maximum of 2 decimal places",
	'fromAccountLabel' : 'From account',
	'toAccountLabel' : 'To account',
	'contentSpotConf' : "Transfer money between your accounts",
	// Use this key when required for cut off message in UK
	'payNowCuttOffTimeMsg' : "Transfers will be made immediately unless it's after 23:45 when they will be made the next day",
	'QMM269' : 'You appear to have made a duplicate Quick Transfer request. Please change the amount and try again or go to \'Move money\' to create a new transfer with the same amount.'
});
