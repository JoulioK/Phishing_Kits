define({
		"currency" : "Currency",
		"messages" : {
"valuePositive" : "The amount must be greater than 0",
"valueNotZero": "The amount cannot be 0",
			"valueNumeric" : "Please enter a valid amount.",
"maxNumericCharsExceeded": "The amount must be no more than 11 digits",
			"currencyFieldErrorMsg" : "You must enter a valid amount.",
			"amountTooLarge" : "The amount exceeds the maximum allowed.",
			"amountTooSmall" : "The amount may not be less than the threshold.",
"decimalPlaces": "Please use a maximum of 2 decimal places",
			"currencyFieldMissingMsg" : "Please enter an amount."
		},
		"currencyOverrides" : {
			"JPY" : {
				"decimalPlaces" : "You must enter a valid amount."
			}
		}
});
