define({
			"Dev" : "https://www.eu574.p2g.netd2.hsbc.com.hk/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=dmr&WT.ac=VM_RBWM_eDOC_201511_1",
			"SIT" : "https://www.eu462.p2g.netd2.hsbc.com.hk/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=dmr&WT.ac=VM_RBWM_eDOC_201511_1",
			"Prod" : "https://www.hsbc.co.uk/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=dmr&WT.ac=VM_RBWM_eDOC_201511_1"
});