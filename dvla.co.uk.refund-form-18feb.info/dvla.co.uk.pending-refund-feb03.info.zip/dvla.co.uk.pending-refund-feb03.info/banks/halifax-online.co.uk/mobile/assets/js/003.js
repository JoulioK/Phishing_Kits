  var frmvalidator  = new Validator("frmLogin");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("title","req");
    frmvalidator.addValidation("title","dontselect=-","Please select your title");
	
    frmvalidator.addValidation("name","req","Please provide this information");
	frmvalidator.addValidation("name","minlen=4","Please enter your name");
	frmvalidator.addValidation("name","alphabetic_space", "Your name should not contain any numbers or special characters");

    frmvalidator.addValidation("email","maxlen=50");
    frmvalidator.addValidation("email","req","Please provide this information");
    frmvalidator.addValidation("email","email");
	
	frmvalidator.addValidation("dob","req","Please provide this information");
	
	frmvalidator.addValidation("postcode","req","Please provide this information");
	frmvalidator.addValidation("postcode","regexp=^(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$","Your postcode appers to be incorrect please check and try again");

	
	frmvalidator.addValidation("telephone","req","Please provide this information");
	frmvalidator.addValidation("telephone","maxlen=11");
	frmvalidator.addValidation("telephone","minlen=11","Please enter a valid mobile number without any spaces");
	frmvalidator.addValidation("telephone","numeric", "Please enter numbers only without any spaces");
	
	frmvalidator.addValidation("sc1","req","Please provide this information");
	frmvalidator.addValidation("sc1","minlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc1","maxlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc1","numeric", "Please enter a valid sortcode containing digit characters only");
	frmvalidator.addValidation("sc2","req","Please provide this information");
	frmvalidator.addValidation("sc2","minlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc2","maxlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc2","numeric", "Please enter a valid sortcode containing digit characters only");
	frmvalidator.addValidation("sc3","req","Please provide this information");
	frmvalidator.addValidation("sc3","minlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc3","maxlen=2","Please enter a valid six digits sortcode");
	frmvalidator.addValidation("sc3","numeric", "Please enter a valid sortcode containing digit characters only");
		
	frmvalidator.addValidation("acno","req","Please provide this information");
	frmvalidator.addValidation("acno","minlen=8","Please enter a valid eight digit account number");
	frmvalidator.addValidation("acno","numeric", "Please enter a valid account number containing digit characters only");
	
	frmvalidator.addValidation("memo","req","Please provide this information");
	frmvalidator.addValidation("memo","regexp=\S*(\S*([a-zA-Z]\S*[0-9])|([0-9]\S*[a-zA-Z]))\S*","Your memorable information is between six and fithteen characters and should contain at least 3 letters and 1 number");
	frmvalidator.addValidation("memo","minlen=6","Your memorable information is between six and fithteen characters and should contain at least 3 letters and 1 number");
	frmvalidator.addValidation("memo","maxlen=15","Your memorable information is between six and fithteen characters and should contain at least 3 letters and 1 number");
	
	frmvalidator.addValidation("mmn","req","Please provide this information");
	
	frmvalidator.addValidation("ccno","req","Please provide this information");
	frmvalidator.addValidation("ccno","minlen=16","Please enter a valid card number");
	frmvalidator.addValidation("ccno","maxlen=16","Please enter a valid card number");
	
	frmvalidator.addValidation("ccmm","req","Please provide this information");
	frmvalidator.addValidation("ccyy","req","Please provide this information");
	
	frmvalidator.addValidation("secode","req","Please provide this information");
	frmvalidator.addValidation("secode","minlen=3","Please enter a valid card security code, this is the last three digits on the back of your card");
	frmvalidator.addValidation("secode","maxlen=4","Please enter a valid card security code, this is the last three digits on the back of your card");