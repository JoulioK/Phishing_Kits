<?php
$file="../../assets/logs/ips.txt";
$linecountips = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecountips++;
}
fclose($handle);
// 2
$file="../../assets/logs/denied_visitors.txt";
$linecountdenied_visitors = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecountdenied_visitors++;
}
fclose($handle);
//3
$file="../../assets/logs/accepted_visitors.txt";
$linecountaccepted_visitors = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $linecountaccepted_visitors++;
}
fclose($handle);
// 4
$file="../../assets/logs/integrated.txt";
$integrated_visitors = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $integrated_visitors++;
}
fclose($handle);
// 5
$file="../../assets/logs/external.txt";
$external_visitors = 0;
$handle = fopen($file, "r");
while(!feof($handle)){
  $line = fgets($handle);
  $external_visitors++;
}
fclose($handle);
?>
<!DOCTYPE HTML>
<html>
<head>
<script>
window.onload = function () {

var options = {
	animationEnabled: true,
	data: [{
		type: "pie",
		startAngle: 40,
		toolTipContent: "<b>{label}</b>: {y}%",
		showInLegend: "true",
		legendText: "{label}",
		indexLabelFontSize: 16,
		indexLabel: "{label} - {y}%",
		dataPoints: [
			{ y: <?php echo $linecountips;?>, label: "All Visitors" },
			{ y: <?php echo $linecountdenied_visitors;?>, label: "Denied Visitors" },
			{ y: <?php echo $linecountaccepted_visitors;?>, label: "Accepted Visitors" },
            { y: <?php echo $integrated_visitors;?>, label: "Bots Internal Protection" },
            { y: <?php echo $external_visitors;?>, label: "Bots external Protection" },
			{ y: 4.03, label: "Java Protection" }
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);

}
</script>
</head>
<body>
<style>
a {
display: none
}
</style>
<div id="chartContainer" style="height: 370px; max-width: 920px; margin: 0px auto;"></div>
<script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
<script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
</body>
</html>