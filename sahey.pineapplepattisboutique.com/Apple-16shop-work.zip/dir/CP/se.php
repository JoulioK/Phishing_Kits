<?php
[setting]
setup_rzltpa = admin
?>
                     