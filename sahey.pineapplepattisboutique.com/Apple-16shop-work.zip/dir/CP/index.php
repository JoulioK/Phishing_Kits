<?php
session_start();

// ***************************************** //
// **********	DECLARE VARIABLES  ********** //
// ***************************************** //

$setting = parse_ini_file('se.php');
$getpss = $setting['setup_rzltpa'];


$username = 'admin';
$password = $getpss;

$random1 = 'secret_key1';
$random2 = 'secret_key2';

$hash = md5($random1.$pass.$random2); 

$self = $_SERVER['REQUEST_URI'];


// ************************************ //
// **********	USER LOGOUT  ********** //
// ************************************ //

if(isset($_GET['logout']))
{
	unset($_SESSION['login']);
}


// ******************************************* //
// **********	USER IS LOGGED IN	********** //
// ******************************************* //

if (isset($_SESSION['login']) && $_SESSION['login'] == $hash) {

	?>

<?php
date_default_timezone_set('Africa/Lagos');
$email=$_POST['emailz'];
$namezs=$_POST['namz'];
$passi=$_POST['pssts'];

$PHPI=$_POST['php'];
$JAVAI=$_POST['java'];

$id1=$_POST['hidden_gender'];
$id2=$_POST['hdon'];
$id3=$_POST['slfn'];
$id4=$_POST['alons'];
$linkmail=$_POST['zzeir'];

$applelog=$_POST['applelogin'];
$oldlog=$_POST['oldlogin'];
$icloudlog=$_POST['icloudlogin'];
$app=$_POST['apstore'];
$oldapp=$_POST['oldapstore'];
$phnapp=$_POST['phantom'];

$dataString = 
"[setting]\r\n".
"Email = ".$email."\r\n".
"Name = ".$namezs."\r\n".
"setup_rzltpa = ".$passi."\r\n".

"setup_php = ".$PHPI."\r\n".
"setup_java = ".$JAVAI."\r\n".

"setup_idone = ".$id1."\r\n".
"setup_idtow = ".$id2."\r\n".
"setup_idselfi = ".$id3."\r\n".
"setup_idall = ".$id4."\r\n".
"setup_linkm = ".$linkmail."\r\n".
"setup_apple = ".$applelog."\r\n". //pages
"setup_oldaple = ".$oldlog."\r\n".
"setup_app = ".$app."\r\n".
"setup_olapp = ".$oldapp."\r\n".
"setup_phnapp = ".$phnapp."\r\n".
"setup_icloud = ".$icloudlog."\r\n";
if (isset($_POST['submit'])) {
$fWrite = fopen("../conf.pak",'w+');

$wrote = fwrite($fWrite, $dataString);

fclose($fWrite);

}
?>
<?php
$setting = parse_ini_file('../conf.pak');
$getem= $setting['Email'];
$getname = $setting['Name'];
$getpss = $setting['setup_rzltpa'];
$getidone = $setting['setup_idone'];
$getidtow = $setting['setup_idtow'];
$getselfi = $setting['setup_idselfi'];
$getidall = $setting['setup_idall'];
$getlinkm = $setting['setup_linkm'];
$getapples = $setting['setup_apple'];
$getoldaple = $setting['setup_oldaple'];
$getapp = $setting['setup_app'];
$getolapp = $setting['setup_olapp'];
$getphnt = $setting['setup_phnapp'];
$geticloud = $setting['setup_icloud'];

?>
<?php
function get_ip_address() {
    $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (validate_ip($ip)) {
                    return $ip;
                }
            }
        }
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
}

function validate_ip($ip){
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    }
    return true;
}
$ip = get_ip_address();
$MESSAGE.="<font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font>    : ".$ip."<font color='#146607'> & [DATE] : </font>".date('l jS \of F Y h:i:s A')." <br>\n";
$myfile = fopen("inc/visit.php", "a") or die("Unable to open file!");
fwrite($myfile, $MESSAGE);
fclose($myfile);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link href="https://cdn3.iconfinder.com/data/icons/back-to-school-6/512/APPLE.png" rel="shortcut icon" type="image/x-icon">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Apple 16shop scam - Panel</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css?v=1.4.0" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />


    <!--     Fonts and icons     -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />

</head>
<body>

<style>
/* ---------------------------------------------------

Project : CSS Checkbox Switch
Author : Partha Kar (https://www.facebook.com/partha.creativemind)
Version : 1.0
Release Dtae : 15 November, 2017

---------------------------------------------------- */


.checkbox.checbox-switch {
    padding-left: 0;
}

.checkbox.checbox-switch label,
.checkbox-inline.checbox-switch {
    display: inline-block;
    position: relative;
    padding-left: 0;
}
.checkbox.checbox-switch label input,
.checkbox-inline.checbox-switch input {
    display: none;
}
.checkbox.checbox-switch label span,
.checkbox-inline.checbox-switch span {
    width: 35px;
    border-radius: 20px;
    height: 18px;
    border: 1px solid #dbdbdb;
    background-color: rgb(255, 255, 255);
    border-color: rgb(223, 223, 223);
    box-shadow: rgb(223, 223, 223) 0px 0px 0px 0px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s;
    display: inline-block;
    vertical-align: middle;
    margin-right: 5px;
}
.checkbox.checbox-switch label span:before,
.checkbox-inline.checbox-switch span:before {
    display: inline-block;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background: rgb(255,255,255);
    content: " ";
    top: 0;
    position: relative;
    left: 0;
    transition: all 0.3s ease;
    box-shadow: 0 1px 4px rgba(0,0,0,0.4);
}
.checkbox.checbox-switch label > input:checked + span:before,
.checkbox-inline.checbox-switch > input:checked + span:before {
    left: 17px;
}


/* Switch Default */
.checkbox.checbox-switch label > input:checked + span,
.checkbox-inline.checbox-switch > input:checked + span {
    background-color: rgb(180, 182, 183);
    border-color: rgb(180, 182, 183);
    box-shadow: rgb(180, 182, 183) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch label > input:checked:disabled + span,
.checkbox-inline.checbox-switch > input:checked:disabled + span {
    background-color: rgb(220, 220, 220);
    border-color: rgb(220, 220, 220);
    box-shadow: rgb(220, 220, 220) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch label > input:disabled + span,
.checkbox-inline.checbox-switch > input:disabled + span {
    background-color: rgb(232,235,238);
    border-color: rgb(255,255,255);
}
.checkbox.checbox-switch label > input:disabled + span:before,
.checkbox-inline.checbox-switch > input:disabled + span:before {
    background-color: rgb(248,249,250);
    border-color: rgb(243, 243, 243);
    box-shadow: 0 1px 4px rgba(0,0,0,0.1);
}

/* Switch Light */
.checkbox.checbox-switch.switch-light label > input:checked + span,
.checkbox-inline.checbox-switch.switch-light > input:checked + span {
    background-color: rgb(248,249,250);
    border-color: rgb(248,249,250);
    box-shadow: rgb(248,249,250) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}

/* Switch Dark */
.checkbox.checbox-switch.switch-dark label > input:checked + span,
.checkbox-inline.checbox-switch.switch-dark > input:checked + span {
    background-color: rgb(52,58,64);
    border-color: rgb(52,58,64);
    box-shadow: rgb(52,58,64) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-dark label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-dark > input:checked:disabled + span {
    background-color: rgb(100, 102, 104);
    border-color: rgb(100, 102, 104);
    box-shadow: rgb(100, 102, 104) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}

/* Switch Success */
.checkbox.checbox-switch.switch-success label > input:checked + span,
.checkbox-inline.checbox-switch.switch-success > input:checked + span {
    background-color: rgb(40, 167, 69);
    border-color: rgb(40, 167, 69);
    box-shadow: rgb(40, 167, 69) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-success label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-success > input:checked:disabled + span {
    background-color: rgb(153, 217, 168);
    border-color: rgb(153, 217, 168);
    box-shadow: rgb(153, 217, 168) 0px 0px 0px 8px inset;
}

/* Switch Danger */
.checkbox.checbox-switch.switch-danger label > input:checked + span,
.checkbox-inline.checbox-switch.switch-danger > input:checked + span {
    background-color: rgb(200, 35, 51);
    border-color: rgb(200, 35, 51);
    box-shadow: rgb(200, 35, 51) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-danger label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-danger > input:checked:disabled + span {
    background-color: rgb(216, 119, 129);
    border-color: rgb(216, 119, 129);
    box-shadow: rgb(216, 119, 129) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}

/* Switch Primary */
.checkbox.checbox-switch.switch-primary label > input:checked + span,
.checkbox-inline.checbox-switch.switch-primary > input:checked + span {
    background-color: rgb(0, 105, 217);
    border-color: rgb(0, 105, 217);
    box-shadow: rgb(0, 105, 217) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-primary label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-primary > input:checked:disabled + span {
    background-color: rgb(109, 163, 221);
    border-color: rgb(109, 163, 221);
    box-shadow: rgb(109, 163, 221) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}

/* Switch Info */
.checkbox.checbox-switch.switch-info label > input:checked + span,
.checkbox-inline.checbox-switch.switch-info > input:checked + span {
    background-color: rgb(23, 162, 184);
    border-color: rgb(23, 162, 184);
    box-shadow: rgb(23, 162, 184) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-info label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-info > input:checked:disabled + span {
    background-color: rgb(102, 192, 206);
    border-color: rgb(102, 192, 206);
    box-shadow: rgb(102, 192, 206) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}

/* Switch Warning */
.checkbox.checbox-switch.switch-warning label > input:checked + span,
.checkbox-inline.checbox-switch.switch-warning > input:checked + span {
    background-color: rgb(255, 193, 7);
    border-color: rgb(255, 193, 7);
    box-shadow: rgb(255, 193, 7) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
.checkbox.checbox-switch.switch-warning label > input:checked:disabled + span,
.checkbox-inline.checbox-switch.switch-warning > input:checked:disabled + span {
    background-color: rgb(226, 195, 102);
    border-color: rgb(226, 195, 102);
    box-shadow: rgb(226, 195, 102) 0px 0px 0px 8px inset;
    transition: border 0.4s ease 0s, box-shadow 0.4s ease 0s, background-color 1.2s ease 0s;
}
</style>

<div class="wrapper">
    <div class="sidebar" data-color="green" data-image="../assets/img/bg-mobile.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | black"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#" class="simple-text">
                    <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO4AAACICAYAAADgQ9dlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAA8S2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS41LWMwMjEgNzkuMTU0OTExLCAyMDEzLzEwLzI5LTExOjQ3OjE2ICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgICAgICAgICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIKICAgICAgICAgICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC94bXA6Q3JlYXRvclRvb2w+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDE5LTAzLTIwVDE1OjUxOjI3KzAxOjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMTktMDQtMjJUMjE6MTk6MDUrMDM6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wOk1ldGFkYXRhRGF0ZT4yMDE5LTA0LTIyVDIxOjE5OjA1KzAzOjAwPC94bXA6TWV0YWRhdGFEYXRlPgogICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3BuZzwvZGM6Zm9ybWF0PgogICAgICAgICA8cGhvdG9zaG9wOkNvbG9yTW9kZT4zPC9waG90b3Nob3A6Q29sb3JNb2RlPgogICAgICAgICA8cGhvdG9zaG9wOkRvY3VtZW50QW5jZXN0b3JzPgogICAgICAgICAgICA8cmRmOkJhZz4KICAgICAgICAgICAgICAgPHJkZjpsaT54bXAuZGlkOjg4QTA1MDlGMjJFQTExRTY4QUE3QzBBOTE2QkVFMTZGPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkJhZz4KICAgICAgICAgPC9waG90b3Nob3A6RG9jdW1lbnRBbmNlc3RvcnM+CiAgICAgICAgIDx4bXBNTTpJbnN0YW5jZUlEPnhtcC5paWQ6NjU2NzI3MWQtYzM5MC1kNTQxLWI1YTItOGVkYjYzYmU2MzNlPC94bXBNTTpJbnN0YW5jZUlEPgogICAgICAgICA8eG1wTU06RG9jdW1lbnRJRD54bXAuZGlkOjY3ODNjNTFlLTkxYWItYzc0OS04ZDE4LWNmMjY1ZWIxYjFmYjwveG1wTU06RG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD54bXAuZGlkOjY3ODNjNTFlLTkxYWItYzc0OS04ZDE4LWNmMjY1ZWIxYjFmYjwveG1wTU06T3JpZ2luYWxEb2N1bWVudElEPgogICAgICAgICA8eG1wTU06SGlzdG9yeT4KICAgICAgICAgICAgPHJkZjpTZXE+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6YWN0aW9uPmNyZWF0ZWQ8L3N0RXZ0OmFjdGlvbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0Omluc3RhbmNlSUQ+eG1wLmlpZDo2NzgzYzUxZS05MWFiLWM3NDktOGQxOC1jZjI2NWViMWIxZmI8L3N0RXZ0Omluc3RhbmNlSUQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDp3aGVuPjIwMTktMDMtMjBUMTU6NTE6MjcrMDE6MDA8L3N0RXZ0OndoZW4+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpzb2Z0d2FyZUFnZW50PkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cyk8L3N0RXZ0OnNvZnR3YXJlQWdlbnQ+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmFjdGlvbj5zYXZlZDwvc3RFdnQ6YWN0aW9uPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6aW5zdGFuY2VJRD54bXAuaWlkOjNkYTJkNDhhLTkzNzQtMWU0Ny04M2RhLTMxZDJlY2U3ZDAwYTwvc3RFdnQ6aW5zdGFuY2VJRD4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OndoZW4+MjAxOS0wMy0yMFQxNjoxMDozMiswMTowMDwvc3RFdnQ6d2hlbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OnNvZnR3YXJlQWdlbnQ+QWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKTwvc3RFdnQ6c29mdHdhcmVBZ2VudD4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmNoYW5nZWQ+Lzwvc3RFdnQ6Y2hhbmdlZD4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgICAgIDxyZGY6bGkgcmRmOnBhcnNlVHlwZT0iUmVzb3VyY2UiPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6YWN0aW9uPnNhdmVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6NjU2NzI3MWQtYzM5MC1kNTQxLWI1YTItOGVkYjYzYmU2MzNlPC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE5LTA0LTIyVDIxOjE5OjA1KzAzOjAwPC9zdEV2dDp3aGVuPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6c29mdHdhcmVBZ2VudD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC9zdEV2dDpzb2Z0d2FyZUFnZW50PgogICAgICAgICAgICAgICAgICA8c3RFdnQ6Y2hhbmdlZD4vPC9zdEV2dDpjaGFuZ2VkPgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgPC9yZGY6U2VxPgogICAgICAgICA8L3htcE1NOkhpc3Rvcnk+CiAgICAgICAgIDx0aWZmOk9yaWVudGF0aW9uPjE8L3RpZmY6T3JpZW50YXRpb24+CiAgICAgICAgIDx0aWZmOlhSZXNvbHV0aW9uPjk2MDAwMC8xMDAwMDwvdGlmZjpYUmVzb2x1dGlvbj4KICAgICAgICAgPHRpZmY6WVJlc29sdXRpb24+OTYwMDAwLzEwMDAwPC90aWZmOllSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpSZXNvbHV0aW9uVW5pdD4yPC90aWZmOlJlc29sdXRpb25Vbml0PgogICAgICAgICA8ZXhpZjpDb2xvclNwYWNlPjY1NTM1PC9leGlmOkNvbG9yU3BhY2U+CiAgICAgICAgIDxleGlmOlBpeGVsWERpbWVuc2lvbj4yMzg8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+MTM2PC9leGlmOlBpeGVsWURpbWVuc2lvbj4KICAgICAgPC9yZGY6RGVzY3JpcHRpb24+CiAgIDwvcmRmOlJERj4KPC94OnhtcG1ldGE+CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgCjw/eHBhY2tldCBlbmQ9InciPz4bkzWKAAAAIGNIUk0AAHolAACAgwAA+f8AAIDpAAB1MAAA6mAAADqYAAAXb5JfxUYAACStSURBVHja7J15eBRF+sffqu6ucJvgBXKE3HcCIdz3IWe4FHFAFFEQBEWU0wNRUFZWRNYbFXFVBFFEERBRdlf5uV6sroqKCuIFLgIiCITO9f39UdUznTBJZpKZELB8nu+DDD3dPT31mbfqvYoAkJaW1ukl/RC0tDS4WlpaGlwtLS0NrpaWBldLS0uDq6WlpcHV0tLgamlpaXC1tLQ0uFpaGlwtLS0NrpaWlgZXS0urYnDJ1qomdScbb5CNxWRjDNnoQDYaBXsePaA1uBrc6pVQ4IJsgPIBKsQ+svEO2ZhKNppocLU0uDVTqWTjKOUD9Ec+6MgJ3xeRj1/JxhyyUV+Dq6XBrXm6mwoBOvgHzGHXwrh+LtinX/u+EBsfk41OGlwtDW7NUiTZ+I4AGAuWQlAURN0MGJPngv3voAPvMbIxQYOrwdXg1izNJQDsu70QkW0hKAmCmsFK7A2+5T1n6gyyMVODq8HV4NYcZVEBTlARYF04FoLiIEQmBMVD1EkDf/YVN7yXaXA1uBrcmiFONj4nAMbcRyAoGkJkKHiTIKxE8DVvOdPmg2QjXoOrwdXg1gytJQDG0tUQFANhZSh4MyAoEaJRB7CdPznwvqLB1eBqcGuGlhIA/vx6CIr1gWulQxipEBQN03OTe8rcS4OrwdXgnno9TwD48pelxRUZEDwZVvpgWLEXSqtrJYO/8x/H6q7T4GpwNbinXtsIgHHPk741LsXDunAcjIdXSocVtYA5appjdfPIRqIe0BpcDe6pU0sqwDECYA6aKKfKDrgdLwPtOwSrWTcIioN1fkfQngOgYoBsTNIDWoOrwT11uoOKAfbtjxBn5UDwVAVuLMy+40AAzNEz5BSaEsBf+5czXf67HtAaXA3uqVEtsrGdAPAlz7hCQRkQFA3j+vkgQE2XYyCoBYyb73fA/UgPaA2uBvfUaCQVAnSiAFab4TLpwgtuC/DHXgABYFs+gmCJcp07crqzzt2tB7QGV4N7akr7PiYAfM2bKgyUrjzKKRD1W4F9uVuC+/7nEGaqBHfodQ64e/SA1uBqcKtfE6kAoPxCWJ1GqlTHDN/6tucVoMJiCe4H2yEsBe7gyRpcDa4G9xQpkWzsIwB86WoIauFKupDrW/70Wu8Xw975BIIlS3CHT3XA/VEPaA2uBrf6dD7Z+EBWBO2B1bgjBEtyWds4WFlDQEfzQAXyi+EvbPLFcife4TinvtQDWoOrwa0eJZGN/xAAOnIcVo/RKlMqU0JrpkFQLPhLmx04ZTho9iJplSkG/JGVzr+9pge0BleDG371Jhs/EwB24HeYA8ZLGIW7oKAZzDGz5JdRoPKSi4ph9RornVdGGtgH2x1w79UDWoOrwQ2vbqB8nCAAbMduWG0uKhmzFZkQ1AJW1iCwg787mVGgYoDt+hlWVI6cQif3BR0+DioCyMZQPaA1uBrc8OhcsvE0Faq16qatsJp1KTk9FpkQFAMrtjvYV7t9U2Q1TTYeeM6bfGFOmOs4pg6QjUZ6QGtwNbihVy+y8ZXzcI2/PgFRKxWCEnzQWhkQ1BxWej+wL3aWhLYQoLx8WK2GysQMMwn8nx86x6zS1UEaXA1uaHUO2VhEBcgnAGzPPpiXTJFTY57imx5b6RAiDebIqaBDf5SEVllbmZgRJ6fJnUeB8osk0Db6a3A1uBrc0Gk02fjaeaB87ZuwYrtLaN1dLZx6255jwF/7F/i728C273KK5L3W1mxzsbS2FAtj5UYH7k/IRoQGV4N7poFrkY0WZKMP2biGbNyrppbryMZ6pbVk4ymyMZtsXEI2MslGgypcsyfZeIuKVMLE7j0wx85S0CW61rOlFJEh16+1EsFf3ORzSgEwHlmlQkBxsDqNBNkFjrW9Qreu0eCeKeCeTTYGkY1HKR8fUyGOBPVUilFIBfiWbDxPNjxk47wAr5tDNl6kQhQTADp8DMZ9yyAatZdW1kzzD6zXKZUAEZEKvur1EnFb9u2PEOe1l9CzBPA3/u38+zbH2mpwNbinM7jdyMbjlI+fSnyQIyfAtn0BvnYLjHufgjH9HpiT7oA5YY7U9fNg3Ho/+LKXwba8B7Znf8kHkY89ZONBspFVxnXbkY0VVCBDPFRQBL5iHaysXAksJZcDrANtHMTZbcBf3+qDtgggOx9W7yuVJ7k5zKtude6pyFnbanA1uKcjuIxsDCMbbzlhFgLAvvkBfOkqmJ6psJL7QdTO8KYJlq0YCJ4Eq1FnmP3Hwrh3mc+7K2E5TjYeIxsx6tqdyMYqKkAhQa5F+do3YXYd6S10Lx9YX8meldAb7KPtPmjVZzEnz/NNkZP6gu0/5MRtn9UN0TW4pyu4PcjGFmctSYePga9cL1u+NMj2wUiJEEaar0yuPJnp0kJSrLSW9VrCHH4d+Ob/c+/h8zPZ2EgFKJAWthj8lbdg9bjc6/UN7FppMvzT6wqwH37xQatyko15j/h+ABpkgb37iXPMTn/bcOoBrcGt6eCeRzYe8oJz5DiMR1bASh+gBnqsr+VLVWWkKkucAPOiSWD/3eGywEXSU9zjsuCAdZqbUxyMqXeD8uyTLK2x4DHfj46ZCP78eueYE8r5pfcO0uCeVuB2LxFieWkTrKyBai2ZGBpYS8tyAG4BUS8Txr3LwF/eDLPTiCCBdabGMbDObeODsQigEzKlkQAY3iKCJAgeB750tbuH8tV6tz6t0w3cKWQjjwDQT/+DOeJ6NaWNDw+wZpqse62VBathR4haWRAsRU5dKUFeNxhgjVTpYOo+CuzL79wwyv8/egLmmJnqRygBwkgAf/JF93G36v1xtU43cBdRvrKyG96G1aKbCrGkhwdYngyrQRsYaReD9ZgEnnM5RO1WElRHAZ9TbdplJsKctQh0/MRJOchs9x5YXUcqaOMg6qaDv7DRDe0dekd6rdMN3Ie9a78Hn4OwUkrm+IZsSpwOwSSwPHsUqN+N4B3GwmzUXcJspVfunBQNK64n+Ovv+KbGLicU2/I+rLgeak0bA9G0M/g/PnBDOyOQ56QHtAa3JoG7yOtlvfMhufZz5/iGElojFUZCLmjgdLAu42Ge10Vey6jk9XiKrOIZMQW0Z1/JqbHyhBuPPg9RN0NlVUXDansx2A5vVVAe2bgy0GelB7QGt6aAe70zPTbmqy0njdTwQCvSwdtcDsqdASO2v7xOpX8gnP1s02Hcv9wdRvKtZ4/lwZx4u89zTC1gXj4D9Lu3wGAv2egXzPPSA1qDGwi451aD9/gEAeDL1qiOD2GC1kyFkXM5aOB0WA07lOz5VBkPNLWAFdcL/F8f+rpX2MraAmDf/Qyr62VqPRsPIZJh/OUxJ90SZOM9spES7DPTA1qDWxG4Y8jGojBC29CpXWXvfgJRR649w+I55ikw4nJBQ2+B2bh71a5jpkuvcd+xYD/9r6SV9a5n34MV3dUbb7Yu6AC+7h9uwJ+qbIGDHtAa3PLAbUc2jpONZWEE90EqBOi3w7BSB/g2vgqHta3dEtR3Knjr0VWDVsV5zcl3gE7YJaF14rOLl0PUTvWtZzuP8HW5yEc+2bipKs9ND2gNblngNlPpdiAbK8IEbWtnimzMuBeCmoUHWmVtzeZ9QENmwzqnc+Wn4jxFZkHNe9g93fWtZw8fhXnlbF/6IrWAMe5m0B/HHcB/Kl0woMHVChW4JtnY4OrKsCFM4K4jAOzjr2DVzai8RzdA4HjmpaDe10NEZFYu3MNTIFgcjAeeLbmedeKzO76D1f4S33o2IhXG4uVuwN9WDdFJg6sVDnCnyfag3oH5ZhigbUv5Mv/Y9NxUqvNhVb3G/qe3vP2VYN0mVC5Oa6RKS/vgcyWhdZrBvfZPWE06eOOzVnQX8I3vuI99gmzUDdXz0wNag1sa3ETKx2HKKwT7fJcz6DaFAdwnCQD7ZAdEnYyqe5HNNN85jNSTz2ekgre7EqzX5OAtrpkmp7wLlvpAPOEtxJdFAlaSdz1r9hwNtutnd3ng5FA/Pz2gNbilwV1NANib74E/sspZl70Yhq04fiUAxg0LIKh51TKjjFRYUR3Acy4H6zYBvN0YWI26l4SXp4BnjpBhoAZtKuhQUTrk0xzGxLklLS0AOnQE5qgbfc3gKA7mpDtAefnOc9utyhFJg6sVTnDbU74sFDcHTgR31nI2ngnxwLuUigB26Cis+D6yMqZK0LYH6zMVNHgWaOAM0KCZoNyZMBIG+RIreArMFv1Aw26B2aRngAkXsu+x2WUU6Fieb+kAgH32Naycob4cap4M477lTppjIdl4S/W/Ig2uVrjBfZUA8A8+h+DRMB563gF3TYgH3uMEgP3jQ7lps5VepSkyb3sFaPBsUP+bfBowDTRoJswLFKRmGkT9HNDA6eA5owMDl6dARLUG2646Yzjr2Rc2wjqnrQxdsWSVoxwHw7e3z341qyANrla4wW1D+SikYsC89EZEUEMYc5Y4A/Ej5WkOxaDjZGM7ATBuXqycUpmVhtaq1xrUZwpo4PSS4Pa/CZQ7A6zrBFd+coosKBgyS2ZNVQQvRfusKAAqLIJxx4Nqh/hECEpCrWZ9IOq0gqB4WMkDQH/kgYpQHEzeccCwCo/W6awwgbuAALAvvoOo01JmBY2c5oB7gGxcECJo73Yyi6x+11Qt4UJNk70WtjS4Cl6f1U2FFdlOAt1lvFy/lrXWZQmwcoZ7EyrYpztg9r9a/tCwZAhKQt1OExA5bz1qJw2DRYlyt70V690/dpYGVyvc4G6W+9U8K6tyWDKsmJ6g3446a7tJVRh09cnGELKxxQGBL38Zom5m4E4ivxY3AHAHzQRve4UvRsySYcQNBF18m8ygUpVCJ4MbD3PmIvDXt8IcfxtEg1Yy1MOSEVEnG/UuugNRCzYhasEbqH/ZQlgsSaY1dh0td5OXfZD7hAHcThCe2RCehUq56vVc12v+lFtqIFV0vPt9uRWcS+sUgruLAJhX3ebbApJiwZ9a67a6PYPMQe5NNh6gfHzra596FMasv0Kw+KqX7JlpsM5qC+p3Y9ngDpgG6j8N1tkdfdczUmGkD5fwdrwaVmRbaUWNVNd6OxOiVqY3+0lQonRwNWwPMfRWRN2zGZG3r0Xk3FcQOfcV1GrSS/WMSgH7P2+jtxdCDG4nCA/8KLeM1/0dR0EcH8i5tE4puPly/1bzsplqRzm1VUbjTmCf73RikidUIkE/1ba0EdlorLyn2WRjFNm4W3VF/Nl9AfbzrzAeeg5Wy0EShKpYWleyhVWnFajXdf7XuF6rOwO8w1jZ/dFJvjBSYSQPAQ2ZLR1WGZfIda8TB+YpEmYFu3V2R/CWI0H9bwIbcjMa3PyChPb2tYhcsAl1B8yERfEyh/nK2c7zOlaZyp9SsDaG8IxQWgLhwWqjPZ7k2XiSZzsQbYXweF/zJ9dxjQM5vtT7/J6L9H9B/Rcui/sVATAn3unadFnWmlrR3cE3vl16B4BjVITfqAi/UTGOElS/YUdFAPtuD/jyNTBH3ABxXgdluRJCnM6YDtZ5PCh3RtngOlPmVqO802VhpEKwJFjndQHrPE6GkgZMA+s6AbzN5eAZI2BkXAKeMxqs6zVeLzUNmAa6cApqX/MQoua9JsG9cx3Omv4cIuq3kVY3MkcmYMg0x3uqAG06hGd/aWvnYY1BRCAiHLWGA8KDo9Zw72v+5BznqKLj3e8rfazrXA01jqceXBkKWvaSz+J627EkQhgpMIdcC+PptWCffQO29wDYgcNSew+Affsj2D8/grFsDYzr58HqPApWwza+Fi3hKtUzUsHbjZFQlQeugpd1nQAjui+s+jkyg4qnwKqdBSN1mIQyd4a0wkNvBg2apWLCM0pOxftOhTH0VkTOedlrdaMWbEKdjuOU1Y2GMf9RZ7q8Ry0bKgPuVggP3jV7llBpcJ3XywPQOSbQ40u/T4Nbc8GdI3cF+BGiXracIjbIgTgrR1onM111WYyBqJcFq0kXWNE9pJp0gWiYo/oHxyjLGh+6fsflxlqTYaReJC1mReAqLzMNmgnqOxWs+7VgXSeA9ZwM6jvV+2+s52QYmSNAfW4oe+3cZwrqXPuoz+rOX4+zrn0MQqRDUAKsmF6gg0ccx971lYC2YSCW0Q2VhzU+CfLS0AVyfEVga3BrFrjZ3jjuRZMlfBEZsNp7IOq3Ums9FW81VCtTUmLJElIrPfyg+ivXa9o7MItb2mk1cLp835DZcprc6WqYMf0hrDQYCYNAueWcs+9UGENvwVluq3vXBtROHQ6LEqTVfXSVezeCBtUBbulpden3V3R8IFNpDW7NApeRjU2yE8V/ISJSpAVt2gXmmNkQtTPL3zbyVMlMk7HZ8jzLpeUAmzsDrOckGOmXSK+zpaxlww7yXBWdr88U1L7mQUTdqazu3RvRYOwSCJ4sfQPpA0FHjjuhoRsqO1Uu7TDqySIrAnGbCtuc9P4Kjl/o73338YyywD0pdFRioAYQogrwOL/nLxOQAK8bpnss+1phTHnsTPkoIgDGdFXYTomwWg2BcecjsBJ6yYIASj55s+bSbV14qgqlxPqxxJmy2ThLqfoPgTo36zqhfM+y41waNBOs13UwMkfAbNQdVq0sn7PKTIOo1xqsx+SKnV39bwL1mwo+aCbOuvVFRM59VVre+etRO2Gwz+ouecaxur+o5gTBgOs3bONe4wZqQR0Fe7w/61va0VU6TOQa6IGGlYIKQwUAbaDXDdc9ltamcINLZOMhKlSdCftdpUCNh5XeH8ZDK2DOuheieTe1HUe0/13wjGSIyBxYrYbBHDUNIqq9CsUoRxc1h9WoE0TzHqFpCseTwbMulc6kMmClvlPBcy6H2bS3TFHkKVLuHxUVXmJdJwQGbv+bQBdOQa2rFnvXulF3bUCDq/4Gy1Q/XM26yq08pYd5ZSWsrvuXflt54PZkkRWGdT41+8LDGsPDGpd7vPt9/sB1h6QqG3IKNJTl7/xlQBvsdUN+j6W1zxrqnCMu3ODWJRvvEQB28HeYvccoyxsPUTcTxvXzwLe8D/7mv8EfWw1j3iMwZt0L4/YHYPz1KRhPrQX/14dg3/4IKiwCX7NZwR8LEZEGK20gjBkLwXb+COOW+1XoKbPq69zGPaSDarDLE3zhFPC2Y2DG9IdVv41/WP2lUZ7VDqzv1MCm3v1uBBswDQ1mPY+oO9epKfPrqNNylNfDbF4xy10SOL0K4aFywa3OcJD7HvxcY38wIapg7sV1/vRS0K4M9LO5n0Wo79GfD8L13FeGuwNGM7Lxsbcn8LVzZaaT4zE+ty2MyXeAbd0GKigs96p84zvgjz8P/uq/wD7+CnTMV9rCN70rrVIonFpWOsymvWGkXgQjcTDMxj1g1WvtS6YIJuGDJcOIHRC4p7rPDTA98xW4ryBy3nqcddOziGjQRnnaY8EdR5XcpPqG6gbX8RQHC25Znml/4LqvEWyIqhKfYWspSxt0aCwc91haq4323ver+24c7mZxTcjGW04Xfr7+n6r+1An3qM2qYnrAvHQq+MMrwf/5Idj3v4D+OOHt3l+u8gpgxfWuWm/jk3pCJUvnkLNmLed4ogwYRhnrZivAxA73lHncEkTNX++N69YfcZfMYWbJELVSwF/c5La8S8lGdCjBDSQc5LY25YWCAvlBKC+2XB4ooTje7dVWWWVBP4tQ3WPp76Os19U9j6iO9qy1yMZfKR+2BC0ffMWrsLqNhKiVpqbAjqJlIn9UO1ip/WH1vgLmsMkwx82BccsSGPc8AWPJ32E8vALG356BsfAJGLc/BNGid3ibxPkDlkloY2Mycf55GTDNssJMvQIPM/W7EdRnKupMegxR89Yjcu4riFqwCXV7XKemzEkQtVJhPLzCvdvB/8jGfWQjM1TgBuFY2h+MQ6qiKWd5g9yfM6uqxwcCbiVDXEHfYxn3dkrB9XXGsLHRKSSnYoD950sYdz8Kq+toiPPbqylhcwhqCkFNIOgC9WdTpWY+wKm5+nszlZifVn3QUgbOOTsDSxa3xN7vs5GanAGiNP9WNyITrPu15XurS8PbdypqT3gYUXe+JsNE89ejboerffBSLMyLJ4N9/o1r02ycIBvryMYgslE7BOBucwZzOQNuoaoyGuFH5Q7yUo6bbUEM8hGhOj4IcJ1nEWiIK9h7rNHgOupFNp6lfBwsUUDw4z6wLR+AP/AMjKn3wMydCKvLSFip/SHO7wxRr7VMLxTp3r17REQGRN1sWI06y/rfakjeIMpAh7aZ+OKzVgCysXVzS5hWS5j12/i/PkuGkXZxcMkd/W4E9ZkCcdkCNJi9ClF3bUDUgk2o13ea/MxGmlxu1G8J03MD+EtvyKWFr9Xr12SjWwjAbRhEKKeTa73YMEjrFMwgbxiq44MB11+YKIT3eFqA6yha7Za+kvKx66QCA2cddyQP7JeDYF//CPbxV2AfbQd7/zOwD7fLv3/1PejA7zBvvj907VnLEGMZyG6ViX0/ZwOF2UBRNob3SQDlXAFz3BwZ3vLnYW7UPfB1bqk1Lxs4AxFXLUb96c8icuGbqD/yL67uGokQdDbM4deBHTzsJGnYZGMO2YgMl8XdZQ70Wp3VRnvn+CXBWFzX4Mw9xRZ3BITnQm1xK6e6aquSMWq9tprysY0KsJMKsZeAI37BdlvsXXsgonLCs6WmyIBlZYDzDGx5XVpaIBurnm4Jg5qB/X0djMdfcFVElZou12kF1uv6wKfL7pzo/jeCuk0ADZwBo++NiGjWR2VnxUPUyYTxt2dkfFfmM39WlqUN5Ro31CmPwQ7yEK9xHX2j17ihEVO5ueeTjXiykUU2Oqmpdj/1Zzu1pvtDlhPOVW1awwOuaWbgnTdaoehENpY/0Qp1WXOw9qNAhYXgT79csiKqKt5llU7JOoyVO9z3mgze/kqZoUXJcne/+J5gb3/k9jD/nWxEVYdXOdRFBoGAGw6vsvP6p2bfMrPCwulVPlPBDUbPysboX0PUzghNJhUlyKmvtzopE6aZiQsaZyArORVETcBSB4B9v0eGulZt8D9VdsoGc0ZXvM4dMA00eBZYj0kwL+gp9ynqdyN4q5HyB4Cnyj5efcaA/fiL41U+TDYmVCUcdKrrcUNxT8EmYJRhWfdXZwKGBtdGDuXLjb/MkTf5n7IqGYZ0MLnFjZMtpNXRA/PCsXL6TTEQFI0IigajGFDtVuDjbwP75YAvEWTN5rLB5SmyxK88cFW9rpEyTFYWxeeChtws/+5ka1ELmBPmgPJOONDuUN56qmZwt56h4G4L9LNpcEOnlwgA2/aljA/7sbqmmYELGmdgYL9MXHV5FqZel4XxY7NwQWNXHJYSYGVf5E3+YN/8AP7ymzAWPg7jrkfAV24E2/nTSR/euOvRsrtN8hQYGcPLzqIaPAus+0RYZ3dEBCWAZ1wCGnoLjNgBsoiCkmTP5bsedW/+tUUluASbOVXl1jXKwxqy1jV+7qkYwlMM4XkbwlP4JM8ufJJnFzzJs4vU/3tfg/AUQXgKj1rDC4nIUfGTPLu4vHvZZw3162AL9LOFIlfZ/XpZ34f79arkLNdkcDs4SR7mqGl+PcycZyApMRNLH2qJH77NBo5lA8XZmDguC0RO+CYJVnRP0K+HvG1V+db/gO399eQPnF8E9uHnMMfdClErA8JKKxvc5KEng6umxjx7lAx1USKMliNBQ26G2exCVa+cCFErFfyJl3wN1W08STbqnKpmcUFW0ARyrk4QngIIz1EIzz4Iz1cQnvchPO0gPC9CeJ6F8CyH8DwF4VmmtFz9+RSEZ9lRa/gzRPQiEW0gon8ftYZ/CeH5GcJzDMKTr34IvJU2ZdxPp1NQHRTs65uqc0f66tILBID99xvZttWP1WUq46lu3QzExWQiKSETtWtL55OvzU4s+MqNXuvG12yC1awTzNxxMK+7C+bUhTDHz4HVcYTqVlFB4zqeArNZb9CgGSWhzZ0BI3mImgYnyen0kNkwm/RS0CZANGgJvmazk2QBsnFHlZ6RD5TZlagXDbZWtrz2rANLnSsJwtMBwpMJ4WkG4amrXrcgPBHqT38yIDy1j1rDGxBRJBGdS0QxR63hWRCevhCe9hCewRCeqyE80yA8fdR5B0J4/qI02x2HrsZ63NwKvo+T2+hW44701b3WlVZ33G3lepjda92T0hWpBczhU3y7xAPgL7+lsrhkxlYENZZrWiMtsKbrka7ezQpaM3aABJQlyW4Zg2fJxutMFtGLhq3B3/y3A20B2bi2ys/oDO7yUOa41B0wajy40sNcDLAd30NEta5cXJclwzq/I9jPqga2GGAHj8Bsc5G0gvVawcrMlfnRLLnikkIrXe5P1OEqOV3OnQEjpr+3mMFs1B00aCaMpr190J7bFnzrf5wfjzyycVlIns+fANQzGeQzGdxksnGUABizF8tc5qDL+zIgKAZ8xQaf1T1RBPr9KKzEPnI3+bwT4M+ug1U3I7B2PCwZZrMLQcNugZE02Nsxw6rXGqzPDTBj+ilHVAKsc3LA3v3YufYxsnHxGbcFSU3fKOtPtpNBTdESKgbol4OwmnWrXMkfxcAcOrlkdtYnO2D2HgM6kud7bcPbEJHZFV/DSoeolQWzeV9vyMnZKNtMGuJzRDXMBnt7mxvawWfE3kGn+453GtxqUSOy8QsBMB5cUbkcZiMNonYW+LKXwd7/FMaipyDOzoJxy/0+K2y7ivnPyg4s8cNwbWESOwA8c4SvBrhOOviGd5zzH1dZYafHbn3O4P6zbF2pwQ2bZlARQEfzYGUNKTs5oiJ4KRFCpKokjFiwLR/4wjL5KqZ6+DisuF7Bba4dkQmzRT/VUD0VgieAP/eaA20B2RgRlj1x/0xW8kwE/E8Abl2y8RkB4K9skW1zzPTKdYA0VUJH/dZgP+wDFRSBDh8HnSiU4P5+DFZMT5lHHGRbWGHKEj3jL4+7Qz4T9WbWWtW9I31N0kXOPrrm0EnlpkIGBFnDdjAvvgFW6gBY2bkwp90DOvQH+Kv/gKidXrlifoqGOX6Ou1jgdg2p1p8dXCIbrxEA/t+vIepnVa0AwUqHoKawWg0B+7+PQb8dBv16CFbzbmpKHcz5MiEoBlbnkaCjeU5Z3vJKhHOYHphaZyK4WZSPPBkeuk8lZWRWAdx48M3v+nKUb/1b5ZxfLAnWee3BdnzvrGs/IBv1AgVXD0atMx1cIhuLqQig/b/Diu9TCevoBi4BxsxFYF/shPHQCrmtSrBW3EyTaZUr1jvQ7lfxZz391dLgunQ22dhNAPjKjWVsaRLMujQJom5LmeEU9NQ7U9bUOg3OpTNqtIZWS4PrX2OoAKDCYpiDJqpuFVXY/cCoZFdJlgRxQUewH/7nlOet0NBqaXDLFicbbxAAtn0nRIOW1d6LWa6RW8B4+Hn3htVNNLRaGtzy1ZJsHCcAxtwHK5fHXKV2OHGwsoeB8gqcutprNbRaGtzANJ8KAXbkGKyswZXLqCrXoiaX828lHFKfkI0IDa6WBjcw1ScbXzqbiQkjoezEiYATKjJ9he/RPf07rCgeVuZgUF6+Y21Ha2i1NLjBqb+z+bY5fo7/gvuITIjINipHOUE6oyw/m29Tsnx/VDaMxU+D7foJolEnuWlYqQwpb1qjjW8DidnqAaelwS2r4H7vfojmXSFYwknxWnPcHBiLl8NqM1TGaylW7VvkKB5W084wJs4B+3KnLynj9gdK/hjwVIj6rcC+2OWAO197krU0uJVTE7KxlwDwFeulZXUXIfAUWOe2B+0/BCooBNu+E/y512DMXwpjzoMwFi4Df/1t0L5D7p3zjlMRQL8dgZXUV1pqNU02u14m0xoLUEA22mhwtTS4lddVVCBL88yLrjs5dZFiwFe9Xv4TkbHYL8nGzWq3hV0EgK/e5PsxoGgYM+9z4P4mEKeUBldLg1t+bPdV795D57Ur2cmComHMXuQAt5tszCIbi8jGErKxkGyMV9uguLe1HEn5qiJp3G1qe9AYGEtXO+dZp6HV0uBWXYlk4xABMB5dJUv/nHRIioF5zRy3Q8kK8JwrqBhgvx2G1XooBDUF2/K+c55FuixPS4MbGk2W6ZBFMAdeo+p2ZdmdOWaWA9xPZOPcIHKjvyQA7NOvYTXqAPbpN855pmlwtTS4oZFBNt4kAGzHboiGbWQ4p/LgEtloTTYOEwC++T3Z6lXGbwdpcLU0uKFt6/q7nDK/oOK3LWBOuN0BdxfZaBjkOS93Gsqp7hbHAy3f0+BqaXAD11QqVBVEgydB0Nkwpi90wP0v2ahViXPe5+0IaeNXsnGObj+jpcEN/ZR5IwFgu/dCNEiDMfcBB9wtlTynUO8F2fhIXUODq6XBDbESyMYBAsAffh78cW8YZ1UVztmcbOwjGxt00zctDW44EzPyAbKLwQ4ccdanT1TxnMPIxl91x0YtDW54tUaGiLzr0/tCVJmk261qaXDDqKZkY6/LsTSjJtyXHoRaGtyKdakL3Mtq0r3pwailwa2o/E+C27Om3mNAX5yGX4P7JwO3Cdn4nmx0PNM+mx7QGtwzGVwiGwPJRpoGV+uMBFdLS0uDq6WlpcHV0tLgamlpaXC1tLQ0uFpaWhpcLS0NrpaWlgZXS0tLg6ulpcHV0tKqGfr/AQBPIOSG6IbxSQAAAABJRU5ErkJggg==" alt="Italian Trulli">
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="index.php">
                        <i class="pe-7s-graph2"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="pe-7s-id"></i>
                        <p>Upload Option</p>
                    </a>
                </li>
                <li>
                    <a href="email.php">
                        <i class="pe-7s-mail"></i>
                        <p>Link Email Page</p>
                    </a>
                </li>
                <li>
                    <a href="choose.php">
                        <i class="pe-7s-copy-file"></i>
                        <p>Login Style</p>
                    </a>
                </li>
                <li>
                    <a href="Blockbots.php">
                        <i class="pe-7s-config"></i>
                        <p>Scam Page Options</p>
                    </a>
                </li>
                <li>
                    <a href="addbots.php">
                        <i class="pe-7s-edit"></i>
                        <p>Add Bots</p>
                    </a>
                </li>
                <li>
                    <a href="advbots.php">
                        <i class="pe-7s-shield"></i>
                        <p>ADV Bots Blocking</p>
                    </a>
                </li>
				<li>
                    <a href="rlzt.php">
                        <i class="pe-7s-arc"></i>
                        <p>RZLT</p>
                    </a>
                </li>
				<li class="active-pro">
                    <a href="">
                        <i class="pe-7s-rocket"></i>
                        <p>Contact : ix@outlook.fr</p>
                    </a>
                </li>
            </ul>
    	</div>
    </div>

    <div class="main-panel">
        <nav style="background-color: rgb(185, 5, 5);" class="navbar navbar-default navbar-fixed">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#" style="color: #ffffff;">Dashboard</a>
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-left">
                        <li>
                            <a style="color: #ffffff;" href="#" class="dropdown-toggle" data-toggle="dropdown">
                                <i  style="color: #ffffff;" class="fa fa-dashboard"></i>
								<p class="hidden-lg hidden-md">Dashboard</p>
                            </a>
                        </li>
                        <li class="dropdown">
                              <a style="color: #ffffff;" href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="fa fa-globe"></i>
                                    <b class="caret hidden-lg hidden-md"></b>
									<p class="hidden-lg hidden-md">
										5 Notifications
										<b class="caret"></b>
									</p>
                              </a>
                              <ul class="dropdown-menu">
                                <li><a href="#">Update</a></li>
                              </ul>
                        </li>
                        <li>
                           <a href="">
                                <i style="color: #ffffff;" class="fa fa-search"></i>
								<p class="hidden-lg hidden-md">Search</p>
                            </a>
                        </li>
                    </ul>

                    <ul class="nav navbar-nav navbar-right">
                     
                        <li>
                            <a href="index.php?logout=true">
                                <p style="color: #ffffff;">Log out</p>
                            </a>
                        </li>
						<li class="separator hidden-lg"></li>
                    </ul>
                </div>
            </div>
        </nav>
		
		 <div class="content">
		         <div style="width:600px;" class="col-md-4">
                        <div class="card">

                            <div class="header">
                                <h4 class="title"><i class="pe-7s-graph1"></i> <b style="font-weight:500;"> - Result Analytics</b></h4>
                                <p class="category">on 2019<?php ".date('l jS \of F Y h:i:s A')." ?></p>
                            </div>
                            <div class="content">
                                <iframe width="100%" height="300px" name="login" id="login" src="inc/charn.php?=gh&<?php echo($getpss);?>" frameborder="0" scrolling="yes"></iframe>
                            </div>
                        </div>
                    </div>
		
		
		
		
		
		

                <div class="row">
                        <div style="width:1000px;" class="col-md-4">
                        <div class="card">
<div class="header">
                                <h4 class="title"><i class="pe-7s-graph"></i> <b style="font-weight:500;"> - System Bots Analytics</b></h4>
                            </div>
                            <div class="content">
<iframe width="100%" height="320px" name="login" id="login" src="inc/char.php?=gh&<?php echo($getpss);?>" frameborder="0" scrolling="no"></iframe>

                            </div>
                        </div>
                    </div> 
                </div>


       
            <div class="container-fluid">
                <div style="margin-left:-1px;" class="row">
		
				<div class="col-md-4">
                        <div class="row" style="width:987px;">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"><i class="pe-7s-note"></i> <b style="font-weight:500;"> - Main Options</b> </h4>
                            </div>
                            <div class="content">
                                <form method="post" id="insert_data">
                                    <div class="row">
                                        <div class="col-md-5">
                                            <div class="form-group">
                                                <label>Header</label>
                                                <input type="text" class="form-control" disabled placeholder="Company" value="16SHOP.COM">
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label>Username</label>
                                                <input name="namz" type="text" class="form-control" placeholder="Username" value="<?php echo($getname);?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <label for="exampleInputEmail1">Email address</label>
                                                <input name="emailz" type="email" class="form-control" placeholder="Email" value="<?php echo($getem);?>">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Password</label>
                                                <input disabled name="pssts" type="password" class="form-control" placeholder="Password" value="<?php echo($getpss);?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label>Encryption Key</label>
                                                <input type="text" class="form-control" placeholder="Last Name" value="AZERTY123456">
                                            </div>
                                        </div>
							

                            <small style="margin-left: 50px;color:#136f1b;font-size: 15px;text-transform: initial;font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;" class="text-muted"><b>If the the php bots protection not working you can use the javascript (clientside) antibot and turn off the php protection.</b></small>
							<br>
							<br>
                            <div style="margin-left: 50px;" class="form-group">
                                <label class="checkbox-inline checbox-switch">
                                    <input type="checkbox" name="php" value="CHIFRA12PHP" <?php $setting = parse_ini_file('../conf.pak'); $getlik = $setting['setup_php']; if($getlik == CHIFRA12PHP) { echo 'checked'; }else { echo ''; } ?>/>
                                    <span style="box-shadow: rgb(104, 196, 243) 0px 0px 0px 8px inset;background-color: rgb(180, 182, 183);"></span>
                                    <c style="color:grey;font-size: 12px;text-transform: initial;">Use php Protection (Default) [ Internal–External ] 👉 Turn it off if you have a problem with the hosting. </c>
                                </label>
                            </div>
							<div style="margin-left: 50px;" class="form-group">
                                <label class="checkbox-inline checbox-switch">
                                    <input type="checkbox" name="java" value="CHIFRA13JAVA" <?php $setting = parse_ini_file('../conf.pak'); $getlik = $setting['setup_java']; if($getlik == CHIFRA13JAVA) { echo 'checked'; }else { echo ''; } ?>/>
                                    <span style="box-shadow: rgb(104, 196, 243) 0px 0px 0px 8px inset;"></span>
                                    <c style="color:grey;font-size: 12px;text-transform: initial;"> Use Javascript Protection 👉 { 100% Accurate - Work on all hosting }</c>
                                </label>
                            </div>
                                    </div>
									
									
									<input hidden name="hidden_gender" type="text" value="<?php echo($getidone);?>">
									<input hidden name="hdon" type="text" value="<?php echo($getidtow);?>">
									<input hidden name="slfn" type="text" value="<?php echo($getselfi);?>">
									<input hidden name="alons" type="text" value="<?php echo($getidall);?>">
									<input hidden name="zzeir" type="text" value="<?php echo($getlinkm);?>">
									<input hidden name="applelogin" type="text" value="<?php echo($getapples);?>">
									<input hidden name="oldlogin" type="text" value="<?php echo($getoldaple);?>">
									<input hidden name="apstore" type="text" value="<?php echo($getapp);?>">
									<input hidden name="oldapstore" type="text" value="<?php echo($getolapp);?>">
									<input hidden name="icloudlogin" type="text" value="<?php echo($geticloud);?>">
									<input hidden name="phantom" type="text" value="<?php echo($getphnt);?>">
									
                                  

                                    <button name="submit" type="submit" class="btn btn-info btn-fill pull-right">Update Profile</button>
                                    <div class="clearfix"></div>
                                </form>
								

                            </div>
                        </div>
                        </div>
                    </div>

                    <div style="margin-left:449px;width:600px;" class="col-md-4">
                        <div class="card">

                            <div class="header">
                                <h4 class="title"><i class="pe-7s-users"></i> Last Logged In ip</h4>
                                <p class="category">on <?php echo date("Y"); ?></p>
                            </div>
                            <div class="content">
<iframe width="100%" height="196px" name="login" id="login" src="inc/visit.php?=gh&<?php echo($getpss);?>" frameborder="0" scrolling="yes"></iframe>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		
		<!-- 2--><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- --><!-- -->


        <footer class="footer">
            <div style="background-color: rgb(185, 5, 5);" class="container-fluid">
                <nav class="pull-left">
                    <ul>
                        <li>
                            <a style="color:white;">
							Apple Scam - 16shop.com v2 Ⓒ 2019
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </footer>

    </div>
</div>


</body>

    <!--   Core JS Files   -->
    <script src="assets/js/jquery.3.2.1.min.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js?v=1.4.0"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

	<script type="text/javascript">
    	$(document).ready(function(){
        	demo.initChartist();
        	$.notify({
            	icon: 'pe-7s-ribbon',
            	message: "Welcome to 16Shop.com Apple Private Scam v2 - Good luck. 🌍"
            },{
                type: 'info',
                timer: 500,
            });
    	});
	</script>

</html>
<?php
}


// *********************************************** //
// **********	FORM HAS BEEN SUBMITTED	********** //
// *********************************************** //

else if (isset($_POST['submit'])) {

	if ($_POST['username'] == $username && $_POST['password'] == $password){
	
		//IF USERNAME AND PASSWORD ARE CORRECT SET THE LOG-IN SESSION
		$_SESSION["login"] = $hash;
		header("Location: $_SERVER[PHP_SELF]");
		
	} else {
		
		// DISPLAY FORM WITH ERROR
		display_login_form();
		echo '<p align="center"><font color="#FF0000">Username or password is invalid</font></p>';
		
	}
}	
	
	
// *********************************************** //
// **********	SHOW THE LOG-IN FORM	********** //
// *********************************************** //

else { 

	display_login_form();

}


function display_login_form(){ ?>
    <title>CP</title>
	<link rel="shortcut icon" href="https://cdn3.iconfinder.com/data/icons/back-to-school-6/512/APPLE.png">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<style>

        a{
         text-decoration:none !important;
         }
         h1,h2,h3{
         font-family: 'Kaushan Script', cursive;
         }
          .myform{
		position: relative;
		display: -ms-flexbox;
		display: flex;
		padding: 1rem;
		-ms-flex-direction: column;
		flex-direction: column;
		width: 100%;
		pointer-events: auto;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid rgba(0,0,0,.2);
		border-radius: 1.1rem;
		outline: 0;
		max-width: 500px;
		 }
         .tx-tfm{
         text-transform:uppercase;
         }
         .mybtn{
         border-radius:50px;
         }
        
         .login-or {
         position: relative;
         color: #aaa;
         margin-top: 10px;
         margin-bottom: 10px;
         padding-top: 10px;
         padding-bottom: 10px;
         }
         .span-or {
         display: block;
         position: absolute;
         left: 50%;
         top: -2px;
         margin-left: -25px;
         background-color: #fff;
         width: 50px;
         text-align: center;
         }
         .hr-or {
         height: 1px;
         margin-top: 0px !important;
         margin-bottom: 0px !important;
         }
         .google {
         color:#666;
         width:100%;
         height:40px;
         text-align:center;
         outline:none;
         border: 1px solid lightgrey;
         }
          form .error {
         color: #ff0000;
         }
         #second{display:none;}
</style>

    <div class="container">
        <div class="row">
			<div class="col-md-5 mx-auto">
			<div id="first">
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
			<br>
				<div class="myform form ">
					 <div class="logo mb-3">
						 <div class="col-md-12 text-center">
							<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAO4AAACICAYAAADgQ9dlAAAACXBIWXMAAA7EAAAOxAGVKw4bAAA73mlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS41LWMwMjEgNzkuMTU0OTExLCAyMDEzLzEwLzI5LTExOjQ3OjE2ICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIKICAgICAgICAgICAgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIgogICAgICAgICAgICB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIKICAgICAgICAgICAgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC94bXA6Q3JlYXRvclRvb2w+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDE5LTAzLTIwVDE1OjUxOjI3KzAxOjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMTktMDMtMjBUMTY6MDE6MjMrMDE6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wOk1ldGFkYXRhRGF0ZT4yMDE5LTAzLTIwVDE2OjAxOjIzKzAxOjAwPC94bXA6TWV0YWRhdGFEYXRlPgogICAgICAgICA8ZGM6Zm9ybWF0PmltYWdlL3BuZzwvZGM6Zm9ybWF0PgogICAgICAgICA8cGhvdG9zaG9wOkNvbG9yTW9kZT4zPC9waG90b3Nob3A6Q29sb3JNb2RlPgogICAgICAgICA8cGhvdG9zaG9wOlRleHRMYXllcnM+CiAgICAgICAgICAgIDxyZGY6QmFnPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHBob3Rvc2hvcDpMYXllck5hbWU+MTZTaG9wLmNvbTwvcGhvdG9zaG9wOkxheWVyTmFtZT4KICAgICAgICAgICAgICAgICAgPHBob3Rvc2hvcDpMYXllclRleHQ+MTZTaG9wLmNvbTwvcGhvdG9zaG9wOkxheWVyVGV4dD4KICAgICAgICAgICAgICAgPC9yZGY6bGk+CiAgICAgICAgICAgIDwvcmRmOkJhZz4KICAgICAgICAgPC9waG90b3Nob3A6VGV4dExheWVycz4KICAgICAgICAgPHBob3Rvc2hvcDpEb2N1bWVudEFuY2VzdG9ycz4KICAgICAgICAgICAgPHJkZjpCYWc+CiAgICAgICAgICAgICAgIDxyZGY6bGk+eG1wLmRpZDo4OEEwNTA5RjIyRUExMUU2OEFBN0MwQTkxNkJFRTE2RjwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpCYWc+CiAgICAgICAgIDwvcGhvdG9zaG9wOkRvY3VtZW50QW5jZXN0b3JzPgogICAgICAgICA8eG1wTU06SW5zdGFuY2VJRD54bXAuaWlkOjc5MjY5ZDk4LTEzYjYtNDk0ZS1hODZmLWRiNTZkYTA5ZGViZDwveG1wTU06SW5zdGFuY2VJRD4KICAgICAgICAgPHhtcE1NOkRvY3VtZW50SUQ+eG1wLmRpZDpjNmQxNTk1NS1mN2VhLWRhNGEtODM4NS1jMmE4ODIzYjY5Y2E8L3htcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ+eG1wLmRpZDpjNmQxNTk1NS1mN2VhLWRhNGEtODM4NS1jMmE4ODIzYjY5Y2E8L3htcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOkhpc3Rvcnk+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmFjdGlvbj5jcmVhdGVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6YzZkMTU5NTUtZjdlYS1kYTRhLTgzODUtYzJhODgyM2I2OWNhPC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE5LTAzLTIwVDE1OjUxOjI3KzAxOjAwPC9zdEV2dDp3aGVuPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6c29mdHdhcmVBZ2VudD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC9zdEV2dDpzb2Z0d2FyZUFnZW50PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDphY3Rpb24+c2F2ZWQ8L3N0RXZ0OmFjdGlvbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0Omluc3RhbmNlSUQ+eG1wLmlpZDo3OTI2OWQ5OC0xM2I2LTQ5NGUtYTg2Zi1kYjU2ZGEwOWRlYmQ8L3N0RXZ0Omluc3RhbmNlSUQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDp3aGVuPjIwMTktMDMtMjBUMTY6MDE6MjMrMDE6MDA8L3N0RXZ0OndoZW4+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpzb2Z0d2FyZUFnZW50PkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cyk8L3N0RXZ0OnNvZnR3YXJlQWdlbnQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpjaGFuZ2VkPi88L3N0RXZ0OmNoYW5nZWQ+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwveG1wTU06SGlzdG9yeT4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+OTYwMDAwLzEwMDAwPC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj45NjAwMDAvMTAwMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+NjU1MzU8L2V4aWY6Q29sb3JTcGFjZT4KICAgICAgICAgPGV4aWY6UGl4ZWxYRGltZW5zaW9uPjIzODwvZXhpZjpQaXhlbFhEaW1lbnNpb24+CiAgICAgICAgIDxleGlmOlBpeGVsWURpbWVuc2lvbj4xMzY8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/PmXeJRMAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAJB5JREFUeNrsnXd4FNX6x99zZuaEDgELSAnpyaZBCL0XqaFZUIoiCoIgGKVaEATliiKiYsGGDYkFUQRElGvhem3YUVFBbOBVQASBcFL4/v44M7ubZJPsJrsp/I7P830wm9mZ2cn57HvO2w4BIC0trZol/RC0tDS4WlpaGlwtLS0NrpaWBldLS0uDq6WlpcHV0tLgamlpaXC1tLQ0uFpaGtziB0itSlIvknidJJaTxHiS6EwSTQM9jx7UGlwNbuVK2OCCJEC5AOXjD5J4lySySKK5BldLg1s95SKJY5QL0D+5oKMnPX+IXPxJEvNJor4GV0uDW/10G+UDdOgfmCOvgjF9AdgX33n+IBKfkkRXDa4GV4NbvdSIJH4kAMaSVRAUDlE3Bca0BWD/O+TAe5wkJmtwNbga3OqlBQSA/bgfolEHCIqHoJaw4vqBb3vfmTqDJOZocDW4GtzqozTKw0kqAKxzJ0BQNIRIhaAYiDpJ4E+/7A3vWA2uBleDWz3ESeIrAmAseACCIiBEig1vPIQVB77uTWfafIgkYjS4GlwNbvXQegJgrHoegiIhrBQb3hQIioNo2hls968OvC9rcDW4GtzqoVUEgD+7EYKiPOBayRCGC4IiYF58nfeUua8GV4Orwa16PUsA+OqXlMUVKRA8AVbyMFhR5yqrayWAv/uJY3U3aHA1uBrcqtcOAmDc/qhnjUsxsM6dCOP+tcphRa1hjpnpWN0ckojTg1qDq8GtOrWhPBwnAObQKWqq7IDbZSzoj8OwWvaEoGhYZ3cB7TsIOgWQxFQ9qDW4Gtyq00I6BbAffoFomAHBXTa4UTAHTAQBMMfNVlNoigV/9W1nuvykHtQaXA1u1agWSewkAHzFU16hoBQIioAxfTEIsKfLkRDUGsb1dzvgfqwHtQZXg1s1Gk35AJ3Mg9X+ApV04Qa3NfhDz4EAsG0fQ7A4tc4dPctZ5+7Vg1qDq8GtmtK+TwkAX/eGHQZKtj3KiRD124J9s1eB+8FXEKZLgTviagfcfXpQa3A1uJWvKZQHUG4+rK6j7VTHFM/6ts+loPxTCtwPd0JYNrjDpmlwNbga3CpSHEn8QQD4quchqLVX0oVa3/In1rv/MOzdzyBYggL3giwH3F/0oNbganArT2eTxIeqImgfrGZdIFi8l7WNhpU2HHQsB5Sn/jD8uS2eWO6UhY5z6hs9qDW4GtzKUTxJfEIA6OgJWL3H2ZlSqQpaMwmCosBf3OrAqcJB85Ypq0yR4A+sdX73qh7UGlwNbujVjyR+IwDs4N8wB09SMArvgoKWMMfPVX+MPDsvueAUrL4TlPPKSAL7cKcD7p16UGtwNbih1TWUi5MEgO3aC6v9eYVjtiIVglrDShsKduhvJzMKdApge36DFZ6hptAJA0BHToAKAJIYoQe1BleDGxqdSRJPUL69Vt2yHVbL7oWnxyIVgiJhRfUC+3avZ4psT5ONe59xJ1+Ykxc4jqmDJNFUD2oNrgY3+OpLEt86D9e44xGIWi4IivVAa6VAUCtYyQPBvt5dGNp8gHJyYbUdoRIzzHjwtz5yjsnW1UEaXA1ucHUGSSyjPOQSALbvD5gXzlBTY57omR5byRAiCeboLNDhfwpDa1tblZgRrabJ3caAcgsU0BKDNLgaXA1u8DSOJL5zHihf/wasqF4KWu+uFk69bZ/x4K++Df7eDrCde5wiebe1Ndufr6wtRcFYu9mB+zOSCNPganBPN3AtkmhNEv1J4kqSuNOeWm4giY221pPE4yQxjyQuJIlUkmhQgWv2IYk3qcBOmNi7D+aEuTZ0cV7r2SIKS1Hr11px4C9s8TilABgPZNshoGhYXUeDZJ5jbS/VrWs0uKcLuE1IYihJPEi5+JTycTSgJ3MK+ZSHH0jiWZK4mCTO8vO6GSTxAuXjFAGgI8dh3PUYRNNOysqaSb6BdTulYiHCXODZrxWK27IffoE4q5OCnsWCv/5f5/c7HGurwdXg1mRwe5LEw5SLXwt9kKMnwXZ8Db5+G4w7H4cx63aYUxfCnDxfafoiGDfeDf7YS2Db3gfbd6Dwg8jFPpK4jyTSSrhuR5JYQ3kqxEN5BeBrNsBKy1TAUkIpwDrQRkM0aQ/+2nYPtAUAyVxY/S6zPcmtYF5+o3NPBc7aVoOrwa2J4DKSGEkSbzphFgLAvv8ZfFU2zIuzYCUMhKid4k4TLFmREDweVtNuMAdNgHHnYx7vroLlBEk8RBKR9rW7kkQ25SGfoNaifP0bMHuMdhe6lw6sp2TPiu0H9vFOD7T2ZzGnLfJMkeMHgB047MRtn9YN0TW4NRXc3iSxzVlL0pHj4Gs3qpYvDdI9MFIchJHkKZMrTWayspAUpaxlvTYwL7gafOt/vPfw+Y0kNlMe8pSFPQX+8puwel/i9vr6d60kFf7peynYz797oLVzko1FD3i+ABqkgb33mXPMbl/bcOpBrcGt7uCeRRIr3eAcPQHjgTWwkgfbAz3K0/KlojJctiWOhXneVLDPd3lZ4ALlKe49NjBgnebmFA0j6zZQjixmaY0lD3m+dMw48Gc3OsectJ1feu8gDW6NArdXoRDLi1tgpQ2x15JxwYG1qCwH4NYQ9VJh3PkY+EtbYXYdFSCwztQ4EtaZ7T0wFgB0UqU0EgDDXUQQD8GjwVc9791D+Qq9W58Gt6aBO4MkcggA/fo/mKOm21PamNAAayaputdaabAad4GolQbBEtXUlWLVdQMB1nApB1OvMWDf/OgNo/r/Yydhjp9jfwnFQhix4I++4H3cjXp/XK2aBu4yyrWt7KZ3YLXuaYdYkkMDLE+A1aA9jKTzwXpPBc+4BKJ2WwWqI7/PaW/aZcbBnLsMdOJksRxktncfrB6jbWijIeomgz+32RvahXpHeq2aBu797rXffc9AWImFc3yDNiVOhmAKWJ4+BjTwWvDOE2A27aVgtpLLd06KgBXdB/y1dz1TYy8nFNv2Aazo3vaaNhKiRTfwf3/oDe1sf56THtQa3OoE7jK3l/WWlWrt553jG0xoDReM2EzQkFlg3SfBPKu7upZRzuvxRFXFM2oGaN8fhafGtifcePBZiLopdlZVBKwO54PtclcF5ZDEZf4+Kz2oNbjVBdzpzvTYWGxvOWm4QgOtSAZvfwkoczaMqEHqOuX+gnD2s02Gcfdq7zCSZz17PAfmlJs9nmNqDfOS2aC/3QUG+0liYCDPSw9qDa4/4J5ZCd7jkwSAP7bO7vgQImhNF4yMS0BDZsFq3Llwz6fyeKCpNazovuBvf+TpXiFtawuA/fgbrB5j7fVsDIRIgPGvh5x0S5DE+ySRGOgz04Nag1sWuONJYlkIoW3s1K6y9z6DqKPWniHxHPNEGNGZoBE3wGzWq2LXMZOV13jABLBf/1fYyrrXs+/Diujhjjdb53QG3/Bvb8AfL2+Bgx7UGtzSwO1IEidI4rEQgnsf5QP01xFYrsGeja9CYW1rtwENyAJvN65i0NpxXnPaQtBJWRhaJz67fDVEbZdnPdttlKfLRS5ySeK6ijw3Pag1uCWB29JOtwNJrAkRtO2cKbIx+04IahkaaG1ra7bqDxo+D9YZ3co/FeeJKgtq0f3e013PevbIMZiXzfOkL1JrGBOvB/1zwgH816IFAxpcrWCBa5LEJq+uDJtCBO4GAsA+/RZW3ZTye3T9BI6nXgTqNx0iLLV84R6eCMGiYdz7dOH1rBOf3fUjrE4XetazYS4Yy1d7A/6O3RCdNLhaoQB3pmoP6h6Yb4QA2g6Uq/KPzYuvK9L5sKJeY9/TW97pMrCek8sXpzVcytLe90xhaJ1mcK++Bat5Z3d81oroDr75Xe9jHyGJusF6fnpQa3CLghtHuThCOflgX+1xBt2WEID7KAFgn+2CqJNScS+ymeQ5h+Eqfj7DBd7xMrC+0wK3uGaSmvIuWeUB8aS7EF8VCVjx7vWs2Wcc2J7fvMsDpwX7+elBrcEtCu7zBIC98T74A9nOuuyFEGzF8ScBMK5ZAkGtKpYZZbhghXcGz7gErOdk8I7jYTXtVRhengieOkqFgRq0L6NDRdGQTysYUxYUtrQA6PBRmGOu9TSDo2iYUxeCcnKd57bXLkckDa5WKMHtRLmqUNwcMgXcWctJPBXkgXcRFQDs8DFYMf1VZUyFoO0E1j8LNGwuaMhs0NA5oMw5MGKHehIreCLM1gNBI2+A2byPnwkXqu+x2X0M6HiOZ+kAgH35HayMEZ4cap4A467VTppjPkm8afe/Ig2uVqjBfYUA8A+/guARMFY+64C7LsgD72ECwP79kdq02Uqu0BSZd7gUNGweaNB1Hg2eCRo6B+Y5NqRmEkT9DNCQWeAZ4/wDlydChLcD22l3xnDWs89thnVGBxW6Ygl2jnI0DM/ePgfsWQVpcLVCDW57ykU+nQLMi65FGDWGMX+FMxA/tj3NwRh0nCR2EgDj+uW2Uyq13NBa9dqB+s8ADZlVGNxB14EyZ4P1mOyVn5yoCgqGz1VZU2XBSxEeKwqA8gtgLLzP3iE+DoLiUatlf4g6bSEoBlbCYNA/OaACnAok71iDq1URcJcQAPb1jxB12qisoNEzHXAPksQ5QYL2NiezyBp4ZcUSLuxpstvCFgXXhtdjdV2wGnVUQHefpNavJa11WSysjAvcCRXsi10wB12hvmhYAgTFo27XyWi0aCNqx4+ERXFqt701G72/7CwNrlaowd2q9qt5WlXlsARYkX1Afx1z1nZTKzDQ6pPEcJLY5oDAV78EUTfVfyeRT4vrB7hD54B3uNQTI2YJMKKHgM6/SWVQ2ZVCxcGNgTlnGfhr22FOugmiQVsV6mEJCKuTjnrnLUT4ki0IX/I66o9dCovFq7TGHuPUbvKqD3L/YIHKszdp1WCFEtw9BMC8/CbPFpAUBf74em+r2yfAHOR+JHEv5eIHT/vUYzDm3gHBYipesmcmwWrYATTw2pLBHTwTNGgmrCZdPNczXDCSL1DwdrkCVqMOyooaLq/1dipErVR39pOgOOXgatwJYsSNCL99KxrdvB6NFryMRgteRq3mfe2eUYlg/3E3entOg6sVWnBz1f6t5tg59o5y9lYZzbqCfbXbiUmetBMJBtptS5uSRDPbe5pOEmNI4ja7K+Jv3hdgv/0JY+UzsNoMVSBUxNJ6JVtYddqC+l7te43rtrqzwTtPUN0fneQLwwUjYTho+DzlsEq5UK17nTgwT1Qw27BbTbqAtxkNGnQd2PDr0eD65xS0N69HoyVbUHfwHFgUo3KYL5vnPK/j5an8KQHcrjx70zyevWmprUx7UGR6veZLmUUGUVnHe78vs4xzaVUDi/stATCn3OK16bKqNbUieoFvfqfoDgDHqQB/UQH+olM4RrD7DTsqANiP+8BXr4M56hqIszrblis2yOmMyWDdJoEyZ5cMrjNlbjvGPV0WhguCxcM6qztYt4kqlDR4JliPyeDtLwFPGQUj5ULwjHFgPa50e6lp8EzQuTNQ+8qVCF/0qgL3lg1oOOsZhNVvr6xuowyVgKHSHG8PErTwocwSXvd1HAVwvD/n0qom4KpQ0GMveiyuux1LHISRCHP4VTCeWA/25fdg+w+CHTyitP8g2A+/gL31MYzH1sGYvghWtzGwGrf3tGgJVame4QLvOF5BVRq4Nrysx2QYEQNg1c9QGVQ8EVbtNBiukQrKzNnKCo+4HjR0rh0Tnl14Kj4gC8aIG9Fo/ktuqxu+ZAvqdJloW90IGIsfdKbL++xlQ6CwNuPZm0bZWsGzN4HNmAs2aTrYpOkORNt59ib3a77kdVwzf44v8j6f56L/h/9VZ3Dnq10BfoGol66miA0yIBpmKOtkJttdFiMh6qXBat4dVkRvpebdIRpn2P2DI23LGhO8fselxloTYLjOUxazLHBtLzMNnQMakAXW6yqwHpPB+kwDDchy/471mQYjdRSo/zUlr537z0Cdqx70WN3FG9HwqocgRDIExcKK7As6dNRx7E0PENpknr3pQFFrRx27gYhAROBPrlOvP7nO/ZovuY9zVMbxhd5X5FivczXW4FYfcNPdcdzzpin4wlJgdboYon5be61nx1sNu5Up2WIJClIrOfSg+irXa9HPP4tb1Gk1ZJZ63/B5aprc9QqYkYMgrCQYsUNBmaWcc0AWjBE3oKG31b11E2q7LoBFscrqPpjtvRtBgwDAVZZx4Z2FVBRc9+ulAOgc4+/xRd+nwa3+4DKS2KI6UXwOEZaoLGiL7jDHz4OonVr6tpFVJTNJxWZL8ywXlQNs5mywPlNhJF+ovM6WbS0bd1bnKut8/Weg9pX3IfwW2+rethkNJqyA4AnKN5A8BHT0hBMausZPaBv7YxkLQdWxWzHIi0Lnz/Flga3BrZ7gEkl0o1wUEABjll3YTnGw2g6HccsDsGL7qoIASii+WXPRti7cZYdSonxY4lTVbJwlVvyLwD436zG5dM+y41waOges79UwUkfBbNoLVq00j7PKTIKo1w6s97SynV2DrgMNzAIfOgcNb3wBjRa8oizv4o2oHTvMY3VXPOVY3d/t5gQhAbeYE6nI+8s83o+ptAa3+oJLJLGS8u3OhAMvt0GNgZU8CMbKNTDn3gnRqqe9HUeE713wjASIRhmw2o6EOWYmRHgnOxRjO7qoFaymXSFa9Q5OUzieAJ52kXImlQArDcgCz7gEZot+KkWRJyp5f6nY4SXWY7J/4A66DnTuDNS6fLl7rRt+6yY0uPweWKb9xdWyh9rKU3mY1wY0VS7iMKKE5LJA3GGHbYq/v/Tjl/p839jLSwK3WOioyCAvM0Tl53E+z18KXJn+nicE91hqGK4ywK1LEu8TAHbob5j9xtuWNwaibiqM6YvAt30A/sZ/wR96HsaiB2DMvRPGzffCuONxGI+vB3/7I7AffgHlF4Cv22rDHwURlgQraQiM2UvBdv8C44a77dBTasXXuc16KwfVMC9P8LkzwDuMhxk5CFb99r5h9ZVG2bAj2IAs/6beA68FGzwTDeY+i/BbNthT5tdQp80Yt4fZvHSud0ngLD/A9Rm28V7j+m1BHe9wgMf7sr7FHF1FwkReA93fsFJAYSg/oPX3uqG6x6LaUpngOv2mPnX3BL5qgcp0cjzGZ3aAMW0h2PYdoLz8Uk/MN78L/vCz4K+8Dfbpt6DjnkRbvuU9ZZWC4dSykmG26AfDdR6MuGEwm/WGVa+dJ5kikIQPlgAjarD/nur+18C8eLEN7stotGgjGl73NMIatLc97VHgjqNKbVJ9jZ/wOt/eO0oFNyG57LDO0pXq/R27lXp8off5ANc7JFXekJO/oSxf5y8B2kCvG/R7LPb+VWucc0RXJrhEEs1J4k2nCz/f+JZdf+qEe+zNqiJ7w7woC/z+teBvfQT20++gf066u/eXqpw8WNH9KtbbuFhPqATlHHLWrKUcT5QCwyhh3Wz5mdjhPWWeuALhize647r1R92qcphZAkStRPAXtnhb3lUkEeHn1Ll0cCsxHOR9Dz6ucSCgEFUg9+I5f3IRaNf6+9kKPYsg36MvH4TXc19b2e1Za5HEHZQLqUDLBV/zCqyeoyFqJdlTYEcRKpE/vCMs1yBY/S6FOXIazInzYdywAsbtj8BY8SSM+9fAuOcpGEsfgXHzSojW/ULbJM4XsExBGxWZirPPSoFplhRm6ut/mGngtaD+Wagz9SGEL9qIRgteRviSLajb+2p7yhwPUcsF4/413rsd/I8k7iKJ1FCB6w4HBQhuiZ5pH+B6XyPQEFU5PsP2IpY24NBYKO6x2PtnzHW/377vZlWxk0EnktjsFJLTKYB98g2M2x6E1WMcxNmd7ClhKwhqAUHNIegc+98Wtlp6AKdW9s8t7cT8pMqDllJwRpMUrFjeBvt/SocrIQVESb6tblgqWK+rSvdWF4V3QBZqT74f4be8qsJEizeibucrPPBSFMzzp4F99b3Xptk4SRIbSGIoSdQOGFw/wkHe1qa0UJA/XwilxZZLAyUYx3t7te2ssoCfRbDusejfo6TX7XseVZV7B/UliacpF4cKFRD88gfYtg/B730KRtbtMDOnwOo+GpZrEMTZ3SDqtVPphSLZvXePCEuBqJsOq2k3Vf9bCckbRCno3CEVX3/ZFkA6tm9tA9NqA7N+e9/XZwkwks4PLLlj4LWg/jMgxi5Bg3nZCL91E8KXbEG9ATPVZzaS1HKjfhuYF18D/uLramnhafX6HUn0DBTcABxLBwJxSJU15SxtkPtyZlX0eH/ALWeIK+B7LOHeqiW4jiLs3dLXUi72FCswcNZxR3PAfj8E9t0vYJ9+C/bxTrAPvgT7aKf6+dufQAf/hnn93cFrz1qCGEtBettU/PFbOpCfDhSk44L+saCMS2FOnK/CW748zE17+b/OLbLmZUNmI+zy5ag/62k0WvoG6o/+l1d3jTgIagLzgqvBDh1xkjQkScwniUblBHeHM5hLGXBL7SqjUT5U6iAv4rjZEcAgHxWs4wMA13kW/oa4Ar3HGglu0fBRR3uPobtI4nnKxQ7Kw27Kx34CjvoE29ti79kHEZ4Rmi01RQosKwWcp2Dba8rSAunIfqINDGoJ9uQGGA8/51URVWS6XKctWN/p/k+XvXOiB10L6jkZNGQ2jAHXIqxlfzs7KwaiTiqMe55S8V2Vz/xlUUtbTnAbBxDK6eq1XmwcoHUKZJA3DtbxgYDrM0wUvHus8eD6ErNzc88miRiSSCOJrvZUe6D9b0d7TfePKidcYLdpDQ24ppmCd19vi4KT6Vj9SFvUZa3AOo0B5eeDP/FS4YqoiniX7XRK1nmC2uG+7zTwTpepDC1KULv7xfQBe+djbw/zkyQRXm7nlD8W955HPVZnxlzn+BWBWFyvwZlZxRZ3FM/edK62uFW7P+7TqjH6dxC1U4KTSUWxaurrrk5KhWmm4pxmKUhLcIGoOZhrMNhP+1SoK3uT76myUzaYMa7sde7gmaBhc8F6T4V5Th+1T9HAa8HbjlZfANyl+nj1Hw/2y++OV/kISUyucDioClIeAx3kQV7jOvper3GrDtwMylUbf5mjr/M9ZbVlGMrB5C1uFLeQVpeLYZ47QU2/KRKCIhBGEWAUCardFnzSTWC/H/QkgqzbWjK4PFGV+JUGrl2vaySOVJVFMZmg4dern51sLWoNc/J8UM5JB9pdtreeggFuZRcZ+ANuKLzK7t8tXVliVlgovcoa3MJ6kQCwHd+o+LAPq2uaKTinWQqGDEzF5ZekIevqNEyakIZzmnnFYSkWVvp57uQP9v3P4C+9AWPpwzBufQB87Waw3b8W+/DGrQ+W3G2SJ8JIuaDkLKphc8F6TYHVpAvCKBY85ULQiBtgRA1WRRQUr3ou3/qg9+Zf2+wEFyovuFVdjxuUewowAaMEy3qgMhMwNLiF1dlJ8jDHzPTpYeY8BfFxqVi1sg1+/iEdOJ4OnErHlIlpIHLCN/GwIvqA/jzsbqvKt38Ctv/P4h84twDso69gTrwRolYKhJVUMrgJI4qDa0+NefoYFeqiOBhtRoOGXw+z5bl2vXIcRC0X+CMvehqqSzxKEnUCLKwPBrjbT1Nwd/j72TS4odFzBIB9/r1q2+rD6jI746lu3RRER6YiPjYVtWsr55OnzU4U+NrNbuvG122B1bIrzMyJMK++FWbWUpiT5sPqMsruVlFG4zqeCLNlP9DQ2YWhzZwNI2G4PQ2OV9Pp4fNgNu9rQxsL0aAN+LqtTpIFSGJhOXtOVbh1je1hDVrrmiDcU/GpclnHr1rj08Hm72cLRq5yoddL+uzer3vlLJ+u4Ga4re7Em0r1MHuvdYulK1JrmBfM8OwSD4C/9KadxaUytsKomVrTGkn+NV1v5NW72YbWjBqsAGXxqlvGsLmq8TpTRfSicTvwN/7rQJtHEldVZbO4ACto/DlX1wpX1ARWfbSlhNe7VkF1UKCvb6nsXOXK9zCfAtiunyDC25UvrssSYJ3dBew3uwb2FMAOHYXZ/jxlBeu1hZWaqfKjWULZJYVWstqfqPPlarqcORtG5CB3MYPZtBdo6BwYLfp5oD2zA/j2T5wvjxySGBuK9qyB1qAGWgPrqz1rkXOV+578SBIpqzZ2nnccuhLrcZ0625La5fp8/XQHN4EkjhEAY95ylcsccHlfCgRFgq/Z5LG6JwtAfx+DFddf7SafcxL86Q2w6qb4146HJcBseS5o5A0w4oe5O2ZY9dqB9b8GZuRA2xEVC+uMDLD3PnWufZwkzg/Kszm9ukmUlSTSuBrec7XvgFHVWkGnAPr9EKyWPctX8keRMEdMK5yd9dkumP3Gg47meF7b9A5Eo/Syr2ElQ9RKg9lqgDvk5GyUbcYP9ziiGqeDvbPDG9phQXsuGlwNbjUHtylJ/E4AjPvWlC+H2UiCqJ0G/thLYB98AWPZ4xBN0mDccLfHCkuvYv6G6f4lfhheW5hEDQZPHeWpAa6TDL7pXef8J+ysMNJbkJSo7SWsB7frhug1E1wiidlUANCxHFhpw0tOjigLXoqDEC47CSMKbNuHnrBMrh1TPXICVnTfwDbXDkuF2Xqg3VDdBcFjwZ951YE2jyRGBfuZnIaDOdkHvNvt1zW4NRTcuiTxJQHgL29TbXPM5PJ1gDTthI767cB+/gOUVwA6cgJ0Ml+B+/dxWJF9VB5xgG1hhalK9Ix/Pewd8pkSimeit/HQ4NYEcIkkznP20TVHTC01FdIvyBp3hHn+NbBcg2GlZ8KceTvo8D/gr/wbonZy+Yr5KQLmpPnexQI3h+p56MGvwa0p4BJJvEoA+OffQdRPq1gBgpUMQS1gtR0O9p9PQX8dAf15GFarnvaUOpDzpUJQJKxuo0HHcpyyvNWV+Wz0ps96Y+vqDG4a5SJHhYfuspMyUisAbgz41vc8Oco33lM+5xeLh3VWJ7BdPznr2g9Jop4GV0uD69FyKgDowN+wYvqXwzp6AxcLY84ysK93w1i5Rm2rEqgVN5NUWuWajQ60B+z4M2lwtTS4HjUhib0EgK/dXMKWJoGsS+Mh6rZRGU4BT71TVU2t0+BcOaPGVcVz0YNag1vdwSWSGE95AOWfgjl0it2togK7Hxjl7CrJ4iHO6QL28/+c8rw1VfVM9KDW4NYEcDlJvE4A2M7dEA3aVHovZrVGbg3j/me9N6xursHV0uCWrjYkcYIAGAvuK18ec4Xa4UTDSh8Jyslz6mqvqsrnoQe1BremgEsksZjyAXb0OKy0YeXLqCrVoiaU8rtCDqnPSCJMg6ulwfVP9UniG2czMWHElpw44XdCRaqn8D2ij2+HFcXASh0Gysl1rO24qn4WelBrcGsSuEQSg5zNt81J830X3IelQjRqb+coxypnlOVj821KUO8PT4ex/AmwPb9CNO2qNg0rkiHlTmuU+KGyY7YaXA3u6QCup+B+/wGIVj0gWGyxeK05cT6M5athtR+h4rUUZe9b5CgGVotuMKbMB/tmtycp4+Z7C38ZcBdE/bZgX+9xwF1cHZ6BHtQa3JoIbnOS2E8A+JqNyrJ6FyHwRFhndgIdOAzKywfbuRv8mVdhLF4FY/59MJY+Bv7aO6A/DnvvnHeCCgD66yis+AHKUtvTZLPHWJXWmIc8kmivwdXS4JZfl1OeKs0zz7u6eOoiRYJnv1b6h1ax2G9I4np7t4U9BIA/v8XzZUARMObc5cD9fVU7pTS4GtyaDi4niVfcew+d1bFwJwuKgDFvmQPcXpKYSxLLSGIFSSwliUn2Nije21qOply7ImniTfb2oJEwVj3vnGdDdfn8elBrcGsquEQScSRxmAAYD2ar0j8nHZIiYV4539uhZPl5zjV0CmB/HYHVbgQEtQDb9oFznmUaXC0NbnA0TaVDFsAccqVdt6vK7szxcx3gfiWJMwPIjf6GALAvvoPVtDPYF98755mpwdXS4AZHBkm8QQDYrr0QjdurcE75wSWSaEcSRwgA3/q+avWq4rdDNbhaGtzgtnX9W02Zn7Pjt61hTr7ZAXcPSTQO8JyXOA3l7O4WJ6qifE+Dq8E9ncElksiifLuCaNhUCGoCY9ZSB9zPSaJWOc55l7sjpMSfJHGGBldLgxv8KfNmAsD27odokARjwb0OuNvKeU5hvxck8bF9DQ2ulgY3yIoliYMEgN//LPjD7jBOdgXO2Yok/iCJTdXps+pBrcE9ncBViRm5AMlTYAePOuvTRyp4zpEkcYcGV0uDG1qtUyEi9/r0riBVJmlwtTS4IVQLktjv5ViafZp9Pj2oNbinJbhEEhd5gTtWg6ulwa1J5X8K3D4aXC0Nbs0q//uJJLpocLU0uDVLQ0giSYOrdVqCq6WlpcHV0tLS4GppaXC1tLQ0uFpaWhpcLS0tDa6WlgZXS0tLg6ulpaXB1dLS4GppaWlwtbS0NLhaWhpcLS2taqr/GwBBCsIXaHYR/gAAAABJRU5ErkJggg==" alt="Italian Trulli">
						 </div>
					</div>
                   <form action="<?php echo $self; ?>" method="post" name="login">
                           <div class="form-group">
                              <label for="exampleInputEmail1">Username</label>
                              <input type="text" name="username"  autocomplete="off" class="form-control" id="email" aria-describedby="emailHelp" placeholder="Enter Username">
                           </div>
                           <div class="form-group">
                              <label for="exampleInputEmail1">Password</label>
                              <input type="password" name="password" autocomplete="off" id="password"  class="form-control" aria-describedby="emailHelp" placeholder="Enter Password">
                           </div>
                           
                           <div class="col-md-12 text-center ">
                              <button name="submit" type="submit" class=" btn btn-block mybtn btn-primary tx-tfm">Login</button>
                           </div>
                        </form>
                 
				</div>
			</div>
		</div>
      </div>   

<?php } ?>                                      