<?
require_once 'cry/crypt.php';


?>