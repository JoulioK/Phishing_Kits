<?php 


include("./myaccount/linguo/lang.php");

header("location:./myaccount/websc_login/?country.x=".$_SESSION['MOCNTRCD']."&locale.x=".$_SESSION['galant']."");

?>