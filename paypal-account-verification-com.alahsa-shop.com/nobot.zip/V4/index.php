<?php

header("location:referrer.php?MTUwMDU1MTQy=secured");
?>