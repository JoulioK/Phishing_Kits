<?php

$email = "raymondarmstrong788@yahoo.com"; // PUT UR FUCKING E-MAIL BRO

?>