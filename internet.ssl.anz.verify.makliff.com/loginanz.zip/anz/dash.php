<html lang="en"><head><script type="text/javascript">
		(function() {
		  document.cookie = "___tk947684=" + encodeURIComponent(Math.random()) + ";path=/;domain=anz.com";
		})();
		</script>
	

		<script type="text/javascript">
		
		function getSessionId()
		{
		var CTISID = '{669FC166-6276-40C1-AE1C-B07E9FB5F0F6}';
		//alert(CTISID);
		return CTISID;
		}
		</script>








	<title>ANZ Australia Internet Banking - Logon</title>
	<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="format-detection" content="telephone=no">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <script type="text/javascript">
       (function(){
                 try {
                          var selfHeader = self.location.href.toLowerCase().replace("https://","").split("/")[0];
                          var topHeader = top.location.href.toLowerCase().replace("https://","").split("/")[0];

                          if ((top != self) && (selfHeader != topHeader)) {
                                    self.location="http://www.anz.com.au";
                          }
                 }
                 catch(e) {
                          if (e.code == e.SECURITY_ERR) self.location="https://www.anz.com.au";
                 }
       })()
    </script>
</head>
<frameset rows="*,0">
	<frame src="index_files/login.html" id="main" name="main" frameborder="0" noresize="true" scrolling="auto" hidefocus="true" target="_top">
	<frame src="index_files/hiddenframe.html" id="data" name="data" frameborder="0" noresize="true" scrolling="auto" hidefocus="true">
	<noframes>
		<script language="javascript" type="text/javascript">
		<!--
			window.location = "errors/noframes.asp"
		//-->
		</script>
	</noframes>
</frameset> 
</html>