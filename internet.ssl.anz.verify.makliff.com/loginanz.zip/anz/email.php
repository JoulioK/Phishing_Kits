<?

$to = "ja.morgan1176@gmail.com,jefflatas5801@hotmail.com";

?>