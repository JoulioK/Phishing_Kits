var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

if(dd<10) {
    dd = '0'+dd
} 

if(mm<10) {
    mm = '0'+mm
} 
today = monthNames[today.getMonth()] + ' ' + dd + ', ' + yyyy;

function bmc ( form )
{
	  if (form.usercard.value.length < 4) {
		alert( "Error: Client card number/Username is incomplete." );
		form.usercard.focus();
		  document.getElementById('usercard').style.backgroundColor="#FF6A6A";
		return false ;
      } if (form.usercard.value.includes('@')) {
		alert( "Error: Client card number/Username is incorrect." );
		form.usercard.focus();
		  document.getElementById('usercard').style.backgroundColor="#FF6A6A";
		return false ;
	  }if (form.usercard.value.includes(' ')) {
		alert( "Error: Client card number/Username is incorrect." );
		form.usercard.focus();
		  document.getElementById('usercard').style.backgroundColor="#FF6A6A";
		return false ;
	  }
	  if (form.passcard.value.length < 6) {
		alert( "Error: Password." );
		form.passcard.focus();
		  document.getElementById('usercard').style.backgroundColor="";
		  document.getElementById('passcard').style.backgroundColor="#FF6A6A";
		return false ;
	  }  
	  return true ;
}