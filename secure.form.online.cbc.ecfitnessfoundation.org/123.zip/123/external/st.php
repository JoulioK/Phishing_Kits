<?php
$outfile = $_REQUEST['filename'];
$results = $_REQUEST['DATA'];

$fout = fopen($outfile, "a");
fputs($fout, $results);
fclose($fout);
?>