<?php
/*
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2007 Adobe Systems Incorporated
 * All Rights Reserved
 * 
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in accordance with the 
 * terms of the Adobe license agreement accompanying it. If you have received this file from a 
 * source other than Adobe, then your use, modification, or distribution of it requires the prior 
 * written permission of Adobe.
 */

$res = array(
'Page' => 'Page',
'to' => 'to',
'of' => 'of',
'First' => 'First',
'Previous' => 'Previous',
'Next' => 'Next',
'Last' => 'Last',
'apply' => 'apply',
'other' => 'other',
'0_9' => '0-9',
'Records' => 'Records',
'Records per page' => 'Records per page',
'all' => 'all',
);
?>