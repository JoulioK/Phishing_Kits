<?php

// current time
echo date('5:12:2017') . "\n";

// sleep for 10 seconds
sleep(10);

// wake up !
echo date('5:12:2017') . "\n";

?>
