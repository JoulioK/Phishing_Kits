From: "Saved by Internet Explorer 11"
Subject: Zimbra Web Client Sign In
Date: Sun, 16 Dec 2018 16:47:03 +0100
MIME-Version: 1.0
Content-Type: multipart/related;
	type="text/html";
	boundary="----=_NextPart_000_0005_01D4955E.F91E3D40"
X-MimeOLE: Produced By Microsoft MimeOLE V6.1.7601.23651

This is a multi-part message in MIME format.

------=_NextPart_000_0005_01D4955E.F91E3D40
Content-Type: text/html;
	charset="utf-8"
Content-Transfer-Encoding: quoted-printable
Content-Location: https://mailsrv.muskingum.edu/zimbra/

=EF=BB=BF<!DOCTYPE HTML>
<!DOCTYPE html PUBLIC "" ""><!-- set this class so CSS definitions that =
now use REM size, would work relative to this.=0A=
	Since now almost everything is relative to one of the 2 absolute font =
size classese --><HTML=20
class=3D"user_font_size_normal" lang=3D"en"><HEAD><META =
content=3D"IE=3D11.0000"=20
http-equiv=3D"X-UA-Compatible">
 <!--=0A=
 login.jsp=0A=
 * ***** BEGIN LICENSE BLOCK *****=0A=
 * Zimbra Collaboration Suite Web Client=0A=
 * Copyright (C) 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014 Zimbra, =
Inc.=0A=
 * =0A=
 * This program is free software: you can redistribute it and/or modify =
it under=0A=
 * the terms of the GNU General Public License as published by the Free =
Software Foundation,=0A=
 * version 2 of the License.=0A=
 * =0A=
 * This program is distributed in the hope that it will be useful, but =
WITHOUT ANY WARRANTY;=0A=
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A =
PARTICULAR PURPOSE.=0A=
 * See the GNU General Public License for more details.=0A=
 * You should have received a copy of the GNU General Public License =
along with this program.=0A=
 * If not, see <http://www.gnu.org/licenses/>.=0A=
 * ***** END LICENSE BLOCK *****=0A=
-->
		=20
<META http-equiv=3D"Content-Type" content=3D"text/html;charset=3Dutf-8">
	 <TITLE>Zimbra Web Client Sign In</TITLE>		=20
<META name=3D"viewport" content=3D"width=3Ddevice-width, =
initial-scale=3D1.0">	=20
<META name=3D"description" content=3D"Zimbra provides open source server =
and client software for messaging and collaboration. To find out more =
visit http://www.zimbra.com.">
	=20
<META name=3D"apple-mobile-web-app-capable" content=3D"yes">	=20
<META name=3D"apple-mobile-web-app-status-bar-style" content=3D"black">	 =
<LINK =
href=3D"https://mailsrv.muskingum.edu/zimbra/css/common,login,zhtml,skin.=
css?skin=3Dharmony&amp;v=3D141215153641"=20
rel=3D"stylesheet" type=3D"text/css">		 <LINK =
href=3D"/zimbra/img/logo/favicon.ico"=20
rel=3D"SHORTCUT ICON">		=20
<META name=3D"GENERATOR" content=3D"MSHTML 11.00.9600.18838"></HEAD>=20
<BODY onload=3D"onLoad();">
<DIV class=3D"LoginScreen">
<DIV class=3D"center">
<DIV class=3D"contentBox">
<H1><A title=3D"Zimbra" id=3D"bannerLink" =
href=3D"http://www.zimbra.com/" target=3D"_new"><SPAN=20
class=3D"ScreenReaderOnly">Zimbra</SPAN>					 <SPAN=20
class=3D"ImgLoginBanner"></SPAN></A></H1>
<DIV id=3D"ZLoginAppName">Web Client</DIV>
<FORM name=3D"loginForm" action=3D"/zimbra/" method=3D"post"=20
accept-charset=3D"UTF-8"><INPUT name=3D"loginOp" type=3D"hidden" =
value=3D"login">				=09
				=20
<TABLE class=3D"form">
  <TBODY>
  <TR>
    <TD><LABEL for=3D"username">Username:</LABEL></TD>
    <TD><INPUT name=3D"username" class=3D"zLoginField" id=3D"username" =
type=3D"text" size=3D"40" maxlength=3D"1024" autocorrect=3D"off" =
autocapitalize=3D"off"></TD></TR>
  <TR>
    <TD><LABEL for=3D"password">Password:</LABEL></TD>
    <TD><INPUT name=3D"password" class=3D"zLoginField" id=3D"password" =
type=3D"password" size=3D"40" maxlength=3D"1024" =
autocomplete=3D"off"></TD></TR>
  <TR>
    <TD>&nbsp;</TD>
    <TD class=3D"submitTD"><INPUT name=3D"zrememberme" id=3D"remember" =
type=3D"checkbox"=20
      value=3D"1">												 <LABEL for=3D"remember">Stay signed =
in</LABEL>
      												 <INPUT class=3D"ZLoginButton DwtButton" =
type=3D"submit" value=3D"Sign In">
      											 </TD></TR>
  <TR>
    <TD colspan=3D"2">
      <HR>
    </TD></TR>
  <TR>
    <TD><LABEL for=3D"client">Version:</LABEL>						 </TD>
    <TD>
      <DIV class=3D"positioning"><SELECT name=3D"client" id=3D"client" =
onchange=3D"clientChange(this.options[this.selectedIndex].value)"><OPTION=
=20
        value=3D"preferred" selected=3D""> Default</OPTION>											 =
<OPTION=20
        value=3D"advanced"> Advanced (Ajax)</OPTION>											 <OPTION =
value=3D"standard">=20
        Standard (HTML)</OPTION>											 <OPTION value=3D"mobile">=20
        Mobile</OPTION>                                               =20
        											 <OPTION value=3D"touch"> Touch</OPTION>              =
         =20
                            										 </SELECT>									    							=20
<SCRIPT type=3D"text/javascript">=0A=
    								document.write("<a href=3D'#' onclick=3D'showWhatsThis();' =
id=3D'ZLoginWhatsThisAnchor' aria-controls=3D'ZLoginWhatsThis'>What's =
This?</a>");=0A=
    							</SCRIPT>
                                                                         =
     =20
      <DIV class=3D"ZLoginInfoMessage" id=3D"ZLoginWhatsThis" =
role=3D"tooltip" style=3D"display: none;"=20
      onclick=3D"showWhatsThis();">
      <H3 style=3D"text-align: center;">Client Types</H3><B>Advanced</B> =
offers=20
      the full set of Web collaboration features. This Web Client works =
best=20
      with newer browsers and faster Internet connections.=20
      <BR><BR><B>Standard</B> is recommended when Internet connections =
are slow,=20
      when using older browsers, or for easier accessibility.=20
      <BR><BR><B>Mobile</B> is recommended for mobile devices.=20
      <BR><BR><B>Touch</B> is recommended for tablets. <BR><BR>To set=20
      <B>Default</B> to be your preferred client type, change the sign =
in=20
      options in your Preferences, General tab after you sign in.</DIV>
      <DIV class=3D"ZLoginInfoMessage" id=3D"ZLoginUnsupported" =
style=3D"display: none;">Note=20
      that your web browser or display does not fully support the =
Advanced=20
      version.  We strongly recommend that you use the Standard=20
      client.</DIV></DIV></TD></TR></TBODY></TABLE></FORM></DIV>
<DIV class=3D"decor1"></DIV></DIV>
<DIV class=3D"Footer">
<DIV class=3D"legalNotice-small" id=3D"ZLoginNotice"><A =
href=3D"http://www.zimbra.com/"=20
target=3D"_new">Zimbra</A> :: the leader in open source messaging and=20
collaboration :: <A href=3D"http://blog.zimbra.com/" =
target=3D"_new">Blog</A> - <A=20
href=3D"http://wiki.zimbra.com/" target=3D"_new">Wiki</A> - <A =
href=3D"http://www.zimbra.com/forums"=20
target=3D"_new">Forums</A></DIV>
<DIV class=3D"copyright">			Copyright =C2=A9 2005-2014 Zimbra, Inc. All =
rights=20
reserved. "Zimbra" is a registered trademark of Zimbra, Inc.			 =
</DIV></DIV>
<DIV class=3D"decor2"></DIV></DIV>
<SCRIPT>=0A=
=0A=
function ZmSkin(e){=0A=
this.hints=3Dthis.mergeObjects(ZmSkin.hints,e)=0A=
}=0A=
ZmSkin.hints=3D{=0A=
name:"harmony",version:"1",skin:{=0A=
containers:"skin_outer"}=0A=
,banner:{=0A=
position:"static",url:"http://mailsrv.muskingum.edu/zimbra/"}=0A=
,userInfo:{=0A=
position:"static"}=0A=
,search:{=0A=
position:"static"}=0A=
,quota:{=0A=
position:"static"}=0A=
,presence:{=0A=
width:"40px",height:"24px"}=0A=
,appView:{=0A=
position:"static"}=0A=
,searchResultsToolbar:{=0A=
containers:["skin_tr_search_results_toolbar"]}=0A=
,newButton:{=0A=
containers:["skin_td_new_button"]}=0A=
,tree:{=0A=
minWidth:"13.5rem",maxWidth:"84rem",containers:["skin_td_tree","skin_td_t=
ree_app_sash"],resizeContainers:["skin_td_tree","skin_container_app_new_b=
utton"]}=0A=
,topToolbar:{=0A=
containers:"skin_spacing_app_top_toolbar"}=0A=
,treeFooter:{=0A=
containers:"skin_tr_tree_footer"}=0A=
,topAd:{=0A=
containers:"skin_tr_top_ad"}=0A=
,sidebarAd:{=0A=
containers:"skin_td_sidebar_ad"}=0A=
,bottomAd:{=0A=
containers:"skin_tr_bottom_ad"}=0A=
,treeTopAd:{=0A=
containers:"skin_tr_tree_top_ad"}=0A=
,treeBottomAd:{=0A=
containers:"skin_tr_tree_bottom_ad"}=0A=
,helpButton:{=0A=
style:"link",container:"quota",url:""}=0A=
,logoutButton:{=0A=
style:"link",container:"quota"}=0A=
,appChooser:{=0A=
position:"static",direction:"LR"}=0A=
,toast:{=0A=
location:"N",transitions:[{=0A=
type:"fade-in",step:5,duration:50}=0A=
,{=0A=
type:"pause",duration:5000}=0A=
,{=0A=
type:"fade-out",step:-10,duration:500}=0A=
]}=0A=
,fullScreen:{=0A=
containers:["!skin_td_tree","!skin_td_tree_app_sash"]}=0A=
,allAds:{=0A=
containers:["skin_tr_top_ad","skin_td_sidebar_ad","skin_tr_bottom_ad","sk=
in_tr_tree_top_ad","skin_tr_tree_bottom_ad"]}=0A=
,hideSearchInCompose:true,notificationBanner:"/zimbra/skins/_base/logos/N=
otificationBanner_grey.gif?v=3D141215153641",socialfox:{=0A=
iconURL:"/zimbra/img/logo/ImgZimbraIcon.gif",icon32URL:"/zimbra/img/logo/=
ImgZimbraLogo_32.gif",icon64URL:"/zimbra/img/logo/ImgZimbraLogo_64.gif",m=
ailIconURL:"/zimbra/img/zimbra/ImgMessage.png"}};=0A=
window.BaseSkin=3DZmSkin;=0A=
ZmSkin.prototype=3D{=0A=
show:function(t,e,l){=0A=
var a=3Dthis.hints[t]&&this.hints[t].containers;=0A=
if(a){=0A=
if(typeof a=3D=3D"function"){=0A=
a.apply(this,[e!=3Dfalse]);=0A=
skin._reflowApp();=0A=
return=0A=
}=0A=
if(typeof a=3D=3D"string"){=0A=
a=3D[a]=0A=
}=0A=
var s=3Dfalse;=0A=
for(var r=3D0;=0A=
r<a.length;=0A=
r++){=0A=
var h=3Da[r];=0A=
var o=3Dh.replace(/^!/,"");=0A=
var n=3Dh!=3Do;=0A=
if(this._showEl(o,n?!e:e)){=0A=
s=3Dtrue=0A=
}}=0A=
if(s&&!l){=0A=
skin._reflowApp()=0A=
}}}=0A=
,hide:function(e,t){=0A=
this.show(e,false,t)=0A=
}=0A=
,gotoApp:function(e,t){=0A=
appCtxt.getAppController().activateApp(e,null,t)=0A=
}=0A=
,gotoPrefs:function(e){=0A=
if(appCtxt.getCurrentAppName()!=3DZmApp.PREFERENCES){=0A=
var t=3Dnew AjxCallback(this,this._gotoPrefPage,[e]);=0A=
this.gotoApp(ZmApp.PREFERENCES,t)=0A=
}else{=0A=
this._gotoPrefPage(e)=0A=
}}=0A=
,mergeObjects:function(e,o){=0A=
if(e=3D=3Dnull){=0A=
e=3D{}=0A=
}=0A=
for(var a=3D1;=0A=
a<arguments.length;=0A=
a++){=0A=
var n=3Darguments[a];=0A=
for(var t in n){=0A=
var s=3De[t];=0A=
if(typeof s=3D=3D"object"&&!(s instanceof Array)){=0A=
this.mergeObjects(e[t],n[t]);=0A=
continue=0A=
}=0A=
if(!e[t]){=0A=
e[t]=3Dn[t]=0A=
}}}=0A=
return e=0A=
}=0A=
,getTreeWidth:function(){=0A=
return Dwt.getSize(this._getEl(this.hints.tree.containers[0])).x=0A=
}=0A=
,setTreeWidth:function(e){=0A=
this._setContainerSizes("tree",e,null)=0A=
}=0A=
,showTopAd:function(e){=0A=
if(skin._showEl("skin_tr_top_ad",e)){=0A=
skin._reflowApp()=0A=
}}=0A=
,hideTopAd:function(){=0A=
skin.showTopAd(false)=0A=
}=0A=
,getTopAdContainer:function(){=0A=
return skin._getEl("skin_container_top_ad")=0A=
}=0A=
,showSidebarAd:function(e){=0A=
var t=3D"skin_td_sidebar_ad";=0A=
if(e!=3Dnull){=0A=
Dwt.setSize(t,e)=0A=
}=0A=
if(skin._showEl(t)){=0A=
skin._reflowApp()=0A=
}}=0A=
,hideSidebarAd:function(){=0A=
var e=3D"skin_td_sidebar_ad";=0A=
if(skin._hideEl(e)){=0A=
skin._reflowApp()=0A=
}}=0A=
,getSidebarAdContainer:function(){=0A=
return this._getEl("skin_container_sidebar_ad")=0A=
}=0A=
,handleNotification:function(t,e){}=0A=
,_getEl:function(e){=0A=
return(typeof e=3D=3D"string"?document.getElementById(e):e)=0A=
}=0A=
,_showEl:function(o,i){=0A=
var t=3Dthis._getEl(o);=0A=
if(!t){=0A=
return=0A=
}=0A=
var a;=0A=
if(i=3D=3Dfalse){=0A=
a=3D"none"=0A=
}else{=0A=
var e=3Dt.tagName;=0A=
if(e=3D=3D"TD"){=0A=
a=3D"table-cell"=0A=
}else{=0A=
if(e=3D=3D"TR"){=0A=
a=3D"table-row"=0A=
}else{=0A=
a=3D"block"=0A=
}}}=0A=
if(a!=3Dt.style.display){=0A=
t.style.display=3Da;=0A=
return true=0A=
}else{=0A=
return false=0A=
}}=0A=
,_hideEl:function(e){=0A=
return this._showEl(e,false)=0A=
}=0A=
,_reparentEl:function(i,e){=0A=
var a=3Dthis._getEl(e);=0A=
var t=3Da&&this._getEl(i);=0A=
if(t){=0A=
a.appendChild(t)=0A=
}}=0A=
,_setContainerSizes:function(n,a,e){=0A=
var o=3Dthis.hints[n].resizeContainers||this.hints[n].containers;=0A=
for(var t=3D0;=0A=
t<o.length;=0A=
t++){=0A=
Dwt.setSize(o[t],a,null)=0A=
}}=0A=
,_reflowApp:function(){=0A=
if(window._zimbraMail){=0A=
window._zimbraMail.getAppViewMgr().fitAll()=0A=
}}=0A=
,_gotoPrefPage:function(a){=0A=
if(a=3D=3Dnull){=0A=
return=0A=
}=0A=
var i=3DappCtxt.getApp(ZmApp.PREFERENCES);=0A=
var t=3Di.getPrefController();=0A=
var e=3Dt.getPrefsView();=0A=
e.selectSection(a)=0A=
}};=0A=
window.skin=3Dnew ZmSkin();=0A=
var link =3D document.getElementById("bannerLink");=0A=
if (link) {=0A=
	link.href =3D skin.hints.banner.url;=0A=
}=0A=
=0A=
=0A=
=0A=
// show a message if they should be using the 'standard' client, but =
have chosen 'advanced' instead=0A=
function clientChange(selectValue) {=0A=
	var useStandard =3D false;=0A=
	useStandard =3D useStandard || (screen && (screen.width <=3D 800 && =
screen.height <=3D 600));=0A=
	var div =3D document.getElementById("ZLoginUnsupported");=0A=
	if (div)=0A=
	div.style.display =3D ((selectValue =3D=3D 'advanced') && useStandard) =
? 'block' : 'none';=0A=
}=0A=
=0A=
// if they have JS, write out a "what's this?" link that shows the =
message below=0A=
function showWhatsThis() {=0A=
	var div =3D document.getElementById("ZLoginWhatsThis"),=0A=
        doHide =3D (div.style.display =3D=3D=3D "block");=0A=
	div.style.display =3D doHide ? "none" : "block";=0A=
    div.setAttribute("aria-expanded", doHide ? "false" : "true");=0A=
}=0A=
=0A=
function onLoad() {=0A=
	var loginForm =3D document.loginForm;=0A=
	if (loginForm.username) {=0A=
		if (loginForm.username.value !=3D "") {=0A=
			loginForm.password.focus(); //if username set, focus on password=0A=
		}=0A=
		else {=0A=
			loginForm.username.focus();=0A=
		}=0A=
	}=0A=
	clientChange("preferred");=0A=
    //check if the login page is loaded in the sidebar.=0A=
    if (navigator.mozSocial) {=0A=
        //send a ping so that worker knows about this page.=0A=
        navigator.mozSocial.getWorker().port.postMessage({topic: =
"worker.reload", data: true});=0A=
        //this page is loaded in firefox sidebar so listen for message =
from worker.=0A=
        navigator.mozSocial.getWorker().port.onmessage =3D function =
onmessage(e) {=0A=
            var topic =3D e.data.topic;=0A=
            if (topic && topic =3D=3D "sidebar.authenticated") {=0A=
                window.location.href =3D "/public/launchSidebar.jsp";=0A=
            }=0A=
        };=0A=
    }=0A=
}=0A=
=0A=
</SCRIPT>
 </BODY></HTML>

------=_NextPart_000_0005_01D4955E.F91E3D40
Content-Type: application/octet-stream
Content-Transfer-Encoding: quoted-printable
Content-Location: https://mailsrv.muskingum.edu/zimbra/css/common,login,zhtml,skin.css?skin=harmony&v=141215153641

.ScreenReaderOnly {
	width: 1px; height: 1px; overflow: hidden; position: absolute =
!important; clip: rect(1px, 1px, 1px, 1px);
}
.user_font_modern {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.user_font_classic {
	font-family: Tahoma,Arial,sans-serif;
}
.user_font_wide {
	font-family: Verdana,sans-serif;
}
.user_font_system {
	font-family: "Segoe UI","Lucida Sans",sans-serif;
}
.user_font_size_small {
	font-size: 11px;
}
.user_font_size_normal {
	font-size: 12px;
}
.user_font_size_large {
	font-size: 14px;
}
.user_font_size_larger {
	font-size: 16px;
}
p {
	font-size: 1rem;
}
th {
	font-size: 1rem;
}
td {
	font-size: 1rem;
}
div {
	font-size: 1rem;
}
select {
	font-size: 1rem;
}
input[type=3Dtext] {
	font-size: 1rem;
}
input[type=3Dpassword] {
	font-size: 1rem;
}
input[type=3Dfile] {
	font-size: 1rem;
}
textarea {
	font-size: 1rem;
}
button {
	font-size: 1rem;
}
html {
	width: 100%; height: 100%;
}
body {
	margin: 0px; width: 100%; height: 100%;
}
form {
	margin: 0px; padding: 0px;
}
table {
	border-width: 0px; border-collapse: collapse; border-spacing: 0;
}
td {
	border-width: 0px; padding: 0px;
}
fieldset {
	margin: 5px; padding: 5px; border: 1px solid rgb(242, 242, 242); =
border-image: none;
}
legend {
	color: rgb(51, 51, 51); overflow: hidden; font-weight: bold; =
white-space: nowrap;
}
input[readonly] {
	border: 1px solid rgb(229, 229, 229); border-image: none; color: =
rgb(153, 153, 153); background-color: transparent;
}
textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(191, 191, 191); =
border-image: none; color: black; cursor: text; background-color: white;
}
textarea[readonly] {
	border: 1px solid rgb(229, 229, 229); border-image: none; color: =
rgb(153, 153, 153); background-color: transparent;
}
input[type=3D'checkbox'] {
	cursor: pointer;
}
input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
input[disabled] {
	border: 1px solid rgb(229, 229, 229); border-image: none; color: =
rgb(153, 153, 153); background-color: transparent;
}
textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(191, 191, 191); =
border-image: none; color: black; cursor: text; background-color: white;
}
.CompactTable {
	padding: 0px; border-collapse: collapse; border-spacing: 0;
}
.fullSize {
	width: 100%; height: 100%;
}
.fullWidth {
	width: 100%;
}
.fullHeight {
	height: 100%;
}
.minSize {
	width: 1px; height: 1px;
}
.leftAlign {
	text-align: left;
}
.rightAlign {
	text-align: right;
}
.checkboxLabel {
	font-weight: bold;
}
.ToolbarBg {
	background-color: transparent;
}
.ZmHead {
	font-size: 1.36rem; font-weight: bold;
}
.ZmSubHead {
	font-size: 1.18rem;
}
.ZmBigger {
	font-size: 1.36rem; font-weight: bold;
}
.ZmFinePrint {
	font-size: 0.82rem;
}
.ZmImportant {
	color: darkred;
}
.ZmFieldLabel {
	color: rgb(51, 51, 51); overflow: hidden; white-space: nowrap;
}
.ZmFieldLabelLeft {
	text-align: left; color: rgb(51, 51, 51); overflow: hidden; =
white-space: nowrap;
}
.ZmFieldLabelRight {
	text-align: right; color: rgb(51, 51, 51); overflow: hidden; =
white-space: nowrap;
}
.ZmFieldLabelCenter {
	text-align: center; color: rgb(51, 51, 51); overflow: hidden; =
white-space: nowrap;
}
ZmSectionLabel {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 1.36rem; =
font-weight: bold; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; white-space: =
nowrap;
}
.TextPadding {
	padding-right: 3px; padding-left: 3px;
}
.BigHeaderBg {
	height: 2.8rem; padding-top: 1px; border-bottom-color: rgb(242, 242, =
242); border-bottom-width: 1px; border-bottom-style: solid; =
background-color: rgb(229, 229, 229);
}
.ZmOverride {
	padding: 2px; background-color: rgb(255, 246, 191);
}
.ZmGraphKey {
	border-width: 1px; border-style: solid; border-color: rgb(127, 127, =
127) rgb(204, 204, 204) rgb(204, 204, 204) rgb(127, 127, 127); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZmGraphKeyHeader {
	text-align: left; color: rgb(51, 51, 51); padding-right: 3px; =
padding-left: 3px; font-size: 1.18rem; font-weight: bold; =
vertical-align: middle; background-color: rgb(229, 229, 229);
}
.ZmGraphKeyBody {
	margin: 5px; padding: 5px;
}
.ZmGraphKeyColorBox {
	border-width: 1px; border-style: solid; border-color: rgb(127, 127, =
127) rgb(204, 204, 204) rgb(204, 204, 204) rgb(127, 127, 127); margin: =
0px; width: 10px; height: 10px;
}
.ZmGraphKeyColorText {
	color: rgb(51, 51, 51); overflow: hidden; white-space: nowrap;
}
.horizSep {
	margin: 5px 0px; width: 100%; height: 1px !important; line-height: 1px; =
font-size: 1px; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid;
}
.vertSep {
	height: 20px; padding-right: 3px; margin-left: 3px; border-left-color: =
rgb(242, 242, 242); border-left-width: 1px; border-left-style: solid;
}
div.vSpace {
	margin: 5px 0px;
}
td.vSpace {
	width: 2px;
}
.AttLink:link {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.AttLink:visited {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.AttLink:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.AttLink:active {
	color: darkgreen; text-decoration: underline;
}
.Row-selected .AttLink:link {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.Row-selected .AttLink:active {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.Row-selected .AttLink:visited {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.AttLink:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.Row-selected .AttLink:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.DragProxy {
	opacity: 0.7;
}
.notDroppable {
	border: 2px solid red !important; border-image: none !important; =
opacity: 0.7; box-shadow: 5px 5px 25px grey; background-color: rgb(153, =
207, 231);
}
.notDroppable-linux {
	border: 2px solid red !important; border-image: none !important; =
box-shadow: 5px 5px 25px grey; background-color: rgb(153, 207, 231);
}
.droppable {
	border: 2px solid green !important; border-image: none !important; =
opacity: 0.7; box-shadow: 5px 5px 25px grey; background-color: rgb(153, =
207, 231);
}
.droppable-linux {
	border: 2px solid green !important; border-image: none !important; =
box-shadow: 5px 5px 25px grey; background-color: rgb(153, 207, 231);
}
.DropTarget {
	border: 1px solid green !important; border-image: none !important;
}
.DragProxyTextLabel {
	color: white; font-weight: bold;
}
.BusyOverlay table {
	cursor: wait; opacity: 0.5; background-color: transparent;
}
.VeilOverlay table {
	cursor: wait; opacity: 0.5; background-color: transparent;
}
.BusyOverlay-linux table {
	cursor: wait; background-color: transparent;
}
.VeilOverlay-linux table {
	cursor: wait; background-color: transparent;
}
.VeilOverlay table {
	cursor: not-allowed !important; background-color: black;
}
.VeilOverlay-linux table {
	cursor: not-allowed !important;
}
.CurtainOverlay table {
	background-color: black;
}
.Row {
	border-width: 1px 0px; border-style: solid; border-color: rgb(255, 255, =
255); height: 1.8rem; cursor: pointer; user-select: none;
}
.RowDouble {
	border-width: 1px 0px; border-style: solid; border-color: rgb(255, 255, =
255) rgb(255, 255, 255) rgb(204, 204, 204); height: 2.6rem; padding-top: =
3px; cursor: pointer; user-select: none;
}
.Row table {
	table-layout: fixed;
}
.RowDouble table {
	table-layout: fixed;
}
.Row td {
	overflow: hidden; vertical-align: middle; white-space: nowrap;
}
.RowDouble td {
	overflow: hidden; vertical-align: middle; white-space: nowrap;
}
.Row div {
	overflow: hidden; vertical-align: middle; white-space: nowrap;
}
.RowDouble div {
	overflow: hidden; vertical-align: middle; white-space: nowrap;
}
.RowDouble td {
	vertical-align: top;
}
.RowDouble td.SubjectDoubleRow {
	vertical-align: text-bottom;
}
.ZmMsgListBottomRowIcon {
	margin-right: 5px; margin-left: 23px;
}
.ZmConvExpanded .ZmMsgListBottomRowIcon {
	margin-left: 39px;
}
.ZmMsgListSelection .ZmMsgListBottomRowIcon {
	margin-left: 37px;
}
.ZmConvExpanded .ZmMsgListSelection .ZmMsgListBottomRowIcon {
	margin-left: 54px;
}
.Row {
	border-top-color: rgb(255, 255, 255); background-color: rgb(255, 255, =
255);
}
.RowOdd {
	border-top-color: rgb(255, 255, 255); background-color: rgb(255, 255, =
255);
}
.selected {
	border-top-color: rgb(153, 207, 231) !important; background-image: none =
!important; background-color: rgb(153, 207, 231) !important;
}
.Row-selected {
	border-top-color: rgb(153, 207, 231) !important; background-image: none =
!important; background-color: rgb(153, 207, 231) !important;
}
.Row-selected-dragProxy {
	border-top-color: rgb(153, 207, 231) !important; background-image: none =
!important; background-color: rgb(153, 207, 231) !important;
}
.Row-selected-disabled {
	border-top-color: rgb(153, 207, 231) !important; background-image: none =
!important; background-color: rgb(153, 207, 231) !important;
}
.Row-selected .ZmListFlagsWrapper {
	background: rgb(153, 207, 231) !important;
}
.Row-selected-disabled .ZmListFlagsWrapper {
	background: rgb(153, 207, 231) !important;
}
.Row-selected .ZmMsgListDate {
	background: rgb(153, 207, 231) !important;
}
.Row-selected-disabled .ZmMsgListDate {
	background: rgb(153, 207, 231) !important;
}
.Row-selected-actioned .ZmListFlagsWrapper {
	background: rgb(153, 207, 231) !important;
}
.Row-selected-actioned .ZmMsgListDate {
	background: rgb(153, 207, 231) !important;
}
.Row-altSelected {
	border-top-color: rgb(229, 243, 249) !important; background-image: none =
!important; background-color: rgb(229, 243, 249) !important;
}
.Row-altSelected .ZmListFlagsWrapper {
	background: rgb(229, 243, 249) !important;
}
.Row-altSelected .ZmMsgListDate {
	background: rgb(229, 243, 249) !important;
}
.Row-matched-dragProxy {
	border-width: 1px 0px; border-style: solid; border-color: rgb(255, 255, =
255); background-color: yellow;
}
.Row-matched table {
	table-layout: fixed;
}
.Row-matched-drag table {
	table-layout: fixed;
}
.Row-focused {
	border-width: 1px 0px; border-style: solid; border-color: rgb(122, 165, =
184) rgb(91, 124, 138) rgb(91, 124, 138) rgb(122, 165, 184); margin: =
0px;
}
.Row-selected-actioned {
	border-color: rgb(153, 207, 231) !important; background-color: rgb(153, =
207, 231) !important;
}
.Row-dragProxy {
	background-color: rgb(153, 207, 231) !important;
}
.Row-matched-dragProxy {
	background-color: rgb(153, 207, 231) !important;
}
.RowDouble-dragProxy .ZmListFlagsWrapper {
	background-color: rgb(153, 207, 231) !important;
}
.RowDouble-dragProxy .ZmMsgListDate {
	background-color: rgb(153, 207, 231) !important;
}
.Row-dragProxy .ZmListFlagsWrapper {
	background-color: rgb(153, 207, 231) !important;
}
.Row-dragProxy .ZmMsgListDate {
	background-color: rgb(153, 207, 231) !important;
}
.Row td {
	color: rgb(51, 51, 51);
}
.RowDouble td {
	color: rgb(51, 51, 51);
}
.Row div {
	color: rgb(51, 51, 51);
}
.RowDouble div {
	color: rgb(51, 51, 51);
}
.RowOdd td {
	color: rgb(51, 51, 51);
}
.RowOdd div {
	color: rgb(51, 51, 51);
}
.RowOdd .ZmMsgListDate {
	background-color: rgb(255, 255, 255);
}
.RowOdd .ZmListFlagsWrapper {
	background-color: rgb(255, 255, 255);
}
li.RowDouble {
	list-style: none;
}
li.Row {
	list-style: none;
}
.selected td {
	color: black;
}
.Row-selected td {
	color: black;
}
.Row-selected-dragProxy td {
	color: black;
}
.Row-selected-disabled td {
	color: black;
}
.Row-focused td {
	color: rgb(51, 51, 51);
}
.Row-selected-right td {
	color: rgb(51, 51, 51);
}
.Row-dragProxy td {
	color: rgb(51, 51, 51);
}
.Row-matched-dragProxy td {
	color: rgb(51, 51, 51);
}
.Row td.Flag {
	text-align: center;
}
.Row td.Attach {
	text-align: center;
}
.Row td.Tag {
	text-align: center;
}
.Row td.Icon {
	text-align: center;
}
.Row td.Count {
	text-align: center;
}
.Row-selected td.Flag {
	text-align: center;
}
.Row-selected td.Attach {
	text-align: center;
}
.Row-selected td.Tag {
	text-align: center;
}
.Row-selected td.Icon {
	text-align: center;
}
.Row-selected td.Count {
	text-align: center;
}
.Row-dragProxy td.Flag {
	text-align: center;
}
.Row-dragProxy td.Attach {
	text-align: center;
}
.Row-dragProxy td.Tag {
	text-align: center;
}
.Row-dragProxy td.Icon {
	text-align: center;
}
.Row-dragProxy td.Count {
	text-align: center;
}
.Row-selected-dragProxy td.Flag {
	text-align: center;
}
.Row-selected-dragProxy td.Attach {
	text-align: center;
}
.Row-selected-dragProxy td.Tag {
	text-align: center;
}
.Row-selected-dragProxy td.Icon {
	text-align: center;
}
.Row-selected-dragProxy td.Count {
	text-align: center;
}
.Row-matched-dragProxy td.Flag {
	text-align: center;
}
.Row-matched-dragProxy td.Attach {
	text-align: center;
}
.Row-matched-dragProxy td.Tag {
	text-align: center;
}
.Row-matched-dragProxy td.Icon {
	text-align: center;
}
.Row-matched-dragProxy td.Count {
	text-align: center;
}
.Row-dragProxy td.Flag {
	text-align: center;
}
.Row-dragProxy td.Attach {
	text-align: center;
}
.Row-dragProxy td.Tag {
	text-align: center;
}
.Row-dragProxy td.Icon {
	text-align: center;
}
.Row-dragProxy td.Count {
	text-align: center;
}
.RowDouble td.Count {
	text-align: right;
}
.RowDouble-selected td.Count {
	text-align: right;
}
.Unread {
	color: rgb(51, 51, 51); font-weight: bold;
}
.Trash {
	color: rgb(153, 153, 153); text-decoration: line-through;
}
.Unread .SubjectDoubleRow {
	color: rgb(51, 51, 51); font-weight: bold;
}
.ZmOverview {
	width: 100%; height: 100%;
}
.ZmOverviewContainer {
	border-radius: 3px; border: currentColor; border-image: none; =
background-color: rgb(255, 255, 255);
}
.ZmVoiceOverviewContainer .ZmOverview {
	height: auto;
}
.ZmOverviewContainer .ZmOverview {
	height: auto;
}
.dialogOverviewContainer .OverviewTree {
	height: auto;
}
.OverviewTree {
	width: 100%;
}
.dialogOverview {
	border-width: 1px; border-style: solid; border-color: rgb(127, 127, =
127) rgb(204, 204, 204) rgb(204, 204, 204) rgb(127, 127, 127); margin: =
0px; padding: 5px; border-radius: 3px; border-image: none; height: =
200px; background-color: rgb(255, 255, 255);
}
.dialogOverviewContainer {
	background-color: rgb(255, 255, 255);
}
.dialogOverview td {
	color: rgb(51, 51, 51);
}
.pickerOverview {
	border-radius: 3px; border: currentColor; border-image: none; height: =
100%; background-color: rgb(255, 255, 255);
}
.overviewHeader {
	color: rgb(51, 51, 51); padding-top: 1px; padding-bottom: 1px; =
font-weight: bold; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; cursor: default; =
background-color: rgb(229, 229, 229);
}
.overviewHeader-Text {
	color: rgb(51, 51, 51); font-weight: bold;
}
.overviewHeader-dragOver {
	color: rgb(51, 51, 51); font-weight: bold;
}
.overviewHeader-selected {
	background-color: rgb(178, 219, 237) !important;
}
.overviewHeader-selected-focused {
	background-color: rgb(153, 207, 231) !important;
}
.overviewHeader .imageCell {
	padding-top: 0.2rem; padding-right: 5px; white-space: nowrap;
}
.overviewHeader td {
	background-color: rgb(255, 255, 255);
}
.overviewHeader-selected td {
	background-color: rgb(242, 242, 242);
}
.inlineIcon {
	font-family: Verdana; font-size: 13px;
}
.inlineContactTagIcon {
	font-size: 11px; vertical-align: middle;
}
.TooltipHint {
	text-align: center; font-style: italic; white-space: nowrap;
}
.TooltipNotInAddrBook {
	padding: 8px 0px 5px; text-align: center; white-space: nowrap;
}
.ImgTagShared {
	display: inline-block;
}
.FakeAnchor {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
a:link {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
a:visited {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.FakeAnchor:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
a:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.FakeAnchor:active {
	color: darkgreen; text-decoration: underline;
}
a:active {
	color: darkgreen; text-decoration: underline;
}
.ZDisabled.FakeAnchor {
	color: rgb(153, 153, 153); text-decoration: none;
}
.ZDisabled.FakeAnchor:hover {
	color: rgb(153, 153, 153); text-decoration: none;
}
.ZDisabled.FakeAnchor:active {
	color: rgb(153, 153, 153); text-decoration: none;
}
.AutoAnchor {
	color: rgb(0, 90, 149); text-decoration: none; border-bottom-color: =
currentColor; border-bottom-width: 1px; border-bottom-style: dotted; =
cursor: pointer;
}
.AutoAnchor:link {
	color: rgb(0, 90, 149); text-decoration: none; border-bottom-color: =
currentColor; border-bottom-width: 1px; border-bottom-style: dotted; =
cursor: pointer;
}
.AutoAnchor:visited {
	color: rgb(0, 90, 149); text-decoration: none; border-bottom-color: =
currentColor; border-bottom-width: 1px; border-bottom-style: dotted; =
cursor: pointer;
}
.AutoAnchor:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.AutoAnchor:active {
	color: darkgreen; text-decoration: underline;
}
.LoginScreen p {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen th {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen td {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen div {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen span {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen select {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen input {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen textarea {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen button {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
.LoginScreen a {
	font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif;
}
html {
	width: 100%; height: 100%;
}
body {
	margin: 0px; width: 100%; height: 100%; background-color: rgb(255, 255, =
255);
}
form {
	margin: 0px; padding: 0px;
}
.ZSplashScreen {
	left: 0px; top: 0px; width: 100%; height: 100%; position: absolute; =
background-color: rgb(255, 255, 255);
}
#ZLoginPanel {
	border-width: 1px; border-style: solid; border-color: rgb(153, 153, =
153) rgb(127, 127, 127) rgb(127, 127, 127) rgb(153, 153, 153); margin: =
0px; border-radius: 4px; width: 500px; overflow: visible; position: =
relative; box-shadow: 5px 5px 25px grey; background-color: rgb(242, 242, =
242);
}
.LoginScreen form {
	text-align: center;
}
.form {
	margin: 0px auto; text-align: left; color: white; border-collapse: =
collapse;
}
.form td:first-child label {
	margin-right: 20px;
}
.form td {
	padding-bottom: 10px;
}
.form input[type=3D'text'] {
	padding: 0px; border: 1px solid rgb(255, 255, 255); border-image: none; =
width: 235px; height: 20px;
}
.form input[type=3D'password'] {
	padding: 0px; border: 1px solid rgb(255, 255, 255); border-image: none; =
width: 235px; height: 20px;
}
.form input[type=3D'text']:focus {
	border: 1px solid rgb(153, 207, 231); border-image: none;
}
.form input[type=3D'password']:focus {
	border: 1px solid rgb(153, 207, 231); border-image: none;
}
.form select {
	width: 165px; height: 20px;
}
.form .submitTD {
	text-align: left;
}
.form .ZLoginButton {
	border-radius: 3px; border: 1px solid rgb(153, 153, 153); border-image: =
none; font-size: 1em; float: right;
}
.form hr {
	border-color: transparent transparent white; height: 0px;
}
.LoginScreen .positioning {
	position: relative; z-index: 20;
}
.LoginScreen #ZLoginWhatsThisAnchor {
	color: white; font-size: 0.9em; margin-left: 5px;
}
.LoginScreen #ZLoginWhatsThis {
	left: 0px; top: 25px; width: 40em; margin-left: -10em; position: =
absolute; z-index: 30;
}
.LoginScreen .ZLoginInfoMessage {
	padding: 3px 7px; border: 1px solid rgb(0, 101, 146); border-image: =
none; text-align: left; color: rgb(51, 51, 51); box-shadow: 0px 0px 2px =
black; background-color: rgb(255, 255, 255);
}
.DwtButton {
	height: 2rem; cursor: pointer;
}
.DwtButton-hover {
	background: rgb(204, 231, 243); height: 2rem; cursor: pointer;
}
.DwtButton-active {
	background: rgb(153, 207, 231); height: 2rem; cursor: pointer;
}
.DwtButton-selected {
	background: rgb(153, 207, 231); height: 2rem; cursor: pointer;
}
.DwtButton-disabled {
	height: 2rem; cursor: pointer;
}
.DwtButton-active {
	border-width: 1px; border-style: solid; border-color: rgb(127, 127, =
127) rgb(63, 63, 63) rgb(63, 63, 63) rgb(127, 127, 127); margin: 0px; =
height: 2rem; cursor: pointer; background-color: rgb(163, 211, 233);
}
.DwtButton-focused {
	border-color: rgb(0, 135, 195); height: 2rem; cursor: pointer;
}
.DwtButton .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.DwtButton-hover .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.DwtButton-active .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.DwtButton-selected .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.DwtButton-disabled .Text {
	text-align: center; color: rgb(153, 153, 153);
}
.DwtButton-active .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.DwtButton-focused .Text {
	text-align: center; color: rgb(51, 51, 51);
}
.LaunchButton {
	padding: 10px; text-align: center;
}
.LaunchButton input {
	border-radius: 26px; border: 1px solid rgb(102, 204, 255); =
border-image: none; width: 250px; height: 35px; text-align: center; =
color: black; font-size: 1.36rem; font-weight: bold; display: =
inline-block; cursor: pointer; box-shadow: 0px 0px 3px black; =
background-image: linear-gradient(rgb(220, 249, 254), rgb(159, 240, =
255)); background-color: rgb(220, 249, 254);
}
.LaunchButton input:hover {
	box-shadow: 0px 0px 1px black; background-image: =
linear-gradient(rgb(159, 240, 255), rgb(220, 249, 254));
}
.spacer {
	padding: 5px; line-height: 1.3em; font-size: 1.2em;
}
.LoginScreen .center-small {
	margin: 10px auto; width: 250px; overflow: visible; padding-top: 5px; =
background-color: rgb(0, 121, 175);
}
.LoginScreen .center-small #ZLoginErrorPanel {
	overflow: auto; max-height: 40px;
}
.center-small h1 {
	margin: 10px 20px 20px;
}
.center-small .decor1 {
	display: none;
}
.center-small .form {
	margin: 0px 10px; text-align: left; color: white; border-collapse: =
collapse;
}
.center-small .form td:first-child label {
	margin-right: 5px;
}
.center-small .form input[type=3D'text'] {
	border: 1px solid rgb(0, 135, 195); border-image: none; width: 155px;
}
.center-small .form input[type=3D'password'] {
	border: 1px solid rgb(0, 135, 195); border-image: none; width: 155px;
}
.center-small .form select {
	width: 140px;
}
.center-small #ZloginWhatsThisAnchor {
	display: none;
}
.center-small .offline {
	display: none;
}
.Footer-small {
	width: 100%; text-align: center; position: relative;
}
.Footer-small .copyright {
	font-size: 9px !important;
}
.Footer-small #ZLoginNotice {
	display: none;
}
html {
	font-size: 12px;
}
img {
	border: currentColor; border-image: none; vertical-align: middle;
}
legend {
	color: rgb(153, 153, 153);
}
SUBMIT {
	border-radius: 3px; border: 1px solid rgb(153, 153, 153); border-image: =
none; height: 100%; text-align: center; color: rgb(51, 51, 51); =
font-size: 1rem;
}
.tbButton {
	border-radius: 3px; border: 1px solid rgb(153, 153, 153); border-image: =
none; height: 100%; text-align: center; color: rgb(51, 51, 51); =
font-size: 1rem;
}
.searchButton {
	border-radius: 3px; border: 1px solid rgb(153, 153, 153); border-image: =
none; height: 100%; text-align: center; color: rgb(51, 51, 51); =
font-size: 1rem;
}
.ZhAppLinks {
	vertical-align: middle; white-space: nowrap;
}
.ZhAppLinks a:link {
	color: darkblue; font-weight: bold; text-decoration: none;
}
.ZhAppLinks a:visited {
	color: darkblue; font-weight: bold; text-decoration: none;
}
.ZhAppSwitchLink {
	white-space: nowrap;
}
.ZhAppSwitchLink a {
	font-size: 10px; font-weight: normal;
}
.ZhAppSwitchLink a:link {
	font-size: 10px; font-weight: normal;
}
.ZhAppSwitchLink a:visited {
	font-size: 10px; font-weight: normal;
}
.Tabs {
	margin-right: 10px;
}
.Tab {
	padding: 2px;
}
.Tab span {
	padding-right: 5px; padding-left: 5px; vertical-align: middle;
}
.Tab .icon {
	padding-right: 0px;
}
.Tab img {
	left: 4px; top: -1px; position: relative;
}
.TabFiller {
	text-align: center; overflow: hidden; border-left-width: 0px; =
white-space: nowrap; background-color: rgb(255, 255, 255);
}
.TabSpacer {
	padding: 2px; border: currentColor; border-image: none; width: 2px;
}
.TabNormal {
	text-align: center; color: white; overflow: hidden; white-space: =
nowrap;
}
.TabSelected {
	text-align: center; color: rgb(51, 51, 51); overflow: hidden; =
border-bottom-width: 0px; white-space: nowrap; background-color: =
rgb(255, 255, 255);
}
.Tabs a:link {
	color: rgb(51, 51, 51); text-decoration: none;
}
.Tabs a:visited {
	color: rgb(51, 51, 51); text-decoration: none;
}
.Overview {
	padding: 0px 6px; width: 170px;
}
.Tree {
	border-radius: 3px; border: currentColor; border-image: none; height: =
auto; background-color: rgb(255, 255, 255);
}
.Tree td {
	margin: 0.25rem 0px; padding: 2px 0px 2px 10px; height: 1.6rem; color: =
rgb(51, 51, 51); cursor: pointer; background-color: transparent;
}
.Tree th {
	border-bottom-color: rgb(242, 242, 242); border-bottom-width: 1px; =
border-bottom-style: solid; background-color: rgb(229, 229, 229);
}
.Tree .Header {
	padding: 1px 5px 0px 0px; height: 18px; text-align: left; font-weight: =
bold;
}
.Tree a:link {
	color: rgb(51, 51, 51); text-decoration: none;
}
.Tree a:visited {
	color: rgb(51, 51, 51); text-decoration: none;
}
.ZhTISelected {
	background-color: rgb(178, 219, 237) !important;
}
.List {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
td.List {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
.ZhRow td {
	border-width: 1px 0px; border-style: solid; border-color: rgb(255, 255, =
255); height: 1.8rem; padding-right: 6px; cursor: pointer; =
background-color: rgb(255, 255, 255);
}
.ZhRowOdd td {
	border-width: 1px 0px; border-style: solid; border-color: rgb(255, 255, =
255); height: 1.8rem; padding-right: 6px; cursor: pointer; =
background-color: rgb(255, 255, 255);
}
.List th {
	text-align: left; overflow: hidden; padding-top: 1px; padding-left: =
3px; border-bottom-color: rgb(242, 242, 242); border-bottom-width: 1px; =
border-bottom-style: solid; white-space: nowrap; cursor: pointer; =
background-color: rgb(229, 229, 229);
}
.List a:link {
	color: rgb(51, 51, 51); text-decoration: none;
}
.List a:visited {
	color: rgb(51, 51, 51); text-decoration: none;
}
.List th a:link {
	text-decoration: underline;
}
.List th a:visited {
	text-decoration: underline;
}
.List .Img {
	width: 20px; padding-right: 0px;
}
.List .ImgNarrow {
	width: 12px; padding-right: 0px;
}
.List .CB {
	width: 20px; padding-right: 0px;
}
.List .Radio {
	width: 20px; text-align: center; padding-right: 0px;
}
.RuleList td {
	padding: 8px;
}
.ZhDisplayRuleContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZhEditRuleContent {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
.RuleList {
	background-color: rgb(255, 255, 255);
}
.RuleHint {
	color: rgb(153, 153, 153); font-size: 0.82rem;
}
.RuleList a:link {
	color: rgb(51, 51, 51); text-decoration: underline;
}
.RuleList a:visited {
	color: rgb(51, 51, 51); text-decoration: underline;
}
.MsgStatusImg {
	width: 20px; padding-right: 6px;
}
a:visited {
	color: rgb(0, 90, 149);
}
.ConvSummary a {
	color: rgb(51, 51, 51); text-decoration: none;
}
.TopContent {
	padding: 0px 15px 0px 0px;
}
.Tree .ZhTreeEdit a:link {
	color: rgb(51, 51, 51); text-decoration: underline;
}
.Tree .ZhTreeEdit a:visited {
	color: rgb(51, 51, 51); text-decoration: underline;
}
.ZhTreeEdit {
	color: rgb(204, 204, 204); padding-right: 4px; font-size: 1rem; =
font-weight: normal; text-decoration: underline;
}
.ZhAppContent2 {
	background-color: rgb(255, 255, 255);
}
.Conv2Tb {
	background-color: transparent;
}
.ZhAppContent {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
.ZhAppColContent {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
.ZhAppViewContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.SearchBar {
	padding: 5px;
}
.TbTop input {
	margin: 0px; padding: 0px; border: currentColor; border-image: none; =
text-align: left; color: rgb(51, 51, 51); font-size: 1rem; cursor: =
pointer; background-color: transparent;
}
.TbBottom input {
	margin: 0px; padding: 0px; border: currentColor; border-image: none; =
text-align: left; color: rgb(51, 51, 51); font-size: 1rem; cursor: =
pointer; background-color: transparent;
}
.TbTop {
	height: 2.4rem; padding-top: 0.2rem; background-color: transparent;
}
.TbBottom {
	height: 2.4rem; padding-top: 0.2rem; margin-bottom: 5px; =
background-color: transparent;
}
.Tb a:link {
	color: rgb(51, 51, 51); font-weight: normal; text-decoration: none;
}
.Tb a:visited {
	color: rgb(51, 51, 51); font-weight: normal; text-decoration: none;
}
.Tb2 {
	background-color: transparent;
}
.TbBt {
	padding: 2px;
}
.TbBt a {
	padding: 0px 5px;
}
.TbBt#caltb a:link {
	color: rgb(51, 51, 51); text-decoration: none;
}
.TbBt#caltb a:visited {
	color: rgb(51, 51, 51); text-decoration: none;
}
.Tb span {
	vertical-align: middle;
}
.Tags span {
	padding-right: 5px; vertical-align: middle;
}
.Unread {
	font-weight: bold;
}
.RowSelected td {
	background-color: rgb(153, 207, 231) !important;
}
.RowMatched td {
	background-color: yellow;
}
.ZhConvExpanded td {
	background-color: rgb(238, 238, 255);
}
.Folder {
	padding-bottom: 2px;
}
.Folder span {
	padding-left: 3px; vertical-align: middle;
}
.Paging {
	padding: 0px 5px;
}
.Compose {
	border: 1px solid rgb(178, 178, 178); border-image: none;
}
.Compose .tobutton {
	width: 50px;
}
.ConvSummary {
	padding: 5px 0px; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; background-color: =
rgb(229, 229, 229);
}
.ConvSummary2 {
	padding: 5px 0px 5px 5px; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; background-color: =
transparent;
}
.ConvSummary span {
	vertical-align: middle;
}
.CompOrigAtt span {
	vertical-align: middle;
}
.MsgHdr {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; padding: 3px; background-color: rgb(229, 229, 229);
}
.MsgHdr table {
	padding: 5px 0px; background-color: rgb(229, 229, 229);
}
.MsgOps {
	background-color: transparent;
}
.MsgHdrName {
	padding: 3px 0px; width: 10%; text-align: right; font-weight: bold; =
vertical-align: top; white-space: nowrap;
}
.MsgHdrValue {
	padding: 3px; overflow: hidden; vertical-align: top;
}
.MsgHdrValue img {
	vertical-align: top;
}
.MsgHdrSub {
	font-size: 1.36rem; font-weight: bold;
}
.MsgHdrSender {
	padding: 3px; overflow: hidden; font-size: 1.18rem; font-weight: bold; =
vertical-align: top;
}
.MsgHdrSent {
	padding: 3px; overflow: hidden; vertical-align: top; white-space: =
nowrap;
}
.MsgHdrAttAnchor {
	padding: 3px; overflow: hidden; vertical-align: top; white-space: =
nowrap;
}
.MsgHdrAttAnchor a {
	color: rgb(51, 51, 51); text-decoration: none;
}
.CompOrigAtt a {
	color: rgb(51, 51, 51); text-decoration: none;
}
.MsgBody {
	border-width: 1px; border-style: solid; border-color: rgb(127, 127, =
127) rgb(204, 204, 204) rgb(204, 204, 204) rgb(127, 127, 127); margin: =
0px; padding: 10px; overflow: auto; font-family: monospace; font-size: =
13px; background-color: rgb(255, 255, 255);
}
.MsgBody .zUrl {
	font-family: monospace; font-size: 1.18rem;
}
.MsgBody-html {
	padding: 10px;
}
.MsgBody-html pre {
	white-space: pre-wrap; -ms-word-wrap: break-word !important; text-wrap: =
suppress;
}
.MsgBody-html pre * {
	white-space: pre-wrap; -ms-word-wrap: break-word !important; text-wrap: =
suppress;
}
.MsgBody-html body {
	white-space: pre-wrap; -ms-word-wrap: break-word !important; text-wrap: =
suppress;
}
.MsgBody-html Section1 {
	white-space: pre-wrap; -ms-word-wrap: break-word !important; text-wrap: =
suppress;
}
.MsgBody-plain-tab {
	display: inline; -ms-word-wrap: break-word !important;
}
.MsgCompose {
	width: 99%; font-family: monospace; font-size: 1.18rem;
}
.Fragment {
	color: gray; font-weight: normal;
}
.contactLabel {
	width: 1%; text-align: right; color: rgb(51, 51, 51); overflow: hidden; =
white-space: nowrap;
}
.contactImage {
	max-height: 48px; max-width: 48px;
}
.IEcontactImage {
	height: 48px;
}
.editContactLabel {
	width: 18em; text-align: right; color: rgb(51, 51, 51); overflow: =
hidden; white-space: nowrap;
}
.editContactGroupLabel {
	width: 18em; text-align: left; color: rgb(51, 51, 51); overflow: =
hidden; white-space: nowrap;
}
.editContactGroupHintLabel {
	text-align: right; color: gray; overflow: hidden; white-space: nowrap;
}
.optionSectionLabel {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 15px; font-weight: =
bold; white-space: nowrap;
}
.sectionLabel {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 15px; font-weight: =
bold; border-bottom-color: rgb(133, 151, 167); border-bottom-width: 1px; =
border-bottom-style: solid; white-space: nowrap;
}
.companyName {
	font-size: 15px; font-weight: bold;
}
.companyName div {
	font-size: 15px; font-weight: bold;
}
.companyFolder {
	width: 1%; overflow: hidden; font-size: 13px; white-space: nowrap;
}
.contactHeaderRow {
	height: 36px; background-color: rgb(233, 233, 233);
}
.contactTagsRow {
	background-color: rgb(233, 233, 233);
}
.contactHeader {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 1.64rem; =
font-weight: bold;
}
.ZhFolderHeader {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 1.64rem; =
font-weight: bold;
}
.ZhFolderHeader {
	white-space: nowrap;
}
.ZhSchedularTbl {
=09
}
.ZhSchedularTbl .allAttShDiv {
	border-bottom-color: gray !important; border-bottom-width: 1px =
!important; border-bottom-style: solid !important;
}
.ZhSchedularTbl .attName {
	padding: 0px 10px; border: 1px solid rgb(205, 205, 205); border-image: =
none; white-space: nowrap;
}
.ZhSchedularTbl .hourLblDiv {
	width: 22px; height: 22px;
}
.ZhSchedularTbl .gridDiv {
	width: 11px; height: 22px;
}
.ZhSchedularTbl .halfHour {
	border-width: 1px 1px 1px 0px; border-style: solid solid solid none; =
border-color: silver silver silver currentColor; border-image: none; =
width: 11px; height: 22px;
}
.ZhSchedularTbl .anHour {
	border-right-color: rgb(170, 170, 170); border-right-width: 1px; =
border-right-style: solid;
}
.ZhSchedularTbl .firstDiv {
	border-left-color: silver; border-left-width: 1px; border-left-style: =
solid;
}
.ZhSchedularTbl .start {
	border-left-color: green; border-left-width: 3px; border-left-style: =
solid;
}
.ZhSchedularTbl .end {
	border-left-color: darkred; border-left-width: 3px; border-left-style: =
solid;
}
.ZmScheduler-F {
	background-color: rgb(255, 255, 255);
}
.ZmScheduler-B {
	background-color: rgb(74, 166, 241);
}
.ZmScheduler-T {
	background-color: rgb(185, 237, 237);
}
.ZmScheduler-O {
	background-color: rgb(136, 84, 171);
}
.ZmScheduler-U {
	background-color: rgb(255, 245, 204);
}
.keyDiv {
	border: 2px inset rgb(119, 115, 106); border-image: none; width: 13px; =
height: 13px;
}
.searchField {
	padding: 0px 3px; width: 99%; height: auto; cursor: text; box-sizing: =
border-box;
}
.YsearchField {
	padding: 0px 3px; width: 97%; height: auto; cursor: text; box-sizing: =
border-box;
}
.SearchFieldWidth {
	width: 100%; padding-right: 5px;
}
.NoResults {
	padding: 20px 0px; text-align: center; font-weight: bold;
}
.InitialContactSearch {
	padding: 20px 0px; text-align: center; color: gray;
}
.ImgDisabled {
	opacity: 0.4;
}
.Displayimages {
	padding: 7px; font-size: 10pt; border-bottom-color: rgb(119, 119, 119); =
border-bottom-width: 1px; border-bottom-style: solid; cursor: pointer; =
background-color: rgb(255, 255, 204);
}
.AttachmentImage {
	width: 120px; height: 80px;
}
.ShowAllImageName {
	font-size: 16px; font-weight: bold;
}
.Status {
	padding: 2px 0px;
}
.StatusEmpty {
	padding: 8px 0px 6px;
}
.Status div {
	padding: 2px 25px 4px; font-weight: bold;
}
.StatusInfo {
	border-color: darkgreen; border-radius: 3px; margin-top: 4px; opacity: =
0.95; box-shadow: 1px 1px 2px #006592; background-color: rgb(255, 255, =
204);
}
.StatusWarning {
	border-color: gold; border-radius: 3px; margin-top: 4px; opacity: 0.95; =
box-shadow: 1px 1px 2px #006592; background-color: rgb(255, 255, 204);
}
.StatusCritical {
	border-color: red; border-radius: 3px; margin-top: 4px; opacity: 0.95; =
box-shadow: 1px 1px 2px #006592; background-color: rgb(255, 255, 204);
}
.VeilOverlay {
	width: 100%; height: 100%; position: absolute; opacity: 0.5; =
background-color: white;
}
.shortcutIntro {
	padding: 7px; border-bottom-color: rgb(119, 119, 119); =
border-bottom-width: 1px; border-bottom-style: solid; background-color: =
rgb(255, 255, 204);
}
.shortcutList {
	width: 100%; margin-bottom: 10px; border-collapse: collapse;
}
.shortcutListHeader {
	border: 1px solid rgb(153, 153, 153); border-image: none;
}
.shortcutKeys {
	padding: 6px 0px; border: 1px solid rgb(242, 242, 242); border-image: =
none; text-align: right; color: rgb(153, 153, 153); font-weight: bold; =
vertical-align: top;
}
.shortcutDescription {
	padding: 5px; border: 1px solid rgb(242, 242, 242); border-image: none; =
width: auto;
}
.shortcutKeyCombo {
	padding: 5px; white-space: nowrap;
}
.shortcutKey {
	margin: 1px; padding: 2px 4px; border: 1px solid rgb(242, 242, 242); =
border-image: none; color: rgb(51, 51, 51); line-height: 22px; =
font-weight: bold;
}
.shortcutTable {
	border: 1px solid rgb(153, 153, 153); border-image: none; =
margin-bottom: 10px; border-collapse: collapse; table-layout: fixed;
}
.shortcutTable th {
	text-align: left; color: rgb(102, 102, 102); padding-left: 5px; =
font-size: 11px; font-weight: bold; border-bottom-color: rgb(153, 153, =
153); border-bottom-width: 1px; border-bottom-style: solid;
}
.SubHead {
	font-size: 12px; font-weight: bold;
}
.PanelHead {
	font-size: 12px; font-weight: bold;
}
.PanelHead {
	background-color: rgb(186, 176, 154);
}
.ZhSubTabs {
	padding-top: 10px;
}
.ZhEditFolderContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZhEditAddressBookContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZhEditCalendarContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZhEditTagContent {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; background-color: rgb(255, 255, 255);
}
.ZhCalType {
	color: rgb(153, 153, 153);
}
.ZhABType {
	color: rgb(153, 153, 153);
}
.ZhFolderType {
	color: rgb(153, 153, 153);
}
.ZhCalMonthHeaderRow {
	background-color: rgb(229, 229, 229);
}
.ZhCalMonthTable {
	padding: 0px; border-collapse: collapse; border-spacing: 0; =
background-color: rgb(255, 255, 255);
}
.ZhCalMonthHeaderMonth {
	text-align: center; color: rgb(51, 51, 51); overflow: hidden; =
font-size: 1.64rem; font-weight: bold; white-space: nowrap; =
background-color: rgb(229, 229, 229);
}
.ZhCalMonthHeaderCellsText {
	padding: 2px; text-align: center; color: rgb(51, 51, 51); overflow: =
hidden; font-size: 1.18rem; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; white-space: =
nowrap; background-color: rgb(229, 229, 229);
}
.ZhCalMonthDay {
	border: 1px solid rgb(242, 242, 242); border-image: none; overflow: =
hidden; vertical-align: top; white-space: nowrap; cursor: pointer;
}
.ZhCalMonthDaySelected {
	border: 1px solid rgb(242, 242, 242); border-image: none; overflow: =
hidden; vertical-align: top; white-space: nowrap; cursor: pointer;
}
.ZhCalMonthDaySelected {
	background-color: rgb(153, 207, 231) !important;
}
.ZhCalDayHeader {
	text-align: center; color: rgb(51, 51, 51); line-height: 2em; overflow: =
hidden; font-size: 1.18rem; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; white-space: =
nowrap; background-color: rgb(229, 229, 229);
}
.ZhCalDayHeaderToday {
	text-align: center; color: rgb(51, 51, 51); line-height: 2em; overflow: =
hidden; font-size: 1.18rem; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; white-space: =
nowrap; background-color: rgb(229, 229, 229);
}
.ZhCalPager {
	text-align: center; color: rgb(51, 51, 51); overflow: hidden; =
font-size: 1.18rem; white-space: nowrap;
}
.ZhCalMonthHeaderRow a:link {
	color: rgb(51, 51, 51);
}
.ZhCalMonthHeaderRow a:visited {
	color: rgb(51, 51, 51);
}
.ZhCalDayHeaderToday {
	color: rgb(0, 101, 146);
}
.ZhCalDayHeaderToday a:link {
	color: rgb(0, 101, 146);
}
.ZhCalDayHeaderToday a:visited {
	color: rgb(0, 101, 146);
}
.ZhCalDOM {
	text-align: right; overflow: hidden; padding-right: 3px; padding-left: =
3px; font-size: 1.18rem; white-space: nowrap;
}
.ZhCalDOMT {
	text-align: right; overflow: hidden; padding-right: 3px; padding-left: =
3px; font-size: 1.18rem; white-space: nowrap;
}
.ZhCalDOMO {
	text-align: right; overflow: hidden; padding-right: 3px; padding-left: =
3px; font-size: 1.18rem; white-space: nowrap;
}
.ZhCalDOMOT {
	text-align: right; overflow: hidden; padding-right: 3px; padding-left: =
3px; font-size: 1.18rem; white-space: nowrap;
}
.ZhCalMonthTable a:link {
	color: inherit; text-decoration: none;
}
.ZhCalMonthTable a:visited {
	color: inherit; text-decoration: none;
}
.ZhCalMiniContainer a:link {
	color: inherit; text-decoration: none;
}
.ZhCalMiniContainer a:visited {
	color: inherit; text-decoration: none;
}
.ZhCalMonthHeaderRow a:link {
	color: inherit; text-decoration: none;
}
.ZhCalMonthHeaderRow a:visited {
	color: inherit; text-decoration: none;
}
.ZhCalDOM {
	color: rgb(51, 51, 51);
}
.ZhCalDOM a:link {
	color: rgb(51, 51, 51);
}
.ZhCalDOM a:visited {
	color: rgb(51, 51, 51);
}
.ZhCalDOMT {
	color: rgb(0, 101, 146);
}
.ZhCalDOMT a:link {
	color: rgb(0, 101, 146);
}
.ZhCalDOMT:visited {
	color: rgb(0, 101, 146);
}
.ZhCalDOMO {
	color: rgb(153, 153, 153);
}
.ZhCalDOMO a:link {
	color: rgb(153, 153, 153);
}
.ZhCalDOMO a:visited {
	color: rgb(153, 153, 153);
}
.ZhCalDOMOT {
	color: rgb(0, 101, 146);
}
.ZhCalDOMOT a:link {
	color: rgb(0, 101, 146);
}
.ZhCalDOMOT a:visited {
	color: rgb(0, 101, 146);
}
.ZhCalMiniContainer {
	border-width: 1px; border-style: solid; border-color: rgb(204, 204, =
204) rgb(153, 153, 153) rgb(153, 153, 153) rgb(204, 204, 204); margin: =
0px; height: 142px; padding-bottom: 5px; background-color: rgb(255, 255, =
255);
}
.ZhCalMDS {
	background-color: rgb(153, 207, 231) !important;
}
.ZhCalMDOM {
	padding: 2px; border: 0px currentColor; border-image: none; text-align: =
center; overflow: hidden; font-size: 0.9rem; white-space: nowrap;
}
.ZhCalMDOMT {
	padding: 2px; border: 0px currentColor; border-image: none; text-align: =
center; overflow: hidden; font-size: 0.9rem; white-space: nowrap;
}
.ZhCalMDOMO {
	padding: 2px; border: 0px currentColor; border-image: none; text-align: =
center; overflow: hidden; font-size: 0.9rem; white-space: nowrap;
}
.ZhCalMDOMOT {
	padding: 2px; border: 0px currentColor; border-image: none; text-align: =
center; overflow: hidden; font-size: 0.9rem; white-space: nowrap;
}
.ZhCalMDOMT {
	padding: 1px; border: 1px solid darkred; border-image: none;
}
.ZhCalMDHA {
	text-align: center; font-weight: bold;
}
.ZhCalMDOMOT {
	padding: 1px; border: 1px solid darkred; border-image: none;
}
.ZhCalMDOMOT a:link {
	padding: 1px; border: 1px solid darkred; border-image: none;
}
.ZhCalMDOMOT a:visited {
	padding: 1px; border: 1px solid darkred; border-image: none;
}
.ZhCalMDOM a:link {
	color: rgb(51, 51, 51);
}
.ZhCalMDOM a:visited {
	color: rgb(51, 51, 51);
}
ZhCalMDOMT a:link {
	color: rgb(51, 51, 51);
}
.ZhCalMDOMT a:visited {
	color: rgb(51, 51, 51);
}
.ZhCalMiniTitlebar {
	height: 2.4rem; padding-top: 0.2rem; border-right-width: 0px; =
background-color: transparent;
}
.ZhCalMiniTitleCell {
	width: auto; color: rgb(51, 51, 51); font-weight: normal; white-space: =
nowrap; cursor: pointer;
}
.ZhCalMiniTitleCell a:link {
	color: rgb(51, 51, 51);
}
.ZhCalMiniTitleCell a:visited {
	color: rgb(51, 51, 51);
}
.ZhCalMiniDow {
	text-align: center; color: rgb(153, 153, 153); font-weight: normal;
}
.ZhCalMonthAppt {
	padding: 0px 5px;
}
.ZhApptSel {
	border: 1px dashed black; border-image: none;
}
.ZhCalMonthAllDayAppt {
	border-width: 1px 2px; border-style: solid; border-color: rgb(51, 51, =
51); border-image: none;
}
.ZhCalMonthAllDayApptNew {
	border-width: 1px 2px; border-style: solid; border-color: rgb(51, 51, =
51); border-image: none;
}
.ZhCalDayAllDayAppt {
	border-width: 1px 2px; border-style: solid; border-color: rgb(51, 51, =
51); border-image: none;
}
.ZhCalDayAllDayApptNew {
	border-width: 1px 2px; border-style: solid; border-color: rgb(51, 51, =
51); border-image: none;
}
.ZhCalMonthAllDayAppt {
	padding: 0px 5px;
}
.ZhCalMonthAllDayApptNew {
	padding: 0px 5px;
}
.ZhCalDayAllDayAppt {
	cursor: pointer;
}
.ZhCalDayAllDayApptNew {
	cursor: pointer;
}
.ZhCalDayAppt {
	border-width: 1px; border-style: solid; border-color: rgb(170, 170, =
170) rgb(51, 51, 51) rgb(51, 51, 51) rgb(170, 170, 170); border-image: =
none; cursor: pointer;
}
.ZhCalDayApptNew {
	border-width: 1px; border-style: solid; border-color: rgb(170, 170, =
170) rgb(51, 51, 51) rgb(51, 51, 51) rgb(170, 170, 170); border-image: =
none; cursor: pointer;
}
.ZhCalDayApptEnd {
	color: rgb(153, 153, 153);
}
.ZhCalTimeZone {
	color: rgb(153, 153, 153);
}
.ZhCalDayHour {
	padding: 2px; text-align: center; color: rgb(51, 51, 51); overflow: =
hidden; border-bottom-color: rgb(242, 242, 242); border-bottom-width: =
1px; border-bottom-style: solid; white-space: nowrap; background-color: =
rgb(255, 255, 255);
}
.ZhCalDayHS {
	border-right-color: rgb(242, 242, 242); border-right-width: 1px; =
border-right-style: solid;
}
.ZhCalAllDayDS {
	border-left-color: rgb(242, 242, 242); border-left-width: 1px; =
border-left-style: solid;
}
.ZhCalDayHSB {
	border-right-color: rgb(242, 242, 242); border-bottom-color: rgb(242, =
242, 242); border-right-width: 1px; border-bottom-width: 1px; =
border-right-style: solid; border-bottom-style: solid;
}
.ZhCalDayHHB {
	border-bottom-color: rgb(244, 244, 244); border-bottom-width: 1px; =
border-bottom-style: dashed;
}
.ZhCalDayHB {
	border-bottom-color: rgb(244, 244, 244); border-bottom-width: 1px; =
border-bottom-style: solid;
}
.ZhCalDayADB {
	border-bottom-color: rgb(244, 244, 244); border-bottom-width: 4px; =
border-bottom-style: solid;
}
.ZhCalDaySEP {
	border-left-color: rgb(242, 242, 242); border-left-width: 1px; =
border-left-style: solid;
}
.ZhCalDayADHS {
	border-right-color: rgb(242, 242, 242); border-bottom-color: rgb(244, =
244, 244); border-right-width: 1px; border-bottom-width: 4px; =
border-right-style: solid; border-bottom-style: solid;
}
.ZhCalDayGrid {
	background-color: rgb(255, 255, 255);
}
.ZhCalDayUnionSEP {
	border-right-color: rgb(242, 242, 242); border-left-color: rgb(242, =
242, 242); border-right-width: 1px; border-left-width: 1px; =
border-right-style: solid; border-left-style: solid;
}
.ZhCalSchedUnion {
	width: 25px; text-align: center; color: rgb(51, 51, 51); =
background-color: rgb(217, 0, 0);
}
.apptHeaderRow {
	height: 28px;
}
.editViewLabel {
	width: 1%; text-align: right; color: rgb(51, 51, 51); white-space: =
nowrap;
}
.apptHeader {
	color: rgb(51, 51, 51); overflow: hidden; font-size: 18px; font-weight: =
bold;
}
.ZhCalDayGrid a:link {
	color: inherit; text-decoration: none;
}
.ZhCalDayGrid a:visited {
	color: inherit; text-decoration: none;
}
.ZhCalMonthTable a:link {
	color: inherit; text-decoration: none;
}
.ZhCalMonthTable a:visited {
	color: inherit; text-decoration: none;
}
.ZhBottomSep {
	border-bottom-color: rgb(242, 242, 242); border-bottom-width: 1px; =
border-bottom-style: solid;
}
.ZhApptRecurrInfo {
	padding: 7px 0px; font-size: 10pt; border-bottom-color: rgb(119, 119, =
119); border-bottom-width: 1px; border-bottom-style: solid; cursor: =
pointer; background-color: rgb(255, 255, 204);
}
.ZhCallListPrintTable th {
	font-weight: bold;
}
.ZhCallListPrintTable td {
	text-align: left; border-bottom-color: currentColor; =
border-bottom-width: 1px; border-bottom-style: solid;
}
.ZhCallListPrintTable th {
	text-align: left; border-bottom-color: currentColor; =
border-bottom-width: 1px; border-bottom-style: solid;
}
.ZhZimbraTitle {
	font-size: 1.64rem; font-weight: bold;
}
.ZhOptVoice .List td {
	padding-left: 20px;
}
.ZhOptVoice .List th {
	padding-left: 20px;
}
.ZhOptVoiceCBCell {
=09
}
.ZhOptVoiceRemove {
	margin: 0px; padding: 0px; border: currentColor; border-image: none; =
color: rgb(51, 51, 51); font-size: 1rem; text-decoration: underline; =
cursor: pointer; background-color: transparent;
}
.Selection {
	background-color: rgb(173, 214, 214);
}
.SelectionDark {
	background-color: rgb(145, 200, 200);
}
.SelectionLight {
	background-color: rgb(200, 228, 228);
}
.SelectionBg {
	background-color: rgb(227, 241, 241);
}
.Red {
	background-color: rgb(227, 64, 64);
}
.RedDark {
	background-color: rgb(217, 0, 0);
}
.RedLight {
	background-color: rgb(236, 128, 128);
}
.RedBg {
	background-color: rgb(245, 191, 191);
}
.RedC {
	color: rgb(227, 64, 64);
}
.RedDarkC {
	color: rgb(217, 0, 0);
}
.RedLightC {
	color: rgb(236, 128, 128);
}
.RedBgC {
	color: rgb(245, 191, 191);
}
.Pink {
	background-color: rgb(244, 146, 191);
}
.PinkDark {
	background-color: rgb(240, 110, 169);
}
.PinkLight {
	background-color: rgb(248, 183, 212);
}
.PinkBg {
	background-color: rgb(251, 219, 233);
}
.PinkC {
	color: rgb(244, 146, 191);
}
.PinkDarkC {
	color: rgb(240, 110, 169);
}
.PinkLightC {
	color: rgb(248, 183, 212);
}
.PinkBgC {
	color: rgb(251, 219, 233);
}
.Orange {
	background-color: rgb(255, 153, 64);
}
.OrangeDark {
	background-color: rgb(255, 119, 0);
}
.OrangeLight {
	background-color: rgb(255, 187, 128);
}
.OrangeBg {
	background-color: rgb(255, 221, 191);
}
.OrangeC {
	color: rgb(255, 153, 64);
}
.OrangeDarkC {
	color: rgb(255, 119, 0);
}
.OrangeLightC {
	color: rgb(255, 187, 128);
}
.OrangeBgC {
	color: rgb(255, 221, 191);
}
.Yellow {
	background-color: rgb(255, 230, 64);
}
.YellowDark {
	background-color: rgb(255, 221, 0);
}
.YellowLight {
	background-color: rgb(255, 238, 128);
}
.YellowBg {
	background-color: rgb(255, 246, 191);
}
.YellowC {
	color: rgb(255, 230, 64);
}
.YellowDarkC {
	color: rgb(255, 221, 0);
}
.YellowLightC {
	color: rgb(255, 238, 128);
}
.YellowBgC {
	color: rgb(255, 246, 191);
}
.Green {
	background-color: rgb(64, 160, 95);
}
.GreenDark {
	background-color: rgb(0, 128, 42);
}
.GreenLight {
	background-color: rgb(128, 192, 149);
}
.GreenBg {
	background-color: rgb(191, 223, 202);
}
.GreenC {
	color: rgb(64, 160, 95);
}
.GreenDarkC {
	color: rgb(0, 128, 42);
}
.GreenLightC {
	color: rgb(128, 192, 149);
}
.GreenBgC {
	color: rgb(191, 223, 202);
}
.Cyan {
	background-color: rgb(64, 217, 217);
}
.CyanDark {
	background-color: rgb(0, 204, 204);
}
.CyanLight {
	background-color: rgb(128, 230, 230);
}
.CyanBg {
	background-color: rgb(191, 242, 242);
}
.CyanC {
	color: rgb(64, 217, 217);
}
.CyanDarkC {
	color: rgb(0, 204, 204);
}
.CyanLightC {
	color: rgb(128, 230, 230);
}
.CyanBgC {
	color: rgb(191, 242, 242);
}
.Blue {
	background-color: rgb(64, 115, 217);
}
.BlueDark {
	background-color: rgb(0, 68, 204);
}
.BlueLight {
	background-color: rgb(128, 162, 230);
}
.BlueBg {
	background-color: rgb(191, 208, 242);
}
.BlueC {
	color: rgb(64, 115, 217);
}
.BlueDarkC {
	color: rgb(0, 68, 204);
}
.BlueLightC {
	color: rgb(128, 162, 230);
}
.BlueBgC {
	color: rgb(191, 208, 242);
}
.Purple {
	background-color: rgb(121, 64, 160);
}
.PurpleDark {
	background-color: rgb(76, 0, 128);
}
.PurpleLight {
	background-color: rgb(166, 128, 192);
}
.PurpleBg {
	background-color: rgb(210, 191, 223);
}
.PurpleC {
	color: rgb(121, 64, 160);
}
.PurpleDarkC {
	color: rgb(76, 0, 128);
}
.PurpleLightC {
	color: rgb(166, 128, 192);
}
.PurpleBgC {
	color: rgb(210, 191, 223);
}
.Gray {
	background-color: rgb(191, 191, 191);
}
.GrayDark {
	background-color: rgb(169, 169, 169);
}
.GrayLight {
	background-color: rgb(212, 212, 212);
}
.GrayBg {
	background-color: rgb(233, 233, 233);
}
.GrayC {
	color: rgb(191, 191, 191);
}
.GrayDarkC {
	color: rgb(169, 169, 169);
}
.GrayLightC {
	color: rgb(212, 212, 212);
}
.GrayBgC {
	color: rgb(233, 233, 233);
}
.ZhAC {
	position: relative;
}
.ZhACB {
	font-weight: bold;
}
.ZhACCont {
	bottom: 0px; position: absolute;
}
.ZhACCont .yui-ac-content {
	background: rgb(255, 255, 255); border: 1px solid rgb(64, 64, 64); =
border-image: none; overflow: hidden; position: absolute; z-index: 9050;
}
.ZhACCont .yui-ac-shadow {
	background: rgb(160, 160, 160); margin: 0.3em; position: absolute; =
z-index: 9010;
}
.ZhACCont ul {
	list-style: none; margin: 0px; padding: 1px 0px;
}
.ZhACCont li {
	margin: 0px; padding: 0px 1px; white-space: nowrap; cursor: default;
}
.ZhACCont li.yui-ac-highlight {
	background-color: rgb(153, 207, 231) !important;
}
.ZhACCont li.yui-ac-prehighlight {
	background: rgb(255, 255, 204);
}
.ZhACTo {
	z-index: 9050;
}
.ZhACCc {
	z-index: 9040;
}
.ZhACBcc {
	z-index: 9030;
}
.ZOptionsHeader {
	color: white; font-size: 1.36rem; font-weight: bold;
}
.ZHeader {
	font-size: 13px; font-weight: bold;
}
.ZOptionsHint {
	color: rgb(153, 153, 153);
}
.ZOptionsSectionMain {
	padding: 1em; background-color: rgb(255, 255, 255);
}
.ZOptionsLabel {
	width: 150px; text-align: right; line-height: 20px; font-weight: bold; =
vertical-align: middle; white-space: nowrap;
}
.ZOptionsLabelTop {
	width: 150px; text-align: right; line-height: 20px; font-weight: bold; =
vertical-align: middle; white-space: nowrap;
}
.ZOptionsLabelNarrow {
	width: 150px; text-align: right; line-height: 20px; font-weight: bold; =
vertical-align: middle; white-space: nowrap;
}
.ZOptionsTableLabel {
	width: 150px; text-align: right; line-height: 20px; font-weight: bold; =
vertical-align: middle; white-space: nowrap;
}
.ZOptionsLabelTop {
	line-height: 20px; vertical-align: top;
}
.ZOptionsLabelNarrow {
	width: auto;
}
.ZOptionsInfo {
	color: rgb(153, 153, 153);
}
.ZhDateHint {
	color: rgb(153, 153, 153); padding-left: 5px;
}
.ZhHomeVoiceCell {
	padding: 0px;
}
.ZhHomeVoiceIframe {
	width: 100%; height: 240px; background-color: rgb(255, 255, 255);
}
.ZhHomeVoiceBody {
	width: 100%; height: 100%; background-color: rgb(255, 255, 255);
}
.ZhHomeVoiceTable {
	width: 100%; background-color: rgb(255, 255, 255);
}
.ZhHomeVoiceTable .ZhHomeCell {
	padding-left: 15px;
}
.ZhHomeRow {
	height: 40px;
}
.ZhHomeCell {
	padding: 5px; border-bottom-color: rgb(204, 204, 204); =
border-bottom-width: 1px; border-bottom-style: solid;
}
.ZhHomeTextLink {
	color: rgb(0, 0, 0); text-decoration: none;
}
.ZhContainingBox {
	float: left; background-color: rgb(255, 255, 255);
}
.ZhThumbnailItem {
	margin: 8px; width: 100px; height: 120px; vertical-align: middle; =
float: left; cursor: pointer; background-repeat: no-repeat; =
background-color: transparent;
}
.ZhThumbnailItem .ZhThumbnailIcon {
	border: 2px solid rgb(204, 204, 204); border-image: none; width: 96px; =
height: 100px; text-align: center; line-height: 100px; font-size: 1px; =
background-color: transparent;
}
.ZhThumbnailItem .ZhThumbnailName {
	margin: 3px 0px 0px; height: 14px; text-align: center; overflow: =
hidden; font-family: Helvetica,Arial,sans-serif; font-size: 1rem; =
display: block;
}
.ZhThumbnailImg {
	margin: 26px 24px;
}
.yui-skin-sam .yui-toolbar-container .yui-toolbar-subcont {
	padding: 0px 1.5em 0.5em 1em !important; border-bottom-color: rgb(128, =
128, 128); border-bottom-width: 1px; border-bottom-style: solid;
}
.yui-toolbar-group-indentlist {
	width: 125px !important;
}
.yui-toolbar-group-alignment {
	width: 125px !important;
}
input[type=3D'text'] {
	border: 1px solid rgb(191, 191, 191); border-image: none; color: black; =
background-color: white;
}
input[type=3D'password'] {
	border: 1px solid rgb(191, 191, 191); border-image: none; color: black; =
background-color: white;
}
input[disabled] {
	border: 1px solid rgb(229, 229, 229); border-image: none; color: =
rgb(153, 153, 153); background-color: transparent;
}
.ImgPrefsHeader {
	width: auto !important;
}
ruby {
	text-indent: 0px;
}
ruby rt {
	text-indent: 0px;
}
ruby rt {
	font-size: 70%; font-weight: normal;
}
ruby rp {
	font-size: 70%; font-weight: normal;
}
ruby rt {
	margin-right: 0.7em;
}
ruby RB {
	margin-right: 0.7em;
}
body {
	margin: 0px;
}
.skin_layout_row {
	width: 100%; clear: both;
}
.skin_layout_cell {
	height: 100%; margin-bottom: auto; float: left;
}
.skin_layout {
	width: 100%; height: 100%; clear: both; display: block;
}
#skin_outer * {
	box-sizing: border-box;
}
.skin_table {
	border-width: 0px; width: 100%; height: 100%; border-collapse: =
collapse;
}
.skin_table > tbody > tr > td {
	padding: 0px;
}
.skin_table > .skin_table_row > .skin_table_cell {
	padding: 0px;
}
.skin_container {
	width: 100%; height: 100%;
}
.skin_container_ad {
	width: 100%; height: 100%;
}
.skin_td_flex {
	width: 100%;
}
#skin_outer {
	display: none;
}
#skin_tr_search_results_toolbar {
	width: 100%; height: 40px; display: none;
}
#skin_tr_main {
	height: 100%;
}
.skin_outer_ad {
	display: none;
}
#skin_outer {
	height: 100%; background-color: rgb(255, 255, 255);
}
#skin_layout_outer {
	padding: 0px; width: 100%; height: 100%;
}
#skin_outer_td_main {
	width: 100%; height: 100%;
}
#skin_spacing_top_row {
	background: rgb(0, 135, 195); width: 100%;
}
#skin_spacing_top_row .divider {
	margin: auto 10px; height: 60%; border-left-color: transparent; =
border-left-width: 1px; border-left-style: solid;
}
#skin_spacing_top_row > .skin_table {
	border-collapse: separate;
}
#skin_spacing_top_row .DwtLinkButtonDropDownArrowRow {
	background-color: white;
}
#skin_container_logo {
	width: 200px;
}
#skin_container_toast {
	width: 100%; height: 100%;
}
#skin_spacing_search {
	height: 42px;
}
#skin_spacing_people_search {
	height: 42px;
}
#skin_container_search {
	height: 1.7rem;
}
#skin_container_search .ZmSearchToolbar {
	border-radius: 4px; background-color: white;
}
#skin_container_search .ZButton {
	height: auto;
}
#skin_container_search .ZButtonBorder {
	border-radius: 0px; border: 0px currentColor; border-image: none; =
box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: transparent;
}
#skin_container_search .ZLeftIcon div {
	margin: 0px 0px 0px 10px;
}
#skin_container_search .ZWidgetTitle {
	display: none;
}
#skin_spacing_tree_top {
	text-align: center;
}
#skin_container_tree_top {
	border-radius: 3px 3px 0px 0px; border: 1px solid rgb(178, 178, 178); =
border-image: none; height: 30px; background-color: rgb(255, 255, 255);
}
#skin_container_username {
	height: auto; color: white; padding-bottom: 2px; font-weight: bold;
}
#skin_container_quota {
	width: 100%; height: auto;
}
#skin_dropMenu {
	padding: 0px 10px 0px 3px; text-align: center; color: white; font-size: =
14px; vertical-align: middle; cursor: pointer;
}
#skin_dropMenu .DwtLinkButtonDropDownArrowTd {
	padding-left: 0px; border-left-color: currentColor; border-left-width: =
0px; border-left-style: none; opacity: 0.75;
}
#skin_dropMenu .ZHover .DwtLinkButtonDropDownArrowTd {
	opacity: 1;
}
#skin_container_global_buttons {
	display: table-row;
}
#skin_container_global_buttons > div {
	padding-top: 2px; display: table-cell;
}
#skin_container_current_app {
	height: 2.4rem; padding-top: 0.2rem; background-color: transparent;
}
#skin_td_switch_offline {
	padding: 0px 10px; text-align: center; white-space: nowrap;
}
#skin_container_help {
	padding: 0px 10px; text-align: center; white-space: nowrap;
}
#skin_container_logoff {
	padding: 0px 10px; text-align: center; white-space: nowrap;
}
#skin_container_adminlink {
	padding: 0px 10px; text-align: center; white-space: nowrap;
}
#skin_container_help a {
	color: white;
}
#skin_container_logoff a {
	color: white;
}
#skin_spacing_tree {
	height: 100%; padding-bottom: 5px;
}
#skin_container_tree {
	border-radius: 3px; border: currentColor; border-image: none; height: =
100%; background-color: rgb(255, 255, 255);
}
#skin_tr_tree_footer {
	display: none;
}
#skin_container_tree_footer {
	border-radius: 3px; border: currentColor; border-image: none; height: =
14rem; background-color: rgb(255, 255, 255);
}
#skin_container_tree_app_sash {
	padding: 0px 1px; width: 5px; height: 100%;
}
#skin_border_app_chooser {
	border-width: 0px 0px 1px; border-style: solid; border-color: rgb(178, =
178, 178); border-radius: 3px 3px 0px 0px; border-image: none; height: =
2.6rem;
}
#skin_container_app_chooser {
	width: auto; height: auto; margin-top: -1rem; margin-right: 100px; =
position: absolute; z-index: 1;
}
#skin_container_app_chooser > div > table {
	margin-top: 0.8rem;
}
#skin_container_global_buttons .offline {
	margin: 0px 5px 0px 8px;
}
#skin_container_global_buttons .ZToolbarButton {
	border: 0px currentColor; border-image: none; border-collapse: =
separate; box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: transparent;
}
#skin_container_global_buttons .ZToolbarButtonTable {
	border: 0px currentColor; border-image: none; border-collapse: =
separate; box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: transparent;
}
#skin_container_global_buttons .ZToolbarButton {
	margin-left: 3px;
}
#skin_container_global_buttons .ZHover .ZToolbarButtonBorder {
	background-color: rgba(255, 255, 255, 0.2);
}
#skin_container_global_buttons .ZFocused .ZToolbarButtonBorder {
	background-color: rgba(255, 255, 255, 0.2);
}
#skin_container_global_buttons .ZActive .ZToolbarButtonBorder {
	background-color: rgba(255, 255, 255, 0.5);
}
#skin_container_global_buttons .ZSelected .ZToolbarButtonBorder {
	background-color: rgb(255, 255, 255);
}
#skin_spacing_app_top_toolbar {
	height: 3rem;
}
#skin_container_app_top_toolbar {
	width: auto; height: 2.4rem; padding-top: 5px; padding-left: 5px; =
background-color: transparent;
}
#skin_container_app_new_button {
	padding: 5px; width: 16rem; height: 2.4rem; background-color: =
transparent;
}
#skin_spacing_app_row {
	padding: 0px 7px; height: 2.5rem; margin-top: -1rem; border-top-color: =
currentColor; border-top-width: 1px; border-top-style: solid; =
border-spacing: 0;
}
#skin_spacing_app_row {
	border-color: rgba(0, 135, 195, 0.2); background-color: rgba(0, 135, =
195, 0.1);
}
#skin_spacing_app_row table {
	border-collapse: separate;
}
#skin_spacing_app_row .ZToolbarButton {
	height: auto;
}
#skin_spacing_app_main {
	height: 100%;
}
#skin_container_top_ad {
	height: 60px;
}
#skin_spacing_sidebar_ad {
	padding: 10px 0px 0px 5px;
}
#skin_container_sidebar_ad {
	width: 165px;
}
#skin_container_tree_top_ad {
	height: 30px;
}
#skin_container_tree_bottom_ad {
	height: 60px;
}
#skin_container_bottom_ad {
	height: 40px;
}
#skin_td_tree {
	width: 16rem; height: 100%;
}
#skin_td_tree_app_sash {
	width: 5px;
}
#skin_td_main {
	width: auto; height: 100%;
}
#skin_td_sidebar_ad {
	width: 165px;
}
#skin_container_splash_screen {
	left: 0px; top: 0px; width: 100%; height: 100%; position: absolute; =
z-index: 90000000; background-color: rgb(255, 255, 255);
}
.LoginScreen {
	left: 0px; top: 0px; width: 100%; height: 100%; overflow: hidden; =
font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif; font-size: 1rem; position: absolute; background-image: =
linear-gradient(rgb(255, 255, 255), rgb(237, 237, 237)); =
background-color: rgb(237, 237, 237);
}
.SplashScreen {
	left: 0px; top: 0px; width: 100%; height: 100%; overflow: hidden; =
font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif; font-size: 1rem; position: absolute; background-image: =
linear-gradient(rgb(255, 255, 255), rgb(237, 237, 237)); =
background-color: rgb(237, 237, 237);
}
.ErrorScreen {
	left: 0px; top: 0px; width: 100%; height: 100%; overflow: hidden; =
font-family: "Helvetica Neue",Helvetica,Arial,"Liberation =
Sans",sans-serif; font-size: 1rem; position: absolute; background-image: =
linear-gradient(rgb(255, 255, 255), rgb(237, 237, 237)); =
background-color: rgb(237, 237, 237);
}
.LoginScreen .center {
	margin-top: -160px; margin-left: -250px;
}
.SplashScreen .center {
	margin-top: -160px; margin-left: -250px;
}
.ErrorScreen .center {
	margin-top: -160px; margin-left: -250px;
}
.LoginScreen .center-small {
	width: 250px; height: 270px; margin-top: -135px; margin-left: -126px;
}
.SplashScreen .center-small {
	width: 250px; height: 270px; margin-top: -135px; margin-left: -126px;
}
.ErrorScreen .center-small {
	width: 250px; height: 270px; margin-top: -135px; margin-left: -126px;
}
.LoginScreen .center {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.LoginScreen .center-small {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.SplashScreen .center {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.SplashScreen .center-small {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.ErrorScreen .center {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.ErrorScreen .center-small {
	left: 50%; top: 40%; overflow: visible; position: absolute; z-index: =
11;
}
.LoginScreen .contentBox {
	padding: 10px 0px 40px; border-radius: 3px; width: 500px; =
background-color: rgb(0, 135, 195);
}
.SplashScreen .contentBox {
	padding: 10px 0px 40px; border-radius: 3px; width: 500px; =
background-color: rgb(0, 135, 195);
}
.ErrorScreen .contentBox {
	padding: 10px 0px 40px; border-radius: 3px; width: 500px; =
background-color: rgb(0, 135, 195);
}
.LoginScreen .contentBox {
	min-height: 265px;
}
.SplashScreen .contentBox {
	min-height: 265px;
}
.LoginScreen .center-small .contentBox {
	width: auto;
}
.SplashScreen .center-small .contentBox {
	width: auto;
}
.ErrorScreen .center-small .contentBox {
	width: auto;
}
.center-small .form .submittd {
	text-align: left;
}
.LoginScreen h1 {
	margin: 0px 30px 30px; overflow: hidden;
}
.SplashScreen h1 {
	margin: 0px 30px 30px; overflow: hidden;
}
#ZLoginAppName {
	color: white; display: none;
}
.LoginScreen .ImgLoginBanner {
	display: block; cursor: pointer;
}
.LoginScreen .ImgAppBanner {
	display: block; cursor: pointer;
}
.SplashScreen .ImgLoginBanner {
	display: block; cursor: pointer;
}
.LoginScreen #ZLoginErrorPanel {
	margin: 10px 10%; padding: 0.5em 1em; border-radius: 8px; border: 0px =
currentColor; border-image: none; left: auto; position: relative; =
background-color: rgb(255, 255, 153);
}
.ErrorScreen .InlineErrorPanel {
	margin: 10px 10%; padding: 0.5em 1em; border-radius: 8px; border: 0px =
currentColor; border-image: none; left: auto; position: relative; =
background-color: rgb(255, 255, 153);
}
.LoginScreen #ZLoginErrorIcon {
	margin: auto 10px auto auto;
}
.ErrorScreen #ZErrorIcon {
	margin: auto 10px auto auto;
}
.LoginScreen .Footer {
	width: 100%; text-align: center; bottom: 0px; position: absolute; =
z-index: 10;
}
.SplashScreen .Footer {
	width: 100%; text-align: center; bottom: 0px; position: absolute; =
z-index: 10;
}
.LoginScreen .Footer-small {
	width: 100%; text-align: center; bottom: 0px; position: absolute; =
z-index: 10;
}
.SplashScreen .Footer-small {
	width: 100%; text-align: center; bottom: 0px; position: absolute; =
z-index: 10;
}
.LoginScreen .copyright {
	color: rgb(101, 101, 101); font-size: 1rem; margin-bottom: 5px; cursor: =
default;
}
.LoginScreen #ZLoginNotice {
	color: rgb(101, 101, 101); font-size: 1rem; margin-bottom: 5px; cursor: =
default;
}
.SplashScreen .copyright {
	color: rgb(101, 101, 101); font-size: 1rem; margin-bottom: 5px; cursor: =
default;
}
.LoginScreen .zLoginField {
	border-radius: 5px;
}
.LoginScreen input[disabled] {
	background-color: white;
}
.LoginScreen .decor1 {
	display: none;
}
.LoginScreen .decor2 {
	display: none;
}
.LoginScreen #ZLoginNotice a {
	color: rgb(101, 101, 101);
}
.SplashScreen .content {
	text-align: center; color: white;
}
.SplashScreen .message {
	color: white; padding-top: 40px; font-size: 1.36rem; font-weight: bold; =
cursor: default;
}
.SplashScreen .switch {
	margin: 70px 100px 30px;
}
.SplashScreen .switch a {
	color: white; font-size: 1rem; text-decoration: underline;
}
.SplashScreen .decor1 {
	display: none;
}
.SplashScreen .decor2 {
	display: none;
}
.ErrorScreen .contentBox {
	padding-bottom: 1em;
}
.ErrorScreen .ZErrorPanel {
	margin-top: 30px;
}
.ErrorScreen h2 {
	margin: 0px;
}
.ErrorScreen a:link {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.ErrorScreen a:visited {
	color: rgb(0, 90, 149); text-decoration: none; cursor: pointer;
}
.ErrorScreen a:hover {
	color: rgb(0, 90, 149); text-decoration: underline;
}
.ErrorScreen a:active {
	color: darkgreen; text-decoration: underline;
}
.ErrorScreen .decor1 {
	display: none;
}
.ErrorScreen .decor2 {
	display: none;
}
.center-small .ImgLoginBanner {
	background-position: left; width: 200px; height: 35px; =
background-image: url("/zimbra/skins/_base/logos/MU_logo_170x35.png"); =
background-repeat: no-repeat;
}
.ImgAppBanner {
	background-position: left; width: 200px; height: 35px; =
background-image: url("/zimbra/skins/_base/logos/MU_logo_170x35.png"); =
background-repeat: no-repeat;
}
.ImgLoginBanner {
	background-position: left bottom; width: 440px; height: 60px; =
background-image: url("/zimbra/skins/_base/logos/MU_logo_300x30.png"); =
background-repeat: no-repeat;
}
.console_inset_app_l .HSashThumb {
	margin-left: -2px;
}
.UserInfoLink {
	width: 100%; text-align: left; white-space: nowrap;
}
.ZmPicker .ZToolbar {
	padding-top: 1px; border-bottom-color: rgb(242, 242, 242); =
border-bottom-width: 1px; border-bottom-style: solid; background-color: =
rgb(229, 229, 229);
}
.BannerTextUser {
	overflow: hidden !important;
}
.BannerTextUserOffline {
	padding: 0px 3px; text-align: left !important;
}
.ZmAppChooser {
	margin: 0px !important;
}
.ZAppTabBorder {
	border-radius: 3px 3px 0px 0px;
}
.ZAppTabBorder .ZLeftIcon {
	padding-left: 10px;
}
.ZAppTabBorder .ZWidgetTitle {
	padding-bottom: 4px; font-size: 1.1rem; font-weight: normal;
}
.ZAppTabBorder .ZDropDown {
	padding-right: 10px;
}
.ZSelectedPrev .ZAppTabBorder {
	border-right-color: rgb(255, 255, 255);
}
.ZAppTabSpacer {
	height: 2.5rem; margin-top: -1rem;
}
.ZTabBarPrefix {
	padding: 0px; width: 10px; border-bottom-color: rgb(178, 178, 178); =
border-bottom-width: 1px; border-bottom-style: solid;
}
.ZTabBarSuffix {
	padding: 0px; width: 100%; border-bottom-color: rgb(178, 178, 178); =
border-bottom-width: 1px; border-bottom-style: solid;
}
.quotaBar {
	height: 8px;
}
.quotaLabel {
	text-align: right; font-size: 0.82rem;
}
.ZmInviteToolBar .ZToolbarTable {
	height: 100%;
}
.ZmShareToolBar .ZToolbarTable {
	height: 100%;
}
.ZNewButton .ZToolbarButtonBorder {
	background-color: rgba(255, 255, 255, 0.65);
}
.ZHover.ZNewButton .ZToolbarButtonBorder {
	background: rgb(204, 231, 243);
}
.ZActive.ZNewButton .ZToolbarButtonBorder {
	background: rgb(153, 207, 231);
}
.ZToolbarButtonTable td:first-child {
	padding-left: 5px;
}
.ZToolbarButtonTable td:last-child {
	padding-right: 5px;
}
.ZmNetworkStatus {
	font-weight: bold;
}
.ZmNetworkStatusIcon {
	cursor: pointer;
}
.DwtInputField input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtInputField input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtSimpleInput {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtInputField textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(191, 191, 191); =
border-image: none; color: black; cursor: text; background-color: white;
}
.DwtInputField-error input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: =
rgb(243, 241, 191);
}
.DwtInputField-error input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: =
rgb(243, 241, 191);
}
.DwtSimpleInput-error {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: =
rgb(243, 241, 191);
}
.DwtInputField-error textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(191, 191, 191); =
border-image: none; color: black; cursor: text; background-color: =
rgb(243, 241, 191);
}
.DwtInputField-focused input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtInputField-focused input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtSimpleInput-focused {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: black; cursor: text; background-color: white;
}
.DwtInputField-focused textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(191, 191, 191); =
border-image: none; color: black; cursor: text; background-color: white;
}
.DwtInputField-disabled input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(229, 229, 229); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); cursor: text; =
background-color: transparent;
}
.DwtInputField-disabled input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(229, 229, 229); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); cursor: text; =
background-color: transparent;
}
.DwtSimpleInput-disabled {
	padding: 0px 3px; border: 1px solid rgb(229, 229, 229); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); cursor: text; =
background-color: transparent;
}
.DwtInputField-disabled textarea {
	padding: 0.2em 0.3em; border: 1px solid rgb(229, 229, 229); =
border-image: none; color: rgb(153, 153, 153); cursor: text; =
background-color: transparent;
}
.DwtInputField-hint input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: white;
}
.DwtInputField-hint input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: white;
}
.DwtInputField-hint input {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: white;
}
.DwtSimpleInput-hint {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: white;
}
.DwtInputField-hint textarea {
	padding: 0.2em 0.3em; color: rgb(153, 153, 153); font-style: italic; =
cursor: default;
}
.DwtInputField-errorhint input[type=3D'text'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: rgb(243, 241, 191);
}
.DwtInputField-errorhint input[type=3D'password'] {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: rgb(243, 241, 191);
}
.DwtSimpleInput-errorhint {
	padding: 0px 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; height: 2rem; color: rgb(153, 153, 153); font-style: italic; =
cursor: default; background-color: rgb(243, 241, 191);
}
.DwtInputField-errorhint textarea {
	border: 1px solid rgb(191, 191, 191); border-image: none; color: =
rgb(204, 204, 204); background-color: rgb(243, 241, 191);
}
textarea .BannerBar * {
	font-size: 0.82rem;
}
.BannerBar {
	height: 1px; padding-top: 1px;
}
.BannerBar td {
	padding-right: 0px;
}
.BannerBar .quotabar {
	background-color: white;
}
.BannerTextQuota {
	text-align: center; vertical-align: top;
}
.BannerTextUser {
	cursor: default;
}
.BannerTextQuota {
	cursor: default;
}
.BannerTextQuota-MultiAccount {
	padding-top: 5px;
}
input[type=3D'text'] {
	margin: 0px; border: 1px solid rgb(191, 191, 191); border-image: none;
}
input[type=3D'password'] {
	margin: 0px; border: 1px solid rgb(191, 191, 191); border-image: none;
}
select {
	margin: 0px; border: 1px solid rgb(191, 191, 191); border-image: none;
}
.TabSpacer {
	display: none;
}
.Tab {
	height: 30px; padding-right: 5px !important; white-space: nowrap;
}
.TbTop {
	border-width: 0px 1px 1px 0px !important; padding-right: 5px =
!important;
}
.TbBottom {
	border-width: 0px 1px 1px 0px !important; padding-right: 5px =
!important;
}
.TabFiller {
	width: 100%;
}
.List .Header th {
	border-right-color: rgb(242, 242, 242); border-right-width: 1px; =
border-right-style: solid;
}
.ZhSubTabs {
	padding-top: 2px; background-color: rgb(229, 229, 229);
}
.ZhSubTabs {
	padding: 5px !important;
}
.ZhSubTabs .TabSelected {
	border-color: rgb(178, 178, 178) rgb(178, 178, 178) rgb(255, 255, 255); =
color: rgb(51, 51, 51); cursor: pointer; background-color: rgb(255, 255, =
255);
}
.ZhRow td {
	border-width: 0px 0px 1px !important; padding-left: 3px !important;
}
.ZhRowOdd td {
	border-width: 0px 0px 1px !important; padding-left: 3px !important;
}
.ZmSearchToolbarCell .ZSelected .ZToolbarButtonBorder {
	border: 2px inset currentColor; border-image: none; color: white; =
background-color: rgb(251, 249, 244) !important;
}
.ZAppTabBorder .ZLeftIcon div {
	display: none;
}
.AlphabetBarTable .DwtButton {
	border-color: rgb(153, 153, 153); border-radius: 0px; box-shadow: 0px =
0px 0px transparent;
}
.AlphabetBarTable .DwtButton-hover {
	border-color: rgb(153, 153, 153); border-radius: 0px; box-shadow: 0px =
0px 0px transparent;
}
.AlphabetBarTable .DwtButton-active {
	border-color: rgb(153, 153, 153); border-radius: 0px; box-shadow: 0px =
0px 0px transparent;
}
.AlphabetBarTable td:first-child {
	border-radius: 3px 0px 0px 3px;
}
.AlphabetBarTable td:last-child {
	border-radius: 0px 3px 3px 0px;
}
.DwtListView-Column {
	background-color: rgb(255, 255, 255);
}
.DwtListView-Column td {
	color: rgb(114, 114, 114);
}
.overviewHeader {
	padding: 1px 0px; border: 0px currentColor; border-image: none; =
background-color: rgb(204, 204, 204);
}
.overviewHeader > table {
	border: 1px solid white; border-image: none;
}
.overviewHeader .ZButton {
	height: auto;
}
.overviewHeader.FirstOverviewHeader {
	padding-top: 0px;
}
.RowDouble {
	height: auto; padding-top: 0px;
}
.RowDouble > table {
	border: 1px solid white; border-image: none;
}
.RowDouble .ZmRowDoubleHeader {
	border: 1px solid white; border-image: none;
}
.RowDouble .TopRow {
	margin: 6px 0px 0px;
}
.RowDouble .ImgCheckboxChecked {
	margin: 6px 0px 0px;
}
.RowDouble .ImgCheckboxUnchecked {
	margin: 6px 0px 0px;
}
.RowDouble .ZmMsgListExpand {
	margin-right: 2px; margin-left: -2px;
}
.RowDouble .BottomRow {
	margin: 4px 0px 6px;
}
.Row-matched {
	background-color: rgb(255, 254, 196);
}
.RowDouble-matched {
	background-color: rgb(255, 254, 196);
}
.RowDouble-matched .ZmListFlagsWrapper {
	background-color: rgb(255, 254, 196);
}
.RowDouble-matched .ZmMsgListDate {
	background-color: rgb(255, 254, 196);
}
.TopRow {
	height: 1.6rem; position: relative;
}
.BottomRow {
	height: 1.6rem; position: relative;
}
.ZmListFlagsWrapper {
	right: 0px; border-top-color: rgb(255, 255, 255); position: absolute; =
background-color: rgb(255, 255, 255);
}
.SimpleContact .ZmListFlagsWrapper {
	padding: 0.08rem 0px; right: 0px;
}
.SimpleContact .ImgCheckboxUnchecked {
	margin: 0px 5px 0px 2px;
}
.SimpleContact .ImgCheckboxChecked {
	margin: 0px 5px 0px 2px;
}
.ZmContactIcon {
	margin: 0px 5px 0px 2px;
}
.ZmListFlagsWrapper div {
	margin: 0px 2px 0px 3px;
}
.TopRow .ImgMsgRead {
	margin: 0px 3px;
}
.TopRow .ImgMsgUnread {
	margin: 0px 3px;
}
.TopRow .ImgCheckboxUnchecked {
	margin: 0px 0px 0px -1px;
}
.TopRow .ImgCheckboxChecked {
	margin: 0px 0px 0px -1px;
}
.TopRow .ImgNodeCollapsed {
	padding: 0px;
}
.TopRow .ImgNodeExpanded {
	padding: 0px;
}
.ZmMsgListColTag {
	padding: 0px 2px 0px 3px; vertical-align: middle;
}
.BottomRow .ZmMsgListColTag {
	margin-right: 3px;
}
.ZmMsgListDate {
	width: 6.8rem; text-align: right; right: 0px; position: absolute;
}
.ZmMsgListColSelection {
	width: 16px;
}
.ZmMsgListColFlag {
	width: 16px;
}
.ZmMsgListColTag {
	width: 16px;
}
.ZmMsgListColAccount {
	width: 16px;
}
.ZmMsgListColStatus {
	width: 16px;
}
.ZmMsgListColMute {
	width: 16px;
}
.ZmMsgListColRead {
	width: 16px;
}
.ZmMsgListColAttachment {
	width: 16px;
}
.ZmMsgListColExpand {
	width: 16px;
}
.ZmMsgListColPriority {
	width: 8px; margin-left: 3px;
}
.ZmMsgListColFolder {
	text-align: left;
}
.ZmMsgListColSize {
	text-align: left;
}
.ZmMsgListColDate {
	text-align: left;
}
.ZToolbarTable .vertSep {
	border-color: transparent;
}
.appt_new_time .ImgBlank_16 {
	display: none;
}
.appt_time .ImgBlank_16 {
	display: none;
}
.form .ZLoginButton {
	border-color: white; color: white; background-color: rgb(0, 135, 195);
}
.form .ZLoginButton:hover {
	color: rgb(51, 51, 51); background-color: rgb(63, 165, 210);
}
.form .ZLoginButton:active {
	background-color: rgb(0, 101, 146);
}
#skin_spacing_app_row {
	height: 2.4rem;
}
.ZAppTabBorder .ZWidgetTitle {
	font-size: 1.3rem;
}
.ZmOverview > div {
	margin-right: 2px;
}
#skin_container_tree {
	border-width: 0px; margin-left: 3px;
}
#skin_container_tree_footer {
	border-width: 0px; margin-left: 3px;
}
.DwtListView {
	border-width: 0px; margin-left: 3px;
}
.ZmConvView {
	border-width: 0px; margin-left: 3px;
}
.ZmConvView2 {
	border-width: 0px; margin-left: 3px;
}
.ZmConvView {
	background-color: rgb(255, 255, 255);
}
.ZmConvView2 {
	background-color: rgb(255, 255, 255);
}
.ZmMailMsgView {
	background-color: rgb(255, 255, 255);
}
.ZmMailMsgView > div {
	background-color: white;
}
#skin_container_tree {
	background-image: none; background-color: transparent;
}
.Conv2View {
	background-image: none; background-color: transparent;
}
.Conv2View-bottom {
	background-image: none; background-color: transparent;
}
.NoResults {
	padding: 1.5em 1em; border-radius: 3px; background-color: transparent;
}
.overviewHeader {
	padding-top: 0px; padding-bottom: 0px; background-color: transparent;
}
.overviewHeader > table {
	border-width: 0px;
}
.overviewHeader td {
	font-size: 1.3rem; font-weight: normal; background-color: transparent;
}
.ZNewButton {
	border-radius: 3px; right: -5px; overflow: hidden !important; =
margin-right: 0px;
}
.ZNewButton .ZToolbarButtonBorder {
	border-color: rgb(0, 135, 195); background-color: rgb(0, 135, 195);
}
.ZHover.ZNewButton .ZToolbarButtonBorder {
	border-color: rgb(0, 170, 246); background-color: rgb(0, 170, 246);
}
.ZActive.ZNewButton .ZToolbarButtonBorder {
	border-color: rgb(0, 170, 246); background-color: rgb(0, 170, 246);
}
.ZActive.ZNewButton .ZToolbarButtonBorder {
	border-color: rgb(241, 89, 34); background-image: none; =
background-color: rgb(241, 89, 34);
}
.ZNewButton .ZToolbarButtonTable .ZLeftIcon {
	display: none;
}
.ZNewButton .ZToolbarButtonTable .ZWidgetTitle {
	color: white;
}
.ZHover.ZNewButton .ZToolbarButtonTable .ZWidgetTitle {
	color: white;
}
.ZNewButton .ImgSelectPullDownArrow {
	background-position: 0px 0px; background-image: =
url("/zimbra/skins/harmony/img/harmony/ImgNewSelectPullDownArrow.png?v=3D=
141215153641");
}
.ZHover.ZNewButton .ImgSelectPullDownArrowHover {
	background-position: 0px 0px; background-image: =
url("/zimbra/skins/harmony/img/harmony/ImgNewSelectPullDownArrow.png?v=3D=
141215153641");
}
.ZActive.ZNewButton .ImgSelectPullDownArrow {
	background-position: 0px 0px; background-image: =
url("/zimbra/skins/harmony/img/harmony/ImgNewSelectPullDownArrow.png?v=3D=
141215153641");
}
.ZmMailMsgCapsuleView {
	border-width: 0px 0px 1px; border-radius: 0px;
}
.ZmMailMsgCapsuleView .separator {
	border-color: transparent;
}
.Conv2Messages {
	padding: 0.25em 0.5em;
}
.Conv2Messages .Last {
	border-color: transparent; border-radius: 3px;
}
.Conv2Header {
	border-bottom-width: 0px; background-color: rgb(242, 242, 242);
}
.Conv2Header .info {
	border-bottom-width: 0px; background-color: rgb(242, 242, 242);
}
.Conv2Header {
	height: 2.2em;
}
.Conv2Header .subject {
	color: rgb(51, 51, 51);
}
.Conv2Header .info {
	color: rgb(51, 51, 51);
}
.Conv2MsgHeader .image {
	border-radius: 24px;
}
.Collapsed .Conv2MsgHeader .image {
	border-radius: 16px;
}
:first-child.DwtListView-Sash div {
	background-color: rgb(229, 229, 229) !important;
}
td.DwtListView-Column {
	font-weight: normal; border-bottom-width: 0px; background-color: =
rgb(242, 242, 242);
}
td.DwtListView-ColumnActive {
	font-weight: bold; background-color: rgb(247, 247, 247);
}
.console_inset_app_l {
	z-index: 499 !important;
}
.console_inset_app_l .HSashThumb {
	margin-left: 0px;
}
.Row {
	border-bottom-color: rgb(191, 191, 191) !important;
}
.RowDouble {
	border-bottom-color: rgb(191, 191, 191) !important;
}
.Row {
	height: 2rem; padding-top: 4px;
}
.ZmContactSplitView {
	border-color: transparent; background-color: transparent;
}
.ZmContactSimpleView {
	border-color: transparent; background-color: transparent;
}
.ZmContactInfoView {
	border-color: transparent; background-color: transparent;
}
.SimpleContact {
	border-color: transparent; background-color: transparent;
}
.ZmContactInfoView .contactHeaderTable {
	border-color: transparent; margin: 0.25em 0px; border-radius: 3px; =
background-color: transparent;
}
.RowDouble {
	padding: 0.25em 0.5em; border-top-color: transparent !important; =
border-right-color: transparent !important; border-left-color: =
transparent !important;
}
.RowDouble > table {
	border-color: transparent;
}
.RowDouble .ZmRowDoubleHeader {
	border-color: transparent;
}
.RowDouble .TopRow {
	position: relative;
}
.ZmComposeView input {
	border: currentColor; border-image: none;
}
.ZmComposeView textarea {
	border: currentColor; border-image: none;
}
.ZmContactSplitView {
	border-color: transparent; background-color: transparent;
}
.ZmContactSimpleView {
	border-color: transparent; background-color: transparent;
}
.ZmContactInfoView .contactHeaderTable {
	border-color: transparent; background-color: transparent;
}
.ZmContactView .contactHeaderTable {
	border-color: transparent; background-color: transparent;
}
.ZmContactInfoView {
	border-width: 0px; padding: 1em 1em 0px; background-color: white;
}
.ZmContactInfoView .contactHeaderTable {
	padding-top: 0.25em; margin-bottom: 0.5em;
}
.ZmContactInfoView .contactGroupTable {
	border-color: rgb(229, 229, 229); border-radius: 3px; border-collapse: =
separate;
}
.ZmContactView {
	background-color: transparent;
}
.ZmEditGroupContact {
	border: 1px solid rgb(191, 191, 191); border-image: none; =
background-color: white;
}
.SimpleContact {
	height: 2.2rem; background-image: none; background-color: transparent;
}
.SimpleContact > div {
	border-color: transparent; background-color: transparent;
}
.SimpleContact .ZmListFlagsWrapper {
	height: 16px; right: 3px; margin-top: 2px;
}
.ZmEditGroupContact .Row {
	margin-bottom: 0.5em;
}
.groupMembers .ZmEditGroupContact .Row {
	border-color: rgb(255, 255, 255); margin: 0.5em; background-color: =
white;
}
.ZmContactView .contactHeaderSubTable {
	border-color: transparent; background-color: rgb(229, 229, 229);
}
.ZmContactInfoView .contactHeaderSubTable {
	border-color: transparent; background-color: rgb(229, 229, 229);
}
.ZmCalViewMgr {
	background-color: transparent;
}
.calendar_view {
	background-color: transparent;
}
.appt_body {
	border-color: transparent; box-shadow: 0px 0px 0px transparent; =
background-color: white;
}
.appt_30_body {
	border-color: transparent; box-shadow: 0px 0px 0px transparent; =
background-color: white;
}
.appt_allday_body {
	border-color: transparent; box-shadow: 0px 0px 0px transparent; =
background-color: white;
}
.appt_body > table {
	border-color: transparent; background-image: none; background-color: =
transparent;
}
.appt_30_body > table {
	border-color: transparent; background-image: none; background-color: =
transparent;
}
.appt_allday_body > table {
	border-color: transparent; background-image: none; background-color: =
transparent;
}
.ZmApptComposeField .FakeAnchor {
	float: right; max-width: 22em;
}
.ZmScheduleAssistantView {
	background-color: white;
}
.InvResponseBar {
	border-top-color: rgb(204, 204, 204); background-color: rgb(229, 229, =
229);
}
.InvResponseBar .ZButtonBorder {
	background-color: rgb(255, 255, 255);
}
.ZmTaskMultiView .DwtListView-Column {
	border-color: transparent; background-color: transparent;
}
.ZmTaskMultiView .ZmMailMsgView {
	background-color: white;
}
.newTaskBannerSep {
	margin-bottom: 1em; border-bottom-width: 0px; background-color: =
transparent;
}
.newTaskBannerSep > tbody > tr > td {
	padding: 0.5em; background-color: rgb(229, 229, 229);
}
.ZmTaskEditView .miniCalendarButton .ZButtonBorder {
	margin-top: 0px;
}
.ZmTaskEditView .miniTimeButton .ZButtonBorder {
	margin-top: 0px;
}
.ZmTaskEditView .ZmCompletionSelector .ZButtonBorder {
	margin-top: 0px;
}
.ZmBriefcaseDetailListView {
	background-color: transparent;
}
.ZmPreviewView .MsgHeaderTable > tbody > tr > td {
	background-color: transparent !important;
}
.ZmPreviewView .PreviewViewHeader {
	margin: 0px 1em;
}
.ZmBriefcaseDetailListView .Row table {
	margin: 0.25em 0px; border-collapse: separate;
}
.ZmDocsEditView {
	background-color: rgb(255, 255, 255);
}
.ZmDocsEditViewHeaderCell > div {
	margin: 5px 3px 0px;
}
.ZmPrefView {
	background-color: rgb(255, 255, 255);
}
.ZOptionsSectionMain {
	border-radius: 0px 0px 3px 3px; background-color: white;
}
.prefHeader {
	border-radius: 3px;
}
.ZmPrefZimletListView .Row {
	height: auto;
}
.ZmWhiteBlackList {
	border-radius: 0px; border: 1px solid rgb(191, 191, 191); border-image: =
none; margin-left: 0px;
}
.ZmFilterRulesView .ZOptionsSectionMain {
	border-radius: 0px; background-color: rgb(255, 255, 255);
}
.ZmFilterRulesView .DwtChooserListView {
	min-height: 160px; background-color: white;
}
.WindowOuterContainer {
	background-color: rgb(255, 255, 255);
}
.WindowInnerContainer {
	border-top-color: currentColor; border-top-width: medium; =
border-top-style: none; background-color: rgb(255, 255, 255);
}
.ZmReminderDialog .DwtToolbarButton {
	border: currentColor; border-image: none;
}
.ZmHtmlEditor .ZmHtmlEditorTextArea {
	padding: 0.25em; border: 1px solid rgb(191, 191, 191); border-image: =
none;
}
.DwtCalendar {
	border-top-color: rgb(191, 191, 191); border-top-width: 1px; =
border-top-style: solid;
}
.DwtMenu .DwtCalendar {
	border-top-width: 0px;
}
.ZmContactPicker .DwtChooserListView {
	border-color: rgb(191, 191, 191); background-color: white;
}
.BriefcaseTabBox {
	border-color: rgb(191, 191, 191);
}
.ZmContactSplitView .rowLabel {
	color: rgb(132, 132, 132); font-weight: normal;
}
.ZmMailMsgView .LabelColName {
	color: rgb(132, 132, 132); font-weight: normal;
}
.ZmMailMsgCapsuleView .LabelColName {
	color: rgb(132, 132, 132); font-weight: normal;
}
.ZmHtmlEditor .mce-btn {
	background-image: none; background-color: rgb(255, 255, 255);
}
.ZmHtmlEditor .mce-panel {
	background-image: none; background-color: rgb(255, 255, 255);
}
.ZmHtmlEditor .mce-btn {
	border-radius: 3px; border: 1px solid rgb(191, 191, 191); border-image: =
none; border-collapse: separate;
}
.ZmHtmlEditor .mce-btn:hover {
	background-image: none; background-color: rgb(204, 231, 243);
}
.ZmHtmlEditor .mce-panel {
	border-color: transparent;
}
.ZmHtmlEditor .mce-edit-area iframe {
	border: 1px solid rgb(191, 191, 191); border-image: none;
}
.ZmHtmlEditor :not(.mce-disabled).mce-btn:active {
	box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: rgb(153, 207, 231);
}
.ZmHtmlEditor .mce-btn:focus {
	box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: rgb(153, 207, 231);
}
.ZmHtmlEditor .mce-active.mce-btn {
	box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: rgb(153, 207, 231);
}
.ZmHtmlEditor .mce-active.mce-btn:hover {
	box-shadow: 0px 0px 0px transparent; background-image: none; =
background-color: rgb(153, 207, 231);
}
.ZmHtmlEditor .mce-btn-group .mce-btn {
	border-color: rgb(191, 191, 191);
}
.ZmHtmlEditor .mce-btn-group :not(.mce-first).mce-btn button:first-child =
{
	border-left-color: rgb(223, 223, 223); border-left-width: 1px; =
border-left-style: solid;
}
.ZmHtmlEditor .mce-btn-group .mce-first {
	border-radius: 3px 0px 0px 3px; border-left-color: rgb(191, 191, 191);
}
.ZmHtmlEditor .mce-btn-group .mce-last {
	border-radius: 0px 3px 3px 0px; border-right-color: rgb(191, 191, 191);
}
.ZmHtmlEditor .mce-btn-group .mce-last.mce-first {
	border-radius: 3px;
}
.ImgNewSelectPullDownArrow {
	background: =
url("/zimbra/skins/harmony/img/harmony/ImgNewSelectPullDownArrow.png?v=3D=
141215153641") no-repeat 0px 0px; width: 12px !important; height: 16px =
!important; overflow: hidden;
}
.ImgDisconnect {
	background: =
url("/zimbra/skins/harmony/img/zimbra.png?v=3D141215153641") no-repeat =
0px 0px; width: 16px !important; height: 16px !important; overflow: =
hidden;
}
.ImgMsgRead {
	background: =
url("/zimbra/skins/harmony/img/zimbra.png?v=3D141215153641") no-repeat =
0px -17px; width: 16px !important; height: 16px !important; overflow: =
hidden;
}
.ImgMsgUnread {
	background: =
url("/zimbra/skins/harmony/img/zimbra.png?v=3D141215153641") no-repeat =
0px -34px; width: 16px !important; height: 16px !important; overflow: =
hidden;
}
.ImgRefreshAll {
	background: =
url("/zimbra/skins/harmony/img/zimbra.png?v=3D141215153641") no-repeat =
0px -51px; width: 16px !important; height: 16px !important; overflow: =
hidden;
}

------=_NextPart_000_0005_01D4955E.F91E3D40--
