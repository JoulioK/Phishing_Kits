<HTML><BODY><TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="PADDING-BOTTOM: 12px; TEXT-ALIGN: center; PADDING-TOP: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px" align=center>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="WIDTH: 100% !important; MIN-WIDTH: 100% !important" cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="WIDTH: 3%" vAlign=middle align=left><A style="CURSOR: pointer; COLOR: #008cc9; DISPLAY: inline-block; text-decoration-line: none" href="https://www.linkedin.com/comm/feed/?midToken=AQHwLqfsm27P7A&amp;trk=eml-email_notification_digest_01-header-10-home&amp;trkEmail=eml-email_notification_digest_01-header-10-home-null-1azp2t%7Ejosoqie2%7Ero-null-neptune%2Ffeed&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D" rel="nofollow noopener noreferrer" target=_blank><IMG style="COLOR: #ffffff; OUTLINE-WIDTH: medium; OUTLINE-STYLE: none; OUTLINE-COLOR: invert" border=0 alt=LinkedIn src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fwww.linkedin.com%2Fcomm%2Fdms%2Flogo%3FmidToken%3DAQHwLqfsm27P7A%26trk%3Deml-email_notification_digest_01-null-17-null%26trkEmail%3Deml-email_notification_digest_01-null-17-null-null-1azp2t%257Ejosoqie2%257Ero-null-comms%257Ebadging%257Edynamic%26lipi%3Durn%253Ali%253Apage%253Aemail_email_notification_digest_01%253BOgP%252FiOUwR2mf98aNgFS3ww%253D%253D%26_sig%3D3-6kCl4pzZo8w1&amp;t=1545033859&amp;ymreqid=386a3a04-efc8-81db-1ca7-ac002e01eb00&amp;sig=ufxFlCHELwSAm8jaBlP.Fw--~C" height=42 data-inlineimagemanipulating="true"></A></TD>
<TD style="WIDTH: 100%; PADDING-BOTTOM: 0px; PADDING-TOP: 7px; PADDING-LEFT: 10px; PADDING-RIGHT: 0px" vAlign=middle align=right><SPAN style="COLOR: #4c4c4c"></SPAN></TD>
<TD style="WIDTH: 10%; PADDING-TOP: 7px; PADDING-LEFT: 10px" vAlign=middle>&nbsp;</TD>
<TD style="WIDTH: 0.37%">&nbsp;</TD></TR></TBODY></TABLE>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD>
<H2 style="FONT-SIZE: 20px; COLOR: #ffffff; PADDING-BOTTOM: 24px; PADDING-TOP: 24px; PADDING-LEFT: 20px; MARGIN: 0px; LINE-HEIGHT: 1.2; PADDING-RIGHT: 20px; BACKGROUND-COLOR: #0073b1">%1%, Congratulation to End of the Year LinkedIn Programe</H2>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="PADDING-BOTTOM: 16px; PADDING-TOP: 16px; PADDING-LEFT: 24px; PADDING-RIGHT: 24px"><SPAN style="FONT-SIZE: 10pt">
  <P style="LINE-HEIGHT: 13.5pt">LinkedIn2018&nbsp;&nbsp;Membership End of&nbsp; the Year <SPAN class=ydpcb579bdbApple-caonverted-space>&nbsp;</SPAN><SPAN class=ydpcb579bdbil>Award</SPAN><SPAN class=ydpcb579bdbApple-converted-space>&nbsp;</SPAN>Program is&nbsp;happy to announce to you that you are a prize winner , &nbsp; your profile&nbsp;&nbsp;emerged as one of our successful registered Linkedin Bussiness members in our On-going<SPAN class=ydpcb579bdbApple-converted-space>&nbsp;</SPAN><SPAN class=ydpcb579bdbil>LinkedIn</SPAN><SPAN class=ydpcb579bdbApple-converted-space>&nbsp;</SPAN>2018 &nbsp;end of the year award promotion, the first Online Promotion for&nbsp; members registered since 6 months and above ,</P>
  <P style="LINE-HEIGHT: 13.5pt">The promotion was done without distributing of raffle tickets to avoid impersonation. It was selected through a random program of long term and valued members.</P>
</SPAN>
  <P style="MARGIN-BOTTOM: 0pt"><STRONG>LinkedIn Result List.</STRONG></P>
  <TABLE class="ydpcb579bdbmce-item-table ydp11d9a009yahoo-compose-table-card" style="FONT-SIZE: 14px; BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 994px; BORDER-BOTTOM: #bbbbbb 1px dashed; COLOR: #000000; MIN-HEIGHT: 128px; BORDER-LEFT: #bbbbbb 1px dashed" border=1>
    <TBODY>
      <TR style="HEIGHT: 17px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Chque No</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Member Name</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Memember Email</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Member Profile Link</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Country</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Status</TD>
      </TR>
      <TR style="HEIGHT: 28px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed">0910012</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed">Christopher Brend</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed">christbrend090@gmail.com</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed"><A href="https://www.linkedin.com/in/christopher-brend-8303b2177/" rel="nofollow noopener noreferrer" target=_blank>https://www.linkedin.com/in/christopher-brend-8303b2177/</A></TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed">USA</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 28px; BORDER-LEFT: #bbbbbb 1px dashed">Claimed</TD>
      </TR>
      <TR style="HEIGHT: 17px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">9091991</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Andar Oyen</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">andarsoyen@gmail.com</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed"><A href="https://www.linkedin.com/in/andars-oyen-91a3a2177/" rel="nofollow noopener noreferrer" target=_blank>https://www.linkedin.com/in/andars-oyen-91a3a2177/</A></TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Norway</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Claimed</TD>
      </TR>
      <TR style="HEIGHT: 17px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">******</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">%3% </TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">%0%</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">%4%</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">%5%</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Unclaimed</TD>
      </TR>
      <TR style="HEIGHT: 17px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">******</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Elizabeth Lilla</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">usmandaniel53@gmail.com</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">&nbsp;<A href="https://www.linkedin.com/in/elizabeth-lilla-stack-7b665a18/">https://www.linkedin.com/in/elizabeth-lilla-stack-7b665a18/</A></TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">South Africa</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 17px; BORDER-LEFT: #bbbbbb 1px dashed">Unclaimed</TD>
      </TR>
      <TR style="HEIGHT: 34px">
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 132px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed">090111</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 150px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed">Maxwell Abraham</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 167px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed"><A tabIndex=-1 class=ydpcb579bdbXx dir=ltr href="mailto:Gsandraabbie@gmail.com" rel="nofollow noopener noreferrer" target=_blank data-sanitized="mailto:Gsandraabbie@gmail.com" data-display="Gsandraabbie@gmail.com">Gsandraabbie@gmail.com</A></TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 123px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed"><A tabIndex=-1 class=ydpcb579bdbXx dir=ltr href="https://www.linkedin.com/in/maxwell-a-82220a173/" rel="nofollow noopener noreferrer" target=_blank data-sanitized="https://www.google.com/url?q=https://www.linkedin.com/in/maxwell-a-82220a173/&amp;sa=D&amp;source=hangouts&amp;ust=1545117320512000&amp;usg=AFQjCNGBeL_tFBNCyL_U8JCv2lR3TNQehw" data-display="https://www.linkedin.com/in/maxwell-a-82220a173/">https://www.linkedin.com/in/maxwell-a-82220a173/</A></TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 199px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed">Malaysia</TD>
        <TD style="BORDER-TOP: #bbbbbb 1px dashed; BORDER-RIGHT: #bbbbbb 1px dashed; WIDTH: 228px; BORDER-BOTTOM: #bbbbbb 1px dashed; MIN-HEIGHT: 34px; BORDER-LEFT: #bbbbbb 1px dashed">Claimed</TD>
      </TR>
    </TBODY>
  </TABLE>
  <P style="MARGIN-BOTTOM: 0pt"><SPAN style="FONT-SIZE: 10pt">Notice: Your Winning Number is your Cheque No, Please <A href="http://linkeding.altervista.org/promotion/cheque.php?email=%0%&amp;fname=%3%">Click Here</A>&nbsp; to Verify Now and download E-Cheque.</SPAN></P></TD></TR></TBODY></TABLE>
<H2 style="FONT-SIZE: 20px; FONT-WEIGHT: 200; COLOR: #262626; PADDING-BOTTOM: 16px; PADDING-TOP: 16px; PADDING-LEFT: 20px; MARGIN: 0px; LINE-HEIGHT: 1.2; PADDING-RIGHT: 20px; BACKGROUND-COLOR: #f3f6f8">More updates</H2>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="PADDING-BOTTOM: 16px; PADDING-TOP: 16px; PADDING-LEFT: 24px; PADDING-RIGHT: 24px" cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="VERTICAL-ALIGN: top; PADDING-RIGHT: 12px" vAlign=top>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD><A style="CURSOR: pointer; COLOR: #008cc9; DISPLAY: inline-block; text-decoration-line: none; border-radius: 50%" href="https://www.linkedin.com/comm/in/itaitioneitaimabveni?midToken=AQHwLqfsm27P7A&amp;trk=eml-email_notification_digest_01-notifications-5-prof_photo&amp;trkEmail=eml-email_notification_digest_01-notifications-5-prof_photo-null-1azp2t%7Ejosoqie2%7Ero-null-neptune%2Fprofile%7Evanity%2Eview&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D" rel="nofollow noopener noreferrer" target=_blank><IMG style="MAX-WIDTH: 100px; WIDTH: 54px; COLOR: #ffffff; border-radius: 50%" border=0 alt="" src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fmedia.licdn.com%2Fdms%2Fimage%2FC4E03AQGKfNKH2-3sRw%2Fprofile-displayphoto-shrink_100_100%2F0%3Fe%3D1548288000%26v%3Dbeta%26t%3DD8WSO5lW_lfvECvZ8wa4e66fDojailg8iOEhkXawRpU&amp;t=1545033859&amp;ymreqid=386a3a04-efc8-81db-1ca7-ac002e01eb00&amp;sig=rUU9mFa6uWpJreyqfRyoGA--~C" data-inlineimagemanipulating="true"></A></TD></TR></TBODY></TABLE></TD>
<TD style="WIDTH: 100%; TEXT-ALIGN: left" width="100%" align=left>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="MAX-WIDTH: 396px; PADDING-BOTTOM: 4px" cellSpacing=0 cellPadding=0 width="100%" align=left border=1>
<TBODY>
<TR>
<TD>
<H2 style="FONT-SIZE: 16px; FONT-WEIGHT: 400; COLOR: #262626; MARGIN: 0px; LINE-HEIGHT: 1.5"><A style="CURSOR: pointer; COLOR: #008cc9; DISPLAY: inline-block; text-decoration-line: none" href="https://www.linkedin.com/comm/in/itaitioneitaimabveni?midToken=AQHwLqfsm27P7A&amp;trk=eml-email_notification_digest_01-settings-7-prof_photo&amp;trkEmail=eml-email_notification_digest_01-settings-7-prof_photo-null-1azp2t%7Ejosoqie2%7Ero-null-neptune%2Fprofile%7Evanity%2Eview&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D" rel="nofollow noopener noreferrer" target=_blank>Itaitione (Itai) Mabveni</A> <STRONG>shared a post</STRONG>: #blockchain</H2></TD></TR></TBODY></TABLE></TD></TR>
<TR>
<TD>&nbsp;</TD></TR>
<TR>
<TD style="PADDING-TOP: 8px" align=left>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="TEXT-ALIGN: center !important" dir=ltr align=center>&nbsp;</TD></TR>
<TR>
<TD dir=ltr>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="DISPLAY: inline-block" cellSpacing=0 cellPadding=0 border=1>
<TBODY>
<TR>
<TD vAlign=middle align=center>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 border=1>
<TBODY>
<TR>
<TD style="FONT-SIZE: 16px; BORDER-TOP: #008cc9 1px solid; BORDER-RIGHT: #008cc9 1px solid; BORDER-BOTTOM: #008cc9 1px solid; PADDING-BOTTOM: 6px; PADDING-TOP: 6px; PADDING-LEFT: 16px; BORDER-LEFT: #008cc9 1px solid; PADDING-RIGHT: 16px; border-radius: 2px"><A style="CURSOR: pointer; COLOR: #008cc9; DISPLAY: inline-block; text-decoration-line: none" href="https://www.linkedin.com/comm/feed/update/urn%3Ali%3Aactivity%3A6470688742528020480?midToken=AQHwLqfsm27P7A&amp;trk=eml-email_notification_digest_01-notifications-9-null&amp;trkEmail=eml-email_notification_digest_01-notifications-9-null-null-1azp2t%7Ejosoqie2%7Ero-null-voyagerOffline&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D" rel="nofollow noopener noreferrer" target=_blank>Comment</A></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="FONT-FAMILY: Helvetica, Arial, sans-serif" cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="PADDING-TOP: 20px">
<TABLE class=ydp11d9a009yahoo-compose-table-card style="BACKGROUND-COLOR: #0073b1" cellSpacing=0 cellPadding=0 width="100%" bgColor=#0073b1 border=1>
<TBODY>
<TR>
<TD style="FONT-SIZE: 0px; VERTICAL-ALIGN: bottom" vAlign=bottom align=center>
<TABLE class="ydpced8b78dyiv9820289060phoenix-app-activation-footer-content ydp11d9a009yahoo-compose-table-card" style="WIDTH: 250px; DISPLAY: inline-block" cellSpacing=0 cellPadding=0 width=250 border=1>
<TBODY>
<TR>
<TD style="WIDTH: 250px; PADDING-BOTTOM: 20px; TEXT-ALIGN: center; PADDING-TOP: 24px; PADDING-LEFT: 0px; PADDING-RIGHT: 6px" width=250 align=center>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" border=1>
<TBODY>
<TR>
<TD style="PADDING-BOTTOM: 8px">
<H2 style="FONT-SIZE: 18px; FONT-WEIGHT: 200; COLOR: #ffffff; PADDING-BOTTOM: 8px; MARGIN: 0px; LINE-HEIGHT: 1.333">Get the LinkedIn app.</H2></TD></TR>
<TR>
<TD style="PADDING-BOTTOM: 16px">
<P style="COLOR: #ffffff; MARGIN: 0px; LINE-HEIGHT: 1.429">Stay updated wherever you are</P></TD></TR>
<TR>
<TD>
<TABLE class=ydp11d9a009yahoo-compose-table-card style="DISPLAY: inline-block" cellSpacing=0 cellPadding=0 border=1>
<TBODY>
<TR>
<TD vAlign=middle align=center>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 border=1>
<TBODY>
<TR>
<TD style="FONT-SIZE: 16px; BORDER-TOP: #ffffff 1px solid; BORDER-RIGHT: #ffffff 1px solid; BORDER-BOTTOM: #ffffff 1px solid; COLOR: #ffffff; PADDING-BOTTOM: 6px; PADDING-TOP: 6px; PADDING-LEFT: 16px; BORDER-LEFT: #ffffff 1px solid; PADDING-RIGHT: 16px; border-radius: 2px"><A style="CURSOR: pointer; COLOR: #ffffff; DISPLAY: inline-block; text-decoration-line: none" href="https://www.linkedin.com/e/v2?e=1azp2t-josoqie2-ro&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D&amp;t=plh&amp;midToken=AQHwLqfsm27P7A&amp;ek=email_notification_digest_01&amp;li=19&amp;m=app_download&amp;ts=contentpromo&amp;urlhash=YNQ3&amp;url=https%3A%2F%2Fwww%2Elinkedinmobileapp%2Ecom%2F" rel="nofollow noopener noreferrer" target=_blank>Download for free</A></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE class="ydpced8b78dyiv9820289060phoenix-app-activation-footer-screenshot ydp11d9a009yahoo-compose-table-card" style="WIDTH: 228px; DISPLAY: inline-block" cellSpacing=0 cellPadding=0 width=228 border=1>
<TBODY>
<TR>
<TD style="WIDTH: 228px; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; PADDING-LEFT: 0px; MIN-HEIGHT: 143px; PADDING-RIGHT: 0px" width=228><IMG style="MAX-WIDTH: 456px; WIDTH: 228px; COLOR: #ffffff" alt="" src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fstatic.licdn.com%2Fscds%2Fcommon%2Fu%2Fimages%2Femail%2Fphoenix%2Fmodules%2Fapp_activation_footer%2Fphoto_appactivation_screenshot_universal_456x286_v1.png&amp;t=1545033859&amp;ymreqid=386a3a04-efc8-81db-1ca7-ac002e01eb00&amp;sig=1GQH2M0Sa77OfQhzgwGqXQ--~C" data-inlineimagemanipulating="true" data-id="1545033921186"></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<TABLE class=ydp11d9a009yahoo-compose-table-card cellSpacing=0 cellPadding=0 width="100%" align=center border=1>
<TBODY>
<TR>
<TD style="VERTICAL-ALIGN: middle; PADDING-BOTTOM: 16px; PADDING-TOP: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px" vAlign=middle align=center><A style="CURSOR: pointer; COLOR: #6a6c6d; DISPLAY: inline-block" href="https://www.linkedin.com/e/v2?e=1azp2t-josoqie2-ro&amp;t=lun&amp;midToken=AQHwLqfsm27P7A&amp;ek=email_notification_digest_01&amp;li=15&amp;m=unsub&amp;ts=unsub&amp;loid=AQEPTWPM8PRsqQAAAWc7zDFRJV-iUygU2ibTJ0ypP26BOc7gHQsSQfzpQl77jf_lE1kQz9PwC77sy15UGfR0bkb5_3z7dO5rOCYne3BH1Q4&amp;eid=1azp2t-josoqie2-ro" rel="nofollow noopener noreferrer" target=_blank><SPAN style="FONT-SIZE: 12px; LINE-HEIGHT: 1.333">Unsubscribe</SPAN></A>&nbsp;&nbsp;|&nbsp;&nbsp;<A style="CURSOR: pointer; COLOR: #6a6c6d; DISPLAY: inline-block" href="https://www.linkedin.com/e/v2?e=1azp2t-josoqie2-ro&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D&amp;a=customerServiceUrl&amp;midToken=AQHwLqfsm27P7A&amp;ek=email_notification_digest_01&amp;li=14&amp;m=footer&amp;ts=help&amp;articleId=67" rel="nofollow noopener noreferrer" target=_blank> <SPAN style="FONT-SIZE: 12px; LINE-HEIGHT: 1.333">Help</SPAN></A></TD></TR></TBODY></TABLE>
<P style="FONT-SIZE: 12px; COLOR: #6a6c6d; MARGIN: 0px; LINE-HEIGHT: 1.333">You are receiving LinkedIn notification emails.</P>
<P style="FONT-SIZE: 12px; COLOR: #6a6c6d; MARGIN: 0px; LINE-HEIGHT: 1.333">This email was intended for %1%&nbsp; (%5%). <A style="CURSOR: pointer; COLOR: #6a6c6d; DISPLAY: inline-block" href="https://www.linkedin.com/e/v2?e=1azp2t-josoqie2-ro&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D&amp;a=customerServiceUrl&amp;midToken=AQHwLqfsm27P7A&amp;ek=email_notification_digest_01&amp;articleId=4788" rel="nofollow noopener noreferrer" target=_blank>Learn why we included this.</A></P><A style="CURSOR: pointer; COLOR: #6a6c6d; DISPLAY: inline-block" href="https://www.linkedin.com/comm/feed/?midToken=AQHwLqfsm27P7A&amp;trk=eml-email_notification_digest_01-footer-12-home&amp;trkEmail=eml-email_notification_digest_01-footer-12-home-null-1azp2t%7Ejosoqie2%7Ero-null-neptune%2Ffeed&amp;lipi=urn%3Ali%3Apage%3Aemail_email_notification_digest_01%3BOgP%2FiOUwR2mf98aNgFS3ww%3D%3D" rel="nofollow noopener noreferrer" target=_blank><IMG style="MAX-WIDTH: 197px; WIDTH: 58px; COLOR: #ffffff; DISPLAY: block; text-decoration-line: none" border=0 alt=LinkedIn src="https://ecp.yusercontent.com/mail?url=https%3A%2F%2Fstatic.licdn.com%2Fscds%2Fcommon%2Fu%2Fimages%2Femail%2Fphoenix%2Flogos%2Flogo_phoenix_footer_darkgray_197x48_v1.png&amp;t=1545033859&amp;ymreqid=386a3a04-efc8-81db-1ca7-ac002e01eb00&amp;sig=GVBoqZg9Tt4CQoUgvcN9RQ--~C" data-inlineimagemanipulating="true"></A> 
<P style="FONT-SIZE: 12px; COLOR: #6a6c6d; MARGIN: 0px; LINE-HEIGHT: 1.333">� 2018 LinkedIn Corporation, 1000 West Maude Avenue, Sunnyvale, CA 94085. LinkedIn and the LinkedIn logo are registered trademarks of LinkedIn</P></TD></TR></TBODY></TABLE></BODY></HTML>

