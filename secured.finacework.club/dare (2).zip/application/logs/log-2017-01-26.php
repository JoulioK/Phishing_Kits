<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-26 09:17:19 --> Query error: Unknown column 'emailaddress' in 'field list' - Invalid query: INSERT INTO `tbltickets` (`subject`, `department`, `clientid`, `priority`, `body`, `status`, `emailaddress`, `attachment`, `additional`) VALUES ('Hello', '1', '14675775313398tp', 'Low', 'Ola', 'open', 'olafashade@hotmail.com', 'http://localhost/charity/resources/web/attachments/ed3b1882b1cfe6ddfb91dccefd0cba4f.png', '[]')
ERROR - 2017-01-26 10:57:04 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-26 11:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Users.php 132
ERROR - 2017-01-26 11:57:45 --> Query error: Unknown column 'gh' in 'where clause' - Invalid query: SELECT `userid`
FROM `tbl_gh`
WHERE `gh` = '14854274576714ty'
ERROR - 2017-01-26 11:57:45 --> Query error: Unknown column 'gh' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485428265, `data` = 'current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;user_session|O:8:\"stdClass\":19:{s:2:\"id\";s:2:\"23\";s:6:\"userid\";s:16:\"14854276689179my\";s:8:\"fullname\";s:11:\"sample fash\";s:8:\"username\";s:6:\"sample\";s:12:\"emailaddress\";s:17:\"sample@sample.com\";s:11:\"phonenumber\";s:11:\"80894392348\";s:8:\"password\";s:128:\"fcb36e9806c7a6f7efc84fb7dbcb473c7a597ee7d99df3b238eed232b38b3e1d0507c35abd2fb4aa27968099468896538a716790decbe69b4893150df53e659d\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";N;s:11:\"accountname\";s:11:\"Sample Fash\";s:13:\"accountnumber\";s:7:\"0190203\";s:8:\"bankname\";s:6:\"GTBank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"0\";s:11:\"datecreated\";s:19:\"2017-01-26 11:47:48\";s:12:\"datemodified\";s:19:\"2017-01-26 11:50:29\";}user_loggedin|b:1;'
WHERE `gh` = '14854274576714ty'
AND `id` = '74c1bf54507b2756270c6c03c4fa9c8fcce35936'
ERROR - 2017-01-26 12:24:04 --> You did not select a file to upload.
ERROR - 2017-01-26 12:32:08 --> You did not select a file to upload.
ERROR - 2017-01-26 12:32:33 --> You did not select a file to upload.
ERROR - 2017-01-26 12:34:42 --> You did not select a file to upload.
ERROR - 2017-01-26 12:40:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:40:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:40:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:40:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:41:58 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:41:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:41:58 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:41:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 142
ERROR - 2017-01-26 12:44:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 143
ERROR - 2017-01-26 12:44:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 143
ERROR - 2017-01-26 12:44:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-26 12:44:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-26 12:44:52 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-26 12:44:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-26 13:43:46 --> Severity: Notice --> Undefined property: Orders::$cron_model C:\xampp\htdocs\charity\application\controllers\management\Orders.php 80
ERROR - 2017-01-26 13:43:46 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 80
ERROR - 2017-01-26 13:43:46 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485434626
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `id` = '74c1bf54507b2756270c6c03c4fa9c8fcce35936'
ORDER BY `id` ASC LIMIT 1
ERROR - 2017-01-26 13:43:46 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-26 13:44:40 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`earning`, `tbl_users`.`accountnumber`, `tbl_users`.`accountname`, `tbl_users`.`bankname`, `tbl_ph`.`maturityamount`, `tbl_ph`.`phid`
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
ORDER BY `id` ASC
 LIMIT 1
ERROR - 2017-01-26 13:44:40 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485434680
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `id` = '74c1bf54507b2756270c6c03c4fa9c8fcce35936'
ORDER BY `id` ASC LIMIT 1
ERROR - 2017-01-26 13:45:09 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 85
ERROR - 2017-01-26 15:55:49 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-26 15:55:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-26 17:38:54 --> Query error: Table 'helpcabal.tbl_user' doesn't exist - Invalid query: UPDATE `tbl_user` SET `datemodified` = '2017-01-26 17:38:53', `enabled` = 0
WHERE `userid` = '14854106682591qc'
ERROR - 2017-01-26 17:52:35 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-26 17:52:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-26 22:31:47 --> 404 Page Not Found: web/Cabal/outgoing
ERROR - 2017-01-26 22:32:49 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\charity\application\views\web\customer\incoming.php 18
ERROR - 2017-01-26 23:51:51 --> 404 Page Not Found: management/Js/classie.js
