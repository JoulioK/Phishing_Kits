<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-16 09:08:04 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\xampp\htdocs\caroossa\application\views\web\customer\profile.php 59
ERROR - 2016-11-16 09:10:15 --> 404 Page Not Found: Hub/customer
ERROR - 2016-11-16 09:15:48 --> Query error: Unknown column 'email' in 'field list' - Invalid query: UPDATE `tbl_users` SET `fullname` = 'Ola', `email` = NULL, `driverslicense` = '9309393030', `password` = '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', `expirydate` = '11/2018', `datemodified` = '2016-11-16 09:15:47'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-16 09:21:58 --> 404 Page Not Found: web/Faq/index
ERROR - 2016-11-16 09:32:17 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 60
ERROR - 2016-11-16 09:32:44 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 09:32:44 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 09:47:25 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 09:47:25 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 09:47:48 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 09:47:48 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 09:48:22 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 09:48:22 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 09:48:23 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 09:53:01 --> 404 Page Not Found: web/Item/14791024063336wd
ERROR - 2016-11-16 09:53:18 --> 404 Page Not Found: web/Item/14789597028834ln
ERROR - 2016-11-16 09:54:35 --> 404 Page Not Found: web/Ride/14791024063336wd
ERROR - 2016-11-16 10:27:51 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 200
ERROR - 2016-11-16 10:36:21 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 37
ERROR - 2016-11-16 16:49:02 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 16:49:02 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 16:49:47 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 16:49:48 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 16:49:48 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 19:53:57 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 19:53:57 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:04:43 --> Query error: Unknown column 'tbl_item_location.locationname' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479323083, `data` = 'user_session|O:8:\"stdClass\":13:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:3:\"Ola\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:14:\"driverslicense\";s:10:\"9309393030\";s:10:\"expirydate\";s:7:\"12/2018\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"1113\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2016-11-16 09:16:46\";}user_loggedin|b:1;location|s:16:\"14668510290307aw\";monthfrom|s:2:\"11\";monthto|s:2:\"11\";dayfrom|s:2:\"01\";dayto|s:2:\"01\";timefrom|s:1:\"0\";timeto|s:1:\"0\";brand|a:1:{i:0;s:12:\"338484748484\";}transmission|N;'
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('338484748484')
AND `id` = 'bcd514bdefaa6859eeffa4806540933b7dc90e10' LIMIT 10
ERROR - 2016-11-16 20:04:55 --> Query error: Unknown column 'tbl_item_location.locationname' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479323095, `data` = 'user_session|O:8:\"stdClass\":13:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:3:\"Ola\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:14:\"driverslicense\";s:10:\"9309393030\";s:10:\"expirydate\";s:7:\"12/2018\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"1113\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2016-11-16 09:16:46\";}user_loggedin|b:1;location|s:16:\"14668510290307aw\";monthfrom|s:2:\"11\";monthto|s:2:\"11\";dayfrom|s:2:\"01\";dayto|s:2:\"01\";timefrom|s:1:\"0\";timeto|s:1:\"0\";brand|a:1:{i:0;s:12:\"338484748484\";}transmission|N;'
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('338484748484')
AND `id` = 'bcd514bdefaa6859eeffa4806540933b7dc90e10' LIMIT 10
ERROR - 2016-11-16 20:05:08 --> Query error: Unknown column 'tbl_item_location.locationname' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479323108
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('338484748484')
AND `id` = 'bcd514bdefaa6859eeffa4806540933b7dc90e10' LIMIT 10
ERROR - 2016-11-16 20:07:12 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:07:12 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:07:51 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:07:51 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:08:58 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:08:58 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:09:19 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:09:19 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:09:36 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:09:36 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:10:00 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:10:00 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:10:52 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-16 20:10:52 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-16 20:11:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:11:06 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:11:52 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:11:58 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:12:19 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:12:26 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-16 20:12:55 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-16 20:13:04 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-16 20:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:13:52 --> 404 Page Not Found: management/Delivery/track
ERROR - 2016-11-16 20:14:37 --> 404 Page Not Found: management/Orders/pending
ERROR - 2016-11-16 20:16:35 --> 404 Page Not Found: management/Messages/index
ERROR - 2016-11-16 20:17:34 --> 404 Page Not Found: Messages/index
ERROR - 2016-11-16 20:19:10 --> 404 Page Not Found: management/Delivery/view_delivery_guys
ERROR - 2016-11-16 20:20:09 --> 404 Page Not Found: management/Settlements/index
ERROR - 2016-11-16 20:22:09 --> Query error: Table 'caroossa.tbl_franchise_payment' doesn't exist - Invalid query: SELECT *
FROM `tbl_franchise_payment`
WHERE datecreated between '2016-11-16 00:00:01' AND '2016-11-16 23:59:59'
AND `franchiseid` = '2626273373'
ERROR - 2016-11-16 20:22:09 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479324129
WHERE datecreated between '2016-11-16 00:00:01' AND '2016-11-16 23:59:59'
AND `franchiseid` = '2626273373'
AND `id` = 'bcd514bdefaa6859eeffa4806540933b7dc90e10'
ERROR - 2016-11-16 20:24:18 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\caroossa\application\views\management\_templates\_menu.php 157
ERROR - 2016-11-16 20:29:12 --> 404 Page Not Found: management/Franchisereport/orders
ERROR - 2016-11-16 20:29:27 --> 404 Page Not Found: management/Franchisereport/orders
ERROR - 2016-11-16 20:32:07 --> Query error: Table 'caroossa.tbl_shippings' doesn't exist - Invalid query: SELECT sum(amount) as total
FROM `tbl_shippings`
WHERE `status` =0
AND datecreated between '2016-11-16 00:00:01' AND '2016-11-16 23:59:59'
AND `franchiseid` = '2626273373'
ERROR - 2016-11-16 20:32:07 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479324727
WHERE `status` =0
AND datecreated between '2016-11-16 00:00:01' AND '2016-11-16 23:59:59'
AND `franchiseid` = '2626273373'
AND `id` = 'bcd514bdefaa6859eeffa4806540933b7dc90e10'
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:38 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 20:41:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-16 21:39:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 32
ERROR - 2016-11-16 21:39:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 78
ERROR - 2016-11-16 21:40:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 78
ERROR - 2016-11-16 21:41:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 78
ERROR - 2016-11-16 21:41:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 78
ERROR - 2016-11-16 21:42:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 78
