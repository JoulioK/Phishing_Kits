<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-25 17:46:20 --> 404 Page Not Found: 
ERROR - 2016-08-25 20:17:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 29
ERROR - 2016-08-25 20:18:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 29
ERROR - 2016-08-25 20:19:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 29
ERROR - 2016-08-25 20:20:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 29
ERROR - 2016-08-25 20:41:50 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 281
ERROR - 2016-08-25 20:41:50 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 288
ERROR - 2016-08-25 20:41:50 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 289
ERROR - 2016-08-25 20:41:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 289
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index: 14711848018894tc C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 290
ERROR - 2016-08-25 20:41:51 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-25 20:54:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-25 20:54:19 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
