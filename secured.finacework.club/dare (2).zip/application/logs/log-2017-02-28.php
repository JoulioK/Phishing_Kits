<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-28 06:59:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-28 07:48:52 --> 404 Page Not Found: management/Report/clients
