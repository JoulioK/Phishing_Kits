<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-01 00:17:08 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-01 00:55:29 --> Query error: Unknown column 'locations' in 'where clause' - Invalid query: SELECT `locationid`, `locationname`
FROM `tbl_locations`
WHERE `locations` = '14675775313398tp'
ERROR - 2016-08-01 00:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 00:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:55:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 00:55:35 --> Query error: Unknown column 'locations' in 'where clause' - Invalid query: SELECT `locationid`, `locationname`
FROM `tbl_locations`
WHERE `locations` IS NULL
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Undefined variable: locationid C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Undefined variable: locationid C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 160
ERROR - 2016-08-01 00:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 00:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 00:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 01:04:47 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 164
ERROR - 2016-08-01 01:04:47 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 167
ERROR - 2016-08-01 01:04:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 01:04:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 01:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 01:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 01:04:53 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 164
ERROR - 2016-08-01 01:04:53 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 167
ERROR - 2016-08-01 01:05:33 --> Severity: Error --> Call to undefined method Settings::locationname() C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 179
ERROR - 2016-08-01 01:05:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 145
ERROR - 2016-08-01 01:05:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 01:05:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 01:05:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 01:51:59 --> Query error: Unknown column 'firstname' in 'field list' - Invalid query: SELECT `firstname`, `lastname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14700080885758ss'
ERROR - 2016-08-01 01:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 267
ERROR - 2016-08-01 01:52:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 268
ERROR - 2016-08-01 01:52:07 --> Query error: Unknown column 'firstname' in 'field list' - Invalid query: SELECT `firstname`, `lastname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` IS NULL
AND `addressid` IS NULL
ERROR - 2016-08-01 01:53:17 --> Query error: Unknown column 'phonenumber' in 'field list' - Invalid query: SELECT `fullname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14700080885758ss'
ERROR - 2016-08-01 01:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 267
ERROR - 2016-08-01 01:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 268
ERROR - 2016-08-01 01:53:23 --> Query error: Unknown column 'phonenumber' in 'field list' - Invalid query: SELECT `fullname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` IS NULL
AND `addressid` IS NULL
ERROR - 2016-08-01 01:54:00 --> Query error: Unknown column 'phonenumber' in 'field list' - Invalid query: SELECT `fullname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14700080885758ss'
ERROR - 2016-08-01 01:55:00 --> Query error: Unknown column 'phonenumber' in 'field list' - Invalid query: SELECT `fullname`, `address`, `phonenumber`, `location`
FROM `tbl_shipping_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14700080885758ss'
ERROR - 2016-08-01 02:06:24 --> 404 Page Not Found: app/Settings/editaddress
ERROR - 2016-08-01 02:06:29 --> 404 Page Not Found: app/Settings/editaddress
ERROR - 2016-08-01 10:52:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 10:52:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 152
ERROR - 2016-08-01 10:52:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 153
ERROR - 2016-08-01 22:08:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 31
ERROR - 2016-08-01 22:08:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 31
ERROR - 2016-08-01 22:29:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 19
ERROR - 2016-08-01 22:32:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 19
ERROR - 2016-08-01 22:32:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 19
ERROR - 2016-08-01 22:33:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 19
ERROR - 2016-08-01 23:26:49 --> Severity: Notice --> Use of undefined constant headfranchise - assumed 'headfranchise' C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 78
