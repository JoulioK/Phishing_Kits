<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-21 00:00:01 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 41
ERROR - 2016-07-21 01:18:33 --> Severity: Compile Error --> Cannot redeclare Settlement_Model::$rules C:\xampp\htdocs\fastfood\application\models\management\settlement_model.php 47
ERROR - 2016-07-21 01:20:08 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\views\management\settlement\franchise_payments.php 79
