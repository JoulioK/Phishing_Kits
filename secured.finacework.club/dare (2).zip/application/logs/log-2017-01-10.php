<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:45:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:37 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-10 12:46:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
