<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-24 00:24:18 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
