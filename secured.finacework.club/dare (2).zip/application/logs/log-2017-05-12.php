<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-12 17:20:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'coinxtra'@'localhost' (using password: YES) C:\xampp\htdocs\coinxtra\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-05-12 17:20:22 --> Unable to connect to the database
ERROR - 2017-05-12 19:48:59 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-05-12 19:49:36 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-05-12 19:49:43 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-05-12 19:50:06 --> 404 Page Not Found: web/Images/4.jpg
