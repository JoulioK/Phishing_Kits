<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-28 21:43:51 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 225
ERROR - 2016-09-28 21:56:32 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 225
ERROR - 2016-09-28 21:56:41 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 225
ERROR - 2016-09-28 21:57:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-28 21:57:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-28 21:57:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-28 21:57:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-28 21:57:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 133
ERROR - 2016-09-28 22:29:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-28 22:29:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-28 22:29:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-28 22:29:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-28 22:29:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 133
ERROR - 2016-09-28 23:05:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 221
ERROR - 2016-09-28 23:05:24 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 190
ERROR - 2016-09-28 23:40:02 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 193
ERROR - 2016-09-28 23:40:08 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 193
ERROR - 2016-09-28 23:40:37 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 193
ERROR - 2016-09-28 23:40:41 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 193
ERROR - 2016-09-28 23:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-28 23:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-28 23:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-28 23:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-28 23:40:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 133
