<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:03:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 112
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:09:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:09:27 --> Query error: Unknown column 'phonenumber' in 'field list' - Invalid query: SELECT `fullname`, `phonenumber`
FROM `tbl_gh`
WHERE `userid` = '14675775313398tp'
ERROR - 2017-01-07 00:09:27 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1483744167
WHERE `userid` = '14675775313398tp'
AND `id` = '75f89b5da7a8f210c3fd5faec1e0490758449e42'
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:20 --> Severity: Parsing Error --> syntax error, unexpected '$gh' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 103
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:12:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-07 00:18:50 --> 404 Page Not Found: web/Authenticate/l
ERROR - 2017-01-07 00:19:21 --> 404 Page Not Found: web/Authenticate/login
ERROR - 2017-01-07 00:19:31 --> 404 Page Not Found: web/Auth/login
