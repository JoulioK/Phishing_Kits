<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-24 09:03:53 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 09:03:55 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 09:04:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:05:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:05:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:05:30 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 18
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 18
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 22
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 22
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 30
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 30
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 39
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 39
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 44
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 44
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 48
ERROR - 2016-02-24 09:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 48
ERROR - 2016-02-24 09:05:31 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 15
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 15
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 19
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 19
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 27
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 27
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 36
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 36
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 45
ERROR - 2016-02-24 09:14:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 45
ERROR - 2016-02-24 09:14:03 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 15
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 15
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 19
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 19
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 27
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 27
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 36
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 36
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-24 09:14:27 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 45
ERROR - 2016-02-24 09:14:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 45
ERROR - 2016-02-24 09:14:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:28:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:28:47 --> 404 Page Not Found: Stores/Configuration
ERROR - 2016-02-24 09:29:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:29:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:29:39 --> Severity: Notice --> Undefined property: Configuration::$Stock_Settings_Model C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 57
ERROR - 2016-02-24 09:29:39 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 57
ERROR - 2016-02-24 09:30:01 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 15
ERROR - 2016-02-24 09:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 15
ERROR - 2016-02-24 09:30:01 --> Severity: Notice --> Undefined variable: Store_info C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 19
ERROR - 2016-02-24 09:30:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 19
ERROR - 2016-02-24 09:30:02 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 15
ERROR - 2016-02-24 09:31:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Stock_config_page.php 19
ERROR - 2016-02-24 09:31:41 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:33:04 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:34:42 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:35:09 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:35:24 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:36:20 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:36:34 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:37:01 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:38:31 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:41:00 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;added_by&quot; violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, &amp;amp;#8358, 10, null). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 09:41:00 --> Query error: ERROR:  null value in column "added_by" violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, &amp;#8358, 10, null). - Invalid query: INSERT INTO "t_stock_settings" ("currency_symbol", "stock_threshold", "storeid") VALUES ('&amp;#8358', '10', '1111111111')
ERROR - 2016-02-24 09:41:37 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:41:49 --> Severity: Warning --> pg_query(): Query failed: ERROR:  value too long for type character varying(10) C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 09:41:49 --> Query error: ERROR:  value too long for type character varying(10) - Invalid query: UPDATE "t_stock_settings" SET "currency_symbol" = '&amp;amp;#8358', "stock_threshold" = '12', "storeid" = '1111111111', "added_by" = '2222222222'
WHERE "id" = 2
ERROR - 2016-02-24 09:42:34 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_settings&quot; does not exist
LINE 2: FROM &quot;t_stock_settings&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 09:42:34 --> Query error: ERROR:  relation "t_stock_settings" does not exist
LINE 2: FROM "t_stock_settings"
             ^ - Invalid query: SELECT *
FROM "t_stock_settings"
WHERE "t_stock_settings"."storeid" = '1111111111'
ORDER BY "t_stock_settings"."id" ASC
ERROR - 2016-02-24 09:42:49 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:44:36 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:44:54 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:45:32 --> Severity: Notice --> Use of undefined constant data - assumed 'data' C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 73
ERROR - 2016-02-24 09:45:32 --> Severity: Warning --> Illegal string offset 'currency_symbol' C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 73
ERROR - 2016-02-24 09:45:32 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:45:55 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:45:59 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:46:01 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:46:13 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:49:25 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 09:49:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:50:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:50:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:51:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:51:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:53:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:55:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:56:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:56:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:57:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:58:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 09:59:59 --> Severity: Notice --> Use of undefined constant storeid - assumed 'storeid' C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 49
ERROR - 2016-02-24 09:59:59 --> Severity: Notice --> Object of class Dashboard could not be converted to int C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 49
ERROR - 2016-02-24 09:59:59 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_other_incomes&quot; does not exist
LINE 2: FROM &quot;t_other_incomes&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 09:59:59 --> Query error: ERROR:  relation "t_other_incomes" does not exist
LINE 2: FROM "t_other_incomes"
             ^ - Invalid query: SELECT *
FROM "t_other_incomes"
WHERE "storeid" = 1
ERROR - 2016-02-24 10:00:09 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_other_incomes&quot; does not exist
LINE 2: FROM &quot;t_other_incomes&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 10:00:09 --> Query error: ERROR:  relation "t_other_incomes" does not exist
LINE 2: FROM "t_other_incomes"
             ^ - Invalid query: SELECT *
FROM "t_other_incomes"
WHERE "storeid" = '1111111111'
ERROR - 2016-02-24 10:04:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:04:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:05:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:06:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:06:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:07:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:07:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:08:18 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\estore\application\views\Store\dashboard_page.php 87
ERROR - 2016-02-24 10:08:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:08:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:08:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:09:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:12:18 --> Severity: Notice --> Undefined property: stdClass::$expenses_amount C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 68
ERROR - 2016-02-24 10:12:18 --> Severity: Notice --> Undefined property: stdClass::$expenses_amount C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 68
ERROR - 2016-02-24 10:12:18 --> Severity: Notice --> Undefined property: stdClass::$expenses_amount C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 68
ERROR - 2016-02-24 10:12:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:12:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:13:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:13:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:15:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:17:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:18:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:18:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:19:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:20:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:20:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:21:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:22:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:22:29 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 10:22:35 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 10:22:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:22:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:22:48 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 10:22:58 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 10:23:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:23:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:23:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:24:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:25:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:27:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:28:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:28:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:30:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:30:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:31:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:31:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:31:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:32:04 --> 404 Page Not Found: Store/Stock_Summary/index
ERROR - 2016-02-24 10:33:09 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\estore\application\views\Store\dashboard_page.php 8
ERROR - 2016-02-24 10:33:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:33:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:35:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:35:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:35:46 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:35:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:35:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:36:01 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:36:04 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:37:26 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:37:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:37:59 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:40:47 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:41:02 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:41:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:41:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:41:59 --> 404 Page Not Found: Store/Sales_Summary/index
ERROR - 2016-02-24 10:42:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:42:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 10:43:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:43:57 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:44:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 10:44:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:44:30 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:46:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:46:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 10:46:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:46:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:46:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:47:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:47:11 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:47:21 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:48:09 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:48:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:48:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 10:48:38 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:49:30 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:49:52 --> 404 Page Not Found: Reports/Stock_Summary
ERROR - 2016-02-24 10:50:16 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:51:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 10:51:37 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:55:10 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:55:45 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:56:36 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:57:02 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:57:26 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:57:54 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:57:59 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:58:09 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:58:28 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:59:01 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:59:35 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 10:59:57 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 11:00:44 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 11:03:04 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-24 11:03:54 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:04:17 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:04:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:04:47 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:04:51 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:04:53 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:05:05 --> 404 Page Not Found: Store/Reports/Expenses_Summary
ERROR - 2016-02-24 11:05:16 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:05:16 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:05:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:06:23 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:06:43 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:07:16 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:07:25 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-24 11:07:36 --> 404 Page Not Found: Store/Reports/Expenses_Summary
ERROR - 2016-02-24 11:09:21 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:09:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:09:33 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:09:36 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:19 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:32 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:36 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:40 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:55 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:10:57 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:11:09 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:11:46 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:11:51 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-24 11:11:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:12:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:12:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:13:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:14:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:14:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:15:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:15:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:15:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:18:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:18:25 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:19:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:19:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:20:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:26:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 11:26:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:51:41 --> Severity: Notice --> Undefined property: Customers::$Store_Customer_model C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 17
ERROR - 2016-02-24 11:51:41 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 17
ERROR - 2016-02-24 11:53:29 --> Severity: Notice --> Undefined property: Customers::$Store_Customer_model C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 17
ERROR - 2016-02-24 11:53:30 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 17
ERROR - 2016-02-24 11:53:48 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;t_store_users&quot;
LINE 5: ORDER BY &quot;t_store_users&quot;.&quot;id&quot; ASC
                 ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 11:53:48 --> Query error: ERROR:  missing FROM-clause entry for table "t_store_users"
LINE 5: ORDER BY "t_store_users"."id" ASC
                 ^ - Invalid query: SELECT *
FROM "t_store_customers"
WHERE "storeid" = '1111111111'
AND "t_store_customers"."storeid" = '1111111111'
ORDER BY "t_store_users"."id" ASC
ERROR - 2016-02-24 11:54:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;t_store_users&quot;
LINE 5: ORDER BY &quot;t_store_users&quot;.&quot;id&quot; ASC
                 ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 11:54:31 --> Query error: ERROR:  missing FROM-clause entry for table "t_store_users"
LINE 5: ORDER BY "t_store_users"."id" ASC
                 ^ - Invalid query: SELECT *
FROM "t_store_customers"
WHERE "storeid" = '1111111111'
AND "t_store_customers"."storeid" = '1111111111'
ORDER BY "t_store_users"."id" ASC
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 20
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 20
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 28
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 28
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 32
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 32
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 36
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 36
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 42
ERROR - 2016-02-24 11:54:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 42
ERROR - 2016-02-24 11:55:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:57:45 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 24
ERROR - 2016-02-24 11:57:45 --> Severity: Notice --> Undefined index: rules C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 24
ERROR - 2016-02-24 11:57:45 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 24
ERROR - 2016-02-24 11:57:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:57:55 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 24
ERROR - 2016-02-24 11:57:56 --> Severity: Notice --> Undefined index: rules C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 24
ERROR - 2016-02-24 11:57:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:58:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:59:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 11:59:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:00:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:00:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:01:11 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:01:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:02:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:03:22 --> Severity: Error --> Call to undefined method CI_Session::customerdata() C:\xampp\htdocs\estore\application\controllers\Store\Customers.php 29
ERROR - 2016-02-24 12:03:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniqueid&quot; of relation &quot;t_store_customers&quot; does not exist
LINE 1: ...r_name&quot;, &quot;customer_phone&quot;, &quot;storeid&quot;, &quot;added_by&quot;, &quot;uniqueid&quot;...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 12:03:36 --> Query error: ERROR:  column "uniqueid" of relation "t_store_customers" does not exist
LINE 1: ...r_name", "customer_phone", "storeid", "added_by", "uniqueid"...
                                                             ^ - Invalid query: INSERT INTO "t_store_customers" ("customer_name", "customer_phone", "storeid", "added_by", "uniqueid") VALUES ('SEUN OGUNMOLA', '07037667193', '1111111111', '2222222222', '1299312255')
ERROR - 2016-02-24 12:03:54 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniqueid&quot; of relation &quot;t_store_customers&quot; does not exist
LINE 1: ...r_name&quot;, &quot;customer_phone&quot;, &quot;storeid&quot;, &quot;added_by&quot;, &quot;uniqueid&quot;...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 12:03:54 --> Query error: ERROR:  column "uniqueid" of relation "t_store_customers" does not exist
LINE 1: ...r_name", "customer_phone", "storeid", "added_by", "uniqueid"...
                                                             ^ - Invalid query: INSERT INTO "t_store_customers" ("customer_name", "customer_phone", "storeid", "added_by", "uniqueid") VALUES ('SEUN OGUNMOLA', '07037667193', '1111111111', '2222222222', '3145635430')
ERROR - 2016-02-24 12:04:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 79
ERROR - 2016-02-24 12:04:24 --> Severity: Notice --> Undefined property: stdClass::$customername C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 82
ERROR - 2016-02-24 12:04:24 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 85
ERROR - 2016-02-24 12:04:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 88
ERROR - 2016-02-24 12:04:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 91
ERROR - 2016-02-24 12:04:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 92
ERROR - 2016-02-24 12:04:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:05:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Customers\Customer_page.php 79
ERROR - 2016-02-24 12:05:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:05:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:05:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 12:05:37 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_customers"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-24 12:05:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:06:08 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = '5290047450'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 12:06:08 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = '5290047450'
            ^ - Invalid query: DELETE FROM "t_store_customers"
WHERE "storeid" = '1111111111'
AND "uniquekey" = '5290047450'
AND "id" = 1
ERROR - 2016-02-24 12:06:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:06:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:06:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:08:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:08:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:08:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:08:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:09:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:09:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:12:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:12:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 12:13:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 12:13:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-24 12:13:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:15:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:15:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:16:20 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 12:16:26 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 12:16:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:16:40 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 12:16:44 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 12:16:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-24 12:16:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:18:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:18:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:18:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:18:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:18:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:21:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:21:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 12:21:36 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 12:21:43 --> 404 Page Not Found: Store/Configuration/images
ERROR - 2016-02-24 12:21:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-24 14:20:01 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 14:34:06 --> Severity: Compile Error --> Cannot redeclare class Migration_Modify_Users_Table C:\xampp\htdocs\estore\application\migrations\015_Modify_Stores_Table.php 16
ERROR - 2016-02-24 14:34:26 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 14:37:02 --> 404 Page Not Found: Web//index
ERROR - 2016-02-24 14:37:11 --> Severity: 4096 --> Object of class W_index could not be converted to string C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 9
ERROR - 2016-02-24 14:37:11 --> Severity: Notice --> Object of class W_index to string conversion C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 9
ERROR - 2016-02-24 14:37:11 --> Severity: Notice --> Undefined variable: Object C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 9
ERROR - 2016-02-24 14:37:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 9
ERROR - 2016-02-24 14:38:15 --> Severity: Notice --> Undefined index: storedata C:\xampp\htdocs\estore\application\controllers\Web\W_index.php 9
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:40:09 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:40:44 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:42:03 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:42:04 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:42:04 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:43:17 --> Severity: Notice --> Undefined variable: theme C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\index_page.php 2
ERROR - 2016-02-24 14:45:27 --> Severity: Notice --> Undefined variable: storeinfo C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\_head.php 5
ERROR - 2016-02-24 14:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\_head.php 5
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Css/style.css
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/jquery.min.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Css/style.css
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:45:27 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:45:28 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:45:29 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:45:57 --> Severity: Notice --> Undefined variable: storeinfo C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\_head.php 1
ERROR - 2016-02-24 14:45:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\_head.php 1
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Js/jquery.min.js
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Css/style.css
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:46:20 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:46:21 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:46:22 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:47:01 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:47:01 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:47:01 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:47:01 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Js/move-top.js
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Js/easing.js
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Css/megamenu.css
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Js/megamenu.js
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:47:02 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:47:03 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/banner.jpg
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:49:23 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:49:24 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:50:25 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:51:02 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:51:17 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:51:17 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 14:51:17 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 14:51:17 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 14:51:17 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:51:18 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:52:50 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:52:51 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:53:14 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:53:15 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/logo.png
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:53:23 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:53:24 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:53:24 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:53:24 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:53:47 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:54:00 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:54:49 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:55:01 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:55:20 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:56:20 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:56:31 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:56:32 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:56:32 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/do.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:56:48 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:57:13 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:57:26 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:57:39 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p4.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p3.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p2.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p1.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p5.png
ERROR - 2016-02-24 14:58:33 --> 404 Page Not Found: Web/Images/p6.png
ERROR - 2016-02-24 15:00:05 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 15:00:05 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:01:13 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 15:01:13 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:01:31 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:01:31 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 15:01:52 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:01:52 --> 404 Page Not Found: Web/Images/si1.jpg
ERROR - 2016-02-24 15:02:20 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:02:33 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:03:15 --> 404 Page Not Found: Web/Images/si.jpg
ERROR - 2016-02-24 15:17:08 --> Severity: Notice --> Undefined property: Route::$data C:\xampp\htdocs\estore\application\controllers\Route.php 8
ERROR - 2016-02-24 15:18:05 --> 404 Page Not Found: store//index
ERROR - 2016-02-24 15:18:11 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 15:18:16 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 15:19:58 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 15:20:29 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 15:32:48 --> Severity: Notice --> Undefined property: W_index::$Stock_Category_Model C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 41
ERROR - 2016-02-24 15:32:48 --> Severity: Error --> Call to a member function get() on null C:\xampp\htdocs\estore\application\libraries\Web_Controller.php 41
ERROR - 2016-02-24 15:43:21 --> Severity: Notice --> Undefined variable: theme C:\xampp\htdocs\estore\application\controllers\Web\W_index.php 9
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:44:06 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:45:03 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:45:04 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:45:04 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:45:04 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:45:04 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:45:04 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:45:08 --> 404 Page Not Found: Web/W_Products/8465832931
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:45:44 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:45:56 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:49:25 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:49:42 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:49:46 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:49:47 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:49:47 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:49:47 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:49:47 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:49:47 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:55:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;STOCK_LEDGER.stock_current_price&quot; must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT &quot;STOCK_LEDGER&quot;.&quot;stock_id&quot;,&quot;STOCK_LEDGER&quot;.&quot;stock_curre...
                                         ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 15:55:31 --> Query error: ERROR:  column "STOCK_LEDGER.stock_current_price" must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: SELECT "STOCK_LEDGER"."stock_id","STOCK_LEDGER"."stock_curre...
                                         ^ - Invalid query: SELECT "STOCK_LEDGER"."stock_id","STOCK_LEDGER"."stock_current_price","t_stocks"."stock_name"
            FROM "STOCK_LEDGER"
            INNER JOIN "t_stocks" ON "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id"
            WHERE "STOCK_LEDGER"."storeid" ='1111111111'
            GROUP BY "STOCK_LEDGER"."stock_id","t_stocks"."stock_name"
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:56:17 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:57:11 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:57:14 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:57:29 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:31 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh3.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh1.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh5.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh2.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:57:32 --> 404 Page Not Found: Web/Images/sh4.png
ERROR - 2016-02-24 15:58:03 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\Products_page.php 23
ERROR - 2016-02-24 15:58:03 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\Products_page.php 23
ERROR - 2016-02-24 15:58:03 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Web\Themes\Glamour\Products_page.php 23
ERROR - 2016-02-24 15:58:03 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:58:42 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:59:09 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:59:20 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:59:50 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 15:59:53 --> 404 Page Not Found: Web/Images/sh.png
ERROR - 2016-02-24 16:04:32 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;STOCK_LEDGER&quot;
LINE 6:             GROUP BY &quot;STOCK_LEDGER&quot;.&quot;stock_id&quot;,&quot;t_stocks&quot;.&quot;s...
                              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 16:04:32 --> Query error: ERROR:  syntax error at or near "STOCK_LEDGER"
LINE 6:             GROUP BY "STOCK_LEDGER"."stock_id","t_stocks"."s...
                              ^ - Invalid query: SELECT "STOCK_LEDGER"."stock_id","STOCK_LEDGER"."stock_current_price","t_stocks"."stock_name"
            FROM "STOCK_LEDGER"
            INNER JOIN "t_stocks" ON "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id"
            WHERE "STOCK_LEDGER"."storeid" ='1111111111'
              AND "t_stocks"."stock_category_id = '8465832931' 
            GROUP BY "STOCK_LEDGER"."stock_id","t_stocks"."stock_name","STOCK_LEDGER"."stock_current_price"
            ORDER BY "t_stocks"."stock_name" ASC 
ERROR - 2016-02-24 16:04:51 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;STOCK_LEDGER&quot;
LINE 7:                 GROUP BY &quot;STOCK_LEDGER&quot;.&quot;stock_id&quot;,&quot;t_stocks...
                                  ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-24 16:04:51 --> Query error: ERROR:  syntax error at or near "STOCK_LEDGER"
LINE 7:                 GROUP BY "STOCK_LEDGER"."stock_id","t_stocks...
                                  ^ - Invalid query: SELECT "STOCK_LEDGER"."stock_id","STOCK_LEDGER"."stock_current_price","t_stocks"."stock_name"
            FROM "STOCK_LEDGER"
            INNER JOIN "t_stocks" ON "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id"
            WHERE "STOCK_LEDGER"."storeid" ='1111111111'
              AND "t_stocks"."stock_category_id = '8465832931'

                GROUP BY "STOCK_LEDGER"."stock_id","t_stocks"."stock_name","STOCK_LEDGER"."stock_current_price"
            ORDER BY "t_stocks"."stock_name" ASC 
ERROR - 2016-02-24 16:12:08 --> 404 Page Not Found: store//index
ERROR - 2016-02-24 16:12:15 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 16:12:15 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-24 16:15:58 --> 404 Page Not Found: Store/Js/classie.js
