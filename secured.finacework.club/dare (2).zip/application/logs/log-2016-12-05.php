<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-05 10:41:38 --> Severity: Notice --> Undefined variable: watwebuydollar C:\xampp\htdocs\snappycoin\application\views\web\pages\sell.php 12
ERROR - 2016-12-05 10:44:39 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:44:39 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:44:39 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:44:40 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:46:21 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:46:22 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 125
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 126
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 128
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-05 10:48:41 --> Severity: Notice --> Undefined property: stdClass::$country C:\xampp\htdocs\snappycoin\application\views\web\customer\bitcoin_address.php 129
ERROR - 2016-12-05 10:54:48 --> 404 Page Not Found: web/Settings/shipping_address
ERROR - 2016-12-05 11:19:40 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 199
ERROR - 2016-12-05 19:23:47 --> 404 Page Not Found: Settings/address
ERROR - 2016-12-05 19:34:16 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 51
ERROR - 2016-12-05 19:43:52 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 36
ERROR - 2016-12-05 19:43:52 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:43:52 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480963432
WHERE `userid` = '14675775313398tp'
AND `id` = '966ef196b266be3c1878bfe0362182a8548903be'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:45:39 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 36
ERROR - 2016-12-05 19:45:39 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:45:39 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480963539
WHERE `userid` = '14675775313398tp'
AND `id` = '966ef196b266be3c1878bfe0362182a8548903be'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:46:09 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:46:09 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480963569
WHERE `userid` = '14675775313398tp'
AND `id` = '966ef196b266be3c1878bfe0362182a8548903be'
ORDER BY `id` ASC
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:47:20 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\models\web\Message_model.php 92
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:48:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:07 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:49:58 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:46 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:50:47 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:56 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:56 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:56 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:51:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:10 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:52:37 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:53:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:02 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
ERROR - 2016-12-05 19:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 83
