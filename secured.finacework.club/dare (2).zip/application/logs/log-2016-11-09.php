<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-09 10:54:18 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-09 11:13:56 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-09 11:14:05 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-09 17:56:24 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-09 17:56:39 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-09 19:00:49 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\caroossa\application\controllers\management\Configuration.php 151
ERROR - 2016-11-09 19:00:49 --> Severity: Error --> Call to undefined method stdClass::get() C:\xampp\htdocs\caroossa\application\controllers\management\Configuration.php 152
ERROR - 2016-11-09 19:02:10 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 59
ERROR - 2016-11-09 19:02:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 59
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:08:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:45 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:45 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:46 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:46 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:10:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:04 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:04 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:05 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:05 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:11:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:16:36 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:16:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:17:21 --> Severity: Notice --> Undefined variable: brand C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:17:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\management\configuration\brand.php 105
ERROR - 2016-11-09 19:24:25 --> Query error: Table 'caroossa.tbl_faq' doesn't exist - Invalid query: SELECT *
FROM `tbl_faq`
ERROR - 2016-11-09 21:18:48 --> 404 Page Not Found: management/Franchisereport/orders
ERROR - 2016-11-09 21:31:04 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-11-09 21:31:17 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-11-09 21:31:53 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-09 21:32:07 --> Query error: Table 'caroossa.tbl_orders' doesn't exist - Invalid query: SELECT count(id) as count
FROM `tbl_orders`
WHERE datecreated between '2016-11-09 00:00:01' AND '2016-11-09 23:59:59'
AND `vendorid` = '14711890669843ss'
ORDER BY `id` desc
ERROR - 2016-11-09 21:32:08 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1478723528
WHERE datecreated between '2016-11-09 00:00:01' AND '2016-11-09 23:59:59'
AND `vendorid` = '14711890669843ss'
AND `id` = '247f9cefeea94ab19ba539a73751c9eff5a275fa'
ORDER BY `id` desc
