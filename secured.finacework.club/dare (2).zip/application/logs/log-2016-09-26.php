<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-26 13:55:34 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:55:40 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:57:17 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:57:18 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:58:03 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:58:32 --> 404 Page Not Found: app/Adminauthenticate/index
ERROR - 2016-09-26 13:59:03 --> Query error: Unknown column 'password' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE `password` = '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6'
AND `username` = 'olafashade'
ERROR - 2016-09-26 14:00:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:00:35 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:22:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:22:17 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:22:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:22:22 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:23:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:23:09 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:27:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:27:30 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:27:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:27:44 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:30:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:30:56 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:35:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:35:02 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:35:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:35:25 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:45:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:45:50 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:46:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:46:31 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:46:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:46:51 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:47:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:47:20 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:54:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:54:16 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:54:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:54:41 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 14:58:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 14:58:53 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:02:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 15:02:50 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:03:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 15:03:41 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:03:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 15:03:53 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:04:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 15:04:42 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:05:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-09-26 15:05:17 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 86
ERROR - 2016-09-26 15:46:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 124
ERROR - 2016-09-26 15:46:36 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 124
ERROR - 2016-09-26 15:46:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-26 15:46:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-26 15:46:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-26 15:46:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-26 15:46:53 --> Query error: Unknown column 'vendoruserid' in 'where clause' - Invalid query: SELECT `vendorid`
FROM `tbl_vendor_users`
WHERE `vendoruserid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-09-26 15:46:53 --> Query error: Unknown column 'vendoruserid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1474901213
WHERE `vendoruserid` IS NULL
AND `id` = '28abdb743a742bcbbfbca6bd7dc67372017dd1ea'
ORDER BY `id` ASC
ERROR - 2016-09-26 15:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-26 15:49:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-26 15:49:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-26 15:49:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-26 15:49:19 --> Query error: Unknown column 'vendoruserid' in 'where clause' - Invalid query: SELECT `vendorid`
FROM `tbl_vendor_users`
WHERE `vendoruserid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-09-26 15:49:19 --> Query error: Unknown column 'vendoruserid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1474901359
WHERE `vendoruserid` IS NULL
AND `id` = '28abdb743a742bcbbfbca6bd7dc67372017dd1ea'
ORDER BY `id` ASC
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 122
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 191
ERROR - 2016-09-26 15:50:07 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 192
ERROR - 2016-09-26 15:51:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 122
ERROR - 2016-09-26 15:51:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 191
ERROR - 2016-09-26 15:51:55 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 192
ERROR - 2016-09-26 15:52:38 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 122
ERROR - 2016-09-26 15:52:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 122
ERROR - 2016-09-26 15:52:38 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 191
ERROR - 2016-09-26 15:52:38 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 192
ERROR - 2016-09-26 17:38:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 123
ERROR - 2016-09-26 17:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 123
ERROR - 2016-09-26 17:38:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 192
ERROR - 2016-09-26 17:38:51 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 193
ERROR - 2016-09-26 18:08:45 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 131
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 100
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 101
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 102
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 103
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 131
ERROR - 2016-09-26 18:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 131
ERROR - 2016-09-26 18:11:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 200
ERROR - 2016-09-26 18:11:55 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 201
ERROR - 2016-09-26 18:13:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 200
ERROR - 2016-09-26 18:13:34 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 201
ERROR - 2016-09-26 18:14:51 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 201
ERROR - 2016-09-26 18:15:14 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 201
