<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-03 00:14:17 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\snappycoin\application\controllers\app\Orders.php 56
ERROR - 2016-12-03 00:14:24 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\snappycoin\application\controllers\app\Orders.php 56
ERROR - 2016-12-03 07:47:47 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:47:59 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:48:01 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:48:02 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:48:03 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:48:47 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 07:48:58 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 11:55:53 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 11:59:52 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 11:59:58 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 12:01:22 --> Severity: Notice --> Undefined variable: _FIlES C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 378
ERROR - 2016-12-03 12:02:53 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 12:02:58 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 12:03:30 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 12:07:25 --> The upload path does not appear to be valid.
ERROR - 2016-12-03 12:10:33 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:10:34 --> Query error: Unknown column 'file' in 'field list' - Invalid query: UPDATE `tbl_users` SET `file` = NULL, `datemodified` = '2016-12-03 12:10:34'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-03 12:11:06 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:11:06 --> Query error: Unknown column 'file' in 'field list' - Invalid query: UPDATE `tbl_users` SET `file` = NULL, `datemodified` = '2016-12-03 12:11:06'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-03 12:11:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 407
ERROR - 2016-12-03 12:11:13 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 409
ERROR - 2016-12-03 12:11:54 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:11:54 --> Query error: Unknown column 'file' in 'field list' - Invalid query: UPDATE `tbl_users` SET `file` = NULL, `datemodified` = '2016-12-03 12:11:54'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-03 12:13:44 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:13:44 --> Query error: Unknown column 'file' in 'field list' - Invalid query: UPDATE `tbl_users` SET `file` = NULL, `datemodified` = '2016-12-03 12:13:44'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-03 12:20:31 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:20:32 --> Severity: Error --> Cannot access protected property Home_model::$_primary_filter C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 396
ERROR - 2016-12-03 12:20:38 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 393
ERROR - 2016-12-03 12:20:38 --> Severity: Error --> Cannot access protected property Home_model::$_primary_filter C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 396
ERROR - 2016-12-03 12:21:31 --> Severity: Error --> Cannot access protected property Home_model::$_primary_filter C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 396
ERROR - 2016-12-03 12:22:17 --> Query error: Unknown column 'file' in 'field list' - Invalid query: UPDATE `tbl_users` SET `file` = 'http://localhost/snappycoin/resources/general/images/itemimages/2f3a53601e2b7573466a04848c3e3932.pdf', `datemodified` = '2016-12-03 12:22:17'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-03 13:48:58 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-12-03 13:48:58 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 414
ERROR - 2016-12-03 13:55:59 --> Severity: Notice --> Undefined property: stdClass::$month C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 121
ERROR - 2016-12-03 13:55:59 --> Severity: Notice --> Undefined property: stdClass::$year C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 121
