<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-25 11:25:37 --> 404 Page Not Found: Store/Js/classie.js
