<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-06 08:34:37 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\controllers\web\item.php 127
ERROR - 2016-07-06 08:34:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\item.php 96
ERROR - 2016-07-06 08:34:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:56 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:34:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:05 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-06 08:35:15 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-06 08:35:16 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-06 08:35:17 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 08:35:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:29 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:35:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:39:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:48:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:19 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:50:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 08:51:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:56 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:57 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:11:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:12:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:16:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:17:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:27:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:03 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 135
ERROR - 2016-07-06 09:40:44 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 31
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:53 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:40:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:10 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 31
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:42:12 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:10 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 31
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:14 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:15 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:17 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:18 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 31
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:58 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:45:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:42 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 127
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:50:53 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 127
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:51:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 09:53:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:29:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 11:30:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:54 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:07:55 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:13:14 --> Severity: Error --> Call to undefined method Item_model::getpackagelocation() C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 63
ERROR - 2016-07-06 12:13:40 --> Severity: Notice --> Undefined index: itemid C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 63
ERROR - 2016-07-06 12:13:40 --> Query error: Unknown column 'location' in 'field list' - Invalid query: SELECT `location`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-07-06 12:14:03 --> Query error: Unknown column 'location' in 'field list' - Invalid query: SELECT `location`
FROM `tbl_item_price`
WHERE `priceid` = '14669263110889yk'
ORDER BY `id` ASC
ERROR - 2016-07-06 12:17:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:17:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:20 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:21 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:22 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:22 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:22 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:18:22 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:19:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:09 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:10 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:22:11 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:03 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:29:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 12:30:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:27 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:34:28 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:45 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:36:59 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:37:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 13:39:58 --> Query error: Unknown column 'transactionid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`) VALUES ('14678050189601oi', '4641947936158', '14675775313398tp', '14669263110889yk', '14668222030861qv', '2626273373', NULL, 1, 200, 200, '14675836092198ly', '2016-07-06 13:39:58', '2016-07-06 13:39:58', 0)
ERROR - 2016-07-06 13:41:27 --> 404 Page Not Found: Resources/web
ERROR - 2016-07-06 13:41:27 --> 404 Page Not Found: Resources/web
ERROR - 2016-07-06 13:41:45 --> Query error: Unknown column 'transactionid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`) VALUES (NULL, NULL, '14675775313398tp', '14669263110889yk', '14668222030861qv', '2626273373', NULL, 1, 200, 200, '14675836092198ly', '2016-07-06 13:41:44', '2016-07-06 13:41:44', 0)
ERROR - 2016-07-06 14:18:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\fastfood\application\controllers\web\item.php 181
ERROR - 2016-07-06 14:19:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:38 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:19:39 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:00 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:01 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:02 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:13 --> 404 Page Not Found: Resources/web
ERROR - 2016-07-06 14:22:13 --> 404 Page Not Found: Resources/web
ERROR - 2016-07-06 14:22:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:22:37 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:04 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:24:05 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:13 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:14 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:15 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:15 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:16 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:16 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:16 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:18 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:18 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:18 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:26:18 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 165
ERROR - 2016-07-06 14:33:46 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:47 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:48 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:49 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:50 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:51 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:33:52 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:44 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-06 14:36:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:36:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:35 --> 404 Page Not Found: web/Orders/index
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:37:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:38:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:30 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:30 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:30 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:30 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:30 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:31 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:31 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:31 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-06 14:39:31 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-06 14:39:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-06 14:39:31 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:35 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:35 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:39:39 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:44 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:40:45 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:41:36 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:02 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:41 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:42:42 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-06 14:43:12 --> 404 Page Not Found: /index
ERROR - 2016-07-06 14:43:23 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:24 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:25 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 14:43:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-06 18:59:05 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-06 18:59:08 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-06 18:59:11 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-06 18:59:12 --> 404 Page Not Found: vendor/Js/classie.js
