<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-21 07:01:20 --> Severity: Error --> Call to undefined method CI_Loader::phtransactionsubmitted() C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 74
ERROR - 2017-01-21 07:09:21 --> Severity: Notice --> Undefined property: stdClass::$bitcoinaddress C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 70
ERROR - 2017-01-21 07:09:21 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:09:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:09:41 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:09:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:10:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 71
ERROR - 2017-01-21 07:10:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 72
ERROR - 2017-01-21 07:10:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 72
ERROR - 2017-01-21 07:22:13 --> Severity: Notice --> Undefined property: stdClass::$maturitydate C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 104
ERROR - 2017-01-21 07:22:13 --> Severity: Notice --> Undefined property: stdClass::$maturitydate C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 104
ERROR - 2017-01-21 09:49:10 --> Query error: Unknown column 'paymentstatus' in 'field list' - Invalid query: SELECT `paymentstatus`, `phuser`, `phrequestdate`
FROM `tbl_users`
WHERE `ghid` = '14826745916946eq'
AND `phuser` = '14675775313398tp'
ERROR - 2017-01-21 09:49:10 --> Query error: Unknown column 'ghid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484988550
WHERE `ghid` = '14826745916946eq'
AND `phuser` = '14675775313398tp'
AND `id` = '327d8a7910751a9a29e9ffed0165f2b216a2f1f0'
ERROR - 2017-01-21 09:50:25 --> Query error: Unknown column 'paymentstatus' in 'field list' - Invalid query: SELECT `paymentstatus`, `phuser`, `phrequestdate`
FROM `tbl_users`
WHERE `ghid` = '14826745916946eq'
AND `userid` = '14675775313398tp'
ERROR - 2017-01-21 09:50:25 --> Query error: Unknown column 'ghid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484988625
WHERE `ghid` = '14826745916946eq'
AND `userid` = '14675775313398tp'
AND `id` = '327d8a7910751a9a29e9ffed0165f2b216a2f1f0'
ERROR - 2017-01-21 09:50:27 --> Query error: Unknown column 'paymentstatus' in 'field list' - Invalid query: SELECT `paymentstatus`, `phuser`, `phrequestdate`
FROM `tbl_users`
WHERE `ghid` = '14826745916946eq'
AND `userid` = '14675775313398tp'
ERROR - 2017-01-21 09:50:27 --> Query error: Unknown column 'ghid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484988627
WHERE `ghid` = '14826745916946eq'
AND `userid` = '14675775313398tp'
AND `id` = '327d8a7910751a9a29e9ffed0165f2b216a2f1f0'
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 283
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 283
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 23
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 24
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 25
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$tellernumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 26
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 27
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 28
ERROR - 2017-01-21 09:50:51 --> Severity: Notice --> Undefined property: stdClass::$paymentfile C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 29
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined variable: transaction C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 23
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 24
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 25
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$tellernumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 26
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 27
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 28
ERROR - 2017-01-21 09:52:21 --> Severity: Notice --> Undefined property: stdClass::$paymentfile C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 29
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$ghid C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 23
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 24
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 25
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$tellernumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 26
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 27
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 28
ERROR - 2017-01-21 09:53:06 --> Severity: Notice --> Undefined property: stdClass::$paymentfile C:\xampp\htdocs\charity\application\views\web\customer\confirmtransaction.php 29
ERROR - 2017-01-21 10:15:25 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 10:15:26 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 10:15:26 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 10:15:26 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:16:25 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:16:26 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:16:26 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:16:26 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:17:17 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:17:17 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:17:17 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:17:17 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:17:40 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:17:40 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:17:40 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:17:40 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:18:19 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:18:19 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:18:19 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:18:19 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:18:57 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:18:57 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:18:57 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:18:58 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:19:10 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:19:10 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:19:10 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:19:10 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:19:55 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:19:55 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:19:55 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:19:55 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:19:56 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:19:56 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:19:56 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-21 13:19:56 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:29:14 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:29:14 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:29:14 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:31:34 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:31:34 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:31:35 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:31:54 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:31:54 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:31:54 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:32:52 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:32:52 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:32:52 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:33:38 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:33:38 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:33:39 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:34:43 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:34:43 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:34:43 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:35:24 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:35:24 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:35:24 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:35:48 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:35:48 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:35:48 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:36:37 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:36:37 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:36:37 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:36:50 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:36:50 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:36:50 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:37:00 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:37:00 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:37:00 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:37:32 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:37:32 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:37:33 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:37:52 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:37:53 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:37:53 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:39:07 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:39:07 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:39:07 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:41:04 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:41:04 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:41:04 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:54:45 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:54:45 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:54:45 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:54:51 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:54:51 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:54:51 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:54:58 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:54:59 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:54:59 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:55:12 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:55:12 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:55:12 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:56:32 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:56:32 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 13:56:32 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:57:04 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 13:57:05 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 13:57:05 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:10:52 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:10:52 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:10:52 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:11:12 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:11:12 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:11:12 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:12:41 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:12:41 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:12:41 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:13:20 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:13:20 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:13:20 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:15:21 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:15:21 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:15:21 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:20:18 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:20:18 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:20:18 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:25:50 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:25:50 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:25:51 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:26:06 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:26:06 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:26:06 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:26:27 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:26:27 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:26:27 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:27:57 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:27:58 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:27:58 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-21 15:27:58 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:31:07 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:31:07 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:31:40 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:31:40 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:35:22 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:35:22 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:35:58 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:35:58 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:36:10 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:36:10 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:38:21 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:38:21 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:38:43 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:38:43 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:38:44 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:38:44 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:40:56 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:40:56 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:41:28 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:41:28 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:43:20 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:43:20 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:44:29 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:44:30 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:44:40 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:44:40 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:46:33 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:46:33 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:46:49 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:46:49 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:51:12 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:51:12 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:53:12 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:53:12 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:53:25 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:53:25 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:54:17 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:54:17 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:56:19 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:56:19 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:57:11 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:57:11 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:57:29 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:57:29 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:57:48 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:57:48 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:58:00 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:58:00 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:58:24 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:58:25 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:58:50 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:58:50 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:59:23 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:59:23 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:59:44 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:59:44 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 15:59:59 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 15:59:59 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 16:01:38 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 16:01:38 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 16:02:03 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-21 16:02:03 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-21 18:14:12 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\charity\application\controllers\web\Auth.php 99
ERROR - 2017-01-21 18:14:12 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\charity\application\controllers\web\Auth.php 102
ERROR - 2017-01-21 18:36:00 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:36:00 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:37:11 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:37:11 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:37:32 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:37:32 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:37:36 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:37:36 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:37:36 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:37:36 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:37:53 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:37:53 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:38:17 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:38:17 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:38:20 --> Severity: Warning --> Missing argument 1 for Ref::index() C:\xampp\htdocs\charity\application\controllers\web\Ref.php 9
ERROR - 2017-01-21 18:38:20 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\web\Ref.php 10
ERROR - 2017-01-21 18:43:48 --> 404 Page Not Found: Ref/u
ERROR - 2017-01-21 18:44:03 --> 404 Page Not Found: Ref/u
ERROR - 2017-01-21 18:44:26 --> 404 Page Not Found: Ref/u
ERROR - 2017-01-21 18:44:36 --> 404 Page Not Found: Ref/uxx
ERROR - 2017-01-21 18:47:07 --> 404 Page Not Found: web/Ref/index
ERROR - 2017-01-21 18:49:07 --> 404 Page Not Found: web/User/settings
ERROR - 2017-01-21 19:17:13 --> Severity: Error --> Call to undefined method CI_Session::set_flasdata() C:\xampp\htdocs\charity\application\controllers\web\Auth.php 82
ERROR - 2017-01-21 21:36:29 --> 404 Page Not Found: web/Faq/index
ERROR - 2017-01-21 23:35:43 --> Severity: Parsing Error --> syntax error, unexpected '||' (T_BOOLEAN_OR) C:\xampp\htdocs\charity\application\controllers\web\User.php 11
