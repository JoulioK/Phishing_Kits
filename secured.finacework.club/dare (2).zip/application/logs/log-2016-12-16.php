<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-16 14:00:22 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-16 14:02:01 --> Severity: error --> Exception: Needed .pem file not found. Please download the .pem file at http://curl.haxx.se/ca/cacert.pem and save it as C:\xampp\htdocs\snappycoin\application\libraries\cacert.pem C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 78
ERROR - 2016-12-16 16:04:54 --> Severity: error --> Exception: Needed .pem file not found. Please download the .pem file at http://curl.haxx.se/ca/cacert.pem and save it as C:\xampp\htdocs\snappycoin\application\libraries\cacert.pem C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 78
