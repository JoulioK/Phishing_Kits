<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-23 09:00:28 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-23 09:00:35 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-23 09:00:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:00:50 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-23 09:00:54 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-23 09:01:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:01:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:02:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:02:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:03:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:05:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:05:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:06:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:06:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:14:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:20:06 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\estore\application\controllers\Store\Expenses.php 24
ERROR - 2016-02-23 09:20:06 --> Severity: Notice --> Undefined index: rules C:\xampp\htdocs\estore\application\controllers\Store\Expenses.php 24
ERROR - 2016-02-23 09:20:06 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; = '1111111111'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:20:06 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" = '1111111111'
              ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 09:20:26 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; = '1111111111'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:20:26 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" = '1111111111'
              ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 09:21:02 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; = '1111111111'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:21:02 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" = '1111111111'
              ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 09:21:17 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_store_expenses&quot; does not exist
LINE 2: FROM &quot;t_store_expenses&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:21:17 --> Query error: ERROR:  relation "t_store_expenses" does not exist
LINE 2: FROM "t_store_expenses"
             ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 20
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 28
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 32
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 36
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 42
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 52
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 52
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:23 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined property: stdClass::$expensename C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 20
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 28
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 32
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 36
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 42
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 52
ERROR - 2016-02-23 09:21:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 52
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 55
ERROR - 2016-02-23 09:21:51 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 56
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 57
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 58
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:52 --> Severity: Notice --> Undefined variable: expense_privilege C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Expenses\Expenses_page.php 59
ERROR - 2016-02-23 09:21:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:26:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:32:15 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:34:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\estore\application\migrations\011_Add_Store_Expenses_Table.php 45
ERROR - 2016-02-23 09:35:27 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;entryid&quot; violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, ESWAMA BILL, ESWAMA BILL, ESWAMA, 20000.00, 2016-02-23, , 2222222222). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:35:27 --> Query error: ERROR:  null value in column "entryid" violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, ESWAMA BILL, ESWAMA BILL, ESWAMA, 20000.00, 2016-02-23, , 2222222222). - Invalid query: INSERT INTO "t_store_expenses" ("expenses_title", "expenses_details", "expense_recepient", "expense_amount", "expense_datemade", "expense_additional_info", "storeid", "added_by") VALUES ('ESWAMA BILL', 'ESWAMA BILL', 'ESWAMA', '20000', '2016-02-23', '', '1111111111', '2222222222')
ERROR - 2016-02-23 09:36:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:39:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:40:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:40:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:40:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:40:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:41:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:41:40 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 53
ERROR - 2016-02-23 09:41:41 --> Severity: Notice --> Undefined property: stdClass::$expensename C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 56
ERROR - 2016-02-23 09:41:41 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 59
ERROR - 2016-02-23 09:41:41 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 62
ERROR - 2016-02-23 09:41:41 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 65
ERROR - 2016-02-23 09:41:41 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 66
ERROR - 2016-02-23 09:41:41 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:42:56 --> Severity: Notice --> Undefined property: stdClass::$expense_name C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 59
ERROR - 2016-02-23 09:42:56 --> Severity: Notice --> Undefined property: stdClass::$expense_details C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 62
ERROR - 2016-02-23 09:42:56 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 68
ERROR - 2016-02-23 09:42:56 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 71
ERROR - 2016-02-23 09:42:56 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 72
ERROR - 2016-02-23 09:42:56 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:43:14 --> Severity: Notice --> Undefined property: stdClass::$expense_title C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 59
ERROR - 2016-02-23 09:43:14 --> Severity: Notice --> Undefined property: stdClass::$expense_details C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 62
ERROR - 2016-02-23 09:43:14 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 68
ERROR - 2016-02-23 09:43:14 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 71
ERROR - 2016-02-23 09:43:14 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 72
ERROR - 2016-02-23 09:43:14 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:44:06 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:44:46 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_store_expenses&quot; does not exist
LINE 2: FROM &quot;t_store_expenses&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:44:46 --> Query error: ERROR:  relation "t_store_expenses" does not exist
LINE 2: FROM "t_store_expenses"
             ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 09:44:56 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:45:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:46:11 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:46:26 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:46:36 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:46:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:47:02 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:47:11 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:47:28 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;expenses_title&quot; of relation &quot;t_store_expenses&quot; does not exist
LINE 1: INSERT INTO &quot;t_store_expenses&quot; (&quot;expenses_title&quot;, &quot;expenses_...
                                        ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 09:47:28 --> Query error: ERROR:  column "expenses_title" of relation "t_store_expenses" does not exist
LINE 1: INSERT INTO "t_store_expenses" ("expenses_title", "expenses_...
                                        ^ - Invalid query: INSERT INTO "t_store_expenses" ("expenses_title", "expenses_details", "expense_recepient", "expense_amount", "expense_datemade", "expense_additional_info", "storeid", "entryid", "added_by") VALUES ('ESWAMA BILL', 'ESWAMA BILL', 'ESWAMA', '2000', '2016-02-23', 'ESWAMA', '1111111111', '7412156852', '2222222222')
ERROR - 2016-02-23 09:48:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:49:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 09:49:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:49:19 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:49:30 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 66
ERROR - 2016-02-23 09:49:30 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 69
ERROR - 2016-02-23 09:49:30 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 70
ERROR - 2016-02-23 09:49:30 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:50:22 --> Severity: Notice --> Undefined property: stdClass::$expense_receipient C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 65
ERROR - 2016-02-23 09:50:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 68
ERROR - 2016-02-23 09:50:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 71
ERROR - 2016-02-23 09:50:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 72
ERROR - 2016-02-23 09:50:25 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:50:38 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 68
ERROR - 2016-02-23 09:50:38 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 71
ERROR - 2016-02-23 09:50:38 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Store\Expenses\View_expenses_page.php 72
ERROR - 2016-02-23 09:50:40 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:51:21 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:51:55 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:52:34 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:53:07 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:53:21 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 09:53:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:25:36 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:25:45 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:26:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:26:29 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:27:14 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 10:28:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:01:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:01:42 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:02:23 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:02:47 --> 404 Page Not Found: Store/Expenses/Expenses
ERROR - 2016-02-23 11:03:00 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:03:18 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:03:24 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniqueid&quot; does not exist
LINE 4: AND &quot;uniqueid&quot; = '9974540643'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:03:24 --> Query error: ERROR:  column "uniqueid" does not exist
LINE 4: AND "uniqueid" = '9974540643'
            ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "uniqueid" = '9974540643'
AND "t_store_expenses"."storeid" = '1111111111'
AND "id" = '1'
ORDER BY "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:03:39 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:03:39 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-23 11:03:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:03:50 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:04:13 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:04:13 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-23 11:04:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:04:21 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:05:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:06:17 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:06:26 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:09:17 --> Severity: Error --> Call to undefined function data() C:\xampp\htdocs\estore\application\views\Store\Expenses\Expense_summary_page.php 11
ERROR - 2016-02-23 11:09:18 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:09:34 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:10:20 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:10:35 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:11:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:11:26 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:12:09 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:12:40 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:13:00 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:13:46 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:14:06 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:14:31 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:14:57 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:16:07 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:16:35 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:17:27 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:17:58 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:20:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:21:01 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:21:04 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character varying &gt;= integer
LINE 3: WHERE expense_datemade BETWEEN 2016-02-23 AND 2016-02-23
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:21:04 --> Query error: ERROR:  operator does not exist: character varying >= integer
LINE 3: WHERE expense_datemade BETWEEN 2016-02-23 AND 2016-02-23
                               ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE expense_datemade BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:21:46 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character &gt;= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:21:46 --> Query error: ERROR:  operator does not exist: character >= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:22:06 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character &gt;= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:22:06 --> Query error: ERROR:  operator does not exist: character >= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:22:11 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character &gt;= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:22:11 --> Query error: ERROR:  operator does not exist: character >= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:22:39 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character &gt;= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:22:39 --> Query error: ERROR:  operator does not exist: character >= integer
LINE 3: WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND ...
                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as CHAR) BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:23:10 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF), expecting ',' or ';' C:\xampp\htdocs\estore\application\controllers\Store\Expenses.php 103
ERROR - 2016-02-23 11:23:24 --> Severity: Warning --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;2016-02-23&quot; C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:23:24 --> Query error: ERROR:  invalid input syntax for integer: "2016-02-23" - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as INT) BETWEEN 2016-02-23 AND 2016-02-23
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:27:02 --> Severity: Warning --> pg_query(): Query failed: ERROR:  cannot cast type integer to date
LINE 3: WHERE CAST(expense_datemade as DATE) BETWEEN CAST(2016-02-23...
                                                     ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:27:02 --> Query error: ERROR:  cannot cast type integer to date
LINE 3: WHERE CAST(expense_datemade as DATE) BETWEEN CAST(2016-02-23...
                                                     ^ - Invalid query: SELECT *
FROM "t_store_expenses"
WHERE CAST(expense_datemade as DATE) BETWEEN CAST(2016-02-23 as date) AND CAST(2016-02-23 as date)
AND "storeid" = '1111111111'
AND "t_store_expenses"."storeid" = '1111111111'
ORDER BY "expense_datemade" DESC, "t_store_expenses"."id" ASC
ERROR - 2016-02-23 11:28:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:32:13 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:32:20 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:32:28 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:32:50 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:33:36 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:33:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:34:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 11:34:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:34:08 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:34:17 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:35:34 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:35:52 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:36:47 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:36:50 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:36:54 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:36:57 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:37:06 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:37:22 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:37:28 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:39:55 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:40:24 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:40:31 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:41:05 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:41:45 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:42:02 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:42:38 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:43:04 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:43:06 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:43:29 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:43:45 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:44:24 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = '9974540643'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 11:44:24 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = '9974540643'
            ^ - Invalid query: DELETE FROM "t_store_expenses"
WHERE "storeid" = '1111111111'
AND "uniquekey" = '9974540643'
AND "id" = 1
ERROR - 2016-02-23 11:45:19 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:45:25 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:45:56 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:46:16 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:46:43 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:47:34 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:48:21 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:48:27 --> 404 Page Not Found: Store/View_Expenses/index
ERROR - 2016-02-23 11:48:41 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:49:10 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:49:37 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 11:52:06 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 13:05:11 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 13:05:15 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 13:12:32 --> 404 Page Not Found: Store/Expenses/images
ERROR - 2016-02-23 13:12:49 --> 404 Page Not Found: Store/Incomes/index
ERROR - 2016-02-23 13:14:43 --> Severity: Notice --> Undefined property: Incomes::$Store_Incomes_Model C:\xampp\htdocs\estore\application\controllers\Store\Incomes.php 38
ERROR - 2016-02-23 13:14:43 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Incomes.php 38
ERROR - 2016-02-23 13:17:52 --> Severity: Notice --> Undefined property: Incomes::$Store_Incomes_Model C:\xampp\htdocs\estore\application\controllers\Store\Incomes.php 38
ERROR - 2016-02-23 13:17:52 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Incomes.php 38
ERROR - 2016-02-23 13:18:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 18
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 18
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 22
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 22
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 27
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 27
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 31
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 31
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 35
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 35
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 40
ERROR - 2016-02-23 13:19:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Incomes\Incomes_page.php 40
ERROR - 2016-02-23 13:19:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:20:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:20:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:20:41 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_datemade C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 56
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_title C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 59
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_details C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 62
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_amount C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 65
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_amount C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 66
ERROR - 2016-02-23 13:21:18 --> Severity: Notice --> Undefined property: stdClass::$expense_recepient C:\xampp\htdocs\estore\application\views\Store\Incomes\View_incomes_page.php 71
ERROR - 2016-02-23 13:21:22 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:22:03 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:22:29 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:22:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:22:45 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:22:50 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_datemade C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 65
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_title C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 68
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_details C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 71
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_amount C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 74
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_amount C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 75
ERROR - 2016-02-23 13:23:36 --> Severity: Notice --> Undefined property: stdClass::$expense_recepient C:\xampp\htdocs\estore\application\views\Store\Incomes\Income_summary_page.php 80
ERROR - 2016-02-23 13:23:36 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:24:07 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:24:25 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:25:00 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:25:05 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:25:09 --> 404 Page Not Found: Store/Incomes/images
ERROR - 2016-02-23 13:25:56 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:30:55 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:31:13 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:31:25 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:32:16 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:32:36 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:32:54 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-23 13:33:06 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column t_stores.storeid does not exist
LINE 3: WHERE &quot;t_stores&quot;.&quot;storeid&quot; = '1111111111'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 13:33:06 --> Query error: ERROR:  column t_stores.storeid does not exist
LINE 3: WHERE "t_stores"."storeid" = '1111111111'
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "t_stores"."storeid" = '1111111111'
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 20
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 20
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 28
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 28
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 37
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 37
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 42
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 42
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 52
ERROR - 2016-02-23 13:36:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 52
ERROR - 2016-02-23 13:36:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 20
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:06 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:07 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 24
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 32
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:38:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 41
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 46
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 50
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Undefined variable: store C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:40:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Config\Store_page.php 56
ERROR - 2016-02-23 13:40:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:40:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:41:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:41:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:47:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:48:13 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;storeid&quot; violates not-null constraint
DETAIL:  Failing row contains (5, null, PLAYHOUSE STORES ENUGU,NIGERIA, http://playhouse.local, platform@platform.com, 070667193, ENUGU, null, null, 2016-02-23 12:48:13.713, 2016-02-23 12:48:13.713). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 13:48:13 --> Query error: ERROR:  null value in column "storeid" violates not-null constraint
DETAIL:  Failing row contains (5, null, PLAYHOUSE STORES ENUGU,NIGERIA, http://playhouse.local, platform@platform.com, 070667193, ENUGU, null, null, 2016-02-23 12:48:13.713, 2016-02-23 12:48:13.713). - Invalid query: INSERT INTO "t_stores" ("store_name", "store_url", "store_email", "store_phone", "store_address") VALUES ('PLAYHOUSE STORES ENUGU,NIGERIA', 'http://playhouse.local', 'platform@platform.com', '070667193', 'ENUGU')
ERROR - 2016-02-23 13:48:59 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 51
ERROR - 2016-02-23 13:48:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 51
ERROR - 2016-02-23 13:48:59 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;storeid&quot; violates not-null constraint
DETAIL:  Failing row contains (6, null, PLAYHOUSE STORES ENUGU,NIGERIA, http://playhouse.local, platform@platform.com, 070667193, ENUGU, null, null, 2016-02-23 12:48:59.109, 2016-02-23 12:48:59.109). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-23 13:48:59 --> Query error: ERROR:  null value in column "storeid" violates not-null constraint
DETAIL:  Failing row contains (6, null, PLAYHOUSE STORES ENUGU,NIGERIA, http://playhouse.local, platform@platform.com, 070667193, ENUGU, null, null, 2016-02-23 12:48:59.109, 2016-02-23 12:48:59.109). - Invalid query: INSERT INTO "t_stores" ("store_name", "store_url", "store_email", "store_phone", "store_address") VALUES ('PLAYHOUSE STORES ENUGU,NIGERIA', 'http://playhouse.local', 'platform@platform.com', '070667193', 'ENUGU')
ERROR - 2016-02-23 13:49:10 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-23 13:49:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:49:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:49:45 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 48
ERROR - 2016-02-23 13:49:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:52:39 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\estore\application\controllers\Store\Configuration.php 31
ERROR - 2016-02-23 13:53:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:53:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:54:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:54:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:54:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:54:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:55:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 13:56:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 15:14:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 15:19:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-23 15:39:18 --> 404 Page Not Found: Store/Images/a.png
