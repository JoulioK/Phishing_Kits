<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-01 10:03:22 --> 404 Page Not Found: Img/grubhub
ERROR - 2016-09-01 10:03:30 --> 404 Page Not Found: Img/grubhub
ERROR - 2016-09-01 15:59:38 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-01 16:00:18 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-01 16:01:13 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-01 16:02:57 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-01 16:03:22 --> 404 Page Not Found: web/Resources/web
