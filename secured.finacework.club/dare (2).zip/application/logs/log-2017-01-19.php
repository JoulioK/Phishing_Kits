<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-19 09:03:52 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 09:04:02 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-19 09:04:03 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484813043
WHERE `id` = '0a2cfa31bb9599312abb22955b54f316406e84d2'
ORDER BY `bankname` ASC
ERROR - 2017-01-19 09:04:29 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484813069
WHERE `userid` != '14675775313398tp'
AND `id` = '0a2cfa31bb9599312abb22955b54f316406e84d2'
ERROR - 2017-01-19 09:06:19 --> Severity: Notice --> Undefined property: stdClass::$bitcoinaddress C:\xampp\htdocs\charity\application\views\web\customer\profile.php 37
ERROR - 2017-01-19 09:11:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\profile.php 18
ERROR - 2017-01-19 09:11:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\profile.php 18
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:16:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:17:50 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-19 12:17:50 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484824670
WHERE `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ORDER BY `bankname` ASC
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:19:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 12:28:18 --> 404 Page Not Found: web/User/settings
ERROR - 2017-01-19 12:32:10 --> 404 Page Not Found: web/Refferal/index
ERROR - 2017-01-19 13:28:14 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-19 13:28:14 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484828894
WHERE `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ORDER BY `bankname` ASC
ERROR - 2017-01-19 13:29:06 --> 404 Page Not Found: web/Settings/profile
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 13:30:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:02 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 14:03:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 16:29:37 --> Severity: Parsing Error --> syntax error, unexpected 'H' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 63
ERROR - 2017-01-19 16:29:39 --> Severity: Parsing Error --> syntax error, unexpected 'H' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 63
ERROR - 2017-01-19 16:36:43 --> Severity: Parsing Error --> syntax error, unexpected 'H' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 71
ERROR - 2017-01-19 16:38:20 --> Severity: Parsing Error --> syntax error, unexpected 'H' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 72
ERROR - 2017-01-19 16:39:06 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 75
ERROR - 2017-01-19 16:39:14 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 73
ERROR - 2017-01-19 16:39:14 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 54
ERROR - 2017-01-19 16:39:36 --> Severity: Error --> Call to a member function format() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 72
ERROR - 2017-01-19 16:41:27 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 73
ERROR - 2017-01-19 16:41:27 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 54
ERROR - 2017-01-19 16:41:49 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 70
ERROR - 2017-01-19 16:42:28 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 71
ERROR - 2017-01-19 16:43:30 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 71
ERROR - 2017-01-19 16:44:06 --> Severity: Warning --> DateTime::modify(): Failed to parse time string (7) at position 0 (7): Unexpected character C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 71
ERROR - 2017-01-19 17:09:34 --> Severity: Notice --> Undefined index: HTTP_X_FORWARDED_FOR C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 49
ERROR - 2017-01-19 17:10:12 --> Severity: Notice --> Undefined index: timezone C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 51
ERROR - 2017-01-19 17:10:33 --> Severity: Notice --> Undefined index: timezone C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 51
ERROR - 2017-01-19 17:10:45 --> Severity: Notice --> Undefined index: timezone C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 51
ERROR - 2017-01-19 17:44:35 --> Severity: Parsing Error --> syntax error, unexpected '$user' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\charity\application\views\web\customer\profile.php 95
ERROR - 2017-01-19 17:46:31 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844391, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:47:16 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844436, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:48:29 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844509, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:51:28 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844688, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:51:59 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844719, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:54:35 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844875, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 17:55:03 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484844903, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 09:08:18\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = '90eee4be323b9cc672dd0669bd123348c9dbab4f'
ERROR - 2017-01-19 18:33:18 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:33:54 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:34:11 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:34:58 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:35:46 --> Severity: Error --> Call to undefined method CI_Loader::convert_from_another_time() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:36:40 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:36:40 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:38:09 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:38:09 --> Severity: 4096 --> Object of class DateTime could not be converted to string C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 18:39:03 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 18:39:20 --> Severity: Notice --> Undefined variable: target C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 30
ERROR - 2017-01-19 18:41:40 --> Severity: Error --> Cannot use object of type DateTime as array C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 31
ERROR - 2017-01-19 18:42:51 --> Severity: Notice --> Undefined property: DateTime::$date C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 31
ERROR - 2017-01-19 18:42:51 --> Severity: Notice --> Undefined property: DateTime::$date C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 31
ERROR - 2017-01-19 18:47:01 --> Severity: Parsing Error --> syntax error, unexpected '" - "' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 113
ERROR - 2017-01-19 19:42:49 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 123
ERROR - 2017-01-19 19:44:43 --> Severity: Parsing Error --> syntax error, unexpected 'exit' (T_EXIT) C:\xampp\htdocs\charity\application\views\web\customer\ph.php 129
ERROR - 2017-01-19 19:46:39 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 128
ERROR - 2017-01-19 20:59:34 --> Severity: Notice --> Undefined variable: rules C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 27
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:12:18 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:12:18 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:12:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:14:25 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:14:25 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:14:26 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:14:49 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:14:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:14:49 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:14:50 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:14:50 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:14:50 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:06 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:06 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:29 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:30 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:53 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:15:54 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:15:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:16:04 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:16:05 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:16:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:17:41 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:17:41 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:17:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:18:02 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:02 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:18:03 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:18:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:20:01 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:20:02 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:20:49 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:20:49 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:20:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:22:00 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:22:00 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:22:11 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:22:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:22:11 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:22:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:22:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:22:12 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:22:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:23:29 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:23:29 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:23:54 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:23:54 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:23:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:24:09 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:24:09 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:24:35 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:24:35 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:25:22 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-19 21:25:22 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-19 21:25:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
