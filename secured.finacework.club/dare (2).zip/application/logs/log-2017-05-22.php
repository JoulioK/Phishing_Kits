<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 117
ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 117
ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:21:18 --> Severity: Notice --> Undefined property: stdClass::$profitmargin C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 117
ERROR - 2017-05-22 23:22:43 --> Severity: Notice --> Undefined property: stdClass::$profit C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:22:43 --> Severity: Notice --> Undefined property: stdClass::$profit C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:22:43 --> Severity: Notice --> Undefined property: stdClass::$profit C:\xampp\htdocs\coinxtra\application\views\web\pages\home.php 102
ERROR - 2017-05-22 23:24:37 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given C:\xampp\htdocs\coinxtra\application\controllers\web\Home.php 49
ERROR - 2017-05-22 23:24:40 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given C:\xampp\htdocs\coinxtra\application\controllers\web\Home.php 49
ERROR - 2017-05-22 23:24:41 --> Severity: Warning --> json_decode() expects parameter 1 to be string, object given C:\xampp\htdocs\coinxtra\application\controllers\web\Home.php 49
