<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-07 07:22:14 --> 404 Page Not Found: Faviconico/index
