<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-29 16:36:29 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 16:46:41 --> 404 Page Not Found: web/Sell/address
ERROR - 2016-11-29 16:47:37 --> 404 Page Not Found: web/Item/cart
ERROR - 2016-11-29 16:51:03 --> 404 Page Not Found: web/Sell/address
ERROR - 2016-11-29 16:52:04 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 51
ERROR - 2016-11-29 16:52:05 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 53
ERROR - 2016-11-29 16:52:48 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 16:52:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 16:54:01 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 16:54:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:01:34 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:01:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:52:43 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:52:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:52:53 --> Severity: Parsing Error --> syntax error, unexpected 'account' (T_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\web\Settings.php 152
ERROR - 2016-11-29 17:53:33 --> Severity: Notice --> Undefined variable: addressid C:\xampp\htdocs\snappycoin\application\controllers\web\Settings.php 211
ERROR - 2016-11-29 17:55:43 --> 404 Page Not Found: Hub/customer
ERROR - 2016-11-29 17:58:15 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:58:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:58:54 --> Severity: Notice --> Undefined variable: addresses C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 17:58:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\confirmaccount.php 26
ERROR - 2016-11-29 18:06:03 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `tbl_users`.`userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-29 18:06:04 --> Query error: Unknown column 'tbl_users.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480439164
WHERE `tbl_users`.`userid` = '14675775313398tp'
AND `id` = 'a367b6d50da595684c96f439d9e4380012ab9577'
ORDER BY `id` ASC
ERROR - 2016-11-29 18:10:41 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 18:10:57 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 18:10:57 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 18:11:43 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 18:11:43 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-29 19:40:16 --> 404 Page Not Found: web/Sell/transferbitcoin
ERROR - 2016-11-29 20:40:55 --> Severity: Notice --> Undefined variable: bitcoin C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 26
ERROR - 2016-11-29 20:40:55 --> Severity: Notice --> Undefined variable: bitcoin C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 34
ERROR - 2016-11-29 20:41:49 --> Severity: Notice --> Undefined variable: bitcoin C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 26
ERROR - 2016-11-29 20:41:49 --> Severity: Notice --> Undefined variable: bitcoin C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 34
