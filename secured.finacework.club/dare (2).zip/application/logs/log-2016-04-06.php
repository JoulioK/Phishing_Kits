<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-06 09:13:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-04-06 09:13:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-04-06 09:13:23 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-04-06 09:13:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-04-06 09:32:18 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-04-06 09:32:19 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-04-06 09:33:19 --> 404 Page Not Found: Super/Authenticate
ERROR - 2016-04-06 09:34:18 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\libraries\Store_Controller.php 58
ERROR - 2016-04-06 09:34:19 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\libraries\Store_Controller.php 75
ERROR - 2016-04-06 09:34:19 --> 404 Page Not Found: Store/Authenticate
ERROR - 2016-04-06 09:34:24 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\libraries\Store_Controller.php 58
ERROR - 2016-04-06 09:34:24 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\libraries\Store_Controller.php 75
ERROR - 2016-04-06 09:34:24 --> 404 Page Not Found: Store/Authenticate
ERROR - 2016-04-06 09:34:28 --> 404 Page Not Found: Store/Authenticate
ERROR - 2016-04-06 09:35:12 --> 404 Page Not Found: Super/Authenticate
ERROR - 2016-04-06 09:36:02 --> 404 Page Not Found: Super/Authenticate
ERROR - 2016-04-06 09:48:08 --> Severity: Notice --> Undefined property: Authenticate::$Store_User_model C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:48:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:48:08 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:48:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:48:09 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:49:42 --> Severity: Notice --> Undefined property: Authenticate::$Store_User_model C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:49:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:49:42 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:49:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:49:42 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:50:10 --> Severity: Notice --> Undefined property: Authenticate::$Admin_User_model C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:50:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 9
ERROR - 2016-04-06 09:50:10 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:50:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:50:11 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:50:37 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:50:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Store\login_page.php 27
ERROR - 2016-04-06 09:50:37 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:51:51 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Admin\login_page.php 27
ERROR - 2016-04-06 09:51:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Admin\login_page.php 27
ERROR - 2016-04-06 09:51:52 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:52:13 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-06 09:52:13 --> 404 Page Not Found: Admin/Js/classie.js
