<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-08 19:09:59 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:19:18 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:20:42 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:21:22 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:21:46 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:23:40 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:23:58 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:24:25 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:24:36 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:26:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:28:08 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:30:09 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:32:38 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:33:03 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:33:05 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:33:08 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:47:08 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:56:13 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:56:38 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:57:40 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:59:28 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 19:59:54 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:00:46 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:00:52 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:28:35 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:29:04 --> 404 Page Not Found: web/Authenticate/resources
ERROR - 2016-09-08 20:29:17 --> 404 Page Not Found: web/Authenticate/resources
ERROR - 2016-09-08 20:29:30 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:30:32 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:34:56 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:37:08 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 20:37:17 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-09-08 20:38:20 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:38:40 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:38:44 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:38:52 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:46:55 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:47:10 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:48:06 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 20:48:37 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 21:25:26 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-08 22:08:45 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 22:13:03 --> 404 Page Not Found: web/Authenticate/resources
ERROR - 2016-09-08 22:13:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-08 22:13:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-08 22:13:20 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:13:31 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:35:32 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:35:37 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 202
ERROR - 2016-09-08 22:35:37 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 247
ERROR - 2016-09-08 22:37:56 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 22:38:05 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 22:38:32 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:38:38 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 202
ERROR - 2016-09-08 22:38:38 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 248
ERROR - 2016-09-08 22:46:30 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-08 22:46:49 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:46:58 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:47:47 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:50:09 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:50:18 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:59:21 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-08 22:59:58 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-08 22:59:58 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-08 23:23:39 --> 404 Page Not Found: management/Delivery/statistics
