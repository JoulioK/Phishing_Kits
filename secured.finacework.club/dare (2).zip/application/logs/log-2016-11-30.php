<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-30 10:01:11 --> Severity: 4096 --> Object of class Sell could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 73
ERROR - 2016-11-30 10:01:12 --> Severity: Notice --> Object of class Sell to string conversion C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 73
ERROR - 2016-11-30 10:01:13 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 26
ERROR - 2016-11-30 10:01:13 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 34
ERROR - 2016-11-30 10:01:13 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-11-30 10:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 38
ERROR - 2016-11-30 10:01:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 40
ERROR - 2016-11-30 10:02:16 --> 404 Page Not Found: web/Customer/orders
ERROR - 2016-11-30 11:07:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Item_model.php 104
ERROR - 2016-11-30 11:07:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Item_model.php 104
ERROR - 2016-11-30 11:07:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Item_model.php 104
ERROR - 2016-11-30 12:23:35 --> Severity: Parsing Error --> syntax error, unexpected '$config_item' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\snappycoin\application\views\web\customer\orders.php 30
ERROR - 2016-11-30 12:23:59 --> Severity: Notice --> Undefined variable: config_item C:\xampp\htdocs\snappycoin\application\views\web\customer\orders.php 30
ERROR - 2016-11-30 12:23:59 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\snappycoin\application\views\web\customer\orders.php 30
ERROR - 2016-11-30 17:18:51 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:18:51 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:18:57 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:19:14 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:19:22 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:22:52 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:22:52 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:22:54 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:23:48 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:23:48 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:23:50 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:25:54 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:25:54 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:25:56 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:26:10 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:26:10 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:26:13 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:26:35 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:26:35 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:26:37 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 17:28:18 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 17:28:18 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 17:28:22 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 19:28:46 --> 404 Page Not Found: web/Receipt/index
ERROR - 2016-11-30 19:35:32 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 110
ERROR - 2016-11-30 19:37:28 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 19:37:28 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 19:40:46 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 19:40:46 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 19:41:00 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 85
ERROR - 2016-11-30 19:41:00 --> Severity: Notice --> Undefined index: naira C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 86
ERROR - 2016-11-30 20:48:59 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 169
ERROR - 2016-11-30 20:49:28 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `transactionid` = '14805312235926qe'
ERROR - 2016-11-30 20:49:28 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480535368, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:9:\"firstname\";s:3:\"Ola\";s:8:\"lastname\";s:4:\"Gcfr\";s:12:\"emailaddress\";N;s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:0:\"\";s:11:\"accountname\";s:11:\"Ola Fashade\";s:13:\"accountnumber\";s:10:\"1303603985\";s:6:\"bankid\";s:9:\"489484940\";s:8:\"identity\";N;s:10:\"expirydate\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2016-11-29 17:58:53\";}user_loggedin|b:1;'
WHERE `transactionid` = '14805312235926qe'
AND `id` = 'aeb93dead0383db79193ac893da84b9027360deb'
ERROR - 2016-11-30 20:50:13 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `transactionid` = '14805312235926qe'
ERROR - 2016-11-30 20:50:13 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480535413, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:9:\"firstname\";s:3:\"Ola\";s:8:\"lastname\";s:4:\"Gcfr\";s:12:\"emailaddress\";N;s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:0:\"\";s:11:\"accountname\";s:11:\"Ola Fashade\";s:13:\"accountnumber\";s:10:\"1303603985\";s:6:\"bankid\";s:9:\"489484940\";s:8:\"identity\";N;s:10:\"expirydate\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2016-11-29 17:58:53\";}user_loggedin|b:1;'
WHERE `transactionid` = '14805312235926qe'
AND `id` = 'aeb93dead0383db79193ac893da84b9027360deb'
ERROR - 2016-11-30 20:50:33 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 166
ERROR - 2016-11-30 20:50:33 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `transactionid` = '14805312235926qe'
ERROR - 2016-11-30 20:50:33 --> Query error: Unknown column 'transactionid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480535433, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":17:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:9:\"firstname\";s:3:\"Ola\";s:8:\"lastname\";s:4:\"Gcfr\";s:12:\"emailaddress\";N;s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:0:\"\";s:11:\"accountname\";s:11:\"Ola Fashade\";s:13:\"accountnumber\";s:10:\"1303603985\";s:6:\"bankid\";s:9:\"489484940\";s:8:\"identity\";N;s:10:\"expirydate\";N;s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2016-11-29 17:58:53\";}user_loggedin|b:1;'
WHERE `transactionid` = '14805312235926qe'
AND `id` = 'aeb93dead0383db79193ac893da84b9027360deb'
ERROR - 2016-11-30 20:50:51 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\snappycoin\application\views\web\pages\deposit.php 20
ERROR - 2016-11-30 20:50:51 --> Severity: Notice --> Undefined property: stdClass::$tellernumber C:\xampp\htdocs\snappycoin\application\views\web\pages\deposit.php 27
ERROR - 2016-11-30 20:50:51 --> Severity: Notice --> Undefined property: stdClass::$paymentdate C:\xampp\htdocs\snappycoin\application\views\web\pages\deposit.php 34
