<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-26 11:23:28 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-26 11:23:28 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-26 11:23:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '3' at line 5 - Invalid query: SELECT `tbl_users`.*, count(tbl_gh.id) as countt
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE tbl_users.sponsor  != ''
GROUP BY `countt >` 3
ERROR - 2017-02-26 11:23:59 --> Query error: Unknown column 'tbl_users.sponsor' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488104639
WHERE tbl_users.sponsor  != ''
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 11:27:14 --> Query error: Unknown column 'countt' in 'having clause' - Invalid query: SELECT `tbl_users`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE tbl_users.sponsor  != ''
AND `tbl_gh`.`paymentstatus` = 1
HAVING `countt` > 3
ERROR - 2017-02-26 11:27:14 --> Query error: Unknown column 'tbl_users.sponsor' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488104834
WHERE tbl_users.sponsor  != ''
AND `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 11:31:55 --> Query error: Unknown column 'tbl_gh.userid' in 'field list' - Invalid query: SELECT distinct(tbl_gh.userid), count(tbl_gh.userid) as countt
FROM `tbl_users`
WHERE `tbl_gh`.`paymentstatus` = 1
ERROR - 2017-02-26 11:31:55 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488105115
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:03:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(*) >= 3
ERROR - 2017-02-26 12:03:12 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488106992
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:03:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:03:37 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107017
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:03:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:03:38 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107018
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:04:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:04:19 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107059
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:05:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:05:17 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107117
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:05:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:05:19 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107119
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:05:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE' at line 1 - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.*)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.*) >= 3
ERROR - 2017-02-26 12:05:20 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107120
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 12:06:09 --> Query error: Table 'helpcabal.tbl_user' doesn't exist - Invalid query: SELECT `tbl_gh`.`userid`, count(tbl_gh.id)
FROM `tbl_gh`
JOIN `tbl_user` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` = 1
GROUP BY `tbl_gh`.`userid`
HAVING count(tbl_gh.id) >= 3
ERROR - 2017-02-26 12:06:09 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488107169
WHERE `tbl_gh`.`paymentstatus` = 1
AND `id` = '6be572d1744b92582202dbe3b7fa47121fa9703f'
ERROR - 2017-02-26 18:12:18 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\controllers\management\Orders.php 755
ERROR - 2017-02-26 18:12:34 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-26 18:13:00 --> Unable to load the requested class: PHPExcel
ERROR - 2017-02-26 18:13:51 --> Severity: Notice --> Undefined property: Orders::$PHPExcel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:13:52 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:14:41 --> Severity: Notice --> Undefined property: Orders::$Excel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:14:41 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:16:21 --> Severity: Notice --> Undefined variable: Excel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:16:21 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:16:36 --> Severity: Notice --> Undefined property: Orders::$Excel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:16:36 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:17:42 --> Severity: Notice --> Undefined property: Orders::$Excel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:17:42 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:17:45 --> Severity: Notice --> Undefined property: Orders::$Excel C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:17:45 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 730
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 730
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 731
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 732
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 732
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 733
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 733
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 734
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 734
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\management\Orders.php 735
ERROR - 2017-02-26 18:34:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 735
ERROR - 2017-02-26 18:34:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 761
ERROR - 2017-02-26 18:34:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 762
ERROR - 2017-02-26 18:34:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 763
ERROR - 2017-02-26 19:26:20 --> 404 Page Not Found: management/Users/usersthathasgh
ERROR - 2017-02-26 19:26:27 --> 404 Page Not Found: management/Records/usersthathasgh
ERROR - 2017-02-26 19:45:55 --> Severity: Notice --> Undefined property: stdClass::$countt C:\xampp\htdocs\charity\application\controllers\management\Orders.php 809
ERROR - 2017-02-26 19:45:55 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 817
ERROR - 2017-02-26 20:11:45 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-26 20:26:13 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 764
ERROR - 2017-02-26 20:54:37 --> Query error: Table 'helpcabal.tbl_user' doesn't exist - Invalid query: SELECT `tbl_users`.*
FROM `tbl_user`
JOIN `tbl_users` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
ERROR - 2017-02-26 20:54:37 --> Query error: Unknown column 'tbl_users.isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488138877
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
AND `id` = 'abe5572088459baa330e3b34f02ae02d6c2ef451'
ERROR - 2017-02-26 21:01:49 --> Query error: Not unique table/alias: 'tbl_users' - Invalid query: SELECT `tbl_users`.*
FROM `tbl_users`
JOIN `tbl_users` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
ERROR - 2017-02-26 21:01:49 --> Query error: Unknown column 'tbl_users.isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488139309
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
AND `id` = 'abe5572088459baa330e3b34f02ae02d6c2ef451'
ERROR - 2017-02-26 21:05:11 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: SELECT `tbl_users`.*
FROM `tbl_users`
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
ERROR - 2017-02-26 21:05:11 --> Query error: Unknown column 'tbl_users.isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488139511
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
AND `id` = 'abe5572088459baa330e3b34f02ae02d6c2ef451'
ERROR - 2017-02-26 21:05:50 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: SELECT `tbl_users`.*
FROM `tbl_users`
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
ERROR - 2017-02-26 21:05:50 --> Query error: Unknown column 'tbl_users.isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488139550
WHERE `tbl_users`.`isguilder` != 1
AND `tbl_gh`.`userid` = '14853825878672yc'
AND `id` = 'abe5572088459baa330e3b34f02ae02d6c2ef451'
ERROR - 2017-02-26 21:06:52 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `tbl_gh`.`userid` = '14853825878672yc'
ERROR - 2017-02-26 21:06:52 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488139612
WHERE `tbl_gh`.`userid` = '14853825878672yc'
AND `id` = 'abe5572088459baa330e3b34f02ae02d6c2ef451'
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:07:48 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 856
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 861
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 862
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 863
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 864
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 865
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 870
ERROR - 2017-02-26 21:08:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 879
ERROR - 2017-02-26 21:08:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 898
ERROR - 2017-02-26 21:08:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 899
ERROR - 2017-02-26 21:08:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 900
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:57 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:26:59 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:00 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:01 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:02 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:03 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:04 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:06 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:08 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:10 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:11 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:13 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:14 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 869
ERROR - 2017-02-26 21:27:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 917
ERROR - 2017-02-26 21:27:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 918
ERROR - 2017-02-26 21:27:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 919
