<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-22 13:55:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 13:55:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 13:55:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 153
ERROR - 2016-08-22 18:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 153
ERROR - 2016-08-22 18:55:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:55:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:55:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 153
ERROR - 2016-08-22 18:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 152
ERROR - 2016-08-22 18:56:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 153
ERROR - 2016-08-22 19:35:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 19:36:18 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 19:37:34 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 19:39:38 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 19:40:23 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 22:32:09 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_item_location`
LEFT JOIN `tbl_location` ON `tbl_item_location`.`locationame`=`tbl_location`.`id`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ORDER BY `id` ASC
ERROR - 2016-08-22 22:32:16 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_item_location`
LEFT JOIN `tbl_location` ON `tbl_item_location`.`locationame`=`tbl_location`.`id`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ORDER BY `id` ASC
ERROR - 2016-08-22 22:32:23 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_item_location`
LEFT JOIN `tbl_location` ON `tbl_item_location`.`locationame`=`tbl_location`.`id`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ORDER BY `id` ASC
ERROR - 2016-08-22 22:32:51 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_item_location`
LEFT JOIN `tbl_location` ON `tbl_item_location`.`locationame`=`tbl_location`.`id`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ORDER BY `id` ASC
ERROR - 2016-08-22 22:33:33 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_item_location`
LEFT JOIN `tbl_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`id`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ORDER BY `id` ASC
ERROR - 2016-08-22 22:35:42 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationame`
FROM `tbl_location`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711848879439cb'
ERROR - 2016-08-22 22:36:01 --> Severity: Notice --> Undefined variable: locationame C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 162
ERROR - 2016-08-22 22:36:01 --> Severity: Notice --> Undefined variable: locationame C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 162
ERROR - 2016-08-22 22:36:01 --> Severity: Notice --> Undefined variable: locationame C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 162
ERROR - 2016-08-22 22:36:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-22 22:36:36 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-22 22:36:48 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_location`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:36:53 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_location`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:37:34 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_location`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:38:28 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_location`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_location`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:39:02 --> Query error: Unknown column 'tbl_location.locationname' in 'field list' - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_locations`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_locations`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:39:06 --> Query error: Unknown column 'tbl_location.locationname' in 'field list' - Invalid query: SELECT `tbl_location`.`locationname`
FROM `tbl_locations`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`locationname`=`tbl_locations`.`locationid`
WHERE `tbl_item_location`.`itemid` = '14711846754695fr'
ERROR - 2016-08-22 22:48:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-22 22:48:10 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-22 22:51:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-22 22:51:13 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-22 23:01:05 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 23:01:24 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 23:06:32 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-08-22 23:09:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-22 23:09:26 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
