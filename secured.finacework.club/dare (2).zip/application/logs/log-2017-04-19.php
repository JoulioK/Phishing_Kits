<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-19 11:14:59 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-19 11:15:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:15:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:31:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:41:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:48:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:50:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 11:51:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:00:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:02:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:03:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:03:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:38 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 28
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:06:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:33 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 28
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:10:59 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 28
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:11:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:00 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:12:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:14:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:16:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:16:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:18:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:18:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:19:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:29:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:30:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:34:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:35:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:40:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:43:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:26 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:47:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:48 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 12:48:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:20:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:21:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 13:28:37 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:28:56 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:28:56 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 158
ERROR - 2017-04-19 13:28:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:28:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:28:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:28:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:28:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:28:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:34 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:29:34 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 158
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:29:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:39 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:30:39 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 961
ERROR - 2017-04-19 13:30:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:30:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:24 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:36:24 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 308
ERROR - 2017-04-19 13:36:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:28 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:36:28 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 308
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:36:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:09 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 159
ERROR - 2017-04-19 13:37:09 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 158
ERROR - 2017-04-19 13:37:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:58 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\bitgiver\application\views\web\customer\packages.php 158
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:37:59 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:38:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:41:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:34 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:39 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:53:48 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:53:48 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:53:50 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: Assets/js
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:54:42 --> 404 Page Not Found: Assets/css
ERROR - 2017-04-19 13:55:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:55:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:05 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:58:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 13:59:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:00:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:26 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:26 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:01:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:25 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 14:02:26 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:45:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:46:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:47:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:49:16 --> Severity: Notice --> Undefined property: stdClass::$bitcoin C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 230
ERROR - 2017-04-19 15:49:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:40 --> Query error: Unknown column 'tbl_gh.btc' in 'field list' - Invalid query: SELECT `tbl_packages`.*, `tbl_gh`.`btc`
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE `tbl_gh`.`userid` = '14853742757197xj'
ERROR - 2017-04-19 15:49:40 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492613380
WHERE `tbl_gh`.`userid` = '14853742757197xj'
AND `id` = 'fd637390a571ccae1ef3754d6142fff4dee7f599'
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:49:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:50:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:50:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:50:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:50:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:50:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:50:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:51:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:53:16 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:54:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:55:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:56:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 15:58:54 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:00:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:02:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:03:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:04:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:11 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:05:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:06:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:07:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:09:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:10:36 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:12:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:13:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:14:56 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE `userid` = '14853742757197xj'
ORDER BY `id` desc
ERROR - 2017-04-19 16:14:56 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492614896
WHERE `userid` = '14853742757197xj'
AND `id` = 'fd637390a571ccae1ef3754d6142fff4dee7f599'
ORDER BY `id` desc
ERROR - 2017-04-19 16:15:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:15:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:16:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:17:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:19:56 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:20:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:12 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:22:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:23:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:24:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:27:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:28:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:33:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:33:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:33:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:33:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:33:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:33:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:01 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 16:37:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:37:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:38:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:07 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 224
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:41:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:42:31 --> 404 Page Not Found: web/Btc/phs
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:43:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:44:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:45:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:46:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:47:52 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:48:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:49:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:50:43 --> Severity: Error --> Call to undefined function dayofmonth() C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 235
ERROR - 2017-04-19 16:51:19 --> Severity: Notice --> Undefined variable: time C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:20 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:51:34 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:52:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:55:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:53 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 16:58:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 16:58:53 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 16:58:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 16:58:54 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 16:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 16:58:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 16:58:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:41 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:26:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:26:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:26:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:26:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:26:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:26:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:26:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:27:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:28:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:29:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:41:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:41:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:41:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:41:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:41:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:41:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:41:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 145
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 148
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:42:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 149
ERROR - 2017-04-19 20:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:42:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:28 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\bitgiver\application\models\web\Customer_model.php 250
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:43:43 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:44:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 20:45:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 21:33:15 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 201
ERROR - 2017-04-19 21:43:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:43:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:01 --> Severity: Notice --> Undefined variable: ghid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 181
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:05 --> Severity: Notice --> Undefined variable: ghid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 181
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:07 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:30 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:32 --> Severity: Notice --> Undefined variable: ghid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 181
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:44:33 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:19 --> Severity: Notice --> Undefined variable: ghid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 181
ERROR - 2017-04-19 21:45:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 190
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:45:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 190
ERROR - 2017-04-19 21:46:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:16 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 190
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:46:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:04 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:06 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:09 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:47:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:52 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:52 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 21:48:52 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:01:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:18 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:21 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:02:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 22:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:08:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 22:08:40 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:19:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:19:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:19:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:19:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:19:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:19:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:05 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:20:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:21:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:22:33 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:23:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:25:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:26:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:29:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:30:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:30:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:30:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:30:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:30:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:30:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:32:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:32:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:33:03 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:08 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:35:12 --> 404 Page Not Found: web/Btc/earnings
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:36:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:37:12 --> 404 Page Not Found: web/Btc/earnings
ERROR - 2017-04-19 23:43:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:50 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:51 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:43:52 --> Query error: Table 'bitgiver.tbl_trade_earnings' doesn't exist - Invalid query: SELECT *
FROM `tbl_trade_earnings`
JOIN `tbl_packages` ON `tbl_trade_earnings`.`packageid`=`tbl_packages`.`packageid`
WHERE `tbl_trade_earnings`.`userid` = '14853742757197xj'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-19 23:43:52 --> Query error: Unknown column 'tbl_trade_earnings.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492641832, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":24:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:2:\"30\";s:14:\"bitcoinaddress\";N;s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;'
WHERE `tbl_trade_earnings`.`userid` = '14853742757197xj'
AND `id` = 'e9cbc9bfa959fc45f9e7032d9a21ebb78f5282d7'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-19 23:48:21 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:48:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:48:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:01 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:02 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:10 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:41 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-19 23:49:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:42 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-19 23:49:44 --> 404 Page Not Found: web/User/images
