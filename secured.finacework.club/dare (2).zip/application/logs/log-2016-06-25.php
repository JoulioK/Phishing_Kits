<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-25 02:34:24 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 03:11:51 --> Severity: Notice --> Undefined property: Vendor::$primary_filter C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 03:11:51 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\fastfood\application\core\MY_Model.php 26
ERROR - 2016-06-25 03:59:43 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 344
ERROR - 2016-06-25 04:00:31 --> Severity: Notice --> Undefined variable: display_image C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 161
ERROR - 2016-06-25 04:24:12 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 372
ERROR - 2016-06-25 04:24:44 --> Severity: Notice --> Undefined variable: display_image C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 163
ERROR - 2016-06-25 04:25:19 --> Severity: Notice --> Undefined variable: display_image C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 163
ERROR - 2016-06-25 04:26:09 --> The upload path does not appear to be valid.
ERROR - 2016-06-25 04:28:24 --> Severity: Notice --> Undefined variable: display_image C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 163
ERROR - 2016-06-25 04:29:32 --> The upload path does not appear to be valid.
ERROR - 2016-06-25 04:32:41 --> The upload path does not appear to be valid.
ERROR - 2016-06-25 04:33:42 --> Severity: Notice --> Undefined variable: display_image C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 191
ERROR - 2016-06-25 04:33:42 --> Query error: Unknown column 'vendorlogo' in 'field list' - Invalid query: INSERT INTO `tbl_vendors` (`vendorname`, `vendoraddress`, `vendoremail`, `vendorphone`, `vendorusername`, `vendorurl`, `vendorid`, `vendorpassword`, `franchiseid`, `vendorlogo`) VALUES ('Crunchies', 'ccccc', 'crunchies@crunchies.com', '08999999', 'olafashade', 'http://crunchies.snappymeals.com', '14668220227703ae', '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', '2626273373', 'http://localhost/fastfood/resources/general/images/vendorlogo')
ERROR - 2016-06-25 04:51:46 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 101
ERROR - 2016-06-25 04:58:18 --> 404 Page Not Found: Js/classie.js
ERROR - 2016-06-25 10:11:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 10:16:05 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:16:05 --> Severity: Error --> Call to undefined method stdClass::get_all() C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 55
ERROR - 2016-06-25 10:19:52 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:19:52 --> Severity: Error --> Call to undefined method stdClass::get_all() C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 55
ERROR - 2016-06-25 10:22:03 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:22:03 --> Severity: Error --> Call to undefined method Vendor_Model::get_all() C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 55
ERROR - 2016-06-25 10:23:55 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:23:55 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:23:55 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:23:55 --> Severity: Notice --> Undefined property: Categories::$_table_name C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:23:55 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 23
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 34
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 43
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 50
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 64
ERROR - 2016-06-25 10:24:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 71
ERROR - 2016-06-25 10:26:05 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:26:05 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:26:23 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:26:23 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:29:08 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:29:08 --> Severity: Notice --> Undefined property: Categories::$_order_by C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-25 10:30:12 --> Severity: Notice --> Undefined variable: parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 96
ERROR - 2016-06-25 10:31:30 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:31:30 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 102
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 103
ERROR - 2016-06-25 10:31:31 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:31:31 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:31:45 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 54
ERROR - 2016-06-25 10:31:45 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:45 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:45 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:45 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:46 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:46 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:31:46 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 102
ERROR - 2016-06-25 10:31:46 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 103
ERROR - 2016-06-25 10:31:46 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:31:46 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 48
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 102
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 103
ERROR - 2016-06-25 10:32:02 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:32:02 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 101
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 102
ERROR - 2016-06-25 10:32:51 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 103
ERROR - 2016-06-25 10:32:51 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 105
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 105
ERROR - 2016-06-25 10:33:32 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:33:33 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 108
ERROR - 2016-06-25 10:34:38 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:38 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 105
ERROR - 2016-06-25 10:34:39 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:34:39 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 108
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 47
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\views\management\categories.php 104
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$categorydescription C:\xampp\htdocs\fastfood\application\views\management\categories.php 105
ERROR - 2016-06-25 10:35:20 --> Severity: Notice --> Undefined property: stdClass::$parent C:\xampp\htdocs\fastfood\application\views\management\categories.php 106
ERROR - 2016-06-25 10:35:20 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 108
ERROR - 2016-06-25 10:36:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\categories.php 100
ERROR - 2016-06-25 10:37:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\categories.php 98
ERROR - 2016-06-25 12:02:46 --> Query error: Table 'fastfood.tbl_locations' doesn't exist - Invalid query: SELECT *
FROM `tbl_locations`
ERROR - 2016-06-25 12:23:15 --> Severity: Notice --> Undefined variable: catid C:\xampp\htdocs\fastfood\application\controllers\management\location.php 52
ERROR - 2016-06-25 12:37:09 --> Severity: Notice --> Undefined variable: catid C:\xampp\htdocs\fastfood\application\controllers\management\location.php 38
ERROR - 2016-06-25 12:38:58 --> 404 Page Not Found: management/Location/location
ERROR - 2016-06-25 12:42:36 --> Severity: Error --> Call to undefined method Vendor_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\management\location.php 52
ERROR - 2016-06-25 12:43:07 --> Severity: Notice --> Undefined property: stdClass::$loactionid C:\xampp\htdocs\fastfood\application\views\management\location.php 49
ERROR - 2016-06-25 12:43:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\location.php 49
ERROR - 2016-06-25 13:01:22 --> Query error: Unknown column 'locationid' in 'where clause' - Invalid query: DELETE FROM `tbl_vendors`
WHERE `locationid` = '14668511172872zz' LIMIT 1
ERROR - 2016-06-25 13:01:31 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 13:01:32 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 13:01:53 --> Query error: Unknown column 'locationid' in 'where clause' - Invalid query: DELETE FROM `tbl_vendors`
WHERE `locationid` = '14668511172872zz' LIMIT 1
ERROR - 2016-06-25 13:17:35 --> Severity: Notice --> Undefined property: Categories::$farm_model C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 29
ERROR - 2016-06-25 13:17:36 --> Severity: Error --> Call to a member function array_from_post() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 29
ERROR - 2016-06-25 13:18:19 --> Query error: Column 'categoryname' cannot be null - Invalid query: INSERT INTO `tbl_item_category` (`categoryname`, `categorydescription`, `datemodified`, `categoryid`, `datecreated`, `parent`) VALUES (NULL, 'Patries item', '2016-06-25 13:18:19', '14668534990278fs', '2016-06-25 13:18:19', '')
ERROR - 2016-06-25 13:19:49 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 108
ERROR - 2016-06-25 13:23:50 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 109
ERROR - 2016-06-25 13:24:31 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 109
ERROR - 2016-06-25 13:25:02 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\management\categories.php 108
ERROR - 2016-06-25 13:46:56 --> Severity: Error --> Call to undefined method Vendor_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\management\categories.php 69
ERROR - 2016-06-25 13:54:51 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\categories.php 33
ERROR - 2016-06-25 13:56:22 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 13:56:40 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 13:56:49 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 14:32:31 --> 404 Page Not Found: Js/classie.js
ERROR - 2016-06-25 14:38:09 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-06-25 14:39:37 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 14:39:44 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 14:39:51 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 14:40:37 --> Query error: Table 'fastfood.tbl_vendor_users' doesn't exist - Invalid query: SELECT *
FROM `tbl_vendor_users`
WHERE `username` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-25 14:45:20 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 14:45:30 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 14:45:44 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 15:06:49 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 15:07:02 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 15:07:10 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 15:07:59 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 15:12:53 --> Severity: Error --> Call to undefined method User_Model::vendor_loggedin() C:\xampp\htdocs\fastfood\application\libraries\Vendor_Controller.php 17
ERROR - 2016-06-25 15:51:34 --> Severity: Error --> Class 'Item_model' not found C:\xampp\htdocs\fastfood\system\core\Loader.php 305
ERROR - 2016-06-25 15:59:06 --> Severity: Notice --> Undefined property: Items::$items_model C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 12
ERROR - 2016-06-25 15:59:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 12
ERROR - 2016-06-25 15:59:06 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 108
ERROR - 2016-06-25 15:59:06 --> Severity: Error --> Call to undefined method stdClass::get_all() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 110
ERROR - 2016-06-25 15:59:23 --> Severity: Error --> Class 'Item_model' not found C:\xampp\htdocs\fastfood\system\core\Loader.php 305
ERROR - 2016-06-25 16:00:01 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 108
ERROR - 2016-06-25 16:00:01 --> Severity: Error --> Call to undefined method stdClass::get_all() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 110
ERROR - 2016-06-25 17:05:16 --> Severity: Error --> Call to undefined method Items_Model::get_all() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 109
ERROR - 2016-06-25 17:07:02 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 101
ERROR - 2016-06-25 17:10:32 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:11:52 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:12:18 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:12:44 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:13:09 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:14:15 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:14:18 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 17:14:25 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-25 17:14:36 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-25 17:15:30 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 128
ERROR - 2016-06-25 17:16:18 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 128
ERROR - 2016-06-25 17:16:38 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 128
ERROR - 2016-06-25 17:17:26 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 123
ERROR - 2016-06-25 17:19:46 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 403
ERROR - 2016-06-25 17:20:24 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 403
ERROR - 2016-06-25 17:20:54 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 403
ERROR - 2016-06-25 17:21:22 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 403
ERROR - 2016-06-25 17:22:07 --> Severity: Error --> Call to undefined function states() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 403
ERROR - 2016-06-25 17:37:15 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 17:37:15 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 17:52:01 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 17:52:01 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 17:53:19 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 17:53:20 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-25 18:03:26 --> 404 Page Not Found: management/Items/index
ERROR - 2016-06-25 18:03:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-25 19:00:13 --> Severity: Error --> Call to undefined method Vendor_Model::get_all() C:\xampp\htdocs\fastfood\application\controllers\management\item_unit.php 57
ERROR - 2016-06-25 19:00:34 --> Query error: Table 'fastfood.t_item_unit' doesn't exist - Invalid query: SELECT *
FROM `t_item_unit`
ERROR - 2016-06-25 19:05:35 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\unit.php 24
ERROR - 2016-06-25 19:06:35 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\unit.php 24
ERROR - 2016-06-25 19:07:26 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\unit.php 24
ERROR - 2016-06-25 19:43:39 --> Query error: Unknown column 'unitname' in 'where clause' - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE `unitname` = 'Extra Large'
AND `vendorid` = '14668583422639we'
ERROR - 2016-06-25 19:45:14 --> 404 Page Not Found: vendor/Item_unit/14668766559544yj
ERROR - 2016-06-25 19:47:46 --> Query error: Table 'fastfood.t_items' doesn't exist - Invalid query: SELECT `t_items`.*, `t_item_category`.`categoryname`
FROM `t_items`
INNER JOIN `t_item_category` ON `t_item_category`.`categoryid` = `t_items`.`categoryid`
