<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-29 10:04:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-29 10:04:25 --> Query error: Unknown column 'tbl_gh.transactionhash' in 'field list' - Invalid query: SELECT `tbl_ph`.*, `tbl_gh`.`transactionhash`
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_gh`.`ghid`=`tbl_ph`.`ghid`
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 50
ERROR - 2017-04-29 10:04:25 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493456665
WHERE `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_ph`.`id` DESC LIMIT 50
ERROR - 2017-04-29 10:34:15 --> Query error: Unknown column 'bitcoin' in 'field list' - Invalid query: SELECT sum(bitcoin) as amount
FROM `tbl_ph`
WHERE datecreated between '2017-4-29 00:00:01' AND '2017-4-29 23:59:59'
AND `status` = 1
ERROR - 2017-04-29 10:34:15 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493458455
WHERE datecreated between '2017-4-29 00:00:01' AND '2017-4-29 23:59:59'
AND `status` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ERROR - 2017-04-29 10:34:21 --> Query error: Unknown column 'bitcoin' in 'field list' - Invalid query: SELECT sum(bitcoin) as amount
FROM `tbl_ph`
WHERE datecreated between '2017-4-29 00:00:01' AND '2017-4-29 23:59:59'
AND `status` = 1
ERROR - 2017-04-29 10:34:21 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493458461
WHERE datecreated between '2017-4-29 00:00:01' AND '2017-4-29 23:59:59'
AND `status` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ERROR - 2017-04-29 10:36:51 --> Query error: Unknown column 'tbl_ph.monotorium' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`reserved` = 1
AND `tbl_ph`.`monotorium` =0
AND `tbl_users`.`enabled` = 1
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-29 10:36:51 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493458611
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`reserved` = 1
AND `tbl_ph`.`monotorium` =0
AND `tbl_users`.`enabled` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-29 11:24:55 --> Query error: Unknown column 'tbl_ph.monotorium' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`reserved` = 1
AND `tbl_ph`.`monotorium` =0
AND `tbl_users`.`enabled` = 1
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-29 11:24:55 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493461495
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`reserved` = 1
AND `tbl_ph`.`monotorium` =0
AND `tbl_users`.`enabled` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-29 11:28:30 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 39
ERROR - 2017-04-29 11:28:32 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 39
ERROR - 2017-04-29 11:28:57 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 40
ERROR - 2017-04-29 11:30:10 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 42
ERROR - 2017-04-29 11:32:47 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 40
ERROR - 2017-04-29 11:48:16 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-29 11:48:16 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493462896
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-29 12:06:41 --> Query error: Unknown table 'tbl_gh' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_trade_earnings` ON `tbl_trade_earnings`.`userid`=`tbl_users`.`userid`
WHERE tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND `tbl_user`.`enabled` = 1
ORDER BY `tbl_trade_earnings`.`id` ASC
ERROR - 2017-04-29 12:06:41 --> Query error: Unknown column 'tbl_trade_earnings.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493464001
WHERE tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND `tbl_user`.`enabled` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_trade_earnings`.`id` ASC
ERROR - 2017-04-29 12:07:11 --> Query error: Unknown column 'tbl_user.enabled' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_trade_earnings`.*
FROM `tbl_users`
JOIN `tbl_trade_earnings` ON `tbl_trade_earnings`.`userid`=`tbl_users`.`userid`
WHERE tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND `tbl_user`.`enabled` = 1
ORDER BY `tbl_trade_earnings`.`id` ASC
ERROR - 2017-04-29 12:07:11 --> Query error: Unknown column 'tbl_trade_earnings.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493464031
WHERE tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND tbl_trade_earnings.datecreated between '2017-04-29 00:00:00' AND '2017-04-29 23:59:59'
AND `tbl_user`.`enabled` = 1
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_trade_earnings`.`id` ASC
ERROR - 2017-04-29 18:36:57 --> 404 Page Not Found: management/Orders/unpaid_plans
ERROR - 2017-04-29 18:37:15 --> Query error: Unknown column 'tbl_users.paymentstatus' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_users`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:37:15'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:37:15 --> Query error: Unknown column 'tbl_gh.phrequestdate' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493487435
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_users`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:37:15'
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:37:28 --> Query error: Unknown column 'tbl_ph.userid' in 'on clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:37:28'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:37:28 --> Query error: Unknown column 'tbl_gh.phrequestdate' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493487448
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:37:28'
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:38:26 --> Query error: Unknown column 'tbl_ph.userid' in 'on clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:38:26'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:38:26 --> Query error: Unknown column 'tbl_gh.phrequestdate' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493487506
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:38:26'
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:39:32 --> Query error: Unknown column 'tbl_ph.userid' in 'on clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:39:32'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-04-29 18:39:32 --> Query error: Unknown column 'tbl_gh.phrequestdate' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493487572
WHERE tbl_gh.phrequestdate between '2017-04-29 00:00:01' AND '2017-04-29 23:59:59'
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`graceperiod` < '2017-04-29 18:39:32'
AND `id` = '9dd322f2617693174b42b5dfb3d33c154a1cc825'
ORDER BY `tbl_gh`.`id` DESC
