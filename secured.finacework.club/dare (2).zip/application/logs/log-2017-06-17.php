<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-17 20:26:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 20:26:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 20:26:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 207
ERROR - 2017-06-17 20:26:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 207
ERROR - 2017-06-17 20:26:06 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 20:26:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 20:26:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 20:26:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 207
ERROR - 2017-06-17 20:26:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 207
ERROR - 2017-06-17 20:26:19 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\finance\capitalone\application\views\web\pages\details.php 206
ERROR - 2017-06-17 23:38:48 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\finance\capitalone\application\controllers\web\Home.php 53
ERROR - 2017-06-17 23:38:48 --> Severity: Notice --> Undefined variable: IP C:\xampp\htdocs\finance\capitalone\application\controllers\web\Home.php 53
ERROR - 2017-06-17 23:40:18 --> 404 Page Not Found: web/Capitalone_files/serverComponent.php
ERROR - 2017-06-17 23:40:18 --> 404 Page Not Found: web/Capitalone_files/cc.js.download
ERROR - 2017-06-17 23:40:18 --> 404 Page Not Found: web/Capitalone_files/cof-97310c9251.css
ERROR - 2017-06-17 23:40:19 --> 404 Page Not Found: web/Capitalone_files/cof-97310c9251.css
ERROR - 2017-06-17 23:40:19 --> 404 Page Not Found: web/Capitalone_files/lock-account-login.png
ERROR - 2017-06-17 23:40:19 --> 404 Page Not Found: web/Capitalone_files/capitalone-logo-2x-oasis.png
ERROR - 2017-06-17 23:40:32 --> 404 Page Not Found: web/Capitalone_files/serverComponent.php
ERROR - 2017-06-17 23:41:23 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:41:23 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:41:23 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:41:24 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:41:24 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:34 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:34 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:35 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:35 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:35 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:42:35 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:44:24 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:44:24 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:46:46 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:46:46 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:47:24 --> 404 Page Not Found: web/Home/capitalone_files
ERROR - 2017-06-17 23:50:07 --> 404 Page Not Found: web/Home/capitalone_files
