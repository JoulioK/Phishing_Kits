<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-13 17:59:53 --> Severity: Notice --> Undefined property: stdClass::$onlinestatus C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 83
ERROR - 2016-10-13 17:59:53 --> Severity: Notice --> Undefined property: stdClass::$onlinestatus C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 83
ERROR - 2016-10-13 19:53:46 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1476384826
WHERE datecreated between '2016-10-13 00:00:01' AND '2016-10-13 23:59:59'
AND `status` = '0'
AND `id` = '86d30e86a0360db6bd0756e69f34224b03b551f7'
