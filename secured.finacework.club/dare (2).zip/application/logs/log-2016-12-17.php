<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-17 19:32:10 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 8
ERROR - 2016-12-17 19:33:32 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 6
ERROR - 2016-12-17 19:34:14 --> Severity: Parsing Error --> syntax error, unexpected 'use' (T_USE) C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 15
ERROR - 2016-12-17 19:34:41 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:34:42 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:34:43 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:34:44 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:36:23 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:36:30 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:37:02 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:37:03 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:38:03 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 5
ERROR - 2016-12-17 19:39:06 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 4
ERROR - 2016-12-17 19:39:08 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Wallet.php 4
ERROR - 2016-12-17 19:39:43 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Mywallet.php 4
ERROR - 2016-12-17 19:40:20 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Mywallet.php 3
ERROR - 2016-12-17 19:40:32 --> Severity: Error --> Class 'Web_Controller' not found C:\xampp\htdocs\snappycoin\application\controllers\web\Home.php 3
ERROR - 2016-12-17 19:48:19 --> Severity: Notice --> Undefined variable: apiKey C:\xampp\htdocs\snappycoin\application\controllers\web\Mywallet.php 17
ERROR - 2016-12-17 19:48:19 --> Severity: Notice --> Undefined variable: apiSecret C:\xampp\htdocs\snappycoin\application\controllers\web\Mywallet.php 17
ERROR - 2016-12-17 21:18:08 --> Severity: error --> Exception: invalid signature C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-17 21:20:03 --> Severity: error --> Exception: invalid signature C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-17 21:23:01 --> Severity: error --> Exception: invalid signature C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-17 21:26:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\snappycoin\application\controllers\web\Authenticate.php 25
ERROR - 2016-12-17 21:26:51 --> Severity: error --> Exception: invalid signature C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-17 21:27:18 --> Severity: error --> Exception: invalid signature C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-17 21:30:31 --> Severity: Notice --> Undefined index: phonenumber C:\xampp\htdocs\snappycoin\application\controllers\web\Authenticate.php 60
