<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-22 13:20:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-22 13:20:58 --> Query error: Table 'helpcabal.tbl_orders' doesn't exist - Invalid query: SELECT count(id) as count
FROM `tbl_orders`
WHERE datecreated between '2017-01-22 00:00:01' AND '2017-01-22 23:59:59'
AND `franchiseid` = '2626273373'
ORDER BY `id` desc
ERROR - 2017-01-22 13:20:58 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485087658
WHERE datecreated between '2017-01-22 00:00:01' AND '2017-01-22 23:59:59'
AND `franchiseid` = '2626273373'
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined variable: totalorders C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 40
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined variable: completedorders C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 45
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined variable: pendingorders C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 50
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined variable: totalearnings C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 56
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined property: stdClass::$transactionid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 107
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 109
ERROR - 2017-01-22 14:03:48 --> Severity: Notice --> Undefined property: stdClass::$packageid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 112
ERROR - 2017-01-22 14:03:48 --> Query error: Table 'helpcabal.tbl_item_price' doesn't exist - Invalid query: SELECT `itemid`, `unit`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` desc
ERROR - 2017-01-22 14:03:48 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485090228
WHERE `priceid` IS NULL
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:32:30 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 40
ERROR - 2017-01-22 14:32:30 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 45
ERROR - 2017-01-22 14:32:30 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 50
ERROR - 2017-01-22 14:32:30 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 56
ERROR - 2017-01-22 14:32:30 --> Severity: Notice --> Undefined variable: totalearnings C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 56
ERROR - 2017-01-22 14:32:30 --> Severity: Notice --> Undefined property: stdClass::$transactionid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 104
ERROR - 2017-01-22 14:32:30 --> Severity: Notice --> Undefined property: stdClass::$packageid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 109
ERROR - 2017-01-22 14:32:30 --> Query error: Table 'helpcabal.tbl_item_price' doesn't exist - Invalid query: SELECT `itemid`, `unit`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` desc
ERROR - 2017-01-22 14:32:30 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485091950
WHERE `priceid` IS NULL
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:34:11 --> Severity: Notice --> Undefined variable: totalearnings C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 56
ERROR - 2017-01-22 14:34:11 --> Severity: Notice --> Undefined property: stdClass::$transactionid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 104
ERROR - 2017-01-22 14:34:11 --> Severity: Notice --> Undefined property: stdClass::$packageid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 109
ERROR - 2017-01-22 14:34:11 --> Query error: Table 'helpcabal.tbl_item_price' doesn't exist - Invalid query: SELECT `itemid`, `unit`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` desc
ERROR - 2017-01-22 14:34:11 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485092051
WHERE `priceid` IS NULL
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:35:15 --> Severity: Notice --> Undefined variable: totalearnings C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 56
ERROR - 2017-01-22 14:35:15 --> Severity: Notice --> Undefined property: stdClass::$transactionid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 104
ERROR - 2017-01-22 14:35:15 --> Severity: Notice --> Undefined property: stdClass::$packageid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 109
ERROR - 2017-01-22 14:35:15 --> Query error: Table 'helpcabal.tbl_item_price' doesn't exist - Invalid query: SELECT `itemid`, `unit`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` desc
ERROR - 2017-01-22 14:35:15 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485092115
WHERE `priceid` IS NULL
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:35:45 --> Severity: Notice --> Undefined property: stdClass::$transactionid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 104
ERROR - 2017-01-22 14:35:45 --> Severity: Notice --> Undefined property: stdClass::$packageid C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 109
ERROR - 2017-01-22 14:35:45 --> Query error: Table 'helpcabal.tbl_item_price' doesn't exist - Invalid query: SELECT `itemid`, `unit`
FROM `tbl_item_price`
WHERE `priceid` IS NULL
ORDER BY `id` desc
ERROR - 2017-01-22 14:35:45 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485092145
WHERE `priceid` IS NULL
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ORDER BY `id` desc
ERROR - 2017-01-22 14:42:40 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\charity\application\models\management\Order_model.php 20
ERROR - 2017-01-22 15:22:34 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\charity\application\controllers\management\Orders.php 32
ERROR - 2017-01-22 15:22:34 --> Severity: Error --> Call to undefined method stdClass::get() C:\xampp\htdocs\charity\application\controllers\management\Orders.php 33
ERROR - 2017-01-22 15:22:34 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485094954
WHERE datecreated between '2017-01-22 00:00:01' AND '2017-01-22 23:59:59'
AND datecreated between '2017-01-22 00:00:01' AND '2017-01-22 23:59:59'
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ERROR - 2017-01-22 15:22:34 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-22 15:23:29 --> Severity: Notice --> Undefined variable: primaryaccountid C:\xampp\htdocs\charity\application\views\management\orders\pledges.php 8
ERROR - 2017-01-22 15:23:29 --> Severity: Notice --> Undefined variable: balance C:\xampp\htdocs\charity\application\views\management\orders\pledges.php 8
ERROR - 2017-01-22 17:18:40 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\controllers\management\Users.php 130
ERROR - 2017-01-22 17:20:32 --> Query error: Unknown column 'isguilder' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `isguilder` = 1
ERROR - 2017-01-22 17:20:32 --> Query error: Unknown column 'isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485102032
WHERE `isguilder` = 1
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ERROR - 2017-01-22 17:23:17 --> Query error: Unknown column 'isguider' in 'field list' - Invalid query: UPDATE `tbl_users` SET `isguider` = 1
WHERE `emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-22 17:27:58 --> Severity: Notice --> Undefined property: Users::$order_model C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-22 17:27:58 --> Severity: Notice --> Indirect modification of overloaded property User_Model::$order_model has no effect C:\xampp\htdocs\charity\application\models\management\User_model.php 161
ERROR - 2017-01-22 17:27:58 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\charity\application\models\management\User_model.php 161
ERROR - 2017-01-22 17:27:58 --> Severity: Notice --> Undefined property: Users::$order_model C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-22 17:27:58 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\charity\application\models\management\User_model.php 164
ERROR - 2017-01-22 17:27:58 --> Query error: Unknown column 'sponsor' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485102478, `data` = 'sponsor|s:16:\"14675775313398tp\";Please login first|N;user_session|O:8:\"stdClass\":18:{s:2:\"id\";s:2:\"17\";s:6:\"userid\";s:16:\"14850381093774dm\";s:8:\"fullname\";s:5:\"admin\";s:8:\"username\";s:7:\"adebola\";s:12:\"emailaddress\";s:20:\"admin@edcanambra.com\";s:11:\"phonenumber\";s:3:\"edc\";s:8:\"password\";s:128:\"fcb36e9806c7a6f7efc84fb7dbcb473c7a597ee7d99df3b238eed232b38b3e1d0507c35abd2fb4aa27968099468896538a716790decbe69b4893150df53e659d\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";N;s:11:\"accountname\";s:16:\"Olalekan Fashade\";s:13:\"accountnumber\";s:8:\"92828733\";s:8:\"bankname\";s:5:\"Bank1\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:1:\"0\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";s:2:\"+1\";s:11:\"datecreated\";s:19:\"2017-01-21 23:35:08\";s:12:\"datemodified\";s:19:\"2017-01-21 23:43:54\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE sponsor  = '14675775313398tp'
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ERROR - 2017-01-22 17:27:58 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-22 17:28:30 --> Severity: Notice --> Undefined variable: todayph C:\xampp\htdocs\charity\application\models\management\User_model.php 165
ERROR - 2017-01-22 17:28:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\management\User_model.php 165
ERROR - 2017-01-22 18:02:57 --> Query error: Table 'helpcabal.tbl_guilder_gh' doesn't exist - Invalid query: SELECT *
FROM `tbl_guilder_gh`
ERROR - 2017-01-22 18:43:24 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 93
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 96
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 99
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 106
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 93
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 96
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 99
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 106
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 93
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 96
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 99
ERROR - 2017-01-22 18:44:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\addguilders.php 106
ERROR - 2017-01-22 18:51:43 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\views\management\users\payguilders.php 100
ERROR - 2017-01-22 19:17:40 --> Severity: Notice --> Undefined variable: site_style C:\xampp\htdocs\charity\application\views\web\_layouts\header.php 15
ERROR - 2017-01-22 19:17:42 --> Severity: Notice --> Undefined variable: site_script C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 38
ERROR - 2017-01-22 19:22:28 --> Query error: Table 'helpcabal.tbl_locations' doesn't exist - Invalid query: SELECT *
FROM `tbl_locations`
ERROR - 2017-01-22 19:24:13 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\charity\application\views\management\users\create_users.php 99
ERROR - 2017-01-22 19:38:51 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-22 19:38:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-22 19:38:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-22 19:39:35 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 91
ERROR - 2017-01-22 19:39:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-22 19:39:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-22 19:40:11 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-22 19:40:11 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-22 19:40:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 36
ERROR - 2017-01-22 19:40:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-22 19:40:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-22 19:41:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-22 19:41:51 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 101
ERROR - 2017-01-22 19:42:35 --> Severity: Notice --> Undefined property: stdClass::$pledgeid C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 20
