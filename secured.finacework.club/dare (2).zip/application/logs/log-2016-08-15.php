<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-15 22:01:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-15 22:05:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-15 22:07:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-15 22:08:46 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-15 22:17:22 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-15 22:17:28 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-15 22:17:38 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-15 22:28:21 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
