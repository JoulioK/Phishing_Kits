<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-10 02:06:23 --> Severity: Notice --> Undefined property: Settings::$authenticate_model C:\xampp\htdocs\snappycoin\application\controllers\web\Settings.php 195
ERROR - 2016-12-10 02:06:23 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Settings.php 195
ERROR - 2016-12-10 07:17:45 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 70
ERROR - 2016-12-10 07:17:45 --> Severity: Notice --> Undefined property: Customer::$authenticate_model C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 97
ERROR - 2016-12-10 07:17:46 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 97
ERROR - 2016-12-10 07:18:54 --> Severity: Notice --> Undefined property: Customer::$authenticate_model C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 97
ERROR - 2016-12-10 07:18:54 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 97
ERROR - 2016-12-10 07:29:47 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 50
ERROR - 2016-12-10 14:04:14 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:09:53 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:13:52 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:14:35 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:15:54 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:24:16 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:26:37 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:26:52 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:27:26 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:27:28 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:28:19 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:28:23 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:29:07 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:29:09 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:29:21 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:29:41 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:30:57 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:31:00 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:31:12 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:32:20 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:32:49 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:32:53 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:34:30 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:35:17 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:36:26 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:37:55 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:38:19 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:39:07 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:44:17 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:46:00 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:47:23 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:48:41 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:49:16 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:51:31 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:51:58 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:52:24 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:52:46 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:53:08 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:53:36 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 14:56:16 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 15:01:03 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 15:03:12 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 15:04:16 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 15:04:31 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 15:05:01 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-12-10 18:24:10 --> Severity: Warning --> Missing argument 1 for Item::receipt() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 214
ERROR - 2016-12-10 18:53:38 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-10 18:53:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-10 19:00:16 --> Severity: Warning --> Missing argument 1 for Item::receipt() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 214
ERROR - 2016-12-10 20:44:28 --> 404 Page Not Found: management/Orders/change_status
ERROR - 2016-12-10 21:11:29 --> 404 Page Not Found: management/Orders/index
ERROR - 2016-12-10 21:12:24 --> 404 Page Not Found: management/Orders/index
ERROR - 2016-12-10 21:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 120
ERROR - 2016-12-10 21:24:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 135
ERROR - 2016-12-10 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 120
ERROR - 2016-12-10 21:24:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 135
