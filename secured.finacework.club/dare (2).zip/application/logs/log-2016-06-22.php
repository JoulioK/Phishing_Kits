<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-22 23:01:36 --> 404 Page Not Found: Admin/Authenticate
ERROR - 2016-06-22 23:02:04 --> 404 Page Not Found: Admin/Authenticate
ERROR - 2016-06-22 23:41:20 --> Severity: Notice --> Undefined property: Authenticate::$Admin_User_Model C:\xampp\htdocs\fastfood\application\controllers\management\authenticate.php 9
ERROR - 2016-06-22 23:41:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\management\authenticate.php 9
ERROR - 2016-06-22 23:41:20 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-22 23:43:51 --> 404 Page Not Found: management/Js/classie.js
