<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-09 09:18:58 --> 404 Page Not Found: management/Delivery/statistics
ERROR - 2016-09-09 12:48:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-09 12:50:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-09 12:50:07 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-09 13:58:26 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-09-09 13:58:55 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 14:30:46 --> Query error: Unknown column 'vendorid' in 'field list' - Invalid query: SELECT `vendorid`
FROM `tbl_item_price`
WHERE `priceid` = '14711901786394an'
ORDER BY `id` ASC
ERROR - 2016-09-09 14:30:46 --> Query error: Unknown column 'priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1473427846
WHERE `priceid` = '14711901786394an'
AND `id` = 'f019fce07376300e64091fdd79942ac7cefe4772'
ORDER BY `id` ASC
ERROR - 2016-09-09 15:02:57 --> Severity: Parsing Error --> syntax error, unexpected '$vendorid' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 77
ERROR - 2016-09-09 15:03:19 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT `tbl_item_price`.`itemid`, `tbl_items`.`vendorid`
FROM `tbl_item_price`
LEFT JOIN `tbl_items` ON `tbl_item_price`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_price`.`priceid` = '14711901786394an'
ORDER BY `id` ASC
ERROR - 2016-09-09 15:03:19 --> Query error: Unknown column 'tbl_item_price.priceid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1473429799, `data` = 'location|s:16:\"14668510290307aw\";user_session|O:8:\"stdClass\":12:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:9:\"firstname\";s:8:\"Olalekan\";s:8:\"lastname\";s:7:\"Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:14:\"contactaddress\";N;s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"1113\";s:11:\"datecreated\";N;s:12:\"datemodified\";N;}user_loggedin|b:1;shippingaddress|s:16:\"14715367143897hv\";current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;cart_contents|a:3:{s:10:\"cart_total\";d:3000;s:11:\"total_items\";d:1;s:32:\"602b2d7cf3554bba03efcae75e35ffa0\";a:7:{s:2:\"id\";s:16:\"14711901786394an\";s:3:\"qty\";d:1;s:5:\"price\";d:3000;s:4:\"name\";s:5:\"Pizza\";s:7:\"options\";a:3:{s:18:\"packagedescription\";s:15:\"Big size pizza \";s:8:\"unitname\";s:8:\"Big size\";s:9:\"unitabbrv\";s:3:\"Big\";}s:5:\"rowid\";s:32:\"602b2d7cf3554bba03efcae75e35ffa0\";s:8:\"subtotal\";d:3000;}}gotocart|b:1;__ci_vars|a:1:{s:8:\"gotocart\";s:3:\"new\";}'
WHERE `tbl_item_price`.`priceid` = '14711901786394an'
AND `id` = 'f019fce07376300e64091fdd79942ac7cefe4772'
ORDER BY `id` ASC
ERROR - 2016-09-09 15:04:30 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 15:07:29 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:15:56 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:18:11 --> Severity: Parsing Error --> syntax error, unexpected 'return' (T_RETURN) C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 75
ERROR - 2016-09-09 16:18:21 --> Severity: Compile Error --> Cannot redeclare Item_model::getvendorbypackageid() C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 78
ERROR - 2016-09-09 16:18:54 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:19:15 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:19:46 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:20:23 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 16:31:31 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-09 20:21:57 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 57
ERROR - 2016-09-09 20:22:09 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:22:19 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:22:36 --> Severity: Notice --> Undefined variable: rest C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 50
ERROR - 2016-09-09 20:22:36 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 50
ERROR - 2016-09-09 20:22:36 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:23:42 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:25:48 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 75
ERROR - 2016-09-09 20:25:57 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 74
ERROR - 2016-09-09 20:26:09 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:26:31 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:26:45 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:27:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:27:27 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:27:39 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:28:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:28:35 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 74
ERROR - 2016-09-09 20:31:17 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 20:31:29 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 21:51:13 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 21:51:37 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 21:52:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 21:52:31 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 21:52:47 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:09:27 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:09:38 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:10:33 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:10:53 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:11:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:12:42 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:15:41 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:15:49 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:17:12 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:17:25 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:17:49 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:18:12 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:18:27 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:18:53 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:19:13 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:19:40 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:20:26 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:20:46 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:21:11 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:21:26 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:21:53 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:23:10 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:25:50 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:26:01 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-09 23:26:10 --> 404 Page Not Found: web/Resources/web
