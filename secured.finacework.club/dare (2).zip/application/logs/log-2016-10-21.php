<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-21 21:06:19 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:06:51 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:06:55 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-10-21 21:07:01 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:08:06 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:08:07 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:08:08 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:08:46 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:08:47 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:09:06 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:09:13 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:14:27 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:14:27 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:14:28 --> 404 Page Not Found: Authenticate/login
ERROR - 2016-10-21 21:14:29 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-10-21 21:14:30 --> 404 Page Not Found: Authenticate/login
