<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-12 04:34:07 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-08-12 04:34:12 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-08-12 04:34:36 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-12 04:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-12 04:52:46 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-12 04:52:47 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-12 05:22:02 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:03 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:06 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:29 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:33 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 61
ERROR - 2016-08-12 05:22:34 --> Severity: Notice --> Undefined variable: monthend C:\xampp\htdocs\fastfood\application\controllers\management\dashboard.php 62
ERROR - 2016-08-12 13:23:31 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-12 13:47:08 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-12 13:48:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 29
ERROR - 2016-08-12 13:48:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 47
ERROR - 2016-08-12 13:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 52
ERROR - 2016-08-12 13:48:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 57
ERROR - 2016-08-12 13:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 31
ERROR - 2016-08-12 13:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 49
ERROR - 2016-08-12 13:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 54
ERROR - 2016-08-12 13:49:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 13:55:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 31
ERROR - 2016-08-12 13:55:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 49
ERROR - 2016-08-12 13:55:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 54
ERROR - 2016-08-12 13:55:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 13:55:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 31
ERROR - 2016-08-12 13:55:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 49
ERROR - 2016-08-12 13:55:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 54
ERROR - 2016-08-12 13:55:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 13:56:39 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-12 13:56:57 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 31
ERROR - 2016-08-12 13:56:57 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 49
ERROR - 2016-08-12 13:56:57 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 54
ERROR - 2016-08-12 13:56:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 14:03:04 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 14:03:05 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\views\vendor\users\profile.php 59
ERROR - 2016-08-12 14:55:59 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-12 15:56:07 --> 404 Page Not Found: web/Home/resources
