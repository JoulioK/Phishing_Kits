<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-24 00:42:08 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 282
ERROR - 2016-07-24 00:42:38 --> Severity: Compile Error --> Cannot redeclare Settlements::deletevendorpayment() C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 295
ERROR - 2016-07-24 00:43:12 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 263
ERROR - 2016-07-24 00:43:12 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 264
ERROR - 2016-07-24 00:44:01 --> Query error: Table 'fastfood.tbl_franchise_paymen' doesn't exist - Invalid query: SELECT sum(amount) as total
FROM `tbl_franchise_paymen`
WHERE datecreated between '2016-7-24 00:00:01' AND '2016-7-24 23:59:59'
AND `franchiseid` = '2626273373'
ERROR - 2016-07-24 00:44:22 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 256
ERROR - 2016-07-24 00:44:22 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 272
ERROR - 2016-07-24 00:53:14 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' C:\xampp\htdocs\fastfood\application\views\management\settlement\earningssummary.php 80
ERROR - 2016-07-24 00:53:36 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\fastfood\application\views\management\settlement\earningssummary.php 80
ERROR - 2016-07-24 01:14:37 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 01:14:43 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-24 01:14:58 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 09:10:34 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 09:11:58 --> 404 Page Not Found: vendor/Orders/pending
ERROR - 2016-07-24 09:12:06 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-24 09:21:54 --> 404 Page Not Found: vendor/Orders/index
ERROR - 2016-07-24 09:22:06 --> Severity: Notice --> Undefined property: Orders::$vendorid C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 23
ERROR - 2016-07-24 09:22:54 --> Severity: Notice --> Undefined property: Orders::$vendorid C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 23
ERROR - 2016-07-24 09:23:33 --> Severity: Notice --> Undefined property: Orders::$vendorid C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 23
ERROR - 2016-07-24 09:24:15 --> Severity: Notice --> Undefined property: Orders::$vendorid C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 23
ERROR - 2016-07-24 10:09:43 --> Severity: Notice --> Undefined property: Items::$vendorid C:\xampp\htdocs\fastfood\application\controllers\management\items.php 131
ERROR - 2016-07-24 10:09:44 --> Severity: Notice --> Undefined property: Items::$vendorid C:\xampp\htdocs\fastfood\application\controllers\management\items.php 138
ERROR - 2016-07-24 10:13:33 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\views\management\items\create_items.php 99
ERROR - 2016-07-24 10:47:57 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\views\management\items\create_items.php 99
ERROR - 2016-07-24 17:34:23 --> 404 Page Not Found: Contact/index
ERROR - 2016-07-24 17:49:29 --> 404 Page Not Found: Contacthtml/index
ERROR - 2016-07-24 18:31:24 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\fastfood\application\controllers\web\contact.php 18
ERROR - 2016-07-24 20:30:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 20:30:46 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 20:38:04 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-24 20:47:32 --> Query error: Table 'fastfood.tbl_faqs' doesn't exist - Invalid query: INSERT INTO `tbl_faqs` (`title`, `text`, `datecreated`, `datemodified`) VALUES ('How do i ship to my location', '<p>You can sip to your location by just shipping</p>', '2016-07-24 20:47:32', '2016-07-24 20:47:32')
ERROR - 2016-07-24 21:04:01 --> 404 Page Not Found: Faqs/index
ERROR - 2016-07-24 21:04:05 --> 404 Page Not Found: web/Faqs/index
ERROR - 2016-07-24 21:04:09 --> 404 Page Not Found: web/Faqs/index
ERROR - 2016-07-24 21:13:46 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\fastfood\application\views\web\faqs.php 38
ERROR - 2016-07-24 21:15:15 --> 404 Page Not Found: web/Faqs/index
ERROR - 2016-07-24 21:15:18 --> 404 Page Not Found: web/Faqs/index
ERROR - 2016-07-24 23:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-24 23:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-24 23:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-24 23:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-24 23:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-24 23:20:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-24 23:20:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-24 23:20:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-24 23:21:33 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-24 23:24:40 --> 404 Page Not Found: Hub/orders
ERROR - 2016-07-24 23:41:03 --> 404 Page Not Found: Hub/orders
