<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-19 21:41:37 --> 404 Page Not Found: management/Js/classie.js
