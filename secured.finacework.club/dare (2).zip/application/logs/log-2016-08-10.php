<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-10 04:15:37 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\web\vendors\home.php 76
ERROR - 2016-08-10 04:15:45 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-08-10 04:18:01 --> 404 Page Not Found: web/Vendors/vendor
ERROR - 2016-08-10 05:25:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 05:25:50 --> 404 Page Not Found: Codeshtml/index
ERROR - 2016-08-10 05:25:54 --> 404 Page Not Found: Contacthtml/index
ERROR - 2016-08-10 05:26:26 --> 404 Page Not Found: web/Home/web
ERROR - 2016-08-10 10:29:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-10 10:45:52 --> 404 Page Not Found: management/Pages/index
ERROR - 2016-08-10 10:48:35 --> 404 Page Not Found: management/Page/page
ERROR - 2016-08-10 11:10:17 --> 404 Page Not Found: About/index
ERROR - 2016-08-10 11:35:32 --> 404 Page Not Found: web/Terms/index
ERROR - 2016-08-10 11:42:00 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\libraries\Web_Controller.php 27
ERROR - 2016-08-10 11:42:00 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\libraries\Web_Controller.php 28
ERROR - 2016-08-10 11:42:29 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_page`
WHERE `id` = 1
ORDER BY `categoryname` ASC
ERROR - 2016-08-10 11:43:03 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_page`
WHERE `id` = 1
ORDER BY `categoryname` ASC
ERROR - 2016-08-10 11:43:05 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_page`
WHERE `id` = 1
ORDER BY `categoryname` ASC
ERROR - 2016-08-10 11:45:51 --> Severity: Error --> Call to undefined function word_limiter() C:\xampp\htdocs\fastfood\application\libraries\Web_Controller.php 30
ERROR - 2016-08-10 16:12:14 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-10 16:12:31 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-10 16:41:28 --> 404 Page Not Found: web/Customer/index.html
ERROR - 2016-08-10 16:42:05 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-10 17:04:30 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-10 17:06:10 --> Severity: Warning --> Missing argument 1 for CI_URI::segment(), called in C:\xampp\htdocs\fastfood\application\libraries\Management_Controller.php on line 41 and defined C:\xampp\htdocs\fastfood\system\core\URI.php 342
ERROR - 2016-08-10 17:06:10 --> Severity: Notice --> Undefined variable: n C:\xampp\htdocs\fastfood\system\core\URI.php 344
ERROR - 2016-08-10 17:06:11 --> Severity: Warning --> Missing argument 1 for CI_URI::segment(), called in C:\xampp\htdocs\fastfood\application\libraries\Management_Controller.php on line 41 and defined C:\xampp\htdocs\fastfood\system\core\URI.php 342
ERROR - 2016-08-10 17:06:11 --> Severity: Notice --> Undefined variable: n C:\xampp\htdocs\fastfood\system\core\URI.php 344
ERROR - 2016-08-10 17:42:50 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 17
ERROR - 2016-08-10 17:42:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 17
ERROR - 2016-08-10 17:42:50 --> Severity: Error --> Call to undefined function show() C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 19
ERROR - 2016-08-10 17:44:12 --> Severity: Error --> Call to undefined function show() C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 20
ERROR - 2016-08-10 17:47:21 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:47:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:47:22 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:47:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:47:46 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:47:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:47:47 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:47:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:48:29 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:48:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:48:49 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 18
ERROR - 2016-08-10 17:48:50 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 18
ERROR - 2016-08-10 17:49:23 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:49:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:49:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:49:24 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:49:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:49:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:49:52 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:49:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:49:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:49:54 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:49:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:49:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:50:08 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:50:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:50:24 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:50:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:50:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:50:28 --> Severity: Notice --> Undefined variable: heading C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 60
ERROR - 2016-08-10 17:50:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\errors\html\error_permission.php 61
ERROR - 2016-08-10 17:50:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:52:02 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:52:20 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:52:20 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:52:38 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:52:40 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:52:58 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:22 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:23 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:24 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:25 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:25 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:40 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:41 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:41 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:53 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:54:54 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:56:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:56:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 17:56:44 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 17:57:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 18:03:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 18:03:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-10 18:03:28 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:03:34 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:08:48 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:09:26 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:09:43 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:11:43 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:11:45 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:18:19 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:18:25 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:18:31 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:18:36 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:22:16 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:23:08 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:24:35 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:24:45 --> 404 Page Not Found: Error_permission/index
ERROR - 2016-08-10 18:51:34 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-10 18:51:49 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 106
ERROR - 2016-08-10 18:57:06 --> 404 Page Not Found: vendor/Items/resources
ERROR - 2016-08-10 19:08:38 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:08:39 --> 404 Page Not Found: vendor/Items/images
ERROR - 2016-08-10 19:10:16 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:10:16 --> Severity: Error --> Call to undefined function base_url() C:\xampp\htdocs\fastfood\application\views\errors\html\error_404.php 72
ERROR - 2016-08-10 19:11:09 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:11:09 --> Severity: Error --> Call to undefined function base_url() C:\xampp\htdocs\fastfood\application\views\errors\html\error_404.php 77
ERROR - 2016-08-10 19:12:15 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:12:15 --> Severity: Error --> Call to undefined function base_url() C:\xampp\htdocs\fastfood\application\views\errors\html\error_404.php 80
ERROR - 2016-08-10 19:12:17 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:12:17 --> Severity: Error --> Call to undefined function base_url() C:\xampp\htdocs\fastfood\application\views\errors\html\error_404.php 80
ERROR - 2016-08-10 19:12:28 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:12:31 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:12:58 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:12:58 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:14:00 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:14:00 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:16:02 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:16:10 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:16:45 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:22:03 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:22:08 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 19:22:31 --> 404 Page Not Found: vendor/Items/list_iddkms
ERROR - 2016-08-10 20:11:57 --> 404 Page Not Found: Authenticate/forgot
ERROR - 2016-08-10 20:31:17 --> 404 Page Not Found: web/Customer/settings
ERROR - 2016-08-10 20:34:02 --> 404 Page Not Found: web/Customer/settings
ERROR - 2016-08-10 20:48:31 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 20:48:31 --> Severity: Notice --> Undefined variable: implode C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 20:48:31 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 20:49:09 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 20:49:09 --> Severity: Notice --> Undefined variable: implode C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 20:49:09 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 21:02:49 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 21:02:49 --> Severity: Notice --> Undefined variable: implode C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 21:02:50 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 21:03:24 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 21:03:24 --> Severity: Notice --> Undefined variable: implode C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 21:03:24 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\fastfood\application\controllers\web\item.php 223
ERROR - 2016-08-10 21:07:41 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 21:07:41 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 232
ERROR - 2016-08-10 21:07:44 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 243
ERROR - 2016-08-10 21:07:45 --> Query error: Unknown column 'orderid' in 'field list' - Invalid query: INSERT INTO `tbl_shippings` (`orderid`, `transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `address`, `location`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`, `shippingid`, `amount`) VALUES ('14708560611785jj', '14708558421674mz', '873880050046', '14675775313398tp', '14707154154570yn', '14668583422639we', '2626273373', 'No 23, Nawfia Street 3', NULL, '14707150964683zu', 1, 1425, 1425, '14690182128317gs', '2016-08-10 21:07:41', '2016-08-10 21:07:41', 0, '14708560642333gp', 5)
ERROR - 2016-08-10 21:07:56 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 21:07:56 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 232
ERROR - 2016-08-10 21:08:00 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 243
ERROR - 2016-08-10 21:08:00 --> Query error: Unknown column 'orderid' in 'field list' - Invalid query: INSERT INTO `tbl_shippings` (`orderid`, `transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `address`, `location`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`, `shippingid`, `amount`) VALUES ('14708560765559dk', NULL, NULL, '14675775313398tp', '14707154154570yn', '14668583422639we', '2626273373', 'No 23, Nawfia Street 3', NULL, '14707150964683zu', 1, 1425, 1425, '14690182128317gs', '2016-08-10 21:07:56', '2016-08-10 21:07:56', 0, '14708560809689jo', 5)
ERROR - 2016-08-10 21:11:16 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-10 21:11:16 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 232
ERROR - 2016-08-10 21:11:21 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 245
ERROR - 2016-08-10 21:13:17 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-08-10 21:35:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-10 21:37:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:37:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:37:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:37:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:43:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:45:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:45:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:45:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:45:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:50:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:50:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
ERROR - 2016-08-10 21:50:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 48
