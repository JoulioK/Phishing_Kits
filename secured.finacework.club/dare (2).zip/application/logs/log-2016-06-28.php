<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-28 06:21:39 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-28 06:21:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-28 06:21:44 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\fastfood\application\controllers\management\users.php 90
ERROR - 2016-06-28 06:22:08 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 58
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 58
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 76
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 76
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 81
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 81
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 86
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 86
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 94
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 94
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 170
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 170
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 178
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 178
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 192
ERROR - 2016-06-28 06:22:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 192
ERROR - 2016-06-28 06:23:41 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 45
ERROR - 2016-06-28 06:23:41 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 81
ERROR - 2016-06-28 06:23:41 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 86
ERROR - 2016-06-28 06:23:41 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:23:41 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:24:26 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 45
ERROR - 2016-06-28 06:24:26 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 81
ERROR - 2016-06-28 06:24:26 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 86
ERROR - 2016-06-28 06:24:26 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:24:26 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:25:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 45
ERROR - 2016-06-28 06:25:34 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:25:34 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:26:25 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:26:25 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:26:46 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 179
ERROR - 2016-06-28 06:26:46 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 183
ERROR - 2016-06-28 06:27:29 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:27:29 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:28:32 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:28:32 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 06:29:53 --> Severity: Notice --> Undefined property: stdClass::$phone_number C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 182
ERROR - 2016-06-28 06:29:53 --> Severity: Notice --> Undefined property: stdClass::$email_address C:\xampp\htdocs\fastfood\application\views\management\users\create_users.php 186
ERROR - 2016-06-28 22:43:41 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-28 22:43:44 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-28 22:44:40 --> 404 Page Not Found: Admin/Users
ERROR - 2016-06-28 22:44:47 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-28 22:53:09 --> 404 Page Not Found: management/View_users/index
ERROR - 2016-06-28 22:53:16 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 32
ERROR - 2016-06-28 22:53:16 --> Severity: Notice --> Undefined variable: existingUsers C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 67
ERROR - 2016-06-28 22:53:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 67
ERROR - 2016-06-28 22:53:41 --> Severity: Notice --> Undefined variable: existingUsers C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 67
ERROR - 2016-06-28 22:53:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 67
ERROR - 2016-06-28 22:58:21 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 88
ERROR - 2016-06-28 22:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\users\view_users.php 88
ERROR - 2016-06-28 23:12:11 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-28 23:12:17 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-28 23:43:50 --> 404 Page Not Found: vendor/View_user/index
ERROR - 2016-06-28 23:43:54 --> 404 Page Not Found: vendor/View_users/index
ERROR - 2016-06-28 23:44:21 --> 404 Page Not Found: Admin/Users
