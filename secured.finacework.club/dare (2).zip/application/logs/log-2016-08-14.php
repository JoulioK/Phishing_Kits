<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-14 13:17:39 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 13:18:24 --> 404 Page Not Found: management/Item_unit/index
ERROR - 2016-08-14 14:08:17 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-08-14 14:09:08 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:09:15 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:11:12 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:11:18 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:13:24 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:13:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:13:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 26
ERROR - 2016-08-14 14:17:09 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:17:47 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-08-14 14:19:29 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-08-14 14:24:00 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 14:24:03 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 14:36:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 17
ERROR - 2016-08-14 14:36:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 67
ERROR - 2016-08-14 14:38:29 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 14:38:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 14:38:49 --> Severity: Notice --> Undefined property: stdClass::$itemsperdelivery C:\xampp\htdocs\fastfood\application\views\management\configuration\configuration.php 64
ERROR - 2016-08-14 15:14:48 --> Severity: Notice --> Undefined property: stdClass::$itemsperdelivery C:\xampp\htdocs\fastfood\application\views\management\configuration\configuration.php 64
ERROR - 2016-08-14 15:17:59 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 15:21:27 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 15:22:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 15:22:09 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 15:22:11 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 15:22:27 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 15:30:00 --> Severity: Notice --> Undefined variable: topcategories C:\xampp\htdocs\fastfood\application\controllers\web\item.php 27
ERROR - 2016-08-14 15:30:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\web\item.php 27
ERROR - 2016-08-14 15:30:00 --> Severity: Notice --> Undefined variable: catnames C:\xampp\htdocs\fastfood\application\controllers\web\item.php 34
ERROR - 2016-08-14 15:30:00 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\web\item.php 34
ERROR - 2016-08-14 15:33:51 --> Severity: Notice --> Undefined variable: shippingtotal C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 116
ERROR - 2016-08-14 15:49:26 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 15:49:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 16:01:49 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-14 16:01:50 --> Severity: Notice --> Undefined property: stdClass::$vendoraddress C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 45
ERROR - 2016-08-14 16:01:50 --> Severity: Notice --> Undefined property: stdClass::$vendoremail C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 75
ERROR - 2016-08-14 16:01:50 --> Severity: Notice --> Undefined property: stdClass::$vendorphone C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 81
ERROR - 2016-08-14 16:01:50 --> Severity: Notice --> Undefined property: stdClass::$vendorusername C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 97
ERROR - 2016-08-14 16:04:03 --> 404 Page Not Found: web/Home/shipping
ERROR - 2016-08-14 16:36:43 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-14 16:44:20 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 16:44:28 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-14 17:00:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-14 17:02:02 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-14 17:13:10 --> 404 Page Not Found: web/Faq/index
ERROR - 2016-08-14 17:18:08 --> 404 Page Not Found: management/Faqs/index
ERROR - 2016-08-14 17:24:40 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\management\pages.php 80
ERROR - 2016-08-14 17:24:40 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\management\pages.php 80
ERROR - 2016-08-14 21:22:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'snappyme_olafash'@'localhost' (using password: YES) C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-08-14 21:22:39 --> Unable to connect to the database
ERROR - 2016-08-14 21:25:39 --> 404 Page Not Found: web/Faq/index
ERROR - 2016-08-14 21:26:00 --> 404 Page Not Found: 
ERROR - 2016-08-14 21:45:05 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 149
ERROR - 2016-08-14 21:48:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-14 22:39:50 --> 404 Page Not Found: 
ERROR - 2016-08-14 22:43:47 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
ERROR - 2016-08-14 22:44:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 151
