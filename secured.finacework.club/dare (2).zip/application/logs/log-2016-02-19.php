<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-19 08:46:01 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-19 08:46:31 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-19 09:18:41 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 09:18:42 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 09:21:13 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 09:21:14 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 09:21:29 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 09:21:30 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 09:21:30 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 09:21:30 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 09:21:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 09:21:31 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 09:21:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 09:21:31 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 09:21:32 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 09:21:32 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 09:21:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:21:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:21:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:26:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:26:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:38:10 --> Severity: Notice --> Undefined property: Stock::$Stock_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 36
ERROR - 2016-02-19 09:38:11 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 36
ERROR - 2016-02-19 09:38:35 --> Severity: Notice --> Undefined variable: stock_category C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 44
ERROR - 2016-02-19 09:38:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 44
ERROR - 2016-02-19 09:38:35 --> Severity: Notice --> Undefined variable: stock_category C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 48
ERROR - 2016-02-19 09:38:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 48
ERROR - 2016-02-19 09:38:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:39:01 --> Severity: Notice --> Undefined variable: stock_category C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 44
ERROR - 2016-02-19 09:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 44
ERROR - 2016-02-19 09:39:01 --> Severity: Notice --> Undefined variable: stock_category C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 48
ERROR - 2016-02-19 09:39:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 48
ERROR - 2016-02-19 09:39:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:41:39 --> Severity: Notice --> Undefined property: stdClass::$stock_name C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 36
ERROR - 2016-02-19 09:41:39 --> Severity: Notice --> Undefined property: stdClass::$stock_name C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 98
ERROR - 2016-02-19 09:41:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:41:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:42:24 --> Severity: Notice --> Undefined property: stdClass::$stock_name C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 98
ERROR - 2016-02-19 09:42:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:42:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:42:40 --> Severity: Notice --> Undefined property: stdClass::$stock_name C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 98
ERROR - 2016-02-19 09:42:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:42:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:43:10 --> Severity: Notice --> Undefined property: stdClass::$stock_name C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 98
ERROR - 2016-02-19 09:43:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:43:29 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;stock_id&quot; does not exist
LINE 3: WHERE &quot;stock_id&quot; = '0832980395'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:43:29 --> Query error: ERROR:  column "stock_id" does not exist
LINE 3: WHERE "stock_id" = '0832980395'
              ^ - Invalid query: SELECT *
FROM "t_stocks"
WHERE "stock_id" = '0832980395'
AND "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:44:07 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stocks&quot; does not exist
LINE 2: FROM &quot;t_stocks&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:44:07 --> Query error: ERROR:  relation "t_stocks" does not exist
LINE 2: FROM "t_stocks"
             ^ - Invalid query: SELECT *
FROM "t_stocks"
WHERE "stock_id" = '4031922223'
AND "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:44:16 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;stock_id&quot; does not exist
LINE 3: WHERE &quot;stock_id&quot; = '0840662867'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:44:16 --> Query error: ERROR:  column "stock_id" does not exist
LINE 3: WHERE "stock_id" = '0840662867'
              ^ - Invalid query: SELECT *
FROM "t_stocks"
WHERE "stock_id" = '0840662867'
AND "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:44:35 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stocks&quot; does not exist
LINE 2: FROM &quot;t_stocks&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:44:35 --> Query error: ERROR:  relation "t_stocks" does not exist
LINE 2: FROM "t_stocks"
             ^ - Invalid query: SELECT *
FROM "t_stocks"
WHERE "stock_id" = '9496330452'
AND "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:44:44 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stocks&quot; does not exist
LINE 2: FROM &quot;t_stocks&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:44:44 --> Query error: ERROR:  relation "t_stocks" does not exist
LINE 2: FROM "t_stocks"
             ^ - Invalid query: SELECT *
FROM "t_stocks"
WHERE "stock_id" = '8825887011'
AND "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:44:55 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;stock_name&quot; of relation &quot;t_stock_categories&quot; does not exist
LINE 1: ...T INTO &quot;t_stock_categories&quot; (&quot;stock_category_id&quot;, &quot;stock_nam...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:44:55 --> Query error: ERROR:  column "stock_name" of relation "t_stock_categories" does not exist
LINE 1: ...T INTO "t_stock_categories" ("stock_category_id", "stock_nam...
                                                             ^ - Invalid query: INSERT INTO "t_stock_categories" ("stock_category_id", "stock_name", "stock_description", "storeid", "added_by", "stock_id") VALUES ('3', 'MILO 750KG', 'MILO 750KG', '1111111111', '2222222222', '6196364149')
ERROR - 2016-02-19 09:45:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:48:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:48:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:49:27 --> Severity: Notice --> Undefined variable: existing_stocks C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Page.php 67
ERROR - 2016-02-19 09:49:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:49:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:50:05 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_Categories&quot; does not exist
LINE 3: INNER JOIN &quot;t_stock_Categories&quot; ON &quot;t_stock_categories&quot;.&quot;sto...
                   ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:50:05 --> Query error: ERROR:  relation "t_stock_Categories" does not exist
LINE 3: INNER JOIN "t_stock_Categories" ON "t_stock_categories"."sto...
                   ^ - Invalid query: SELECT "t_stocks".*, "t_stock_categories"."stock_category_name"
FROM "t_stocks"
INNER JOIN "t_stock_Categories" ON "t_stock_categories"."stock_category_id" = "t_stocks"."stock_category_id"
WHERE "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:50:18 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character varying = integer
LINE 3: ...ries&quot; ON &quot;t_stock_categories&quot;.&quot;stock_category_id&quot; = &quot;t_stock...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:50:18 --> Query error: ERROR:  operator does not exist: character varying = integer
LINE 3: ...ries" ON "t_stock_categories"."stock_category_id" = "t_stock...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT "t_stocks".*, "t_stock_categories"."stock_category_name"
FROM "t_stocks"
INNER JOIN "t_stock_categories" ON "t_stock_categories"."stock_category_id" = "t_stocks"."stock_category_id"
WHERE "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:57:15 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_categories&quot; does not exist
LINE 2: FROM &quot;t_stock_categories&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:57:15 --> Query error: ERROR:  relation "t_stock_categories" does not exist
LINE 2: FROM "t_stock_categories"
             ^ - Invalid query: SELECT *
FROM "t_stock_categories"
WHERE "storeid" = '1111111111'
ORDER BY "t_stock_categories"."id" ASC
ERROR - 2016-02-19 09:57:21 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column reference &quot;storeid&quot; is ambiguous
LINE 4: WHERE &quot;storeid&quot; = '1111111111'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 09:57:21 --> Query error: ERROR:  column reference "storeid" is ambiguous
LINE 4: WHERE "storeid" = '1111111111'
              ^ - Invalid query: SELECT "t_stocks".*, "t_stock_categories"."stock_category_name"
FROM "t_stocks"
INNER JOIN "t_stock_categories" ON "t_stock_categories"."stock_category_id" = "t_stocks"."stock_category_id"
WHERE "storeid" = '1111111111'
ORDER BY "t_stocks"."id" ASC
ERROR - 2016-02-19 09:58:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:58:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:59:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:59:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 09:59:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:00:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:00:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:00:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:03:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:03:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:05:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:05:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:05:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:05:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:06:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:06:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:06:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:07:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:07:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:08:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 44
ERROR - 2016-02-19 10:08:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 48
ERROR - 2016-02-19 10:08:38 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:08:39 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:08:40 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:08:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:08:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:08:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:08:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:09:23 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:09:23 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:09:23 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:09:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:09:23 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:09:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 10:09:24 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 10:09:24 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 10:09:24 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 10:09:24 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 10:09:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:09:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:10:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:10:15 --> 404 Page Not Found: Stock/Stock_Categories
ERROR - 2016-02-19 10:10:34 --> 404 Page Not Found: Stock/Stocks
ERROR - 2016-02-19 10:10:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:10:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:11:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:11:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:11:04 --> 404 Page Not Found: Store/Stock/Store
ERROR - 2016-02-19 10:12:26 --> 404 Page Not Found: Store/Stock/Store
ERROR - 2016-02-19 10:12:33 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:12:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:12:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:12:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:13:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:13:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:13:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:14:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:14:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:14:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:15:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:15:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:19 --> 404 Page Not Found: Store/Stock/TakeStock
ERROR - 2016-02-19 10:17:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:17:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:19:43 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 92
ERROR - 2016-02-19 10:19:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:19:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:20:15 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 91
ERROR - 2016-02-19 10:20:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:23:19 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 29
ERROR - 2016-02-19 10:23:19 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 33
ERROR - 2016-02-19 10:23:19 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 37
ERROR - 2016-02-19 10:23:19 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 41
ERROR - 2016-02-19 10:23:19 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 99
ERROR - 2016-02-19 10:23:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:23:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 29
ERROR - 2016-02-19 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 33
ERROR - 2016-02-19 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 37
ERROR - 2016-02-19 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 41
ERROR - 2016-02-19 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 99
ERROR - 2016-02-19 10:24:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:24:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:25:42 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 29
ERROR - 2016-02-19 10:25:42 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 33
ERROR - 2016-02-19 10:25:42 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 37
ERROR - 2016-02-19 10:25:42 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 41
ERROR - 2016-02-19 10:25:42 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 99
ERROR - 2016-02-19 10:25:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:25:47 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 29
ERROR - 2016-02-19 10:25:47 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 33
ERROR - 2016-02-19 10:25:47 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 37
ERROR - 2016-02-19 10:25:47 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 41
ERROR - 2016-02-19 10:25:47 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 99
ERROR - 2016-02-19 10:25:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:25:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:26:41 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 29
ERROR - 2016-02-19 10:26:41 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 33
ERROR - 2016-02-19 10:26:41 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 37
ERROR - 2016-02-19 10:26:41 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 41
ERROR - 2016-02-19 10:26:41 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 99
ERROR - 2016-02-19 10:26:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:26:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:27:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:27:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:27:41 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 10:27:41 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 10:27:41 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 10:27:41 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 10:27:41 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 98
ERROR - 2016-02-19 10:27:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:27:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:28:14 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 10:28:14 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 98
ERROR - 2016-02-19 10:28:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:28:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:30:52 --> Severity: Notice --> Undefined property: stdClass::$additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 10:30:52 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:30:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:30:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:31:59 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:31:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:31:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:37:52 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:37:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:37:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:40:10 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:40:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:40:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:41:22 --> Severity: Warning --> pg_query(): Query failed: ERROR:  type &quot;datetime&quot; does not exist
LINE 9:  &quot;stock_datesupplied&quot; DATETIME NOT NULL,
                              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:41:22 --> Query error: ERROR:  type "datetime" does not exist
LINE 9:  "stock_datesupplied" DATETIME NOT NULL,
                              ^ - Invalid query: CREATE TABLE "t_stock_taking" (
	"id" SERIAL NOT NULL,
	"storeid" VARCHAR(10) NOT NULL,
	"stock_id" VARCHAR(10) NOT NULL,
	"stock_qty" INT NOT NULL,
	"stock_selling_price" DECIMAL(10) NOT NULL,
	"stock_additional_info" TEXT NOT NULL,
	"stock_supplier" TEXT NOT NULL,
	"stock_datesupplied" DATETIME NOT NULL,
	"added_by" VARCHAR(10) NOT NULL,
	datecreated timestamp default now(),
	datemodified timestamp default now(),
	CONSTRAINT "pk_t_stock_taking" PRIMARY KEY("id")
)
ERROR - 2016-02-19 10:42:37 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:42:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:42:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:44:42 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;entryid&quot; does not exist
LINE 3: WHERE &quot;entryid&quot; = '9318570003'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:44:42 --> Query error: ERROR:  column "entryid" does not exist
LINE 3: WHERE "entryid" = '9318570003'
              ^ - Invalid query: SELECT *
FROM "t_stock_taking"
WHERE "entryid" = '9318570003'
AND "t_stock_taking"."storeid" = '1111111111'
ORDER BY "t_stock_taking"."id" ASC
ERROR - 2016-02-19 10:44:57 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_taking&quot; does not exist
LINE 2: FROM &quot;t_stock_taking&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:44:57 --> Query error: ERROR:  relation "t_stock_taking" does not exist
LINE 2: FROM "t_stock_taking"
             ^ - Invalid query: SELECT *
FROM "t_stock_taking"
WHERE "entryid" = '8778525083'
AND "t_stock_taking"."storeid" = '1111111111'
ORDER BY "t_stock_taking"."id" ASC
ERROR - 2016-02-19 10:45:06 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;stock_cost_price&quot; of relation &quot;t_stock_taking&quot; does not exist
LINE 1: ...T INTO &quot;t_stock_taking&quot; (&quot;stock_id&quot;, &quot;stock_qty&quot;, &quot;stock_cos...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:45:06 --> Query error: ERROR:  column "stock_cost_price" of relation "t_stock_taking" does not exist
LINE 1: ...T INTO "t_stock_taking" ("stock_id", "stock_qty", "stock_cos...
                                                             ^ - Invalid query: INSERT INTO "t_stock_taking" ("stock_id", "stock_qty", "stock_cost_price", "stock_selling_price", "stock_additional_info", "stock_datesupplied", "stock_supplier", "storeid", "added_by", "entryid") VALUES ('8492881610', '100', '700', '800', '', '2016-02-19 10:42:37', 'MADAM', '1111111111', '2222222222', '6472008503')
ERROR - 2016-02-19 10:45:28 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_taking&quot; does not exist
LINE 2: FROM &quot;t_stock_taking&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:45:28 --> Query error: ERROR:  relation "t_stock_taking" does not exist
LINE 2: FROM "t_stock_taking"
             ^ - Invalid query: SELECT *
FROM "t_stock_taking"
WHERE "entryid" = '2642606101'
AND "t_stock_taking"."storeid" = '1111111111'
ORDER BY "t_stock_taking"."id" ASC
ERROR - 2016-02-19 10:45:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:46:26 --> Severity: Notice --> Undefined property: stdClass::$stock_category_name C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 106
ERROR - 2016-02-19 10:46:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:50:02 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;t_stock_takind&quot;
LINE 3: INNER JOIN &quot;t_stocks&quot; ON &quot;t_stocks&quot;.&quot;stock_id&quot; = &quot;t_stock_ta...
                                                         ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 10:50:02 --> Query error: ERROR:  missing FROM-clause entry for table "t_stock_takind"
LINE 3: INNER JOIN "t_stocks" ON "t_stocks"."stock_id" = "t_stock_ta...
                                                         ^ - Invalid query: SELECT "t_stock_taking".*, "t_stocks"."stock_name"
FROM "t_stock_taking"
INNER JOIN "t_stocks" ON "t_stocks"."stock_id" = "t_stock_takind"."stockid"
WHERE "t_stock_taking"."storeid" = '1111111111'
ORDER BY "datemodified" DESC, "t_stock_taking"."id" ASC
ERROR - 2016-02-19 10:51:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:53:40 --> Severity: Notice --> Undefined property: stdClass::$stock_additionalinfo C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 130
ERROR - 2016-02-19 10:53:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:53:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:53:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:55:23 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:56:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:56:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:56:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 10:56:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 10:58:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:58:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 10:59:44 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 140
ERROR - 2016-02-19 11:00:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:00:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:00:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:00:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:05:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:05:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:11:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:11:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:13:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:13:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:13:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:18:27 --> Severity: Notice --> Undefined variable: farmid C:\xampp\htdocs\estore\application\core\MY_Model.php 139
ERROR - 2016-02-19 11:18:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:18:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:19:15 --> Severity: Notice --> Undefined variable: farmid C:\xampp\htdocs\estore\application\core\MY_Model.php 145
ERROR - 2016-02-19 11:19:15 --> Severity: Notice --> Undefined property: Stock::$_table_name C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 11:19:15 --> Severity: Warning --> pg_query(): Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 11:19:15 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ - Invalid query: SELECT *
WHERE "storeid" IS NULL
AND "stock_id" = '8492881610'
ERROR - 2016-02-19 11:19:33 --> Severity: Notice --> Undefined property: Stock::$_table_name C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 11:19:33 --> Severity: Warning --> pg_query(): Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 11:19:33 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ - Invalid query: SELECT *
WHERE "storeid" = '1111111111'
AND "stock_id" = '8492881610'
ERROR - 2016-02-19 11:24:47 --> Severity: Notice --> Undefined property: Stock::$Stock_Ledger_Model C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 11:24:47 --> Severity: Error --> Call to a member function generate_unique_id() on null C:\xampp\htdocs\estore\application\core\MY_Model.php 219
ERROR - 2016-02-19 11:25:45 --> Severity: Error --> Call to undefined method Stock_Taking_Model::save_update() C:\xampp\htdocs\estore\application\core\MY_Model.php 220
ERROR - 2016-02-19 11:26:45 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;ledger_id&quot; of relation &quot;t_stock_taking&quot; does not exist
LINE 1: ...tock_taking&quot; (&quot;storeid&quot;, &quot;stock_id&quot;, &quot;stock_qty&quot;, &quot;ledger_id...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 11:26:45 --> Query error: ERROR:  column "ledger_id" of relation "t_stock_taking" does not exist
LINE 1: ...tock_taking" ("storeid", "stock_id", "stock_qty", "ledger_id...
                                                             ^ - Invalid query: INSERT INTO "t_stock_taking" ("storeid", "stock_id", "stock_qty", "ledger_id") VALUES ('1111111111', '8492881610', '1000', '4003524353')
ERROR - 2016-02-19 11:27:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:27:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:27:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:27:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:27:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:30:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:30:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:31:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:31:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:32:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:52:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:52:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:52:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:52:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:53:14 --> Severity: Notice --> Undefined variable: batch_data C:\xampp\htdocs\estore\application\core\MY_Model.php 158
ERROR - 2016-02-19 11:53:14 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 11:53:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:53:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:54:11 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:54:25 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;8492881610&quot;
LINE 1: ...NSERT INTO &quot;STOCK_LEDGER&quot; (&quot;storeid&quot;, &quot;stock_id&quot;, 8492881610...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 11:54:25 --> Query error: ERROR:  syntax error at or near "8492881610"
LINE 1: ...NSERT INTO "STOCK_LEDGER" ("storeid", "stock_id", 8492881610...
                                                             ^ - Invalid query: INSERT INTO "STOCK_LEDGER" ("storeid", "stock_id", 8492881610, "ledger_id") VALUES ('1111111111', 'stock_qty', '10000', '7788192270')
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:55:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:55:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:56:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:56:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:56:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:58:18 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:58:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:58:18 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:58:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:58:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 11:58:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 11:58:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:14:25 --> Severity: Notice --> Undefined variable: batch_data C:\xampp\htdocs\estore\application\core\MY_Model.php 159
ERROR - 2016-02-19 12:14:25 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:14:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:15:07 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:15:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:17:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:17:53 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;8492881610&quot;
LINE 1: ...NSERT INTO &quot;STOCK_LEDGER&quot; (&quot;storeid&quot;, &quot;stock_id&quot;, 8492881610...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 12:17:53 --> Query error: ERROR:  syntax error at or near "8492881610"
LINE 1: ...NSERT INTO "STOCK_LEDGER" ("storeid", "stock_id", 8492881610...
                                                             ^ - Invalid query: INSERT INTO "STOCK_LEDGER" ("storeid", "stock_id", 8492881610, "ledger_id") VALUES ('1111111111', 'stock_qty', '1000', '4464613264')
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:20:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:20:57 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:20:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:20:57 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:20:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:20:59 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:34 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:21:34 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:21:34 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:21:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:21:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:21:51 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:21:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:21:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:22:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:22:07 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:22:07 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 176
ERROR - 2016-02-19 12:22:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:24:22 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:24:22 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 176
ERROR - 2016-02-19 12:24:23 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:24:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:24:49 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:24:49 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 176
ERROR - 2016-02-19 12:24:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:24:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:28:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 28
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 32
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 36
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 40
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 44
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:28:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 48
ERROR - 2016-02-19 12:28:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:29:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:29:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:29:45 --> Severity: Error --> Call to undefined method Stock_Taking_Model::save_update() C:\xampp\htdocs\estore\application\core\MY_Model.php 191
ERROR - 2016-02-19 12:30:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:30:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:30:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:30:51 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 176
ERROR - 2016-02-19 12:30:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:32:33 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:32:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:45:22 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:45:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:45:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:45:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:45:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:51:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:52:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:52:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:52:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:52:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:53:17 --> Severity: Notice --> Undefined property: Stock::$_operation C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 12:53:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:53:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:54:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:54:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:21 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 179
ERROR - 2016-02-19 12:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:23 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:55:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:58:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 12:58:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\core\MY_Model.php 174
ERROR - 2016-02-19 12:58:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\core\MY_Model.php 175
ERROR - 2016-02-19 12:58:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;NULL&quot;
LINE 3: AND  IS NULL
                ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 12:58:37 --> Query error: ERROR:  syntax error at or near "NULL"
LINE 3: AND  IS NULL
                ^ - Invalid query: SELECT *
WHERE "store" = '1111111111'
AND  IS NULL
ERROR - 2016-02-19 13:05:51 --> Severity: Notice --> Undefined property: Stock::$_table_name C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-19 13:05:51 --> Severity: Warning --> pg_query(): Query failed: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 13:05:51 --> Query error: ERROR:  SELECT * with no tables specified is not valid
LINE 1: SELECT *
               ^ - Invalid query: SELECT *
WHERE "storeid" = '1111111111'
AND "id" = '26'
ERROR - 2016-02-19 13:07:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 13:08:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:38:51 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 14:38:51 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-19 14:54:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:54:55 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:38 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 185
ERROR - 2016-02-19 14:55:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:55:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:56:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:56:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:58:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 14:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:02:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:02:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:03:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:03:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:09:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:09:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:09:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:10:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:10:42 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:10:42 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:10:42 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:10:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:10:42 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:10:43 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:12:44 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:12:44 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:12:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:12:44 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:12:44 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:12:45 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:13:17 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:13:18 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:13:18 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:13:18 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:13:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:13:20 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:13:20 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:13:20 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:13:20 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:16:36 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:16:36 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:16:36 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:16:36 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:16:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:16:38 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:16:38 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:16:38 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:16:38 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:16:42 --> 404 Page Not Found: Store/Stock/Sales
ERROR - 2016-02-19 15:17:11 --> 404 Page Not Found: Store/Stock/Sales
ERROR - 2016-02-19 15:17:14 --> 404 Page Not Found: Store/Stock/Sales
ERROR - 2016-02-19 15:22:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:23:07 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_Page.php 30
ERROR - 2016-02-19 15:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_Page.php 30
ERROR - 2016-02-19 15:23:07 --> Severity: Notice --> Undefined variable: stock C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_Page.php 34
ERROR - 2016-02-19 15:23:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_Page.php 34
ERROR - 2016-02-19 15:23:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:24:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:27:03 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;stockid&quot;
LINE 3: INNER JOIN &quot;t_stocks&quot; ON &quot;t_stocks&quot;.&quot;stockid&quot;.&quot;t_stock_takin...
                                 ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 15:27:03 --> Query error: ERROR:  missing FROM-clause entry for table "stockid"
LINE 3: INNER JOIN "t_stocks" ON "t_stocks"."stockid"."t_stock_takin...
                                 ^ - Invalid query: SELECT *
FROM "t_stock_taking"
INNER JOIN "t_stocks" ON "t_stocks"."stockid"."t_stock_taking"
WHERE "t_stock_taking"."storeid" = '1111111111'
ORDER BY "t_stock_taking"."id" ASC
ERROR - 2016-02-19 15:27:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;stockid&quot;
LINE 3: INNER JOIN &quot;t_stocks&quot; ON &quot;t_stocks&quot;.&quot;stockid&quot;.&quot;t_stock_takin...
                                 ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-19 15:27:37 --> Query error: ERROR:  missing FROM-clause entry for table "stockid"
LINE 3: INNER JOIN "t_stocks" ON "t_stocks"."stockid"."t_stock_takin...
                                 ^ - Invalid query: SELECT "t_stocks".*, "t_stock_taking".*
FROM "t_stock_taking"
INNER JOIN "t_stocks" ON "t_stocks"."stockid"."t_stock_taking"
WHERE "t_stock_taking"."storeid" = '1111111111'
ORDER BY "t_stock_taking"."id" ASC
ERROR - 2016-02-19 15:43:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:44:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:45:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:45:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:45:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:49:12 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:49:12 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:49:12 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:49:12 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:49:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:49:13 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:49:13 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:49:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:51:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:51:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:51:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:51:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:51:59 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:51:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:52:00 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:52:00 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:52:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:52:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:53:56 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-19 15:53:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-19 15:53:56 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-19 15:53:57 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:53:57 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:53:57 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-19 15:53:57 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-19 15:54:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:54:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:54:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-19 15:54:12 --> 404 Page Not Found: Store/Stock/images
