<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-12 07:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:28:55 --> Severity: error --> Exception: Failed:  C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:28:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\snappycoin\system\core\Exceptions.php:272) C:\xampp\htdocs\snappycoin\system\core\Common.php 569
ERROR - 2016-12-12 07:29:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:29:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:29:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:29:02 --> Severity: error --> Exception: Failed:  C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:29:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\snappycoin\system\core\Exceptions.php:272) C:\xampp\htdocs\snappycoin\system\core\Common.php 569
ERROR - 2016-12-12 07:39:13 --> Severity: Compile Error --> Cannot redeclare Orders::pending() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 37
ERROR - 2016-12-12 07:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:39:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:39:27 --> Severity: error --> Exception: Failed:  C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:39:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\snappycoin\system\core\Exceptions.php:272) C:\xampp\htdocs\snappycoin\system\core\Common.php 569
ERROR - 2016-12-12 07:40:17 --> Severity: error --> Exception: Failed:  C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 07:41:04 --> Severity: Notice --> Undefined variable: label C:\xampp\htdocs\snappycoin\application\views\management\orders\pendingsell.php 8
ERROR - 2016-12-12 07:41:04 --> Severity: Notice --> Undefined variable: address C:\xampp\htdocs\snappycoin\application\views\management\orders\pendingsell.php 8
ERROR - 2016-12-12 07:41:04 --> Severity: Notice --> Undefined variable: balance C:\xampp\htdocs\snappycoin\application\views\management\orders\pendingsell.php 8
ERROR - 2016-12-12 07:42:38 --> Severity: error --> Exception: Failed:  C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
ERROR - 2016-12-12 09:49:15 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-12 13:01:19 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 153
ERROR - 2016-12-12 13:32:38 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 222
ERROR - 2016-12-12 15:06:28 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\snappycoin\application\views\management\orders\view_sell_order.php 108
ERROR - 2016-12-12 15:06:42 --> Severity: Notice --> Undefined variable: acount C:\xampp\htdocs\snappycoin\application\models\web\Customer_model.php 47
ERROR - 2016-12-12 15:40:48 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 209
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
ERROR - 2016-12-12 19:56:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 30
