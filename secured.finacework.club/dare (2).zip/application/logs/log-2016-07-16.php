<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-16 00:57:45 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-16 00:58:01 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 00:58:01 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:07:31 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:07:31 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 127
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 127
ERROR - 2016-07-16 01:09:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 130
ERROR - 2016-07-16 01:14:44 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:14:45 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:14:45 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:16:19 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:16:19 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:16:20 --> Severity: Notice --> Undefined property: stdClass::$messagestatus C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 119
ERROR - 2016-07-16 01:16:39 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:16:39 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:18:14 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:18:14 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:18:58 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:18:58 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:19:59 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:19:59 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:20:12 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:20:12 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:21:10 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-16 01:21:10 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$datecreated C:\xampp\htdocs\fastfood\application\models\web\message_model.php 54
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$datecreated C:\xampp\htdocs\fastfood\application\models\web\message_model.php 54
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$datecreated C:\xampp\htdocs\fastfood\application\models\web\message_model.php 54
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:12 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:44:48 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 125
ERROR - 2016-07-16 01:45:23 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:45:23 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 01:45:23 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 122
ERROR - 2016-07-16 02:38:10 --> Severity: Error --> Call to undefined method Messages::trendpagination() C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 96
ERROR - 2016-07-16 02:39:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:43:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:43:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:48:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 66
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 02:50:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 67
ERROR - 2016-07-16 10:25:24 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-16 10:25:25 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-16 10:28:30 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:28:30 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:28:30 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:29:49 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:29:49 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:29:49 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:31:10 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:31:10 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:31:10 --> Severity: Notice --> Undefined variable: folders C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 101
ERROR - 2016-07-16 10:31:35 --> 404 Page Not Found: management/Messages/inbox
ERROR - 2016-07-16 10:31:55 --> 404 Page Not Found: management/Messages/inbox
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 54
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 54
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 55
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 55
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 56
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 56
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 57
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 57
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 58
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 58
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 59
ERROR - 2016-07-16 10:50:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 59
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 54
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 54
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 55
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 55
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 56
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 56
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 57
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 57
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 58
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 58
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 59
ERROR - 2016-07-16 10:51:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 59
ERROR - 2016-07-16 11:04:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 112
ERROR - 2016-07-16 11:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 112
ERROR - 2016-07-16 11:04:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 113
ERROR - 2016-07-16 11:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 113
ERROR - 2016-07-16 12:54:51 --> Severity: Warning --> Missing argument 1 for Messages::trend() C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 56
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Undefined variable: trendid C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 101
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Undefined variable: trendid C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 102
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Undefined variable: trendid C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 103
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 112
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 112
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 113
ERROR - 2016-07-16 12:54:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\messages\trend.php 113
