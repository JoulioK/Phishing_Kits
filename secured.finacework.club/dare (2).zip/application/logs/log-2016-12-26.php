<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-26 11:22:07 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\charity\application\config\_params.php 63
ERROR - 2016-12-26 11:22:57 --> Severity: Notice --> Undefined variable: quotes C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 6
ERROR - 2016-12-26 15:59:26 --> Query error: Table 'helpcabal.tbl_user' doesn't exist - Invalid query: UPDATE `tbl_user` SET `datemodified` = '2016-12-26 15:59:25', `enabled` = 0
WHERE `userid` = '14826692594374ss'
