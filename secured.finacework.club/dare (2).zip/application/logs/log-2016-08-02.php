<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:39:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:40:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:45:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 156
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 157
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 158
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 16:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 159
ERROR - 2016-08-02 20:59:22 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 44
ERROR - 2016-08-02 20:59:31 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 44
ERROR - 2016-08-02 21:00:11 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 44
ERROR - 2016-08-02 21:02:08 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 44
ERROR - 2016-08-02 21:36:28 --> Query error: Unknown column 'datecreated' in 'order clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `franchiseid` = '2626273373'
ORDER BY `datecreated` desc
ERROR - 2016-08-02 21:36:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 107
ERROR - 2016-08-02 21:36:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 108
ERROR - 2016-08-02 21:36:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 109
ERROR - 2016-08-02 21:36:54 --> Severity: Notice --> Undefined variable: dmessage C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 143
ERROR - 2016-08-02 21:36:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\messages.php 146
ERROR - 2016-08-02 21:37:54 --> Query error: Unknown column 'datecreated' in 'order clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `franchiseid` = '2626273373'
ORDER BY `datecreated` desc
ERROR - 2016-08-02 21:39:27 --> Query error: Unknown column 'datecreated' in 'order clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `franchiseid` = '2626273373'
ORDER BY `datecreated` desc
ERROR - 2016-08-02 23:41:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:41:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:20 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:20 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:20 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:42:21 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-02 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-02 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
