<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-08 17:04:51 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-03-08 17:04:51 --> 404 Page Not Found: management/Js/classie.js
