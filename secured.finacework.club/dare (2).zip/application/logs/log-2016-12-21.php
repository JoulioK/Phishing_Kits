<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-21 01:45:48 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 28
ERROR - 2016-12-21 01:46:34 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 28
ERROR - 2016-12-21 15:10:18 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-21 15:10:19 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
