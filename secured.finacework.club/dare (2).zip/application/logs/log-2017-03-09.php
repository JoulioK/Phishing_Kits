<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-09 04:25:26 --> 404 Page Not Found: management/Js/classie.js
