<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-30 02:47:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\fastfood\application\views\management\configuration\slider.php 62
ERROR - 2016-06-30 03:19:36 --> Severity: Notice --> Undefined property: Configuration::$sliderrules C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-30 03:21:42 --> Severity: Notice --> Undefined property: Configuration::$sliderrules C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-06-30 03:24:44 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-06-30 03:25:07 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 65
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$slider C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$buttonurl C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$buttonurl C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$buttontext C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:46:38 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:46:39 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:46:39 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 60
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$sliderurl C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 62
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$buttonurl C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 63
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$buttonurl C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$buttontext C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 64
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 68
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:47:42 --> Severity: Notice --> Undefined property: stdClass::$sliderid C:\xampp\htdocs\fastfood\application\views\management\configuration\sliders.php 70
ERROR - 2016-06-30 03:50:01 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:50:37 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:52:02 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-06-30 03:52:36 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:53:17 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:53:38 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:56:03 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:56:47 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-06-30 03:57:31 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
