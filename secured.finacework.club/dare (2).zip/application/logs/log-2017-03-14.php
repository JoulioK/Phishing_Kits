<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-14 20:31:55 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-03-14 20:31:55 --> 404 Page Not Found: management/Js/classie.js
