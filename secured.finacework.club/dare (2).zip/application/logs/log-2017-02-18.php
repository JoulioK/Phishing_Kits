<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-18 11:14:26 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\models\web\Earning_model.php 29
ERROR - 2017-02-18 11:15:26 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\charity\application\models\web\Earning_model.php 29
ERROR - 2017-02-18 11:16:10 --> Query error: Table 'helpcabal.page_view' doesn't exist - Invalid query: select distinct(date), earning as amount, is_unique as unique_view from page_view WHERE date BETWEEN '2017-02-01' AND '2017-02-31' AND uid='' order by date desc
ERROR - 2017-02-18 11:17:18 --> Query error: Table 'helpcabal.page_view' doesn't exist - Invalid query: select distinct(date), earning as amount, is_unique as unique_view from page_view WHERE date BETWEEN '2017-02-01' AND '2017-02-31' AND uid='' order by date desc
ERROR - 2017-02-18 11:17:20 --> Query error: Table 'helpcabal.page_view' doesn't exist - Invalid query: select distinct(date), earning as amount, is_unique as unique_view from page_view WHERE date BETWEEN '2017-02-01' AND '2017-02-31' AND uid='' order by date desc
ERROR - 2017-02-18 11:21:09 --> Query error: Unknown column 'sponsor' in 'where clause' - Invalid query: SELECT sum(amount) as amount
FROM `tbl_earning_history`
WHERE tbl_earning_history.datecreated between '2017-02-18 00:00:01' AND '2017-02-18 11:59:59'
AND `datecreated` = '2017-02-18'
AND sponsor  = '14853742757197xj'
ERROR - 2017-02-18 11:21:09 --> Query error: Unknown column 'tbl_earning_history.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487413269
WHERE tbl_earning_history.datecreated between '2017-02-18 00:00:01' AND '2017-02-18 11:59:59'
AND `datecreated` = '2017-02-18'
AND sponsor  = '14853742757197xj'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 11:22:26 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\charity\application\models\web\Earning_model.php 49
ERROR - 2017-02-18 11:22:26 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\charity\application\models\web\Earning_model.php 49
ERROR - 2017-02-18 11:22:26 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\charity\application\models\web\Earning_model.php 54
ERROR - 2017-02-18 11:22:26 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\charity\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2017-02-18 11:22:26 --> Query error:  - Invalid query: 
ERROR - 2017-02-18 11:22:26 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487413346
WHERE datecreated between '' AND ''
AND `datecreated` = '2017-02-18'
AND sponsor  = '14853742757197xj'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 11:22:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\database\DB_driver.php:1697) C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-02-18 11:23:01 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\charity\application\models\web\Earning_model.php 54
ERROR - 2017-02-18 11:23:01 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\charity\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2017-02-18 11:23:01 --> Query error:  - Invalid query: 
ERROR - 2017-02-18 11:23:01 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487413381
WHERE datecreated between '2017-02-01' AND '2017-02-18'
AND `datecreated` = '2017-02-18'
AND sponsor  = '14853742757197xj'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 11:23:02 --> Severity: Notice --> Undefined variable: query C:\xampp\htdocs\charity\application\models\web\Earning_model.php 54
ERROR - 2017-02-18 11:23:02 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\charity\system\database\drivers\mysqli\mysqli_driver.php 221
ERROR - 2017-02-18 11:23:02 --> Query error:  - Invalid query: 
ERROR - 2017-02-18 11:23:02 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487413382
WHERE datecreated between '2017-02-01' AND '2017-02-18'
AND `datecreated` = '2017-02-18'
AND sponsor  = '14853742757197xj'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 11:23:29 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 39
ERROR - 2017-02-18 11:23:29 --> Severity: Error --> Call to undefined method Earning_model::select() C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 71
ERROR - 2017-02-18 11:25:29 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:25:29 --> Severity: Error --> Call to undefined method Earning_model::select() C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 65
ERROR - 2017-02-18 11:41:03 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:41:03 --> Severity: Error --> Call to undefined method Earning_model::select() C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 65
ERROR - 2017-02-18 11:41:42 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:41:42 --> Severity: Error --> Call to undefined method Earning_model::select() C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 64
ERROR - 2017-02-18 11:43:56 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:44:54 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:45:11 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 33
ERROR - 2017-02-18 11:45:53 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:46:20 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:46:57 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:47:08 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:47:34 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:47:57 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 11:48:09 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 12:39:40 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 12:40:16 --> 404 Page Not Found: Earnings/fetch_earnings
ERROR - 2017-02-18 12:40:18 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 12:49:35 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\controllers\web\Earnings.php 21
ERROR - 2017-02-18 12:50:19 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\controllers\web\Earnings.php 19
ERROR - 2017-02-18 12:50:20 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\controllers\web\Earnings.php 19
ERROR - 2017-02-18 12:50:34 --> Query error: Unknown column 'date' in 'order clause' - Invalid query: select distinct(datecreated), sum(amount) as amount from tbl_referral_earnings WHERE datecreated BETWEEN '2017-02-01' AND '2017-02-31' AND sponsor='14853742757197xj' order by date desc
ERROR - 2017-02-18 12:50:56 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:05:29 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:05:50 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:06:39 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:06:47 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:19:45 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\charity\application\models\web\Earning_model.php 78
ERROR - 2017-02-18 13:19:45 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:19:48 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\charity\application\models\web\Earning_model.php 78
ERROR - 2017-02-18 13:19:48 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:20:33 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\charity\application\models\web\Earning_model.php 78
ERROR - 2017-02-18 13:20:33 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:21:11 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\charity\application\models\web\Earning_model.php 78
ERROR - 2017-02-18 13:21:11 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:22:21 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\charity\application\models\web\Earning_model.php 83
ERROR - 2017-02-18 13:22:21 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:22:47 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:23:03 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Earning_model.php 113
ERROR - 2017-02-18 13:24:58 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:25:45 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:26:39 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:27:14 --> 404 Page Not Found: Earnings/fetch_earnings
ERROR - 2017-02-18 13:27:43 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:27:44 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:27:48 --> 404 Page Not Found: Earnings/index
ERROR - 2017-02-18 13:28:02 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:05 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:08 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:14 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:46 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:49 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:54 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:28:57 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:29:25 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:31:09 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:34:30 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:35:26 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:35:29 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:36:51 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:36:54 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 100
ERROR - 2017-02-18 13:37:07 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\models\web\Earning_model.php 101
ERROR - 2017-02-18 13:38:54 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:38:54 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:38:58 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:38:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:40:30 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:40:30 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:40:33 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:40:33 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:41:03 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:41:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:41:32 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:41:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 69
ERROR - 2017-02-18 13:42:03 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:42:45 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:42:50 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:43:22 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:44:02 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 13:44:07 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:07:41 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:07:51 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:09:09 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:09:09 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 76
ERROR - 2017-02-18 14:09:24 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:09:52 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:10:25 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:10:25 --> Severity: Error --> Call to undefined function num_format() C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 90
ERROR - 2017-02-18 14:10:36 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:10:48 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:10:54 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:11:49 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:14:08 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:14:14 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:14:20 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:15:11 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:15:15 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:15:19 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:15:23 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:15:47 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:16:07 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:18:00 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 14:18:24 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 15:00:32 --> Severity: Notice --> Undefined property: stdClass::$points C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 22
ERROR - 2017-02-18 16:27:42 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\models\web\Customer_model.php 163
ERROR - 2017-02-18 17:42:16 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-18 17:42:16 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-18 18:13:27 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 18:14:50 --> Severity: Parsing Error --> syntax error, unexpected '$ghs' (T_VARIABLE) C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 276
ERROR - 2017-02-18 18:40:35 --> Severity: Parsing Error --> syntax error, unexpected '$gh' (T_VARIABLE) C:\xampp\htdocs\charity\application\views\web\customer\incoming.php 119
ERROR - 2017-02-18 19:09:08 --> 404 Page Not Found: web/Howitworks/index
ERROR - 2017-02-18 20:26:51 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:26:51 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:26:51 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:28:21 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:28:21 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:28:21 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:29:22 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:29:22 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:29:22 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:30:08 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:30:08 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:30:08 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:30:15 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:30:15 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:30:15 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:30:22 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:30:22 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:30:22 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:30:59 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 20:30:59 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 20:30:59 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 20:57:00 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 321
ERROR - 2017-02-18 21:11:55 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 24
ERROR - 2017-02-18 21:11:55 --> Severity: Notice --> Undefined property: stdClass::$point C:\xampp\htdocs\charity\application\views\web\customer\hubreward.php 27
ERROR - 2017-02-18 21:11:55 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 22:36:18 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 22:54:25 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Orders.php 661
ERROR - 2017-02-18 22:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 661
ERROR - 2017-02-18 22:54:25 --> Query error: Unknown column 'sponsor' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487454865
WHERE sponsor  = '14855085758813tw'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 22:55:23 --> Severity: Error --> Call to undefined method Orders::get_by() C:\xampp\htdocs\charity\application\controllers\management\Orders.php 660
ERROR - 2017-02-18 22:59:16 --> Severity: Error --> Call to undefined method Orders::get_by() C:\xampp\htdocs\charity\application\controllers\management\Orders.php 665
ERROR - 2017-02-18 22:59:42 --> Query error: Unknown column 'point' in 'field list' - Invalid query: SELECT `point`
FROM `tbl_referral_earnings`
WHERE `userid` = '14855085758813tw'
ERROR - 2017-02-18 22:59:42 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487455182
WHERE `userid` = '14855085758813tw'
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5'
ERROR - 2017-02-18 23:02:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 668
ERROR - 2017-02-18 23:02:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\management\Orders.php 668
ERROR - 2017-02-18 23:10:44 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 23:11:01 --> Severity: Notice --> Undefined variable: point C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 301
ERROR - 2017-02-18 23:33:57 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:34:18 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:34:25 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:35:29 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:39:16 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:39:49 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:42:48 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:42:50 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:42:57 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:43:02 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:43:06 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:44:23 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:47:01 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:50:42 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:54:44 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:54:56 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:55:30 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:56:18 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:56:28 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:57:08 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
ERROR - 2017-02-18 23:58:44 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\charity\application\views\web\customer\earnings.php 29
