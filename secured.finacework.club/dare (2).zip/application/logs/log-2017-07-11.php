<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-11 00:05:05 --> Severity: Warning --> touch() [<a href='function.touch'>function.touch</a>]: Unable to create file ci_sessions/ci_session01006374887d95f5d578c114d1f4b33c4dd5ab9b because No such file or directory /home/secureds/mandatory.securedserver.ltd/system/libraries/Session/drivers/Session_files_driver.php 234
