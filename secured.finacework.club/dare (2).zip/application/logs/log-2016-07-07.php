<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-07 10:52:04 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-07 10:52:06 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:06 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:06 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:07 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:08 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-07 10:52:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-07 10:52:19 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-07 10:52:20 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-07 10:52:21 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-07 10:52:21 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-07 10:52:21 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-07 10:52:21 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-07 10:52:21 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-07 10:52:24 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\fastfood\application\controllers\web\item.php 181
ERROR - 2016-07-07 10:53:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:53:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:53:59 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\web\item.php 221
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-07 10:54:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-07 10:54:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:41 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:42 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:54:43 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:06 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:07 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:24 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:25 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:26 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:55:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:32 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:33 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:34 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:35 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:56:36 --> 404 Page Not Found: web/Item/images
ERROR - 2016-07-07 10:58:54 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:55 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:58 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:58:59 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:00 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
ERROR - 2016-07-07 10:59:01 --> Severity: Notice --> Undefined variable: total C:\xampp\htdocs\fastfood\application\views\web\pages\receipt.php 164
