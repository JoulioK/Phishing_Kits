<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 81
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14711898675769hb C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14711905227641sf C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14712958890068jh C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14712959838004fx C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14712964981108xw C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14713262774355ql C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:34:48 --> Severity: Notice --> Undefined index: 14713263332310wq C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 116
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 76
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14711898675769hb C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14711905227641sf C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14712958890068jh C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14712959838004fx C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14712964981108xw C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14713262774355ql C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:37:29 --> Severity: Notice --> Undefined index: 14713263332310wq C:\xampp\htdocs\fastfood\application\controllers\app\Home.php 111
ERROR - 2016-08-18 16:56:55 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 16:56:56 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\Categories.php 131
ERROR - 2016-08-18 17:10:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:07 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:10:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:18 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:10:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:19 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:10:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:20 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:10:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:20 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:10:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:10:48 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:12:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-18 17:12:27 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-18 17:31:59 --> Severity: Error --> Call to undefined function html_entities() C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 39
ERROR - 2016-08-18 20:31:13 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\fastfood\application\controllers\app\Page.php 42
ERROR - 2016-08-18 20:32:30 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\fastfood\application\controllers\app\Page.php 42
ERROR - 2016-08-18 20:58:51 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 16
ERROR - 2016-08-18 20:59:09 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 16
ERROR - 2016-08-18 21:00:07 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 16
ERROR - 2016-08-18 21:00:12 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 16
ERROR - 2016-08-18 21:00:18 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 16
ERROR - 2016-08-18 21:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 167
ERROR - 2016-08-18 21:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:08:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:08:41 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-18 21:11:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 167
ERROR - 2016-08-18 21:11:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:01 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-18 21:11:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 167
ERROR - 2016-08-18 21:11:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 168
ERROR - 2016-08-18 21:11:19 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-18 21:12:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 154
ERROR - 2016-08-18 21:12:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 155
ERROR - 2016-08-18 21:12:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 155
ERROR - 2016-08-18 21:12:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 155
ERROR - 2016-08-18 21:12:28 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-18 21:14:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 156
ERROR - 2016-08-18 21:14:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 157
ERROR - 2016-08-18 21:14:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 157
ERROR - 2016-08-18 21:14:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 157
ERROR - 2016-08-18 21:14:24 --> The cart array must contain a product ID, quantity, price, and name.
ERROR - 2016-08-18 21:17:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 155
ERROR - 2016-08-18 21:17:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 156
ERROR - 2016-08-18 21:17:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 156
ERROR - 2016-08-18 21:17:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 156
ERROR - 2016-08-18 21:17:57 --> The cart array must contain a product ID, quantity, price, and name.
