<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/2.jpg
ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/3.jpg
ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/6.jpg
ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/7.jpg
ERROR - 2017-04-03 05:34:46 --> 404 Page Not Found: web/Images/5.jpg
ERROR - 2017-04-03 05:35:57 --> 404 Page Not Found: web/Images/2.jpg
ERROR - 2017-04-03 05:35:57 --> 404 Page Not Found: web/Images/5.jpg
ERROR - 2017-04-03 05:35:58 --> 404 Page Not Found: web/Images/6.jpg
ERROR - 2017-04-03 05:35:58 --> 404 Page Not Found: web/Images/7.jpg
ERROR - 2017-04-03 05:35:58 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-04-03 05:35:58 --> 404 Page Not Found: web/Images/3.jpg
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:19 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:36 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:45 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:36:47 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:40:37 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:27 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:27 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:27 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:27 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:27 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:41:28 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:42:05 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-03 06:57:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-03 06:57:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 79
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 79
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 86
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 86
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 93
ERROR - 2017-04-03 07:25:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\users\create_dummy_guilder.php 93
ERROR - 2017-04-03 08:47:50 --> Query error: Unknown column 'perfectmoney' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`fullname`, `phonenumber`, `username`, `emailaddress`, `bitcoinaddress`, `perfectmoney`, `skrilldollar`, `datemodified`, `password`, `enabled`, `userid`, `earning`, `dummyguilder`, `isguilder`, `datecreated`) VALUES ('ola', '0292039303', 'olafashade', 'olafashade@hotmail.com', 'kdjdjfkfjfkgk', 'kdkdkfkfflkfk', 'jdkdkdfjflfkfl', '2017-04-03 08:47:50', '34f8ef49bb211291fcab6bb1d7b5bcb44ec87d40d942d15bbbb9ca96c182634cfe374f1cc03ad985bb3b99aa9b6dbee9a6a463794e2cee7daaccb0403a74d126', 1, '14912056707290oj', 0, 1, 1, '2017-04-03 8:47:50')
ERROR - 2017-04-03 09:20:14 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\views\management\users\dummy_guilder.php 80
ERROR - 2017-04-03 09:20:14 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\bitgiver\application\views\management\users\dummy_guilder.php 83
ERROR - 2017-04-03 09:21:42 --> Severity: Notice --> Undefined property: stdClass::$skrill C:\xampp\htdocs\bitgiver\application\views\management\users\dummy_guilder.php 86
ERROR - 2017-04-03 09:23:41 --> Severity: Error --> Call to undefined function object() C:\xampp\htdocs\bitgiver\application\controllers\management\Users.php 553
ERROR - 2017-04-03 09:46:10 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 57
ERROR - 2017-04-03 09:46:36 --> Severity: Notice --> Undefined variable: accounts C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 09:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 09:46:59 --> Severity: Notice --> Undefined variable: accounts C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 09:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 09:47:18 --> Severity: Notice --> Undefined variable: accounts C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 09:47:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\management\users\payguilders.php 52
ERROR - 2017-04-03 14:57:30 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-03 14:57:39 --> Query error: Unknown column 'tbl_gh.depositorsname' in 'field list' - Invalid query: SELECT `tbl_ph`.*, `tbl_gh`.`depositorsname`
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_gh`.`ghid`=`tbl_ph`.`ghid`
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 50
ERROR - 2017-04-03 14:57:39 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491227859
WHERE `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` DESC LIMIT 50
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 14:58:42 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\bitgiver\application\views\management\dashboard_page.php 127
ERROR - 2017-04-03 15:14:08 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-03 15:14:08 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491228848
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-03 15:14:17 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 203
ERROR - 2017-04-03 15:14:17 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 218
ERROR - 2017-04-03 15:14:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
ORDER BY `tbl_ph`.`id` ASC' at line 7 - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:14:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`' at line 5 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491228857
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:21:50 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 203
ERROR - 2017-04-03 15:21:50 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 218
ERROR - 2017-04-03 15:21:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
ORDER BY `tbl_ph`.`id` ASC' at line 7 - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:21:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`' at line 5 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491229310
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:21:58 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 203
ERROR - 2017-04-03 15:21:58 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 218
ERROR - 2017-04-03 15:21:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
ORDER BY `tbl_ph`.`id` ASC' at line 7 - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:21:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`' at line 5 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491229318
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:22:32 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 213
ERROR - 2017-04-03 15:22:32 --> Severity: Notice --> Undefined variable: waitingtime C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 228
ERROR - 2017-04-03 15:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
ORDER BY `tbl_ph`.`id` ASC' at line 7 - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`emailaddress`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`' at line 5 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491229352
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_ph`.`datecreated` < `IS` `NULL`
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` ASC
ERROR - 2017-04-03 15:30:12 --> Severity: Notice --> Undefined variable: existingusers C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 12
ERROR - 2017-04-03 15:30:12 --> Severity: Notice --> Undefined variable: existingusers C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 12
ERROR - 2017-04-03 15:34:05 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-03 15:34:05 --> Query error: Unknown column 'tbl_gh.tellernumber' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491230045
WHERE `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`phuser` IS NULL
AND `tbl_gh`.`paymentstatus` =0
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:37:03 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\bitgiver\application\views\management\orders\release.php 70
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:38:09 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 39
ERROR - 2017-04-03 15:59:59 --> Query error: Unknown column 'tbl_gh.depositorsname' in 'field list' - Invalid query: SELECT `tbl_ph`.*, `tbl_gh`.`depositorsname`
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_gh`.`ghid`=`tbl_ph`.`ghid`
WHERE tbl_ph.datecreated between '2017-04-03 00:00:01' AND '2017-04-03 23:59:59'
ORDER BY `tbl_ph`.`id` DESC
ERROR - 2017-04-03 15:59:59 --> Query error: Unknown column 'tbl_ph.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1491231599
WHERE tbl_ph.datecreated between '2017-04-03 00:00:01' AND '2017-04-03 23:59:59'
AND `id` = '838e5ba81c6f0204d2c5a1b4a07deb39cbe13bcd'
ORDER BY `tbl_ph`.`id` DESC
ERROR - 2017-04-03 16:03:58 --> 404 Page Not Found: management/Orders/pledges
ERROR - 2017-04-03 16:04:08 --> 404 Page Not Found: management/Orders/ghs
