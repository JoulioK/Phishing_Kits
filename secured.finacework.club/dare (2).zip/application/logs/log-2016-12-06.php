<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-06 14:44:12 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\snappycoin\application\controllers\web\Authenticate.php 99
ERROR - 2016-12-06 14:57:01 --> Severity: Error --> Call to undefined method CI_Input::session() C:\xampp\htdocs\snappycoin\application\controllers\web\Address.php 16
ERROR - 2016-12-06 15:32:18 --> Severity: Error --> Call to undefined function num_format() C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 60
ERROR - 2016-12-06 15:33:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 65
ERROR - 2016-12-06 15:34:12 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 65
ERROR - 2016-12-06 15:53:16 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 74
ERROR - 2016-12-06 15:55:48 --> 404 Page Not Found: web/Home/sendapplink
ERROR - 2016-12-06 16:21:47 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\snappycoin\application\views\web\_layouts\footer.php 56
ERROR - 2016-12-06 16:22:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\footer.php 56
ERROR - 2016-12-06 18:21:34 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_settings`
LEFT JOIN `tbl_banks` ON `tbl_settings`.`bankid`=`tbl_banks`.`bankid`
WHERE `id` = 1
ERROR - 2016-12-06 18:22:00 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_settings`
LEFT JOIN `tbl_banks` ON `tbl_settings`.`id`=`tbl_banks`.`bankid`
WHERE `id` = 1
ERROR - 2016-12-06 18:22:33 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_settings`
LEFT JOIN `tbl_banks` ON `tbl_settings`.`bankid`=`tbl_banks`.`bankid`
WHERE `id` = 1
ERROR - 2016-12-06 18:37:00 --> 404 Page Not Found: web/Term/index
