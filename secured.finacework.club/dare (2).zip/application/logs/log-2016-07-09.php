<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-09 00:00:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-09 01:07:07 --> 404 Page Not Found: management/Order/orders
ERROR - 2016-07-09 01:09:50 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 43
ERROR - 2016-07-09 01:09:50 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 44
ERROR - 2016-07-09 01:21:09 --> Severity: Notice --> Undefined property: Reports::$item_model C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-07-09 01:21:09 --> Severity: Notice --> Indirect modification of overloaded property Order_Model::$item_model has no effect C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 19
ERROR - 2016-07-09 01:21:09 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 19
ERROR - 2016-07-09 01:21:09 --> Severity: Notice --> Undefined property: Reports::$item_model C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-07-09 01:21:09 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 21
ERROR - 2016-07-09 01:21:31 --> Severity: Notice --> Undefined property: Reports::$item_model C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-07-09 01:21:31 --> Severity: Notice --> Indirect modification of overloaded property Order_Model::$item_model has no effect C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 19
ERROR - 2016-07-09 01:21:31 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 19
ERROR - 2016-07-09 01:21:31 --> Severity: Notice --> Undefined property: Reports::$item_model C:\xampp\htdocs\fastfood\system\core\Model.php 77
ERROR - 2016-07-09 01:21:31 --> Severity: Error --> Call to a member function get_by() on a non-object C:\xampp\htdocs\fastfood\application\models\vendor\order_model.php 21
ERROR - 2016-07-09 01:22:57 --> Query error: Unknown column 'unitid' in 'field list' - Invalid query: SELECT `itemid`, `unitid`
FROM `tbl_item_price`
WHERE `priceid` = '14669263110889yk'
ERROR - 2016-07-09 01:35:02 --> Severity: Notice --> Undefined variable: statustype C:\xampp\htdocs\fastfood\application\views\management\reports\orders.php 19
ERROR - 2016-07-09 01:35:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\reports\orders.php 19
ERROR - 2016-07-09 02:26:10 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 63
ERROR - 2016-07-09 02:26:50 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 63
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 02:36:38 --> Severity: Warning --> Cannot use a scalar value as an array C:\xampp\htdocs\fastfood\application\views\management\reports\orders_summary.php 86
ERROR - 2016-07-09 15:36:06 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-09 15:36:16 --> 404 Page Not Found: management/Orders/index
ERROR - 2016-07-09 16:08:09 --> Severity: Compile Error --> Cannot redeclare Reports::Income_Summary() C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 211
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 135
ERROR - 2016-07-09 16:08:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fastfood\system\core\Exceptions.php:272) C:\xampp\htdocs\fastfood\system\core\Common.php 569
ERROR - 2016-07-09 21:00:48 --> 404 Page Not Found: management/Js/classie.js
