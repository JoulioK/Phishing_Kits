<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-03 08:29:56 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-03 08:32:08 --> Severity: Compile Error --> Cannot redeclare Orders::users() C:\xampp\htdocs\charity\application\controllers\management\Orders.php 429
ERROR - 2017-02-03 08:32:56 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\charity\application\views\management\orders\user.php 65
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:41 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:43 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:45 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
ERROR - 2017-02-03 08:33:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\user.php 48
