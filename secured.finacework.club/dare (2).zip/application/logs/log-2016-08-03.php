<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-03 09:22:18 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-08-03 09:22:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:31 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-08-03 09:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:22:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:23:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:23:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:23:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:23:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:23:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:27:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 31
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 09:36:58 --> Severity: Notice --> Undefined property: stdClass::$date C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 42
ERROR - 2016-08-03 19:06:55 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 94
ERROR - 2016-08-03 19:25:34 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 94
ERROR - 2016-08-03 19:25:41 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 94
ERROR - 2016-08-03 19:26:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:26:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:26:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 86
ERROR - 2016-08-03 19:26:59 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 89
ERROR - 2016-08-03 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:28:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 86
ERROR - 2016-08-03 19:28:16 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 89
ERROR - 2016-08-03 19:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 86
ERROR - 2016-08-03 19:28:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 89
ERROR - 2016-08-03 19:28:29 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:28:29 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:28:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:28:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:28:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 86
ERROR - 2016-08-03 19:28:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 89
ERROR - 2016-08-03 19:33:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 84
ERROR - 2016-08-03 19:33:36 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:33:37 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:33:43 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:33:43 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:33:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 18
ERROR - 2016-08-03 19:33:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 19
ERROR - 2016-08-03 19:33:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 84
ERROR - 2016-08-03 19:35:10 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:35:10 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:36:57 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:36:57 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:37:38 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:37:38 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:37:45 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:37:45 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 45
ERROR - 2016-08-03 19:38:32 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:38:32 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:38:54 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:38:54 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:39:50 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 19:39:51 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:17:39 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:17:39 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:18:27 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:18:27 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:21:16 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:21:16 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:24:01 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:24:01 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 43
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 67
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 67
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 67
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 67
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:24:50 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 67
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:26:55 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:29:12 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:29:12 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:29:12 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:29:12 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:29:12 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:29:13 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:29:13 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:29:13 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:29:13 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 65
ERROR - 2016-08-03 22:29:13 --> Severity: Notice --> Undefined index: 14669259683913 C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 66
ERROR - 2016-08-03 22:39:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 84
ERROR - 2016-08-03 22:39:52 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\orders.php 85
ERROR - 2016-08-03 23:37:33 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:40:37 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:40:49 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:42:14 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:43:07 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:55:30 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 64
ERROR - 2016-08-03 23:55:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 64
ERROR - 2016-08-03 23:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 15
ERROR - 2016-08-03 23:55:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 16
ERROR - 2016-08-03 23:55:53 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
ERROR - 2016-08-03 23:55:58 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 22
