<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-11 00:00:29 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 00:01:26 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 00:03:14 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 00:03:50 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 00:04:19 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 00:06:02 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 00:06:24 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 00:07:38 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 08:28:40 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 08:44:05 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 08:53:37 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 08:55:45 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 09:08:35 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-11 11:40:47 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:47 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:47 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:49 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:50 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:51 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:51 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:53 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:40:59 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:41:00 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:41:29 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:41:29 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\Vendors.php 95
ERROR - 2016-09-11 11:48:54 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-09-11 11:50:58 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 11:52:41 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-11 12:27:05 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 142
ERROR - 2016-09-11 12:27:05 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 142
ERROR - 2016-09-11 12:27:29 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 142
ERROR - 2016-09-11 12:27:29 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 142
ERROR - 2016-09-11 12:27:36 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 142
ERROR - 2016-09-11 12:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 134
ERROR - 2016-09-11 12:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 136
ERROR - 2016-09-11 12:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 45
ERROR - 2016-09-11 17:55:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 174
ERROR - 2016-09-11 17:55:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 174
ERROR - 2016-09-11 17:56:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 84
ERROR - 2016-09-11 17:56:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 53
ERROR - 2016-09-11 17:56:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 209
ERROR - 2016-09-11 17:56:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 210
ERROR - 2016-09-11 17:56:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 84
ERROR - 2016-09-11 17:56:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 53
ERROR - 2016-09-11 18:00:18 --> Query error: Unknown column 'tbl_item.itemid' in 'where clause' - Invalid query: SELECT `vendorid`
FROM `tbl_items`
WHERE `tbl_item`.`itemid` = '14711845704888ov'
ERROR - 2016-09-11 18:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 134
ERROR - 2016-09-11 18:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 136
ERROR - 2016-09-11 18:00:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 45
ERROR - 2016-09-11 18:25:42 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:34:04 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:34:14 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:34:45 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:35:21 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:35:28 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:36:45 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:37:13 --> Severity: Notice --> Undefined property: stdClass::$addressid C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 357
ERROR - 2016-09-11 18:56:06 --> Severity: Notice --> Undefined property: stdClass::$phone C:\xampp\htdocs\fastfood\application\controllers\app\Settings.php 235
ERROR - 2016-09-11 19:56:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'snappyme_olafash'@'localhost' (using password: YES) C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-09-11 19:56:22 --> Unable to connect to the database
