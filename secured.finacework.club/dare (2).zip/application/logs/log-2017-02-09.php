<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-09 05:31:35 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:31:42 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:31:54 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:32:01 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:32:08 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:32:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:32:50 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:39:21 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 05:39:34 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:13:14 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:13:31 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:13:46 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:14:41 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:10 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:15 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:15 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:19 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:22 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:22 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:25 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:25 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:29 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:29 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:32 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:32 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:35 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:35 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:37 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:38 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:40 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:40 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:42 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:43 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:45 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:47 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:47 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:49 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:50 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:52 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:53 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:15:57 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:15:58 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:01 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:01 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:05 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:05 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:08 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:08 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:10 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:13 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:13 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:16 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:16 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:19 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:16:22 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 43
ERROR - 2017-02-09 06:16:22 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 49
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 56
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$to C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 56
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\charity\application\views\web\customer\ph.php 150
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$to C:\xampp\htdocs\charity\application\views\web\customer\ph.php 150
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\charity\application\views\web\customer\ph.php 163
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\charity\application\views\web\customer\ph.php 170
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined property: stdClass::$to C:\xampp\htdocs\charity\application\views\web\customer\ph.php 170
ERROR - 2017-02-09 06:18:20 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:19:32 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:19:35 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:23:51 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:23:54 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:23:56 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:23:59 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:01 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:05 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:08 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:14 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:24:16 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:23 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:25 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:28 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:31 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:33 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:36 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:39 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:42 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:47 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:50 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:53 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:56 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:25:58 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:26:03 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:26:05 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:47:21 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:48:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 06:50:31 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 10:46:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'helpcabal' C:\xampp\htdocs\charity\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2017-02-09 10:46:53 --> Unable to connect to the database
ERROR - 2017-02-09 10:51:24 --> Query error: Table 'helpcabal.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '9ab7072d4049d67d903c0cbbf20dd17be28135f4'
ERROR - 2017-02-09 10:52:32 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 10:52:52 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 10:53:07 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 10:53:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:45:31 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:45:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-09 11:48:13 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:15 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:26 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:28 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:31 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:33 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:36 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:38 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:40 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:42 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:43 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:48 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:49 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:51 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:53 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:54 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:56 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:48:58 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:49:00 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:49:03 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-09 11:49:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
