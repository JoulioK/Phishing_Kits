<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-20 00:20:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 00:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 00:20:47 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 00:20:47 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 00:20:48 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:42 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 00:44:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 00:44:42 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 00:44:42 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 00:44:43 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 00:44:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:13:13 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:13:14 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:13:38 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:13:38 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:13:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:16 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:14:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:14:16 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:14:16 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:14:17 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:14:47 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:14:47 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:14:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:15:15 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:15:15 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:15:43 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:15:43 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:15:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:51:24 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:51:24 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:51:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:52:06 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:52:06 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:55:04 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:55:04 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:00 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:01 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:12 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:12 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:46 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:56:46 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:56:46 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:56:47 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:56:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:57:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:57:00 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:57:00 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:57:01 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:57:31 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:57:31 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:57:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:58:39 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 01:58:39 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 179
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 182
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 01:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 02:04:49 --> Severity: Notice --> Undefined property: Cabal::$post C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 28
ERROR - 2017-01-20 02:04:54 --> Severity: Error --> Call to a member function opened() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 28
ERROR - 2017-01-20 02:04:57 --> Severity: Notice --> Undefined property: Cabal::$post C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 28
ERROR - 2017-01-20 02:04:57 --> Severity: Error --> Call to a member function opened() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 28
ERROR - 2017-01-20 02:46:33 --> 404 Page Not Found: web/Support/faqs
ERROR - 2017-01-20 07:52:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 07:52:32 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 07:52:32 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:52:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 07:53:42 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-20 07:53:42 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-20 07:53:42 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-20 07:53:43 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-20 11:32:04 --> Severity: Parsing Error --> syntax error, unexpected 'his' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cron.php 14
ERROR - 2017-01-20 11:32:28 --> Severity: Compile Error --> Cannot redeclare Cron::reset_pastph() C:\xampp\htdocs\charity\application\controllers\web\Cron.php 18
ERROR - 2017-01-20 11:41:23 --> Severity: Parsing Error --> syntax error, unexpected 'his' (T_STRING) C:\xampp\htdocs\charity\application\controllers\web\Cron.php 24
ERROR - 2017-01-20 11:42:03 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\controllers\web\Cron.php 69
ERROR - 2017-01-20 11:47:23 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 11:47:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 11:47:23 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 11:47:23 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-20 11:47:24 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:47:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-20 11:51:03 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\models\web\Customer_model.php on line 97 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 11:51:03 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 11:51:03 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 11:51:03 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (2017-01-20 2017-01-20 11:51:00) at position 11 (2): Double date specification C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 32
ERROR - 2017-01-20 12:12:18 --> Severity: Warning --> Missing argument 2 for timeaway(), called in C:\xampp\htdocs\charity\application\controllers\web\Cabal.php on line 193 and defined C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 184
ERROR - 2017-01-20 12:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 187
ERROR - 2017-01-20 12:12:18 --> Severity: Notice --> Undefined variable: gmt C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 189
ERROR - 2017-01-20 12:12:18 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (2017-01-20 2017-01-20 11:51:00) at position 11 (2): Double date specification C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 32
