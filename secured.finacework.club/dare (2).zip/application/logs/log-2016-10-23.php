<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-23 04:43:31 --> 404 Page Not Found: web/About/index
ERROR - 2016-10-23 07:18:43 --> Query error: Unknown column 'bedroom' in 'where clause' - Invalid query: SELECT *
FROM `tbl_items`
WHERE `categoryid` = '14675351092681zg'
AND `bedroom` = '3'
AND `bathroom` = '3'
ORDER BY `tbl_items`.`datecreated` DESC
ERROR - 2016-10-23 07:18:43 --> Query error: Unknown column 'categoryid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477203523
WHERE `categoryid` = '14675351092681zg'
AND `bedroom` = '3'
AND `bathroom` = '3'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `tbl_items`.`datecreated` DESC
ERROR - 2016-10-23 07:27:50 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\corperslodge\application\controllers\web\Home.php 58
ERROR - 2016-10-23 14:06:39 --> 404 Page Not Found: web/Home/fetch
ERROR - 2016-10-23 14:08:19 --> 404 Page Not Found: web/Aparments/index
ERROR - 2016-10-23 14:14:58 --> 404 Page Not Found: web/Aparments/index
ERROR - 2016-10-23 14:19:20 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 17
ERROR - 2016-10-23 14:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 17
ERROR - 2016-10-23 14:19:21 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 30
ERROR - 2016-10-23 14:19:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 30
ERROR - 2016-10-23 14:22:08 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 17
ERROR - 2016-10-23 14:22:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 17
ERROR - 2016-10-23 14:22:08 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 30
ERROR - 2016-10-23 14:22:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\views\web\_layouts\banner.php 30
ERROR - 2016-10-23 14:51:15 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 5
ERROR - 2016-10-23 14:57:57 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 14
ERROR - 2016-10-23 15:09:05 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 31
ERROR - 2016-10-23 15:09:05 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 15:09:05 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 38
ERROR - 2016-10-23 15:10:01 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:16:10 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:50:13 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:50:46 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:53:11 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:54:44 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 17:56:30 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:30:43 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-10-23 19:31:10 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-10-23 19:42:39 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:42:48 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:43:40 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:44:39 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:44:59 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:45:14 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:45:49 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 37
ERROR - 2016-10-23 19:47:02 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 19:48:20 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 19:48:33 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 19:56:58 --> Severity: Warning --> Missing argument 1 for Apartment::index() C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 13
ERROR - 2016-10-23 19:56:58 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 18
ERROR - 2016-10-23 19:56:58 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 22
ERROR - 2016-10-23 19:56:58 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 25
ERROR - 2016-10-23 19:56:58 --> Query error: Table 'corperslodge.tbl_item_images' doesn't exist - Invalid query: SELECT *
FROM `tbl_item_images`
WHERE `itemid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-10-23 19:56:58 --> Query error: Unknown column 'itemid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249018
WHERE `itemid` IS NULL
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 19:58:01 --> Severity: Warning --> Missing argument 1 for Apartment::index() C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 13
ERROR - 2016-10-23 19:58:01 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 18
ERROR - 2016-10-23 19:58:01 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 22
ERROR - 2016-10-23 19:58:01 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 25
ERROR - 2016-10-23 19:58:01 --> Query error: Table 'corperslodge.tbl_item_images' doesn't exist - Invalid query: SELECT *
FROM `tbl_item_images`
WHERE `itemid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-10-23 19:58:01 --> Query error: Unknown column 'itemid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249081
WHERE `itemid` IS NULL
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 19:58:15 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 19:58:19 --> Query error: Table 'corperslodge.tbl_item_images' doesn't exist - Invalid query: SELECT *
FROM `tbl_item_images`
WHERE `itemid` = '14713263332310wq'
ORDER BY `id` ASC
ERROR - 2016-10-23 19:58:20 --> Query error: Unknown column 'itemid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249100
WHERE `itemid` = '14713263332310wq'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:03:53 --> Query error: Table 'corperslodge.tbl_item_images' doesn't exist - Invalid query: SELECT *
FROM `tbl_item_images`
WHERE `itemid` = '14713263332310wq'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:03:53 --> Query error: Unknown column 'itemid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249433
WHERE `itemid` = '14713263332310wq'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:04:15 --> Severity: Notice --> Undefined index: topcategories C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 27
ERROR - 2016-10-23 20:04:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 27
ERROR - 2016-10-23 20:04:15 --> Severity: Notice --> Undefined variable: catnames C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:04:15 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:04:15 --> Query error: Table 'corperslodge.tbl_vendors' doesn't exist - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` = '14711890669843ss'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:04:15 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249455
WHERE `vendorid` = '14711890669843ss'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:06:25 --> Severity: Notice --> Undefined index: topcategories C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 27
ERROR - 2016-10-23 20:06:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 27
ERROR - 2016-10-23 20:06:25 --> Severity: Notice --> Undefined variable: catnames C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:06:25 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:06:25 --> Query error: Table 'corperslodge.tbl_vendors' doesn't exist - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` = '14711890669843ss'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:06:25 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249585
WHERE `vendorid` = '14711890669843ss'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:07:06 --> Query error: Table 'corperslodge.tbl_vendors' doesn't exist - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` = '14711890669843ss'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:07:06 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1477249626
WHERE `vendorid` = '14711890669843ss'
AND `id` = '74501a92bed57021a9025a70c7d25539b3c07705'
ORDER BY `id` ASC
ERROR - 2016-10-23 20:18:17 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 24
ERROR - 2016-10-23 20:20:03 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 24
ERROR - 2016-10-23 20:41:42 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 20:42:55 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\corperslodge\application\views\web\pages\apartments.php 39
ERROR - 2016-10-23 20:43:52 --> Severity: Error --> Call to undefined function num_format() C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 26
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 32
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 34
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 6
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 10
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 10
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 17
ERROR - 2016-10-23 20:51:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 20
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 32
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 33
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\controllers\web\Apartment.php 34
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 6
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 10
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 10
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 17
ERROR - 2016-10-23 20:52:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\corperslodge\application\views\web\pages\item.php 20
