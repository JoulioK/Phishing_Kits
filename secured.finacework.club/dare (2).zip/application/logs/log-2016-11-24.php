<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-24 07:45:16 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:45:17 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:45:17 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:45:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:46:19 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:46:19 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:46:19 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:46:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:13 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:13 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:13 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:30 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:30 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:30 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 07:47:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-24 09:44:13 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 109
ERROR - 2016-11-24 09:44:13 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 110
ERROR - 2016-11-24 09:44:13 --> Severity: Notice --> Undefined property: stdClass::$bankid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 111
ERROR - 2016-11-24 09:44:13 --> Query error: Unknown column 'bankids' in 'field list' - Invalid query: UPDATE `tbl_users` SET `emailaddress` = 'olafashade@hotmail.com', `phonenumber` = '080687529478', `lastname` = 'Gcfr', `firstname` = 'Ola', `accountname` = NULL, `accountnumber` = NULL, `bankids` = NULL, `password` = '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', `verificationcode` = '', `datemodified` = '2016-11-24 9:44:13'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 103
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 105
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 106
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 107
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 108
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 109
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 110
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 111
ERROR - 2016-11-24 09:44:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 112
ERROR - 2016-11-24 09:44:22 --> Query error: Unknown column 'bankids' in 'field list' - Invalid query: UPDATE `tbl_users` SET `emailaddress` = NULL, `phonenumber` = NULL, `lastname` = NULL, `firstname` = NULL, `accountname` = NULL, `accountnumber` = NULL, `bankids` = NULL, `password` = '008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444', `verificationcode` = '', `datemodified` = '2016-11-24 9:44:22'
WHERE `userid` IS NULL
ERROR - 2016-11-24 09:44:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\snappycoin\system\core\Exceptions.php:272) C:\xampp\htdocs\snappycoin\system\core\Common.php 569
ERROR - 2016-11-24 09:46:16 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 109
ERROR - 2016-11-24 09:46:16 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 110
ERROR - 2016-11-24 09:46:16 --> Severity: Notice --> Undefined property: stdClass::$bankid C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 111
ERROR - 2016-11-24 20:31:10 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 105
ERROR - 2016-11-24 20:33:20 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 105
ERROR - 2016-11-24 20:33:43 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 105
ERROR - 2016-11-24 20:34:59 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 105
ERROR - 2016-11-24 21:38:01 --> 404 Page Not Found: app/Item/shippingaddress
ERROR - 2016-11-24 22:43:03 --> 404 Page Not Found: app/Item/checkout
ERROR - 2016-11-24 22:45:48 --> 404 Page Not Found: app/Item/checkout
