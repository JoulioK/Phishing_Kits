<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-31 04:30:21 --> Query error: Table 'helpcabal.tbl_testimonials' doesn't exist - Invalid query: SELECT *
FROM `tbl_testimonials`
ERROR - 2017-01-31 04:35:10 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\charity\application\views\web\pages\testimonial.php 10
ERROR - 2017-01-31 04:35:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\pages\testimonial.php 10
ERROR - 2017-01-31 04:52:19 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\charity\application\views\web\pages\testimonial.php 35
ERROR - 2017-01-31 04:52:19 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\charity\application\views\web\pages\testimonial.php 35
ERROR - 2017-01-31 05:24:12 --> 404 Page Not Found: web/Testimonial/index
ERROR - 2017-01-31 05:24:42 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-31 05:29:04 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\charity\application\controllers\web\Home.php 14
ERROR - 2017-01-31 05:33:32 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\charity\application\views\web\pages\home.php 158
ERROR - 2017-01-31 05:33:52 --> Severity: Notice --> Undefined variable: testimonials C:\xampp\htdocs\charity\application\views\web\pages\home.php 147
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:35:01 --> Severity: Notice --> Undefined property: stdClass::$text C:\xampp\htdocs\charity\application\views\web\pages\home.php 154
ERROR - 2017-01-31 05:38:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-31 06:06:29 --> Query error: Table 'helpcabal.tbl_notice' doesn't exist - Invalid query: SELECT *
FROM `tbl_notice`
ERROR - 2017-01-31 06:39:08 --> 404 Page Not Found: web/Notice/index
ERROR - 2017-01-31 06:39:23 --> Query error: Unknown column 'tbl_news' in 'field list' - Invalid query: SELECT `tbl_news`
FROM `tbl_testimonial`
ORDER BY `id` DESC
 LIMIT 3
ERROR - 2017-01-31 06:45:05 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 111
ERROR - 2017-01-31 15:59:08 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-31 16:12:30 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:12:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:27 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:32 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:36 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:40 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:40 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:53 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:59 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:14:05 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:14:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:14:10 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:14:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 47
ERROR - 2017-01-31 16:29:52 --> 404 Page Not Found: management/Js/classie.js
