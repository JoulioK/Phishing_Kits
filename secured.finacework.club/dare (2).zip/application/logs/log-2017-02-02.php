<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-02 09:29:23 --> 404 Page Not Found: management/Js/classie.js
