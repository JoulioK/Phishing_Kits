<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-13 11:55:44 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 17
ERROR - 2016-11-13 18:59:03 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ';' C:\xampp\htdocs\caroossa\application\views\web\_layouts\banner.php 182
ERROR - 2016-11-13 18:59:40 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ';' C:\xampp\htdocs\caroossa\application\views\web\_layouts\banner.php 182
ERROR - 2016-11-13 19:05:45 --> Severity: Parsing Error --> syntax error, unexpected '$i' (T_VARIABLE), expecting ';' C:\xampp\htdocs\caroossa\application\views\web\_layouts\banner.php 182
ERROR - 2016-11-13 19:22:06 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 20
ERROR - 2016-11-13 19:38:06 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:38:07 --> Severity: Error --> Call to a member function getvendorname() on a non-object C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:38:27 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:38:27 --> Severity: Error --> Call to a member function getvendorname() on a non-object C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:39:07 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:39:07 --> Severity: Error --> Call to a member function getvendorname() on a non-object C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 29
ERROR - 2016-11-13 19:46:32 --> Severity: Error --> Call to undefined method Item_model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 30
ERROR - 2016-11-13 19:48:41 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 30
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:07:58 --> Severity: Notice --> Undefined property: stdClass::$locationame C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 52
ERROR - 2016-11-13 20:22:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'distinct(tbl_item_location.locationid)
FROM `tbl_items`
LEFT JOIN `tbl_item_loca' at line 1 - Invalid query: SELECT `tbl_items`.*, distinct(tbl_item_location.locationid)
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
ORDER BY `tbl_items`.`datecreated` ASC
 LIMIT 6
ERROR - 2016-11-13 20:22:46 --> Query error: Unknown column 'tbl_items.datecreated' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479064966
WHERE `id` = '1c2c76ae2490f4d5388a578120e7264e5a66b000'
ORDER BY `tbl_items`.`datecreated` ASC LIMIT 6
ERROR - 2016-11-13 20:24:47 --> Severity: Parsing Error --> syntax error, unexpected ':' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 21
ERROR - 2016-11-13 20:26:00 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-11-13 20:31:18 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 24
ERROR - 2016-11-13 20:31:31 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 25
ERROR - 2016-11-13 20:31:47 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 55
ERROR - 2016-11-13 20:32:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 15
ERROR - 2016-11-13 20:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 15
ERROR - 2016-11-13 20:32:11 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 72
ERROR - 2016-11-13 20:32:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 72
ERROR - 2016-11-13 20:48:45 --> 404 Page Not Found: web/Ride/index
ERROR - 2016-11-13 20:51:29 --> 404 Page Not Found: web/Ride/index
ERROR - 2016-11-13 21:07:09 --> Severity: Notice --> Undefined property: CI_Loader::$items_model C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:09 --> Severity: Error --> Call to a member function getitemunit() on a non-object C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:31 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:48 --> Severity: Notice --> Undefined variable: unit C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:48 --> Severity: Notice --> Undefined variable: unit C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
ERROR - 2016-11-13 21:07:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\pages\item.php 53
