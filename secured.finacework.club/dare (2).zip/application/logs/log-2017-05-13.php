<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-13 10:35:14 --> 404 Page Not Found: web/Images/sttTop-img1.png
ERROR - 2017-05-13 10:35:14 --> 404 Page Not Found: web/Images/sttTop-img3.png
ERROR - 2017-05-13 10:35:37 --> 404 Page Not Found: web/Images/sttTop-img1.png
ERROR - 2017-05-13 10:35:37 --> 404 Page Not Found: web/Images/sttTop-img3.png
ERROR - 2017-05-13 10:36:46 --> 404 Page Not Found: web/Images/sttTop-img1.png
ERROR - 2017-05-13 10:36:46 --> 404 Page Not Found: web/Images/sttTop-img3.png
