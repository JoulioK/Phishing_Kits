<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-06 12:13:20 --> 404 Page Not Found: Faviconico/index
