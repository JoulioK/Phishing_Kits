<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-02 15:47:27 --> Severity: Compile Error --> Cannot redeclare Orders::updatestatus() C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 353
ERROR - 2016-10-02 15:47:47 --> Severity: Compile Error --> Cannot redeclare Orders::updatestatus() C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 353
ERROR - 2016-10-02 15:47:58 --> Severity: Compile Error --> Cannot redeclare Orders::updatestatus() C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 353
ERROR - 2016-10-02 15:47:59 --> 404 Page Not Found: 
ERROR - 2016-10-02 19:21:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:21:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:21:56 --> Unable to connect to the database
ERROR - 2016-10-02 19:21:56 --> Unable to connect to the database
ERROR - 2016-10-02 19:21:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:21:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:21:58 --> Unable to connect to the database
ERROR - 2016-10-02 19:21:58 --> Unable to connect to the database
ERROR - 2016-10-02 19:21:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:21:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:00 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:00 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:01 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:01 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:04 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:04 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:06 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:06 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:08 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:08 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:10 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:10 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:12 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:13 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:13 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:13 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:17 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:17 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:17 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:17 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:20 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:20 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:22 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:22 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:24 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:24 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:27 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:27 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:28 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:28 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:30 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:30 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:32 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:32 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:33 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:33 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:36 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:36 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:37 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:37 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:39 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:39 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:42 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:42 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:43 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:44 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:45 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:46 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:47 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:48 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:49 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:50 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:51 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:51 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:51 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:54 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:54 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:55 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:55 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:57 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:57 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:22:59 --> Unable to connect to the database
ERROR - 2016-10-02 19:22:59 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:01 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:02 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:03 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:03 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:05 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:05 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:07 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:07 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:09 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:10 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:11 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:12 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:23:13 --> Unable to connect to the database
ERROR - 2016-10-02 19:23:13 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:54 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:54 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:56 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:56 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-10-02 19:35:58 --> Unable to connect to the database
ERROR - 2016-10-02 19:35:58 --> Unable to connect to the database
ERROR - 2016-10-02 22:55:42 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 398
ERROR - 2016-10-02 23:57:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:57:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:13 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:13 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:13 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:15 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:15 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:15 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:17 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:17 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:17 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:19 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:19 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:19 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:21 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:21 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:21 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:23 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:23 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:23 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:25 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:25 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:25 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:27 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:27 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:27 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:29 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:29 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:29 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:33 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:39 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:41 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:43 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:45 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:47 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:49 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:53 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:55 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:57 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:58:59 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:01 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:03 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:05 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:09 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:11 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:20 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:20 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:21 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:22 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:22 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:23 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:24 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:24 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:25 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:30 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:30 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:30 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:32 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:34 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:34 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:34 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:36 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:36 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:36 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:38 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:40 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:40 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:40 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:44 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:44 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:44 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:46 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:46 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:46 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:48 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:48 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:48 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:50 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:50 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:50 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:52 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:54 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:56 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
ERROR - 2016-10-02 23:59:58 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Dashboard.php 170
