<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-16 01:45:45 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-10-16 01:45:46 --> 404 Page Not Found: 
ERROR - 2016-10-16 01:46:12 --> Severity: Notice --> Undefined property: stdClass::$vendorcommision C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 104
ERROR - 2016-10-16 03:01:03 --> Severity: Notice --> Undefined property: stdClass::$vendorcommision C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income.php 135
ERROR - 2016-10-16 03:01:03 --> Severity: Notice --> Undefined property: stdClass::$vendorcommision C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income.php 135
ERROR - 2016-10-16 03:02:13 --> Severity: Notice --> Undefined property: stdClass::$vendorcommision C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income.php 135
ERROR - 2016-10-16 03:02:13 --> Severity: Notice --> Undefined property: stdClass::$vendorcommision C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income.php 135
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Undefined variable: ven C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 03:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\reports\income_summary.php 79
ERROR - 2016-10-16 04:02:11 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 19
ERROR - 2016-10-16 04:02:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 19
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined variable: vendors C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 79
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 117
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 117
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 117
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 117
ERROR - 2016-10-16 04:22:47 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 117
ERROR - 2016-10-16 04:35:25 --> 404 Page Not Found: 
ERROR - 2016-10-16 04:35:29 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-10-16 04:39:54 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\vendor\reports\income.php 116
ERROR - 2016-10-16 04:39:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\reports\income.php 116
ERROR - 2016-10-16 04:49:02 --> Severity: Error --> Call to undefined method Reports::get_by() C:\xampp\htdocs\fastfood\application\controllers\vendor\Reports.php 214
ERROR - 2016-10-16 04:49:24 --> Severity: Notice --> Undefined variable: vendorid C:\xampp\htdocs\fastfood\application\controllers\vendor\Reports.php 214
ERROR - 2016-10-16 04:49:24 --> Query error: Unknown column 'vendorname' in 'field list' - Invalid query: SELECT `vendorname`, `vendorcommision`
FROM `tbl_orders`
WHERE `vendorid` IS NULL
ERROR - 2016-10-16 04:49:25 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1476589765
WHERE `vendorid` IS NULL
AND `id` = '458de92e49ae49b177135341142c5a4031f8ab46'
ERROR - 2016-10-16 04:49:38 --> Query error: Unknown column 'vendorname' in 'field list' - Invalid query: SELECT `vendorname`, `vendorcommision`
FROM `tbl_orders`
WHERE `vendorid` = '14711890669843ss'
ERROR - 2016-10-16 04:49:38 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1476589778
WHERE `vendorid` = '14711890669843ss'
AND `id` = '458de92e49ae49b177135341142c5a4031f8ab46'
