<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-30 20:21:05 --> 404 Page Not Found: 
