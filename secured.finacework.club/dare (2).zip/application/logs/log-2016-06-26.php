<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-26 04:35:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-26 04:43:49 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 133
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:43:49 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 133
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:44:25 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 56
ERROR - 2016-06-26 04:49:20 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 133
ERROR - 2016-06-26 04:50:25 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 133
ERROR - 2016-06-26 04:52:44 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 05:01:29 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 126
ERROR - 2016-06-26 05:01:29 --> Severity: Error --> Call to undefined method stdClass::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:02:43 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 126
ERROR - 2016-06-26 05:02:43 --> Severity: Error --> Call to undefined method stdClass::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:02:44 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 126
ERROR - 2016-06-26 05:02:44 --> Severity: Error --> Call to undefined method stdClass::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:03:34 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:05:42 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:05:44 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 129
ERROR - 2016-06-26 05:08:40 --> Severity: Notice --> Undefined property: stdClass::$locationname C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 115
ERROR - 2016-06-26 05:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 115
ERROR - 2016-06-26 05:11:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 116
ERROR - 2016-06-26 05:18:36 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 05:18:55 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2016-06-26 05:19:23 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2016-06-26 05:19:24 --> Query error: No tables used - Invalid query: SELECT *
ERROR - 2016-06-26 05:20:00 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 115
ERROR - 2016-06-26 05:20:00 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 116
ERROR - 2016-06-26 06:03:12 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 06:03:12 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 06:04:47 --> Query error: Unknown column 'imageid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`imageid`, `itemid`, `imageurl`) VALUES ('14669138873743tt', '14669138729095xq', 'http://localhost/fastfood/resources/general/images/itemimages/01bfff9e1b03dd7003ba826cb377cdab.jpg')
ERROR - 2016-06-26 06:04:56 --> Query error: Unknown column 'imageid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`imageid`, `itemid`, `imageurl`) VALUES ('14669138969953sw', '14669138729095xq', 'http://localhost/fastfood/resources/general/images/itemimages/74bb8808df29fd527d1be627af810941.jpg')
ERROR - 2016-06-26 06:05:11 --> Query error: Unknown column 'imageid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`imageid`, `itemid`, `imageurl`) VALUES ('14669139110617ss', '14669138729095xq', 'http://localhost/fastfood/resources/general/images/itemimages/183c47175789c1b76989313ce7e928d8.jpg')
ERROR - 2016-06-26 08:55:26 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 08:55:27 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 08:56:26 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 08:56:47 --> Query error: Unknown column 'imageid' in 'field list' - Invalid query: INSERT INTO `tbl_items` (`imageid`, `itemid`, `imageurl`) VALUES ('14669242079323yv', '14669241981960ju', 'http://localhost/fastfood/resources/general/images/itemimages/1fa31685b1d30b5175f6c3d725febdfe.jpg')
ERROR - 2016-06-26 09:00:19 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 09:00:19 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 09:00:33 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\vendor\item_unit.php 63
ERROR - 2016-06-26 09:02:27 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\vendor\item_unit.php 63
ERROR - 2016-06-26 09:03:25 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 09:05:15 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-06-26 09:33:45 --> Query error: Table 'fastfood.t_items' doesn't exist - Invalid query: SELECT `t_items`.*, `t_item_category`.`categoryname`
FROM `t_items`
INNER JOIN `t_item_category` ON `t_item_category`.`categoryid` = `t_items`.`categoryid`
ERROR - 2016-06-26 09:48:58 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 161
ERROR - 2016-06-26 09:48:58 --> Severity: Error --> Call to undefined method stdClass::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 162
ERROR - 2016-06-26 09:50:09 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 161
ERROR - 2016-06-26 09:51:13 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 36
ERROR - 2016-06-26 09:51:13 --> Severity: Error --> Call to a member function getcatname() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 36
ERROR - 2016-06-26 09:52:51 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 34
ERROR - 2016-06-26 09:52:51 --> Severity: Error --> Call to a member function getcatname() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 34
ERROR - 2016-06-26 09:52:52 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 34
ERROR - 2016-06-26 09:52:52 --> Severity: Error --> Call to a member function getcatname() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 34
ERROR - 2016-06-26 09:53:41 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\models\vendor\items_model.php 32
ERROR - 2016-06-26 09:53:52 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\models\vendor\items_model.php 36
ERROR - 2016-06-26 09:53:52 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 09:53:52 --> Severity: Error --> Call to a member function getitemunit() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 09:54:52 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 09:54:52 --> Severity: Error --> Call to a member function getitemunit() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 09:55:58 --> Severity: Error --> Call to undefined method Items_Model::getitemunit() C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 09:59:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 44
ERROR - 2016-06-26 10:02:53 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 50
ERROR - 2016-06-26 10:02:53 --> Severity: Error --> Call to a member function getlocationname() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 50
ERROR - 2016-06-26 10:04:21 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 125
ERROR - 2016-06-26 10:19:46 --> Severity: Error --> Call to undefined method Items_Model::get_where() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 125
ERROR - 2016-06-26 10:20:13 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-26 10:20:13 --> Severity: Error --> Call to a member function getitemprice() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 127
ERROR - 2016-06-26 10:21:11 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 141
ERROR - 2016-06-26 10:21:47 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 211
ERROR - 2016-06-26 10:21:47 --> Severity: Error --> Call to a member function getitemimages() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 211
ERROR - 2016-06-26 10:22:21 --> Severity: Notice --> Undefined property: CI_Loader::$item_model C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 211
ERROR - 2016-06-26 10:22:21 --> Severity: Error --> Call to a member function getitemimages() on a non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 211
ERROR - 2016-06-26 10:56:08 --> Severity: Error --> Call to undefined function get_btn() C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 218
ERROR - 2016-06-26 11:15:59 --> Severity: Parsing Error --> syntax error, unexpected 'Package' (T_STRING) C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 200
ERROR - 2016-06-26 11:26:07 --> 404 Page Not Found: Items/deleteimage
ERROR - 2016-06-26 11:26:15 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-26 11:28:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 11:29:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\create_items.php 72
ERROR - 2016-06-26 13:35:35 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 13:36:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= 2147483647' at line 2 - Invalid query: UPDATE `tbl_items` SET `itemname` = 'Chicken Pie and Coke Edited', `itemdescription` = 'Chicken Pie and Coke', `categoryid` = '14668551670829ak', `itemquantity` = '100', `itemid` = '14669259683913zm', `vendorid` = '14668222030861qv', `franchiseid` = '2626273373', `datecreated` = '2016-06-26 13:36:04', `datemodified` = '2016-06-26 13:36:04'
WHERE  = 2147483647
ERROR - 2016-06-26 13:40:03 --> Severity: Warning --> Missing argument 1 for Items::view_item() C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 161
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Undefined variable: itemid C:\xampp\htdocs\fastfood\application\controllers\vendor\items.php 163
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 12
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 22
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 28
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 34
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 39
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 48
ERROR - 2016-06-26 13:40:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 49
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 59
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 69
ERROR - 2016-06-26 13:40:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\items\view_item.php 104
ERROR - 2016-06-26 14:08:00 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-26 14:08:02 --> 404 Page Not Found: vendor/Js/classie.js
