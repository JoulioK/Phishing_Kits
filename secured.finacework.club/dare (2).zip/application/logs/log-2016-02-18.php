<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-18 08:21:54 --> 404 Page Not Found: /index
ERROR - 2016-02-18 08:23:10 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-18 08:23:25 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-18 08:23:30 --> 404 Page Not Found: Administrator/Authenticate/index
