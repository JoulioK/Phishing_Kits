<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-22 18:56:12 --> Severity: Notice --> Undefined variable: page_level_script C:\xampp\htdocs\corperslodge\application\views\web\_layouts\footer.php 79
