<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-20 13:10:04 --> 404 Page Not Found: /index
ERROR - 2016-02-20 13:10:19 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-20 13:10:21 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 13:10:51 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 13:10:52 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 13:10:55 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 13:11:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:11:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:14:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:14:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:14:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:14:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:16:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:17:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:17:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:22:49 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;1000&quot;
LINE 2: FROM 1000
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 13:22:49 --> Query error: ERROR:  syntax error at or near "1000"
LINE 2: FROM 1000
             ^ - Invalid query: SELECT *
FROM 1000
WHERE "storeid" = '1111111111'
AND "stock_id" = '8492881610'
ERROR - 2016-02-20 13:24:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:24:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:25:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:26:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 122
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 125
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 128
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_supplier C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 131
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_datesupplied C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 134
ERROR - 2016-02-20 13:46:04 --> Severity: Notice --> Undefined property: stdClass::$stock_additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 137
ERROR - 2016-02-20 13:46:05 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 141
ERROR - 2016-02-20 13:46:05 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 141
ERROR - 2016-02-20 13:46:05 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 142
ERROR - 2016-02-20 13:46:05 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Take_stock_page.php 142
ERROR - 2016-02-20 13:46:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:46:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:46:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:49:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_qty C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 61
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_cost_price C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 64
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_selling_price C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 67
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_supplier C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 70
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_datesupplied C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 73
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$stock_additional_info C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 76
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 80
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 80
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 81
ERROR - 2016-02-20 13:49:37 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 81
ERROR - 2016-02-20 13:49:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:49:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:51:20 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 47
ERROR - 2016-02-20 13:51:20 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 47
ERROR - 2016-02-20 13:51:20 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 48
ERROR - 2016-02-20 13:51:20 --> Severity: Notice --> Undefined property: stdClass::$entryid C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 48
ERROR - 2016-02-20 13:51:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:51:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:53:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:53:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 13:53:59 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-20 13:54:03 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-20 13:56:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 13:56:40 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 13:56:40 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 13:56:40 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 13:56:40 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 13:56:41 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 13:56:41 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 13:59:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;STOCK_LEDGER&quot;
LINE 1: ...on t_stocks.stock_id = STOCK_LEDGER.stock_idWHERE STOCK_LEDG...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 13:59:37 --> Query error: ERROR:  syntax error at or near "STOCK_LEDGER"
LINE 1: ...on t_stocks.stock_id = STOCK_LEDGER.stock_idWHERE STOCK_LEDG...
                                                             ^ - Invalid query: SELECT * FROM STOCK_LEDGER INNER JOIN t_stock on t_stocks.stock_id = STOCK_LEDGER.stock_idWHERE STOCK_LEDGER.storeid = '1111111111'
ERROR - 2016-02-20 13:59:52 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;stock_ledger&quot; does not exist
LINE 1: SELECT * FROM STOCK_LEDGER INNER JOIN t_stock on t_stocks.st...
                      ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 13:59:52 --> Query error: ERROR:  relation "stock_ledger" does not exist
LINE 1: SELECT * FROM STOCK_LEDGER INNER JOIN t_stock on t_stocks.st...
                      ^ - Invalid query: SELECT * FROM STOCK_LEDGER INNER JOIN t_stock on t_stocks.stock_id = STOCK_LEDGER.stock_id WHERE STOCK_LEDGER.storeid = '1111111111'
ERROR - 2016-02-20 14:00:13 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;'STOCK_LEDGER'&quot;
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:00:13 --> Query error: ERROR:  syntax error at or near "'STOCK_LEDGER'"
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ - Invalid query: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks.stock_id = 'STOCK_LEDGER'.stock_id WHERE STOCK_LEDGER.storeid = '1111111111'
ERROR - 2016-02-20 14:00:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;'STOCK_LEDGER'&quot;
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:00:37 --> Query error: ERROR:  syntax error at or near "'STOCK_LEDGER'"
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ - Invalid query: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks.stock_id = 'STOCK_LEDGER'.stock_id WHERE STOCK_LEDGER.storeid = '1111111111'
ERROR - 2016-02-20 14:00:49 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;'STOCK_LEDGER'&quot;
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:00:49 --> Query error: ERROR:  syntax error at or near "'STOCK_LEDGER'"
LINE 1: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks....
                      ^ - Invalid query: SELECT * FROM 'STOCK_LEDGER' INNER JOIN t_stock on t_stocks.stock_id = 'STOCK_LEDGER'.stock_id WHERE STOCK_LEDGER.storeid = '1111111111'
ERROR - 2016-02-20 14:02:23 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock&quot; does not exist
LINE 1: SELECT * FROM &quot;STOCK_LEDGER&quot; INNER JOIN t_stock on t_stocks....
                                                ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:02:23 --> Query error: ERROR:  relation "t_stock" does not exist
LINE 1: SELECT * FROM "STOCK_LEDGER" INNER JOIN t_stock on t_stocks....
                                                ^ - Invalid query: SELECT * FROM "STOCK_LEDGER" INNER JOIN t_stock on t_stocks.stock_id = "STOCK_LEDGER".stock_id WHERE "STOCK_LEDGER".storeid = "1111111111"
ERROR - 2016-02-20 14:34:51 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character varying = integer
LINE 1: ...LEDGER&quot;.&quot;stock_id&quot; WHERE &quot;STOCK_LEDGER&quot;.&quot;storeid&quot; = 11111111...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:34:51 --> Query error: ERROR:  operator does not exist: character varying = integer
LINE 1: ...LEDGER"."stock_id" WHERE "STOCK_LEDGER"."storeid" = 11111111...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT * FROM "STOCK_LEDGER" INNER JOIN "t_stocks" on "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id" WHERE "STOCK_LEDGER"."storeid" = 1111111111
ERROR - 2016-02-20 14:35:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: character varying = integer
LINE 1: ...LEDGER&quot;.&quot;stock_id&quot; WHERE &quot;STOCK_LEDGER&quot;.&quot;storeid&quot; =111111111...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 14:35:36 --> Query error: ERROR:  operator does not exist: character varying = integer
LINE 1: ...LEDGER"."stock_id" WHERE "STOCK_LEDGER"."storeid" =111111111...
                                                             ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT * FROM "STOCK_LEDGER" INNER JOIN "t_stocks" on "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id" WHERE "STOCK_LEDGER"."storeid" =1111111111
ERROR - 2016-02-20 14:36:34 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 29
ERROR - 2016-02-20 14:39:04 --> Severity: Notice --> Undefined property: stdClass::$stock_price C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_Page.php 21
ERROR - 2016-02-20 14:39:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:39:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:39:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:39:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:39:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:42:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:42:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:42:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:42:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:43:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:43:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:43:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:43:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:46:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:47:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:47:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:47:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:47:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:48:15 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:48:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:48:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:49:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:49:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:49:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:49:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:56:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:56:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:56:39 --> 404 Page Not Found: Stores/Sales
ERROR - 2016-02-20 14:56:50 --> 404 Page Not Found: Stores/Sales
ERROR - 2016-02-20 14:57:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:57:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:57:52 --> 404 Page Not Found: Stores/Sales
ERROR - 2016-02-20 14:58:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 14:58:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:01:24 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 61
ERROR - 2016-02-20 15:08:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:08:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:09:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:09:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:09:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:09:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:10:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:10:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 15:12:17 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 15:12:18 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 15:12:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:12:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:13:35 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;150&quot;
LINE 2: FROM 150
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 15:13:35 --> Query error: ERROR:  syntax error at or near "150"
LINE 2: FROM 150
             ^ - Invalid query: SELECT *
FROM 150
WHERE "storeid" = '1111111111'
AND "stock_id" = '4608119329'
ERROR - 2016-02-20 15:14:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:14:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:14:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:14:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 15:15:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 15:15:40 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 15:15:43 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 41
ERROR - 2016-02-20 15:16:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:16:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:17:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:19:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:19:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:19:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:19:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:24:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:24:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:25:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:25:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:26:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:26:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:26:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:27:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:27:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:27:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:27:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:28:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:33:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:33:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:34:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:35:57 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:36:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:36:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:37:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:37:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:38:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:38:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:39:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:40:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:40:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:41:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:41:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:43:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:43:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:44:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:44:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:57 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:45:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:48:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:48:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:52:15 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;STOCK_LEDGER&quot; already exists C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 15:52:15 --> Query error: ERROR:  relation "STOCK_LEDGER" already exists - Invalid query: CREATE TABLE "STOCK_LEDGER" (
	"id" SERIAL NOT NULL,
	"ledger_id" VARCHAR(10) NOT NULL,
	"storeid" VARCHAR(10) NOT NULL,
	"stock_id" VARCHAR(10) NOT NULL,
	"stock_qty" INT NOT NULL,
	"stock_selling_price" DECIMAL(10,2) NOT NULL,
	datecreated timestamp default now(),
	datemodified timestamp default now(),
	CONSTRAINT "pk_STOCK_LEDGER" PRIMARY KEY("id")
)
ERROR - 2016-02-20 15:52:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:52:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:53:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:53:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:53:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 15:53:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:01:45 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;entry_id&quot; does not exist
LINE 3: WHERE &quot;entry_id&quot; = '8303608023'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:01:45 --> Query error: ERROR:  column "entry_id" does not exist
LINE 3: WHERE "entry_id" = '8303608023'
              ^ - Invalid query: SELECT *
FROM "t_sales"
WHERE "entry_id" = '8303608023'
AND "t_sales"."storeid" = '1111111111'
ORDER BY "t_sales"."id" ASC
ERROR - 2016-02-20 16:03:07 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;stock_datesold&quot; violates not-null constraint
DETAIL:  Failing row contains (1, 1280620773, 1111111111, 8492881610, 1, 2000, null, 2222222222, 2016-02-20 15:03:07.623, 2016-02-20 15:03:07.623). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:03:07 --> Query error: ERROR:  null value in column "stock_datesold" violates not-null constraint
DETAIL:  Failing row contains (1, 1280620773, 1111111111, 8492881610, 1, 2000, null, 2222222222, 2016-02-20 15:03:07.623, 2016-02-20 15:03:07.623). - Invalid query: INSERT INTO "t_sales" ("entryid", "storeid", "stock_id", "stock_qty", "stock_selling_price", "added_by") VALUES ('1280620773', '1111111111', '8492881610', '1', '2000.00', '2222222222')
ERROR - 2016-02-20 16:12:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:12:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:12:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:12:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:12:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 102
ERROR - 2016-02-20 16:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 103
ERROR - 2016-02-20 16:12:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 103
ERROR - 2016-02-20 16:13:34 --> Severity: Warning --> pg_query(): Query failed: ERROR:  operator does not exist: integer = boolean
LINE 5: AND &quot;id&quot; = TRUE
                 ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:13:34 --> Query error: ERROR:  operator does not exist: integer = boolean
LINE 5: AND "id" = TRUE
                 ^
HINT:  No operator matches the given name and argument type(s). You might need to add explicit type casts. - Invalid query: SELECT *
FROM "STOCK_LEDGER"
WHERE "storeid" = '1111111111'
AND "stock_id" = '3048657976'
AND "id" = TRUE
AND "STOCK_LEDGER"."storeid" = '1111111111'
ORDER BY "STOCK_LEDGER"."id" ASC
ERROR - 2016-02-20 16:14:41 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 95
ERROR - 2016-02-20 16:24:29 --> Severity: Notice --> Undefined variable: update_stock_ledger C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 105
ERROR - 2016-02-20 16:24:29 --> Severity: Notice --> Use of undefined constant save_sale - assumed 'save_sale' C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 105
ERROR - 2016-02-20 16:28:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:29:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:32:04 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;,&quot;
LINE 2: FROM &quot;t_sales&quot;.*, &quot;t_stocks&quot;.&quot;stock_name&quot;
                        ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:32:04 --> Query error: ERROR:  syntax error at or near ","
LINE 2: FROM "t_sales".*, "t_stocks"."stock_name"
                        ^ - Invalid query: SELECT *
FROM "t_sales".*, "t_stocks"."stock_name"
ERROR - 2016-02-20 16:36:05 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 46
ERROR - 2016-02-20 16:36:05 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:36:06 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:36:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:36:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:37:31 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:37:31 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:38:17 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:38:17 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:39:43 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:39:44 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:39:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:39:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:39:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:39:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:39:59 --> Severity: Error --> Call to undefined method Sales::redirect() C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 119
ERROR - 2016-02-20 16:40:34 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:40:34 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:41:17 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:41:18 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:41:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:47 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:41:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:41:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 16:41:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 16:42:00 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:42:00 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:42:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 16:42:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 16:42:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:42:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:42:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 16:42:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-20 16:42:29 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:42:30 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:42:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:42:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:47:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:47:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:47:21 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;t_stock_taking&quot;
LINE 3: ...       INNER JOIN t_stocks ON t_stocks.stock_id = t_stock_ta...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:47:22 --> Query error: ERROR:  missing FROM-clause entry for table "t_stock_taking"
LINE 3: ...       INNER JOIN t_stocks ON t_stocks.stock_id = t_stock_ta...
                                                             ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_stock_taking.stock_id
            WHERE t_sales.storeid = '1111111111'
            GROUP BY t_sales.stock_id,t_stocks.stock_name
ERROR - 2016-02-20 16:48:04 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:48:05 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Undefined variable: takensale C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 59
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 59
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Undefined variable: takensale C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 65
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 65
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Undefined variable: takensale C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 59
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 59
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Undefined variable: takensale C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 65
ERROR - 2016-02-20 16:48:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_summary_page.php 65
ERROR - 2016-02-20 16:48:21 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:48:23 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:48:59 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:01 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:15 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:16 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:49:50 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:50 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:53 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:49:53 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:50:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:50:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:50:51 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column t_stocks.stockname does not exist
LINE 1: ...&quot;.&quot;stock_id&quot; = &quot;STOCK_LEDGER&quot;.&quot;stock_id&quot; ORDER BY t_stocks.s...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-20 16:50:51 --> Query error: ERROR:  column t_stocks.stockname does not exist
LINE 1: ..."."stock_id" = "STOCK_LEDGER"."stock_id" ORDER BY t_stocks.s...
                                                             ^ - Invalid query: SELECT * FROM "STOCK_LEDGER" INNER JOIN "t_stocks" on "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id" ORDER BY t_stocks.stockname ASC
ERROR - 2016-02-20 16:51:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:51:07 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 16:52:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:52:23 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:52:23 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 16:52:23 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 16:52:23 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:52:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:52:24 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:52:24 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:53:22 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-20 16:53:23 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-20 16:53:23 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-20 16:53:23 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-20 16:54:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:54:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:55:57 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:56:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:56:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:57:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:57:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:58:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:58:11 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:58:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:58:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:59:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 16:59:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:00:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:00:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:00:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:00:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:01:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:01:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-20 17:01:11 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 17:01:12 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 17:01:19 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-20 17:01:19 --> 404 Page Not Found: Store/Sales/images
