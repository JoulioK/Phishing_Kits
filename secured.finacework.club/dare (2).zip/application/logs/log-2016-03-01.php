<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-01 09:45:42 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-03-01 09:45:44 --> 404 Page Not Found: Store/Js/classie.js
