<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-30 07:49:13 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-30 08:00:33 --> Query error: Unknown column 'tbl_ph.userid' in 'on clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_gh.datecreated between '2017-04-30 00:00:01' AND '2017-04-30 23:59:59'
AND `tbl_users`.`emailaddress` IS NULL
ORDER BY `id` DESC
ERROR - 2017-04-30 08:00:33 --> Query error: Unknown column 'tbl_gh.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493535633
WHERE tbl_gh.datecreated between '2017-04-30 00:00:01' AND '2017-04-30 23:59:59'
AND `tbl_users`.`emailaddress` IS NULL
AND `id` = 'ba3cb4bea1bee986cd472561cb3f5a6e1f81e6b3'
ORDER BY `id` DESC
ERROR - 2017-04-30 09:04:34 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2017-04-30 09:04:34 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2017-04-30 09:58:04 --> Query error: Unknown column 'tbl_packages.papckagename' in 'field list' - Invalid query: SELECT `tbl_gh`.*, `tbl_packages`.`papckagename`
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 50
ERROR - 2017-04-30 09:58:04 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493542684
WHERE `id` = 'ba3cb4bea1bee986cd472561cb3f5a6e1f81e6b3'
ORDER BY `tbl_ph`.`id` DESC LIMIT 50
ERROR - 2017-04-30 09:58:30 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: SELECT `tbl_gh`.*, `tbl_packages`.`packagename`
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_gh`.`packageid`=`tbl_packages`.`packageid`
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 50
ERROR - 2017-04-30 09:58:31 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493542711
WHERE `id` = 'ba3cb4bea1bee986cd472561cb3f5a6e1f81e6b3'
ORDER BY `tbl_ph`.`id` DESC LIMIT 50
ERROR - 2017-04-30 11:11:51 --> Severity: Compile Error --> Cannot redeclare Orders::withdrawalrequest() C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 249
ERROR - 2017-04-30 11:12:22 --> Severity: Compile Error --> Cannot redeclare Orders::withdrawalrequest() C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 249
ERROR - 2017-04-30 11:20:31 --> Severity: Compile Error --> Cannot redeclare Orders::withdrawalrequest() C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 249
ERROR - 2017-04-30 11:21:48 --> Severity: Compile Error --> Cannot redeclare Orders::withdrawalrequest() C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 249
ERROR - 2017-04-30 12:23:22 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 575
ERROR - 2017-04-30 12:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 162
ERROR - 2017-04-30 12:23:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 170
ERROR - 2017-04-30 12:23:26 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 575
ERROR - 2017-04-30 12:23:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 162
ERROR - 2017-04-30 12:23:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 170
ERROR - 2017-04-30 12:25:57 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 98
ERROR - 2017-04-30 12:25:57 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 98
ERROR - 2017-04-30 13:13:04 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 169
ERROR - 2017-04-30 13:13:04 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 169
ERROR - 2017-04-30 13:40:26 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-04-30 14:50:07 --> 404 Page Not Found: management/Js/classie.js
