<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-19 01:39:17 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:39:41 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:39:42 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-19 01:39:42 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-19 01:39:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-19 01:45:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 68
ERROR - 2016-07-19 01:45:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 68
ERROR - 2016-07-19 01:45:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 68
ERROR - 2016-07-19 01:49:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 69
ERROR - 2016-07-19 01:49:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 69
ERROR - 2016-07-19 01:49:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 69
ERROR - 2016-07-19 01:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 81
ERROR - 2016-07-19 01:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 81
ERROR - 2016-07-19 01:58:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 81
ERROR - 2016-07-19 02:16:21 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 85
ERROR - 2016-07-19 02:16:22 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 97
ERROR - 2016-07-19 02:16:22 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 85
ERROR - 2016-07-19 02:16:22 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 97
ERROR - 2016-07-19 02:16:22 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 85
ERROR - 2016-07-19 02:16:22 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 97
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:17:27 --> Severity: Notice --> Undefined index: firstname C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 29
ERROR - 2016-07-19 02:40:49 --> 404 Page Not Found: Hub/settings
ERROR - 2016-07-19 02:42:01 --> 404 Page Not Found: Hub/settings
ERROR - 2016-07-19 03:04:25 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\fastfood\application\controllers\web\settings.php 132
ERROR - 2016-07-19 03:14:58 --> Severity: Notice --> Undefined property: CI_Cart::$contents C:\xampp\htdocs\fastfood\application\views\web\pages\cart.php 131
ERROR - 2016-07-19 03:29:10 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\fastfood\application\views\web\_layouts\_customer_navigation.php 163
ERROR - 2016-07-19 03:29:10 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\fastfood\application\views\web\_layouts\_customer_navigation.php 164
