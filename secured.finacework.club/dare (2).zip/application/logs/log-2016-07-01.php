<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-01 12:39:03 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-01 13:02:39 --> 404 Page Not Found: vendor/Location/index
ERROR - 2016-07-01 13:02:46 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-01 13:05:41 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 3
ERROR - 2016-07-01 13:18:46 --> 404 Page Not Found: Js/classie.js
ERROR - 2016-07-01 13:18:55 --> 404 Page Not Found: management/Item_unit/index
ERROR - 2016-07-01 13:37:19 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-01 13:40:12 --> 404 Page Not Found: Js/classie.js
ERROR - 2016-07-01 14:14:21 --> 404 Page Not Found: management/Delivery/add_delivery_guy
ERROR - 2016-07-01 14:19:36 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:21:36 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:22:19 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:23:33 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:24:39 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:25:04 --> Could not find the language line "form_validation_match"
ERROR - 2016-07-01 14:27:52 --> 404 Page Not Found: management/Delivery/view_delivery_guys
ERROR - 2016-07-01 14:29:52 --> 404 Page Not Found: management/Users/14673759667746uf
ERROR - 2016-07-01 14:30:33 --> 404 Page Not Found: management/Delivery/14673759667746uf
ERROR - 2016-07-01 14:41:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\view_delivery_guys.php 67
ERROR - 2016-07-01 14:41:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\view_delivery_guys.php 67
ERROR - 2016-07-01 14:46:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\add_delivery_guy.php 55
ERROR - 2016-07-01 14:46:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\add_delivery_guy.php 73
ERROR - 2016-07-01 14:46:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\add_delivery_guy.php 78
ERROR - 2016-07-01 14:46:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\add_delivery_guy.php 83
ERROR - 2016-07-01 14:46:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\add_delivery_guy.php 93
ERROR - 2016-07-01 16:10:15 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) C:\xampp\htdocs\fastfood\application\controllers\web\home.php 6
