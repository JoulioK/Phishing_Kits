<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-27 07:23:02 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 62
ERROR - 2017-04-27 07:23:41 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 62
ERROR - 2017-04-27 10:12:56 --> 404 Page Not Found: web/Btc/plan
ERROR - 2017-04-27 10:17:06 --> 404 Page Not Found: web/User/pick
ERROR - 2017-04-27 10:49:16 --> Query error: Unknown column 'tbl_package.packagename' in 'field list' - Invalid query: SELECT distinct(tbl_gh.packageid), `tbl_package`.`packagename`
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_packages`.`packageid`=`tbl_gh`.`packageid`
WHERE `tbl_gh`.`userid` = '14853742757197xj'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-27 10:49:16 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493286556
WHERE `tbl_gh`.`userid` = '14853742757197xj'
AND `id` = '63914e84a69c763880c6641223c0e865a403f5d3'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-27 10:49:30 --> Query error: Unknown column 'tbl_trade_earnings.id' in 'order clause' - Invalid query: SELECT distinct(tbl_gh.packageid), `tbl_packages`.`packagename`
FROM `tbl_gh`
JOIN `tbl_packages` ON `tbl_packages`.`packageid`=`tbl_gh`.`packageid`
WHERE `tbl_gh`.`userid` = '14853742757197xj'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-27 10:49:30 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493286570
WHERE `tbl_gh`.`userid` = '14853742757197xj'
AND `id` = '63914e84a69c763880c6641223c0e865a403f5d3'
ORDER BY `tbl_trade_earnings`.`id` desc
ERROR - 2017-04-27 11:05:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 178
