<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-09 01:10:57 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-10-09 01:11:23 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\management\Delivery.php 112
ERROR - 2016-10-09 04:17:46 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-10-09 11:45:32 --> Severity: Notice --> Undefined variable: delivery C:\xampp\htdocs\fastfood\application\views\management\delivery\track_guys.php 12
ERROR - 2016-10-09 11:45:32 --> Severity: Notice --> Undefined variable: delivery C:\xampp\htdocs\fastfood\application\views\management\delivery\track_guys.php 58
ERROR - 2016-10-09 11:45:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\delivery\track_guys.php 58
ERROR - 2016-10-09 12:07:19 --> Severity: Notice --> Undefined variable: delivery C:\xampp\htdocs\fastfood\application\views\management\delivery\track_guys.php 55
ERROR - 2016-10-09 12:07:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\delivery\track_guys.php 55
