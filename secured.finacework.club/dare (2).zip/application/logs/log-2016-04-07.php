<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-07 09:25:06 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_tither&quot; does not exist C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-04-07 09:25:06 --> Unable to connect to the database
ERROR - 2016-04-07 09:26:09 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_store_users&quot; does not exist C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-04-07 09:26:09 --> Query error: ERROR:  relation "t_store_users" does not exist - Invalid query: ALTER TABLE "t_store_users" ADD "added_by" VARCHAR(10)
ERROR - 2016-04-07 09:27:47 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\controllers\Route.php 8
ERROR - 2016-04-07 09:28:15 --> Severity: Notice --> Undefined index: current_url C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 42
ERROR - 2016-04-07 09:28:16 --> Severity: Notice --> Undefined index: storedata C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 23
ERROR - 2016-04-07 09:28:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 23
ERROR - 2016-04-07 09:28:16 --> Severity: Notice --> Undefined property: W_index::$storeid C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 24
ERROR - 2016-04-07 09:28:46 --> Severity: Notice --> Undefined index: storedata C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 23
ERROR - 2016-04-07 09:28:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 23
ERROR - 2016-04-07 09:28:46 --> Severity: Notice --> Undefined property: W_index::$storeid C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 24
ERROR - 2016-04-07 09:29:07 --> Severity: Notice --> Undefined variable: stock_settings C:\xampp\htdocs\tithe\application\libraries\Web_Controller.php 24
ERROR - 2016-04-07 09:29:07 --> Severity: Notice --> Undefined index: theme C:\xampp\htdocs\tithe\application\controllers\Web\W_index.php 9
ERROR - 2016-04-07 09:29:11 --> 404 Page Not Found: Admin//index
ERROR - 2016-04-07 09:29:24 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:30:59 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:31:04 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:31:10 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:32:23 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:33:31 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:33:36 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:34:30 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:34:34 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_admin_users&quot; does not exist
LINE 2: FROM &quot;t_admin_users&quot;
             ^ C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-04-07 09:34:34 --> Query error: ERROR:  relation "t_admin_users" does not exist
LINE 2: FROM "t_admin_users"
             ^ - Invalid query: SELECT *
FROM "t_admin_users"
WHERE ((username = 'seun') OR (email_address = 'seun')) AND "password" = '8aad41b0eb7dd57c3e459a943914240ba3066cbf'
ORDER BY "t_admin_users"."id" ASC
ERROR - 2016-04-07 09:34:55 --> 404 Page Not Found: Store/Dashboard
ERROR - 2016-04-07 09:35:14 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\tithe\application\controllers\Admin\Dashboard.php 3
ERROR - 2016-04-07 09:35:54 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\tithe\application\controllers\Admin\Dashboard.php 3
ERROR - 2016-04-07 09:35:56 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\tithe\application\controllers\Admin\Dashboard.php 3
ERROR - 2016-04-07 09:37:44 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Store\_templates\_header.php 22
ERROR - 2016-04-07 09:37:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Store\_templates\_header.php 22
ERROR - 2016-04-07 09:37:44 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: storedata C:\xampp\htdocs\tithe\application\views\Admin\_templates\_header.php 22
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Admin\_templates\_header.php 22
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 122
ERROR - 2016-04-07 09:38:52 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 141
ERROR - 2016-04-07 09:38:53 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 122
ERROR - 2016-04-07 09:39:10 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 141
ERROR - 2016-04-07 09:39:11 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 111
ERROR - 2016-04-07 09:39:43 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 130
ERROR - 2016-04-07 09:39:43 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:40:06 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:06 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:06 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:06 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:40:06 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 111
ERROR - 2016-04-07 09:40:06 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:40:35 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:35 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:35 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:35 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:40:35 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:40:55 --> Severity: Notice --> Undefined variable: total_income C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:55 --> Severity: Notice --> Undefined variable: all_time_sales C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:55 --> Severity: Notice --> Undefined variable: total_expenses C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 1
ERROR - 2016-04-07 09:40:55 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 11
ERROR - 2016-04-07 09:40:55 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:41:31 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 8
ERROR - 2016-04-07 09:41:31 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 15
ERROR - 2016-04-07 09:41:31 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 17
ERROR - 2016-04-07 09:41:31 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 24
ERROR - 2016-04-07 09:41:31 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 27
ERROR - 2016-04-07 09:41:31 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:41:50 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\tithe\application\views\Admin\dashboard_page.php 8
ERROR - 2016-04-07 09:41:50 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:42:03 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:43:20 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:44:29 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:45:05 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:45:09 --> 404 Page Not Found: Store/Authenticate
ERROR - 2016-04-07 09:45:21 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:45:25 --> Severity: Notice --> Undefined property: Authenticate::$Admin_User_model C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 34
ERROR - 2016-04-07 09:45:26 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\tithe\application\controllers\Admin\Authenticate.php 34
ERROR - 2016-04-07 09:46:06 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:46:06 --> 404 Page Not Found: Admin/Js/classie.js
ERROR - 2016-04-07 09:46:14 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:47:00 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:47:10 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:47:33 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:56:45 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:57:42 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 09:57:47 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\tithe\application\controllers\Admin\Tithers.php 3
ERROR - 2016-04-07 09:59:00 --> Severity: Notice --> Undefined property: Tithers::$storeid C:\xampp\htdocs\tithe\application\controllers\Admin\Tithers.php 89
ERROR - 2016-04-07 09:59:00 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-04-07 09:59:00 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" IS NULL
              ^ - Invalid query: SELECT *
FROM "t_tithers"
WHERE "storeid" IS NULL
ORDER BY "t_tithers"."id" ASC
ERROR - 2016-04-07 09:59:29 --> Severity: Notice --> Undefined property: Tithers::$storeid C:\xampp\htdocs\tithe\application\controllers\Admin\Tithers.php 88
ERROR - 2016-04-07 09:59:29 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-04-07 09:59:29 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" IS NULL
              ^ - Invalid query: SELECT *
FROM "t_tithers"
WHERE "storeid" IS NULL
ORDER BY "t_tithers"."id" ASC
ERROR - 2016-04-07 09:59:47 --> Severity: Notice --> Undefined property: Tithers::$storeid C:\xampp\htdocs\tithe\application\controllers\Admin\Tithers.php 87
ERROR - 2016-04-07 09:59:47 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\tithe\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-04-07 09:59:47 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" IS NULL
              ^ - Invalid query: SELECT *
FROM "t_tithers"
WHERE "storeid" IS NULL
ORDER BY "t_tithers"."id" ASC
ERROR - 2016-04-07 10:01:03 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\tithe\application\views\Admin\Tithers\Tither_page.php 20
ERROR - 2016-04-07 10:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Admin\Tithers\Tither_page.php 20
ERROR - 2016-04-07 10:01:03 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\tithe\application\views\Admin\Tithers\Tither_page.php 24
ERROR - 2016-04-07 10:01:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\tithe\application\views\Admin\Tithers\Tither_page.php 24
ERROR - 2016-04-07 10:01:03 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 10:01:37 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 10:03:28 --> 404 Page Not Found: Admin/Images/a.png
ERROR - 2016-04-07 12:28:07 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:31:00 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:31:53 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:34:05 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:35:32 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:38:11 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:38:14 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:40:15 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_tither&quot; does not exist C:\xampp\htdocs\tither\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-04-07 12:40:15 --> Unable to connect to the database
ERROR - 2016-04-07 12:40:22 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:40:23 --> 404 Page Not Found: /index
ERROR - 2016-04-07 12:40:28 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_tither&quot; does not exist C:\xampp\htdocs\tither\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-04-07 12:40:28 --> Unable to connect to the database
ERROR - 2016-04-07 12:44:45 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_tither&quot; does not exist C:\xampp\htdocs\tither\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-04-07 12:44:45 --> Unable to connect to the database
ERROR - 2016-04-07 13:07:33 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_tither&quot; does not exist C:\xampp\htdocs\tither\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-04-07 13:07:33 --> Unable to connect to the database
ERROR - 2016-04-07 13:08:24 --> 404 Page Not Found: Images/timer.png
ERROR - 2016-04-07 13:08:28 --> 404 Page Not Found: Images/timer.png
ERROR - 2016-04-07 13:08:28 --> 404 Page Not Found: Resources/web
