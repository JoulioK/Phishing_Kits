<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-15 12:07:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-15 12:07:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-15 12:07:57 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-03-15 12:07:57 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-03-15 12:08:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-03-15 12:08:39 --> 404 Page Not Found: Store/Images/a.png
