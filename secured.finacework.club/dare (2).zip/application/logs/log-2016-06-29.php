<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-29 02:39:43 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-29 02:39:43 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-06-29 17:38:20 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-29 17:56:35 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-29 17:56:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-29 22:45:16 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-29 22:45:17 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\configuration_model.php 63
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:45:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:45:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\configuration_model.php 63
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:46:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\configuration_model.php 63
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 29
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 36
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 53
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 58
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:47:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 63
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\configuration_model.php 63
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 23
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 23
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 24
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 24
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 35
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 35
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 52
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 52
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Undefined variable: fanchise C:\xampp\htdocs\fastfood\application\views\management\configuration.php 57
ERROR - 2016-06-29 22:48:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 57
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\configuration_model.php 63
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 23
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 24
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 30
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 35
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 41
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 47
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 52
ERROR - 2016-06-29 22:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\configuration.php 57
ERROR - 2016-06-29 22:49:56 --> Severity: Notice --> Undefined property: stdClass::$franchisename C:\xampp\htdocs\fastfood\application\views\management\configuration.php 23
ERROR - 2016-06-29 23:20:10 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\configuration.php 37
ERROR - 2016-06-29 23:21:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\configuration.php 38
ERROR - 2016-06-29 23:22:42 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\views\management\configuration.php 39
ERROR - 2016-06-29 23:26:31 --> Query error: Unknown column 'franchisename' in 'field list' - Invalid query: UPDATE `tbl_franchise_configuration` SET `franchisename` = 'Chities', `franchiselocation` = '14668510290307aw', `franchiseaddress` = 'No 23, Nawfia Street', `franchisephone` = '+2348068752947', `franchiseemail` = 'olafashade@hotmail.com', `shippingfee` = '500', `slashdiscount` = '5'
WHERE `id` = 2147483647
ERROR - 2016-06-29 23:27:38 --> Query error: Unknown column 'franchisename' in 'field list' - Invalid query: INSERT INTO `tbl_franchise_configuration` (`franchisename`, `franchiselocation`, `franchiseaddress`, `franchisephone`, `franchiseemail`, `shippingfee`, `slashdiscount`) VALUES ('Chities', '14668510290307aw', 'No 23, Nawfia Street', '+2348068752947', 'olafashade@hotmail.com', '500', '5')
ERROR - 2016-06-29 23:29:39 --> Severity: Notice --> Undefined property: Configuration::$franchiseid C:\xampp\htdocs\fastfood\application\controllers\management\configuration.php 13
