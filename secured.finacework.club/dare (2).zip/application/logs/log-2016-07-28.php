<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-28 17:26:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 143
ERROR - 2016-07-28 17:31:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-28 18:50:55 --> Severity: Notice --> Undefined property: stdClass::$shippingaddress C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-28 20:59:26 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\item.php 270
ERROR - 2016-07-28 20:59:39 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\item.php 270
ERROR - 2016-07-28 21:19:36 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `locationname`
FROM `tbl_location`
WHERE `locationid` = '14675831192868hv'
ORDER BY `id` ASC
ERROR - 2016-07-28 21:19:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-28 21:19:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-28 21:19:45 --> Severity: Notice --> Undefined property: Item::$settings_model C:\xampp\htdocs\fastfood\application\controllers\app\item.php 306
ERROR - 2016-07-28 21:19:46 --> Severity: Error --> Call to a member function generate_unique_id() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 306
ERROR - 2016-07-28 21:20:13 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `locationname`
FROM `tbl_location`
WHERE `locationid` = '14675831192868hv'
ORDER BY `id` ASC
ERROR - 2016-07-28 21:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-28 21:20:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-28 21:21:03 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `locationname`
FROM `tbl_location`
WHERE `locationid` = '14675831192868hv'
ORDER BY `id` ASC
ERROR - 2016-07-28 21:21:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-28 21:21:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-28 21:24:41 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `locationname`
FROM `tbl_location`
WHERE `locationid` = '14675831192868hv'
ORDER BY `id` ASC
ERROR - 2016-07-28 21:24:45 --> Query error: Table 'fastfood.tbl_location' doesn't exist - Invalid query: SELECT `locationname`
FROM `tbl_location`
WHERE `locationid` = '14675831192868hv'
ORDER BY `id` ASC
ERROR - 2016-07-28 21:25:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 281
