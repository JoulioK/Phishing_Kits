<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-17 17:02:19 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-17 17:12:14 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 37 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 2 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:50 --> Severity: Warning --> Missing argument 3 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:51 --> Severity: Warning --> Missing argument 4 for Message_model::getuser(), called in C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php on line 38 and defined C:\xampp\htdocs\fastfood\application\models\web\message_model.php 57
ERROR - 2016-07-17 17:14:51 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\models\web\message_model.php 75
ERROR - 2016-07-17 17:14:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\message_model.php 79
ERROR - 2016-07-17 17:21:36 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-17 17:29:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-17 17:34:10 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-17 17:36:02 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 17:37:21 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-17 17:41:30 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-17 17:41:34 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 18:47:15 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 18:47:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 19:00:20 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\management\page.php 9
ERROR - 2016-07-17 19:00:20 --> Severity: Notice --> Undefined index: page_javascript C:\xampp\htdocs\fastfood\application\controllers\management\page.php 9
ERROR - 2016-07-17 19:01:19 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\management\page.php 9
ERROR - 2016-07-17 19:01:19 --> 404 Page Not Found: management/Resources/general
ERROR - 2016-07-17 19:16:40 --> Severity: Notice --> Undefined variable: catid C:\xampp\htdocs\fastfood\application\controllers\management\page.php 43
ERROR - 2016-07-17 19:16:51 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\fastfood\application\views\management\page.php 22
ERROR - 2016-07-17 19:16:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\page.php 22
ERROR - 2016-07-17 19:16:51 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\fastfood\application\views\management\page.php 29
ERROR - 2016-07-17 19:16:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\page.php 29
ERROR - 2016-07-17 19:16:51 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\page.php 35
ERROR - 2016-07-17 19:24:07 --> Severity: Notice --> Undefined variable: catid C:\xampp\htdocs\fastfood\application\controllers\management\page.php 43
ERROR - 2016-07-17 20:22:47 --> 404 Page Not Found: management/Report/order
ERROR - 2016-07-17 20:22:53 --> 404 Page Not Found: management/Report/order
ERROR - 2016-07-17 20:23:25 --> 404 Page Not Found: management/Report/orders
ERROR - 2016-07-17 20:25:57 --> 404 Page Not Found: management/Delivery/statistics
ERROR - 2016-07-17 21:38:58 --> 404 Page Not Found: management/Users/14687841867486tw
ERROR - 2016-07-17 22:32:39 --> 404 Page Not Found: management/Delivery/statistics
ERROR - 2016-07-17 22:42:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 22:42:46 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-17 22:49:07 --> 404 Page Not Found: management/Delivery/statistics
ERROR - 2016-07-17 22:50:06 --> 404 Page Not Found: management/Orders/view_order
