<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-13 05:02:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:02:47 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:03:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-13 05:03:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-13 05:05:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 171
ERROR - 2017-02-13 05:05:18 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:06:34 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:06:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:06:46 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:07:18 --> 404 Page Not Found: web/Referrals/earnings
ERROR - 2017-02-13 05:07:40 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:07:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:07:57 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:08:38 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:08:51 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:08:54 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:08:58 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 05:09:01 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 06:39:39 --> Query error: Unknown column 'tbl_referral_earnings' in 'on clause' - Invalid query: SELECT *
FROM `tbl_referral_earnings`
LEFT JOIN `tbl_users` ON `tbl_users`.`userid`=`tbl_referral_earnings`
WHERE tbl_referral_earnings.sponsor  = '14862327593536gv'
ORDER BY `tbl_referral_earnings`.`datecreated` DESC
ERROR - 2017-02-13 06:39:39 --> Query error: Unknown column 'tbl_referral_earnings.sponsor' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1486964379
WHERE tbl_referral_earnings.sponsor  = '14862327593536gv'
AND `id` = 'e52fedd3968d6203a842a507672cc3ecb81a6e81'
ORDER BY `tbl_referral_earnings`.`datecreated` DESC
ERROR - 2017-02-13 06:59:44 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 07:00:02 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 07:00:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\earning.php 29
ERROR - 2017-02-13 07:00:52 --> Severity: Error --> Call to undefined function dateofmonth() C:\xampp\htdocs\charity\application\views\web\customer\earning.php 30
ERROR - 2017-02-13 07:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\earning.php 28
ERROR - 2017-02-13 07:01:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\earning.php 29
ERROR - 2017-02-13 07:01:39 --> Severity: Error --> Call to undefined function dateofmonth() C:\xampp\htdocs\charity\application\views\web\customer\earning.php 30
ERROR - 2017-02-13 07:02:00 --> Severity: Error --> Call to undefined function dateofmonth() C:\xampp\htdocs\charity\application\views\web\customer\earning.php 30
ERROR - 2017-02-13 07:03:51 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 10:55:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-13 10:56:02 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
