<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-18 09:26:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:27:15 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:27:32 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:28:00 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:28:14 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:28:26 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:29:10 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:29:10 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:31:16 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-09-18 09:31:28 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-09-18 09:31:34 --> 404 Page Not Found: management/Js/classie.js
