<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-20 04:11:14 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 04:11:15 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 06:27:35 --> Severity: Notice --> Undefined variable: client C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 97
ERROR - 2016-12-20 06:27:35 --> Severity: Error --> Call to a member function getPrimaryAccount() on a non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 97
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 26
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 34
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Undefined variable: bitcointosell C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 40
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Undefined variable: bitcoinprofile C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 41
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 41
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Undefined variable: bitcoinprofile C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 43
ERROR - 2016-12-20 06:40:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 43
ERROR - 2016-12-20 08:12:44 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 35
ERROR - 2016-12-20 08:12:44 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:13:30 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Resource\Account.php 50
ERROR - 2016-12-20 08:13:31 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 35
ERROR - 2016-12-20 08:13:31 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:15:26 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Resource\Account.php 50
ERROR - 2016-12-20 08:15:28 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 35
ERROR - 2016-12-20 08:15:28 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:16:42 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Resource\Account.php 50
ERROR - 2016-12-20 08:20:06 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:22:37 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:26:17 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:26:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 207
ERROR - 2016-12-20 08:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 207
ERROR - 2016-12-20 08:31:30 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 08:31:30 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 08:31:44 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:36:04 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:37:03 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:37:07 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:38:45 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:38:51 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:40:33 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:42:24 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 08:43:19 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 08:43:24 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 13:35:05 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 13:37:11 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 13:37:18 --> Severity: Notice --> Undefined variable: transactions C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 251
ERROR - 2016-12-20 14:06:39 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 230
ERROR - 2016-12-20 14:07:15 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 229
ERROR - 2016-12-20 14:07:15 --> Severity: Warning --> http_build_query(): Parameter 1 expected to be Array or Object.  Incorrect value given C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 230
ERROR - 2016-12-20 14:14:23 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 221
ERROR - 2016-12-20 14:14:23 --> Severity: 4096 --> Object of class Coinbase\Wallet\Resource\Account could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 222
ERROR - 2016-12-20 14:55:20 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 14:55:29 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 14:56:48 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 14:58:53 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:01:57 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:04:35 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:05:05 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:06:40 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:07:08 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:07:14 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:16:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:16:46 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:16:46 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:21:56 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting ']' C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 223
ERROR - 2016-12-20 15:22:38 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 15:22:43 --> Severity: 4096 --> Object of class Coinbase\Wallet\Value\Money could not be converted to string C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Value\Money.php 24
ERROR - 2016-12-20 15:22:44 --> Severity: error --> Exception: Required parameter missing: amount C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:23:14 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:24:10 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:26:16 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:26:57 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:27:35 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:28:23 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:28:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:28:44 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:30:16 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:30:33 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:32:11 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:41:03 --> Severity: error --> Exception: Not found C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 37
ERROR - 2016-12-20 15:46:05 --> Severity: Notice --> Undefined variable: transactions C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 237
ERROR - 2016-12-20 15:46:05 --> Severity: Notice --> Undefined variable: transactions C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 240
ERROR - 2016-12-20 15:47:20 --> Severity: Notice --> Undefined variable: transactions C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 240
ERROR - 2016-12-20 15:49:34 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:49:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:50:19 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 15:58:11 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:11 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:11 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:11 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 15:58:12 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 16:04:20 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 16:05:02 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 53
ERROR - 2016-12-20 16:05:43 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 21:51:39 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 445
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:51:40 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 446
ERROR - 2016-12-20 21:52:58 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 21:53:06 --> Severity: Error --> Cannot use object of type Coinbase\Wallet\Resource\Transaction as array C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 244
ERROR - 2016-12-20 21:53:58 --> Severity: Error --> Cannot use object of type Coinbase\Wallet\Resource\Transaction as array C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 244
ERROR - 2016-12-20 22:15:21 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 22:15:22 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 22:15:40 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 22:15:41 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 22:15:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:15:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:15:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:15:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:16:00 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:23 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:36 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:17:37 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:29:11 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must implement interface Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 22:29:11 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:58 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 22:31:59 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:44 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:03:45 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:07 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:08 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:08 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:04:08 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:04:08 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:08:26 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2016-12-20 23:08:26 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\snappycoin\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2016-12-20 23:08:56 --> Severity: Parsing Error --> syntax error, unexpected '$account' (T_VARIABLE), expecting ',' or ';' C:\xampp\htdocs\snappycoin\application\controllers\web\wallet.php 58
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:20 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:09:43 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 440
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:10:41 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:16:20 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 441
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:48 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:49 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:49 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:49 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:49 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:16:49 --> Severity: Notice --> Undefined index: network C:\xampp\htdocs\snappycoin\application\views\web\customer\wallet.php 447
ERROR - 2016-12-20 23:37:48 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:41:30 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:44:06 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:45:20 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:45:25 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:57:11 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:57:16 --> Severity: Error --> Cannot use object of type Coinbase\Wallet\Resource\Transaction as array C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 242
ERROR - 2016-12-20 23:59:06 --> Severity: Notice --> Undefined variable: newaddress C:\xampp\htdocs\snappycoin\application\views\web\pages\transferbitcoin.php 37
ERROR - 2016-12-20 23:59:16 --> Severity: Notice --> Undefined variable: transactionS C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 242
ERROR - 2016-12-20 23:59:16 --> Severity: Notice --> Undefined variable: transactionS C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 243
ERROR - 2016-12-20 23:59:16 --> Severity: Notice --> Undefined variable: bitcoinprofile C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 263
ERROR - 2016-12-20 23:59:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Sell.php 263
