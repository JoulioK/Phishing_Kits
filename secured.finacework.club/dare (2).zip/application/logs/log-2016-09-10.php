<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-10 00:20:00 --> 404 Page Not Found: web/Cart/index
ERROR - 2016-09-10 00:20:11 --> Severity: Error --> Call to undefined method Item::getvendoridbypackageid() C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 128
ERROR - 2016-09-10 00:20:33 --> Severity: Warning --> array_column() expects at least 2 parameters, 1 given C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 131
ERROR - 2016-09-10 00:22:20 --> Severity: Warning --> array_column() expects at least 2 parameters, 1 given C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 132
ERROR - 2016-09-10 00:22:57 --> Severity: Warning --> array_column() expects at least 2 parameters, 1 given C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 132
ERROR - 2016-09-10 00:35:15 --> Severity: Warning --> array_column() expects at least 2 parameters, 1 given C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 132
ERROR - 2016-09-10 00:55:23 --> Severity: Parsing Error --> syntax error, unexpected '$shippingtotalbatch' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 137
ERROR - 2016-09-10 00:55:36 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 142
ERROR - 2016-09-10 00:58:23 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 00:59:57 --> Severity: Notice --> Undefined variable: shippingtotal C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 104
ERROR - 2016-09-10 00:59:58 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 01:00:36 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 21:52:03 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:15:51 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:18:43 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:20:01 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:20:46 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:21:38 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:22:12 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:22:43 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:22:55 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:23:15 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:25:00 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:25:17 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:25:34 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:27:15 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:34:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 117
ERROR - 2016-09-10 22:54:13 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\views\web\pages\cart.php 146
ERROR - 2016-09-10 22:54:16 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:54:38 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:55:04 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:55:21 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:55:42 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:55:57 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:56:06 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:56:20 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:56:36 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:57:21 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:57:54 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 22:59:54 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 23:01:11 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-09-10 23:01:49 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-10 23:02:59 --> 404 Page Not Found: web/Customer/resources
ERROR - 2016-09-10 23:03:07 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:09:38 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:27:47 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:28:02 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:28:21 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:28:33 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:32:51 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:33:35 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:34:36 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:36:15 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:38:57 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:40:21 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:41:00 --> 404 Page Not Found: web/Settings/resources
ERROR - 2016-09-10 23:45:02 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-10 23:46:11 --> 404 Page Not Found: web/Resources/web
