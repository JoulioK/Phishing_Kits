<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-21 09:12:39 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 578
ERROR - 2016-08-21 09:12:39 --> Severity: Notice --> Undefined variable: unitids C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 591
ERROR - 2016-08-21 09:12:39 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 591
ERROR - 2016-08-21 09:12:39 --> Severity: Notice --> Undefined property: stdClass::$itemname C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 601
ERROR - 2016-08-21 09:12:39 --> Severity: Notice --> Undefined variable: echo C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 677
ERROR - 2016-08-21 10:40:50 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 584
ERROR - 2016-08-21 10:40:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 584
ERROR - 2016-08-21 10:40:51 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 585
ERROR - 2016-08-21 10:40:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 577
ERROR - 2016-08-21 10:47:02 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 585
ERROR - 2016-08-21 10:47:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 585
ERROR - 2016-08-21 10:47:02 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 10:47:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 577
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:46:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:47:44 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:47:51 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:47:53 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:48:08 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 11:48:51 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$qty C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$qty C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$itemid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$qty C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 586
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 587
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 594
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$qty C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 595
ERROR - 2016-08-21 12:29:25 --> Severity: Notice --> Undefined property: stdClass::$id C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 596
