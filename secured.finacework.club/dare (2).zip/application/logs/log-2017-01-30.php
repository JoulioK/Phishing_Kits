<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-30 02:32:25 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: SELECT `userid`
FROM `tbl_gh`
WHERE `ghid` = '14855146186692ku'
ORDER BY `tbl_ph`.`id` desc
ERROR - 2017-01-30 02:32:25 --> Query error: Unknown column 'ghid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485739945
WHERE `ghid` = '14855146186692ku'
AND `id` = '2e0a552ae9fd550c606fc080626cdb2bb005ff7b'
ORDER BY `tbl_ph`.`id` desc
ERROR - 2017-01-30 02:35:35 --> Query error: Unknown column 'tbl_ph.id' in 'order clause' - Invalid query: SELECT `userid`
FROM `tbl_gh`
WHERE `ghid` = '14855146186692ku'
ORDER BY `tbl_ph`.`id` desc
ERROR - 2017-01-30 02:35:35 --> Query error: Unknown column 'ghid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485740135
WHERE `ghid` = '14855146186692ku'
AND `id` = '2e0a552ae9fd550c606fc080626cdb2bb005ff7b'
ORDER BY `tbl_ph`.`id` desc
ERROR - 2017-01-30 03:55:34 --> Query error: Unknown column 'username' in 'field list' - Invalid query: INSERT INTO `tbl_testimonial` (`message`, `location`, `amount`, `datemodified`, `datecreated`, `userid`, `username`) VALUES ('PledgerHub gave me hope and life, thanks pledgers hub', 'Ibadan, Nigeria', '78', '2017-01-30 03:55:33', '2017-01-30 03:55:33', '14853742757197xj', '14853742757197xj')
ERROR - 2017-01-30 04:15:56 --> Severity: Notice --> Undefined variable: unread C:\xampp\htdocs\charity\application\views\web\_layouts\_customer_navigation.php 161
ERROR - 2017-01-30 07:09:28 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\controllers\web\Auth.php 18
ERROR - 2017-01-30 07:09:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `username`
FROM `tbl_users`
WHERE  IS NULL
ORDER BY `id` ASC
ERROR - 2017-01-30 07:09:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL
AND `id` = '6d8abaf4cae46c90ae0665c4b086335f13c19515'
ORDER BY `id` ASC' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485756569
WHERE  IS NULL
AND `id` = '6d8abaf4cae46c90ae0665c4b086335f13c19515'
ORDER BY `id` ASC
ERROR - 2017-01-30 08:03:40 --> 404 Page Not Found: web/Cabl/outgoing
ERROR - 2017-01-30 08:14:46 --> Query error: Unknown column 'earning' in 'field list' - Invalid query: SELECT `earning`
FROM `tbl_referral_earnings`
WHERE `userid` = '14853742757197xj'
ERROR - 2017-01-30 08:14:46 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485760486
WHERE `userid` = '14853742757197xj'
AND `id` = '6d8abaf4cae46c90ae0665c4b086335f13c19515'
ERROR - 2017-01-30 08:56:36 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\charity\application\models\web\Customer_model.php 90
ERROR - 2017-01-30 09:11:18 --> Severity: Notice --> Undefined property: stdClass::$bitcoinaddress C:\xampp\htdocs\charity\application\views\web\customer\profile.php 38
ERROR - 2017-01-30 09:11:38 --> Severity: Notice --> Undefined property: stdClass::$bitcoinaddress C:\xampp\htdocs\charity\application\views\web\customer\profile.php 38
ERROR - 2017-01-30 10:39:47 --> Severity: Notice --> Undefined variable: sponsor C:\xampp\htdocs\charity\application\views\web\authenticate\register.php 20
ERROR - 2017-01-30 10:44:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-30 11:12:11 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 185
ERROR - 2017-01-30 13:47:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-30 16:33:17 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-30 16:44:33 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 376
