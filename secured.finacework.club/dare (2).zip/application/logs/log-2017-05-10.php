<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-10 14:05:48 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\coinxtra\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\coinxtra\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2017-05-10 14:05:48 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\coinxtra\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2017-05-10 14:12:54 --> 404 Page Not Found: Btc/pay
ERROR - 2017-05-10 14:14:05 --> Severity: Notice --> Undefined index: social C:\xampp\htdocs\coinxtra\application\controllers\web\User.php 50
ERROR - 2017-05-10 14:52:09 --> Severity: Notice --> Undefined property: stdClass::$identityconfirmed C:\xampp\htdocs\coinxtra\application\views\web\customer\identity.php 164
ERROR - 2017-05-10 14:52:09 --> Severity: Notice --> Undefined property: stdClass::$identityconfirmed C:\xampp\htdocs\coinxtra\application\views\web\customer\identity.php 171
