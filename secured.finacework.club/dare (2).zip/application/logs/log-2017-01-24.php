<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-24 00:12:13 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\charity\application\views\web\authenticate\forgot.php 14
ERROR - 2017-01-24 00:12:13 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\charity\application\views\web\authenticate\forgot.php 15
ERROR - 2017-01-24 00:12:13 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\charity\application\views\web\authenticate\forgot.php 17
ERROR - 2017-01-24 00:12:13 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\charity\application\views\web\authenticate\forgot.php 17
ERROR - 2017-01-24 11:24:40 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 183
