<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-04 11:33:21 --> Query error: Table 'helpcabal.ci_sessions' doesn't exist - Invalid query: SELECT `data`
FROM `ci_sessions`
WHERE `id` = '880200443b544244e03ed68c89673b182411cb4e'
