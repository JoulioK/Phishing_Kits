<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 36
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 36
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 61
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 93
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 93
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 93
ERROR - 2016-12-11 04:41:20 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders_summary.php 93
ERROR - 2016-12-11 04:44:27 --> Severity: Notice --> Undefined variable: month C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income_summary.php 54
ERROR - 2016-12-11 04:44:27 --> Severity: Notice --> Undefined variable: year C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income_summary.php 54
ERROR - 2016-12-11 04:44:27 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income_summary.php 73
ERROR - 2016-12-11 04:46:26 --> Severity: Notice --> Undefined variable: commision C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income_summary.php 85
ERROR - 2016-12-11 04:48:56 --> Severity: Notice --> Undefined property: Franchisereport::$vendorid C:\xampp\htdocs\snappycoin\application\controllers\management\Franchisereport.php 147
ERROR - 2016-12-11 04:49:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\vendor\reports\income.php 109
ERROR - 2016-12-11 04:51:45 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 19
ERROR - 2016-12-11 04:51:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 19
ERROR - 2016-12-11 04:52:20 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 19
ERROR - 2016-12-11 04:52:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 19
ERROR - 2016-12-11 04:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income.php 109
ERROR - 2016-12-11 04:53:27 --> Severity: Notice --> Undefined variable: commision C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\income_summary.php 85
ERROR - 2016-12-11 08:12:15 --> Unable to load the requested class: Curl
ERROR - 2016-12-11 08:28:40 --> Severity: Warning --> file_get_contents(): SSL: The operation completed successfully.
 C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 82
ERROR - 2016-12-11 08:28:40 --> Severity: Warning --> file_get_contents(https://block.io/api/v2/get_address_balance/?api_key=3c48-1ae0-0524-ab80&amp;addresses=1BH1tVpmzGbNBvchoPQPx4XwiCAGDhUugg): failed to open stream: HTTP request failed!  C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 82
ERROR - 2016-12-11 08:28:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 88
ERROR - 2016-12-11 08:32:00 --> Severity: Notice --> Undefined property: stdClass::$available_balance C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 85
ERROR - 2016-12-11 08:33:15 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 85
ERROR - 2016-12-11 08:44:10 --> Severity: Parsing Error --> syntax error, unexpected '3' (T_LNUMBER), expecting variable (T_VARIABLE) or '$' C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 97
ERROR - 2016-12-11 08:45:41 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 85
ERROR - 2016-12-11 08:45:41 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 89
ERROR - 2016-12-11 08:45:43 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 85
ERROR - 2016-12-11 08:45:43 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 89
ERROR - 2016-12-11 08:46:14 --> Severity: Notice --> Undefined index: label C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 96
ERROR - 2016-12-11 12:52:28 --> Severity: error --> Exception: GMP extension seems not to be installed C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 8
ERROR - 2016-12-11 12:52:29 --> Severity: error --> Exception: GMP extension seems not to be installed C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 8
ERROR - 2016-12-11 12:53:28 --> Severity: error --> Exception: Needed .pem file not found. Please download the .pem file at http://curl.haxx.se/ca/cacert.pem and save it as C:\xampp\htdocs\snappycoin\application\libraries\cacert.pem C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 78
ERROR - 2016-12-11 17:13:55 --> Severity: Parsing Error --> syntax error, unexpected 'redirect' (T_STRING) C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 75
ERROR - 2016-12-11 17:22:05 --> Severity: Parsing Error --> syntax error, unexpected 'redirect' (T_STRING) C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 75
ERROR - 2016-12-11 17:57:53 --> Severity: error --> Exception: Failed: Cannot withdraw funds without Network Fee of 0.00000 BTC. Maximum withdrawable balance is 0.00000 BTC. C:\xampp\htdocs\snappycoin\application\libraries\BlockIo.php 96
