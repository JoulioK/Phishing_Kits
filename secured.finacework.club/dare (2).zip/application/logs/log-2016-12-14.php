<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-14 10:19:27 --> Severity: Notice --> Undefined variable: earnings C:\xampp\htdocs\snappycoin\application\views\web\customer\referral.php 19
ERROR - 2016-12-14 10:21:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Referral.php 21
ERROR - 2016-12-14 12:03:16 --> 404 Page Not Found: web/Referral/cashout
ERROR - 2016-12-14 14:27:07 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\snappycoin\application\controllers\web\Referral.php 63
ERROR - 2016-12-14 14:27:39 --> Severity: Notice --> Undefined variable: bankid C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 51
ERROR - 2016-12-14 14:27:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 14:27:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Referral.php 52
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 36
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 36
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 42
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 42
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 49
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 49
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 56
ERROR - 2016-12-14 14:27:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 56
ERROR - 2016-12-14 14:33:36 --> Severity: Notice --> Undefined variable: bankid C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 51
ERROR - 2016-12-14 14:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 14:33:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Referral.php 52
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 25
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 36
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 36
ERROR - 2016-12-14 14:33:39 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 42
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 42
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 48
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 49
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 49
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 56
ERROR - 2016-12-14 14:33:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\customer\cashout.php 56
ERROR - 2016-12-14 14:35:25 --> Severity: Notice --> Undefined variable: bankid C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 51
ERROR - 2016-12-14 14:35:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 14:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 14:37:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 15:23:00 --> Query error: Unknown column 'earning' in 'field list' - Invalid query: SELECT sum(earning) as amount
FROM `tbl_referral_earnings`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-14 15:23:00 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1481725380
WHERE `userid` = '14675775313398tp'
AND `id` = 'fa2876e7d9cca7a383e0db64edfa13c52d6e5c4c'
ERROR - 2016-12-14 16:09:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 16:09:14 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\snappycoin\application\controllers\web\Referral.php 60
ERROR - 2016-12-14 16:09:14 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO `tbl_banks` () VALUES ('')
ERROR - 2016-12-14 16:11:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 53
ERROR - 2016-12-14 16:11:41 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', NULL, '14817283018705ol')
ERROR - 2016-12-14 16:15:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-14 16:15:44 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', NULL, '14817285449990iv')
ERROR - 2016-12-14 16:23:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\models\web\Settings_model.php 45
ERROR - 2016-12-14 16:23:19 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', NULL, '14817289995928id')
ERROR - 2016-12-14 16:26:07 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817291670496vy')
ERROR - 2016-12-14 16:29:21 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817293611935vg')
ERROR - 2016-12-14 16:33:16 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817295965514uw', '2016-12-14 16:33:16', '2016-12-14 16:33:16')
ERROR - 2016-12-14 16:33:53 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817296337625pk', '2016-12-14 16:33:53', '2016-12-14 16:33:53')
ERROR - 2016-12-14 16:34:45 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817296855981ba', '2016-12-14 16:34:45', '2016-12-14 16:34:45')
ERROR - 2016-12-14 16:35:47 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817297476019br', '2016-12-14 16:35:47', '2016-12-14 16:35:47')
ERROR - 2016-12-14 16:35:51 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817297516455xo', '2016-12-14 16:35:51', '2016-12-14 16:35:51')
ERROR - 2016-12-14 16:36:44 --> Query error: Unknown column 'userid' in 'field list' - Invalid query: INSERT INTO `tbl_banks` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817298042643hl', '2016-12-14 16:36:44', '2016-12-14 16:36:44')
ERROR - 2016-12-14 16:37:58 --> Query error: Unknown column 'recorid' in 'field list' - Invalid query: INSERT INTO `tbl_earning_history` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817298784759ia', '2016-12-14 16:37:58', '2016-12-14 16:37:58')
ERROR - 2016-12-14 16:42:41 --> Query error: Unknown column 'recorid' in 'field list' - Invalid query: INSERT INTO `tbl_earning_history` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817301613178ac', '2016-12-14 16:42:41', '2016-12-14 16:42:41')
ERROR - 2016-12-14 16:42:56 --> Query error: Unknown column 'recorid' in 'field list' - Invalid query: INSERT INTO `tbl_earning_history` (`userid`, `accountname`, `accountnumber`, `bankname`, `recorid`, `datecreated`, `datemodified`) VALUES ('14675775313398tp', 'Olalekan Fashade', '0130360398', 'GTBANK', '14817301761382gf', '2016-12-14 16:42:56', '2016-12-14 16:42:56')
ERROR - 2016-12-14 16:48:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '14675775313398tp'' at line 2 - Invalid query: UPDATE `tbl_earning_history` SET `earning` = 0
WHERE  = '14675775313398tp'
ERROR - 2016-12-14 19:41:04 --> Severity: Notice --> Undefined variable: fields_string C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 318
ERROR - 2016-12-14 19:41:05 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 326
ERROR - 2016-12-14 19:43:02 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 326
ERROR - 2016-12-14 19:54:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 335
ERROR - 2016-12-14 19:54:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 357
