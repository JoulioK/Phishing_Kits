<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-04 00:02:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `franchiseid` = '2626273373'' at line 2 - Invalid query: SELECT `sliderurl`, `tbl_franchise_sliders`
WHERE `franchiseid` = '2626273373'
ERROR - 2016-08-04 00:02:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `franchiseid` = '2626273373'' at line 2 - Invalid query: SELECT `sliderurl`, `tbl_franchise_sliders`
WHERE `franchiseid` = '2626273373'
ERROR - 2016-08-04 00:02:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 15
ERROR - 2016-08-04 00:02:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 16
ERROR - 2016-08-04 00:02:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 17
ERROR - 2016-08-04 00:04:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `franchiseid` = '2626273373'' at line 2 - Invalid query: SELECT `sliderurl`, `tbl_franchise_sliders`
WHERE `franchiseid` = '2626273373'
ERROR - 2016-08-04 00:05:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `franchiseid` = '2626273373'' at line 2 - Invalid query: SELECT `sliderurl`, `tbl_franchise_sliders`
WHERE `franchiseid` = '2626273373'
ERROR - 2016-08-04 00:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 15
ERROR - 2016-08-04 00:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 16
ERROR - 2016-08-04 00:05:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 17
ERROR - 2016-08-04 12:04:04 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:04:04 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:04:04 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 84
ERROR - 2016-08-04 12:04:05 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:04:05 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:04:05 --> Severity: Error --> Call to undefined method stdClass::get() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 90
ERROR - 2016-08-04 12:04:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 81
ERROR - 2016-08-04 12:04:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:04:16 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 84
ERROR - 2016-08-04 12:04:16 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:04:16 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:04:16 --> Severity: Error --> Call to undefined method stdClass::get() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 90
ERROR - 2016-08-04 12:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 81
ERROR - 2016-08-04 12:07:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:07:32 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:07:32 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:07:32 --> Severity: Error --> Cannot access protected property Orders_model::$_ordey_by C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 89
ERROR - 2016-08-04 12:09:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:09:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 81
ERROR - 2016-08-04 12:09:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:09:43 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:09:43 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:09:50 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:09:50 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:09:50 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:09:50 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:14:49 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:14:49 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:14:49 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:14:49 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:21:33 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:21:33 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:21:33 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:22:25 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:22:25 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:22:25 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:23:01 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:23:01 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:25:50 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:25:50 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 86
ERROR - 2016-08-04 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 106
ERROR - 2016-08-04 12:26:30 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 115
ERROR - 2016-08-04 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 115
ERROR - 2016-08-04 12:26:30 --> Severity: Error --> Call to undefined method Vendors::getunit() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 125
ERROR - 2016-08-04 12:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 12:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 81
ERROR - 2016-08-04 12:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 82
ERROR - 2016-08-04 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 105
ERROR - 2016-08-04 12:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 114
ERROR - 2016-08-04 12:28:00 --> Severity: Error --> Call to undefined method Vendors::getunit() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 124
ERROR - 2016-08-04 12:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 105
ERROR - 2016-08-04 12:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 113
ERROR - 2016-08-04 12:29:56 --> Severity: Error --> Call to undefined method Vendors::getunit() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 124
ERROR - 2016-08-04 12:32:44 --> Severity: Error --> Call to undefined method Vendors::getunit() C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 122
ERROR - 2016-08-04 12:35:46 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 136
ERROR - 2016-08-04 12:35:46 --> Severity: Notice --> Undefined variable: itemvendor C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 136
ERROR - 2016-08-04 14:04:56 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 165
ERROR - 2016-08-04 14:05:01 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 165
ERROR - 2016-08-04 14:12:52 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 165
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 78
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 80
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 173
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 174
ERROR - 2016-08-04 14:18:45 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 14:18:57 --> Severity: Notice --> Undefined property: Vendors::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 154
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:35:43 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 31
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:35:43 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:35:43 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:35:43 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:35:43 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 31
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:29 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:29 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:48 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 31
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:48 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:48 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:48 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:36:49 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 26
ERROR - 2016-08-04 20:36:49 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:36:49 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 29
ERROR - 2016-08-04 20:37:52 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 32
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:37:53 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:38:04 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:38:04 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 32
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryname C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 27
ERROR - 2016-08-04 20:38:05 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 28
ERROR - 2016-08-04 20:39:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 32
ERROR - 2016-08-04 21:34:54 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 60
ERROR - 2016-08-04 21:34:54 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 62
ERROR - 2016-08-04 21:35:41 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 60
ERROR - 2016-08-04 21:35:41 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 62
ERROR - 2016-08-04 21:35:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 55
ERROR - 2016-08-04 21:35:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 57
ERROR - 2016-08-04 21:35:45 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 60
ERROR - 2016-08-04 21:35:45 --> Severity: Error --> Call to undefined method stdClass::get() C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 74
ERROR - 2016-08-04 21:36:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 56
ERROR - 2016-08-04 21:36:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 58
ERROR - 2016-08-04 21:36:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:36:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:36:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:36:25 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:36:25 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:36:25 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 147
ERROR - 2016-08-04 21:37:21 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 148
ERROR - 2016-08-04 21:37:21 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 148
ERROR - 2016-08-04 21:37:21 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 148
ERROR - 2016-08-04 21:48:25 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:25 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:25 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:25 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:27 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:27 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:27 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:27 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:28 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:28 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:28 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:28 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:29 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:29 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:29 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:29 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:31 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:31 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:31 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:31 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:32 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:32 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:32 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:32 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:36 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:36 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:36 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:36 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:48:37 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:48:37 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:48:37 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:48:37 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:49:45 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:49:46 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:49:46 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:49:46 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:49:48 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 77
ERROR - 2016-08-04 21:49:48 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 79
ERROR - 2016-08-04 21:49:49 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-04 21:49:49 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-04 21:52:24 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 158
ERROR - 2016-08-04 21:52:28 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 158
ERROR - 2016-08-04 21:53:57 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 158
ERROR - 2016-08-04 21:56:08 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 158
ERROR - 2016-08-04 21:56:12 --> Severity: Notice --> Undefined variable: dcategories C:\xampp\htdocs\fastfood\application\controllers\app\categories.php 158
