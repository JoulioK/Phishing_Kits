<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-19 00:07:18 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\charity\application\views\web\customer\outgoing.php 69
ERROR - 2017-02-19 00:08:46 --> Severity: Notice --> Undefined property: Cabal::$pagination C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 397
ERROR - 2017-02-19 00:08:46 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 397
ERROR - 2017-02-19 02:09:06 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487466546
WHERE `tbl_gh`.`userid` != '14853946163915jw'
AND `tbl_gh`.`userid` != '14853825878672yc'
AND tbl_gh.amount between '0.0625' AND '0.25'
AND `tbl_users`.`isguilder` =0
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5' LIMIT 1
ERROR - 2017-02-19 02:09:21 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487466561
WHERE `tbl_gh`.`userid` != '14853946163915jw'
AND `tbl_gh`.`userid` != '14853825878672yc'
AND tbl_gh.amount between '0.0625' AND '0.25'
AND `tbl_users`.`isguilder` =0
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5' LIMIT 1
ERROR - 2017-02-19 02:11:01 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487466661
WHERE `tbl_gh`.`userid` != '14853946163915jw'
AND `tbl_gh`.`userid` != '14853825878672yc'
AND tbl_gh.amount between '0.0625' AND '0.25'
AND `tbl_users`.`isguilder` =0
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5' LIMIT 1
ERROR - 2017-02-19 02:12:30 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487466750
WHERE `tbl_gh`.`userid` != '14853946163915jw'
AND `tbl_gh`.`userid` != '14853825878672yc'
AND tbl_gh.amount between '0.0625' AND '0.25'
AND `tbl_users`.`isguilder` =0
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5' LIMIT 1
ERROR - 2017-02-19 02:13:00 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487466780
WHERE `tbl_gh`.`userid` != '14853946163915jw'
AND `tbl_gh`.`userid` != '14853825878672yc'
AND tbl_gh.amount between '0.0625' AND '0.25'
AND `tbl_users`.`isguilder` =0
AND `id` = 'aa156e3495555d591b93c8e5c467428f2f3235a5' LIMIT 1
ERROR - 2017-02-19 02:45:41 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\charity\application\views\web\customer\ph.php 157
ERROR - 2017-02-19 02:51:22 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\views\web\customer\ph.php 209
ERROR - 2017-02-19 10:49:30 --> 404 Page Not Found: management/Js/classie.js
