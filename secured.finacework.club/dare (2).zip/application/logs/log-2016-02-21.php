<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-21 10:58:56 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 10:59:06 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 10:59:07 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 10:59:13 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 10:59:13 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 10:59:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 10:59:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 10:59:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 10:59:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 10:59:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:00:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:00:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:02:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:02:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:05:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:28:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:29:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:30:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 43
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 43
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_history_page.php 79
ERROR - 2016-02-21 11:34:06 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:34:07 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:34:46 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:34:46 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:36:59 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:37:15 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:37:16 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 11:48:02 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 11:48:03 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 11:48:03 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 11:48:03 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 11:48:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 11:48:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 11:48:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 11:48:24 --> Severity: Warning --> Missing argument 1 for MY_Model::delete(), called in C:\xampp\htdocs\estore\application\controllers\Store\Sales.php on line 170 and defined C:\xampp\htdocs\estore\application\core\MY_Model.php 76
ERROR - 2016-02-21 11:48:24 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\estore\application\core\MY_Model.php 78
ERROR - 2016-02-21 11:48:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:48:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:49:16 --> Severity: Warning --> Missing argument 1 for MY_Model::delete(), called in C:\xampp\htdocs\estore\application\controllers\Store\Sales.php on line 170 and defined C:\xampp\htdocs\estore\application\core\MY_Model.php 76
ERROR - 2016-02-21 11:49:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\estore\application\core\MY_Model.php 78
ERROR - 2016-02-21 11:49:53 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:50:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:50:23 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:50:23 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 11:52:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 11:52:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 11:55:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:09:56 --> Severity: Notice --> Undefined index: 4608119329 C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_summary_page.php 56
ERROR - 2016-02-21 12:09:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:10:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:10:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:11:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:11:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:11:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:11:13 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:11:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:11:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:11:31 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:13:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:16:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:17:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:18:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:19:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:19:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:19:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:19:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:20:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:20:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:21:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:27:36 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 139
ERROR - 2016-02-21 12:28:09 --> Severity: Compile Error --> Can't use method return value in write context C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 143
ERROR - 2016-02-21 12:29:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:29:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:29:12 --> Severity: Error --> Call to undefined method CI_Session::user_data() C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 139
ERROR - 2016-02-21 12:29:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:29:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:29:38 --> 404 Page Not Found: Store/Store/Sales
ERROR - 2016-02-21 12:30:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:30:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:30:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:30:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:30:41 --> Severity: Error --> Call to undefined method CI_Session::user_data() C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 3
ERROR - 2016-02-21 12:30:41 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:30:58 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:30:59 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:38:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 30
ERROR - 2016-02-21 12:38:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 33
ERROR - 2016-02-21 12:38:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 36
ERROR - 2016-02-21 12:38:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 39
ERROR - 2016-02-21 12:38:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Sales\Sales_receipt_page.php 40
ERROR - 2016-02-21 12:44:38 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:44:38 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:44:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:44:46 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:44:46 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:44:47 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:44:47 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:44:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:44:47 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:44:47 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:44:50 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:44:51 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:44:54 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:44:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:44:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:45:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:45:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:45:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:46:33 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:46:33 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:46:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:46:34 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:47:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:47:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:48:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:48:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 12:48:57 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:48:57 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:48:57 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:48:57 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:48:57 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:48:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:48:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:48:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:48:58 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:48:58 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:52:47 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:52:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 12:53:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:53:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:54:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:54:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:55 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:55:55 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:55:55 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:55:55 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:55:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:55:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:55:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:55:58 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:55:58 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:56:17 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:56:17 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:56:17 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:56:18 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:56:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:56:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:56:20 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:56:21 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:56:21 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:56:21 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:56:45 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:56:45 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:56:45 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:56:45 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:56:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:56:48 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:56:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:56:48 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:56:48 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:56:48 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:57:00 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:57:00 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:57:00 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:57:00 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:57:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:57:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:57:02 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:57:02 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:57:03 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:57:03 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:57:28 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:57:28 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:57:28 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:57:28 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:57:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:57:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:57:31 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:57:31 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:57:31 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:57:31 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:59:29 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:59:29 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:59:30 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:59:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:30 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:59:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:31 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:59:31 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:59:32 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:59:32 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:59:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:52 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:59:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:52 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:59:52 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 12:59:52 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:59:53 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 12:59:53 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 12:59:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 12:59:53 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 12:59:53 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:00:07 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:00:07 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 13:00:07 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:00:07 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 13:00:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:00:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:00:08 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 13:00:08 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 13:00:09 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:00:09 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:00:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:00:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:01:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:01:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:02:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:03:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:03:26 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:03:32 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:03:32 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:04:19 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:04:20 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:04:52 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:07:03 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:07:03 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:07:03 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 13:07:03 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 13:07:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:07:05 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 13:07:05 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 13:07:05 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 13:07:05 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 13:07:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:07:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:07:36 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:07:38 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:07:55 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:07:58 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:08:09 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:08:11 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 13:08:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 13:08:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:01:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:01:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:01:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:01:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:09:27 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;pk_t_users&quot; already exists C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 14:09:27 --> Query error: ERROR:  relation "pk_t_users" already exists - Invalid query: CREATE TABLE "t_users" (
	"id" SERIAL NOT NULL,
	"storeid" VARCHAR(10) NOT NULL,
	"user_id" VARCHAR(10) NULL,
	"user_name" VARCHAR(200) NOT NULL,
	"user_password" TEXT NOT NULL,
	"user_fullname" VARCHAR(200) NOT NULL,
	"user_phone_number" VARCHAR(200) NOT NULL,
	"user_email" VARCHAR(200) NOT NULL,
	"user_address" TEXT NOT NULL,
	"user_status" INT NOT NULL,
	"user_privilege" TEXT NOT NULL,
	"added_by" VARCHAR(10) NOT NULL,
	datecreated timestamp default now(),
	datemodified timestamp default now(),
	CONSTRAINT "pk_t_users" PRIMARY KEY("id")
)
ERROR - 2016-02-21 14:10:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:13:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:13:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:13:30 --> Severity: Notice --> Undefined property: Users::$Users_Model C:\xampp\htdocs\estore\application\controllers\Store\Users.php 26
ERROR - 2016-02-21 14:13:30 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Users.php 26
ERROR - 2016-02-21 14:15:07 --> Severity: Notice --> Undefined property: stdClass::$user_name C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 30
ERROR - 2016-02-21 14:15:07 --> Severity: Notice --> Undefined property: stdClass::$user_description C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 34
ERROR - 2016-02-21 14:15:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:15:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:19:54 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 40
ERROR - 2016-02-21 14:19:54 --> Severity: Notice --> Undefined property: stdClass::$user_name C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 45
ERROR - 2016-02-21 14:19:54 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:19:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:20:34 --> Severity: Notice --> Undefined property: stdClass::$user_name C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 45
ERROR - 2016-02-21 14:20:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:20:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:21:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:21:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:23:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:24:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:24:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:24:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:24:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:25:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:25:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:25:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:25:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:28:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:28:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:28:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:28:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:41:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:42:53 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:43:15 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;stock_id&quot; does not exist
LINE 3: WHERE &quot;stock_id&quot; = '7022106262'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 14:43:15 --> Query error: ERROR:  column "stock_id" does not exist
LINE 3: WHERE "stock_id" = '7022106262'
              ^ - Invalid query: SELECT *
FROM "t_store_users"
WHERE "stock_id" = '7022106262'
AND "t_store_users"."storeid" = '1111111111'
ORDER BY "t_store_users"."id" ASC
ERROR - 2016-02-21 14:47:42 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;user_id&quot; does not exist
LINE 3: WHERE &quot;user_id&quot; = '8415458468'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 14:47:42 --> Query error: ERROR:  column "user_id" does not exist
LINE 3: WHERE "user_id" = '8415458468'
              ^ - Invalid query: SELECT *
FROM "t_store_users"
WHERE "user_id" = '8415458468'
AND "t_store_users"."storeid" = '1111111111'
ORDER BY "t_store_users"."id" ASC
ERROR - 2016-02-21 14:50:07 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;privilege&quot; of relation &quot;t_store_users&quot; does not exist
LINE 1: ...name&quot;, &quot;email_address&quot;, &quot;phone_number&quot;, &quot;status&quot;, &quot;privilege...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 14:50:07 --> Query error: ERROR:  column "privilege" of relation "t_store_users" does not exist
LINE 1: ...name", "email_address", "phone_number", "status", "privilege...
                                                             ^ - Invalid query: INSERT INTO "t_store_users" ("username", "password", "fullname", "email_address", "phone_number", "status", "privilege", "storeid", "added_by", "uniqueid") VALUES ('ogechi', '9b919e5a59ef56a40bb06d836c96b77da6c2ae463fbd6b02515f70e3a50919781d4f8c77e54c4fc536efc1464f4571cfda945448067201b5db9b9c4b03bd2cf1', 'ogechi', 'fash@fash.com', '08037667193', '1', 'sales,stock_taking,reporting,updating,deleting', '1111111111', '2222222222', '1077590396')
ERROR - 2016-02-21 14:50:26 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;added_by&quot; of relation &quot;t_store_users&quot; does not exist
LINE 1: ...phone_number&quot;, &quot;status&quot;, &quot;privileges&quot;, &quot;storeid&quot;, &quot;added_by&quot;...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 14:50:26 --> Query error: ERROR:  column "added_by" of relation "t_store_users" does not exist
LINE 1: ...phone_number", "status", "privileges", "storeid", "added_by"...
                                                             ^ - Invalid query: INSERT INTO "t_store_users" ("username", "password", "fullname", "email_address", "phone_number", "status", "privileges", "storeid", "added_by", "uniqueid") VALUES ('ogechi', '9b919e5a59ef56a40bb06d836c96b77da6c2ae463fbd6b02515f70e3a50919781d4f8c77e54c4fc536efc1464f4571cfda945448067201b5db9b9c4b03bd2cf1', 'ogechi', 'fash@fash.com', '08037667193', '1', 'sales,stock_taking,reporting,updating,deleting', '1111111111', '2222222222', '4688223829')
ERROR - 2016-02-21 14:54:38 --> Severity: Notice --> Undefined property: Users::$db_forge C:\xampp\htdocs\estore\system\libraries\Migration.php 443
ERROR - 2016-02-21 14:54:38 --> Severity: Error --> Call to a member function add_column() on null C:\xampp\htdocs\estore\application\migrations\009_Modify_Users_Table.php 8
ERROR - 2016-02-21 14:56:20 --> Severity: Notice --> Undefined property: Users::$db_forge C:\xampp\htdocs\estore\system\libraries\Migration.php 443
ERROR - 2016-02-21 14:56:20 --> Severity: Error --> Call to a member function add_column() on null C:\xampp\htdocs\estore\application\migrations\009_Modify_Users_Table.php 11
ERROR - 2016-02-21 14:56:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 14:56:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:01:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:01:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_description C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 111
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_category_name C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 114
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 117
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 118
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_description C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 111
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_category_name C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 114
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 117
ERROR - 2016-02-21 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$user_id C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 118
ERROR - 2016-02-21 15:01:27 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:01:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$uniquekey C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 123
ERROR - 2016-02-21 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$uniquekey C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 124
ERROR - 2016-02-21 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$uniquekey C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 123
ERROR - 2016-02-21 15:02:57 --> Severity: Notice --> Undefined property: stdClass::$uniquekey C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 124
ERROR - 2016-02-21 15:02:57 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:02:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:03:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:03:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:03:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:03:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:06:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:06:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:06:16 --> 404 Page Not Found: Store/Users/2
ERROR - 2016-02-21 15:06:35 --> 404 Page Not Found: Store/Users/Index2
ERROR - 2016-02-21 15:06:51 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;user_id&quot; does not exist
LINE 4: AND &quot;user_id&quot; = '2222222222'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:06:51 --> Query error: ERROR:  column "user_id" does not exist
LINE 4: AND "user_id" = '2222222222'
            ^ - Invalid query: SELECT *
FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "user_id" = '2222222222'
AND "id" = '1'
AND "t_store_users"."storeid" = '1111111111'
ORDER BY "t_store_users"."id" ASC
ERROR - 2016-02-21 15:07:07 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:07:07 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:07:09 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:07:09 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:07:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:07:36 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:08:34 --> Severity: Notice --> Use of undefined constant existingUsers - assumed 'existingUsers' C:\xampp\htdocs\estore\application\controllers\Store\Users.php 91
ERROR - 2016-02-21 15:08:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:09:03 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:09:04 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:10:05 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:10:05 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:10:06 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:10:06 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:10:18 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:10:18 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:10:19 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:10:19 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:10:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\estore\application\controllers\Store\Users.php 298
ERROR - 2016-02-21 15:10:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:10:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:14:55 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:14:55 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 2
ERROR - 2016-02-21 15:16:55 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:16:55 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 2
ERROR - 2016-02-21 15:16:56 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:16:56 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 2
ERROR - 2016-02-21 15:17:02 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 49
ERROR - 2016-02-21 15:17:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:25:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:25:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:25:40 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 50
ERROR - 2016-02-21 15:25:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:25:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:26:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:26:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:26:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:26:31 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:26:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:26:46 --> Severity: Notice --> Undefined property: stdClass::$privilege C:\xampp\htdocs\estore\application\views\Store\Users\User_page.php 50
ERROR - 2016-02-21 15:26:47 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:26:47 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:27:02 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:27:02 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:27:04 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:27:04 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:28:02 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) C:\xampp\htdocs\estore\application\controllers\Store\Users.php 298
ERROR - 2016-02-21 15:28:35 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:28:37 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:31:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:31:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:31:11 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:31:17 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:32:40 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:32:42 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:33:03 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:33:03 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:36:35 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:36:37 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:37:04 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:37:20 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:37:20 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:38:08 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:38:10 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:38:39 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:38:39 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:38:57 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:39:00 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:39:17 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:39:19 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:39:55 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:39:55 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:41:31 --> Severity: Notice --> Undefined variable: pasword C:\xampp\htdocs\estore\application\models\Store\Store_User_Model.php 59
ERROR - 2016-02-21 15:42:35 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:42:41 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:42:41 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:43:17 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:44:14 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:44:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 15:44:42 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:44:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:44:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:44:58 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:44:58 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:45:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:45:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:45:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:45:36 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:45:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:46:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:46:36 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:48:00 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:48:00 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:48:08 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:48:08 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:48:19 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:48:19 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:48:25 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:48:25 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:49:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniquekey&quot; does not exist
LINE 3: AND &quot;uniquekey&quot; = 'images'
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 15:49:31 --> Query error: ERROR:  column "uniquekey" does not exist
LINE 3: AND "uniquekey" = 'images'
            ^ - Invalid query: DELETE FROM "t_store_users"
WHERE "storeid" = '1111111111'
AND "uniquekey" = 'images'
AND "id" = 1
ERROR - 2016-02-21 15:50:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:50:14 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:50:21 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:50:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:50:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:52:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:52:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:53:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:53:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 15:53:33 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 15:54:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:57:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:58:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 15:58:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 15:59:07 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 15:59:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 15:59:13 --> 404 Page Not Found: Reports/Stock_Summary
ERROR - 2016-02-21 15:59:33 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 15:59:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 15:59:43 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 15:59:43 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 15:59:59 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:00:01 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:02:01 --> Severity: Error --> Call to undefined method Reports::getStockTakingData() C:\xampp\htdocs\estore\application\controllers\Store\Reports.php 107
ERROR - 2016-02-21 16:02:12 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:02:13 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:05:28 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:05:28 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:06:31 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:06:51 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:06:51 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:06:59 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:08:05 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:08:07 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 16:08:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 16:09:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 16:09:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 16:09:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 16:09:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 16:10:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:10:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:10:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:10:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:10:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:10:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:11:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:11:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:11:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:12:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:12:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 16:12:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:12:25 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:12:47 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:12:48 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:16 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:17 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:20 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:24 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:26 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:27 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:55 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:13:57 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:14:22 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:14:24 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:14:27 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:16:09 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:16:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:16:32 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:17:27 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 16:17:27 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 20:07:48 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 20:07:55 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:07:55 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:07:55 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:07:55 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:07:55 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:07:56 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:07:56 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:07:59 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:08:06 --> 404 Page Not Found: Store/Reports/Sales
ERROR - 2016-02-21 20:09:52 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:09:56 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:10:38 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:10:41 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:10:47 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:10:47 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:12:09 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:12:18 --> 404 Page Not Found: Store/Reports/Sales
ERROR - 2016-02-21 20:12:42 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:12:44 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:13:16 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:13:16 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:13:40 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:17:39 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;1111111111&quot; does not exist
LINE 5:             WHERE t_sales.storeid = &quot;1111111111&quot;
                                            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 20:17:39 --> Query error: ERROR:  column "1111111111" does not exist
LINE 5:             WHERE t_sales.storeid = "1111111111"
                                            ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            INNER JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = "1111111111"
            GROUP BY t_sales.stock_id,t_stocks.stock_name
ERROR - 2016-02-21 20:17:44 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;1111111111&quot; does not exist
LINE 5:             WHERE t_sales.storeid = &quot;1111111111&quot;
                                            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 20:17:44 --> Query error: ERROR:  column "1111111111" does not exist
LINE 5:             WHERE t_sales.storeid = "1111111111"
                                            ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            INNER JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = "1111111111"
            GROUP BY t_sales.stock_id,t_stocks.stock_name
ERROR - 2016-02-21 20:18:14 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:20:40 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;STOCK_LEDGER.stock_current_price&quot; must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: ...ales.stock_qty) as total_sold,t_stocks.stock_name,&quot;STOCK_LED...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 20:20:40 --> Query error: ERROR:  column "STOCK_LEDGER.stock_current_price" must appear in the GROUP BY clause or be used in an aggregate function
LINE 1: ...ales.stock_qty) as total_sold,t_stocks.stock_name,"STOCK_LED...
                                                             ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name,"STOCK_LEDGER".stock_current_price as stock_price
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            LEFT JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = '1111111111'
            GROUP BY t_sales.stock_id,t_stocks.stock_name
ERROR - 2016-02-21 20:21:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:21:42 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:21:44 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:23:29 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:23:29 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:02 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:04 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:32 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:34 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:55 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\estore\application\views\Store\Reports\Sales_summary_page.php 53
ERROR - 2016-02-21 20:24:55 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:24:56 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:25:04 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:25:04 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:26:34 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Store\Reports\Sales_summary_page.php 59
ERROR - 2016-02-21 20:26:34 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Store\Reports\Sales_summary_page.php 59
ERROR - 2016-02-21 20:26:34 --> Severity: Notice --> Undefined variable: currency_symbol C:\xampp\htdocs\estore\application\views\Store\Reports\Sales_summary_page.php 59
ERROR - 2016-02-21 20:26:35 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:26:38 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:26:50 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:26:52 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:27:13 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:27:13 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:28:08 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:28:38 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:28:39 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:28:48 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:28:49 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:29:30 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:29:33 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:29:53 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:30:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:30:24 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:32:29 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:32:30 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:33:03 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:33:23 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:33:24 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:33:32 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:33:33 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:33:33 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:34:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 20:34:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 20:34:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 20:35:47 --> Severity: Notice --> Use of undefined constant stock_category_count - assumed 'stock_category_count' C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 12
ERROR - 2016-02-21 20:35:47 --> Severity: Notice --> Use of undefined constant stock_category_count - assumed 'stock_category_count' C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 13
ERROR - 2016-02-21 20:35:47 --> Severity: Notice --> Use of undefined constant stock_count - assumed 'stock_count' C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 14
ERROR - 2016-02-21 20:35:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:35:47 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:35:48 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:35:49 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:35:49 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:36:05 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:36:06 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:36:06 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:36:06 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:36:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:36:09 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:36:09 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:36:09 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:36:09 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:37:18 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:37:18 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:37:18 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:37:18 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:37:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:37:20 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:37:20 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:37:20 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:37:20 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:40:11 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:40:11 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:40:11 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:40:11 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:40:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:40:14 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:40:14 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:40:14 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:40:14 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:40:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:41:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-21 20:42:01 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-21 20:42:02 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-21 20:42:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:43:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:44:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:45:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:45:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:46:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:46:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:46:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:47:12 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:48:02 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:49:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:49:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:50:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:50:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:50:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:51:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:51:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:51:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 20:52:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:05:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:05:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:06:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:06:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:06:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:06:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:07:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:08:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:08:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:09:19 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:09:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:12:43 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:13:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:13:34 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:17:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:18:38 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:19:31 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:19:52 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:20:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:20:28 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:21:08 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:21:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:22:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:22:46 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:23:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:23:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:30:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:34:14 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;=&quot;
LINE 5: ...eid = '1111111111'AND cast(stock_datesold as date = '2016-02...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 21:34:14 --> Query error: ERROR:  syntax error at or near "="
LINE 5: ...eid = '1111111111'AND cast(stock_datesold as date = '2016-02...
                                                             ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name,"STOCK_LEDGER".stock_current_price as stock_price
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            LEFT JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = '1111111111'AND cast(stock_datesold as date = '2016-02-21' GROUP BY t_sales.stock_id,t_stocks.stock_name,stock_price
ERROR - 2016-02-21 21:34:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;=&quot;
LINE 5: ...eid = '1111111111'AND cast(stock_datesold as date = '2016-02...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 21:34:36 --> Query error: ERROR:  syntax error at or near "="
LINE 5: ...eid = '1111111111'AND cast(stock_datesold as date = '2016-02...
                                                             ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name,"STOCK_LEDGER".stock_current_price as stock_price
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            LEFT JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = '1111111111'AND cast(stock_datesold as date = '2016-02-21' GROUP BY t_sales.stock_id,t_stocks.stock_name,stock_price
ERROR - 2016-02-21 21:34:52 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;=&quot;
LINE 5: ...id = '1111111111' AND cast(stock_datesold as date = '2016-02...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 21:34:52 --> Query error: ERROR:  syntax error at or near "="
LINE 5: ...id = '1111111111' AND cast(stock_datesold as date = '2016-02...
                                                             ^ - Invalid query: SELECT t_sales.stock_id,sum(t_sales.stock_qty) as total_sold,t_stocks.stock_name,"STOCK_LEDGER".stock_current_price as stock_price
            FROM t_sales
            INNER JOIN t_stocks ON t_stocks.stock_id = t_sales.stock_id
            LEFT JOIN "STOCK_LEDGER" ON "STOCK_LEDGER"."stock_id" = t_sales.stock_id
            WHERE t_sales.storeid = '1111111111' AND cast(stock_datesold as date = '2016-02-21' GROUP BY t_sales.stock_id,t_stocks.stock_name,stock_price
ERROR - 2016-02-21 21:36:00 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:36:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:36:27 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:39:33 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:40:10 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:40:30 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:40:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:41:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:42:41 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:43:44 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:46:31 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:47:46 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:48:03 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:48:24 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:48:41 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:49:41 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:49:52 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:50:09 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:50:32 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:51:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:51:24 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 21:51:30 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 21:51:34 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 21:52:00 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-21 21:52:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:52:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:52:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:52:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:53:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:53:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:54:08 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:54:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:54:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-21 21:55:47 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:55:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 21:57:04 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 21:57:06 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 22:00:12 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-21 22:00:14 --> Severity: Notice --> Undefined variable: ledger_threshold C:\xampp\htdocs\estore\application\controllers\Store\Dashboard.php 35
ERROR - 2016-02-21 22:00:14 --> Severity: Warning --> pg_query(): Query failed: ERROR:  syntax error at or near &quot;&quot;NULL&quot;&quot;
LINE 3: WHERE &quot;STOCK_LEDGER&quot;.&quot;stock_qty&quot; &lt; &quot;IS&quot; &quot;NULL&quot;
                                                ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 22:00:14 --> Query error: ERROR:  syntax error at or near ""NULL""
LINE 3: WHERE "STOCK_LEDGER"."stock_qty" < "IS" "NULL"
                                                ^ - Invalid query: SELECT *
FROM "STOCK_LEDGER"
WHERE "STOCK_LEDGER"."stock_qty" < "IS" "NULL"
AND "STOCK_LEDGER"."storeid" = '1111111111'
ORDER BY "STOCK_LEDGER"."id" ASC
ERROR - 2016-02-21 22:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\dashboard_page.php 105
ERROR - 2016-02-21 22:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\dashboard_page.php 108
ERROR - 2016-02-21 22:08:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:09:03 --> Severity: Notice --> Undefined variable: dat C:\xampp\htdocs\estore\application\views\Store\dashboard_page.php 108
ERROR - 2016-02-21 22:09:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:09:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:09:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:10:03 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:10:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:10:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:12:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:13:01 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:15:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:15:39 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 22:18:05 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-21 22:19:39 --> Severity: Error --> Class 'Admin_Controller' not found C:\xampp\htdocs\estore\application\controllers\administrator\Authenticate.php 2
ERROR - 2016-02-21 22:20:29 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:20:31 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:22:51 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:22:53 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:23:02 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:23:04 --> 404 Page Not Found: Administrator/Js/classie.js
ERROR - 2016-02-21 22:28:49 --> 404 Page Not Found: Administrator/Authenticate
ERROR - 2016-02-21 22:28:53 --> Severity: Notice --> Undefined property: Authenticate::$Super_User_Model C:\xampp\htdocs\estore\application\controllers\Super\Authenticate.php 9
ERROR - 2016-02-21 22:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Super\Authenticate.php 9
ERROR - 2016-02-21 22:28:54 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:28:54 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:29:26 --> Severity: Notice --> Undefined property: Authenticate::$Super_User_Model C:\xampp\htdocs\estore\application\controllers\Super\Authenticate.php 9
ERROR - 2016-02-21 22:29:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\controllers\Super\Authenticate.php 9
ERROR - 2016-02-21 22:29:27 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:29:28 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:29:54 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:29:55 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:30:00 --> Severity: Notice --> Undefined property: Authenticate::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-21 22:30:00 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column t_super_users.storeid does not exist
LINE 4: AND &quot;t_super_users&quot;.&quot;storeid&quot; IS NULL
            ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 22:30:00 --> Query error: ERROR:  column t_super_users.storeid does not exist
LINE 4: AND "t_super_users"."storeid" IS NULL
            ^ - Invalid query: SELECT *
FROM "t_super_users"
WHERE ((username = 'platform') OR (email_address = 'platform')) AND "password" = '19c2a0dbd8e3a41b25d504744c57df8853e36677'
AND "t_super_users"."storeid" IS NULL
ORDER BY "t_super_users"."id" ASC
ERROR - 2016-02-21 22:31:23 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:31:24 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:31:31 --> 404 Page Not Found: Super/Dashboard/index
ERROR - 2016-02-21 22:32:07 --> 404 Page Not Found: Super/Dashboard/index
ERROR - 2016-02-21 22:32:31 --> Severity: Error --> Call to undefined method Dashboard::getSalesData() C:\xampp\htdocs\estore\application\controllers\Super\Dashboard.php 13
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 9
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 9
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 9
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 9
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 27
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 27
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 27
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 27
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 47
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 47
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 47
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 47
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 58
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 58
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 58
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 58
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 74
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 74
ERROR - 2016-02-21 22:32:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 74
ERROR - 2016-02-21 22:32:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Store\_templates\_menu.php 74
ERROR - 2016-02-21 22:32:48 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:33:36 --> Severity: Notice --> Undefined property: Dashboard::$Super_User_model C:\xampp\htdocs\estore\application\libraries\Admin_Controller.php 21
ERROR - 2016-02-21 22:33:37 --> Severity: Error --> Call to a member function loggedin() on null C:\xampp\htdocs\estore\application\libraries\Admin_Controller.php 21
ERROR - 2016-02-21 22:33:49 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:34:46 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:34:52 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:34:52 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-21 22:35:02 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:35:35 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:36:38 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:37:14 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\estore\application\controllers\Super\Dashboard.php 9
ERROR - 2016-02-21 22:37:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\estore\application\controllers\Super\Dashboard.php 9
ERROR - 2016-02-21 22:38:41 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:39:02 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:39:16 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:40:27 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:48:28 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:48:33 --> 404 Page Not Found: Super/Stores/index
ERROR - 2016-02-21 22:51:31 --> Severity: Notice --> Undefined property: Stores::$rules_admin C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-21 22:51:31 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 23
ERROR - 2016-02-21 22:51:31 --> Severity: Notice --> Undefined index: rules C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 23
ERROR - 2016-02-21 22:51:31 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 79
ERROR - 2016-02-21 22:51:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 22:51:31 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" IS NULL
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "storeid" IS NULL
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-21 22:51:54 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 75
ERROR - 2016-02-21 22:51:54 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-21 22:51:54 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" IS NULL
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "storeid" IS NULL
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 40
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 40
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 43
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 43
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 43
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 43
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 44
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 44
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 44
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 44
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 45
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 45
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 45
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 45
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 46
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 46
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 46
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 46
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:52:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 105
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 108
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 111
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 114
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 117
ERROR - 2016-02-21 22:52:16 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-21 22:52:17 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 47
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 50
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 50
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 50
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 50
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 51
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 51
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 51
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 51
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:53:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-21 22:53:43 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-21 22:53:44 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-21 22:53:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-21 22:53:44 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 124
ERROR - 2016-02-21 22:53:44 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 125
ERROR - 2016-02-21 22:53:44 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 49
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 49
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:14 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 114
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 117
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 120
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 123
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-21 22:54:15 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 127
ERROR - 2016-02-21 22:54:15 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 49
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 49
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 53
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 54
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 55
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 56
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 114
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 117
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 120
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 123
ERROR - 2016-02-21 22:54:33 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-21 22:54:34 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 127
ERROR - 2016-02-21 22:54:34 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 67
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 67
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 70
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 70
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 70
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 70
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:18 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-21 22:55:19 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 145
ERROR - 2016-02-21 22:55:19 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 68
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 68
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 71
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 72
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 73
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 74
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 75
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 75
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined variable: store_privilege C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 75
ERROR - 2016-02-21 22:55:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 75
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 133
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 136
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 139
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 142
ERROR - 2016-02-21 22:55:52 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 145
ERROR - 2016-02-21 22:55:53 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 146
ERROR - 2016-02-21 22:55:53 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$store_status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 52
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-21 22:58:13 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-21 22:58:14 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-21 22:58:14 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-21 22:58:44 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-21 22:58:44 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-21 23:02:30 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:04:26 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\estore\application\views\Store\login_page.php 24
ERROR - 2016-02-21 23:04:38 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:04:40 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:04:50 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:04:51 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:21 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:22 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:24 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:24 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:41 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:05:41 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:06:04 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:06:04 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:07 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:08 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:29 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:30 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:48 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:07:49 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-21 23:08:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-21 23:08:54 --> 404 Page Not Found: Store/Js/classie.js
