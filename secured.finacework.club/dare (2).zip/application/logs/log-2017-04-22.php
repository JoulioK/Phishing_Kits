<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-22 00:33:59 --> Query error: Unknown column 'packageid' in 'where clause' - Invalid query: SELECT sum(bitcoin) as sum
FROM `tbl_earning_history`
WHERE `packageid` = '72728283838uj'
AND `userid` = '14853742757197xj'
ERROR - 2017-04-22 00:34:00 --> Query error: Unknown column 'packageid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492817640
WHERE `packageid` = '72728283838uj'
AND `userid` = '14853742757197xj'
AND `id` = '70d130cb73202e113dd0855fc2d934cc40b75bfb'
ERROR - 2017-04-22 00:35:52 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\package.php 104
ERROR - 2017-04-22 00:35:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\package.php 104
ERROR - 2017-04-22 01:01:53 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\package.php 139
ERROR - 2017-04-22 01:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\package.php 139
ERROR - 2017-04-22 01:02:49 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 476
ERROR - 2017-04-22 01:02:49 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 477
ERROR - 2017-04-22 01:02:49 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: SELECT sum(amount) as amount
FROM `tbl_trade_earnings`
WHERE datecreated between '2017-4- 00:00:01' AND '2017-4- 23:59:59'
AND `packageid` = '72728283838uj'
ERROR - 2017-04-22 01:02:49 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492819369
WHERE datecreated between '2017-4- 00:00:01' AND '2017-4- 23:59:59'
AND `packageid` = '72728283838uj'
AND `id` = '70d130cb73202e113dd0855fc2d934cc40b75bfb'
ERROR - 2017-04-22 01:03:17 --> Query error: Unknown column 'amount' in 'field list' - Invalid query: SELECT sum(amount) as amount
FROM `tbl_trade_earnings`
WHERE datecreated between '2017-4-22 00:00:01' AND '2017-4-22 23:59:59'
AND `packageid` = '72728283838uj'
ERROR - 2017-04-22 01:03:17 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492819397
WHERE datecreated between '2017-4-22 00:00:01' AND '2017-4-22 23:59:59'
AND `packageid` = '72728283838uj'
AND `id` = '70d130cb73202e113dd0855fc2d934cc40b75bfb'
ERROR - 2017-04-22 07:40:14 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-22 10:57:30 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 246
ERROR - 2017-04-22 10:58:59 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 246
ERROR - 2017-04-22 10:59:27 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 246
ERROR - 2017-04-22 11:27:40 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 246
ERROR - 2017-04-22 11:28:42 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 246
ERROR - 2017-04-22 11:32:22 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\bitgiver\application\views\web\customer\profile.php 260
ERROR - 2017-04-22 21:07:08 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-22 21:07:08 --> Severity: Notice --> Undefined variable: earning C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 195
ERROR - 2017-04-22 21:14:33 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2017-04-22 21:14:33 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
ERROR - 2017-04-22 21:17:05 --> Severity: 4096 --> Argument 1 passed to Coinbase\Wallet\Exception\HttpException::exceptionClass() must be an instance of Psr\Http\Message\ResponseInterface, null given, called in C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php on line 33 and defined C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 98
ERROR - 2017-04-22 21:17:05 --> Severity: Error --> Call to a member function getStatusCode() on a non-object C:\xampp\htdocs\bitgiver\vendor\coinbase\coinbase\src\Exception\HttpException.php 121
