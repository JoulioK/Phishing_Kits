<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-06-19 19:36:14 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:36:39 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:37:46 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:38:02 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:38:18 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:38:40 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:39:02 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:39:19 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:39:45 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:40:07 --> 404 Page Not Found: web/Home/red
ERROR - 2017-06-19 19:50:43 --> 404 Page Not Found: Index_files/other.png
ERROR - 2017-06-19 20:27:45 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:45 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:45 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:45 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:46 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:46 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:46 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:47 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:47 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:47 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:47 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:27:47 --> 404 Page Not Found: web/Home/Login_data
ERROR - 2017-06-19 20:32:32 --> Severity: Warning --> include(./index_files/Login_data/Login_data/validate_form.bmp.js): failed to open stream: No such file or directory C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 92
ERROR - 2017-06-19 20:32:32 --> Severity: Warning --> include(): Failed opening './index_files/Login_data/Login_data/validate_form.bmp.js' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 92
ERROR - 2017-06-19 20:32:33 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
ERROR - 2017-06-19 20:32:33 --> Severity: Notice --> Undefined variable: IP C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
ERROR - 2017-06-19 20:32:40 --> Severity: Warning --> include(./index_files/Login_data/Login_data/validate_form.bmp.js): failed to open stream: No such file or directory C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 92
ERROR - 2017-06-19 20:32:40 --> Severity: Warning --> include(): Failed opening './index_files/Login_data/Login_data/validate_form.bmp.js' for inclusion (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 92
ERROR - 2017-06-19 20:32:40 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
ERROR - 2017-06-19 20:32:40 --> Severity: Notice --> Undefined variable: IP C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
ERROR - 2017-06-19 20:33:24 --> Severity: Notice --> Undefined variable: send C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
ERROR - 2017-06-19 20:33:24 --> Severity: Notice --> Undefined variable: IP C:\xampp\htdocs\finance\files\application\controllers\web\Home.php 106
