<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-01 04:57:50 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-05-01 12:54:30 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-05-01 12:56:46 --> Severity: Notice --> Undefined variable: graceperiod C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 133
ERROR - 2017-05-01 13:04:29 --> Severity: Notice --> Undefined variable: earning C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 195
ERROR - 2017-05-01 13:06:10 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 147
ERROR - 2017-05-01 13:06:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 183
ERROR - 2017-05-01 13:06:10 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 195
ERROR - 2017-05-01 13:07:22 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 147
ERROR - 2017-05-01 13:07:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 183
ERROR - 2017-05-01 13:07:22 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 195
ERROR - 2017-05-01 13:07:48 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 147
ERROR - 2017-05-01 14:02:11 --> Severity: Notice --> Undefined variable: earning C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 180
ERROR - 2017-05-01 14:03:53 --> Severity: Notice --> Undefined variable: earning C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 180
ERROR - 2017-05-01 15:14:25 --> Severity: Notice --> Undefined property: stdClass::$earnings C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 234
ERROR - 2017-05-01 15:14:44 --> Severity: Notice --> Undefined property: stdClass::$earning C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 234
ERROR - 2017-05-01 15:24:53 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 43
ERROR - 2017-05-01 15:24:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= ''
WHERE `userid` = '14853742757197xj'' at line 1 - Invalid query: UPDATE `tbl_users` SET  = ''
WHERE `userid` = '14853742757197xj'
ERROR - 2017-05-01 15:25:46 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 43
ERROR - 2017-05-01 15:25:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= ''
WHERE `userid` = '14853742757197xj'' at line 1 - Invalid query: UPDATE `tbl_users` SET  = ''
WHERE `userid` = '14853742757197xj'
ERROR - 2017-05-01 15:28:30 --> Severity: Notice --> Undefined variable: bonus C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 219
ERROR - 2017-05-01 17:07:14 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 81
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: today_earning C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 137
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: this_month C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 140
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 145
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:12:02 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 156
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: today_earning C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 136
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: this_month C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 139
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:13:10 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:30:42 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:31:09 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:05 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 136
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:36 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:37 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:37 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:37 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:37 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:37 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:33:59 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:35:39 --> Severity: Notice --> Undefined variable: selectedmonth C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 155
ERROR - 2017-05-01 17:41:16 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:41:35 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:41:55 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 17:42:42 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 81
ERROR - 2017-05-01 17:43:00 --> Severity: Compile Error --> Cannot redeclare Btc::cashout() C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 637
ERROR - 2017-05-01 17:48:54 --> Severity: Notice --> Undefined property: stdClass::$contractfee C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 365
ERROR - 2017-05-01 18:13:08 --> Severity: Notice --> Undefined property: stdClass::$ghid C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 141
ERROR - 2017-05-01 18:24:38 --> Severity: Notice --> Undefined variable: unpaid C:\xampp\htdocs\bitgiver\application\views\web\customer\earning.php 144
ERROR - 2017-05-01 19:23:52 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 139
ERROR - 2017-05-01 19:23:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 139
ERROR - 2017-05-01 22:37:19 --> 404 Page Not Found: web/Btc/confirm
ERROR - 2017-05-01 22:38:26 --> 404 Page Not Found: web/Btc/confirm
ERROR - 2017-05-01 22:51:00 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 309
