<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-01 20:33:39 --> Severity: Warning --> Missing argument 1 for Item::deposit() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 116
ERROR - 2016-12-01 20:33:39 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 148
ERROR - 2016-12-01 20:33:40 --> Query error: Unknown column 'depositorsname' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`depositorsname`, `tellernumber`, `paymentdate`, `datemodified`) VALUES ('Ola Gcfr', '3457889900-', '2016-12-01', '2016-12-01 20:33:39')
ERROR - 2016-12-01 20:34:06 --> Severity: Warning --> Missing argument 1 for Item::deposit() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 116
ERROR - 2016-12-01 20:34:06 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 148
ERROR - 2016-12-01 20:40:01 --> Severity: Warning --> Missing argument 1 for Item::deposit() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 116
ERROR - 2016-12-01 20:40:01 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 148
ERROR - 2016-12-01 20:46:11 --> Severity: Warning --> Missing argument 1 for Item::deposit() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 116
ERROR - 2016-12-01 20:46:11 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 148
ERROR - 2016-12-01 20:49:15 --> Severity: Warning --> Missing argument 1 for Item::deposit() C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 116
ERROR - 2016-12-01 20:49:15 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 148
ERROR - 2016-12-01 22:51:50 --> Severity: Error --> Call to undefined method Customer::upload_data() C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 80
ERROR - 2016-12-01 22:53:43 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: UPDATE `tbl_users` SET `fullname` = NULL, `emailaddress` = 'olafashade@hotmail.com', `password` = '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', `expirydate` = '6/2016', `datemodified` = '2016-12-01 22:53:43', `identity` = 'http://localhost/snappycoin/resources/general/images/itemimages/0a908c8b852e5263832335a5c7c8205c.png'
WHERE `userid` = '14675775313398tp'
ERROR - 2016-12-01 22:55:45 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 61
