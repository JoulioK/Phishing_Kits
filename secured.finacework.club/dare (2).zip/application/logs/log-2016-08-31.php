<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-31 19:36:34 --> 404 Page Not Found: Faviconico/index
