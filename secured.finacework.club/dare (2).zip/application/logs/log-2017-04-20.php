<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-20 15:34:36 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 15:34:44 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-20 15:34:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 144
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:34:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 147
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 147
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 148
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 148
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 149
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 149
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 150
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 150
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 151
ERROR - 2017-04-20 15:37:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 151
ERROR - 2017-04-20 15:37:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 152
ERROR - 2017-04-20 15:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 152
ERROR - 2017-04-20 15:37:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 152
ERROR - 2017-04-20 15:37:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\tradeearnings.php 152
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:37:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-04-20 15:39:37 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:39:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:41:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:44:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:46:41 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:47:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:22 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> Severity: Notice --> Undefined variable: banks C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 24
ERROR - 2017-04-20 15:57:23 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 37
ERROR - 2017-04-20 15:57:23 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 43
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:57:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:23 --> Severity: Notice --> Undefined variable: banks C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 137
ERROR - 2017-04-20 15:59:23 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 150
ERROR - 2017-04-20 15:59:23 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 156
ERROR - 2017-04-20 15:59:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:38 --> Severity: Notice --> Undefined variable: banks C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 137
ERROR - 2017-04-20 15:59:38 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 150
ERROR - 2017-04-20 15:59:38 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 156
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 15:59:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> Severity: Notice --> Undefined variable: banks C:\xampp\htdocs\bitgiver\application\views\web\customer\cashout.php 137
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:00:35 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:37 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:01:49 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:03:55 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:17 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:32 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:34 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:57 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:04:58 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:05:53 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:19:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:20:24 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:20 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:23 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:28 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:29 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:31 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:50 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:56 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:57 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:57 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:57 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:57 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:57 --> 404 Page Not Found: web/Support/images
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/2.jpg
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/6.jpg
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/7.jpg
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/5.jpg
ERROR - 2017-04-20 16:21:58 --> 404 Page Not Found: web/Images/3.jpg
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:37:45 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:38:12 --> Query error: Unknown column 'bitcoin' in 'field list' - Invalid query: INSERT INTO `tbl_earning_history` (`userid`, `bitcoinaddress`, `bitcoin`, `recordid`, `datecreated`, `datemodified`) VALUES ('14853742757197xj', NULL, '0.002', '14927134925210ax', '2017-04-20 19:38:12', '2017-04-20 19:38:12')
ERROR - 2017-04-20 19:40:42 --> Query error: Column 'bitcoinaddress' cannot be null - Invalid query: INSERT INTO `tbl_earning_history` (`userid`, `bitcoinaddress`, `bitcoin`, `recordid`, `datecreated`, `datemodified`) VALUES ('14853742757197xj', NULL, '0.002', '14927136421389dv', '2017-04-20 19:40:42', '2017-04-20 19:40:42')
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:41:27 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:57:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 19:59:43 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:15 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:47 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:00:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:13 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-20 20:04:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:04:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 142
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:05:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:01 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 20:55:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:13 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-20 21:00:52 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 169
ERROR - 2017-04-20 21:00:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 169
ERROR - 2017-04-20 21:00:52 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 170
