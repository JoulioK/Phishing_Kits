<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-23 03:51:22 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-07-23 03:51:28 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-07-23 03:51:29 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-07-23 03:51:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 03:51:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 03:51:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-23 03:52:09 --> Severity: Warning --> Missing argument 1 for MY_Model::get_by(), called in C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php on line 37 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 38
ERROR - 2016-07-23 03:52:09 --> Severity: Notice --> Undefined variable: where C:\xampp\htdocs\fastfood\application\core\MY_Model.php 39
ERROR - 2016-07-23 03:52:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'IS NULL' at line 3 - Invalid query: SELECT `franchisename`, `franchiseid`
FROM `tbl_franchise_configuration`
WHERE  IS NULL
ERROR - 2016-07-23 04:00:39 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\fastfood\application\views\management\franchisereport\orders.php 130
ERROR - 2016-07-23 04:08:59 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\fastfood\application\views\management\franchisereport\orders.php 130
ERROR - 2016-07-23 04:08:59 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\fastfood\application\views\management\franchisereport\orders.php 130
ERROR - 2016-07-23 04:08:59 --> Severity: Notice --> Undefined variable: config C:\xampp\htdocs\fastfood\application\views\management\franchisereport\orders.php 130
ERROR - 2016-07-23 04:13:11 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\views\management\franchisereport\orders.php 130
ERROR - 2016-07-23 04:21:16 --> 404 Page Not Found: management/Franchisereports/orders_summary
ERROR - 2016-07-23 05:20:19 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 175
ERROR - 2016-07-23 05:20:19 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 176
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined variable: vendors C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 58
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 90
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 90
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 90
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 90
ERROR - 2016-07-23 05:20:20 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\income_summary.php 90
ERROR - 2016-07-23 05:23:25 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 175
ERROR - 2016-07-23 05:23:25 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 176
ERROR - 2016-07-23 05:56:26 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping.php 21
ERROR - 2016-07-23 05:56:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping.php 21
ERROR - 2016-07-23 05:56:42 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping.php 21
ERROR - 2016-07-23 05:56:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping.php 21
ERROR - 2016-07-23 06:26:59 --> Severity: Notice --> Undefined variable: shippings C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 294
ERROR - 2016-07-23 06:27:00 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping_summary.php 120
ERROR - 2016-07-23 06:27:00 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping_summary.php 120
ERROR - 2016-07-23 06:27:00 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping_summary.php 120
ERROR - 2016-07-23 06:27:00 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping_summary.php 120
ERROR - 2016-07-23 06:27:00 --> Severity: Notice --> Undefined offset: 4 C:\xampp\htdocs\fastfood\application\views\management\franchisereport\shipping_summary.php 120
ERROR - 2016-07-23 06:27:40 --> Severity: Notice --> Undefined variable: shippings C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 294
ERROR - 2016-07-23 10:46:06 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 10:46:26 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 10:46:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 10:46:42 --> Severity: Notice --> Undefined property: Franchisereport::$franchise C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 224
ERROR - 2016-07-23 10:47:48 --> Severity: Notice --> Undefined property: Franchisereport::$franchise C:\xampp\htdocs\fastfood\application\controllers\management\franchisereport.php 224
ERROR - 2016-07-23 11:09:30 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:09:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:19:15 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:19:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:19:16 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:19:16 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:19:16 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:19:23 --> Severity: Notice --> Undefined variable: franchises C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:19:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 21
ERROR - 2016-07-23 11:19:23 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:19:23 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:19:23 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 71
ERROR - 2016-07-23 11:55:53 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\views\management\franchisereport\delivery_summary.php 53
ERROR - 2016-07-23 12:24:37 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-23 13:09:37 --> Severity: Notice --> Undefined variable: month C:\xampp\htdocs\fastfood\application\views\vendor\reports\orders_summary.php 53
ERROR - 2016-07-23 13:09:37 --> Severity: Notice --> Undefined variable: year C:\xampp\htdocs\fastfood\application\views\vendor\reports\orders_summary.php 53
ERROR - 2016-07-23 13:09:37 --> Severity: Notice --> Undefined variable: days C:\xampp\htdocs\fastfood\application\views\vendor\reports\orders_summary.php 72
ERROR - 2016-07-23 17:17:51 --> 404 Page Not Found: web/Settings/index.html
ERROR - 2016-07-23 17:21:10 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-23 17:21:10 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-23 17:21:17 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 17:27:33 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 19:14:47 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-23 19:18:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-23 22:19:43 --> 404 Page Not Found: management/Js/classie.js
