<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-02 06:37:36 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-05-02 06:37:57 --> 404 Page Not Found: web/Btc/cashoutrecords
ERROR - 2017-05-02 06:43:55 --> Query error: Unknown column 'tbl_trade_earnings.bitcoin' in 'field list' - Invalid query: SELECT `tbl_packages`.`packagename`, `tbl_trade_earnings`.`bitcoin`, `tbl_trade_earnings`.`datecreated`
FROM `tbl_withdrawals`
JOIN `tbl_packages` ON `tbl_trade_earnings`.`packageid`=`tbl_packages`.`packageid`
WHERE `tbl_withdrawals`.`userid` = '14853742757197xj'
ORDER BY `tbl_withdrawals`.`id` desc
ERROR - 2017-05-02 06:43:55 --> Query error: Unknown column 'tbl_withdrawals.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493703835
WHERE `tbl_withdrawals`.`userid` = '14853742757197xj'
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ORDER BY `tbl_withdrawals`.`id` desc
ERROR - 2017-05-02 08:05:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-05-02 08:05:24 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 9
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 73
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 73
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 78
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 78
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 79
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 79
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 80
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 80
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 81
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 81
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 86
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 86
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 90
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 90
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 94
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 94
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 100
ERROR - 2017-05-02 08:05:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 100
ERROR - 2017-05-02 08:07:06 --> Severity: Notice --> Undefined property: stdClass::$phid C:\xampp\htdocs\bitgiver\application\views\management\orders\unfulfiled_pledges.php 73
ERROR - 2017-05-02 08:07:06 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:07:06 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:07:25 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:07:25 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 08:08:16 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 9
ERROR - 2017-05-02 08:23:12 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 9
ERROR - 2017-05-02 08:26:58 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 9
ERROR - 2017-05-02 08:26:58 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 42
ERROR - 2017-05-02 08:27:01 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 9
ERROR - 2017-05-02 08:27:01 --> Severity: Notice --> Undefined variable: benefactorslist C:\xampp\htdocs\bitgiver\application\views\management\orders\beneficiary.php 42
ERROR - 2017-05-02 08:47:14 --> Query error: Unknown column 'tbl_gh' in 'field list' - Invalid query: SELECT `tbl_gh`
FROM `tbl_users`
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711234
ERROR - 2017-05-02 08:47:14 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493711234, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":25:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:5:\"0.024\";s:14:\"bitcoinaddress\";s:15:\"1xslk3030dkfjfk\";s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:8:\"identity\";N;s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711234
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ERROR - 2017-05-02 08:47:41 --> Query error: Unknown column 'tbl_gh' in 'field list' - Invalid query: SELECT `tbl_gh`
FROM `tbl_gh`
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711261
ERROR - 2017-05-02 08:47:41 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493711261, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":25:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:5:\"0.024\";s:14:\"bitcoinaddress\";s:15:\"1xslk3030dkfjfk\";s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:8:\"identity\";N;s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711261
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ERROR - 2017-05-02 08:47:57 --> Query error: Unknown column 'tbl_ph.maturitydate' in 'where clause' - Invalid query: SELECT *
FROM `tbl_gh`
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711277
ERROR - 2017-05-02 08:47:57 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493711277, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":25:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:5:\"0.024\";s:14:\"bitcoinaddress\";s:15:\"1xslk3030dkfjfk\";s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:8:\"identity\";N;s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE `tbl_gh`.`paymentstatus` = 1
AND `tbl_gh`.`machinestatus` = 1
AND `tbl_gh`.`status` = 1
AND `tbl_gh`.`packageid` IS NULL
AND unix_timestamp(tbl_ph.maturitydate) <= 1493711277
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ERROR - 2017-05-02 08:53:16 --> Query error: Unknown column 'earning' in 'field list' - Invalid query: INSERT INTO `tbl_trade_earnings` (`earning`, `packageid`, `userid`, `earningid`, `datemodified`, `datecreated`) VALUES (0.00135, '72728283838uj', '14853742757197xj', '14937115961193vq', '2017-05-02 08:53:16', '2017-05-02 08:53:16')
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: year C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 190
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: month C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 190
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 190
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: year C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 191
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: month C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 191
ERROR - 2017-05-02 08:58:27 --> Severity: Notice --> Undefined variable: day C:\xampp\htdocs\bitgiver\application\controllers\management\Orders.php 191
ERROR - 2017-05-02 08:58:27 --> Query error: Not unique table/alias: 'tbl_trade_earnings' - Invalid query: SELECT *
FROM `tbl_trade_earnings`, `tbl_trade_earnings`
WHERE datecreated between '-- 00:00:00' AND '-- 23:59:59'
AND `packageid` = '72728283838uj'
ERROR - 2017-05-02 08:58:27 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493711907, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":25:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:5:\"0.024\";s:14:\"bitcoinaddress\";s:15:\"1xslk3030dkfjfk\";s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:8:\"identity\";N;s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE datecreated between '-- 00:00:00' AND '-- 23:59:59'
AND `packageid` = '72728283838uj'
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ERROR - 2017-05-02 08:58:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\bitgiver\system\database\DB_driver.php:1697) C:\xampp\htdocs\bitgiver\system\core\Common.php 569
ERROR - 2017-05-02 08:58:58 --> Query error: Not unique table/alias: 'tbl_trade_earnings' - Invalid query: SELECT *
FROM `tbl_trade_earnings`, `tbl_trade_earnings`
WHERE datecreated between '2017-05-02 00:00:00' AND '2017-05-02 23:59:59'
AND `packageid` = '72728283838uj'
ERROR - 2017-05-02 08:58:58 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493711938, `data` = 'Please login first|N;user_session|O:8:\"stdClass\":25:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:5:\"0.024\";s:14:\"bitcoinaddress\";s:15:\"1xslk3030dkfjfk\";s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:8:\"identity\";N;s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE datecreated between '2017-05-02 00:00:00' AND '2017-05-02 23:59:59'
AND `packageid` = '72728283838uj'
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 89
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 89
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 90
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 90
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 91
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 91
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 92
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 92
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 97
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 97
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 101
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 101
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 105
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 105
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 120
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 120
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 89
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 89
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 90
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 90
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 91
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 91
ERROR - 2017-05-02 09:35:57 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 92
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 92
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 97
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 97
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 101
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 101
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 105
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 105
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 120
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 120
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:35:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined property: stdClass::$phid C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined property: stdClass::$phid C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 84
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:48 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:40:57 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 108
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 110
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:23 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 112
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:41:47 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 115
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:42:09 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 117
ERROR - 2017-05-02 09:43:01 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:43:27 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:43:27 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 125
ERROR - 2017-05-02 09:44:03 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:44:03 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:48:08 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:48:08 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:49:56 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:49:56 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:50:12 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:50:12 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:50:39 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 09:50:39 --> Severity: Notice --> Undefined property: stdClass::$reserved C:\xampp\htdocs\bitgiver\application\views\management\orders\pledges.php 129
ERROR - 2017-05-02 10:15:32 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:15:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:15:32 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 165
ERROR - 2017-05-02 10:15:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 165
ERROR - 2017-05-02 10:15:32 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 173
ERROR - 2017-05-02 10:15:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 173
ERROR - 2017-05-02 10:17:39 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 143
ERROR - 2017-05-02 10:17:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 143
ERROR - 2017-05-02 10:18:15 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 143
ERROR - 2017-05-02 10:18:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 143
ERROR - 2017-05-02 10:18:39 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:18:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:19:25 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:19:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:06 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:22 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:22 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:37 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:20:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:21:21 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:21:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 140
ERROR - 2017-05-02 10:24:19 --> Severity: Notice --> Undefined property: stdClass::$ghid C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:24:19 --> Severity: Notice --> Undefined property: stdClass::$earning C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:24:19 --> Severity: Notice --> Undefined property: stdClass::$ghid C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:24:19 --> Severity: Notice --> Undefined property: stdClass::$earning C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:25:15 --> Severity: Notice --> Undefined property: stdClass::$earning C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:25:15 --> Severity: Notice --> Undefined property: stdClass::$earning C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:26:46 --> Severity: Parsing Error --> syntax error, unexpected '?' C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 142
ERROR - 2017-05-02 10:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 266
ERROR - 2017-05-02 10:48:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 266
ERROR - 2017-05-02 10:48:01 --> Severity: Parsing Error --> syntax error, unexpected '/' C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 123
ERROR - 2017-05-02 10:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 266
ERROR - 2017-05-02 10:48:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 266
ERROR - 2017-05-02 11:27:26 --> Query error: Unknown column '72728283838uj' in 'field list' - Invalid query: UPDATE `tbl_gh` SET `72728283838uj` = 'Amateur', `292929399po` = 'Intermediate', `earning` = -7.0000000000001E-5, `bitcoin` = 0.4095, `datemodified` = '2017-05-02 11:27:26'
WHERE `ghid` = '14937135910592gi'
ERROR - 2017-05-02 11:27:58 --> Severity: Notice --> Undefined index: 72728283838uj C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 123
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 140
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 140
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 146
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 146
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 12:35:50 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 12:37:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 140
ERROR - 2017-05-02 12:37:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\terminate.php 146
ERROR - 2017-05-02 12:37:11 --> Severity: Notice --> Undefined offset: 2 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 12:37:11 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\bitgiver\application\helpers\utilities_helper.php 156
ERROR - 2017-05-02 13:46:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 244
ERROR - 2017-05-02 13:46:20 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 244
ERROR - 2017-05-02 13:57:26 --> Query error: Unknown column 'tbl_withdrawals.bitcointbl_withdrawals.datecreated' in 'field list' - Invalid query: SELECT `tbl_packages`.`packagename`, `tbl_withdrawals`.`bitcointbl_withdrawals`.`datecreated`
FROM `tbl_withdrawals`
JOIN `tbl_packages` ON `tbl_withdrawals`.`packageid`=`tbl_packages`.`packageid`
WHERE tbl_withdrawals.datecreated between '2017-05-01 00:00:00' AND '2017-05-02 23:59:59'
AND `tbl_withdrawals`.`userid` = '14853742757197xj'
ORDER BY `tbl_withdrawals`.`id` desc
ERROR - 2017-05-02 13:57:26 --> Query error: Unknown column 'tbl_withdrawals.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1493729846
WHERE tbl_withdrawals.datecreated between '2017-05-01 00:00:00' AND '2017-05-02 23:59:59'
AND `tbl_withdrawals`.`userid` = '14853742757197xj'
AND `id` = '1a007c126df8f14b63dae2e748026e78a0934ec8'
ORDER BY `tbl_withdrawals`.`id` desc
ERROR - 2017-05-02 14:30:05 --> Severity: Notice --> Undefined variable: upgrades C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 199
ERROR - 2017-05-02 14:30:51 --> Severity: Notice --> Undefined variable: upgrades C:\xampp\htdocs\bitgiver\application\views\web\customer\upgradeplan.php 196
