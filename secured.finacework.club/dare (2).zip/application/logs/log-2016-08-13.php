<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-13 06:41:02 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 07:04:02 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:04:13 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 07:04:15 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:04:20 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:04:31 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:05:19 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 07:05:20 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:05:22 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 07:05:56 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 07:07:57 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 08:03:48 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 08:04:06 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 08:04:19 --> 404 Page Not Found: vendor/Items/resources
ERROR - 2016-08-13 08:05:06 --> 404 Page Not Found: vendor/Items/resources
ERROR - 2016-08-13 08:23:42 --> Query error: Unknown column 'status' in 'field list' - Invalid query: INSERT INTO `tbl_vendor_users` (`username`, `fullname`, `emailaddress`, `phonenumber`, `status`, `userid`, `datecreated`, `datemodified`, `privileges`, `password`, `vendorid`, `franchiseid`) VALUES ('olafashade', 'Ola Fashade', 'olafashade@hotmail.com', '8068752947', '1', '14710694221782xc', '2016-08-13 08:23:42', '2016-08-13 08:23:42', 'Admin', '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', '14668583422639we', '2626273373')
ERROR - 2016-08-13 08:24:54 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 08:28:16 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-13 08:36:21 --> 404 Page Not Found: management/Orders/view_order
ERROR - 2016-08-13 09:03:46 --> Severity: Error --> Cannot access protected property Item_model::$_primary_filter C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 34
ERROR - 2016-08-13 09:04:17 --> Severity: Error --> Cannot access protected property Order_Model::$_primary_filter C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 34
ERROR - 2016-08-13 09:04:56 --> Severity: Error --> Cannot access protected property Item_model::$_primary_filter C:\xampp\htdocs\fastfood\application\controllers\vendor\orders.php 34
ERROR - 2016-08-13 10:10:07 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 10:10:12 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\fastfood\application\controllers\web\item.php 306
ERROR - 2016-08-13 10:10:46 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\web\item.php 388
ERROR - 2016-08-13 10:12:46 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 198
ERROR - 2016-08-13 10:12:46 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 232
ERROR - 2016-08-13 10:12:52 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 245
ERROR - 2016-08-13 10:17:44 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 98
ERROR - 2016-08-13 10:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 77
ERROR - 2016-08-13 10:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 82
ERROR - 2016-08-13 10:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 106
ERROR - 2016-08-13 10:17:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\checkout.php 106
ERROR - 2016-08-13 10:19:52 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 10:24:43 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 10:24:44 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 10:24:46 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 10:26:43 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 10:27:25 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 10:27:25 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 10:27:28 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 10:29:43 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 10:30:44 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 10:30:44 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 10:30:47 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 11:01:05 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 11:01:58 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 11:01:58 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 11:02:02 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 11:02:56 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 11:04:07 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 11:04:07 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 11:04:10 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 11:10:51 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 11:12:00 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 205
ERROR - 2016-08-13 11:12:00 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\web\item.php 239
ERROR - 2016-08-13 11:12:04 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\fastfood\application\controllers\web\item.php 252
ERROR - 2016-08-13 11:56:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 11:57:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 11:57:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:01:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:05:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:05:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:05:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:05:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:13:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:14:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:14:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:15:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:16:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:16:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:16:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:18:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:18:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:19:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:19:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:21:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:21:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:22:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:22:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:22:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:24:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:24:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:25:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:26:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 12:27:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 13:58:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 14:04:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\web\item.php 404
ERROR - 2016-08-13 16:34:55 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: images C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 13
ERROR - 2016-08-13 16:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 13
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-08-13 16:34:56 --> Severity: Notice --> Undefined variable: prices C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 51
ERROR - 2016-08-13 16:34:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 51
ERROR - 2016-08-13 16:35:01 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-08-13 16:41:06 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 16:42:18 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 16:42:19 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-08-13 16:45:21 --> 404 Page Not Found: Orders/index
ERROR - 2016-08-13 16:46:37 --> 404 Page Not Found: Orders/index
ERROR - 2016-08-13 17:31:58 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-13 17:32:02 --> 404 Page Not Found: management/Js/classie.js
