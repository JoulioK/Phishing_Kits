<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-16 21:28:45 --> 404 Page Not Found: 
ERROR - 2016-09-16 21:37:22 --> 404 Page Not Found: 
ERROR - 2016-09-16 21:37:23 --> 404 Page Not Found: 
ERROR - 2016-09-16 21:58:03 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\fastfood\application\controllers\web\Authenticate.php 93
ERROR - 2016-09-16 21:58:11 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\fastfood\application\controllers\web\Authenticate.php 93
ERROR - 2016-09-16 21:58:43 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\fastfood\application\controllers\web\Authenticate.php 93
