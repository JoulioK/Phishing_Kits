<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-17 11:33:39 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:33:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:41:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:42:29 --> 404 Page Not Found: web/Users/plan
ERROR - 2017-04-17 11:43:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\plan.php 100
ERROR - 2017-04-17 11:43:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:43:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:43:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:43:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:43:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:43:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:25 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:44:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:46:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:53 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:47:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:13 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\customer\plan.php 117
ERROR - 2017-04-17 11:52:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\plan.php 117
ERROR - 2017-04-17 11:52:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:14 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:15 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:56 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:52:57 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:54:39 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:03 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:40 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:56:50 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 11:57:04 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:00:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:01:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:23 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:03:25 --> 404 Page Not Found: web/Btc/pick
ERROR - 2017-04-17 12:04:01 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 79
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:04:41 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:57 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 81
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:15:58 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 12:16:18 --> Query error: Unknown column 'tbl_gh.packageid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_gh`
WHERE `tbl_gh`.`userid` = '14853742757197xj'
AND `tbl_gh`.`packageid` = '72728283838uj'
AND `tbl_gh`.`status` = 'active'
ERROR - 2017-04-17 12:16:18 --> Query error: Unknown column 'tbl_gh.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492427778
WHERE `tbl_gh`.`userid` = '14853742757197xj'
AND `tbl_gh`.`packageid` = '72728283838uj'
AND `tbl_gh`.`status` = 'active'
AND `id` = 'ecdf78f843afa90ed8d01853c236f325ce4b09a5'
ERROR - 2017-04-17 12:23:09 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:23:10 --> Severity: Notice --> Undefined variable: amount C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 15
ERROR - 2017-04-17 12:24:13 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:13 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:13 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:14 --> Severity: Notice --> Undefined variable: investment C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 20
ERROR - 2017-04-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:24:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 165
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 172
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:25:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 179
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 26
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 33
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 40
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 48
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 49
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 83
ERROR - 2017-04-17 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:26:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:27:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:28:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:29:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:31:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 12:32:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:35:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:42:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:43:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:44:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:45:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:46:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:47:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 13:49:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 114
ERROR - 2017-04-17 14:07:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:09 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 122
ERROR - 2017-04-17 14:07:43 --> Severity: Warning --> require_once(C:\xampp\htdocs\bitgiver/vendor/autoload.php): failed to open stream: No such file or directory C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 45
ERROR - 2017-04-17 14:07:43 --> Severity: Compile Error --> require_once(): Failed opening required 'C:\xampp\htdocs\bitgiver/vendor/autoload.php' (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 45
ERROR - 2017-04-17 14:08:37 --> Severity: Error --> Class 'Configuration' not found C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 46
ERROR - 2017-04-17 14:09:04 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 74
ERROR - 2017-04-17 14:09:04 --> Query error: Unknown column 'phrequestdate' in 'field list' - Invalid query: INSERT INTO `tbl_packages` (`datecreated`, `datemodified`, `phrequestdate`, `graceperiod`, `phuser`, `ghid`, `userid`, `bitcoin`, `bitcoinaddress`, `paymentstatus`, `status`, `maturitydate`) VALUES ('2017-04-17 14:09:02', '2017-04-17 14:09:02', '2017-04-17 14:09:02', '2017-04-17 20:09:04', '14853742757197xj', '14924345446702jz', NULL, '0.0034', '1HoLQZxn6xGEoGThYSoEwvUbiPaRJVZcaq', 0, 0, '2017-04-25 2:09:04')
ERROR - 2017-04-17 14:09:40 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 74
ERROR - 2017-04-17 14:09:40 --> Query error: Unknown column 'bitcoin' in 'field list' - Invalid query: INSERT INTO `tbl_gh` (`datecreated`, `datemodified`, `phrequestdate`, `graceperiod`, `phuser`, `ghid`, `userid`, `bitcoin`, `bitcoinaddress`, `paymentstatus`, `status`, `maturitydate`) VALUES ('2017-04-17 14:09:38', '2017-04-17 14:09:38', '2017-04-17 14:09:38', '2017-04-17 20:09:40', '14853742757197xj', '14924345806253yc', NULL, '0.0034', '1MEm2eufQnxrVa7vCphMoKrjtkjcNFApKY', 0, 0, '2017-04-25 2:09:40')
ERROR - 2017-04-17 14:15:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:15:38 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:14 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 51
ERROR - 2017-04-17 14:16:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 51
ERROR - 2017-04-17 14:16:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 82
ERROR - 2017-04-17 14:16:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 86
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:24 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:16:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:16:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:16:48 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:17:39 --> 404 Page Not Found: web/Btc/images
ERROR - 2017-04-17 14:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:18:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:18:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:20:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:21:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 128
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:22:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:18 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:32:19 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:35:08 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:17 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:37:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:39:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:48:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:49:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:50:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:53:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:56:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:57:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:58:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 14:59:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:00:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:01:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:02:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:07:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:08:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:09:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:10:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:12:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 89
ERROR - 2017-04-17 15:14:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:14:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\controllers\web\Btc.php 132
ERROR - 2017-04-17 15:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\bitgiver\application\views\web\customer\confirmpackage.php 93
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:15:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:27 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:28 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:30 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:54 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:16:55 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:17:46 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:37 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:18:38 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:42 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:44 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-17 15:20:47 --> 404 Page Not Found: web/Btc/ph
