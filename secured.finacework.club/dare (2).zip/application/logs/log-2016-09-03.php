<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-03 01:35:40 --> 404 Page Not Found: 
ERROR - 2016-09-03 01:35:48 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 01:37:01 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:30:37 --> 404 Page Not Found: 
ERROR - 2016-09-03 02:30:40 --> 404 Page Not Found: 
ERROR - 2016-09-03 02:30:58 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:31:52 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:32:43 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:33:30 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:34:32 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:36:10 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:36:39 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:37:09 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:37:42 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:38:59 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:40:19 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:42:23 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:43:00 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:44:23 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:44:39 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:45:08 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:45:52 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:46:21 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:47:44 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:49:23 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:50:05 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:53:17 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:53:28 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:54:17 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:55:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 02:55:11 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-03 07:20:35 --> 404 Page Not Found: web/Resources/web
