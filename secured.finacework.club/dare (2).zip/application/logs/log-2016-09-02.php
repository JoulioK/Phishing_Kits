<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-02 21:52:58 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 84
ERROR - 2016-09-02 21:53:06 --> Severity: Warning --> Missing argument 1 for Item::receipt() C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 461
ERROR - 2016-09-02 21:53:06 --> Severity: Warning --> Missing argument 2 for Item::receipt() C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 461
ERROR - 2016-09-02 21:53:07 --> Severity: Warning --> Missing argument 3 for Item::receipt() C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 461
ERROR - 2016-09-02 21:53:07 --> Severity: Warning --> Missing argument 4 for Item::receipt() C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 461
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Undefined variable: shippingaddress C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 465
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 488
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 490
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 491
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 47
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 493
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Undefined variable: transactionid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 501
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 523
ERROR - 2016-09-02 21:53:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 523
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Undefined variable: item C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 538
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 538
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 77
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 82
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 539
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 539
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 574
ERROR - 2016-09-02 21:53:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 574
ERROR - 2016-09-02 22:42:02 --> 404 Page Not Found: web/Restaurant/index
ERROR - 2016-09-02 22:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-02 22:42:11 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 31
ERROR - 2016-09-02 22:42:42 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 56
ERROR - 2016-09-02 22:42:42 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 60
ERROR - 2016-09-02 22:43:34 --> Severity: Notice --> Undefined property: Restaurants::$pagination C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 64
ERROR - 2016-09-02 22:43:34 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 64
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: banners C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 15
ERROR - 2016-09-02 22:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 15
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 24
ERROR - 2016-09-02 22:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 24
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 113
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 181
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 187
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: products C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 188
ERROR - 2016-09-02 22:45:14 --> Severity: Notice --> Undefined variable: featuredvendors C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 222
ERROR - 2016-09-02 22:45:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 222
ERROR - 2016-09-02 22:45:21 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:45:49 --> Severity: Notice --> Undefined variable: banners C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 15
ERROR - 2016-09-02 22:45:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 15
ERROR - 2016-09-02 22:45:49 --> Severity: Notice --> Undefined variable: restaurants C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 4
ERROR - 2016-09-02 22:45:49 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:46:19 --> Severity: Notice --> Undefined variable: restaurants C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 4
ERROR - 2016-09-02 22:46:19 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:49:10 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 46
ERROR - 2016-09-02 22:49:21 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 24
ERROR - 2016-09-02 22:49:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 24
ERROR - 2016-09-02 22:49:22 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:49:44 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 24
ERROR - 2016-09-02 22:49:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 24
ERROR - 2016-09-02 22:49:45 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:51:03 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 34
ERROR - 2016-09-02 22:51:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\restaurants.php 34
ERROR - 2016-09-02 22:51:04 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:52:16 --> Query error: Unknown column 'locationname' in 'order clause' - Invalid query: SELECT count(id) as count
FROM `tbl_vendors`
WHERE `location` IS NULL
ORDER BY `locationname` ASC
ERROR - 2016-09-02 22:52:16 --> Query error: Unknown column 'location' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1472853136
WHERE `location` IS NULL
AND `id` = 'f019fce07376300e64091fdd79942ac7cefe4772'
ORDER BY `locationname` ASC
ERROR - 2016-09-02 22:52:57 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:54:38 --> 404 Page Not Found: web/Resources/web
ERROR - 2016-09-02 22:54:41 --> Severity: Notice --> Undefined variable: restaurant C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 35
ERROR - 2016-09-02 22:54:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 35
ERROR - 2016-09-02 22:54:41 --> Severity: Notice --> Undefined variable: rest C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 40
ERROR - 2016-09-02 22:54:41 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\web\Restaurants.php 40
ERROR - 2016-09-02 22:54:42 --> 404 Page Not Found: web/Restaurants/resources
ERROR - 2016-09-02 22:55:44 --> 404 Page Not Found: web/Restaurants/resources
ERROR - 2016-09-02 23:09:48 --> 404 Page Not Found: web/Restaurants/resources
ERROR - 2016-09-02 23:12:31 --> 404 Page Not Found: web/Restaurants/resources
