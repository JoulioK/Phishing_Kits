<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-14 00:36:36 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 00:36:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 00:36:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 06:52:14 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 09:59:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:12:04 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:16:53 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:17:03 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:17:23 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:18:34 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:18:45 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:18:56 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:19:07 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:19:41 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:20:13 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-14 10:34:38 --> Severity: Notice --> Undefined variable: limit C:\xampp\htdocs\charity\application\controllers\management\Orders.php 143
ERROR - 2017-02-14 10:34:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.r' at line 2 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	       JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated='2017-02-11 10:34:38' AND
		   tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, '' ORDER BYtbl_ph.id ASC
ERROR - 2017-02-14 10:42:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.r' at line 2 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	       JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated='2017-02-11 10:42:03' AND
		   tbl_users.userid NOT IN (select userid FROM tbl_gh) ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 10:43:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.r' at line 2 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	       JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-11 10:43:37' AND
		   tbl_users.userid NOT IN (select distinct(userid) FROM tbl_gh) ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 10:43:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.r' at line 2 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	       JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-11 10:43:38' AND
		   tbl_users.userid NOT IN (select distinct(userid) FROM tbl_gh) ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 10:44:57 --> Severity: Notice --> Undefined property: mysqli::$username C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Undefined property: mysqli::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Undefined property: mysqli::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Undefined property: mysqli_result::$username C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Undefined property: mysqli_result::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Undefined property: mysqli_result::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 58
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:44:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\release.php 64
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:46:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:55 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:56 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:48:57 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\release.php 61
ERROR - 2017-02-14 10:58:35 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 11:14:39 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 11:38:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.r' at line 2 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	            JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-09 11:38:43' AND
				tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, '7' ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 11:40:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'tbl_users.userid,tbl_users.username,tbl_users.emailaddress,tbl_users.fullname,tb' at line 1 - Invalid query: tbl_users.userid,tbl_users.username,tbl_users.emailaddress,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	            FROM tbl_users JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-09 11:40:03' 
                AND tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, '7' ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 11:40:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''7' ORDER BY tbl_ph.id ASC' at line 3 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.emailaddress,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	            FROM tbl_users JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-09 11:40:38' 
                AND tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, '7' ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 11:40:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''7' ORDER BY tbl_ph.id ASC' at line 3 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.emailaddress,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	            FROM tbl_users JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-09 11:40:44' 
                AND tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, '7' ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 11:41:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY tbl_ph.id ASC' at line 3 - Invalid query: SELECT tbl_users.userid,tbl_users.username,tbl_users.emailaddress,tbl_users.fullname,tbl_users.earning,tbl_users.accountnumber,tbl_users.accountname,tbl_users.bankname,tbl_ph.maturityamount,tbl_ph.phid 
	            FROM tbl_users JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-09 11:41:01' 
                AND tbl_users.userid NOT IN (select userid FROM tbl_gh) LIMIT 0, 7 ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 11:47:32 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 223
ERROR - 2017-02-14 11:47:39 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 223
ERROR - 2017-02-14 11:47:44 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 223
ERROR - 2017-02-14 11:47:49 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 223
ERROR - 2017-02-14 11:47:52 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 223
ERROR - 2017-02-14 12:23:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 12:50:18 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 15:03:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 15:27:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'where paymentstatus=1) ORDER BY tbl_ph.id ASC' at line 2 - Invalid query: SELECT count(tbl_users.userid) as countts FROM tbl_users JOIN tbl_ph ON tbl_ph.userid=tbl_users.userid WHERE tbl_ph.status=1 AND tbl_ph.reserved=0 AND tbl_users.isguilder=0 AND tbl_users.enabled=1 AND tbl_ph.datecreated<='2017-02-10 15:27:24' 
	            AND tbl_ph.userid IN (select userid FROM tbl_gh WHERE where paymentstatus=1) ORDER BY tbl_ph.id ASC
ERROR - 2017-02-14 15:29:32 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\charity\application\controllers\management\Orders.php 188
ERROR - 2017-02-14 15:34:24 --> Query error: Unknown column 'tbl_gh' in 'where clause' - Invalid query: SELECT `tbl_users`.`userid`, `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`earning`, `tbl_users`.`accountnumber`, `tbl_users`.`accountname`, `tbl_users`.`bankname`, `tbl_ph`.`maturityamount`, `tbl_ph`.`phid`
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_users`.`enabled` = 1
AND `tbl_ph`.`datecreated` <= '2017-02-10 15:34:24'
AND `tbl_gh` <= '2017-02-10 15:34:24'
ORDER BY `tbl_ph`.`id` ASC
 LIMIT 10
ERROR - 2017-02-14 15:34:24 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487082864
WHERE `tbl_ph`.`status` = 1
AND `tbl_ph`.`reserved` =0
AND `tbl_users`.`isguilder` =0
AND `tbl_users`.`enabled` = 1
AND `tbl_ph`.`datecreated` <= '2017-02-10 15:34:24'
AND `tbl_gh` <= '2017-02-10 15:34:24'
AND `id` = 'a5097cbd2e4ad32c5be8aca0acf2e05f43f2a500'
ORDER BY `tbl_ph`.`id` ASC LIMIT 10
ERROR - 2017-02-14 15:38:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Orders.php 206
ERROR - 2017-02-14 15:38:20 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Orders.php 207
ERROR - 2017-02-14 15:47:21 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 16:26:00 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 16:38:19 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-14 17:02:28 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\management\Orders.php 516
ERROR - 2017-02-14 17:02:28 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\charity\application\controllers\management\Orders.php 516
ERROR - 2017-02-14 17:06:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '14854413387887im,'14862404562339av,'14858511900536vy,'14861159897569zq,'14857862' at line 1 - Invalid query: SELECT userid FROM tbl_gh WHERE paymentstatus=1 AND userid IN ('14854233775848ad,'14854413387887im,'14862404562339av,'14858511900536vy,'14861159897569zq,'14857862194285ih,'14856491423690xa,'14863310642607uj,'14857189327095il,'14864924953664ly,'14864967745085ai,'14864964397350js,'14859603198884yx,'14859589330975yr,'14865065673579ho,'14859464284136rr,'14862272332064zu,'14855091698372je,'14865588049862vs,'14865221624026al,'14865605318383au,'14861499484033ya,'14857657903864bs,'14856791623332do,'14859366713599tg,'14857773121520zg,'14858897669092ql,'14862010980873yz,'14860650942305ol,'14862909326245sp,'14862316804042lu,'14860794220891nu,'14862004332731wv,'14858897669092ql,'14857862194285ih,'14860794220891nu,'14856491423690xa,'14865065673579ho,'14857189327095il,'14863310642607uj,'14862010980873yz,'14865414845197tx,'14863843216764nf,'14865827174910lm,'14862364787215vc,'14866324701659rg,'14861220690954sj,'14866359594972wi,'14866363401651ok,'14866257115754us,'14866324582377jr,'14865826208466wv,'14866335342580vx,'14865706726819pk,'14866258951338nt,'14865811670771ij,'14865518585279ey,'14863864963712tw,'14866371976162qv,'14866374965962nd,'14864877076945zv,'14865939376081kb,'14865584312861tx,'14863712942866kr,'14866366260012kf,'14865571133780jp,'14863835457688xz,'14865909920207gz,'14866313778750tu,'14864953028627hx,'14866355763789vs,'14864841606598as,'14866368129217or,'14866328197013gi,'14866277691442ha,'14866369994707qb,'14865142053510sc,'14865363735832lu,'14866332879086yf,'14865672946992jg,'14861972714618ja,'14865508612678ad,'14866371266420uo,'14864732498048wf,'14862779638179vl,'14865543458241tl,'14862435392372ps,'14865719334677wv,'14862866159291mo,'14866334175216bs,'14866373498079ll,'14866359750512bd,'14862212872984ir,'14866375032657py,'14860283624502tg,'14865828599059jt,'14866340207750on,'14857680377826xl,'14865833337273ul,'14866323365769yh,'14865723608808tt,'14865449719330qz,'14866387773616fv,'14864669917490xu,'14866388915757nk,'14866390314016tm,'14865759780906df,'14866331085461tc,'14865059791582va,'14866546806743jb,'14866587833093pd,'14865471303326as,'14863823604638ot,'14864660504130ei,'14865584312861tx,'14866312272019gz,'14864971289576rb,'14866441638360sq,'14866621916178lj,'14866449826743rq,'14866501450931rq,'14865517536899xr,'14866391123092ty,'14864134938255rr,'14865909920207gz,'14866358850678nn,'14866501791967kk,'14866396398957fx,'14866136933612vx,'14865773018067nc,'14865657652682ll,'14864854632263tw,'14865802498915rw,'14866339115694it,'14862323277397cc,'14865492530856si,'14866544136213rr,'14866371307993an,'14865703592501yw,'14866293677474vu,'14866565411495av,'14867230580875yt,'14867235494145uw,'14866741338911pt,'14867238928580is,'14867226142204jt,'14866416305173yo,'14867220288208tg,'14867226912079uq,'14866685615626ng,'14867186465189if,'14866757217981qj,'14863699496591wx,'14867239776661vr,'14865956149473gg,'14864742133702lj,'14860270884486yi,'14867213618046cl,'14867226545337ep,'14867184734629oh,'14867230856981aw,'14866614769867st,'14863141004137lo,'14866333068246bi,'14866533144858es,'14866832259487rt,'14866665421699xn,'14864924953664ly,'14867239776661vr,'14864686122080gj,'14861333637186pm,'14867248258330qn,'14865723608808tt,'14867128402173ti,'14864596679658im,'14867050558046dy,'14865052475543ex,'14867193458818vv,'14861454738626ki,'14867226142204jt,'14867111657213kq,'14862323277397cc,'14866685615626ng,'14864626102599xj,'14866269685154de,'14867273444258vs,'14866476306947ul,'14867226912079uq')
ERROR - 2017-02-14 18:39:42 --> 404 Page Not Found: management/Js/classie.js
