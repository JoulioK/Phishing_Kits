<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-03 03:41:08 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-05-03 06:40:08 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
