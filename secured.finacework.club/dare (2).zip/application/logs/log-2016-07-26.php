<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-26 00:25:07 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\home.php 113
ERROR - 2016-07-26 00:25:09 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\home.php 113
ERROR - 2016-07-26 00:27:37 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\home.php 112
ERROR - 2016-07-26 00:28:07 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\fastfood\application\controllers\app\home.php 126
ERROR - 2016-07-26 00:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Undefined property: stdClass::$vendorname C:\xampp\htdocs\fastfood\application\controllers\app\home.php 88
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Undefined property: stdClass::$vendorname C:\xampp\htdocs\fastfood\application\controllers\app\home.php 88
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Undefined property: stdClass::$vendorname C:\xampp\htdocs\fastfood\application\controllers\app\home.php 88
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Undefined property: stdClass::$vendorname C:\xampp\htdocs\fastfood\application\controllers\app\home.php 88
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 101
ERROR - 2016-07-26 00:31:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:33:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:34:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:35:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:35:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:35:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:35:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:35:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:35:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:35:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:37:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:40:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:41:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:43:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:32 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:52 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 00:59:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:00:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:02:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 102
ERROR - 2016-07-26 01:05:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 104
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 104
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
ERROR - 2016-07-26 01:07:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 104
ERROR - 2016-07-26 01:08:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 09:31:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-26 21:52:36 --> 404 Page Not Found: app/Item/cart
ERROR - 2016-07-26 22:04:46 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\item.php 88
ERROR - 2016-07-26 22:04:47 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 91
ERROR - 2016-07-26 22:04:59 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\app\item.php 88
ERROR - 2016-07-26 22:04:59 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 91
ERROR - 2016-07-26 23:51:22 --> 404 Page Not Found: app/Item/shippingaddress
ERROR - 2016-07-26 23:54:56 --> Severity: Notice --> Undefined property: stdClass::$userid C:\xampp\htdocs\fastfood\application\controllers\app\item.php 90
ERROR - 2016-07-26 23:54:56 --> Severity: Notice --> Undefined variable: shippingaddresses C:\xampp\htdocs\fastfood\application\controllers\app\item.php 121
