<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-27 09:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:11:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:11:31 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\snappycoin\application\views\web\pages\address.php 32
ERROR - 2016-11-27 09:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:11:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-27 09:57:08 --> 404 Page Not Found: web/Checkout/index
ERROR - 2016-11-27 10:01:08 --> Severity: Notice --> Use of undefined constant address - assumed 'address' C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 16
ERROR - 2016-11-27 10:02:16 --> Severity: Notice --> Use of undefined constant address - assumed 'address' C:\xampp\htdocs\snappycoin\application\views\web\pages\checkout.php 16
