<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-31 10:34:09 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:34:09 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:34:09 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:34:14 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:34:14 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:34:14 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:34:17 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:34:17 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:34:17 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:34:19 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:34:19 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:34:19 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:36:24 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:36:24 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:36:24 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:38:59 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:38:59 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:38:59 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:39:59 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:41:04 --> Severity: Notice --> Undefined property: stdClass::$phonenumber C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 10:41:04 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:41:04 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 10:43:19 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 54
ERROR - 2016-07-31 10:43:20 --> Severity: Notice --> Undefined property: stdClass::$count C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 73
ERROR - 2016-07-31 11:46:34 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 113
ERROR - 2016-07-31 11:46:48 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 113
ERROR - 2016-07-31 11:46:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-31 11:47:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 46
ERROR - 2016-07-31 11:47:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 47
ERROR - 2016-07-31 11:47:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\settings.php 48
ERROR - 2016-07-31 12:43:28 --> Severity: Notice --> Undefined property: Authenticate::$home_model C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 117
ERROR - 2016-07-31 12:43:28 --> Severity: Error --> Call to a member function hash() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 117
ERROR - 2016-07-31 12:43:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 113
ERROR - 2016-07-31 12:43:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 114
ERROR - 2016-07-31 12:43:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 115
ERROR - 2016-07-31 12:43:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 116
ERROR - 2016-07-31 12:43:41 --> Severity: Notice --> Undefined property: Authenticate::$home_model C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 117
ERROR - 2016-07-31 12:43:41 --> Severity: Error --> Call to a member function hash() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 117
ERROR - 2016-07-31 15:55:49 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 15:56:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 15:56:16 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 15:56:21 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 16:00:20 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 16:00:48 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 16:00:58 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 42
ERROR - 2016-07-31 21:57:53 --> Severity: Parsing Error --> syntax error, unexpected '$status' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 167
ERROR - 2016-07-31 21:58:06 --> Severity: Parsing Error --> syntax error, unexpected '$status' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 167
ERROR - 2016-07-31 21:58:34 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 169
ERROR - 2016-07-31 22:00:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:00:17 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 202
ERROR - 2016-07-31 22:01:40 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:01:40 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 204
ERROR - 2016-07-31 22:01:49 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:01:49 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 204
ERROR - 2016-07-31 22:02:35 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:02:36 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 204
ERROR - 2016-07-31 22:03:04 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (2454)
ERROR - 2016-07-31 22:03:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:03:12 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 204
ERROR - 2016-07-31 22:04:45 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (6676)
ERROR - 2016-07-31 22:04:49 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (5003)
ERROR - 2016-07-31 22:04:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
ERROR - 2016-07-31 22:05:12 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (7206)
ERROR - 2016-07-31 22:05:48 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (2635)
ERROR - 2016-07-31 22:13:25 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (3120)
ERROR - 2016-07-31 22:15:02 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (5336)
ERROR - 2016-07-31 22:15:05 --> Query error: Unknown column 'code' in 'field list' - Invalid query: INSERT INTO `tbl_users` (`code`) VALUES (9388)
ERROR - 2016-07-31 22:16:01 --> Query error: Unknown column 'code' in 'field list' - Invalid query: UPDATE `tbl_users` SET `code` = 2044
WHERE `emailaddress` = 'olafashade@hotmail.com'
ERROR - 2016-07-31 22:16:03 --> Query error: Unknown column 'code' in 'field list' - Invalid query: UPDATE `tbl_users` SET `code` = 1836
WHERE `emailaddress` = 'olafashade@hotmail.com'
ERROR - 2016-07-31 22:25:51 --> Severity: Error --> Call to undefined function url_encode() C:\xampp\htdocs\fastfood\application\core\MY_Model.php 218
ERROR - 2016-07-31 22:28:28 --> Severity: Error --> Call to undefined function url_encode() C:\xampp\htdocs\fastfood\application\core\MY_Model.php 218
ERROR - 2016-07-31 22:28:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\authenticate.php 148
