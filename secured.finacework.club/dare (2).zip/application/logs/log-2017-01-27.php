<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 122
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 122
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 123
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 123
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 124
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 124
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 125
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 125
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 126
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 126
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 128
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 128
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 132
ERROR - 2017-01-27 01:06:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 132
ERROR - 2017-01-27 01:06:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:06:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 32
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 43
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 70
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 122
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 123
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 124
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 125
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 126
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 128
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 132
ERROR - 2017-01-27 01:13:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:16:11 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 32
ERROR - 2017-01-27 01:16:11 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 43
ERROR - 2017-01-27 01:16:11 --> Severity: Notice --> Undefined variable: ghs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 70
ERROR - 2017-01-27 01:16:11 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 117
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 122
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 123
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 124
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 125
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 126
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 128
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 132
ERROR - 2017-01-27 01:17:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 121
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 122
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 123
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 124
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 125
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 126
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 128
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 129
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 130
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 132
ERROR - 2017-01-27 01:22:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 133
ERROR - 2017-01-27 01:25:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 139
ERROR - 2017-01-27 01:35:40 --> Severity: Error --> Call to undefined function num_format() C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 163
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 160
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 161
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 164
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 165
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 166
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 167
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 170
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 172
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 173
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 173
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 173
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 175
ERROR - 2017-01-27 01:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 177
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 118
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 146
ERROR - 2017-01-27 02:28:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 147
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 118
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 146
ERROR - 2017-01-27 02:29:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 147
ERROR - 2017-01-27 02:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 118
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 146
ERROR - 2017-01-27 02:29:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 147
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 118
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 146
ERROR - 2017-01-27 02:32:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 147
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 115
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 116
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 118
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 144
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 146
ERROR - 2017-01-27 02:32:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 147
ERROR - 2017-01-27 04:02:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\incoming.php 68
ERROR - 2017-01-27 04:16:24 --> Query error: Unknown column 'reserved' in 'field list' - Invalid query: INSERT INTO `tbl_gh` (`reserved`, `fullname`, `accountname`, `accountnumber`, `bankname`, `amount`, `userid`, `ghid`, `datemodified`, `datecreated`) VALUES (1, 'babaru', 'Rotowa Odunayo james', '0029040367', 'GTB', 218, '14854009465886pm', '14854869849489us', '2017-01-27 04:16:24', '2017-01-27 04:16:24')
ERROR - 2017-01-27 09:09:42 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\charity\application\controllers\management\Orders.php 134
ERROR - 2017-01-27 09:10:37 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\charity\application\controllers\management\Orders.php 166
ERROR - 2017-01-27 09:18:32 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 80
ERROR - 2017-01-27 09:22:28 --> Query error: Unknown table 'tbl_ph' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_user`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_ph`.*, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-27 09:22:28 --> Query error: Unknown column 'tbl_users.emailaddress' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485505348
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 09:23:03 --> Query error: Unknown table 'tbl_ph' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_user`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_ph`.*, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-27 09:23:03 --> Query error: Unknown column 'tbl_users.emailaddress' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485505383
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 09:24:09 --> Query error: Unknown column 'tbl_user.emailaddress' in 'field list' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_user`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-27 09:24:09 --> Query error: Unknown column 'tbl_users.emailaddress' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485505449
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 09:29:29 --> Query error: Unknown column 'tbl_user.emailaddress' in 'field list' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_user`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-27 09:29:29 --> Query error: Unknown column 'tbl_users.emailaddress' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485505769
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 09:32:59 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 29
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 35
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 35
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 40
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 40
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 46
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 46
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 52
ERROR - 2017-01-27 09:33:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 52
ERROR - 2017-01-27 09:39:48 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 89
ERROR - 2017-01-27 09:40:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:40:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:40:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:40:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:42:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:42:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:42:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:42:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:43:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:43:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:43:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:43:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:44:39 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:44:39 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:44:39 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 80
ERROR - 2017-01-27 09:44:39 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:45:27 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:45:27 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 09:45:27 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:45:27 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 09:47:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:47:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 09:47:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:47:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 09:47:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:47:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 09:47:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 81
ERROR - 2017-01-27 09:47:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\view_gh.php 82
ERROR - 2017-01-27 11:34:24 --> Query error: Unknown column 'tbl_user.emailaddress' in 'field list' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`fullname`, `tbl_users`.`userid`, `tbl_user`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_ph`.*
FROM `tbl_users`
JOIN `tbl_ph` ON `tbl_ph`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
ERROR - 2017-01-27 11:34:24 --> Query error: Unknown column 'tbl_users.emailaddress' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485513264
WHERE `tbl_users`.`emailaddress` = 'olafashade@hotmail.com'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 11:34:45 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 84
ERROR - 2017-01-27 11:34:45 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 89
ERROR - 2017-01-27 11:34:45 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 84
ERROR - 2017-01-27 11:34:45 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 89
ERROR - 2017-01-27 11:35:14 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 89
ERROR - 2017-01-27 11:35:14 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 89
ERROR - 2017-01-27 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 86
ERROR - 2017-01-27 11:35:38 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\management\orders\view_ph.php 86
ERROR - 2017-01-27 11:38:18 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:38:18 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:38:18 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:38:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:08 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 99
ERROR - 2017-01-27 11:39:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 100
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 92
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 92
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 92
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 92
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 92
ERROR - 2017-01-27 11:42:05 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 93
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:42:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:44:40 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\charity\application\views\management\orders\pledges.php 85
ERROR - 2017-01-27 11:44:40 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\charity\application\views\management\orders\pledges.php 85
ERROR - 2017-01-27 11:44:40 --> Severity: Notice --> Undefined property: stdClass::$email C:\xampp\htdocs\charity\application\views\management\orders\pledges.php 85
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:19 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:45:26 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:49:37 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:50:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:14 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 11:51:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:06 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:07 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:21:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:42 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-27 12:22:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-27 15:24:01 --> Query error: Column 'userid' in field list is ambiguous - Invalid query: SELECT `userid`
FROM `tbl_users`, `management_users`
WHERE `isguilder` = 1
ERROR - 2017-01-27 15:24:01 --> Query error: Unknown column 'isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485527041
WHERE `isguilder` = 1
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 17:02:25 --> 404 Page Not Found: management/User/adddummyguilder
ERROR - 2017-01-27 17:02:34 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' C:\xampp\htdocs\charity\application\controllers\management\Users.php 392
ERROR - 2017-01-27 17:03:22 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 91
ERROR - 2017-01-27 17:03:54 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 98
ERROR - 2017-01-27 17:04:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 45
ERROR - 2017-01-27 17:04:05 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 69
ERROR - 2017-01-27 17:04:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 69
ERROR - 2017-01-27 17:05:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 45
ERROR - 2017-01-27 17:05:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 69
ERROR - 2017-01-27 17:05:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 69
ERROR - 2017-01-27 17:05:35 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 64
ERROR - 2017-01-27 17:05:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 64
ERROR - 2017-01-27 17:25:30 --> Severity: Compile Error --> Cannot redeclare Users::adddummyguilder() C:\xampp\htdocs\charity\application\controllers\management\Users.php 499
ERROR - 2017-01-27 17:25:52 --> Query error: Unknown column 'dummyguilder' in 'where clause' - Invalid query: SELECT *
FROM `tbl_users`
WHERE `dummyguilder` = 1
ERROR - 2017-01-27 17:25:52 --> Query error: Unknown column 'dummyguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485534352
WHERE `dummyguilder` = 1
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 17:35:42 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 80
ERROR - 2017-01-27 17:35:42 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 80
ERROR - 2017-01-27 17:35:42 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 80
ERROR - 2017-01-27 17:35:42 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 80
ERROR - 2017-01-27 17:36:53 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 83
ERROR - 2017-01-27 17:36:53 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 83
ERROR - 2017-01-27 17:36:53 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 83
ERROR - 2017-01-27 17:36:53 --> Severity: Notice --> Undefined property: stdClass::$accountumber C:\xampp\htdocs\charity\application\views\management\users\dummy_guilder.php 83
ERROR - 2017-01-27 17:42:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 3 - Invalid query: SELECT `ghid`
FROM `tbl_gh`
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
ERROR - 2017-01-27 17:42:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485535320
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 17:43:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 3 - Invalid query: SELECT `ghid`
FROM `tbl_gh`
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
ERROR - 2017-01-27 17:43:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485535401
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 17:43:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 3 - Invalid query: SELECT `ghid`
FROM `tbl_gh`
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
ERROR - 2017-01-27 17:43:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','148' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485535419
WHERE userid in '14853742757197xj','14853825878672yc','14853868521833kg','14853877239563yk','14853907689801uh','14853946163915jw','14853960920947nr','14853966231259wb','14854163783750of','14854180638280gb','14854189337733hg','14854206871244hq','14854210402705vg','14854223701454ov','14855085758813tw','14855104355382ms'
AND `phuser` IS NULL
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 18:00:15 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 357
ERROR - 2017-01-27 18:00:15 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 358
ERROR - 2017-01-27 18:00:15 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 359
ERROR - 2017-01-27 18:00:15 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 360
ERROR - 2017-01-27 18:00:17 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 371
ERROR - 2017-01-27 18:00:17 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 372
ERROR - 2017-01-27 18:00:17 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 373
ERROR - 2017-01-27 18:00:17 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 374
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 385
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 357
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 358
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 359
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 360
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 371
ERROR - 2017-01-27 18:00:18 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 372
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 373
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 374
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 357
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 358
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 359
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 360
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 371
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 372
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 373
ERROR - 2017-01-27 18:00:19 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 374
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 357
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 358
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 359
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 360
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Users.php 371
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\charity\application\controllers\management\Users.php 372
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$accountnumber C:\xampp\htdocs\charity\application\controllers\management\Users.php 373
ERROR - 2017-01-27 18:00:20 --> Severity: Notice --> Undefined property: stdClass::$bankname C:\xampp\htdocs\charity\application\controllers\management\Users.php 374
ERROR - 2017-01-27 18:00:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\system\helpers\url_helper.php 564
ERROR - 2017-01-27 18:02:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 385
ERROR - 2017-01-27 18:09:11 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 385
ERROR - 2017-01-27 18:14:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 55
ERROR - 2017-01-27 18:14:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 73
ERROR - 2017-01-27 18:14:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 78
ERROR - 2017-01-27 18:14:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 83
ERROR - 2017-01-27 18:14:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 93
ERROR - 2017-01-27 18:52:18 --> Query error: Unknown column 'sponsor' in 'field list' - Invalid query: SELECT `sponsor`
FROM `tbl_ph`
WHERE `userid` = '14853742757197xj'
ERROR - 2017-01-27 18:52:18 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485539538
WHERE `userid` = '14853742757197xj'
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 19:57:10 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-27 19:58:01 --> Query error: Unknown column 'tbl_guilder_gh.dummyguilder' in 'where clause' - Invalid query: SELECT `tbl_guilder_gh`.*, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.`paymentstatus` as `paymentconfirmed`, `tbl_gh`.`datepaid` as `userdatepaid`
FROM `tbl_guilder_gh`
LEFT JOIN `tbl_gh` ON `tbl_guilder_gh`.`ghid`=`tbl_gh`.`ghid`
LEFT JOIN `tbl_users` ON `tbl_guilder_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_guilder_gh`.`dummyguilder` = 1
ERROR - 2017-01-27 19:58:01 --> Query error: Unknown column 'tbl_guilder_gh.dummyguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485543481
WHERE `tbl_guilder_gh`.`dummyguilder` = 1
AND `id` = '8569660ecbf9e55f9b4d89e06fa6b3c1dfd9c115'
ERROR - 2017-01-27 20:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 55
ERROR - 2017-01-27 20:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 73
ERROR - 2017-01-27 20:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 78
ERROR - 2017-01-27 20:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 83
ERROR - 2017-01-27 20:01:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_users.php 93
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 51
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 58
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 65
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 72
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 79
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 87
ERROR - 2017-01-27 20:17:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\create_dummy_guilder.php 94
