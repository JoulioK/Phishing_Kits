<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-15 00:07:06 --> Severity: Notice --> Undefined variable: ch C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 328
ERROR - 2016-12-15 00:07:06 --> Severity: Warning --> curl_setopt() expects parameter 1 to be resource, null given C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 331
ERROR - 2016-12-15 00:27:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 341
ERROR - 2016-12-15 00:43:33 --> Severity: Parsing Error --> syntax error, unexpected 'print_r' (T_STRING) C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 342
ERROR - 2016-12-15 00:49:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\web\Item.php 348
ERROR - 2016-12-15 08:47:11 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-15 10:18:27 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 23
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 23
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 24
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 24
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 30
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 30
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 38
ERROR - 2016-12-15 10:19:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 38
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 48
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 48
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 54
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 54
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 59
ERROR - 2016-12-15 10:19:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\management\configuration\dailyrate.php 59
ERROR - 2016-12-15 15:46:25 --> 404 Page Not Found: Ref/14675775313398tp
ERROR - 2016-12-15 15:54:11 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:54:33 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:54:35 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:54:36 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:54:41 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:54:45 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:05 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:08 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:08 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:09 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:09 --> 404 Page Not Found: web/Ref/14675775313398tp
ERROR - 2016-12-15 15:55:09 --> 404 Page Not Found: web/Ref/14675775313398tp
