<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-17 09:08:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-17 09:21:36 --> Severity: Error --> Call to undefined method CI_Session::user() C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 3
ERROR - 2016-08-17 09:26:06 --> 404 Page Not Found: Settings/shipping_address
ERROR - 2016-08-17 09:39:43 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:39:52 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:39:59 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:00 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:01 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:02 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:02 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:03 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:04 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:40:04 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:19 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:20 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:21 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:21 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:21 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:22 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:22 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:23 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:24 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:42:24 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:43:21 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:44:11 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:44:11 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:45:43 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:45:44 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:45:45 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:45:45 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:45:46 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:22 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:24 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:24 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:25 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:25 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:25 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:26 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:26 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:27 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:47:27 --> Severity: error --> Exception: Configured database connection is persistent. Aborting. C:\xampp\htdocs\fastfood\system\libraries\Session\drivers\Session_database_driver.php 94
ERROR - 2016-08-17 09:49:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:49:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:49:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:49:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:52:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:52:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:52:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:52:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:52:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 09:58:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'' at line 2 - Invalid query: SELECT `data`
WHERE `id` = 'e84c29fed9c205091577e681810e1a7793e6aa2c'
ERROR - 2016-08-17 10:25:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'snappyme_olafash'@'localhost' (using password: YES) C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-08-17 10:25:01 --> Unable to connect to the database
ERROR - 2016-08-17 11:14:02 --> 404 Page Not Found: web/Settings/delete_address
ERROR - 2016-08-17 11:32:30 --> Severity: Error --> Call to undefined function html_entities() C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 38
