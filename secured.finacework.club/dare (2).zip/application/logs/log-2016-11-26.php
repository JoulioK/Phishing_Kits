<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-26 14:58:17 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 14:59:09 --> Severity: Notice --> Undefined property: stdClass::$usd C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 14:59:36 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 15:00:26 --> Severity: Notice --> Undefined property: stdClass::$usd C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 15:01:27 --> Severity: Notice --> Undefined property: stdClass::$usd C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 15:01:48 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 15:02:00 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 15:04:30 --> Severity: Error --> Cannot use object of type stdClass as array C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 16:32:02 --> Severity: Warning --> file_get_contents(): php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 16:32:02 --> Severity: Warning --> file_get_contents(http://api.coindesk.com/v1/bpi/currentprice.json): failed to open stream: php_network_getaddresses: getaddrinfo failed: No such host is known.  C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 16:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 16:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 16:32:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\views\web\_layouts\header.php 93
ERROR - 2016-11-26 17:22:06 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 22
ERROR - 2016-11-26 17:22:06 --> Severity: Notice --> Undefined property: stdClass::$driverslicense C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 43
ERROR - 2016-11-26 17:22:06 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 48
ERROR - 2016-11-26 17:23:28 --> Severity: Notice --> Undefined property: stdClass::$driverslicense C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 50
ERROR - 2016-11-26 17:23:28 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 55
ERROR - 2016-11-26 17:26:26 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 55
ERROR - 2016-11-26 17:29:52 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 55
ERROR - 2016-11-26 17:30:20 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 55
ERROR - 2016-11-26 17:30:41 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 54
ERROR - 2016-11-26 17:31:26 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 54
ERROR - 2016-11-26 17:31:33 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 54
ERROR - 2016-11-26 17:31:51 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 53
ERROR - 2016-11-26 17:32:14 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\snappycoin\application\views\web\customer\profile.php 53
ERROR - 2016-11-26 17:55:09 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF) C:\xampp\htdocs\snappycoin\application\controllers\web\Customer.php 98
ERROR - 2016-11-26 18:52:12 --> 404 Page Not Found: web/Transactions/index
ERROR - 2016-11-26 18:55:12 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 36
ERROR - 2016-11-26 18:55:12 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-26 18:55:12 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480182912
WHERE `userid` = '14675775313398tp'
AND `id` = '07fe67b551b5ee25978d624efbbcae4f6d5fe248'
ORDER BY `id` ASC
ERROR - 2016-11-26 18:55:38 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\snappycoin\application\views\web\customer\trends.php 36
ERROR - 2016-11-26 18:55:39 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-26 18:55:39 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480182939
WHERE `userid` = '14675775313398tp'
AND `id` = '07fe67b551b5ee25978d624efbbcae4f6d5fe248'
ORDER BY `id` ASC
ERROR - 2016-11-26 19:51:09 --> Severity: Parsing Error --> syntax error, unexpected '$return' (T_VARIABLE) C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 303
ERROR - 2016-11-26 20:08:56 --> 404 Page Not Found: web/Buy/index
ERROR - 2016-11-26 20:12:46 --> Severity: Notice --> Undefined variable: naira C:\xampp\htdocs\snappycoin\application\views\web\_layouts\banner.php 12
