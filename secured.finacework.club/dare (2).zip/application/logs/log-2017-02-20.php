<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-20 09:05:31 --> Severity: Parsing Error --> syntax error, unexpected 'welcome' (T_STRING), expecting variable (T_VARIABLE) C:\xampp\htdocs\charity\application\controllers\web\User.php 113
ERROR - 2017-02-20 16:46:02 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
ERROR - 2017-02-20 16:49:48 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
ERROR - 2017-02-20 16:56:47 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
ERROR - 2017-02-20 16:58:01 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
ERROR - 2017-02-20 16:58:10 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
ERROR - 2017-02-20 16:58:43 --> Severity: Notice --> Undefined property: stdClass::$graceperiod C:\xampp\htdocs\charity\application\controllers\web\Auth.php 165
