<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-08 18:16:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'corpersl_olafash'@'localhost' (using password: YES) C:\xampp\htdocs\caroossa\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-11-08 18:16:37 --> Unable to connect to the database
ERROR - 2016-11-08 18:46:25 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:46:25 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:46:26 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:46:26 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:49:18 --> Severity: Parsing Error --> syntax error, unexpected '=' C:\xampp\htdocs\caroossa\application\controllers\web\Home.php 27
ERROR - 2016-11-08 18:49:40 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:49:40 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:49:40 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:49:40 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:50:27 --> 404 Page Not Found: web/Css/zoomslider.css
ERROR - 2016-11-08 18:50:27 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:50:28 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:50:28 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:50:28 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:50:34 --> 404 Page Not Found: web/Css/zoomslider.css
ERROR - 2016-11-08 18:50:34 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:50:34 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:50:34 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:50:35 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:50:39 --> 404 Page Not Found: web/Css/zoomslider.css
ERROR - 2016-11-08 18:54:18 --> 404 Page Not Found: web/Css/zoomslider.css
ERROR - 2016-11-08 18:54:19 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:54:19 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:54:20 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:54:20 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:54:23 --> 404 Page Not Found: web/Css/zoomslider.css
ERROR - 2016-11-08 18:54:23 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:54:24 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 18:54:24 --> 404 Page Not Found: web/Js/jquery.zoomslider.min.js
ERROR - 2016-11-08 18:54:24 --> 404 Page Not Found: web/Js/jquery.flexisel.j
ERROR - 2016-11-08 21:12:36 --> 404 Page Not Found: management/Authenticate/index
ERROR - 2016-11-08 21:16:04 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-08 21:16:06 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-08 21:16:17 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-08 22:43:14 --> Query error: Table 'corperslodge.tbl_country' doesn't exist - Invalid query: SELECT *
FROM `tbl_country`
ERROR - 2016-11-08 22:43:49 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-08 22:43:54 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-08 22:44:51 --> Severity: Notice --> Undefined variable: parent C:\xampp\htdocs\caroossa\application\views\management\configuration\country.php 87
ERROR - 2016-11-08 22:51:57 --> Severity: Notice --> Undefined variable: parent C:\xampp\htdocs\caroossa\application\views\management\configuration\state.php 102
ERROR - 2016-11-08 22:52:51 --> Severity: Notice --> Undefined variable: parent C:\xampp\htdocs\caroossa\application\views\management\configuration\state.php 102
ERROR - 2016-11-08 22:55:16 --> 404 Page Not Found: management/Messages/index
