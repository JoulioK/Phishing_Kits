<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-08 23:57:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-08 23:57:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-08 23:59:29 --> 404 Page Not Found: Fastfood/authenticate
ERROR - 2016-07-08 23:59:45 --> 404 Page Not Found: Franchise/authenticate
ERROR - 2016-07-08 23:59:57 --> 404 Page Not Found: management/Js/classie.js
