<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-29 07:41:04 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 168
ERROR - 2017-01-29 07:49:15 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-29 23:14:36 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-29 23:15:45 --> Query error: Unknown column 'tbl_gh.status' in 'where clause' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`phonenumber`, `tbl_gh`.*
FROM `tbl_users`
JOIN `tbl_gh` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`status` =0
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-01-29 23:15:45 --> Query error: Unknown column 'tbl_gh.paymentstatus' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485728145
WHERE `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`tellernumber` IS NULL
AND `tbl_gh`.`status` =0
AND `id` = '2e0a552ae9fd550c606fc080626cdb2bb005ff7b'
ORDER BY `tbl_gh`.`id` ASC
ERROR - 2017-01-29 23:16:25 --> Severity: Notice --> Undefined variable: phwaitinglistcount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 12
ERROR - 2017-01-29 23:18:07 --> Severity: Notice --> Undefined variable: phwaitinglistcount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 12
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:18:42 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$emailaddress C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 38
ERROR - 2017-01-29 23:19:17 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:29 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:30 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:19:30 --> Severity: Notice --> Undefined property: stdClass::$maturityamount C:\xampp\htdocs\charity\application\views\management\orders\beneficiary.php 41
ERROR - 2017-01-29 23:43:30 --> 404 Page Not Found: management/Orders/split
ERROR - 2017-01-29 23:44:03 --> 404 Page Not Found: management/Orders/split
ERROR - 2017-01-29 23:44:48 --> 404 Page Not Found: management/Orders/split
ERROR - 2017-01-29 23:48:12 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 185
ERROR - 2017-01-29 23:48:49 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\charity\application\controllers\management\Orders.php 185
