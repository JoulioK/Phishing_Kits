<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 13:52:49 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 16:05:41 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\bitgiver\application\views\web\pages\home.php 68
ERROR - 2017-04-16 16:05:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\pages\home.php 68
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:15:42 --> 404 Page Not Found: web/Auth/images
ERROR - 2017-04-16 17:22:34 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\Auth.php 243
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:35 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:22:43 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 11
ERROR - 2017-04-16 17:22:43 --> Query error: Unknown column 'tbl_gh.accountname' in 'field list' - Invalid query: SELECT `tbl_gh`.`fullname`, `tbl_gh`.`accountname`, `tbl_gh`.`accountnumber`, `tbl_gh`.`bankname`, `tbl_gh`.`userid`, `tbl_gh`.`paymentstatus`, `tbl_ph`.*
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_ph`.`ghid`=`tbl_gh`.`ghid`
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`userid` = '14853742757197xj'
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 2
ERROR - 2017-04-16 17:22:43 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492359763, `data` = 'packageid|s:13:\"72728283838uj\";user_session|O:8:\"stdClass\":24:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:2:\"30\";s:14:\"bitcoinaddress\";N;s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;error|s:112:\"Please complete your <a href=\"http://localhost/bitgiver/index.php/web/user/profile\"> Profile Settings </a> first\";__ci_vars|a:1:{s:5:\"error\";s:3:\"new\";}'
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`userid` = '14853742757197xj'
AND `id` = '0b61a0b0ffb0f90cf1f48e7e3f62c65995c3e6e8'
ORDER BY `tbl_ph`.`id` DESC LIMIT 2
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:02 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:23:22 --> Query error: Unknown column 'tbl_gh.accountname' in 'field list' - Invalid query: SELECT `tbl_gh`.`fullname`, `tbl_gh`.`accountname`, `tbl_gh`.`accountnumber`, `tbl_gh`.`bankname`, `tbl_gh`.`userid`, `tbl_gh`.`paymentstatus`, `tbl_ph`.*
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_ph`.`ghid`=`tbl_gh`.`ghid`
WHERE `tbl_ph`.`userid` = '14853742757197xj'
ORDER BY `tbl_ph`.`id` desc
 LIMIT 10
ERROR - 2017-04-16 17:23:22 --> Query error: Unknown column 'tbl_ph.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492359802
WHERE `tbl_ph`.`userid` = '14853742757197xj'
AND `id` = '0b61a0b0ffb0f90cf1f48e7e3f62c65995c3e6e8'
ORDER BY `tbl_ph`.`id` desc LIMIT 10
ERROR - 2017-04-16 17:34:59 --> 404 Page Not Found: web/Images/2.jpg
ERROR - 2017-04-16 17:34:59 --> 404 Page Not Found: web/Images/3.jpg
ERROR - 2017-04-16 17:34:59 --> 404 Page Not Found: web/Images/5.jpg
ERROR - 2017-04-16 17:34:59 --> 404 Page Not Found: web/Images/6.jpg
ERROR - 2017-04-16 17:34:59 --> 404 Page Not Found: web/Images/7.jpg
ERROR - 2017-04-16 17:35:00 --> 404 Page Not Found: web/Images/4.jpg
ERROR - 2017-04-16 17:35:31 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 11
ERROR - 2017-04-16 17:35:31 --> Query error: Unknown column 'tbl_gh.accountname' in 'field list' - Invalid query: SELECT `tbl_gh`.`fullname`, `tbl_gh`.`accountname`, `tbl_gh`.`accountnumber`, `tbl_gh`.`bankname`, `tbl_gh`.`userid`, `tbl_gh`.`paymentstatus`, `tbl_ph`.*
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_ph`.`ghid`=`tbl_gh`.`ghid`
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`userid` = '14853742757197xj'
ORDER BY `tbl_ph`.`id` DESC
 LIMIT 2
ERROR - 2017-04-16 17:35:31 --> Query error: Unknown column 'tbl_ph.status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1492360531, `data` = 'packageid|s:13:\"72728283838uj\";user_session|O:8:\"stdClass\":24:{s:2:\"id\";s:2:\"33\";s:6:\"userid\";s:16:\"14853742757197xj\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";s:10:\"olafashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:14:\"+2348068752947\";s:8:\"password\";s:128:\"008e2a957b2563c72695f23cba3b6d94ad3be605051e51a67f530d29021246309c99c2c529d123b16fcce2476717d0ddf85dd72a0f8b70827f277c6c02b12444\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"2802\";s:7:\"sponsor\";s:16:\"14675775313398tp\";s:7:\"earning\";s:2:\"30\";s:14:\"bitcoinaddress\";N;s:12:\"perfectmoney\";N;s:12:\"skrilldollar\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:12:\"dummyguilder\";s:1:\"0\";s:10:\"socialtask\";s:1:\"1\";s:7:\"welcome\";s:1:\"1\";s:5:\"point\";s:1:\"8\";s:13:\"suspensionend\";N;s:16:\"suspensionreason\";N;s:11:\"datecreated\";s:19:\"2017-02-19 04:37:03\";s:12:\"datemodified\";s:19:\"2017-01-26 14:36:16\";}user_loggedin|b:1;error|s:112:\"Please complete your <a href=\"http://localhost/bitgiver/index.php/web/user/profile\"> Profile Settings </a> first\";__ci_vars|a:1:{s:5:\"error\";s:3:\"new\";}'
WHERE `tbl_ph`.`status` =0
AND `tbl_ph`.`userid` = '14853742757197xj'
AND `id` = '0b61a0b0ffb0f90cf1f48e7e3f62c65995c3e6e8'
ORDER BY `tbl_ph`.`id` DESC LIMIT 2
ERROR - 2017-04-16 17:38:30 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 11
ERROR - 2017-04-16 17:38:31 --> Severity: Notice --> Undefined variable: windows C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 257
ERROR - 2017-04-16 17:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\bitgiver\application\views\web\customer\dashboard.php 257
ERROR - 2017-04-16 17:38:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:38:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:38:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:38:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:38:31 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:38:32 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:10 --> Severity: Notice --> Undefined property: stdClass::$accountname C:\xampp\htdocs\bitgiver\application\controllers\web\User.php 11
ERROR - 2017-04-16 17:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:10 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:45:11 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:46:12 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:45 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:47:49 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:06 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:07 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:29 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:48:59 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:21 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:22 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:47 --> 404 Page Not Found: web/User/images
ERROR - 2017-04-16 17:49:48 --> 404 Page Not Found: web/User/images
