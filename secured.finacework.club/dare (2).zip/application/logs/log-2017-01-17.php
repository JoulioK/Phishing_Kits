<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 01:16:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:09:07 --> 404 Page Not Found: web/Authenticate/login
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 11:10:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:13 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:33:26 --> Severity: Notice --> Undefined property: Support::$Admin C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:33:26 --> Severity: Error --> Call to a member function ListDepartments() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:21 --> Severity: Notice --> Undefined property: Support::$Admin_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:21 --> Severity: Error --> Call to a member function ListDepartments() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:24 --> Severity: Notice --> Undefined property: Support::$Admin_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:24 --> Severity: Error --> Call to a member function ListDepartments() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:55 --> Severity: Notice --> Undefined property: Support::$Admin_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:55 --> Severity: Error --> Call to a member function ListDepartments() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:58 --> Severity: Notice --> Undefined property: Support::$Admin_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:35:58 --> Severity: Error --> Call to a member function ListDepartments() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 16
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 16:52:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 17:06:00 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\charity\application\controllers\web\Support.php 55
ERROR - 2017-01-17 17:06:23 --> Severity: Error --> Call to undefined method CI_Loader::template() C:\xampp\htdocs\charity\application\controllers\web\Support.php 92
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 40
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 51
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 58
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:45:00 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 40
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 51
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 58
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:06 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 40
ERROR - 2017-01-17 17:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 51
ERROR - 2017-01-17 17:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 58
ERROR - 2017-01-17 17:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:41 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:41 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:42 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 40
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 51
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 58
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:46:59 --> Severity: Notice --> Undefined index: priority C:\xampp\htdocs\charity\application\views\web\customer\compose.php 67
ERROR - 2017-01-17 17:48:50 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\charity\application\controllers\web\Support.php 155
ERROR - 2017-01-17 17:48:50 --> Severity: Notice --> Undefined variable: email C:\xampp\htdocs\charity\application\controllers\web\Support.php 167
ERROR - 2017-01-17 17:48:50 --> Severity: Notice --> Undefined property: Support::$encrypt C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-17 17:48:50 --> Severity: Error --> Call to a member function decode() on a non-object C:\xampp\htdocs\charity\application\models\web\Emails.php 45
ERROR - 2017-01-17 17:51:20 --> Severity: Notice --> Undefined property: Support::$encrypt C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-17 17:51:20 --> Severity: Error --> Call to a member function decode() on a non-object C:\xampp\htdocs\charity\application\models\web\Emails.php 45
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:18:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:38:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:38:06 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:38:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:43:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:43:09 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:43:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:44:31 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-17 22:44:31 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-17 22:44:32 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-17 22:44:34 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-17 22:46:32 --> 404 Page Not Found: web/Faq/index
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-17 22:47:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
