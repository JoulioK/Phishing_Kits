<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-22 08:04:23 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-22 08:04:48 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:04:54 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:04:54 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:05:16 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:05:17 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:06:00 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:06:00 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:07:04 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:07:05 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:08:23 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:08:24 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 109
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 112
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 115
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 118
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 121
ERROR - 2016-02-22 08:09:48 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:09:48 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:13:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 91
ERROR - 2016-02-22 08:13:25 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 30
ERROR - 2016-02-22 08:13:25 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniqueid&quot; does not exist
LINE 3: WHERE &quot;uniqueid&quot; = '8411082013'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:13:25 --> Query error: ERROR:  column "uniqueid" does not exist
LINE 3: WHERE "uniqueid" = '8411082013'
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "uniqueid" = '8411082013'
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 122
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 125
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 128
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 131
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 134
ERROR - 2016-02-22 08:18:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:19:50 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 139
ERROR - 2016-02-22 08:19:50 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:21:28 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 139
ERROR - 2016-02-22 08:21:32 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:22:25 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;uniqueid&quot; does not exist
LINE 3: WHERE &quot;uniqueid&quot; = '4350565413'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:22:25 --> Query error: ERROR:  column "uniqueid" does not exist
LINE 3: WHERE "uniqueid" = '4350565413'
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "uniqueid" = '4350565413'
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-22 08:22:48 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 3: WHERE &quot;storeid&quot; = '9550956513'
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:22:48 --> Query error: ERROR:  column "storeid" does not exist
LINE 3: WHERE "storeid" = '9550956513'
              ^ - Invalid query: SELECT *
FROM "t_stores"
WHERE "storeid" = '9550956513'
ORDER BY "t_stores"."id" ASC
ERROR - 2016-02-22 08:23:11 --> Severity: Error --> Call to undefined function array_from_post() C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 33
ERROR - 2016-02-22 08:31:46 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;added_by&quot; of relation &quot;t_stores&quot; does not exist
LINE 1: ... &quot;store_phone&quot;, &quot;store_address&quot;, &quot;store_enabled&quot;, &quot;added_by&quot;...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:31:46 --> Query error: ERROR:  column "added_by" of relation "t_stores" does not exist
LINE 1: ... "store_phone", "store_address", "store_enabled", "added_by"...
                                                             ^ - Invalid query: INSERT INTO "t_stores" ("store_name", "store_url", "store_email", "store_phone", "store_address", "store_enabled", "added_by", "store_id") VALUES ('PLATFORM SUPER MARKET', 'store.local', 'admin@edcabiastate.com', '070667193', 'ENUGU', '1', '9090909090', '8289398523')
ERROR - 2016-02-22 08:32:19 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;uniqueid&quot; violates not-null constraint
DETAIL:  Failing row contains (3, null, 6498502390, admin, d033e22ae348aeb5660fc2140aec35850c4da997, admin, null, null, Admin, 1, Super). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:32:19 --> Query error: ERROR:  null value in column "uniqueid" violates not-null constraint
DETAIL:  Failing row contains (3, null, 6498502390, admin, d033e22ae348aeb5660fc2140aec35850c4da997, admin, null, null, Admin, 1, Super). - Invalid query: INSERT INTO "t_store_users" ("fullname", "username", "password", "storeid", "privileges", "status", "added_by") VALUES ('admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '6498502390', 'Admin', 1, 'Super')
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined index: username C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 44
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 139
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 126
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:33:22 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 139
ERROR - 2016-02-22 08:33:23 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:33:37 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;email_address&quot; violates not-null constraint
DETAIL:  Failing row contains (4, 9635695667, 1117363049, admin, d033e22ae348aeb5660fc2140aec35850c4da997, admin, null, null, Admin, 1, Super). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:33:37 --> Query error: ERROR:  null value in column "email_address" violates not-null constraint
DETAIL:  Failing row contains (4, 9635695667, 1117363049, admin, d033e22ae348aeb5660fc2140aec35850c4da997, admin, null, null, Admin, 1, Super). - Invalid query: INSERT INTO "t_store_users" ("fullname", "username", "password", "storeid", "privileges", "status", "added_by", "uniqueid") VALUES ('admin', 'admin', 'd033e22ae348aeb5660fc2140aec35850c4da997', '1117363049', 'Admin', 1, 'Super', '9635695667')
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:36:32 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:36:32 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:37:24 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 135
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$username C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 138
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 141
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 144
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 147
ERROR - 2016-02-22 08:37:25 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 148
ERROR - 2016-02-22 08:37:25 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 133
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 133
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 133
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$status C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 129
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 132
ERROR - 2016-02-22 08:38:40 --> Severity: Notice --> Undefined property: stdClass::$uniqueid C:\xampp\htdocs\estore\application\views\Super\Stores\Store_page.php 133
ERROR - 2016-02-22 08:38:41 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:40:22 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:40:43 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:41:02 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:41:30 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 74
ERROR - 2016-02-22 08:41:30 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 2: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:41:30 --> Query error: ERROR:  column "storeid" does not exist
LINE 2: WHERE "storeid" IS NULL
              ^ - Invalid query: DELETE FROM "t_stores"
WHERE "storeid" IS NULL
AND "uniquekey" = 'images'
AND "id" = 4
ERROR - 2016-02-22 08:41:37 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:41:48 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 74
ERROR - 2016-02-22 08:41:48 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 2: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:41:48 --> Query error: ERROR:  column "storeid" does not exist
LINE 2: WHERE "storeid" IS NULL
              ^ - Invalid query: DELETE FROM "t_stores"
WHERE "storeid" IS NULL
AND "uniquekey" = 'images'
AND "id" = 4
ERROR - 2016-02-22 08:42:26 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:42:31 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 75
ERROR - 2016-02-22 08:42:31 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 2: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:42:31 --> Query error: ERROR:  column "storeid" does not exist
LINE 2: WHERE "storeid" IS NULL
              ^ - Invalid query: DELETE FROM "t_stores"
WHERE "storeid" IS NULL
AND "uniquekey" = 'images'
AND "id" = 4
ERROR - 2016-02-22 08:42:36 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:42:43 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\application\controllers\Super\Stores.php 75
ERROR - 2016-02-22 08:42:43 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;storeid&quot; does not exist
LINE 2: WHERE &quot;storeid&quot; IS NULL
              ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 08:42:43 --> Query error: ERROR:  column "storeid" does not exist
LINE 2: WHERE "storeid" IS NULL
              ^ - Invalid query: DELETE FROM "t_stores"
WHERE "storeid" IS NULL
AND "uniquekey" = '1117363049'
AND "id" = 3
ERROR - 2016-02-22 08:43:38 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:44:04 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:44:54 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:45:46 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:46:09 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:47:08 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:47:21 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 08:47:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:47:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 08:47:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:49:14 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:51:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:53:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:53:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 08:53:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 08:53:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 08:55:34 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 08:55:34 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 08:55:38 --> 404 Page Not Found: Super/Sales/Sales_History
ERROR - 2016-02-22 08:55:40 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 08:57:05 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 08:57:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:58:09 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 08:58:16 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 08:58:16 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 09:00:07 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 09:00:07 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 09:01:07 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 09:01:07 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 09:01:36 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 09:01:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 09:01:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 09:06:28 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 09:09:20 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 09:09:21 --> Severity: Notice --> Undefined property: Stores::$storeid C:\xampp\htdocs\estore\system\core\Model.php 77
ERROR - 2016-02-22 09:10:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 09:11:26 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 09:12:08 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 09:25:26 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 09:25:31 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-22 09:25:32 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-22 11:51:46 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-22 11:52:10 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 11:52:37 --> 404 Page Not Found: Super/Images/a.png
ERROR - 2016-02-22 11:53:04 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 11:53:05 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 11:53:15 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 11:54:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 11:54:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:54:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:55:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:55:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:55:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:55:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:58:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:58:27 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:58:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:59:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:59:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 11:59:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:00:06 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:02:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:33 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:41 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:02:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:03:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:03:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 12:03:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:04:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:04:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:04:36 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:04:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:04:49 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:05:07 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 12:05:16 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 12:05:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:06:28 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-22 12:06:38 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-22 12:06:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:07:23 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:08:15 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 12:08:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:08:42 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:09:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:09:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 12:09:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:12:25 --> 404 Page Not Found: Super/Js/classie.js
ERROR - 2016-02-22 14:12:40 --> 404 Page Not Found: Store/Js/classie.js
ERROR - 2016-02-22 14:12:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:13:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:14:49 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\xampp\htdocs\estore\application\controllers\Store\Sales.php 36
ERROR - 2016-02-22 14:15:01 --> Severity: Warning --> pg_query(): Query failed: ERROR:  column &quot;STOCK_LEDGER.storeid&quot; does not exist
LINE 1: ...cks&quot;.&quot;stock_id&quot; = &quot;STOCK_LEDGER&quot;.&quot;stock_id&quot; WHERE &quot;STOCK_LED...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-22 14:15:01 --> Query error: ERROR:  column "STOCK_LEDGER.storeid" does not exist
LINE 1: ...cks"."stock_id" = "STOCK_LEDGER"."stock_id" WHERE "STOCK_LED...
                                                             ^ - Invalid query: SELECT * FROM "STOCK_LEDGER" INNER JOIN "t_stocks" on "t_stocks"."stock_id" = "STOCK_LEDGER"."stock_id" WHERE "STOCK_LEDGER.storeid" = '9765090089' ORDER BY t_stocks.stock_name ASC
ERROR - 2016-02-22 14:15:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:15:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:16:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:17:33 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:17:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:17:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:18:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:18:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:18:55 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:19:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:19:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:19:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:19:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:20:10 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:20:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:20:40 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:20:54 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-22 14:21:26 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-22 14:21:29 --> 404 Page Not Found: Store/Reports/images
ERROR - 2016-02-22 14:24:03 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 14:24:32 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 14:24:49 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 14:25:10 --> 404 Page Not Found: Store/Sales/images
ERROR - 2016-02-22 14:25:18 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:25:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-22 14:26:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-22 14:36:25 --> 404 Page Not Found: Store/Reports/images
