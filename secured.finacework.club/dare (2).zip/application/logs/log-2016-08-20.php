<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-20 06:09:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-20 06:30:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 84
ERROR - 2016-08-20 06:30:42 --> Severity: Notice --> Undefined variable: dorders C:\xampp\htdocs\fastfood\application\controllers\app\Orders.php 85
ERROR - 2016-08-20 09:28:35 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 677
ERROR - 2016-08-20 09:28:51 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 677
ERROR - 2016-08-20 09:55:48 --> Severity: Parsing Error --> syntax error, unexpected ''packageids'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 677
ERROR - 2016-08-20 09:56:00 --> Severity: Parsing Error --> syntax error, unexpected ''packageids'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 677
ERROR - 2016-08-20 09:56:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 578
ERROR - 2016-08-20 09:56:47 --> Severity: Notice --> Undefined variable: unitids C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 591
ERROR - 2016-08-20 09:56:47 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 591
ERROR - 2016-08-20 09:56:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 601
ERROR - 2016-08-20 09:56:47 --> Severity: Notice --> Undefined variable: echo C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 676
