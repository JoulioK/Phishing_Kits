<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-21 20:32:04 --> 404 Page Not Found: 
ERROR - 2016-09-21 20:32:07 --> Severity: Notice --> Undefined index: topcategories C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 27
ERROR - 2016-09-21 20:32:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 27
ERROR - 2016-09-21 20:32:07 --> Severity: Notice --> Undefined variable: catnames C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 33
ERROR - 2016-09-21 20:32:07 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 33
