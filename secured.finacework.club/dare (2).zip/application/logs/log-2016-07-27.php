<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-27 11:51:33 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 11:54:32 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 11:54:33 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 11:59:52 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 11:59:52 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 12:00:58 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 12:00:58 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 12:02:38 --> Severity: Compile Error --> Cannot redeclare Item::cart() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-27 12:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 136
ERROR - 2016-07-27 12:05:22 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\fastfood\application\controllers\app\item.php 138
ERROR - 2016-07-27 12:08:19 --> Severity: Notice --> Undefined variable: cart C:\xampp\htdocs\fastfood\application\controllers\app\item.php 144
ERROR - 2016-07-27 12:08:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 144
ERROR - 2016-07-27 12:08:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\item.php 181
ERROR - 2016-07-27 12:08:43 --> Query error: Unknown column 'tbl_items' in 'where clause' - Invalid query: SELECT *
FROM `tbl_items`
WHERE `tbl_items` IS NULL
AND `itemid` = '14669259683913zm'
ORDER BY `id` ASC
ERROR - 2016-07-27 12:08:56 --> Query error: Unknown column 'tbl_items' in 'where clause' - Invalid query: SELECT *
FROM `tbl_items`
WHERE `tbl_items` IS NULL
AND `itemid` = '14669259683913zm'
ORDER BY `id` ASC
ERROR - 2016-07-27 12:11:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 144
ERROR - 2016-07-27 12:11:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\item.php 181
ERROR - 2016-07-27 12:16:00 --> Query error: Unknown column 'tbl_items' in 'where clause' - Invalid query: SELECT *
FROM `tbl_items`
WHERE `tbl_items` IS NULL
AND `itemid` = '14669259683913zm'
ORDER BY `id` ASC
ERROR - 2016-07-27 12:16:24 --> Query error: Unknown column 'tbl_items' in 'where clause' - Invalid query: SELECT *
FROM `tbl_items`
WHERE `tbl_items` IS NULL
AND `itemid` = '14669263110889yk'
ORDER BY `id` ASC
ERROR - 2016-07-27 16:38:10 --> Severity: Notice --> Undefined variable: packageids C:\xampp\htdocs\fastfood\application\controllers\app\item.php 181
