<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-24 00:57:47 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-24 00:57:48 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-24 01:00:14 --> Severity: Error --> Call to undefined function get_message() C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 116
ERROR - 2016-06-24 01:07:57 --> Severity: Error --> Call to undefined function encrypt() C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 102
ERROR - 2016-06-24 01:11:00 --> Query error: Table 'fastfood.tbl_vendors' doesn't exist - Invalid query: INSERT INTO `tbl_vendors` (`vendorname`, `vendoraddress`, `vendoremail`, `vendorphone`, `vendorusername`, `vendorurl`, `vendorpassword`, `franchiseid`) VALUES ('Crunchies', 'Crunchies Enugu', 'crunchies@crunchies.com', '08068752947', 'crunchies', 'http://crunchies.snappymeals.com', '876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6', '2626273373')
ERROR - 2016-06-24 01:18:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-24 01:19:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:19:05 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:19:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '39213278309624857268'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '39213278309624857268'
ERROR - 2016-06-24 01:21:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:21:24 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:21:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '65940916740183480173'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '65940916740183480173'
ERROR - 2016-06-24 01:23:52 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:23:52 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:23:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '91278063936634057824'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '91278063936634057824'
ERROR - 2016-06-24 01:24:50 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:24:50 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:24:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '22237785735398622410'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '22237785735398622410'
ERROR - 2016-06-24 01:25:49 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:25:49 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:25:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '27566232094250867468'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '27566232094250867468'
ERROR - 2016-06-24 01:29:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:29:24 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 105
ERROR - 2016-06-24 01:29:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '36536872890965780869'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '36536872890965780869'
ERROR - 2016-06-24 01:36:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 93
ERROR - 2016-06-24 01:36:15 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 105
ERROR - 2016-06-24 01:36:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '83373152147790257098'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '83373152147790257098'
ERROR - 2016-06-24 01:38:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:38:25 --> Severity: Notice --> Undefined variable: fieldname C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:38:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '69236273373451002793'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '69236273373451002793'
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:21 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:23 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:24 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:24 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:25 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:25 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:26 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:26 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:27 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:27 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:28 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:28 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:29 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:29 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:30 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:30 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:31 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:31 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:32 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:32 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:33 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:33 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:34 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:34 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:35 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:35 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:36 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:36 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:37 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:37 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:38 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:38 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:38 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:40:38 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 105 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:40:38 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:58 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:58 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:41:59 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:41:59 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:00 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:00 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:01 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:01 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:02 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:02 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:03 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:03 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:04 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:04 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:05 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:05 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:06 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:06 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:07 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:07 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:09 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:09 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:09 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:09 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:09 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:10 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:10 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:11 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:11 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:12 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:12 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:13 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:13 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:14 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:14 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:15 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:15 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:16 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:16 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:17 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:17 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:18 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:18 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:19 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:19 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:20 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:20 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:21 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:22 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:42:22 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:42:23 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:43:08 --> Severity: Warning --> Missing argument 2 for MY_Model::generate_unique_id(), called in C:\xampp\htdocs\fastfood\application\core\MY_Model.php on line 106 and defined C:\xampp\htdocs\fastfood\application\core\MY_Model.php 92
ERROR - 2016-06-24 01:43:08 --> Severity: Notice --> Undefined variable: column C:\xampp\htdocs\fastfood\application\core\MY_Model.php 104
ERROR - 2016-06-24 01:43:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '= '42215266214801878655'' at line 3 - Invalid query: SELECT *
FROM `tbl_vendors`
WHERE  = '42215266214801878655'
ERROR - 2016-06-24 02:19:33 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\xampp\htdocs\fastfood\application\views\management\vendor\view_vendor.php 95
ERROR - 2016-06-24 02:22:34 --> Severity: Error --> Call to undefined function getBtn() C:\xampp\htdocs\fastfood\application\views\management\vendor\view_vendor.php 93
ERROR - 2016-06-24 02:26:25 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 02:26:25 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 02:27:43 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 02:27:43 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 02:28:33 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 02:28:33 --> 404 Page Not Found: Resources/assets
ERROR - 2016-06-24 18:29:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-24 18:31:03 --> 404 Page Not Found: management/Vendor/management
