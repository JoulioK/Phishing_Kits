<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-23 00:58:23 --> Severity: 8192 --> mysql_connect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 136
ERROR - 2016-06-23 00:58:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'NULL,
	CONSTRAINT `pk_t_tithers` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf' at line 14 - Invalid query: CREATE TABLE `t_tithers` (
	`id` INT(5) UNSIGNED NOT NULL AUTO_INCREMENT,
	`tpn` VARCHAR(50) NOT NULL,
	`password` TEXT NOT NULL,
	`fullname` VARCHAR(100) NOT NULL,
	`gender` VARCHAR(6) NOT NULL,
	`date_of_birth` DATE NOT NULL,
	`marital_status` VARCHAR(50) NOT NULL,
	`wedding_anniversary_date` DATE NULL,
	`occupation` VARCHAR(11) NULL,
	`email_address` VARCHAR(100) NOT NULL,
	`phone_number` VARCHAR(11) NOT NULL,
	`home_address` VARCHAR(11) NOT NULL,
	`church_department` VARCHAR NULL,
	CONSTRAINT `pk_t_tithers` PRIMARY KEY(`id`)
) DEFAULT CHARACTER SET = utf8 COLLATE = utf8_general_ci
ERROR - 2016-06-23 00:58:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `passwor' at line 2 - Invalid query: SELECT *
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 00:58:26 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 00:58:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `passwor' at line 2 - Invalid query: SELECT *
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 00:58:48 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 01:00:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `passwor' at line 2 - Invalid query: SELECT *
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:00:31 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 01:00:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `passwor' at line 2 - Invalid query: SELECT *
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:00:35 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 01:01:12 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:01:12 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 01:01:50 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:01:50 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 41
ERROR - 2016-06-23 01:15:56 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:15:56 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 42
ERROR - 2016-06-23 01:17:51 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:17:51 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 43
ERROR - 2016-06-23 01:18:03 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:18:03 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 43
ERROR - 2016-06-23 01:19:41 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:19:41 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 34
ERROR - 2016-06-23 01:21:06 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:21:06 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 35
ERROR - 2016-06-23 01:22:07 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:22:07 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 36
ERROR - 2016-06-23 01:22:40 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:23:27 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:24:02 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:24:18 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE ((username = 'olafashade') OR (email_address = 'olafashade')) AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:24:18 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 35
ERROR - 2016-06-23 01:28:36 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:28:36 --> Severity: Error --> Call to a member function row() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 35
ERROR - 2016-06-23 01:31:47 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:31:47 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 35
ERROR - 2016-06-23 01:32:59 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:32:59 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 35
ERROR - 2016-06-23 01:34:17 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:34:17 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 34
ERROR - 2016-06-23 01:34:57 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:34:57 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 34
ERROR - 2016-06-23 01:35:14 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:35:55 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:35:55 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 34
ERROR - 2016-06-23 01:37:21 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2016-06-23 01:37:21 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:37:21 --> Severity: Error --> Call to a member function num_rows() on a non-object C:\xampp\htdocs\fastfood\application\core\MY_Model.php 34
ERROR - 2016-06-23 01:37:52 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2016-06-23 01:37:52 --> Query error: Unknown column 'email_address' in 'where clause' - Invalid query: SELECT *
FROM `management_users`
WHERE `username` = 'olafashade'
OR `email_address` = 'olafashade'
AND `password` = '0cad0602c6e97b216e7a7e8a10582f79f263461e'
ERROR - 2016-06-23 01:38:34 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2016-06-23 01:38:35 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:38:35 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:38:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:38:39 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:38:44 --> Severity: 8192 --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\fastfood\system\database\drivers\mysql\mysql_driver.php 135
ERROR - 2016-06-23 01:39:00 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:39:04 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:39:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:39:04 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:00 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:00 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:10 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:10 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:39 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:41:39 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:42:43 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:42:44 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:42:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:42:44 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:34 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:35 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:59 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:44:59 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:45:21 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:45:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:45:22 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:46:47 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:46:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:46:51 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:47:26 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:47:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:47:27 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 12
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 31
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:48:17 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:48:17 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\Admin\_templates\_menu.php 43
ERROR - 2016-06-23 01:48:17 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:49:16 --> Severity: Notice --> Undefined variable: user_privilege C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:49:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:49:17 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:50:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:50:16 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 12
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 31
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:50:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given C:\xampp\htdocs\fastfood\application\views\management\_templates\_menu.php 43
ERROR - 2016-06-23 01:50:28 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:50:44 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:51:19 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:53:57 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:54:00 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 01:58:51 --> 404 Page Not Found: management/Images/a.png
ERROR - 2016-06-23 02:02:17 --> 404 Page Not Found: Admin/authenticate
ERROR - 2016-06-23 02:02:34 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-23 02:02:38 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:02:44 --> 404 Page Not Found: Admin/authenticate
ERROR - 2016-06-23 02:03:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-23 02:03:03 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:03:06 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-06-23 02:03:26 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:04:35 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:05:55 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:06:21 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:06:26 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:06:50 --> Severity: Notice --> Undefined property: stdClass::$privileges C:\xampp\htdocs\fastfood\application\models\management\user_model.php 75
ERROR - 2016-06-23 02:08:28 --> 404 Page Not Found: management/Add_vendors/index
ERROR - 2016-06-23 02:10:48 --> 404 Page Not Found: management/Vendor/add_vendors
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 18
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 18
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 22
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 22
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 27
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 27
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 31
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 31
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 42
ERROR - 2016-06-23 02:14:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 42
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 16
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 16
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 20
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 20
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Undefined variable: expense C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 40
ERROR - 2016-06-23 02:15:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 40
ERROR - 2016-06-23 02:22:17 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 16
ERROR - 2016-06-23 02:22:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 16
ERROR - 2016-06-23 02:22:17 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 20
ERROR - 2016-06-23 02:22:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 20
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 35
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 35
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Undefined variable: vendor C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 40
ERROR - 2016-06-23 02:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 40
ERROR - 2016-06-23 02:45:12 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\vendor_model.php 25
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 16
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 20
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 25
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 29
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 35
ERROR - 2016-06-23 02:45:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 40
ERROR - 2016-06-23 02:46:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\vendor_model.php 25
ERROR - 2016-06-23 02:46:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\models\management\vendor_model.php 25
ERROR - 2016-06-23 02:47:23 --> Severity: Notice --> Undefined property: stdClass::$vendorusername C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 46
ERROR - 2016-06-23 02:58:27 --> Severity: Notice --> Undefined variable: edit C:\xampp\htdocs\fastfood\application\views\management\vendor\add_vendor.php 85
ERROR - 2016-06-23 03:31:58 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\fastfood\application\views\management\_templates\_topnav.php 11
ERROR - 2016-06-23 03:31:58 --> Severity: Notice --> Undefined variable: url C:\xampp\htdocs\fastfood\application\views\management\_templates\_topnav.php 11
ERROR - 2016-06-23 03:32:39 --> 404 Page Not Found: management/Vendor/add_vendor
ERROR - 2016-06-23 03:33:32 --> 404 Page Not Found: management/Vendor/add_vendors
ERROR - 2016-06-23 03:33:34 --> Severity: Error --> Call to undefined method Vendor::add_vendors() C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 29
