<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-11 12:18:08 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-05-11 12:18:09 --> 404 Page Not Found: management/Js/classie.js
