<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-19 21:43:03 --> 404 Page Not Found: web/Vendor/index
