<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-23 10:19:48 --> Query error: Table 'bitnaira.tbl_items' doesn't exist - Invalid query: SELECT *
FROM `tbl_items`
ORDER BY `tbl_items`.`datecreated` ASC
 LIMIT 6
ERROR - 2016-11-23 11:13:22 --> Query error: Table 'bitnaira.tbl_items' doesn't exist - Invalid query: SELECT *
FROM `tbl_items`
ORDER BY `tbl_items`.`datecreated` ASC
 LIMIT 6
ERROR - 2016-11-23 11:13:23 --> Query error: Unknown column 'tbl_items.datecreated' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479896003
WHERE `id` = 'cca2d8b48e804b20791c9a40eb1324297ad54070'
ORDER BY `tbl_items`.`datecreated` ASC LIMIT 6
ERROR - 2016-11-23 11:13:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 144
ERROR - 2016-11-23 11:14:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 144
ERROR - 2016-11-23 11:18:39 --> Severity: Notice --> Undefined property: stdClass::$addressname C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 189
ERROR - 2016-11-23 11:18:56 --> Severity: Notice --> Undefined property: stdClass::$addressname C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 189
ERROR - 2016-11-23 11:45:07 --> Query error: Unknown column 'addresssname' in 'field list' - Invalid query: SELECT `address`, `addresssname`
FROM `tbl_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14798964940253we'
ERROR - 2016-11-23 11:45:07 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479897907
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14798964940253we'
AND `id` = 'cca2d8b48e804b20791c9a40eb1324297ad54070'
ERROR - 2016-11-23 11:51:29 --> Query error: Unknown column 'addresssname' in 'field list' - Invalid query: SELECT `address`, `addresssname`
FROM `tbl_address`
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14798964940253we'
ERROR - 2016-11-23 11:51:29 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479898289
WHERE `userid` = '14675775313398tp'
AND `addressid` = '14798964940253we'
AND `id` = 'cca2d8b48e804b20791c9a40eb1324297ad54070'
ERROR - 2016-11-23 11:55:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 241
ERROR - 2016-11-23 11:55:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 242
ERROR - 2016-11-23 11:55:42 --> Query error: Unknown column 'addresssname' in 'field list' - Invalid query: SELECT `address`, `addresssname`
FROM `tbl_address`
WHERE `userid` IS NULL
AND `addressid` IS NULL
ERROR - 2016-11-23 11:55:42 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479898542
WHERE `userid` IS NULL
AND `addressid` IS NULL
AND `id` = 'cca2d8b48e804b20791c9a40eb1324297ad54070'
ERROR - 2016-11-23 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 241
ERROR - 2016-11-23 12:34:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 242
ERROR - 2016-11-23 12:34:00 --> Query error: Unknown column 'addresssname' in 'field list' - Invalid query: SELECT `address`, `addresssname`
FROM `tbl_address`
WHERE `userid` IS NULL
AND `addressid` IS NULL
ERROR - 2016-11-23 12:34:00 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479900840
WHERE `userid` IS NULL
AND `addressid` IS NULL
AND `id` = 'cca2d8b48e804b20791c9a40eb1324297ad54070'
ERROR - 2016-11-23 12:34:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 144
ERROR - 2016-11-23 12:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 241
ERROR - 2016-11-23 12:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 242
ERROR - 2016-11-23 12:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 256
ERROR - 2016-11-23 12:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 257
ERROR - 2016-11-23 13:42:15 --> 404 Page Not Found: app/Snappycoindashboard/dailyrate
ERROR - 2016-11-23 13:43:39 --> 404 Page Not Found: app/Dashboard/dailyrate
ERROR - 2016-11-23 19:56:07 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:08 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:08 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:39 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:39 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:39 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:59 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:59 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:59 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:56:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:11 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:11 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:11 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:45 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:45 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:45 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:58:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:20 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:20 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:20 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:48 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:48 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:48 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 19:59:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 20:10:44 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 20:10:44 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 20:10:44 --> Severity: Notice --> Undefined property: stdClass::$Object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
ERROR - 2016-11-23 20:10:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 53
