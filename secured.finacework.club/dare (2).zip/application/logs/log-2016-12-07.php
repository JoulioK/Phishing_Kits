<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-07 17:35:17 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\snappycoin\application\controllers\web\Authenticate.php 26
ERROR - 2016-12-07 17:35:47 --> Severity: Notice --> Undefined index: password C:\xampp\htdocs\snappycoin\application\controllers\web\Authenticate.php 26
