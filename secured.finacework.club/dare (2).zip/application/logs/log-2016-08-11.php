<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-11 08:07:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT `message`, `messagestatus`, `status`, `date`, `datecreated`
FROM 
WHERE `trendid` = '14684130358407uh'
ORDER BY `id` ASC
ERROR - 2016-08-11 08:18:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:18:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:18:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:18:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:16 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:16 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:16 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:16 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
ERROR - 2016-08-11 08:19:54 --> Severity: Notice --> Undefined variable: itemlocation C:\xampp\htdocs\fastfood\application\controllers\app\home.php 116
