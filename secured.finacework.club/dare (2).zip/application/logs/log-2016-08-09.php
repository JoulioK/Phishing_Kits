<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-09 05:57:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-09 05:57:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-09 05:57:40 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-08-09 06:05:46 --> 404 Page Not Found: vendor/Items/resources
