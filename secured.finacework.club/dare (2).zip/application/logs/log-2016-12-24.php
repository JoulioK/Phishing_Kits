<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-24 08:53:28 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-24 08:56:46 --> Severity: Error --> Call to undefined method Orders::set_flashdata() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 144
ERROR - 2016-12-24 08:56:50 --> Severity: Error --> Call to undefined method Orders::set_flashdata() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 144
ERROR - 2016-12-24 08:56:56 --> Severity: Error --> Call to undefined method Orders::set_flashdata() C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 144
ERROR - 2016-12-24 09:19:54 --> Severity: Error --> [] operator not supported for strings C:\xampp\htdocs\snappycoin\application\controllers\management\Orders.php 289
ERROR - 2016-12-24 21:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\_layouts\headerhome.php 134
ERROR - 2016-12-24 21:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\_layouts\headerhome.php 147
ERROR - 2016-12-24 21:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\_layouts\headerhome.php 159
ERROR - 2016-12-24 21:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\_layouts\headerhome.php 186
ERROR - 2016-12-24 21:45:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\_layouts\headerhome.php 529
ERROR - 2016-12-24 21:59:35 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-12-24 22:24:32 --> 404 Page Not Found: web/Authenticate/login
ERROR - 2016-12-24 22:58:14 --> 404 Page Not Found: web/Auth/login
