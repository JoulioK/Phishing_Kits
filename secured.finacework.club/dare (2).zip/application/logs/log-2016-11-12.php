<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-12 09:28:30 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 09:28:31 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 09:28:31 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 09:28:32 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 09:28:32 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 09:28:32 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-11-12 13:15:51 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-12 13:42:01 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-12 13:42:11 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-12 13:43:10 --> Query error: Unknown column 'statename' in 'field list' - Invalid query: INSERT INTO `tbl_locations` (`locationname`, `statename`, `countryname`, `locationid`, `datecreated`) VALUES ('Ola', NULL, NULL, '14789545905851yn', '2016-11-12')
ERROR - 2016-11-12 13:55:51 --> Severity: Notice --> Undefined property: stdClass::$statename C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 124
ERROR - 2016-11-12 13:55:52 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 13:55:52 --> Severity: Notice --> Undefined property: stdClass::$statename C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 124
ERROR - 2016-11-12 13:55:52 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 13:55:52 --> Severity: Notice --> Undefined property: stdClass::$statename C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 124
ERROR - 2016-11-12 13:55:52 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 13:58:20 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 13:58:20 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 13:58:20 --> Severity: Notice --> Undefined property: stdClass::$countryname C:\xampp\htdocs\caroossa\application\views\management\configuration\location.php 125
ERROR - 2016-11-12 14:05:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 98
ERROR - 2016-11-12 14:05:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 99
ERROR - 2016-11-12 14:08:45 --> Severity: Notice --> Undefined property: stdClass::$location C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 105
ERROR - 2016-11-12 14:10:44 --> Severity: Parsing Error --> syntax error, unexpected ':', expecting ',' or ';' C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 100
ERROR - 2016-11-12 14:19:09 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-11-12 14:32:43 --> Query error: Unknown column 'tbl_brand.brandname' in 'field list' - Invalid query: SELECT `tbl_items`.*, `tbl_brand`.`brandname`
FROM `tbl_items`
INNER JOIN `tbl_brands` ON `tbl_brands`.`brandid` = `tbl_items`.`brandid`
WHERE `vendorid` = '14711890669843ss'
ERROR - 2016-11-12 14:32:43 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1478957563
WHERE `vendorid` = '14711890669843ss'
AND `id` = 'becc980f7194ebe539611fa66608a2a7bd4c0a8d'
ERROR - 2016-11-12 15:07:51 --> 404 Page Not Found: management/Vendor/items
ERROR - 2016-11-12 15:10:09 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 34
ERROR - 2016-11-12 15:10:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:11:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:12:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:14:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:15:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\caroossa\application\views\vendor\items\view_item.php 105
ERROR - 2016-11-12 15:47:19 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 191
ERROR - 2016-11-12 15:47:58 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\caroossa\application\views\vendor\items\create_items.php 289
ERROR - 2016-11-12 18:01:15 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:01:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:13:20 --> Query error: Table 'caroossa.tbl_vendor_users' doesn't exist - Invalid query: SELECT *
FROM `tbl_vendor_users`
ERROR - 2016-11-12 18:15:37 --> Query error: Table 'caroossa.tbl_vendor_payment' doesn't exist - Invalid query: SELECT *
FROM `tbl_vendor_payment`
WHERE datecreated between '2016-11-12 00:00:01' AND '2016-11-12 23:59:59'
AND `vendorid` = '14711890669843ss'
ERROR - 2016-11-12 18:15:37 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1478970937
WHERE datecreated between '2016-11-12 00:00:01' AND '2016-11-12 23:59:59'
AND `vendorid` = '14711890669843ss'
AND `id` = '1c2c76ae2490f4d5388a578120e7264e5a66b000'
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:20:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:28:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:29:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:31:48 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-11-12 18:31:59 --> 404 Page Not Found: management/Dashboard/index
ERROR - 2016-11-12 18:32:22 --> Query error: Table 'caroossa.tbl_shippings' doesn't exist - Invalid query: SELECT sum(amount) as total
FROM `tbl_shippings`
WHERE `status` = '1'
AND datecreated between '2016-11-12 00:00:01' AND '2016-11-12 23:59:59'
AND `franchiseid` = '2626273373'
ORDER BY `id` desc
ERROR - 2016-11-12 18:32:22 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1478971942
WHERE `status` = '1'
AND datecreated between '2016-11-12 00:00:01' AND '2016-11-12 23:59:59'
AND `franchiseid` = '2626273373'
AND `id` = '1c2c76ae2490f4d5388a578120e7264e5a66b000'
ORDER BY `id` desc
ERROR - 2016-11-12 18:33:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:33:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-12 18:53:10 --> 404 Page Not Found: management/Orders/pending
ERROR - 2016-11-12 18:53:38 --> 404 Page Not Found: management/Messages/index
ERROR - 2016-11-12 22:08:20 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\caroossa\application\views\web\_layouts\banner.php 688
