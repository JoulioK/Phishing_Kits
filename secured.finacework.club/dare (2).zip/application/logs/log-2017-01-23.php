<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-23 12:23:01 --> 404 Page Not Found: web/Support/faqs
ERROR - 2017-01-23 13:59:16 --> 404 Page Not Found: web/Support/faqs
ERROR - 2017-01-23 16:46:22 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\charity\application\models\web\Customer_model.php 88
ERROR - 2017-01-23 16:46:25 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\charity\application\models\web\Customer_model.php 88
ERROR - 2017-01-23 16:49:58 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-23 16:49:58 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-23 20:53:17 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-23 20:53:17 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-23 23:03:18 --> 404 Page Not Found: web/Authenticate/logout
ERROR - 2017-01-23 23:21:20 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\charity\application\controllers\web\Auth.php 112
ERROR - 2017-01-23 23:21:21 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\charity\application\controllers\web\Auth.php 118
ERROR - 2017-01-23 23:21:21 --> Query error: Unknown column 'tellernumber' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485210081, `data` = 'sponsor|s:16:\"14675775313398tp\";Please login first|N;user_session|O:8:\"stdClass\":19:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";N;s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 19:36:21\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE `tellernumber` IS NULL
AND `graceperiod` < '2017-01-23 23:21:20'
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ERROR - 2017-01-23 23:21:21 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-23 23:23:03 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\charity\application\controllers\web\Auth.php 112
ERROR - 2017-01-23 23:23:03 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\charity\application\controllers\web\Auth.php 118
ERROR - 2017-01-23 23:23:03 --> Query error: Unknown column 'tellernumber' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485210183, `data` = 'sponsor|s:16:\"14675775313398tp\";Please login first|N;user_session|O:8:\"stdClass\":19:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:8:\"username\";N;s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";N;s:3:\"gmt\";s:2:\"+1\";s:9:\"isguilder\";s:1:\"1\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-19 19:36:21\";}user_loggedin|b:1;current_userid|s:20:\"7373hu8e3e8388e9e8e9\";franchiseid|s:10:\"2626273373\";username|s:10:\"olafashade\";privileges|s:5:\"Admin\";fullname|s:11:\"Ola Fashade\";loggedin|b:1;'
WHERE `tellernumber` IS NULL
AND `graceperiod` < '2017-01-23 23:23:03'
AND `id` = '0eb70eaff8d8010bbfe26ce03f96881273a0dd20'
ERROR - 2017-01-23 23:23:03 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-23 23:24:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:24:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:24:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:52 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:25:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:26:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:26:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:26:31 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 127
ERROR - 2017-01-23 23:36:10 --> Severity: Notice --> Undefined property: stdClass::$paymentstatus C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 79
ERROR - 2017-01-23 23:36:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:36:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:36:11 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:36:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:36:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:36:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:37:53 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:40:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:40:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
ERROR - 2017-01-23 23:40:42 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 134
