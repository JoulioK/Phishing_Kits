<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-15 00:56:07 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\caroossa\application\controllers\web\Rides.php 25
ERROR - 2016-11-15 00:56:34 --> 404 Page Not Found: web/Rides/index
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:18:40 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:14 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:14 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:15 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:15 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:15 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:25:15 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:26:41 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:27:53 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:29 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:30 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:30 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:30 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:30 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:30 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:28:54 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:30:39 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 01:33:13 --> 404 Page Not Found: web/Rides/images
ERROR - 2016-11-15 05:18:18 --> Query error: Unknown column 'transmission' in 'field list' - Invalid query: SELECT distinct(transmission)
ERROR - 2016-11-15 05:18:45 --> Query error: Unknown column 'optiontransmission' in 'field list' - Invalid query: SELECT distinct(optiontransmission)
ERROR - 2016-11-15 05:19:59 --> Severity: Notice --> Use of undefined constant tbl_item_options - assumed 'tbl_item_options' C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 17
ERROR - 2016-11-15 05:19:59 --> Severity: Error --> Call to a member function result_array() on a non-object C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 23
ERROR - 2016-11-15 05:20:16 --> Severity: Error --> Call to a member function result_array() on a non-object C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 23
ERROR - 2016-11-15 05:20:29 --> Severity: Error --> Call to a member function results_array() on a non-object C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 23
ERROR - 2016-11-15 05:20:49 --> Severity: Error --> Call to a member function results() on a non-object C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 23
ERROR - 2016-11-15 05:21:09 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::results() C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 23
ERROR - 2016-11-15 05:21:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:21:31 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:21:32 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:21:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:21:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:21:56 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\caroossa\application\views\web\pages\rides.php 104
ERROR - 2016-11-15 05:23:16 --> Severity: Warning --> array_column() expects parameter 1 to be array, string given C:\xampp\htdocs\caroossa\application\models\web\Item_model.php 24
ERROR - 2016-11-15 11:04:10 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\caroossa\application\controllers\web\Rides.php 71
ERROR - 2016-11-15 11:04:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',autom' at line 3 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479204280
WHERE `tbl_item_location`.`locationid` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('533633637346747',26263376733',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',automatic')
AND `id` = '3d76418955d6d51fb552352b4ac5dff4eb01381c'
ERROR - 2016-11-15 11:05:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',autom' at line 6 - Invalid query: SELECT *
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
LEFT JOIN `tbl_item_options` ON `tbl_item_options`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_location`.`locationid` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('533633637346747',26263376733',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',automatic')
ORDER BY `tbl_items`.`datecreated` DESC
ERROR - 2016-11-15 11:05:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',autom' at line 3 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479204325
WHERE `tbl_item_location`.`locationid` = '14668510290307aw'
AND `tbl_items`.`brandid` IN ('533633637346747',26263376733',3536537367478')
AND `tbl_item_options`.`optiontransmission` IN ('manual',automatic')
AND `id` = '3d76418955d6d51fb552352b4ac5dff4eb01381c'
ORDER BY `tbl_items`.`datecreated` DESC
ERROR - 2016-11-15 16:36:56 --> 404 Page Not Found: web/Login/index
ERROR - 2016-11-15 16:37:17 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:37:17 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:38:04 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:38:04 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:39:33 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:39:33 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:39:55 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:39:55 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:40:30 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:40:30 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:40:57 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:40:57 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:42:41 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:42:41 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:51:13 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:51:13 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:51:32 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:51:32 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 16:53:32 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 16:53:32 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 17:05:45 --> Severity: Notice --> Undefined variable: topabout C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 10
ERROR - 2016-11-15 17:05:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 10
ERROR - 2016-11-15 17:06:35 --> Query error: Unknown column 'text' in 'field list' - Invalid query: SELECT `text`
FROM `tbl_item_category`
WHERE `id` = 1
ORDER BY `id` ASC
ERROR - 2016-11-15 17:07:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 10
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Undefined variable: topcontact C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 16
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 16
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Undefined variable: topcontact C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 17
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 17
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Undefined variable: topcontact C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 18
ERROR - 2016-11-15 17:16:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\views\web\_layouts\footer.php 18
ERROR - 2016-11-15 17:18:00 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 36
ERROR - 2016-11-15 17:18:00 --> Query error: Unknown column 'firstname' in 'field list' - Invalid query: SELECT `firstname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:18:00 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479226680
WHERE `userid` = '14675775313398tp'
AND `id` = '32cbb5aaa3124acdb8cd92a5b3c1be2a161d39d2'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:19:13 --> Query error: Unknown column 'firstname' in 'field list' - Invalid query: SELECT `firstname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:19:13 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479226753
WHERE `userid` = '14675775313398tp'
AND `id` = '32cbb5aaa3124acdb8cd92a5b3c1be2a161d39d2'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:20:02 --> Query error: Unknown column 'firstname' in 'field list' - Invalid query: SELECT `firstname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:20:02 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479226802
WHERE `userid` = '14675775313398tp'
AND `id` = '32cbb5aaa3124acdb8cd92a5b3c1be2a161d39d2'
ORDER BY `id` ASC
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:20:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\models\web\Message_model.php 92
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:21:11 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:22:51 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:23:52 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:24:17 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:48 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:25:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 77
ERROR - 2016-11-15 17:28:41 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 54
ERROR - 2016-11-15 17:29:01 --> Severity: Parsing Error --> syntax error, unexpected 'endforeach' (T_ENDFOREACH) C:\xampp\htdocs\caroossa\application\views\web\customer\trends.php 52
ERROR - 2016-11-15 17:30:35 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\caroossa\application\views\web\customer\trend.php 31
ERROR - 2016-11-15 17:31:48 --> Query error: Table 'caroossa.tbl_shipping_address' doesn't exist - Invalid query: SELECT *
FROM `tbl_shipping_address`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-15 17:31:48 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1479227508
WHERE `userid` = '14675775313398tp'
AND `id` = '32cbb5aaa3124acdb8cd92a5b3c1be2a161d39d2'
ERROR - 2016-11-15 18:19:49 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-15 18:19:49 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-15 18:25:54 --> Severity: Notice --> Undefined variable: uri C:\xampp\htdocs\caroossa\application\views\web\_layouts\_customer_navigation.php 151
