<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-01 15:11:09 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-03-01 15:11:18 --> 404 Page Not Found: management/Js/classie.js
