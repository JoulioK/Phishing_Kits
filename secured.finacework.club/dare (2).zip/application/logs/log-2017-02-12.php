<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-12 20:36:53 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:11 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:22 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:25 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:33 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:50 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:18:52 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:20:16 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
ERROR - 2017-02-12 21:20:19 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
