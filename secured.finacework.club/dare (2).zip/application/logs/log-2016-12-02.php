<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-02 09:02:21 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-02 09:02:27 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-02 09:56:25 --> Severity: Notice --> Undefined property: CI_Loader::$customer_model C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders.php 108
ERROR - 2016-12-02 09:56:25 --> Severity: Error --> Call to a member function getuserbyid() on a non-object C:\xampp\htdocs\snappycoin\application\views\management\franchisereport\orders.php 108
ERROR - 2016-12-02 13:00:16 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-02 14:44:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-02 16:35:03 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-12-02 17:52:04 --> Severity: Notice --> Undefined property: stdClass::$transactionref C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 63
ERROR - 2016-12-02 17:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 64
ERROR - 2016-12-02 17:52:06 --> Severity: Notice --> Undefined property: Item::$naira C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 68
ERROR - 2016-12-02 17:52:06 --> Severity: Notice --> Undefined property: Item::$naira C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 69
ERROR - 2016-12-02 17:52:06 --> Severity: 4096 --> Object of class stdClass could not be converted to string C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 69
ERROR - 2016-12-02 17:52:06 --> Severity: Notice --> Object of class stdClass to string conversion C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 69
ERROR - 2016-12-02 17:52:06 --> Severity: Notice --> Undefined variable: Object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 69
ERROR - 2016-12-02 17:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 69
ERROR - 2016-12-02 19:50:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 77
ERROR - 2016-12-02 20:27:54 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:28:10 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:28:13 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:30:52 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:30:55 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:31:04 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:31:33 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 127
ERROR - 2016-12-02 20:33:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT *
FROM 
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-12-02 20:33:22 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480707202
WHERE `userid` = '14675775313398tp'
AND `id` = '599c685192125ba8a27ca46a14d80037aaad8f68'
ORDER BY `id` ASC
ERROR - 2016-12-02 20:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 116
ERROR - 2016-12-02 20:33:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `userid` IS NULL
ORDER BY `id` ASC' at line 3 - Invalid query: SELECT *
FROM 
WHERE `userid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-12-02 20:33:29 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480707209
WHERE `userid` IS NULL
AND `id` = '599c685192125ba8a27ca46a14d80037aaad8f68'
ORDER BY `id` ASC
ERROR - 2016-12-02 20:35:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 117
ERROR - 2016-12-02 20:35:05 --> Query error: Table 'bitnaira.userid' doesn't exist - Invalid query: SELECT *
FROM `userid`
WHERE `userid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-12-02 20:35:05 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480707305
WHERE `userid` IS NULL
AND `id` = '599c685192125ba8a27ca46a14d80037aaad8f68'
ORDER BY `id` ASC
ERROR - 2016-12-02 20:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 117
ERROR - 2016-12-02 20:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 121
ERROR - 2016-12-02 20:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 131
ERROR - 2016-12-02 20:35:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 131
ERROR - 2016-12-02 21:48:36 --> Severity: Error --> Cannot access protected property Item_model::$_primary_filter C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 164
ERROR - 2016-12-02 21:48:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 158
ERROR - 2016-12-02 21:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 159
ERROR - 2016-12-02 21:48:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 160
ERROR - 2016-12-02 21:48:56 --> Severity: Error --> Cannot access protected property Item_model::$_primary_filter C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 164
ERROR - 2016-12-02 21:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 158
ERROR - 2016-12-02 21:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 159
ERROR - 2016-12-02 21:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 160
ERROR - 2016-12-02 21:49:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 167
ERROR - 2016-12-02 22:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 158
ERROR - 2016-12-02 22:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 159
ERROR - 2016-12-02 22:44:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 160
ERROR - 2016-12-02 22:44:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 167
