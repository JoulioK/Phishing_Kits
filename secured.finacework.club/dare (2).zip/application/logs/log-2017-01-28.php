<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-28 06:18:34 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-28 06:18:35 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-01-28 06:22:51 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\charity\application\controllers\management\Orders.php 35
ERROR - 2017-01-28 06:23:28 --> Query error: Column 'datecreated' in where clause is ambiguous - Invalid query: SELECT `tbl_ph`.*, `tbl_gh`.`depositorsname`
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_gh`.`ghid`=`tbl_ph`.`phid`
WHERE datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `id` DESC
ERROR - 2017-01-28 06:23:28 --> Query error: Unknown column 'datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485581008
WHERE datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `id` DESC
ERROR - 2017-01-28 06:24:32 --> Query error: Column 'datecreated' in where clause is ambiguous - Invalid query: SELECT `tbl_ph`.*, `tbl_gh`.`depositorsname`
FROM `tbl_ph`
JOIN `tbl_gh` ON `tbl_gh`.`ghid`=`tbl_ph`.`phid`
WHERE tbl_ph.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `tbl_ph`.`id` DESC
ERROR - 2017-01-28 06:24:32 --> Query error: Unknown column 'tbl_ph.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485581072
WHERE tbl_ph.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_ph`.`id` DESC
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:03 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:33:04 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:19 --> Severity: Error --> Call to undefined function select() C:\xampp\htdocs\charity\application\controllers\management\Orders.php 58
ERROR - 2017-01-28 06:38:19 --> Query error: Unknown column 'tbl_gh.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485581899
WHERE tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:38:19 --> Severity: Warning --> Cannot modify header information - headers already sent C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-01-28 06:38:28 --> Query error: Unknown column 'tbl_user.isguilder' in 'field list' - Invalid query: SELECT `tbl_gh`.*, `tbl_user`.`isguilder`
FROM `tbl_gh`
LEFT JOIN `tbl_users` ON `tbl_users`.`userid`=`tbl_gh`.`userid`
WHERE tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:38:28 --> Query error: Unknown column 'tbl_gh.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485581908
WHERE tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:38:53 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:43 --> Query error: Unknown column 'tbl_users.email' in 'field list' - Invalid query: SELECT `tbl_gh`.*, `tbl_users`.`isguilder`, `tbl_users`.`email`, `tbl_users`.`phonenumber`
FROM `tbl_gh`
LEFT JOIN `tbl_users` ON `tbl_users`.`userid`=`tbl_gh`.`userid`
WHERE tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:39:43 --> Query error: Unknown column 'tbl_gh.datecreated' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485581983
WHERE tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-27 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:39:57 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 95
ERROR - 2017-01-28 06:39:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 96
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:43 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:41:44 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:35 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:42:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:21 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:43:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:44:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '' at line 4 - Invalid query: SELECT `tbl_gh`.*, `tbl_users`.`isguilder`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`
FROM `tbl_gh`
LEFT JOIN `tbl_users` ON `tbl_users`.`userid`=`tbl_gh`.`userid`
WHERE tbl_gh.between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:44:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485582268
WHERE tbl_gh.between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:45:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '' at line 4 - Invalid query: SELECT `tbl_gh`.*, `tbl_users`.`isguilder`, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`
FROM `tbl_gh`
LEFT JOIN `tbl_users` ON `tbl_users`.`userid`=`tbl_gh`.`userid`
WHERE tbl_gh.between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:45:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '' at line 2 - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485582319
WHERE tbl_gh.between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND tbl_gh.datecreated between '2017-01-28 00:00:01' AND '2017-01-28 23:59:59'
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ORDER BY `tbl_gh`.`id` DESC
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:58 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:45:59 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 06:51:45 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 07:18:36 --> 404 Page Not Found: web/Management/orders
ERROR - 2017-01-28 07:21:00 --> 404 Page Not Found: web/Management/orders
ERROR - 2017-01-28 07:51:50 --> Query error: Unknown column 'tbl_users,isguider' in 'where clause' - Invalid query: SELECT `tbl_guilder_gh`.*, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.`paymentstatus` as `paymentconfirmed`, `tbl_gh`.`datepaid` as `userdatepaid`
FROM `tbl_guilder_gh`
LEFT JOIN `tbl_gh` ON `tbl_guilder_gh`.`ghid`=`tbl_gh`.`ghid`
LEFT JOIN `tbl_users` ON `tbl_guilder_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users,isguider` = 1
AND `tbl_users,dummyguilder` =0
ERROR - 2017-01-28 07:51:50 --> Query error: Unknown column 'tbl_users,isguider' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485586310
WHERE `tbl_users,isguider` = 1
AND `tbl_users,dummyguilder` =0
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ERROR - 2017-01-28 07:52:00 --> Query error: Unknown column 'tbl_users,isguilder' in 'where clause' - Invalid query: SELECT `tbl_guilder_gh`.*, `tbl_users`.`emailaddress`, `tbl_users`.`phonenumber`, `tbl_gh`.`paymentstatus` as `paymentconfirmed`, `tbl_gh`.`datepaid` as `userdatepaid`
FROM `tbl_guilder_gh`
LEFT JOIN `tbl_gh` ON `tbl_guilder_gh`.`ghid`=`tbl_gh`.`ghid`
LEFT JOIN `tbl_users` ON `tbl_guilder_gh`.`userid`=`tbl_users`.`userid`
WHERE `tbl_users,isguilder` = 1
AND `tbl_users,dummyguilder` =0
ERROR - 2017-01-28 07:52:00 --> Query error: Unknown column 'tbl_users,isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485586320
WHERE `tbl_users,isguilder` = 1
AND `tbl_users,dummyguilder` =0
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ERROR - 2017-01-28 07:52:34 --> 404 Page Not Found: management/Users/guilderpaymentsummary
ERROR - 2017-01-28 08:18:01 --> Severity: Parsing Error --> syntax error, unexpected ''),true);' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\xampp\htdocs\charity\application\controllers\management\Users.php 431
ERROR - 2017-01-28 08:18:50 --> Query error: Unknown column 'tbl_user.emailaddress' in 'field list' - Invalid query: SELECT `tbl_users`.`username`, `tbl_users`.`phonenumber`, `tbl_user`.`emailaddress`, `tbl_user`.`userid`
FROM `tbl_users`
WHERE `tbl_users`.`isguilder` = 1
AND `tbl_users`.`dummyguilder` =0
ERROR - 2017-01-28 08:18:50 --> Query error: Unknown column 'tbl_users.isguilder' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1485587930
WHERE `tbl_users`.`isguilder` = 1
AND `tbl_users`.`dummyguilder` =0
AND `id` = 'd7bd2f476a6fc1d81c05880a6908da0f2e4dc972'
ERROR - 2017-01-28 08:19:18 --> Severity: Notice --> Undefined variable: userid C:\xampp\htdocs\charity\application\controllers\management\Users.php 413
ERROR - 2017-01-28 08:19:18 --> Severity: Error --> Call to undefined method Users::guilderbenfits() C:\xampp\htdocs\charity\application\controllers\management\Users.php 397
ERROR - 2017-01-28 08:19:46 --> Severity: Error --> Call to undefined method Users::guilderbenfits() C:\xampp\htdocs\charity\application\controllers\management\Users.php 397
ERROR - 2017-01-28 08:20:05 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 61
ERROR - 2017-01-28 08:20:47 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting ',' or ';' C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 61
ERROR - 2017-01-28 08:25:17 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 68
ERROR - 2017-01-28 08:26:29 --> Severity: Notice --> Undefined variable: guilers C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 42
ERROR - 2017-01-28 08:26:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 42
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:51 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:52 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 44
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 56
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 59
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined property: stdClass::$guilderid C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:26:53 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 62
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 52
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 53
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:28:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:29:14 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\management\users\guilderpaymentsummary.php 49
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 08:51:34 --> Severity: Notice --> Undefined property: stdClass::$depositorsname C:\xampp\htdocs\charity\application\views\management\dashboard_page.php 129
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 09:03:34 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 09:12:55 --> Severity: Parsing Error --> syntax error, unexpected '(' C:\xampp\htdocs\charity\application\controllers\management\Users.php 198
ERROR - 2017-01-28 09:13:52 --> Severity: Parsing Error --> syntax error, unexpected '(' C:\xampp\htdocs\charity\application\controllers\management\Users.php 198
ERROR - 2017-01-28 09:14:34 --> Severity: Parsing Error --> syntax error, unexpected '(' C:\xampp\htdocs\charity\application\controllers\management\Users.php 198
ERROR - 2017-01-28 09:19:00 --> Query error: Unknown column 'maturityamount' in 'field list' - Invalid query: INSERT INTO `tbl_guilder_gh` (`fullname`, `accountname`, `accountnumber`, `bankname`, `amount`, `userid`, `ghid`, `datemodified`, `datecreated`, `maturityamount`) VALUES ('olafashade', 'OLALEKAN FASHADE', '0130360398', 'GTBank', 125, '14853742757197xj', '14855915403958li', '2017-01-28 09:18:59', '2017-01-28 09:18:59', 125)
ERROR - 2017-01-28 10:21:32 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 10:21:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 10:21:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 10:21:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 15:33:36 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 15:33:37 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 15:33:37 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 15:33:37 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 15:58:27 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 376
ERROR - 2017-01-28 15:58:29 --> Severity: Notice --> Use of undefined constant dddf - assumed 'dddf' C:\xampp\htdocs\charity\application\views\management\users\paydummyguilders.php 87
ERROR - 2017-01-28 15:58:30 --> Severity: Notice --> Use of undefined constant dddf - assumed 'dddf' C:\xampp\htdocs\charity\application\views\management\users\paydummyguilders.php 87
ERROR - 2017-01-28 16:15:37 --> Severity: Notice --> Undefined variable: count C:\xampp\htdocs\charity\application\controllers\management\Users.php 375
ERROR - 2017-01-28 16:47:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 16:47:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 16:47:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 16:47:46 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:02:47 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:02:47 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:02:47 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:02:47 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:02:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:02:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:02:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:02:54 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:03:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:03:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:03:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:03:20 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:04:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:04:15 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:05:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:05:33 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:07:50 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (2017-01-28 2017-01-27 12:00:39) at position 11 (2): Double date specification C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 32
ERROR - 2017-01-28 17:08:56 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:08:56 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:11:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 101
ERROR - 2017-01-28 17:11:02 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:12:51 --> Severity: error --> Exception: DateTime::__construct(): Failed to parse time string (2017-01-28 2017-01-27 12:00:39) at position 11 (2): Double date specification C:\xampp\htdocs\charity\application\helpers\utilities_helper.php 32
ERROR - 2017-01-28 17:16:23 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 101
ERROR - 2017-01-28 17:16:23 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:16:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 101
ERROR - 2017-01-28 17:16:48 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:17:24 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:17:24 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:17:24 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:17:24 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:19:52 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 101
ERROR - 2017-01-28 17:19:52 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:22:17 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 101
ERROR - 2017-01-28 17:22:17 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:23:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 102
ERROR - 2017-01-28 17:23:29 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\unfulfiled_pledges.php 103
ERROR - 2017-01-28 17:33:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:33:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:33:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:33:50 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:00 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 102
ERROR - 2017-01-28 17:34:01 --> Severity: Notice --> Undefined property: stdClass::$orderid C:\xampp\htdocs\charity\application\views\management\orders\benefits.php 103
ERROR - 2017-01-28 18:34:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\charity\application\views\management\orders\release.php 12
