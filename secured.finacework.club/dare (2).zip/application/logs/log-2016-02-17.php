<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-17 09:51:29 --> 404 Page Not Found: /index
ERROR - 2016-02-17 11:25:33 --> 404 Page Not Found: /index
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Css/bootstrap.css
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Css/style.css
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Css/font-awesome.css
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Js/wow.min.js
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Js/jquery-1.11.1.min.js
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Css/clndr.css
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Js/modernizr.custom.js
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Js/Chart.js
ERROR - 2016-02-17 11:44:57 --> 404 Page Not Found: store/Css/animate.css
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/moment-2.2.1.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/metisMenu.min.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/clndr.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/underscore-min.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/custom.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/site.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Css/custom.css
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/modernizr.custom.js
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Css/animate.css
ERROR - 2016-02-17 11:44:58 --> 404 Page Not Found: store/Js/wow.min.js
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Js/Chart.js
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Js/underscore-min.js
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Css/clndr.css
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Js/moment-2.2.1.js
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Js/clndr.js
ERROR - 2016-02-17 11:44:59 --> 404 Page Not Found: store/Js/site.js
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Js/metisMenu.min.js
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Js/custom.js
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Css/custom.css
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:45:00 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Css/font-awesome.css
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Css/animate.css
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Css/style.css
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/wow.min.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/Chart.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/jquery-1.11.1.min.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/modernizr.custom.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Css/clndr.css
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/clndr.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/underscore-min.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/moment-2.2.1.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/site.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/metisMenu.min.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/modernizr.custom.js
ERROR - 2016-02-17 11:46:13 --> 404 Page Not Found: store/Js/custom.js
ERROR - 2016-02-17 11:46:14 --> 404 Page Not Found: store/Js/wow.min.js
ERROR - 2016-02-17 11:46:14 --> 404 Page Not Found: store/Css/custom.css
ERROR - 2016-02-17 11:46:14 --> 404 Page Not Found: store/Css/animate.css
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Js/Chart.js
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Js/underscore-min.js
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Css/clndr.css
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Js/moment-2.2.1.js
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Js/clndr.js
ERROR - 2016-02-17 11:46:15 --> 404 Page Not Found: store/Js/site.js
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Js/metisMenu.min.js
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Js/custom.js
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Css/custom.css
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:46:16 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:50:34 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:50:34 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:50:34 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:50:34 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:51:53 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:51:53 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:51:53 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:51:53 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:55:07 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:55:07 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:55:07 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:55:07 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:56:06 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:56:06 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:56:06 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:56:06 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:57:10 --> Severity: Notice --> Undefined variable: subview C:\xampp\htdocs\estore\application\views\store\_layout_main.php 5
ERROR - 2016-02-17 11:57:11 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:57:12 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:57:12 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:57:12 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:57:58 --> 404 Page Not Found: store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 11:57:58 --> 404 Page Not Found: store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 11:57:58 --> 404 Page Not Found: store/Css/jqvmap.css
ERROR - 2016-02-17 11:57:58 --> 404 Page Not Found: store/Js/jquery.vmap.js
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Css/jqvmap.css
ERROR - 2016-02-17 11:58:01 --> 404 Page Not Found: store/Js/jquery.vmap.js
ERROR - 2016-02-17 11:58:02 --> 404 Page Not Found: store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 11:58:02 --> 404 Page Not Found: store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 11:58:10 --> 404 Page Not Found: store/Gridshtml/index
ERROR - 2016-02-17 11:58:51 --> 404 Page Not Found: store/Dashboard/index
ERROR - 2016-02-17 11:59:09 --> 404 Page Not Found: store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 11:59:09 --> 404 Page Not Found: store/Js/jquery.vmap.js
ERROR - 2016-02-17 11:59:09 --> 404 Page Not Found: store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 11:59:09 --> 404 Page Not Found: store/Css/jqvmap.css
ERROR - 2016-02-17 11:59:10 --> 404 Page Not Found: store/Js/jquery.vmap.js
ERROR - 2016-02-17 11:59:10 --> 404 Page Not Found: store/Css/jqvmap.css
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Images/1.png
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Images/3.png
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Images/a.png
ERROR - 2016-02-17 11:59:11 --> 404 Page Not Found: store/Images/2.png
ERROR - 2016-02-17 12:01:29 --> Severity: Notice --> Undefined property: Authenticate::$data C:\xampp\htdocs\estore\application\controllers\store\Authenticate.php 9
ERROR - 2016-02-17 12:01:29 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:01:29 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:01:29 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:01:29 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:01:29 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:01:30 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:01:30 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:01:30 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:01:39 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:01:40 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:01:40 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:01:40 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:01:41 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:01:41 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:01:41 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:01:41 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:02:22 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:03:39 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:03:39 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:03:39 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:03:39 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:03:42 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:03:43 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:03:43 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:03:43 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:04:41 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:04:41 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:04:41 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:04:41 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:04:42 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:04:42 --> 404 Page Not Found: store/Js/jquery.nicescroll.js
ERROR - 2016-02-17 12:04:43 --> 404 Page Not Found: store/Js/scripts.js
ERROR - 2016-02-17 12:04:43 --> 404 Page Not Found: store/Js/bootstrap.js
ERROR - 2016-02-17 12:09:01 --> Severity: Notice --> Undefined variable: sitename C:\xampp\htdocs\estore\application\views\store\login_page.php 4
ERROR - 2016-02-17 12:09:01 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:09:03 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:09:24 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:09:26 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:10:10 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:10:11 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:17:16 --> Severity: Warning --> pg_connect(): Unable to connect to PostgreSQL server: FATAL:  database &quot;db_estore&quot; does not exist C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 154
ERROR - 2016-02-17 12:17:16 --> Unable to connect to the database
ERROR - 2016-02-17 12:18:36 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:18:37 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:19:43 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:19:45 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:27:09 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:27:11 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:27:39 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:27:40 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:31:20 --> 404 Page Not Found: /index
ERROR - 2016-02-17 12:31:22 --> 404 Page Not Found: /index
ERROR - 2016-02-17 12:31:32 --> 404 Page Not Found: /index
ERROR - 2016-02-17 12:31:58 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:31:58 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:32:05 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:33:01 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-17 12:33:04 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-17 12:33:08 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-17 12:33:40 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:33:50 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-17 12:34:01 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:34:02 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:34:07 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:34:07 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:38:42 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:38:42 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:47:51 --> Severity: Error --> Call to protected method MY_Model::hash() from context 'Authenticate' C:\xampp\htdocs\estore\application\controllers\Store\Authenticate.php 8
ERROR - 2016-02-17 12:49:22 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:49:24 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:04 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:05 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:14 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:29 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:30 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:50:36 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_store_users&quot; does not exist
LINE 2: FROM &quot;t_store_users&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 12:50:36 --> Query error: ERROR:  relation "t_store_users" does not exist
LINE 2: FROM "t_store_users"
             ^ - Invalid query: SELECT *
FROM "t_store_users"
WHERE ((username = 'seunogunmola') OR (email_address = 'seunogunmola')) AND "password" = 'aec74485993ca0eb226625a22d3d2b60273bdb59540e514aa7795093f2d4f032fb1585f71bb4b951e6363db228191680419f5c2659f6555bae3eb937a050320e'
ORDER BY "t_users"."id" ASC
ERROR - 2016-02-17 12:51:41 --> Severity: Warning --> pg_query(): Query failed: ERROR:  missing FROM-clause entry for table &quot;t_users&quot;
LINE 4: ORDER BY &quot;t_users&quot;.&quot;id&quot; ASC
                 ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 12:51:41 --> Query error: ERROR:  missing FROM-clause entry for table "t_users"
LINE 4: ORDER BY "t_users"."id" ASC
                 ^ - Invalid query: SELECT *
FROM "t_store_users"
WHERE ((username = 'seunogunmola') OR (email_address = 'seunogunmola')) AND "password" = 'aec74485993ca0eb226625a22d3d2b60273bdb59540e514aa7795093f2d4f032fb1585f71bb4b951e6363db228191680419f5c2659f6555bae3eb937a050320e'
ORDER BY "t_users"."id" ASC
ERROR - 2016-02-17 12:51:59 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:52:01 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:54:05 --> 404 Page Not Found: Administrator/Authenticate/index
ERROR - 2016-02-17 12:54:09 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:54:10 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:55:01 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:55:03 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:56:21 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:56:22 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 12:56:32 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 12:56:34 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 12:56:34 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 12:56:34 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 12:56:34 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:00:28 --> Severity: Notice --> Undefined property: stdClass::$storeid C:\xampp\htdocs\estore\application\libraries\Store_Controller.php 41
ERROR - 2016-02-17 13:00:29 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:00:57 --> Severity: Notice --> Undefined property: stdClass::$storeid C:\xampp\htdocs\estore\application\libraries\Store_Controller.php 41
ERROR - 2016-02-17 13:01:14 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:01:16 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:01:26 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:01:27 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:02:19 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:02:20 --> 404 Page Not Found: store/Js/classie.js
ERROR - 2016-02-17 13:02:24 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:02:24 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:02:24 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:02:25 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:07:27 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:07:27 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:07:27 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:07:27 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:07:29 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:08:11 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:08:11 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:08:11 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:08:11 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:08:13 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:08:32 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:08:32 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:08:32 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:08:32 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:08:34 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:08:35 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:08:35 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:15:01 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:15:01 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:15:01 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:15:01 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:15:05 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:15:06 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:15:06 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:15:57 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:15:57 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:15:57 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:15:57 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:15:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:29:18 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:29:18 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:29:19 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:29:19 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:29:19 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:29:20 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:29:24 --> Severity: Notice --> Undefined property: Stock::$Store_Category_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:29:24 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:29:48 --> Severity: Notice --> Undefined property: Stock::$Stock_Category_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:29:48 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:29:59 --> Severity: Notice --> Undefined property: Stock::$Stock_Category_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:29:59 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:30:35 --> Severity: Notice --> Undefined property: Stock::$Stock_Category_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:30:35 --> Severity: Error --> Call to a member function get_new() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 18
ERROR - 2016-02-17 13:30:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:30:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:30:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:30:59 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:32:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:32:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:32:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:32:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:33:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:33:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:33:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:33:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:37:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:37:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:37:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:37:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:41:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:42:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:42:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:42:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:42:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:43:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:43:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:43:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:43:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:44:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:45:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:45:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:45:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:45:06 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:47:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:48:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:05 --> 404 Page Not Found: Store/Stock/index.html
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:49:47 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:49:48 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 13:49:56 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 13:50:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:47 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:50:48 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:52:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:52:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:52:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:52:56 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 13:58:08 --> Severity: Notice --> Undefined property: Stock::$Branch_Model C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 29
ERROR - 2016-02-17 13:58:08 --> Severity: Error --> Call to a member function generate_unique_id() on null C:\xampp\htdocs\estore\application\controllers\Store\Stock.php 29
ERROR - 2016-02-17 14:24:05 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;parent_category_id&quot; violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, null, PROVISIONS, PROVISIONS, 2222222222, 2016-02-17 13:24:05.03, 2016-02-17 13:24:05.03). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 14:24:05 --> Query error: ERROR:  null value in column "parent_category_id" violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, null, PROVISIONS, PROVISIONS, 2222222222, 2016-02-17 13:24:05.03, 2016-02-17 13:24:05.03). - Invalid query: INSERT INTO "t_stock_categories" ("stock_category_name", "stock_category_description", "parent_category_id", "storeid", "added_by") VALUES ('PROVISIONS', 'PROVISIONS', NULL, '1111111111', '2222222222')
ERROR - 2016-02-17 14:24:49 --> Severity: Warning --> pg_query(): Query failed: ERROR:  relation &quot;t_stock_categories&quot; does not exist
LINE 2: FROM &quot;t_stock_categories&quot;
             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 14:24:49 --> Query error: ERROR:  relation "t_stock_categories" does not exist
LINE 2: FROM "t_stock_categories"
             ^ - Invalid query: SELECT *
FROM "t_stock_categories"
WHERE "stock_category_name" = 'PROVISIONS'
ERROR - 2016-02-17 14:24:59 --> Severity: Warning --> pg_query(): Query failed: ERROR:  null value in column &quot;stock_category_id&quot; violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, null, PROVISIONS, PROVISIONS, 2222222222, 2016-02-17 13:24:59.532, 2016-02-17 13:24:59.532). C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 14:24:59 --> Query error: ERROR:  null value in column "stock_category_id" violates not-null constraint
DETAIL:  Failing row contains (1, 1111111111, null, null, PROVISIONS, PROVISIONS, 2222222222, 2016-02-17 13:24:59.532, 2016-02-17 13:24:59.532). - Invalid query: INSERT INTO "t_stock_categories" ("stock_category_name", "stock_category_description", "parent_category_id", "storeid", "added_by") VALUES ('PROVISIONS', 'PROVISIONS', NULL, '1111111111', '2222222222')
ERROR - 2016-02-17 14:27:40 --> 404 Page Not Found: Stocks/Stock_Categories
ERROR - 2016-02-17 14:29:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:29:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:29:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:29:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:51:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:51:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:51:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:51:32 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:55:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 14:58:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:19 --> Severity: Notice --> Undefined property: stdClass::$description C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 80
ERROR - 2016-02-17 15:04:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:04:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:07:40 --> Severity: Warning --> pg_query(): Query failed: ERROR:  table name &quot;t_stock_categories&quot; specified more than once C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 15:07:40 --> Query error: ERROR:  table name "t_stock_categories" specified more than once - Invalid query: SELECT "t_stock_categories".*, "t_stock_categories"."stock_category_name"
FROM "t_stock_categories"
LEFT JOIN "t_stock_categories" ON "t_stock_categories"."parent_category_id" = "t_stock_category"."id"
WHERE "storeid" = '1111111111'
ORDER BY "t_stock_categories"."id" ASC
ERROR - 2016-02-17 15:08:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:19 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:08:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:09:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:09:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:09:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:09:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:14 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:10:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:11:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:11:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:11:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:11:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:12:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:12:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:12:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:12:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 93
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 93
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 93
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 93
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 94
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 94
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 94
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 94
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 95
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 95
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Undefined variable: branch C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 95
ERROR - 2016-02-17 15:17:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\estore\application\views\Store\Stock\Stock_Category_Page.php 95
ERROR - 2016-02-17 15:17:43 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:17:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:18:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:18:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:18:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:18:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:23:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:23:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:23:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:23:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:24:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:24:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:24:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:24:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:24:20 --> 404 Page Not Found: Stock/Stock_Categories
ERROR - 2016-02-17 15:25:14 --> Severity: Warning --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;NULL&quot;
LINE 1: ...category_id&quot;) VALUES ('PROVISIONS', 'PROVISIONS', 'NULL', '1...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 15:25:14 --> Query error: ERROR:  invalid input syntax for integer: "NULL"
LINE 1: ...category_id") VALUES ('PROVISIONS', 'PROVISIONS', 'NULL', '1...
                                                             ^ - Invalid query: INSERT INTO "t_stock_categories" ("stock_category_name", "stock_category_description", "parent_category_id", "storeid", "added_by", "stock_category_id") VALUES ('PROVISIONS', 'PROVISIONS', 'NULL', '1111111111', '2222222222', '6822516391')
ERROR - 2016-02-17 15:26:29 --> Severity: Warning --> pg_query(): Query failed: ERROR:  invalid input syntax for integer: &quot;&quot;
LINE 1: ...category_id&quot;) VALUES ('PROVISIONS', 'PROVISIONS', '', '11111...
                                                             ^ C:\xampp\htdocs\estore\system\database\drivers\postgre\postgre_driver.php 242
ERROR - 2016-02-17 15:26:29 --> Query error: ERROR:  invalid input syntax for integer: ""
LINE 1: ...category_id") VALUES ('PROVISIONS', 'PROVISIONS', '', '11111...
                                                             ^ - Invalid query: INSERT INTO "t_stock_categories" ("stock_category_name", "stock_category_description", "parent_category_id", "storeid", "added_by", "stock_category_id") VALUES ('PROVISIONS', 'PROVISIONS', '', '1111111111', '2222222222', '5385737144')
ERROR - 2016-02-17 15:26:54 --> 404 Page Not Found: Store/Stocks/Stock_Categories
ERROR - 2016-02-17 15:27:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:13 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:27:35 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:28:54 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:17 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:36 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:29:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:22 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:23 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:24 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:38 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:40 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:45 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Images/1.png
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Images/3.png
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Images/2.png
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:30:51 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:02 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:04 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:31:05 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:42 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:32:53 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:33:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:34:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:35:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:35:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:35:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:36:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:36:39 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:36:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:03 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:37:07 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:37:08 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:37:08 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:37:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:20 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:26 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:29 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:37:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:38:04 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:38:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:38:34 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:38:50 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:38:51 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:38:52 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:39:46 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:39:58 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:39:59 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:40:16 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:40:16 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:40:16 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:40:16 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:40:16 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:40:17 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:40:17 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:40:17 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:40:17 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:40:21 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:40:21 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:40:21 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:40:21 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:40:21 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:40:22 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:40:22 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:40:22 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:40:23 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:40:23 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:40:30 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:40:30 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:42:37 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:42:44 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:42:44 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:42:44 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:42:44 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Css/jqvmap.css
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Images/a.png
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Js/jquery.vmap.js
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Js/jquery.vmap.sampledata.js
ERROR - 2016-02-17 15:42:45 --> 404 Page Not Found: Store/Js/jquery.vmap.world.js
ERROR - 2016-02-17 15:43:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:43:16 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:43:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:43:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:43:58 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:44:31 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:44:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:44:44 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:47:15 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:47:50 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:48:21 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:49:09 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:50:12 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:51:01 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:53:51 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:53:52 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:56:28 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:57:49 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:58:18 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:58:24 --> 404 Page Not Found: Store/Stock/Stock
ERROR - 2016-02-17 15:58:57 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:59:00 --> 404 Page Not Found: Store/Stock/images
ERROR - 2016-02-17 15:59:01 --> 404 Page Not Found: Store/Stock/images
