<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-25 21:21:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 21:21:37 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-25 21:37:24 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:39:44 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:40:17 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:40:49 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:42:23 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:42:41 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:44:24 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:44:28 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:44:50 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 21:46:07 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:05:35 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:05:38 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:05:54 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:06:28 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:06:55 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:07:19 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:10:39 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:10:53 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:13:33 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:20:20 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:20:56 --> 404 Page Not Found: web/App/schools
ERROR - 2016-07-25 22:42:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 21
ERROR - 2016-07-25 23:26:01 --> Severity: Notice --> Undefined variable: site_style C:\xampp\htdocs\fastfood\application\views\web\_layouts\header.php 11
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: topcategories C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 25
ERROR - 2016-07-25 23:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 25
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: vendors C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 62
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: banners C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 14
ERROR - 2016-07-25 23:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 14
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: featuredvendors C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 125
ERROR - 2016-07-25 23:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 125
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: topcategories C:\xampp\htdocs\fastfood\application\views\web\_layouts\footer.php 15
ERROR - 2016-07-25 23:26:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\footer.php 15
ERROR - 2016-07-25 23:26:02 --> Severity: Notice --> Undefined variable: site_script C:\xampp\htdocs\fastfood\application\views\web\_layouts\footer.php 77
ERROR - 2016-07-25 23:26:03 --> 404 Page Not Found: app/Home/resources
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 65
ERROR - 2016-07-25 23:26:32 --> Severity: Notice --> Undefined variable: dlocations C:\xampp\htdocs\fastfood\application\controllers\app\home.php 70
ERROR - 2016-07-25 23:27:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-25 23:27:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-07-25 23:53:44 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\app\home.php 103
