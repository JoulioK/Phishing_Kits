<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-15 03:46:30 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-15 03:46:52 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 03:47:11 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 03:47:43 --> Severity: Error --> Call to undefined method Vendor_Model::get_new_featured() C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 245
ERROR - 2016-07-15 04:37:39 --> Severity: Notice --> Undefined variable: vendorid C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 232
ERROR - 2016-07-15 04:37:39 --> Query error: Unknown column 'featuredimage' in 'field list' - Invalid query: INSERT INTO `tbl_featured_vendor` (`vendorname`, `vendorslogan`, `status`, `featuredid`, `featuredimage`) VALUES ('Chities', 'We provide meal for everuone to eat', '1', '14685502593743gt', 'http://meals.ng/resources/general/images/vendorlogo/3e7517c9b89d7cac22df2d35f3cd295a.jpg')
ERROR - 2016-07-15 04:40:12 --> Severity: Notice --> Undefined variable: vendorid C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 232
ERROR - 2016-07-15 04:44:12 --> Severity: Notice --> Undefined property: stdClass::$vendorid C:\xampp\htdocs\fastfood\application\views\management\vendor\featured_vendor.php 20
ERROR - 2016-07-15 04:45:39 --> Severity: Notice --> Undefined variable: vendorid C:\xampp\htdocs\fastfood\application\controllers\management\vendor.php 232
ERROR - 2016-07-15 05:07:03 --> Severity: Warning --> mysqli::real_connect(): MySQL server has gone away C:\xampp\htdocs\fastfood\system\database\drivers\mysqli\mysqli_driver.php 135
ERROR - 2016-07-15 05:12:35 --> 404 Page Not Found: management/Configuration/302e208d2052f36ae6ecef628e2318c3.jpg
ERROR - 2016-07-15 18:04:55 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 18:05:14 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 18:22:32 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-07-15 18:49:19 --> Query error: Table 'fastfood.tbl_franchise_slider' doesn't exist - Invalid query: SELECT *
FROM `tbl_franchise_slider`
WHERE `franchiseid` = '2626273373'
ORDER BY `id` ASC
ERROR - 2016-07-15 18:58:04 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 19
ERROR - 2016-07-15 18:58:07 --> 404 Page Not Found: 302e208d2052f36ae6ecef628e2318c3jpg/index
ERROR - 2016-07-15 18:59:13 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 18
ERROR - 2016-07-15 18:59:14 --> 404 Page Not Found: 302e208d2052f36ae6ecef628e2318c3jpg/index
ERROR - 2016-07-15 19:00:03 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 18
ERROR - 2016-07-15 19:00:03 --> 404 Page Not Found: 302e208d2052f36ae6ecef628e2318c3jpg/index
ERROR - 2016-07-15 19:00:03 --> 404 Page Not Found: 302e208d2052f36ae6ecef628e2318c3jpg/index
ERROR - 2016-07-15 19:01:13 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 18
ERROR - 2016-07-15 19:01:13 --> 404 Page Not Found: 302e208d2052f36ae6ecef628e2318c3jpg/index
ERROR - 2016-07-15 19:45:38 --> Query error: Unknown column 'franchiseid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_featured_vendor`
WHERE `franchiseid` = '2626273373'
ORDER BY `id` ASC
 LIMIT 3
ERROR - 2016-07-15 19:55:39 --> Severity: Error --> Call to undefined method Home::gethqfeaturedvendors() C:\xampp\htdocs\fastfood\application\controllers\web\home.php 48
ERROR - 2016-07-15 20:00:40 --> 404 Page Not Found: Kitchenhtml/index
ERROR - 2016-07-15 20:20:14 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 20:20:18 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-15 20:23:55 --> Query error: Unknown column 'vendorurl' in 'field list' - Invalid query: UPDATE `tbl_featured_vendor` SET `vendorname` = 'Chities edited', `vendorslogan` = 'We provide meal for everuone to eat', `status` = '1', `franchiseid` = '2626273373', `vendorurl` = 'http://olafashade.meals.ng'
WHERE `featuredid` = '14685504126684ga'
ERROR - 2016-07-15 20:25:54 --> Severity: Notice --> Undefined property: stdClass::$featuredimage C:\xampp\htdocs\fastfood\application\views\management\vendor\featured_vendor.php 31
ERROR - 2016-07-15 20:36:59 --> Severity: Notice --> Undefined property: stdClass::$vendorlogo C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 106
ERROR - 2016-07-15 20:38:26 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT `franchiseid`
FROM `tbl_franchise_configuration`
WHERE `franchiselocation` = '14668510290307aw'
ORDER BY `categoryname` ASC
ERROR - 2016-07-15 20:39:06 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-15 22:11:40 --> Severity: Compile Error --> Cannot redeclare Mail::pagination() C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 156
ERROR - 2016-07-15 22:13:15 --> 404 Page Not Found: management/Messages/index
ERROR - 2016-07-15 22:13:25 --> 404 Page Not Found: management/Messages/index
ERROR - 2016-07-15 22:14:33 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 15
ERROR - 2016-07-15 22:14:33 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT *
FROM `tbl_messages`
WHERE `status` =0
AND `folder` =0
 LIMIT 10
ERROR - 2016-07-15 22:15:40 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 15
ERROR - 2016-07-15 22:15:40 --> Severity: Notice --> Undefined variable: inbox_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 23
ERROR - 2016-07-15 22:15:40 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-15 22:15:40 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
ERROR - 2016-07-15 22:15:40 --> Severity: Notice --> Undefined variable: pagination C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 49
ERROR - 2016-07-15 22:18:02 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 15
ERROR - 2016-07-15 22:18:02 --> Severity: Warning --> Missing argument 1 for Messages::pagination(), called in C:\xampp\htdocs\fastfood\application\controllers\management\messages.php on line 23 and defined C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 30
ERROR - 2016-07-15 22:18:02 --> Severity: Warning --> Missing argument 2 for Messages::pagination(), called in C:\xampp\htdocs\fastfood\application\controllers\management\messages.php on line 23 and defined C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 30
ERROR - 2016-07-15 22:18:02 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 33
ERROR - 2016-07-15 22:18:02 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 33
ERROR - 2016-07-15 22:18:02 --> Severity: Notice --> Undefined property: Messages::$pagination C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:18:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fastfood\system\core\Exceptions.php:272) C:\xampp\htdocs\fastfood\system\core\Common.php 569
ERROR - 2016-07-15 22:18:02 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:18:43 --> Severity: Warning --> Missing argument 1 for Messages::pagination(), called in C:\xampp\htdocs\fastfood\application\controllers\management\messages.php on line 23 and defined C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 30
ERROR - 2016-07-15 22:18:44 --> Severity: Warning --> Missing argument 2 for Messages::pagination(), called in C:\xampp\htdocs\fastfood\application\controllers\management\messages.php on line 23 and defined C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 30
ERROR - 2016-07-15 22:18:44 --> Severity: Notice --> Undefined variable: page C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 33
ERROR - 2016-07-15 22:18:44 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 33
ERROR - 2016-07-15 22:18:44 --> Severity: Notice --> Undefined property: Messages::$pagination C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:18:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\fastfood\system\core\Exceptions.php:272) C:\xampp\htdocs\fastfood\system\core\Common.php 569
ERROR - 2016-07-15 22:18:44 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:19:16 --> Severity: Notice --> Undefined property: Messages::$pagination C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:19:17 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:20:13 --> Severity: Notice --> Undefined property: Messages::$pagination C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:20:13 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\messages.php 40
ERROR - 2016-07-15 22:21:34 --> Severity: Notice --> Undefined variable: inbox_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 23
ERROR - 2016-07-15 22:21:34 --> Severity: Notice --> Undefined variable: important C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 25
ERROR - 2016-07-15 22:21:34 --> Severity: Notice --> Undefined variable: trash_count C:\xampp\htdocs\fastfood\application\views\management\messages\message.php 27
