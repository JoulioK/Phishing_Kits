<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-05 05:08:23 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:08:23 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:08:57 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:08:57 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:27:17 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:27:17 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:27:36 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:27:36 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:29:04 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:29:04 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:30:59 --> Severity: Notice --> Undefined variable: vendorname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 176
ERROR - 2016-08-05 05:30:59 --> Severity: Notice --> Undefined variable: locationname C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 177
ERROR - 2016-08-05 05:33:21 --> Severity: Notice --> Undefined variable: categories C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 162
ERROR - 2016-08-05 05:35:06 --> Severity: Notice --> Undefined property: stdClass::$categoryid C:\xampp\htdocs\fastfood\application\controllers\app\vendors.php 81
ERROR - 2016-08-05 05:45:44 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-08-05 05:45:44 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:45:44 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:45:44 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:47:38 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-08-05 05:47:38 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:47:38 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:47:38 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 131
ERROR - 2016-08-05 05:48:49 --> Severity: Notice --> Undefined property: stdClass::$from C:\xampp\htdocs\fastfood\application\controllers\app\home.php 42
ERROR - 2016-08-05 05:48:49 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 134
ERROR - 2016-08-05 05:48:49 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 134
ERROR - 2016-08-05 05:48:49 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 134
ERROR - 2016-08-05 05:57:33 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\home.php 41
ERROR - 2016-08-05 05:57:33 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:57:34 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:57:34 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:07 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\controllers\app\home.php 41
ERROR - 2016-08-05 05:58:07 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:07 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:07 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:51 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:51 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 05:58:51 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\fastfood\application\controllers\app\home.php 136
ERROR - 2016-08-05 09:35:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-08-05 09:42:25 --> The filetype you are attempting to upload is not allowed.
ERROR - 2016-08-05 09:43:12 --> The image you are attempting to upload doesn't fit into the allowed dimensions.
ERROR - 2016-08-05 09:44:33 --> Severity: Notice --> Undefined offset: 3 C:\xampp\htdocs\fastfood\application\views\web\_layouts\slider.php 16
ERROR - 2016-08-05 09:52:47 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_franchise_sliders`
WHERE `franchiseid` = '2626273373'
ORDER BY `id` DESC, `categoryname` ASC
 LIMIT 3
ERROR - 2016-08-05 09:56:11 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 09:57:04 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:04:25 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:08:32 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:09:11 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:09:26 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:11:05 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:11:32 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:12:03 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:12:03 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:12:25 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-08-05 10:12:41 --> 404 Page Not Found: web/Home/resources
