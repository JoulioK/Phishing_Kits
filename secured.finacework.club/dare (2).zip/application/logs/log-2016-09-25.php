<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-25 07:23:12 --> 404 Page Not Found: 
ERROR - 2016-09-25 07:24:46 --> Severity: Error --> Call to undefined method CI_Cart::content() C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 26
ERROR - 2016-09-25 07:32:35 --> Severity: Notice --> Undefined property: CI_Loader::$items_model C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 26
ERROR - 2016-09-25 07:32:35 --> Severity: Error --> Call to a member function checkifitemincart() on a non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 26
ERROR - 2016-09-25 07:38:19 --> Severity: Notice --> Undefined variable: price C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 26
ERROR - 2016-09-25 07:38:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 26
ERROR - 2016-09-25 07:38:19 --> Severity: Error --> Call to undefined function array_flatten() C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 137
ERROR - 2016-09-25 07:38:32 --> Severity: Warning --> Missing argument 1 for Item_model::checkifitemincart(), called in C:\xampp\htdocs\fastfood\application\views\web\pages\item.php on line 26 and defined C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 131
ERROR - 2016-09-25 07:38:32 --> Severity: Error --> Call to undefined function array_flatten() C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 137
ERROR - 2016-09-25 07:38:50 --> Severity: Error --> Call to undefined function array_flatten() C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 137
ERROR - 2016-09-25 07:59:12 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\fastfood\application\models\web\Item_model.php 138
ERROR - 2016-09-25 10:43:09 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\xampp\htdocs\fastfood\application\controllers\app\Item.php 737
ERROR - 2016-09-25 13:21:49 --> Severity: Parsing Error --> syntax error, unexpected '$rowcount' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 538
ERROR - 2016-09-25 13:37:32 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) C:\xampp\htdocs\fastfood\application\controllers\web\Item.php 148
