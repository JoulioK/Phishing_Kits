<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-27 05:31:32 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-27 05:39:01 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\models\web\Customer_model.php 93
ERROR - 2017-02-27 05:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 93
ERROR - 2017-02-27 05:39:01 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-02-27 05:39:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-02-27 05:39:02 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\charity\application\models\web\Customer_model.php 100
ERROR - 2017-02-27 05:39:02 --> Query error: Column 'userid' in where clause is ambiguous - Invalid query: SELECT `ghid`
FROM `tbl_gh`, `tbl_users`
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
ERROR - 2017-02-27 05:39:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-02-27 05:39:02 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488170342
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
AND `id` = '51a49276de30a09b9fcdbf55dd7db150d704fde5'
ERROR - 2017-02-27 05:39:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\charity\system\core\Exceptions.php:272) C:\xampp\htdocs\charity\system\core\Common.php 569
ERROR - 2017-02-27 05:53:07 --> Query error: Column 'userid' in where clause is ambiguous - Invalid query: SELECT `ghid`
FROM `tbl_gh`, `tbl_referral_earnings`
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
ERROR - 2017-02-27 05:53:07 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488171187
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
AND `id` = '51a49276de30a09b9fcdbf55dd7db150d704fde5'
ERROR - 2017-02-27 06:08:47 --> Query error: Not unique table/alias: 'tbl_gh' - Invalid query: SELECT `ghid`
FROM `tbl_gh`, `tbl_gh`
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
ERROR - 2017-02-27 06:08:47 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1488172127
WHERE `userid` = '14871013565699zk'
AND `paymentstatus` = 2
AND `phuser` IS NULL
AND `amount` >= 212.5
AND `id` = '51a49276de30a09b9fcdbf55dd7db150d704fde5'
