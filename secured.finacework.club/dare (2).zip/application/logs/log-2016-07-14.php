<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-14 00:01:22 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:01:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-14 00:02:51 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:02:52 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:02:52 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:09 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:10 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:10 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:11 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:11 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:11 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:11 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:11 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:12 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:12 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:12 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:49 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:03:50 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 00:04:06 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 00:04:07 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 00:04:51 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 00:04:52 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 00:04:53 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:22 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:26 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:27 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:32 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:47 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:48 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:51 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:51 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:52 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:53 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:54 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:54 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:55 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:56 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:57 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:57 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:58 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:59 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:06:59 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:00 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:01 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:02 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:02 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:03 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:04 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:05 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:23 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:36 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:07:36 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:26:59 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:27:00 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:28:27 --> Severity: Parsing Error --> syntax error, unexpected 'sksk' (T_STRING), expecting function (T_FUNCTION) C:\xampp\htdocs\fastfood\application\core\MY_Router.php 9
ERROR - 2016-07-14 00:28:46 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:28:47 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:28:48 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:29:30 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:29:31 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:29:32 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:07 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:08 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:27 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:27 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:28 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:41 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:30:41 --> 404 Page Not Found: /index
ERROR - 2016-07-14 00:41:09 --> Severity: Notice --> Use of undefined constant EXT - assumed 'EXT' C:\xampp\htdocs\fastfood\application\core\MY_Router.php 10
ERROR - 2016-07-14 00:41:09 --> Severity: Notice --> Use of undefined constant EXT - assumed 'EXT' C:\xampp\htdocs\fastfood\application\core\MY_Router.php 39
ERROR - 2016-07-14 00:41:09 --> 404 Page Not Found: web/home
ERROR - 2016-07-14 00:41:52 --> Severity: Error --> Call to undefined method CI_URI::_reindex_segments() C:\xampp\htdocs\fastfood\application\core\MY_Router.php 45
ERROR - 2016-07-14 00:46:55 --> Severity: Notice --> Undefined variable: class C:\xampp\htdocs\fastfood\application\core\MY_Router.php 34
ERROR - 2016-07-14 00:46:55 --> Severity: Notice --> Undefined variable: method C:\xampp\htdocs\fastfood\application\core\MY_Router.php 36
ERROR - 2016-07-14 00:47:02 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 00:47:02 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 00:47:02 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 00:47:03 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 00:47:04 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 00:48:26 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 00:48:27 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 00:48:28 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 00:48:28 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 00:48:28 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 00:48:28 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 00:48:28 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 00:49:49 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 00:49:50 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:41 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:42 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 00:50:48 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 00:50:48 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 00:50:48 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 00:50:48 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 00:50:48 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 00:50:49 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 00:50:50 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 00:50:50 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 00:50:50 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 00:50:50 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 00:50:50 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 00:58:23 --> Severity: Error --> Call to undefined function current_url() C:\xampp\htdocs\fastfood\application\core\MY_Router.php 50
ERROR - 2016-07-14 01:00:13 --> Severity: Error --> Class 'CI_Controller' not found C:\xampp\htdocs\fastfood\system\core\CodeIgniter.php 366
ERROR - 2016-07-14 01:04:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\core\MY_Router.php 51
ERROR - 2016-07-14 01:16:53 --> 404 Page Not Found: vendor/Home/index
ERROR - 2016-07-14 01:16:57 --> 404 Page Not Found: vendor/Home/index
ERROR - 2016-07-14 01:17:17 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 01:17:18 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 01:17:18 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 01:17:19 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 01:17:20 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 01:17:44 --> 404 Page Not Found: web/Vendor/index
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 01:24:01 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 01:24:02 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 01:35:08 --> 404 Page Not Found: web/Index/index
ERROR - 2016-07-14 01:35:32 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-07-14 01:37:17 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 01:37:17 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 01:37:17 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 01:37:17 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 01:37:18 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 01:37:19 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 01:37:22 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 01:37:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-14 01:37:57 --> 404 Page Not Found: web/Faviconico/index
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 01:44:12 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 01:44:13 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:18 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 01:44:26 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 01:44:26 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 01:44:26 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 01:44:27 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 01:44:28 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 01:44:28 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 01:52:51 --> 404 Page Not Found: 
ERROR - 2016-07-14 02:04:13 --> Severity: Notice --> Undefined variable: locations C:\xampp\htdocs\fastfood\application\views\web\vendors\home.php 21
ERROR - 2016-07-14 02:04:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\vendors\home.php 21
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:04:33 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:04:34 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:04:35 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:04:35 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:04:35 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:04:35 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:05:17 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:05:18 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:10:59 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:11:00 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:11:39 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:11:40 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:18:44 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:18:45 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:21:34 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:21:34 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:21:34 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:21:34 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:21:35 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:21:36 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:21:36 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:23:33 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:23:34 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:23:54 --> Severity: Notice --> Undefined property: stdClass::$vendorbanner C:\xampp\htdocs\fastfood\application\views\web\_layouts\vendorbanner.php 7
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:23:55 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:23:56 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:24:45 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:24:46 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:24:47 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:27:22 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:27:23 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:27:24 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:27:24 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:27:24 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:27:24 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:27:24 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:27:50 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:27:51 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:27:52 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:30:55 --> Severity: Notice --> Undefined property: stdClass::$locationid C:\xampp\htdocs\fastfood\application\views\web\_layouts\vendorbanner.php 27
ERROR - 2016-07-14 02:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\home_model.php 55
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:30:55 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:30:56 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:31:15 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:31:15 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:31:16 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:31:17 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:31:17 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:31:17 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:32:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:32:36 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:33:37 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:33:38 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:38:21 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:38:22 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:38:23 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:38:40 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:38:41 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:38:42 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:39:07 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:39:08 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:40:04 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:40:05 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:40:42 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:40:43 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:40:44 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:41:24 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:41:24 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:41:25 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:41:26 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:41:26 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:41:26 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:42:08 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:42:09 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:43:05 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:43:06 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:44:07 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:44:08 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:44:26 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:44:27 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 02:47:41 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 02:47:42 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 02:53:49 --> 404 Page Not Found: web/Index/index
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/resources
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:10 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 02:54:11 --> 404 Page Not Found: web/Vendor/images
ERROR - 2016-07-14 18:52:24 --> 404 Page Not Found: web/Vendors/authenticate
ERROR - 2016-07-14 18:52:39 --> 404 Page Not Found: web/Authenticate/index
ERROR - 2016-07-14 18:53:04 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-14 18:53:07 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-14 18:53:34 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 3
ERROR - 2016-07-14 18:53:43 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 3
ERROR - 2016-07-14 18:54:05 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-14 19:10:41 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-14 19:10:49 --> 404 Page Not Found: vendor/Js/classie.js
ERROR - 2016-07-14 19:11:13 --> Severity: Error --> Class 'Store_Controller' not found C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 3
ERROR - 2016-07-14 19:11:24 --> Severity: Notice --> Use of undefined constant NUL - assumed 'NUL' C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 26
ERROR - 2016-07-14 19:11:24 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 131
ERROR - 2016-07-14 19:11:42 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 26
ERROR - 2016-07-14 19:18:09 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 137
ERROR - 2016-07-14 19:18:11 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 137
ERROR - 2016-07-14 19:18:35 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 137
ERROR - 2016-07-14 19:18:56 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 137
ERROR - 2016-07-14 19:18:57 --> Severity: Error --> Call to undefined method Configuration::getresources() C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 137
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 23
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 23
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 24
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 24
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 30
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 30
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: location C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 38
ERROR - 2016-07-14 19:19:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 38
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 48
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 48
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 54
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 54
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 59
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 59
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 64
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 64
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Undefined variable: franchise C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 69
ERROR - 2016-07-14 19:19:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\vendor\config\configuration.php 69
ERROR - 2016-07-14 19:22:56 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:22:56 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:22:56 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:22:56 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:22:56 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:22:57 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:22:58 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:22:58 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:26:45 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:26:46 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:27:24 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:27:25 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:27:44 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:27:45 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:34:55 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:34:56 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:34:56 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:35:44 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:35:44 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:35:45 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:36:15 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:36:16 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:36:29 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:36:29 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:36:29 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:36:29 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:36:30 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:36:31 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:36:31 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:36:44 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:36:44 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:36:44 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:36:44 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:36:44 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:36:45 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:36:59 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:37:00 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:39:41 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:39:42 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:41:39 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:42:22 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:42:23 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:42:23 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:42:23 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:42:23 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:42:41 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:42:42 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:47:15 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:47:16 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:51:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 44
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:51:16 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:51:17 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:53:09 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:53:10 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:53:50 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:53:50 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:53:50 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:53:50 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:53:50 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:53:51 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:54:14 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:54:15 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:54:32 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:54:33 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:55:16 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:55:17 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:56:01 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:56:02 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:56:16 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of2.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of3.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of5.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of4.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of1.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of8.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of7.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of6.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of9.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of11.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of10.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of13.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of14.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of15.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of12.png
ERROR - 2016-07-14 19:56:27 --> 404 Page Not Found: Images/of16.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of19.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of17.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of18.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of21.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of20.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of22.png
ERROR - 2016-07-14 19:56:28 --> 404 Page Not Found: Images/of23.png
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:13 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:14 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:15 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:57:36 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:57:37 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:49 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:50 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:57:52 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:57:53 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:04 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:05 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:07 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:58:07 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:58:08 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:58:09 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:12 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:13 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-14 19:58:14 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 19:58:15 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 19:58:16 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 19:58:16 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 19:58:20 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` = '14668583422639we'
ORDER BY `categoryname` ASC
ERROR - 2016-07-14 19:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 19:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 19:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 19:58:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 19:58:21 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` IS NULL
ORDER BY `categoryname` ASC
ERROR - 2016-07-14 20:00:01 --> Severity: Error --> Cannot access protected property Item_model::$_ordey_by C:\xampp\htdocs\fastfood\application\controllers\web\item.php 15
ERROR - 2016-07-14 20:00:36 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` = '14668583422639we'
ORDER BY `categoryname` ASC
ERROR - 2016-07-14 20:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:00:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:00:37 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT `vendorname`, `vendorurl`
FROM `tbl_vendors`
WHERE `vendorid` IS NULL
ORDER BY `categoryname` ASC
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 9
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 16
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 19
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 23
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 42
ERROR - 2016-07-14 20:02:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:03:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:04:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:05:25 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:05:26 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-14 20:05:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:06:03 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:06:04 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:08:04 --> Severity: Error --> Cannot access protected property Vendor_Model::$_primary_filter C:\xampp\htdocs\fastfood\application\controllers\vendor\configuration.php 81
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:14:52 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:14:53 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:18:34 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:18:35 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:18:51 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:18:51 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:18:51 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:18:52 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:19:17 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:19:18 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:19:32 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:19:33 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:20:21 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:20:22 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:20:22 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:20:22 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:20:22 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:20:36 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:20:37 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:20:37 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:20:37 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:20:37 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:20:37 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:21:11 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:21:11 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:21:12 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:21:51 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:21:52 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:22:59 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:23:00 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:53:12 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:53:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:53:12 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:53:13 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:53:14 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:53:37 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:53:38 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:53:49 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:53:50 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:54:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:54:09 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:54:20 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:54:21 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:54:21 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:54:21 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:54:29 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:54:30 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:54:41 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:54:42 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 20:55:53 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 20:55:54 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 21:00:31 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 21:00:31 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 21:00:31 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 21:00:31 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 21:00:31 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 21:00:32 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-14 21:04:54 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-14 21:04:55 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:09 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:05:10 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-14 21:06:34 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:07:55 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:08:53 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:09:45 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:14:16 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ',' or ';' C:\xampp\htdocs\fastfood\application\views\web\_layouts\footer.php 17
ERROR - 2016-07-14 21:14:17 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:14:18 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-14 21:14:36 --> 404 Page Not Found: web/Resources/general
