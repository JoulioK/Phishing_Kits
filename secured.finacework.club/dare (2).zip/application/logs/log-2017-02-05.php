<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-05 08:24:08 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\charity\application\controllers\web\Settings.php 51
ERROR - 2017-02-05 09:26:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\web\Settings.php 64
ERROR - 2017-02-05 09:26:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\libraries\Customer_Controller.php 19
