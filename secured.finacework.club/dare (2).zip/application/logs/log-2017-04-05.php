<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-05 00:57:42 --> 404 Page Not Found: web/Resources/images
