<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-29 00:04:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-29 00:04:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-29 03:22:21 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:22:21 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-29 03:22:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-29 03:23:44 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:23:44 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:25:59 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:25:59 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:26:31 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:26:31 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:28:08 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$get C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:28:08 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 234
ERROR - 2016-07-29 03:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 203
ERROR - 2016-07-29 03:28:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 204
ERROR - 2016-07-29 03:31:48 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\fastfood\application\controllers\app\item.php 271
ERROR - 2016-07-29 03:31:48 --> Severity: Notice --> Undefined variable: itemlocations C:\xampp\htdocs\fastfood\application\controllers\app\item.php 282
ERROR - 2016-07-29 03:32:29 --> Severity: Notice --> Use of undefined constant locationname - assumed 'locationname' C:\xampp\htdocs\fastfood\application\controllers\app\item.php 276
ERROR - 2016-07-29 03:33:47 --> Severity: Notice --> Undefined index: unit C:\xampp\htdocs\fastfood\application\controllers\app\item.php 303
ERROR - 2016-07-29 03:33:47 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\fastfood\application\controllers\app\item.php 303
ERROR - 2016-07-29 03:33:47 --> Severity: Notice --> Undefined index: 14669259683913zm C:\xampp\htdocs\fastfood\application\controllers\app\item.php 303
ERROR - 2016-07-29 03:33:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 315
ERROR - 2016-07-29 03:37:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 315
ERROR - 2016-07-29 21:04:32 --> Severity: Notice --> Undefined property: stdClass::$transactionref C:\xampp\htdocs\fastfood\application\controllers\app\item.php 377
ERROR - 2016-07-29 21:04:32 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\fastfood\application\controllers\app\item.php 408
ERROR - 2016-07-29 21:04:32 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\fastfood\application\controllers\app\item.php 409
ERROR - 2016-07-29 21:04:33 --> Query error: Unknown column 'orderid' in 'field list' - Invalid query: INSERT INTO `tbl_shippings` (`orderid`, `transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `address`, `location`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`, `shippingid`, `amount`) VALUES ('14698190721651vs', '14698189286802zy', NULL, '14675775313398tp', '146692631194989yk', '14668222030861qv', '2626273373', 'No 23, Nawfia Street', '14668510290307aw', '14669259683913zm', 5, NULL, 0, '14690183167607ce', '2016-07-29 21:04:32', '2016-07-29 21:04:32', 0, '14698190735635gb', 500)
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 370
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 371
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 372
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 373
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 374
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 375
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 376
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 377
ERROR - 2016-07-29 21:04:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\app\item.php 382
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 450
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 451
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Undefined variable: ditem C:\xampp\htdocs\fastfood\application\controllers\app\item.php 454
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\app\item.php 454
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\controllers\app\item.php 468
ERROR - 2016-07-29 21:04:59 --> Severity: Notice --> Undefined variable: status C:\xampp\htdocs\fastfood\application\controllers\app\item.php 469
ERROR - 2016-07-29 21:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-29 21:12:50 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\fastfood\application\controllers\app\item.php 408
ERROR - 2016-07-29 21:12:50 --> Severity: Notice --> Undefined property: stdClass::$price C:\xampp\htdocs\fastfood\application\controllers\app\item.php 409
ERROR - 2016-07-29 21:12:50 --> Query error: Unknown column 'orderid' in 'field list' - Invalid query: INSERT INTO `tbl_shippings` (`orderid`, `transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `address`, `location`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`, `shippingid`, `amount`) VALUES ('14698195702289tl', '14698194980893oh', '12164441690458', '14675775313398tp', '146692631194989yk', '14668222030861qv', '2626273373', 'No 23, Nawfia Street', '14668510290307aw', '14669259683913zm', 5, NULL, 0, '14690183167607ce', '2016-07-29 21:12:50', '2016-07-29 21:12:50', 0, '14698195705468yw', 500)
ERROR - 2016-07-29 21:31:31 --> Query error: Unknown column 'orderid' in 'field list' - Invalid query: INSERT INTO `tbl_shippings` (`orderid`, `transactionid`, `transactionref`, `userid`, `packageid`, `vendorid`, `franchiseid`, `address`, `location`, `itemid`, `quantity`, `price`, `total`, `addressid`, `datecreated`, `datemodified`, `status`, `shippingid`, `amount`) VALUES ('14698206914733qg', '14698203315437tw', '12175896178641', '14675775313398tp', '146692631194989yk', '14668222030861qv', '2626273373', 'No 23, Nawfia Street', '14668510290307aw', 14669259683913, 5, '400.00', 2000, '14690183167607ce', '2016-07-29 21:31:31', '2016-07-29 21:31:31', 0, '14698206916980gl', 500)
