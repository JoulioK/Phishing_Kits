<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-18 01:43:31 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 01:43:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 01:43:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 02:05:53 --> 404 Page Not Found: web/Images/tt2.png
ERROR - 2017-01-18 02:05:54 --> 404 Page Not Found: web/Images/1.png
ERROR - 2017-01-18 02:05:54 --> 404 Page Not Found: web/Images/2.png
ERROR - 2017-01-18 02:05:54 --> 404 Page Not Found: web/Images/w.jpg
ERROR - 2017-01-18 02:42:23 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\mytickets.php 68
ERROR - 2017-01-18 03:19:42 --> 404 Page Not Found: Tickets/viewticket
ERROR - 2017-01-18 03:20:07 --> 404 Page Not Found: Support/viewticket
ERROR - 2017-01-18 03:20:54 --> 404 Page Not Found: Support/viewticket
ERROR - 2017-01-18 03:21:57 --> Severity: Notice --> Undefined property: Support::$tickets_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 228
ERROR - 2017-01-18 03:21:58 --> Severity: Error --> Call to a member function GetTicketDetails() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 228
ERROR - 2017-01-18 03:27:49 --> Severity: Notice --> Undefined index: clientid C:\xampp\htdocs\charity\application\controllers\web\Support.php 234
ERROR - 2017-01-18 03:29:35 --> Severity: Notice --> Undefined variable: ticketid C:\xampp\htdocs\charity\application\controllers\web\Support.php 222
ERROR - 2017-01-18 03:30:09 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 72
ERROR - 2017-01-18 03:30:09 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 72
ERROR - 2017-01-18 03:30:09 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 72
ERROR - 2017-01-18 03:30:09 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 72
ERROR - 2017-01-18 03:30:09 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 72
ERROR - 2017-01-18 03:43:39 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 116
ERROR - 2017-01-18 03:43:39 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 163
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 116
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 142
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 142
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 142
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 142
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined index: fullname C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 142
ERROR - 2017-01-18 03:44:51 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 163
ERROR - 2017-01-18 03:45:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 116
ERROR - 2017-01-18 03:45:11 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 163
ERROR - 2017-01-18 03:45:33 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 163
ERROR - 2017-01-18 03:48:40 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 03:49:10 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 03:49:23 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 03:49:50 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 03:50:00 --> Severity: Notice --> Undefined variable: clienthash C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 06:32:14 --> Severity: Notice --> Undefined property: Support::$emails_model C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:32:15 --> Severity: Error --> Call to a member function GetSetting() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:33:32 --> Severity: Notice --> Undefined property: Support::$emails C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:33:32 --> Severity: Error --> Call to a member function GetSetting() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:33:38 --> Severity: Notice --> Undefined property: Support::$emails C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:33:38 --> Severity: Error --> Call to a member function GetSetting() on a non-object C:\xampp\htdocs\charity\application\controllers\web\Support.php 278
ERROR - 2017-01-18 06:34:17 --> Severity: Notice --> Undefined property: Support::$clients_model C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-18 06:34:17 --> Severity: Error --> Call to a member function GetClientData() on a non-object C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 66
ERROR - 2017-01-18 06:35:53 --> Severity: Notice --> Undefined property: Support::$clients_model C:\xampp\htdocs\charity\system\core\Model.php 77
ERROR - 2017-01-18 06:35:53 --> Severity: Error --> Call to a member function GetClientData() on a non-object C:\xampp\htdocs\charity\application\models\web\Tickets_model.php 66
ERROR - 2017-01-18 06:36:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 06:36:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 06:36:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 06:36:11 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\charity\application\views\web\customer\viewticket.php 130
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:04:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 16:16:01 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 27
ERROR - 2017-01-18 16:16:01 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 27
ERROR - 2017-01-18 16:16:01 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 158
ERROR - 2017-01-18 16:16:01 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 158
ERROR - 2017-01-18 16:17:22 --> 404 Page Not Found: web/Settings/index
ERROR - 2017-01-18 16:17:38 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 27
ERROR - 2017-01-18 16:17:38 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 27
ERROR - 2017-01-18 16:17:38 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 158
ERROR - 2017-01-18 16:17:38 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 158
ERROR - 2017-01-18 16:20:31 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:20:31 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:20:31 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:20:31 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:21:04 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:21:04 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:21:04 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:21:04 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:21:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:21:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:21:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:21:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:23:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:23:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 29
ERROR - 2017-01-18 16:23:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:23:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 160
ERROR - 2017-01-18 16:29:46 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 41
ERROR - 2017-01-18 16:29:46 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 41
ERROR - 2017-01-18 16:29:46 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 172
ERROR - 2017-01-18 16:29:46 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 172
ERROR - 2017-01-18 16:30:39 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 43
ERROR - 2017-01-18 16:30:39 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 43
ERROR - 2017-01-18 16:30:39 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 174
ERROR - 2017-01-18 16:30:39 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 174
ERROR - 2017-01-18 16:31:06 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 43
ERROR - 2017-01-18 16:31:06 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 43
ERROR - 2017-01-18 16:31:06 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 174
ERROR - 2017-01-18 16:31:06 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 174
ERROR - 2017-01-18 16:31:50 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:31:50 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:31:50 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:31:50 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:33:29 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:33:29 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:33:29 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:33:29 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:33:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:33:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:33:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:33:49 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:36:55 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:36:55 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 42
ERROR - 2017-01-18 16:36:55 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:36:55 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 173
ERROR - 2017-01-18 16:38:00 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:38:00 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:39:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:39:54 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:41:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:41:08 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 175
ERROR - 2017-01-18 16:44:20 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 177
ERROR - 2017-01-18 16:44:20 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 177
ERROR - 2017-01-18 16:44:37 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 177
ERROR - 2017-01-18 16:44:37 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 177
ERROR - 2017-01-18 16:45:12 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 178
ERROR - 2017-01-18 16:45:12 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 178
ERROR - 2017-01-18 16:47:45 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 181
ERROR - 2017-01-18 16:47:45 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 181
ERROR - 2017-01-18 16:48:14 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 16:48:14 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 16:48:48 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 16:48:48 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 16:49:19 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 16:49:19 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\referral.php 183
ERROR - 2017-01-18 20:37:26 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-18 20:37:26 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484768246
WHERE `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ORDER BY `bankname` ASC
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:38:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 20:40:46 --> 404 Page Not Found: web/Settings/profile
ERROR - 2017-01-18 20:41:05 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-18 20:41:05 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484768465
WHERE `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ORDER BY `bankname` ASC
ERROR - 2017-01-18 21:02:03 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-18 21:02:04 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484769724
WHERE `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ORDER BY `bankname` ASC
ERROR - 2017-01-18 21:02:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 21:02:38 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 21:02:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 94
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 97
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:02:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 110
ERROR - 2017-01-18 21:17:22 --> Query error: Table 'helpcabal.tbl_banks' doesn't exist - Invalid query: SELECT *
FROM `tbl_banks`
ORDER BY `bankname` ASC
ERROR - 2017-01-18 21:17:22 --> Query error: Unknown column 'bankname' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484770642
WHERE `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ORDER BY `bankname` ASC
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 55
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 55
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 62
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 62
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 69
ERROR - 2017-01-18 21:17:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 69
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 55
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 55
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 62
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 62
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Undefined variable: account C:\xampp\htdocs\charity\application\views\web\customer\profile.php 69
ERROR - 2017-01-18 21:19:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\profile.php 69
ERROR - 2017-01-18 21:48:43 --> Query error: Unknown column 'bankid' in 'field list' - Invalid query: UPDATE `tbl_users` SET `fullname` = 'Ola Fashade', `phonenumber` = '08068752947', `emailaddress` = 'olafashade@hotmail.com', `bitcoinaddress` = '1skskdkdddkdlfkflfl', `accountname` = 'Olalekan Fashade Edited', `accountnumber` = '0130360398', `bankid` = NULL, `datemodified` = '2017-01-18 21:48:43'
WHERE `userid` = '14675775313398tp'
ERROR - 2017-01-18 22:04:52 --> Severity: Notice --> Undefined property: User::$user_model C:\xampp\htdocs\charity\application\controllers\web\User.php 90
ERROR - 2017-01-18 22:04:52 --> Severity: Error --> Call to a member function hash() on a non-object C:\xampp\htdocs\charity\application\controllers\web\User.php 90
ERROR - 2017-01-18 22:08:23 --> Severity: Notice --> Undefined property: stdClass::$bitcoinaddress C:\xampp\htdocs\charity\application\views\web\customer\profile.php 37
ERROR - 2017-01-18 22:11:32 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484773892, `data` = 'user_session|O:8:\"stdClass\":16:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";s:19:\"1skskdkdddkdlfkflfl\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-18 21:51:41\";}user_loggedin|b:1;error|s:32:\"Phone already exist, try another\";__ci_vars|a:2:{s:5:\"error\";s:3:\"new\";s:4:\"user\";s:3:\"new\";}user|O:8:\"stdClass\":8:{s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"bankname\";s:7:\" Gtbank\";s:11:\"accountname\";s:16:\"Olalekan Fashade\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"password\";s:4:\"xxxc\";s:6:\"submit\";s:14:\"Update Profile\";}'
WHERE `userid` != '14675775313398tp'
AND `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ERROR - 2017-01-18 22:13:27 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484774007, `data` = 'user_session|O:8:\"stdClass\":16:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";s:19:\"1skskdkdddkdlfkflfl\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-18 21:51:41\";}user_loggedin|b:1;error|s:32:\"Phone already exist, try another\";__ci_vars|a:2:{s:5:\"error\";s:3:\"new\";s:4:\"user\";s:3:\"new\";}user|O:8:\"stdClass\":8:{s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"bankname\";s:7:\" Gtbank\";s:11:\"accountname\";s:16:\"Olalekan Fashade\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"password\";s:4:\"xxxc\";s:6:\"submit\";s:14:\"Update Profile\";}'
WHERE `userid` != '14675775313398tp'
AND `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
ERROR - 2017-01-18 22:14:06 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1484774046, `data` = 'user_session|O:8:\"stdClass\":16:{s:2:\"id\";s:1:\"1\";s:6:\"userid\";s:16:\"14675775313398tp\";s:8:\"fullname\";s:11:\"Ola Fashade\";s:12:\"emailaddress\";s:22:\"olafashade@hotmail.com\";s:11:\"phonenumber\";s:11:\"08068752947\";s:8:\"password\";s:128:\"876de0325d57e40bc185d1cf45bccb1339b1fbe8978618fa7edefe8497b286bd268a9885ede34f2c2d858f0e54fdfca57d5ec71c8dfb044861419eb42ef780c6\";s:7:\"enabled\";s:1:\"1\";s:16:\"verificationcode\";s:4:\"4211\";s:11:\"accountname\";s:23:\"Olalekan Fashade Edited\";s:13:\"accountnumber\";s:10:\"0130360398\";s:8:\"bankname\";s:7:\" Gtbank\";s:7:\"sponsor\";s:0:\"\";s:7:\"earning\";s:2:\"10\";s:14:\"bitcoinaddress\";s:19:\"1skskdkdddkdlfkflfl\";s:11:\"datecreated\";s:19:\"2016-09-13 22:45:05\";s:12:\"datemodified\";s:19:\"2017-01-18 21:51:41\";}user_loggedin|b:1;'
WHERE `userid` != '14675775313398tp'
AND `id` = 'bd8c0418bedce56c918682c5042f330d99a3a279'
