<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-01 01:44:31 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-01 03:19:07 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-01 04:07:48 --> 404 Page Not Found: web/News/1
ERROR - 2017-02-01 04:08:37 --> Severity: Error --> Call to undefined method CI_DB_mysqli_driver::set_flashdata() C:\xampp\htdocs\charity\application\controllers\web\News.php 18
ERROR - 2017-02-01 04:09:36 --> 404 Page Not Found: web/Dashboard/index
ERROR - 2017-02-01 08:57:44 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2017-02-01 09:04:58 --> Severity: Notice --> Undefined variable: gh C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 221
ERROR - 2017-02-01 09:04:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 221
ERROR - 2017-02-01 17:14:14 --> 404 Page Not Found: management/Js/classie.js
