<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-14 02:53:45 --> 404 Page Not Found: web/Images/u2.jpg
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-14 02:53:45 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-14 03:49:54 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 13
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 13
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 14
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 14
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 15
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 15
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 17
ERROR - 2016-11-14 03:49:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 17
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 13
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 13
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 14
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 14
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Undefined variable: about C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 15
ERROR - 2016-11-14 03:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\controllers\web\Pricing.php 15
ERROR - 2016-11-14 03:56:20 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-14 03:56:20 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-14 03:58:35 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-14 03:58:35 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-14 04:34:06 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-14 04:34:08 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-14 04:49:21 --> Severity: Parsing Error --> syntax error, unexpected '1500' (T_LNUMBER), expecting ',' or ';' C:\xampp\htdocs\caroossa\application\views\web\pricing.php 41
ERROR - 2016-11-14 05:25:30 --> 404 Page Not Found: web/Images/u1.jpeg
ERROR - 2016-11-14 05:25:31 --> 404 Page Not Found: web/Images/u2.jpg
ERROR - 2016-11-14 05:56:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 05:56:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\caroossa\application\models\management\Order_model.php 26
ERROR - 2016-11-14 06:54:52 --> Query error: Unknown column 'optionid' in 'field list' - Invalid query: INSERT INTO `tbl_item_options` (`optionid`, `itemid`, `optiontransmission`, `optioncolor`, `optionquantity`, `datecreated`, `datemodified`) VALUES ('14791028920668yx', '14791024063336wd', 'Automatic', NULL, '2', '2016-11-14 06:54:51', '2016-11-14 06:54:51')
ERROR - 2016-11-14 07:03:41 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 26
ERROR - 2016-11-14 07:05:30 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:05:52 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:06:17 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:06:36 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:06:58 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:07:52 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:08:30 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:08:51 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:09:02 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
ERROR - 2016-11-14 07:09:19 --> Severity: Error --> Call to undefined method Items_Model::getitemprice() C:\xampp\htdocs\caroossa\application\views\web\pages\home.php 83
