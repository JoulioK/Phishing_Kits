<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:16 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:17 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 08:49:25 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 08:49:26 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: /index
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 08:49:28 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 08:49:29 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 08:49:30 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:51:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 08:51:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 08:51:31 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 20
ERROR - 2016-07-13 08:54:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\web\item_model.php 23
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 08:54:13 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 08:54:14 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 08:54:34 --> Severity: Error --> Call to undefined method Item_model::getdisplayimage() C:\xampp\htdocs\fastfood\application\views\web\customer\orders.php 41
ERROR - 2016-07-13 08:55:01 --> Severity: Error --> Call to undefined method Item_model::getdisplayimage() C:\xampp\htdocs\fastfood\application\views\web\customer\orders.php 41
ERROR - 2016-07-13 08:55:48 --> Severity: Error --> Call to undefined method Item_model::getdisplayimage() C:\xampp\htdocs\fastfood\application\views\web\customer\orders.php 41
ERROR - 2016-07-13 09:06:43 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:06:43 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:06:43 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:06:43 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:06:43 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:06:44 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:06:45 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:06:45 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:06:45 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:06:45 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:07:08 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:07:09 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:07:22 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:07:23 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:06 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:07 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:08 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:08 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:08 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:14:17 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:14:18 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:14:19 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:14:19 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:14:21 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:14:22 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:14:23 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:14:23 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:14:23 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:14:23 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:14:23 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:14:38 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:14:39 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:15:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:15:12 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:15:12 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:15:12 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:15:13 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:15:14 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:15:29 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:15:30 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:15:31 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:16:08 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:16:09 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:16:36 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:16:37 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:16:50 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:16:51 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:26:19 --> Severity: Error --> Class 'FarmLite_Model' not found C:\xampp\htdocs\fastfood\application\models\web\message_model.php 14
ERROR - 2016-07-13 09:53:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php 29
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:53:02 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:53:03 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:55:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php 29
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:55:12 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:55:13 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:55:13 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:55:13 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:55:13 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:55:13 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:55:42 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:55:42 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:55:42 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:55:42 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:55:43 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:55:44 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 09:56:53 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 09:56:54 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 09:56:55 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 09:56:55 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 09:56:55 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 09:56:55 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 10:09:32 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 10:09:33 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 10:09:33 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 10:09:33 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 10:09:33 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 10:09:33 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 10:09:34 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 10:09:34 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 10:09:34 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 10:09:34 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 10:09:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 10:09:37 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 10:10:15 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 10:10:16 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 10:37:14 --> 404 Page Not Found: Messages/compose
ERROR - 2016-07-13 10:37:30 --> Severity: Notice --> Undefined variable: trends C:\xampp\htdocs\fastfood\application\views\web\customer\compose.php 30
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:31 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:32 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 10:37:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 11:25:14 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 11:25:15 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 11:25:28 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 11:25:29 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 11:25:31 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 11:25:32 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 11:25:35 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 11:25:36 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 11:25:36 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 11:25:36 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 11:25:36 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 11:25:36 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:37 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:38 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:25:38 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:04 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:04 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:04 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:05 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:26:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:27:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:17 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:29:18 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:40 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:41 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:41 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:41 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:41 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:41 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:50 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:32:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:40:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:40:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:40:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:40:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:40:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:00 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:14 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 11:41:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:19 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:20 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:03:23 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:03:24 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:03:25 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:03:27 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:03:28 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:03:31 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:03:32 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:03:32 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:03:32 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:03:32 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:03:32 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:33 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:34 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:35 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:03:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:51 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:52 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:04:56 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:15 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:06:16 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:53 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:55 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:58 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:11:59 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:14:25 --> Severity: Error --> Cannot access protected property Message_model::$_tablename C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 50
ERROR - 2016-07-13 14:14:49 --> Severity: Error --> Call to undefined method Message_model::get_where() C:\xampp\htdocs\fastfood\application\models\web\message_model.php 43
ERROR - 2016-07-13 14:16:05 --> Query error: Unknown column 'storeid' in 'field list' - Invalid query: SELECT `storeid`, `firstname`
FROM `tbl_messages`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-07-13 14:23:24 --> Query error: Unknown column 'username' in 'field list' - Invalid query: SELECT `username`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-07-13 14:24:35 --> Severity: Notice --> Undefined variable: storename C:\xampp\htdocs\fastfood\application\models\web\message_model.php 78
ERROR - 2016-07-13 14:24:35 --> Severity: Notice --> Undefined property: stdClass::$recipientuserid C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php 37
ERROR - 2016-07-13 14:24:35 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `userid` IS NULL
AND `franchiseid` IS NULL
ERROR - 2016-07-13 14:25:08 --> Severity: Notice --> Undefined variable: storename C:\xampp\htdocs\fastfood\application\models\web\message_model.php 78
ERROR - 2016-07-13 14:25:08 --> Severity: Notice --> Undefined property: stdClass::$recipientuserid C:\xampp\htdocs\fastfood\application\views\web\customer\trends.php 37
ERROR - 2016-07-13 14:25:08 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `userid` IS NULL
AND `franchiseid` IS NULL
ERROR - 2016-07-13 14:26:28 --> Severity: Notice --> Undefined variable: storename C:\xampp\htdocs\fastfood\application\models\web\message_model.php 78
ERROR - 2016-07-13 14:26:28 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `userid` = '2626273373'
AND `franchiseid` = '2626273373'
ERROR - 2016-07-13 14:26:51 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: SELECT `franchisename`
FROM `tbl_franchise_configuration`
WHERE `userid` = '2626273373'
AND `franchiseid` = '2626273373'
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:27:55 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:27:57 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:27:58 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:28:33 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:28:34 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:30:27 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:28 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:29 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:35 --> Query error: Unknown column 'trendid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_franchise_configuration`
WHERE `trendid` = '14684130358407uh'
ERROR - 2016-07-13 14:30:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:46 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:47 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:48 --> 404 Page Not Found: web/Messages/images
ERROR - 2016-07-13 14:30:49 --> Query error: Unknown column 'trendid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_franchise_configuration`
WHERE `trendid` = '14684130358407uh'
ERROR - 2016-07-13 14:31:05 --> Query error: Unknown column 'trendid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_franchise_configuration`
WHERE `trendid` = '14684130358407uh'
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:32:12 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:32:13 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:33:22 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:33:23 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:33:23 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:33:23 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:33:23 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:33:30 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:34:08 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:34:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:34:09 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:34:10 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:35:04 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:35:05 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:35:21 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:35:22 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 14:56:32 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 14:56:33 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:01:47 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:01:47 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:01:47 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:01:47 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:01:48 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:01:50 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:01:51 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:02:04 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:02:05 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:02:35 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:02:36 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:02:36 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:02:36 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:03:31 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:03:32 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:04:16 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:04:17 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:04:30 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:04:31 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:04:36 --> 404 Page Not Found: web/Messages/trend
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:45 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:46 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:47 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:48 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:48 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:48 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:48 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:34:48 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 15:35:07 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:35:07 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:35:07 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 15:35:07 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:35:08 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:35:09 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:35:10 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:35:10 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:35:10 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:35:10 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:35:10 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:35:11 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:35:11 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:35:11 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:35:12 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 15:35:13 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:35:13 --> Severity: Notice --> Undefined property: Messages::$pagination C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 103
ERROR - 2016-07-13 15:35:13 --> Severity: Error --> Call to a member function initialize() on a non-object C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 103
ERROR - 2016-07-13 15:35:40 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 15:35:41 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 16:03:41 --> Severity: Error --> Call to undefined function dayth() C:\xampp\htdocs\fastfood\application\helpers\utilities_helper.php 124
ERROR - 2016-07-13 16:27:07 --> Severity: Parsing Error --> syntax error, unexpected 'private' (T_PRIVATE) C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 123
ERROR - 2016-07-13 16:27:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:27:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:28:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:29:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 52
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:10 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:31 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:32 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:35 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:37 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:53 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:30:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:26 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:26 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:27 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: file_url C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:33:30 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:13 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined index: page_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:25 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:27 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined index: page_level_style C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 11
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:34:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:11 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:12 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:48 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:35:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:36:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:41:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:42:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:46:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:48:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:49:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:02 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:50:09 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:51:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:52:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:18 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:18 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:19 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:20 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:25 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:26 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:27 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:28 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:28 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:29 --> Severity: Warning --> Missing argument 2 for Messages::trendpagination(), called in C:\xampp\htdocs\fastfood\application\controllers\web\messages.php on line 121 and defined C:\xampp\htdocs\fastfood\application\controllers\web\messages.php 144
ERROR - 2016-07-13 16:53:29 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:53:29 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 58
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:54 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:54:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:03 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:05 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:55:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:01 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:56:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:13 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:44 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:45 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:40 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:41 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:50 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:58:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:21 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:22 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 16:59:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:23 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:26 --> Severity: Notice --> Undefined variable: message C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\customer\trend.php 60
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 17:00:38 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 17:00:39 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 17:00:51 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 17:00:52 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 17:00:54 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 17:00:55 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:00 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:01 --> 404 Page Not Found: web/Customer/images
ERROR - 2016-07-13 17:01:44 --> 404 Page Not Found: /index
ERROR - 2016-07-13 17:01:53 --> 404 Page Not Found: /index
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 17:02:04 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 17:02:05 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 22:22:21 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:22 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:23 --> 404 Page Not Found: web/Authenticate/images
ERROR - 2016-07-13 22:22:28 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 22:22:29 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 22:22:30 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 22:22:30 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 22:22:30 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 22:22:30 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 22:22:31 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 22:22:32 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 22:24:07 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 22:24:08 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 22:26:05 --> 404 Page Not Found: web/Indexhtml/index
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of1.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of2.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of3.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of5.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of4.png
ERROR - 2016-07-13 22:26:09 --> 404 Page Not Found: web/Images/of6.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of7.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of10.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of8.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of9.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of12.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of13.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of14.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of11.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of16.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of15.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of17.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of18.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of19.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of22.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of21.png
ERROR - 2016-07-13 22:26:10 --> 404 Page Not Found: web/Images/of23.png
ERROR - 2016-07-13 22:26:11 --> 404 Page Not Found: web/Images/of20.png
ERROR - 2016-07-13 22:26:16 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:16 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:17 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:18 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:26:22 --> Severity: Error --> Call to undefined method Home_model::get_where() C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:26:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:26:57 --> Severity: Error --> Call to undefined method Home_model::get_where() C:\xampp\htdocs\fastfood\application\controllers\web\home.php 34
ERROR - 2016-07-13 22:27:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:27:49 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND 0 = 'franchiseid'
AND 1 IS NULL
ORDER BY `id` ASC
 LIMIT 20
ERROR - 2016-07-13 22:29:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:29:46 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND `franchiseid` IS NULL
ORDER BY `id` ASC
 LIMIT 20
ERROR - 2016-07-13 22:33:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:33:39 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
AND `tbl_items`.`franchiseid` IS NULL
ORDER BY `id` ASC
 LIMIT 20
ERROR - 2016-07-13 22:34:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:35:00 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `tbl_items`
LEFT JOIN `tbl_item_location` ON `tbl_item_location`.`itemid`=`tbl_items`.`itemid`
WHERE `tbl_item_location`.`locationname` = '14668510290307aw'
ORDER BY `id` ASC
 LIMIT 20
ERROR - 2016-07-13 22:37:15 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\fastfood\application\controllers\web\home.php 36
ERROR - 2016-07-13 22:37:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:37:26 --> Severity: Error --> Cannot access protected property Home_model::$_ordey_by C:\xampp\htdocs\fastfood\application\controllers\web\home.php 35
ERROR - 2016-07-13 22:37:57 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:37:57 --> Query error: Unknown column 'tbl_items.id' in 'order clause' - Invalid query: SELECT *
FROM `tbl_item_category`
ORDER BY `tbl_items`.`id` DESC
ERROR - 2016-07-13 22:38:56 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:38:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:58 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:38:59 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:00 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\home.php 22
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:39:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:03 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:21 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:40:22 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:01 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:41:02 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:38 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:48:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:40 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:40 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:40 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:41 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:48:42 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:36 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 22:58:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:03:04 --> Severity: Notice --> Undefined variable: vendors C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 64
ERROR - 2016-07-13 23:03:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 64
ERROR - 2016-07-13 23:04:39 --> Severity: Notice --> Undefined variable: vendors C:\xampp\htdocs\fastfood\application\views\web\_layouts\navigation.php 64
ERROR - 2016-07-13 23:06:02 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:07:20 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:08:29 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:08:41 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:08:42 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:08:43 --> Query error: Unknown column 'categoryname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_locations`
ORDER BY `categoryname` ASC
ERROR - 2016-07-13 23:09:40 --> Query error: Unknown column 'locationname' in 'order clause' - Invalid query: SELECT *
FROM `tbl_franchise_configuration`
WHERE `franchiselocation` = '14668510290307aw'
ORDER BY `locationname` ASC
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:28 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:56 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:10:57 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:26 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:14:27 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:34 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:35 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:36 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:37 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:38 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
ERROR - 2016-07-13 23:32:39 --> 404 Page Not Found: web/Home/images
