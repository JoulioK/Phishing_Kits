<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-06 06:42:28 --> Severity: Notice --> Undefined variable: social C:\xampp\htdocs\charity\application\views\web\_layouts\footer.php 67
