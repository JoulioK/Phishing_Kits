<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-07-22 23:15:55 --> Severity: Warning --> touch() [<a href='function.touch'>function.touch</a>]: Unable to create file ci_sessions/ci_sessionda4691ce9f877ffb0a922159ab1c160526734395 because No such file or directory /home/secureds/mandatory.securedserver.ltd/system/libraries/Session/drivers/Session_files_driver.php 234
