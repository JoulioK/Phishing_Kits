<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-05-09 03:25:42 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\login.php 43
ERROR - 2017-05-09 03:25:42 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\login.php 44
ERROR - 2017-05-09 03:25:42 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\login.php 46
ERROR - 2017-05-09 03:25:42 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\login.php 46
ERROR - 2017-05-09 03:30:38 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\register.php 48
ERROR - 2017-05-09 03:30:38 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\register.php 49
ERROR - 2017-05-09 03:30:38 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\register.php 51
ERROR - 2017-05-09 03:30:38 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\register.php 51
ERROR - 2017-05-09 03:31:07 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 35
ERROR - 2017-05-09 03:31:07 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 36
ERROR - 2017-05-09 03:31:07 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:31:07 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:31:26 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 35
ERROR - 2017-05-09 03:31:26 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 36
ERROR - 2017-05-09 03:31:26 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:31:26 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:31:43 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 35
ERROR - 2017-05-09 03:31:43 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 36
ERROR - 2017-05-09 03:31:43 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:31:43 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:33:03 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 35
ERROR - 2017-05-09 03:33:03 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 36
ERROR - 2017-05-09 03:33:03 --> Severity: Notice --> Undefined variable: no1 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
ERROR - 2017-05-09 03:33:03 --> Severity: Notice --> Undefined variable: no2 C:\xampp\htdocs\coinxtra\application\views\web\authenticate\forgot.php 38
