<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-17 13:24:17 --> Query error: Column 'userid' in where clause is ambiguous - Invalid query: SELECT *
FROM `tbl_gh`
JOIN `tbl_users` ON `tbl_gh`.`userid`=`tbl_users`.`userid`
WHERE amount between '80000' AND '81000' AND `userid` != '14853742757197xj'
AND `tbl_gh`.`userid` != '14853742757197xj'
AND `tbl_gh`.`userid` != '14675775313398tp'
AND `tbl_users`.`isguilder` =0
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`phuser` IS NULL
ORDER BY `tbl_gh`.`id` asc
 LIMIT 2
ERROR - 2017-02-17 13:24:18 --> Query error: Unknown column 'amount' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1487334258
WHERE amount between '80000' AND '81000' AND `userid` != '14853742757197xj'
AND `tbl_gh`.`userid` != '14853742757197xj'
AND `tbl_gh`.`userid` != '14675775313398tp'
AND `tbl_users`.`isguilder` =0
AND `tbl_gh`.`paymentstatus` =0
AND `tbl_gh`.`phuser` IS NULL
AND `id` = '94792266e69eea8a0f2e60eca6b0fe97fbde8203'
ORDER BY `tbl_gh`.`id` asc LIMIT 2
ERROR - 2017-02-17 21:37:27 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\charity\application\controllers\web\Earnings.php 2
ERROR - 2017-02-17 21:37:41 --> Severity: Error --> Class 'Frontend_Controller' not found C:\xampp\htdocs\charity\application\controllers\web\Earnings.php 3
