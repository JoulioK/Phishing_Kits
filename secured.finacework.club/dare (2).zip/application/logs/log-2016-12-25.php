<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-12-25 08:25:41 --> 404 Page Not Found: web/Authenticate/l
ERROR - 2016-12-25 08:30:33 --> 404 Page Not Found: web/Authenticate/login
ERROR - 2016-12-25 08:30:47 --> 404 Page Not Found: web/Auth/login
ERROR - 2016-12-25 08:31:18 --> 404 Page Not Found: web/User/dashboard
ERROR - 2016-12-25 09:48:46 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 09:48:47 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 09:48:47 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 09:49:33 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 09:49:33 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 09:49:34 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 10:28:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 58
ERROR - 2016-12-25 10:29:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 58
ERROR - 2016-12-25 10:29:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 58
ERROR - 2016-12-25 10:30:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 58
ERROR - 2016-12-25 10:31:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 56
ERROR - 2016-12-25 10:31:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 56
ERROR - 2016-12-25 10:32:36 --> 404 Page Not Found: web/Customer/dashboard
ERROR - 2016-12-25 10:32:46 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 10:32:46 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 10:32:46 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 10:33:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 56
ERROR - 2016-12-25 10:42:40 --> 404 Page Not Found: web/Customer/dashboard
ERROR - 2016-12-25 10:42:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\charity\application\views\web\customer\ph.php 56
ERROR - 2016-12-25 11:09:47 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 68
ERROR - 2016-12-25 11:10:34 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 68
ERROR - 2016-12-25 11:11:37 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 67
ERROR - 2016-12-25 11:12:42 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 67
ERROR - 2016-12-25 11:13:53 --> Severity: Parsing Error --> syntax error, unexpected 'endif' (T_ENDIF), expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\ph.php 67
ERROR - 2016-12-25 11:23:10 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\charity\application\views\web\customer\ph.php 78
ERROR - 2016-12-25 11:25:21 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\ph.php 18
ERROR - 2016-12-25 11:26:43 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\ph.php 18
ERROR - 2016-12-25 11:26:53 --> Severity: Notice --> Undefined variable: phs C:\xampp\htdocs\charity\application\views\web\customer\ph.php 18
ERROR - 2016-12-25 11:27:19 --> Query error: Table 'bitnaira.tbl_gh' doesn't exist - Invalid query: SELECT *
FROM `tbl_gh`
WHERE amount between '10' AND '30'
AND `paymentstatus` =0
ERROR - 2016-12-25 11:27:19 --> Query error: Unknown column 'amount' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1482661639
WHERE amount between '10' AND '30'
AND `paymentstatus` =0
AND `id` = 'df1b712eefa99578fa967da4189e37341ff9b85d'
ERROR - 2016-12-25 11:49:37 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 22
ERROR - 2016-12-25 11:49:37 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 29
ERROR - 2016-12-25 11:49:37 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 50
ERROR - 2016-12-25 11:49:37 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 51
ERROR - 2016-12-25 11:49:37 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\charity\application\views\web\customer\profile.php 56
ERROR - 2016-12-25 11:53:16 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 22
ERROR - 2016-12-25 11:53:16 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 29
ERROR - 2016-12-25 11:53:16 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 50
ERROR - 2016-12-25 11:53:16 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 51
ERROR - 2016-12-25 11:53:16 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\charity\application\views\web\customer\profile.php 56
ERROR - 2016-12-25 11:55:21 --> Severity: Notice --> Undefined property: stdClass::$firstname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 94
ERROR - 2016-12-25 11:55:21 --> Severity: Notice --> Undefined property: stdClass::$lastname C:\xampp\htdocs\charity\application\views\web\customer\profile.php 101
ERROR - 2016-12-25 11:55:21 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 122
ERROR - 2016-12-25 11:55:21 --> Severity: Notice --> Undefined property: stdClass::$identity C:\xampp\htdocs\charity\application\views\web\customer\profile.php 123
ERROR - 2016-12-25 11:55:21 --> Severity: Notice --> Undefined property: stdClass::$expirydate C:\xampp\htdocs\charity\application\views\web\customer\profile.php 128
ERROR - 2016-12-25 12:22:18 --> 404 Page Not Found: web/Customer/profile
ERROR - 2016-12-25 12:23:21 --> 404 Page Not Found: web/Customer/profile
ERROR - 2016-12-25 12:27:52 --> 404 Page Not Found: web/Customer/dashboard
ERROR - 2016-12-25 12:28:04 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 12:28:04 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 12:28:04 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 13:22:18 --> Severity: Notice --> Undefined variable: bitcoinaddress C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 81
ERROR - 2016-12-25 13:22:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 81
ERROR - 2016-12-25 13:31:06 --> Severity: Notice --> Undefined property: stdClass::$fullname C:\xampp\htdocs\charity\application\views\web\customer\ph.php 63
ERROR - 2016-12-25 13:46:27 --> 404 Page Not Found: Cabal/help
ERROR - 2016-12-25 14:59:14 --> Severity: Parsing Error --> syntax error, unexpected '==' (T_IS_EQUAL), expecting ')' C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 163
ERROR - 2016-12-25 14:59:25 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 248
ERROR - 2016-12-25 15:04:26 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:04:26 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:04:26 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:04:44 --> 404 Page Not Found: Cabal/help
ERROR - 2016-12-25 15:05:28 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 141
ERROR - 2016-12-25 15:05:28 --> Severity: Notice --> Undefined property: stdClass::$amount C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 142
ERROR - 2016-12-25 15:05:28 --> Severity: Error --> Call to undefined method Cabal::config() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 142
ERROR - 2016-12-25 15:07:28 --> Severity: Error --> Call to undefined method Cabal::config() C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 142
ERROR - 2016-12-25 15:17:22 --> 404 Page Not Found: web/Customer/dashboard
ERROR - 2016-12-25 15:17:30 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:17:30 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:17:30 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:39:48 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:39:48 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:39:48 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:47 --> 404 Page Not Found: web/Customer/dashboard
ERROR - 2016-12-25 15:41:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:53 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:53 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:41:53 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:28 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:30 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:30 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:42 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:42 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:56:42 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:01 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:01 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:01 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:38 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:38 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:57:38 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:18 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:18 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:18 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:36 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:37 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:37 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:45 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:45 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:58:45 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:23 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:23 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:23 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:27 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:27 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:27 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:50 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:56 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:56 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 15:59:56 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:00:34 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:00:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:00:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:12 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:12 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:12 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:34 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:01:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:02:22 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:02:22 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:02:23 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:24 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:24 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:24 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:49 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:49 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:03:49 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:04:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:04:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:04:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:05:29 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:05:29 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:05:29 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:07:37 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:07:37 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:07:37 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:17 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:17 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:17 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:41 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:42 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:08:42 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:00 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:34 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:09:35 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:01 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:02 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:02 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:57 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:57 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:10:57 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:19 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:19 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:19 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:38 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:39 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:39 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:58 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:58 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:11:58 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:12:31 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:12:31 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:12:31 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:14:43 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 74
ERROR - 2016-12-25 16:14:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:14:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:14:51 --> 404 Page Not Found: web/User/images
ERROR - 2016-12-25 16:40:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 87
ERROR - 2016-12-25 16:40:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 87
ERROR - 2016-12-25 16:40:06 --> Severity: Notice --> Undefined variable: order C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 87
ERROR - 2016-12-25 16:40:06 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 87
ERROR - 2016-12-25 16:40:06 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 87
ERROR - 2016-12-25 17:02:24 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) C:\xampp\htdocs\charity\application\models\web\Customer_model.php 102
ERROR - 2016-12-25 17:05:26 --> Severity: Notice --> Undefined variable: timeaway C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2016-12-25 17:05:26 --> Severity: Error --> Function name must be a string C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2016-12-25 17:07:57 --> Severity: Parsing Error --> syntax error, unexpected '{' C:\xampp\htdocs\charity\application\controllers\web\Cabal.php 180
ERROR - 2016-12-25 17:29:34 --> Severity: Notice --> Undefined property: User::$user_model C:\xampp\htdocs\charity\application\controllers\web\User.php 67
ERROR - 2016-12-25 17:29:34 --> Severity: Error --> Call to a member function get() on a non-object C:\xampp\htdocs\charity\application\controllers\web\User.php 67
