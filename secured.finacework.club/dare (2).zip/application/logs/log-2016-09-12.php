<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-12 08:05:14 --> Severity: Notice --> Undefined variable: current_url C:\xampp\htdocs\fastfood\application\controllers\web\Vendor.php 15
ERROR - 2016-09-12 08:05:14 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:05:15 --> Severity: Notice --> Undefined variable: current_url C:\xampp\htdocs\fastfood\application\controllers\web\Vendor.php 15
ERROR - 2016-09-12 08:05:15 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:05:32 --> Severity: Notice --> Undefined variable: current_url C:\xampp\htdocs\fastfood\application\controllers\web\Vendor.php 15
ERROR - 2016-09-12 08:05:32 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:05:43 --> Severity: Notice --> Undefined variable: current_url C:\xampp\htdocs\fastfood\application\controllers\web\Vendor.php 15
ERROR - 2016-09-12 08:05:43 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:05:43 --> Severity: Notice --> Undefined variable: current_url C:\xampp\htdocs\fastfood\application\controllers\web\Vendor.php 15
ERROR - 2016-09-12 08:05:43 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:08:07 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:12:40 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:13:08 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:13:50 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:15:49 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:18:13 --> 404 Page Not Found: 
ERROR - 2016-09-12 08:21:29 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:22:09 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:22:39 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:22:42 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:23:43 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:23:45 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:24:18 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:24:22 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:24:25 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:24:29 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:25:41 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:26:17 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:35:43 --> 404 Page Not Found: web/Crunchiesenugu/index
ERROR - 2016-09-12 08:37:59 --> Severity: Error --> Call to undefined method MY_Router::checksubdomain() C:\xampp\htdocs\fastfood\application\core\MY_Router.php 6
ERROR - 2016-09-12 08:38:17 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:40:47 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:40:50 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:41:06 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:41:24 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:43:56 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:45:42 --> 404 Page Not Found: web/Vedd/index
ERROR - 2016-09-12 08:45:48 --> 404 Page Not Found: web/Vedd/index
ERROR - 2016-09-12 08:45:52 --> 404 Page Not Found: web/Vedd/index
ERROR - 2016-09-12 08:45:54 --> 404 Page Not Found: web/Vedd/index
ERROR - 2016-09-12 08:53:23 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:53:33 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:53:42 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:54:16 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:54:30 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:55:14 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:55:41 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:56:43 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:58:16 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:58:18 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:58:52 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 08:59:05 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:00:12 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:00:37 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:00:47 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:01:01 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:01:54 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:02:23 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:02:37 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:03:47 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:04:16 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:04:52 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:05:51 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:06:08 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:06:58 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:08:16 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:11:28 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:19:28 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:19:35 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:23:46 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:24:19 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:29:42 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:52:14 --> 404 Page Not Found: Crunchiesenugu/index
ERROR - 2016-09-12 09:52:35 --> 404 Page Not Found: web/Resources/web
