<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-06 21:41:47 --> 404 Page Not Found: web/Authenticate/login
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 94
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 94
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 95
ERROR - 2017-01-06 23:43:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 95
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 93
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 94
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 94
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 95
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 95
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 97
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:43:01 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 99
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Undefined property: stdClass::$paymentstatu C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:49:14 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Undefined property: stdClass::$paymentstatu C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 96
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:49:15 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:38 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 95
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\models\web\Customer_model.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Undefined variable: ph C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
ERROR - 2017-01-06 23:51:39 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\charity\application\views\web\customer\dashboard.php 98
