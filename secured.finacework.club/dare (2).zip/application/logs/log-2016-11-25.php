<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-11-25 00:48:24 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 00:54:34 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 00:55:31 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 00:55:44 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 00:56:24 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 00:57:13 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 08:45:13 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 08:46:29 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 11:23:38 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 11:30:01 --> Severity: Notice --> Undefined property: stdClass::$cart C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 218
ERROR - 2016-11-25 11:31:59 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 217
ERROR - 2016-11-25 11:33:08 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 217
ERROR - 2016-11-25 11:33:39 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 217
ERROR - 2016-11-25 11:33:54 --> Severity: Notice --> Undefined property: stdClass::$address C:\xampp\htdocs\snappycoin\application\controllers\app\Item.php 217
ERROR - 2016-11-25 14:05:45 --> Query error: Table 'bitnaira.tbl_user' doesn't exist - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_user`
LEFT JOIN `tbl_banks` ON `tbl_user`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-25 14:05:46 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079146
WHERE `userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:07:10 --> Query error: Table 'bitnaira.tbl_user' doesn't exist - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_user`
LEFT JOIN `tbl_banks` ON `tbl_user`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-25 14:07:10 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079230
WHERE `userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:10:16 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 272
ERROR - 2016-11-25 14:10:16 --> Query error: Table 'bitnaira.tbl_user' doesn't exist - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_user`
LEFT JOIN `tbl_banks` ON `tbl_user`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` IS NULL
ERROR - 2016-11-25 14:10:16 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079416
WHERE `userid` IS NULL
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:11:18 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 272
ERROR - 2016-11-25 14:11:18 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` IS NULL
ERROR - 2016-11-25 14:11:18 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079478
WHERE `userid` IS NULL
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:12:25 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-25 14:12:25 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079545
WHERE `userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:12:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 272
ERROR - 2016-11-25 14:12:36 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` IS NULL
ERROR - 2016-11-25 14:12:37 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079557
WHERE `userid` IS NULL
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:13:04 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `userid` = '14675775313398tp'
ERROR - 2016-11-25 14:13:04 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079584
WHERE `userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:14:34 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `tbl_users`.`userid` = '14675775313398tp'
ERROR - 2016-11-25 14:14:34 --> Query error: Unknown column 'tbl_users.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079674
WHERE `tbl_users`.`userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:15:49 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `tbl_users`.`userid` = '14675775313398tp'
ERROR - 2016-11-25 14:15:50 --> Query error: Unknown column 'tbl_users.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079750
WHERE `tbl_users`.`userid` = '14675775313398tp'
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:15:55 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 272
ERROR - 2016-11-25 14:15:55 --> Query error: Column 'bankid' in field list is ambiguous - Invalid query: SELECT `accountname`, `accountnumber`, `bankid`
FROM `tbl_users`
LEFT JOIN `tbl_banks` ON `tbl_users`.`bankid`=`tbl_banks`.`bankid`
WHERE `tbl_users`.`userid` IS NULL
ERROR - 2016-11-25 14:15:55 --> Query error: Unknown column 'tbl_users.userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480079755
WHERE `tbl_users`.`userid` IS NULL
AND `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ERROR - 2016-11-25 14:25:12 --> Query error: Table 'bitnaira.tbl_items' doesn't exist - Invalid query: SELECT *
FROM `tbl_items`
ORDER BY `tbl_items`.`datecreated` ASC
 LIMIT 6
ERROR - 2016-11-25 14:25:12 --> Query error: Unknown column 'tbl_items.datecreated' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480080312
WHERE `id` = '1f6658b6bac36f331e27735d7fa9ad6e4059cc66'
ORDER BY `tbl_items`.`datecreated` ASC LIMIT 6
ERROR - 2016-11-25 15:12:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Settings.php 272
ERROR - 2016-11-25 19:18:39 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` = '14675775313398tp'
ORDER BY `id` ASC
ERROR - 2016-11-25 19:18:39 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480097919
WHERE `userid` = '14675775313398tp'
AND `id` = '07fe67b551b5ee25978d624efbbcae4f6d5fe248'
ORDER BY `id` ASC
ERROR - 2016-11-25 19:19:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Messages.php 17
ERROR - 2016-11-25 19:19:00 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\snappycoin\application\controllers\app\Messages.php 18
ERROR - 2016-11-25 19:19:00 --> Query error: Unknown column 'fullname' in 'field list' - Invalid query: SELECT `fullname`
FROM `tbl_users`
WHERE `userid` IS NULL
ORDER BY `id` ASC
ERROR - 2016-11-25 19:19:00 --> Query error: Unknown column 'userid' in 'where clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480097940
WHERE `userid` IS NULL
AND `id` = '07fe67b551b5ee25978d624efbbcae4f6d5fe248'
ORDER BY `id` ASC
ERROR - 2016-11-25 20:10:02 --> Query error: Table 'bitnaira.tbl_items' doesn't exist - Invalid query: SELECT *
FROM `tbl_items`
ORDER BY `tbl_items`.`datecreated` ASC
 LIMIT 6
ERROR - 2016-11-25 20:10:02 --> Query error: Unknown column 'tbl_items.datecreated' in 'order clause' - Invalid query: UPDATE `ci_sessions` SET `timestamp` = 1480101002
WHERE `id` = '07fe67b551b5ee25978d624efbbcae4f6d5fe248'
ORDER BY `tbl_items`.`datecreated` ASC LIMIT 6
ERROR - 2016-11-25 20:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:11:03 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:11:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:11:49 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:11:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:12:15 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:12:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:13:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:13:39 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:13:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:15:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:15:24 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:15:24 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:15:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:15:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:15:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:15:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:16:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:16:46 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:16:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:18:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:18:33 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:18:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:18:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:18:50 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:18:50 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:19:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:19:17 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:19:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:19:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:19:56 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:19:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:37 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:31:51 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:31:51 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:25 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:36 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:32:47 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:32:47 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:34:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:34:07 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:34:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:34:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:34:48 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:34:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:36:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:36:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 20:36:52 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 20:36:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 23:05:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 23:05:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 23:05:13 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 23:05:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 23:05:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 23:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 15
ERROR - 2016-11-25 23:05:18 --> Severity: Notice --> Undefined variable: items C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
ERROR - 2016-11-25 23:05:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\snappycoin\application\views\web\pages\home.php 72
