<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-20 12:08:17 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 89
ERROR - 2016-07-20 12:08:17 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\fastfood\application\views\web\pages\home.php 92
ERROR - 2016-07-20 13:32:07 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-20 13:33:42 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-20 13:34:38 --> 404 Page Not Found: web/Home/resources
ERROR - 2016-07-20 13:44:54 --> Query error: Not unique table/alias: 'tbl_items' - Invalid query: SELECT distinct(tbl_items.categoryid), `tbl_item_category`.`categoryname`
FROM (`tbl_items`, `tbl_items`)
LEFT JOIN `tbl_item_category` ON `tbl_item_category`.`categoryid`=`tbl_items`.`categoryid`
WHERE `tbl_item`.`vendorid` = '14668583422639we'
ORDER BY `tbl_item_category`.`categoryname` ASC
ERROR - 2016-07-20 13:45:19 --> Query error: Unknown column 'tbl_item.vendorid' in 'where clause' - Invalid query: SELECT distinct(tbl_items.categoryid), `tbl_item_category`.`categoryname`
FROM `tbl_items`
LEFT JOIN `tbl_item_category` ON `tbl_item_category`.`categoryid`=`tbl_items`.`categoryid`
WHERE `tbl_item`.`vendorid` = '14668583422639we'
ORDER BY `tbl_item_category`.`categoryname` ASC
ERROR - 2016-07-20 13:57:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 7
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 14
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 21
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 40
ERROR - 2016-07-20 13:57:47 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 41
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-20 13:59:52 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 44
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 43
ERROR - 2016-07-20 14:00:03 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 44
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:01:42 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:02:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:02:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:03:08 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:03:26 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:03:59 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:04:24 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:04:25 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:05:04 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:07:43 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:07:44 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:08:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:08:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 6
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 10
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 17
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 20
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 24
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 45
ERROR - 2016-07-20 14:09:34 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\web\pages\item.php 46
ERROR - 2016-07-20 14:13:58 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\item.php 100
ERROR - 2016-07-20 14:17:49 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\controllers\web\item.php 100
ERROR - 2016-07-20 14:18:10 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-20 14:18:11 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-20 14:18:20 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:24:44 --> 404 Page Not Found: web/Resources/general
ERROR - 2016-07-20 14:26:12 --> 404 Page Not Found: web/Items/cart
ERROR - 2016-07-20 14:26:32 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:26:57 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:29:58 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:31:43 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:32:04 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:32:42 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:33:32 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:35:39 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:38:19 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:38:37 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:39:50 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:40:02 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:40:30 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:41:04 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:41:15 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:43:15 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:43:31 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:43:55 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:44:13 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:45:51 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:47:11 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:47:38 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:48:03 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 14:48:40 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 15:19:56 --> 404 Page Not Found: web/Item/resources
ERROR - 2016-07-20 15:20:45 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-20 15:20:46 --> 404 Page Not Found: management/Js/classie.js
ERROR - 2016-07-20 15:56:33 --> 404 Page Not Found: management/Orders/view_order
ERROR - 2016-07-20 16:06:53 --> 404 Page Not Found: management/Orders/pending
ERROR - 2016-07-20 16:07:55 --> 404 Page Not Found: management/Orders/pending
ERROR - 2016-07-20 16:54:21 --> Query error: Table 'fastfood.tbl_vendor' doesn't exist - Invalid query: SELECT *
FROM `tbl_vendor`
ERROR - 2016-07-20 16:54:38 --> Severity: Error --> Call to undefined method CI_DB_mysqli_result::where() C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 49
ERROR - 2016-07-20 16:55:21 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 49
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined property: CI_DB_mysqli_result::$count C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 55
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 58
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 58
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 61
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 61
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 65
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 65
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:07 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 58
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 58
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 61
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 61
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 65
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 65
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 17:00:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\delivery\assign_delivery.php 66
ERROR - 2016-07-20 18:16:47 --> Severity: Error --> Call to undefined method Delivery_Model::save() C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 126
ERROR - 2016-07-20 18:17:16 --> Severity: Error --> Call to undefined method Delivery_Model::save() C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 126
ERROR - 2016-07-20 18:20:12 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 133
ERROR - 2016-07-20 18:20:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 138
ERROR - 2016-07-20 18:20:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 138
ERROR - 2016-07-20 18:26:30 --> Severity: Error --> Call to undefined method stdClass::result() C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 132
ERROR - 2016-07-20 18:26:41 --> Severity: Error --> Call to a member function result() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 132
ERROR - 2016-07-20 18:27:44 --> Severity: Notice --> Undefined property: Delivery::$delivery_mode C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 140
ERROR - 2016-07-20 18:27:44 --> Severity: Error --> Call to a member function generate_unique_id() on a non-object C:\xampp\htdocs\fastfood\application\controllers\management\delivery.php 140
ERROR - 2016-07-20 18:28:02 --> Query error: Column 'transactionid' cannot be null - Invalid query: INSERT INTO `tbl_delivery` (`vendorid`, `status`, `deliveryid`, `packageid`, `address`, `location`, `datecreated`, `datemodified`, `franchiseid`, `transactionid`, `deliveryguyid`) VALUES (NULL, '0', '14690320820100lb', NULL, NULL, NULL, '2016-07-20 18:28:02', '2016-07-20 18:28:02', '2626273373', NULL, NULL)
ERROR - 2016-07-20 18:31:28 --> Query error: Column 'transactionid' cannot be null - Invalid query: INSERT INTO `tbl_delivery` (`vendorid`, `status`, `deliveryid`, `packageid`, `address`, `location`, `datecreated`, `datemodified`, `franchiseid`, `transactionid`, `deliveryguyid`) VALUES (NULL, '0', '14690322888909ny', NULL, NULL, NULL, '2016-07-20 18:31:27', '2016-07-20 18:31:27', '2626273373', NULL, NULL)
ERROR - 2016-07-20 19:13:54 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_delivery_guys`
WHERE `vendorid` = '14668222030861qv'
AND `status` = '0'
ERROR - 2016-07-20 19:14:21 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_delivery_guys`
WHERE `vendorid` = '14668222030861qv'
AND `status` = '0'
ERROR - 2016-07-20 19:14:37 --> Query error: Unknown column 'vendorid' in 'where clause' - Invalid query: SELECT *
FROM `tbl_delivery_guys`
WHERE `vendorid` IS NULL
AND `status` = '0'
ERROR - 2016-07-20 19:25:54 --> Severity: Error --> Call to undefined method Order_Model::getmeals() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 107
ERROR - 2016-07-20 19:30:37 --> Severity: Error --> Call to undefined method Order_Model::getdeliveryguy() C:\xampp\htdocs\fastfood\application\views\management\reports\delivery.php 98
ERROR - 2016-07-20 19:41:52 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 263
ERROR - 2016-07-20 19:41:52 --> Severity: Error --> Call to undefined method stdClass::get_by() C:\xampp\htdocs\fastfood\application\controllers\management\reports.php 268
ERROR - 2016-07-20 20:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 20:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 20:03:53 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 20:04:32 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 20:04:33 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\models\management\order_model.php 76
ERROR - 2016-07-20 21:10:48 --> Severity: Notice --> Undefined variable: activeurl C:\xampp\htdocs\fastfood\application\views\management\_templates\_header.php 30
ERROR - 2016-07-20 23:03:20 --> 404 Page Not Found: management/Settlements/vendor
ERROR - 2016-07-20 23:03:35 --> 404 Page Not Found: management/Settlements/vendor
ERROR - 2016-07-20 23:03:59 --> Severity: Error --> Class 'Settlement_model' not found C:\xampp\htdocs\fastfood\system\core\Loader.php 305
ERROR - 2016-07-20 23:04:12 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 57
ERROR - 2016-07-20 23:04:12 --> Severity: Error --> Call to undefined method Settlements::vendornav() C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 61
ERROR - 2016-07-20 23:05:36 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 57
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 45
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 55
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 55
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 73
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 73
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 78
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 78
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 83
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 83
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 93
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 93
ERROR - 2016-07-20 23:05:36 --> Severity: Notice --> Undefined variable: franchiseid C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 99
ERROR - 2016-07-20 23:19:07 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 57
ERROR - 2016-07-20 23:19:08 --> Severity: Notice --> Undefined variable: user C:\xampp\htdocs\fastfood\application\views\management\settlement\pay_vendor.php 45
ERROR - 2016-07-20 23:19:48 --> Severity: Warning --> Creating default object from empty value C:\xampp\htdocs\fastfood\application\controllers\management\settlements.php 57
ERROR - 2016-07-20 23:36:59 --> Query error: Unknown column 'referencenumber' in 'field list' - Invalid query: INSERT INTO `tbl_vendor_payment` (`accountnumber`, `referencenumber`, `amount`, `memo`, `date`, `paymentid`, `datecreated`, `datemodified`, `vendorid`, `franchiseid`) VALUES ('1234555', '13345666', '5000', 'Payment for', '2016-07-20', '14690506194031xv', '2016-07-20 23:36:59', '2016-07-20 23:36:59', '14668222030861qv', '2626273373')
ERROR - 2016-07-20 23:56:53 --> Severity: Notice --> Undefined property: stdClass::$account C:\xampp\htdocs\fastfood\application\views\management\settlement\vendor_payments.php 95
