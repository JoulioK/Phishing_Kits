<?php
defined('BASEPATH') OR exit('No direct script access allowed');
    $autoload['packages'] = array();
    $autoload['libraries'] = array('form_validation','session');
    $autoload['drivers'] = array();
    $autoload['helper'] = array('utilities','url','html','form','text');
    $autoload['config'] = array('_params');
    $autoload['language'] = array();
    $autoload['model'] = array();
