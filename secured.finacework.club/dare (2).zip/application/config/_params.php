<?php

$config['sitename'] = "Info";
$config['siteslug'] = "Administrator";
$config['version'] = "v0.0.1";
$config['headfranchise'] = "2626273373";
$config['currency'] = "&#8358";

$config['site_email'] = "Sharenwillson0@gmail.com";
