<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$route['default_controller'] = 'web/home/index';

$route['vendor'] = 'vendor/authenticate';
$route['agent'] = 'vendor/authenticate';
$route['management'] = 'management/authenticate';

$route['web'] = "web/home/index";
$route['web/(:any)'] = "web/$1";

$route['ref'] = "web/ref/index";
$route['ref/(:any)'] = "web/ref/index/$1";

$route['web'] = "web/home/index";
$route['web/(:any)'] = "web/$1";

$route['app'] = "app/index";
$route['app/(:any)'] = "app/$1";

$route['(:any)'] = "web/vendor/index";
$route['(:any)/index/(:any)'] = "web/vendor/index/$2";
$route['(:any)/fetch'] = "web/vendor/fetch";

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
