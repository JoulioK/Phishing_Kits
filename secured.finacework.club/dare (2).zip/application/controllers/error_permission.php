<?php

class Error_permission extends Web_Controller {

    function __construct() {
        parent::__construct();

    }


 public function index()
 {   
	
 }
	

}
