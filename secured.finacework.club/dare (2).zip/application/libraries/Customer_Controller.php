<?php

class Customer_Controller extends Web_Controller{
    public function __construct() {
        parent::__construct();
		if(!$this->session->userdata('user_loggedin'))
		{
			$this->session->set_flashdata('Please login first');
			redirect('web/auth/l');
		}
        $this->supportcount();
    }

  public function supportcount(){
         $this->db->select('count(tblticketreplies.ticketid) as count');
         $this->db->from("tbltickets");
         $this->db->join('tblticketreplies','tbltickets.id=tblticketreplies.ticketid','BOTH');
         $this->db->where('tblticketreplies.read',0);
         $this->db->where('tbltickets.clientid',$this->session->userdata("user_session")->userid);
         $unread = $this->db->get()->row();
         $unread = $unread->count;
         $this->data['unread'] = $unread;
    }

//SINCE MORE THAN ONE METHOD IS MAKING USE OF THE SAME SCRIPTS IT IS GOOD PRACTICE FROM KEEP IT IN ONE PLACE
    public function getDataTableScripts(){
        #scripts for the dataTable
        $this->data['page_level_scripts'] = '<script src="'.base_url('resources/assets/js/DataTables/js/jquery.dataTables.js').'" ></script>';
        $this->data['page_level_scripts'] .= '<script src="'.base_url('resources/assets/js/DataTables/js/DT_bootstrap.js').'" ></script>';
        $this->data['page_level_scripts'] .= '<script src="'.base_url('resources/assets/js/DataTables/js/datatables.init.js').'" ></script>';
    }



}

