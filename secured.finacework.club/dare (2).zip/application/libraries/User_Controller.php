<?php

class User_Controller extends MY_Controller{

    function __construct() {
		
        parent::__construct();
		
        $file_url = base_url();
        $this->data["site_javascript"] = "<script src='" . $file_url . "resources/assets/js/jquery-1.11.1.min.js'> </script>";
        $this->data["site_javascript"] .= "<script src='" . $file_url . "resources/web/js/jquery.chocolat.js'> </script>";
        $this->data["site_javascript"] .= "<script src='" . $file_url . "resources/web/js/bootstrap.js'> </script>";
        $this->data["site_javascript"] .= "<script src='" . $file_url . "resources/web/js/easing.js'> </script>";
        $this->data["site_javascript"].= "<script src='" . $file_url . "resources/web/js/move-top.js'> </script>";
  
		$this->data["site_style"] = "<link href='" . $file_url . "resources/assets/css/bootstrap.css' rel='stylesheet' type='text/css'> </link>";
        $this->data["site_style"] .= "<link href='" . $file_url . "resources/web/css/style.css' rel='stylesheet' type='text/css'> </link>";
        $this->data["site_style"] .= "<link href='" . $file_url . "resources/web/css/chocolat.css' rel='stylesheet' type='text/css'> </link>";

    }

}
