<?php

class Management_Controller extends MY_Controller {

    function __construct() {
        parent::__construct();
		
        $this->data['error_message'] = '';
        #LOAD NEEDED MODELS
        #LOAD NECESSARY MODELS HERESO THEY ARE ACCESSIBLE FROM CHILDREN CONTROLLERS
		
        $this->load->model('management/user_model');
    
        #CONFIRM IF USER IS LOGGEDIN ELSE REDIRECT TO LOGIN
        if(!in_array(uri_string(), array('management/authenticate')))
        {
            if (!$this->user_model->loggedin()) {
                redirect('management/authenticate');
            }

			$this->franchiseid = $this->session->userdata('franchiseid');
        }
		
        $this->getDataTableScripts();

        #GET USER PRIVILEGES
        $user_privilege = $this->session->userdata('privileges');
	
        if(isset($user_privilege)) {
            $user_privilege = explode(',',$user_privilege);
            $this->data['user_privilege'] = $user_privilege;
		 
        }
		else
		{
			  $this->data['user_privilege'] = array();
			  $user_privilege = array();
		}
		
    }

}
