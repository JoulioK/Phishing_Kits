<?php

class Web_Controller extends MY_Controller {

    function __construct() {
        parent::__construct();

    }
	
}
