<?php

function add_meta_title($string) {
    $CI =&get_instance();
    $CI->data['meta_title'] = e($string). ' - '. $CI->data['meta_title'];

}

function getResource($resourceName){
    return base_url('resources/'.$resourceName);
}

function maturity($hour)
 {
  return date('Y-m-d G:i:s', strtotime("+".$hour." hours"));
 }

function maturitybehind($hour)
 {
   return date('Y-m-d G:i:s', strtotime("-".$hour." hours"));
 }
 
function datedifference($your_date)
{
    $now = time(); // or your date as well
	$datediff = strtotime($your_date) - $now;
	return floor($datediff / (60 * 60 * 24));
}


function getAlertMessage($message,$type = 'danger') {
   return '<div class = "alert alert-'.$type.'" style = "margin-left:10px; margin-right:10px;"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'. $message ."</div>";
   //return '<div class = "alert alert-'.$type.'"> <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> '. $message ."</div>";
}

function convert_from_another_time($time, $source_timezone, $dest_timezone){
    $date = date("Y-m-d");
    $source = new DateTime($date.' '.$time);    
    $offset = $dest_timezone - $source_timezone;
    if($offset == 0)
    { 
      return $source->format('Y-m-d G:i:s'); 
    }
    else
    {
     $target = new DateTime($source->format('Y-m-d G:i:s'));
     $target->modify($offset.' hours');
     return $target->format('Y-m-d G:i:s');
    }
}

function get_settings($key) {
    $ci = & get_instance();
    $config = $ci->db->where('key', $key)->get('tbl_settings')->row();
    if (count($config)) {
        if (!empty($config->value))
            return $config->value;
        return true;
    }
    return false;
}


function encrypt($string) {
    return hash('sha512', $string . config_item('encryption_key'));
}

function get_message($msg, $type = 'danger') {
    $message = '<div class="alert alert-' . $type . '">' . $msg . '</div>';
    return $message;
}

function getBtn($url, $type = "del") {
    if ($type == "del")
        return '<a href="' . $url . '" title="Delete this record" onclick="return confirm(\'Are you sure you wish to delete this record? Action cannot be undone!\')" class="btn-action btn-sm glyphicons remove_2 btn-danger"><i></i>Del</a>';
    elseif ($type == "view") {
        return '<a href="' . $url . '" title="View full details" class="btn btn-xs btn-success glyphicons search"><i></i></a>';
    }
    elseif($type == "edit") {
        return '<a href="' . $url . '" title="Edit this record" class="btn btn-primary btn-xs"> Edit </a>';
    }
}

function getExcerpt($article,$numwords = 50) {
    $string = '';
    $url = 'articles/'.intval($article->article_id).'/'.$article->slug;
    $string .= '<h2>'.anchor($url,e($article->title)).'</h2>';
    $string .= '<p> <span class = "glyphicon glyphicon-time"></span> Posted on : '.e($article->publication_date).'</p>';
    $string .= '<p>'.e(limit_to_words(strip_tags($article->body),$numwords)).'</p>';
    $string .= anchor($url,'Read More');
    return $string;
}


function limit_to_words($string,$numwords) {
    $excerpt = explode(' ',$string,$numwords);
    if (count($excerpt) >= $numwords) {
        array_pop($excerpt);
    }
    $excerpt = implode(' ', $excerpt);
    return $excerpt;
}

function e($string){
    return htmlentities($string);
}

function article_link($article) {
    $url = 'articles/'.intval($article->article_id).'/'.$article->slug;
    $url = '<h2>'.anchor($url,e($article->title)).'</h2>';
    return $url;
}

function article_links($articles) {
    $string = '<ul>';
    foreach ($articles as $article):
        $url = article_link($article);
        $string .= '<li>'.$url.'</li>';
    endforeach;
    $string .= '</ul>';

    return $string;
}


function hashstring($stringtohash) {
    return hash('sha1',$stringtohash);
}


function management_privileges()
{
	return array('Users','Messages','Report','Configuration');
}


function vendor_privileges()
{
	return array('Users','Items','Configuration','Report','Settlement');
}


 function dayofmonthtime($date)
 {
	$dat = explode(" ",$date);
	$day = explode("-",$dat[0]);
	$time = explode(':',$dat[1]);
	return dayth($day[2])." of ".month($day[1]).", ".$day[0]." at ".$time[0].':'.$time[1];
 }
 
 
 function dayofmonth($date)
 {
	$dat = explode(" ",$date);
	$day = explode("-",$dat[0]);
	return dayth($day[2])." of ".month($day[1]).", ".$day[0];
 }

function gettimeonly($date)
 {
	$dat = explode(" ",$date);
	$time = $dat[1];
	return $time;
 }
 
  function dayth($dob)
   {
       $day = array('','1st','2nd','3rd','4th','5th','6th','7th','8th','9th','10th','11th','12th','13th','14th','15th','16th','17th','18th','19th','20th','21st','22nd','23rd','24th','25th','26th','27th','28th','29th','30th','31st');
	   $dob = intval($dob);
	   $isday = $day[$dob];
	   return $isday;  
   }
    
function month($dob)
   {
        $month = array("","January","February","March","April","May","June","July","August","September","October","November","December");
		$dob = intval($dob);
		$ismonth = $month[$dob];
        return $ismonth;
                           
    }
	
function getweekday($date) {
    $weekday = date('l', strtotime($date)); // note: first arg to date() is lower-case L
    return $weekday;
}


function timeaway1($timestring)
 {
   $timeaway = abs(time() - strtotime($timestring));
   return $timeaway;
 }

function timeaway($timestring,$gmt)
   {
     $time = date("G:i:s");
     $time = convert_from_another_time($time, "+1",$gmt);

     $timestring = convert_from_another_time($timestring, "+1",$gmt);

     $timeline = abs(strtotime($timestring) - strtotime($time));
     $periods = array ('year'=>31556925.9763,'month'=>2629743.83136,'day'=>86400,'hour'=>3600,'minute'=>60,'second'=>1);
	  foreach($periods as $name=>$seconds)
		{
		   if($timeline>=$seconds)
			{
			  $ret = get_time_string_away($timeline,$seconds,$name);
			  if($ret=="oo"){ return $timestring; } else { return $ret; }  
			  break;
		    }
	    }
	}

function timedifference($datetime1,$datetime2)
  {
     $datetime1 = new DateTime($datetime1);
     $datetime2 = new DateTime($datetime2);
	 $interval = $datetime1->diff($datetime2);
     return $interval->format('%h')." Hours ".$interval->format('%i')." Minutes";
  }
  
////////////////////This function gets the evaluation of time in strings 
function get_time_string_away($timeline,$seconds,$name)
   {
      $num = ceil($timeline/$seconds);
      if($name=="second")
	   {
		 return " Some seconds";                             
	   }
	  if($name=="minute")
	   {
		if($num<=1)
		  { 
			return " Secs"; 
		  }
		else
		  { 
		   return $num." Minutes"; 
		  }                                     
	   }
     elseif($name=="hour")
      {
		if($num == 1)
	    { 
          return $num." Hour"; }
	    else
		{ 
		  return $num. " Hours"; 
		}                                     
	  }
	 elseif($name=="day")
      {
	       if($num == 1)
		    { return $num." Day"; }
           else
            { 
			 return $num." Days"; 
			}
      }
	  elseif($name=="month" || $name=="year")
	  {
		 return "oo";
	  }
	  elseif($name=="month")
      {
	   if($num == 1)
		 { return $num." Month"; }
       else 
         { 
	      return $num. " Months"; }
      }
   }
     

function userpointearning($point)
  {
	  if($point < 20)
	  {
		 return 0;
	  }
  elseif($point >= 20 && $point < 30)
	  {
		 return 5000;
	  }
  elseif($point >= 30 && $point < 70)
	  {
		 return 10000;
	  } 
  elseif($point >= 70 && $point <= 120)
	  {
		 return 15000;
	  } 
  elseif($point >= 120 && $point < 150)
	  {
		 return 20000;
	  } 
   elseif($point >= 150)
	  {
		 return 30000;
	  } 
	  
  }
  
function userpointrank($point)
  {
	 if($point < 20)
	  {
		 return "Beginner";
	  }
  elseif($point >= 20 && $point < 30)
	  {
		 return "Junior";
	  }
  elseif($point >= 30 && $point < 70)
	  {
		 return "Captain";
	  } 
  elseif($point >= 70 && $point <= 120)
	  {
		 return "Leader";
	  } 
  elseif($point >= 120 && $point < 150)
	  {
		 return "Major";
	  } 
   elseif($point >= 150)
	  {
		 return "Overseer";
	  } 
	
  }
  
  function userpointstar($point)
  {
	 if($point < 20)
	  {
		 return 0;
	  }
  elseif($point >= 20 && $point < 30)
	  {
		 return 1;
	  }
  elseif($point >= 30 && $point < 70)
	  {
		 return 2;
	  } 
  elseif($point >= 70 && $point <= 120)
	  {
		 return 3;
	  } 
  elseif($point >= 120 && $point < 150)
	  {
		 return 4;
	  } 
   elseif($point >= 150)
	  {
		 return 5;
	  } 
	
  }
  


