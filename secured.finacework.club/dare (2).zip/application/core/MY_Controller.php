<?php
class MY_Controller extends CI_Controller{
    public $data = array();
    function __construct(){
        parent::__construct();
        #GET APP DATA
        $this->data['errors'] = '';
        $this->data['sitename'] = config_item('sitename');
        $this->data['siteslug'] = config_item('siteslug');

        #GLOBAL VARIABLES FOR PAGE LEVEL STYLES AND SCRIPTS
        $this->data['page_level_styles'] = "";
        $this->data['page_level_scripts'] = "";
		
    }
	
   //SINCE MORE THAN ONE METHOD IS MAKING USE OF THE SAME SCRIPTS IT IS GOOD PRACTICE FROM KEEP IT IN ONE PLACE
    public function getDataTableScripts(){
        #scripts for the dataTable
        $this->data['page_level_scripts'] = '<script src="'.base_url('resources/assets/js/DataTables/js/jquery.dataTables.js').'" ></script>';
        $this->data['page_level_scripts'] .= '<script src="'.base_url('resources/assets/js/DataTables/js/DT_bootstrap.js').'" ></script>';
        $this->data['page_level_scripts'] .= '<script src="'.base_url('resources/assets/js/DataTables/js/datatables.init.js').'" ></script>';
    }

}
