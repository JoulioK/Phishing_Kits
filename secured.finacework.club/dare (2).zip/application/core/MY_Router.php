<?php
Class MY_Router extends CI_Router {

    Function MY_Router() {
        parent::__construct();
        //$this->checksubdomain();		
    }
	
	protected function _set_default_controller()
	{
		if (empty($this->default_controller))
		{
			show_error('Unable to determine what should be displayed. A default route has not been specified in the routing file.');
		}
		
		  $x = explode('/', $this->default_controller);
		    if(is_dir(APPPATH.'controllers/'.$x[0]))
			 {

				  $this->set_directory($x[0]);
				  $this->set_class(ucfirst($x[1]));
			      $this->set_method($x[2]);
				  $class = $x[1];
				  $method = $x[2];
			 }
		     else
			 {
				  $this->set_class(ucfirst($x[0]));
			      $this->set_method($x[1]);
				  $class = $x[0];
				  $method = $x[1];
			 }
					
		// Assign routed segments, index starting from 1
		$this->uri->rsegments = array(
			1 => $class,
			2 => $method
		);
		log_message('debug', 'No URI present. Default controller set.');
	}
	
 private function checksubdomain()
  {
	 $url = $this->config->config['base_url']; 
	 $parsedUrl = parse_url($url);
	 $host = explode('.', $parsedUrl['host']);
	 if($host[0]!="snappymeals")
	  {
		    $this->set_directory('web');
			$this->uri->rsegments[1]=='home'?$this->set_class('vendor'):$this->set_class($this->uri->rsegments[1]); 
			$this->set_method($this->uri->rsegments[2]); 
	  }   
   }

}
