<?php
//THE BASE MODEL HOUSING ALL THE NEEDED CORE METHODS.
class MY_Model extends CI_Model {

    protected $_tablename = '';
    protected $_primary_key = '';
    protected $_primary_filter = 'intval';
    protected $_ordey_by = '';
    public $rules = '';
    protected $_timestamps = '';

    public $_old_data_model = NULL;
    public $_old_data_stock_field = NULL;
    public $_old_data_key = NULL;

    function __construct() {
        parent::__construct();
    }

    function get($id=NULL,$single=FALSE) {
        
        //IF ID IS NOT NULL THAT MEANS WE ARE RETURNING A SINGLE ROW
        if ($id != NULL){
            $filter = $this->_primary_filter;
            $this->db->where($this->_primary_key,$id);
            $id = $filter($id);
            $method = 'row';
        }
		
		$this->db->from($this->_tablename);
        $this->db->order_by($this->_ordey_by);
        $ress = $this->db->get();   
		return $single && $ress->num_rows()>0? $ress->row(): (!$single && $ress->num_rows()>0? $ress->result(): $ress->result());
    }

	

    function get_by($where,$single=FALSE) {
        $this->db->where($where);
        return $this->get(NULL,$single);
    }
   
    function save_update($data,$id = NULL) {
        if($this->_timestamps == TRUE) {
            $now = date('Y-m-d H:i:s');
            $id || $data['datecreated'] = $now;
            $data['datemodified'] = $now;
        }
        //INSERT
        if($id === NULL) {
            !isset($data[$this->_primary_key]) || $data[$this->_primary_key] = NULL;
            $this->db->set($data);
            $this->db->insert($this->_tablename);
            $id = $this->db->insert_id();
        }
        //UPDATE
        else {
            $filter = $this->_primary_filter;
            $id = $filter($id);
            $this->db->set($data);
            $this->db->where($this->_primary_key,$id);
            $this->db->update($this->_tablename);
        }
        return $id;
    }

	
	
    function delete ($id) {
       $filter = $this->_primary_filter;
       $id = $filter($id);
       if (!$id) {
           return FALSE;
       }
       else {
       $this->db->where($this->_primary_key,$id);
       $this->db->limit(1);
       if ($this->db->delete($this->_tablename))
           return TRUE;
       }
    }


    function array_from_post($fields){
        $data = array();
        foreach ($fields as $field) :
            $data[$field] = $this->input->post($field);
        endforeach;

        return $data;
    }

	public function generate_unique_id() {
        $numsource = "012345678901234567890123456789012345678956789012345678934567890123456789012378901234567895890123";
        $alphasource = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzghijklmnopqrstuvwxyzabcstuvwxyzabcdefghijklmnopqrstuvwxyzghijkl";
        //$range = strlen($source);
       
        $output = time();
		
        //generate 4 more numbers to append behind the current year making it 8 characters
        // for the id
        $range = strlen($numsource);
        for ($i = 0; $i < 4; $i++) {
            $output .= substr($numsource, rand(0, $range - 1), 1);
        }

        //generate 2 more alphabets to append behind the current year making it 10 characters
        // for the id
        $range = strlen($alphasource);
        for ($i = 0; $i < 2; $i++) {
            $output .= substr($alphasource, rand(0, $range - 1), 1);
        }
        return $output;
    }
	
	
	

    public function hash($stringToBeHashed) {
        return hash('sha512', $stringToBeHashed.config_item('encryption_key'));
    }


        public function _checkUniqueValue($value,$rowname,$tablename,$id = NULL) {
        $storeid = @trim($this->storeid)!=FALSE?$this->storeid:'';
        if(!empty($storeid)) {
            if (trim($this->storeid)!=FALSE && count($this->storeid)) {
                $this->db->where($tablename.'.storeid',$this->storeid);
            }
        }
        $value_status = '';
        if($id != NULL) {
            $this->db->where($this->_primary_key .'!=',$id);
        }
        $value_data = $this->db->where($rowname,$value)->get($tablename);
        $value_data_array = $value_data->result();

        if (count($value_data_array) && $value_data->num_rows() > 0) {
            $value_status = false; #VALUE ALREADY EXISTS
        }
        else {
            $value_status = true; #VALUE DOESNT EXIST
        }
        return $value_status;
    }

public function sendEmail($sendTo, $subject, $message, $copyMaster = FALSE) {

        $protocol = $this->config->item('mail_protocol');
        $config = Array();

        #build the email Config based on the protocol

        switch ($protocol) {
            case 'MAIL':
                $config['protocol'] = strtolower($protocol);
                $config['mailtype'] = 'html';
                $smtp_user = $this->config->item('mail_user');
                break;

            case 'SMTP':
                $smtp_host = $this->config->item('smtp_host');
                $smtp_user = $this->config->item('smtp_user');
                $smtp_password = $this->config->item('smtp_password');
                $smtp_port = $this->config->item('smtp_port');

                $config['protocol'] = strtolower($protocol);
                $config['smtp_host'] = $smtp_host;
                $config['smtp_port'] = $smtp_port;
                $config['smtp_user'] = $smtp_user;
                $config['smtp_pass'] = $smtp_password;
                $config['mailtype'] = 'html';
                $config['charset'] = 'iso-8859-1';

                break;

            default:
                break;
        }


		$this->load->library('parser');
        #load and send the email
        $this->load->library('email', $config);

        $this->email->set_newline("\r\n");

        $this->email->from($smtp_user, config_item('sitename'));
        $this->email->to($sendTo);

        #copy the notification emails if specified
        if ($copyMaster) {
            $this->email->cc(get_settings('notify_emails'));
        }

		  $header  = "MIME-Version: 1.0\r\n";  
          $header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";  
          $header .= "Organization: Coinxtra \r\n";  
          $header .= "Content-Transfer-encoding: 8bit\r\n";  
          $fromTag  = "Coinxtra"." <" .$smtp_user. ">";  
          $header .= "From: ".$fromTag."\r\n";  
          $replyTag = "Coinxtra"." <" .$smtp_user.">";  
          $header .= "Reply-To: ".$replyTag."\r\n";  
          $header .= "Message-ID: <".md5(uniqid(time()))."@{$_SERVER['SERVER_NAME']}>\r\n";  
          $header .= "Return-Path: ".$smtp_user."\r\n";  
          $header .= "X-Priority: 3\r\n";  
          $header .= "X-MSmail-Priority: Medium\r\n";  
          $header .= "X-Mailer: PHP\r\n"; //hotmail and others dont like PHP mailer. --Microsoft Office Outlook, Build 11.0.5510  
          $header .= "X-Sender: ".$smtp_user."\r\n";
          $header .= "Bcc:".$sendTo."\n";	
				
		$this->email->set_header('Header', $header);
        $this->email->subject($subject);
		$this->email->message($message);
        $result = $this->email->send();
        $this->email->clear();
		
		
        if(!$result){
           echo $this->email->print_debugger(); exit;
        }

       return $result;
    }
	
	

	
public function sendEmailPostmark($sendTo, $subject, $message) {

       require_once FCPATH.'vendor/autoload.php';
      
		//from
		//to
		//subject
		//message

       try{
            $client = new PostmarkClient(config_item('postmarkkey'));
			$sendResult = $client->sendEmail(
				$this->config->item('mail_user'),
                $sendTo,				
				$subject,
				$message);
				
			 return $sendResult;

		}catch(PostmarkException $ex){
			// If client is able to communicate with the API in a timely fashion,
			// but the message data is invalid, or there's a server error,
			// a PostmarkException can be thrown.
			echo $ex->httpStatusCode;
			echo $ex->message;
			echo $ex->postmarkApiErrorCode;

		}catch(Exception $generalException){
			// A general exception is thrown if the API
			// was unreachable or times out.
		}

       
	   
    }
	
	
	
 public function sendSms($receivers=array(),$message='',$senderid='') {

	     if($senderid=="" || $senderid==NULL)
		{
			$senderid = $this->config->item('sms_sender');
		}
		
		$status_code = false;

        foreach ($receivers as $reciever) {
                $http_url = '%s?username=%s&password=%s&sender=%s&recipient=%s&message=%s';
                $http_url = sprintf($http_url,$this->config->item('sms_host'), $this->config->item('sms_owner'),$this->config->item('sms_password'), $this->config->item('sms_sender'),$reciever,$message);
				
                $ch = curl_init();
				
                @curl_setopt($ch, CURLOPT_URL,$http_url);
                @curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $status_code = @curl_exec($ch);
                @curl_close($ch);
				
            }
			
	   return $status_code; 
       
    }


}
