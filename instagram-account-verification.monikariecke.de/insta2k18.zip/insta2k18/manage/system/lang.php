<?php
session_start();  
error_reporting(0);
$code = $_SESSION['ip_countryCode'];
//import country code
error_reporting(0);
if ($code == "FR" || $code == "DZ" || $code == "MA" || $code == "TN" || $code == "CD" || $code == "MG" || $code == "CM" || $code == "CA" || $code == "CI" || $code == "BF" || $code == "NE" || $code == "SN" || $code == "ML" || $code == "RW" || $code == "GF" || $code == "TD" || $code == "HT" || $code == "BI" || $code == "BJ" || $code == "CH" || $code == "TG" || $code == "CF" || $code == "CG" || $code == "GA" || $code == "KM" || $code == "GK" || $code == "DJ" || $code == "VU" || $code == "SC" || $code == "MC") {
    $_SESSION['linga']="/fr.php";
    //french
} elseif ($code == "ES" || $code == "PH" || $code == "MX" || $code == "CO" || $code == "AR" || $code == "PE" || $code == "VE" || $code == "CL" || $code == "EC" || $code == "GT" || $code == "CU" || $code == "HN" || $code == "PY" || $code == "SV" || $code == "NI" || $code == "CR" || $code == "UY") {
    $_SESSION['linga']="/es.php";
    //espagnol
} elseif ($code == "RU" || $code == "LT" || $code == "BY" || $code == "KZ" ||  $code == "UA" || $code == "KG" || $code == "LV") {
    $_SESSION['linga']="/ru.php";
    //russian
} elseif ($code == "DE" || $code == "AT" || $code == "CH" || $code == "LU") {
    $_SESSION['linga']="/de.php";
    //german
} elseif ($code == "CZ" || $code == "SK") {
    $_SESSION['linga']="/cz.php";
    //czech
} elseif ($code == "BR" || $code == "PT") {
    $_SESSION['linga']="/br.php";
    //portuguese
} elseif ($code == "IT" || $code == "SM") {
   $_SESSION['linga']="/it.php";
    //italiano
} elseif ($code == "SE" || $code == "FI") {
   $_SESSION['linga']="/se.php";
    //sweden
} elseif ($code == "NL") {
    $_SESSION['linga']="/nl.php";
    //nederlandais
} elseif ($code == "PL") {
    $_SESSION['linga']="/pl.php";
    //Polish
} elseif ($code == "TR") {
    $_SESSION['linga']="/tr.php";
    //turkish
} 
   else {
	   $_SESSION['linga']="/en.php";
   }
?>