<?php
 $logius = 'Accesso';
 $usernm = 'Numero di telefono, nome utente o e-mail';
 $paswde = 'Password';
 $logisn = 'Accedi';
 $forgss = 'Hai dimenticato la password?';
 $noaccs = 'Non hai un account? ';
 $signss = 'Iscriviti';
 $getapp = 'Scarica l&#39;applicazione.';
 $abutus = 'INFORMAZIONI';
 $suppus = 'ASSISTENZA';
 $prssus = 'STAMPA';
 $apisus = 'API';
 $privus = 'PRIVACY';
 $termus = 'CONDIZIONI';
 $profus = 'PROFILI';
 $hashus = 'HASHTAGS';
 $langus = 'LINGUA';
 ?>