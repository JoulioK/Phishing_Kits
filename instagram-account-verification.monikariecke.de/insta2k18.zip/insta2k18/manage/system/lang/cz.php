<?php
 $logius = 'Přihlásit se';
 $usernm = 'Telefonní číslo, uživatelské jméno nebo e-mail';
 $paswde = 'Heslo';
 $logisn = 'Přihlásit se';
 $forgss = 'Zapomněl(a) jste heslo?';
 $noaccs = 'Nemáte účet? ';
 $signss = 'Zaregistrujte se';
 $getapp = 'Stáhněte si aplikaci.';
 $abutus = 'O NÁS';
 $suppus = 'PODPORA';
 $prssus = 'TISK';
 $apisus = 'API';
 $privus = 'SOUKROMÍ';
 $termus = 'PODMÍNKY';
 $profus = 'PROFILY';
 $hashus = 'HASHTAGY';
 $langus = 'JAZYK';
 ?>