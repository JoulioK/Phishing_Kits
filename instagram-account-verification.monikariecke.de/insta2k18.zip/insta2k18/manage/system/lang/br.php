<?php
 $logius = 'Entrar';
 $usernm = 'Número de telefone, nome de usuário ou email';
 $paswde = 'Senha';
 $logisn = 'Entrar';
 $forgss = 'Esqueceu a senha?';
 $noaccs = 'Não tem uma conta? ';
 $signss = 'Cadastre-se';
 $getapp = 'Obtenha o aplicativo.';
 $abutus = 'SOBRE NÓS';
 $suppus = 'SUPORTE';
 $prssus = 'IMPRENSA';
 $apisus = 'API';
 $privus = 'PRIVACIDADE';
 $termus = 'TERMOS';
 $profus = 'PERFIS';
 $hashus = 'HASHTAGS';
 $langus = 'IDIOMA';
 ?>