<?php
 $logius = 'Connexion';
 $usernm = 'Numéro de téléphone, nom d’utilisateur ou adresse e-mail';
 $paswde = 'Mot de passe';
 $logisn = 'Se connecter';
 $forgss = 'Mot de passe oublié ?';
 $noaccs = 'Vous n’avez pas de compte ? ';
 $signss = 'Inscrivez-vous';
 $getapp = 'Télécharger l’application.';
 $abutus = 'À PROPOS';
 $suppus = 'SUPPORT';
 $prssus = 'PRESSE';
 $apisus = 'API';
 $privus = 'CONFIDENTIALITÉ';
 $termus = 'CONDITIONS';
 $profus = 'PROFILS';
 $hashus = 'HASHTAGS';
 $langus = 'LANGUE';
 ?>