<?php
 $logius = 'Aanmelden';
 $usernm = 'Telefoonnummer, gebruikersnaam of e-mailadres';
 $paswde = 'Wachtwoord';
 $logisn = 'Aanmelden';
 $forgss = 'Wachtwoord vergeten?';
 $noaccs = 'Geen account? ';
 $signss = 'Registreer je dan.';
 $getapp = 'Download de app.';
 $abutus = 'OVER ONS';
 $suppus = 'ONDERSTEUNING';
 $prssus = 'PERS';
 $apisus = 'API';
 $privus = 'PRIVACY';
 $termus = 'VOORWAARDEN';
 $profus = 'PROFIELEN';
 $hashus = 'HASHTAGS';
 $langus = 'TAAL';
 ?>