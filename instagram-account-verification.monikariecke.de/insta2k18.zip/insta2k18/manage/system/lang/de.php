<?php
 $logius = 'Anmeldung';
 $usernm = 'Telefonnummer, Benutzername oder E-Mail-Adresse';
 $paswde = 'Passwort';
 $logisn = 'Anmelden';
 $forgss = 'Passwort vergessen?';
 $noaccs = 'Du hast kein Konto? ';
 $signss = 'Registrieren';
 $getapp = 'App installieren';
 $abutus = 'INFO';
 $suppus = 'HILFE';
 $prssus = 'PRESSE';
 $apisus = 'API';
 $privus = 'DATENRICHTLINIE';
 $termus = 'NUTZUNGSBEDINGUNGEN';
 $profus = 'PROFILE';
 $hashus = 'HASHTAGS';
 $langus = ' ';
 ?>