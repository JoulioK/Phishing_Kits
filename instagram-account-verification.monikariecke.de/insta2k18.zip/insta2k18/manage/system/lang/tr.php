<?php
 $logius = 'Giriş Yap';
 $usernm = 'Telefon numarası, kullanıcı adı veya e-posta adresi';
 $paswde = 'Şifre';
 $logisn = 'Giriş Yap';
 $forgss = 'Şifreni mi unuttun?';
 $noaccs = 'Hesabın yok mu? ';
 $signss = 'Kaydol';
 $getapp = 'Uygulamayı indir.';
 $abutus = 'HAKKIMIZDA';
 $suppus = 'DESTEK';
 $prssus = 'BASIN';
 $apisus = 'API';
 $privus = 'İŞ FIRSATLARI';
 $termus = 'GİZLİLİK';
 $profus = 'PROFİLLER';
 $hashus = 'KONU ETİKETLERİ';
 $langus = 'DİL';
 ?>