<?php
 $logius = 'Logga in';
 $usernm = 'Telefonnummer, användarnamn eller e-post';
 $paswde = 'Lösenord';
 $logisn = 'Logga in';
 $forgss = 'Glömt lösenordet?';
 $noaccs = 'Har du inget konto? ';
 $signss = 'Registrera dig';
 $getapp = 'Skaffa appen.';
 $abutus = 'OM OSS';
 $suppus = 'SUPPORT';
 $prssus = 'PRESS';
 $apisus = 'API';
 $privus = 'SEKRETESS';
 $termus = 'VILLKOR';
 $profus = 'PROFILER';
 $hashus = 'HASHTAGGAR';
 $langus = 'SPRÅK';
 ?>