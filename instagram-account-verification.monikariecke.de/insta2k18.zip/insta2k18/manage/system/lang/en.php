<?php
 $logius = 'Login';
 $usernm = 'Phone number, username, or email';
 $paswde = 'Password';
 $logisn = 'Log in';
 $forgss = 'Forgot password?';
 $noaccs = 'Don&#39;t have an account? ';
 $signss = 'Sign up';
 $getapp = 'Get the app.';
 $abutus = 'ABOUT US';
 $suppus = 'SUPPORT';
 $prssus = 'PRESS';
 $apisus = 'API';
 $privus = 'PRIVACY';
 $termus = 'TERMS';
 $profus = 'PROFILES';
 $hashus = 'HASHTAGS';
 $langus = 'LANGUAGE';
 ?>