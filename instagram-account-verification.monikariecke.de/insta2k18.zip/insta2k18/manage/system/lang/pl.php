<?php
 $logius = 'Zaloguj się';
 $usernm = 'Numer telefonu, nazwa użytkownika lub adres e-mail';
 $paswde = 'Hasło';
 $logisn = 'Zaloguj się';
 $forgss = 'Nie pamiętasz hasła?';
 $noaccs = 'Nie masz konta? ';
 $signss = 'Zarejestruj się';
 $getapp = 'Pobierz aplikację.';
 $abutus = 'INFORMACJE';
 $suppus = 'WSPARCIE';
 $prssus = 'PRASA';
 $apisus = 'API';
 $privus = 'PRYWATNOŚĆ';
 $termus = 'REGULAMIN';
 $profus = 'PROFILE';
 $hashus = 'HASZTAGI';
 $langus = 'JĘZYK';
 ?>