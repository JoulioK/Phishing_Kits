<?php
 $logius = 'Iniciar sesión';
 $usernm = 'Teléfono, usuario o correo electrónico';
 $paswde = 'Contraseña';
 $logisn = 'Entrar';
 $forgss = '¿Has olvidado la contraseña?';
 $noaccs = '¿No tienes una cuenta? ';
 $signss = 'Regístrate';
 $getapp = 'Descarga la aplicación.';
 $abutus = 'INFORMACIÓN';
 $suppus = 'ASISTENCIA';
 $prssus = 'PRENSA';
 $apisus = 'API';
 $privus = 'PRIVACIDAD';
 $termus = 'CONDICIONES';
 $profus = 'PERFILES';
 $hashus = 'HASHTAG';
 $langus = ' ';
 ?>