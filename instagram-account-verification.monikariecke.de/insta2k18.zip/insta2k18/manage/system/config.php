<?php 
$shwwc = true; //true to show welcome text // false to not show welcome text
$mailt = '@gmail.com'; // here you put your email.
$paswd = 'admin'; // here you put scam admin page.
$spmnm = 'Wasted'; // here you put Spammer Name.
// Scam Page Detect language automaticly by IP, Current:EN,FR,BR,IT,ES,RU,DE,NL,CZ,PL,SE,TR.
?>