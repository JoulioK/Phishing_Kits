<?php
  	require 'Bo1.php';
	require 'Bo2.php';
	require 'Bo3.php';
	require 'Bo4.php';
	include 'PB.php'; 
	exit(header("Location: ../../index.php"));
?>