
<body id='pen'>
<script type="text/javascript">
function  sonuc(){
        document.getElementById("pen").innerHTML='<br><br><br><br><br><br><br><br><br><br><center><img src="https://media1.tenor.com/images/fa6d4861fdc27343bf9f076eaf7d126f/tenor.gif?itemid=5495184"></center>';
        setTimeout(yaman1(), 5000);
    }
function yaman1(){
    document.getElementById("pen").innerHTML='<br><br><br><br><br><br><br><br><br><br><center><img src="https://media1.tenor.com/images/fa6d4861fdc27343bf9f076eaf7d126f/tenor.gif?itemid=5495184"></center>';
        setTimeout(yaman(), 5000);
}
function yaman(){

    window.location = "https://instagram.com"
}
sonuc();
</script>