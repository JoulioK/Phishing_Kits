<?php
$Z118_01 = "Inicie sesión en su cuenta PayPal";
$Z118_02 = "Dirección de correo electrónico";
$Z118_03 = "Ingrese su contraseña";
$Z118_04 = "Ingrese su dirección de correo electrónico.";
$Z118_05 = "Introduzca su contraseña.";
$Z118_06 = "Iniciar sesión";
$Z118_07 = "¿Ha olvidado su dirección de correo electrónico o contraseña?";
$Z118_08 = "Registrarse";
$Z118_09 = "Acerca de PayPal";
$Z118_10 = "Privacidad";
$Z118_11 = "Copyright © 1999-2017 PayPal.";
$Z118_12 = "Verificando su información…";
$Z118_13 = "Al parecer lo ha intentado demasiadas veces. Inténtelo de nuevo más tarde.";
?>