<?php
$Z118_01 = "Connectez-vous à votre compte PayPal";
$Z118_02 = "Email";
$Z118_03 = "Mot de passe";
$Z118_04 = "Entrez votre adresse email.";
$Z118_05 = "Entrez votre mot de passe.";
$Z118_06 = "Connexion";
$Z118_07 = "Vous avez oublié votre adresse email ou votre mot de passe ?";
$Z118_08 = "Ouvrir un compte";
$Z118_09 = "Respect de la vie privée";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999-2017 PayPal. Tous droits réservés.";
$Z118_12 = "Vérification de vos informations…";
$Z118_13 = "Certaines de vos informations sont incorrectes. Réessayez.";
?>