<?php



?>

<body>
<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <title>#Users Coming#</title>

    <p><img alt="Logo" src="http://www.officialpsds.com/images/thumbs/Spiderman-Logo-psd59240.png" style="height: 190px; width: 174px;" title="Logo" /></p>
    <p>&nbsp;</p>
    <h2> # Users Coming # </h2>

    <link rel="stylesheet" href="css/normalize.css">

    <link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/css/bootstrap.min.css'>
    <link rel='stylesheet prefetch' href='http://cdn.datatables.net/plug-ins/f2c75b7247b/integration/bootstrap/3/dataTables.bootstrap.css'>
    <link rel='stylesheet prefetch' href='http://cdn.datatables.net/responsive/1.0.4/css/dataTables.responsive.css'>
    <link rel='stylesheet prefetch' href='https://cdn.datatables.net/1.10.10/css/dataTables.bootstrap.min.css'>
    <style>

        body {
            background-color: #E9ECEE;
            text-align: center;
            padding-top: 50px;
        }

        .button {
            text-decoration: none;
            text-transform: uppercase;
            font-family: 'Exo 2', sans-serif;
            font-weight: 300;
            font-size: 30px;
            display: inline-block;
            position: relative;
            text-align: center;
            color: #333738;
            border: 1px solid #333738;
            border-radius: 5px;
            line-height: 1em;
            padding-left: 2em;
            padding-right: 2em;
            box-shadow: 0 0 0 0 transparent;
            -webkit-transition: all 0.2s ease-in;
            -moz-transition: all 0.2s ease-in;
            transition: all 0.2s ease-in;
        }
        .button:hover {
            color: white;
            box-shadow: 0 0 30px 0 rgba(188, 188, 188, 0.5);
            background-color: #00c7ec;
            -webkit-transition: all 0.2s ease-out;
            -moz-transition: all 0.2s ease-out;
            transition: all 0.2s ease-out;
        }
        .button:hover:before {
            -webkit-animation: shine 0.5s 0s linear;
            -moz-animation: shine 0.5s 0s linear;
            animation: shine 0.5s 0s linear;
        }
        .button:active {
            box-shadow: 0 0 0 0 transparent;
            -webkit-transition: box-shadow 0.2s ease-in;
            -moz-transition: box-shadow 0.2s ease-in;
            transition: box-shadow 0.2s ease-in;
        }
        .button:before {
            content: '';
            display: block;
            width: 0px;
            height: 86%;
            position: absolute;
            top: 7%;
            left: 0%;
            opacity: 0;
            background: white;
            box-shadow: 0 0 15px 3px white;
            -webkit-transform: skewX(-20deg);
            -moz-transform: skewX(-20deg);
            -ms-transform: skewX(-20deg);
            -o-transform: skewX(-20deg);
            transform: skewX(-20deg);
        }

        @-webkit-keyframes shine {
            from {
                opacity: 0;
                left: 0%;
            }
            50% {
                opacity: 1;
            }
            to {
                opacity: 0;
                left: 100%;
            }
        }
        @-moz-keyframes shine {
            from {
                opacity: 0;
                left: 0%;
            }
            50% {
                opacity: 1;
            }
            to {
                opacity: 0;
                left: 100%;
            }
        }
        @keyframes shine {
            from {
                opacity: 0;
                left: 0%;
            }
            50% {
                opacity: 1;
            }
            to {
                opacity: 0;
                left: 100%;
            }
        }
    </style>




</head>

<body>

<div class="container">
    <table id="example" summary="This table shows how to create responsive tables using Datatables' extended functionality" class="table table-bordered table-hover dt-responsive" id="table" >
        <thead>
        <tr>
            <th></th>
            <th></th>
        </tr>
        </thead>
        <tfoot>

        <tr>
        <tfoot>
        <tr>
            <th>Time</th>
            <th>Country</th>
            <th>User IP</th>
            <th>Agent</th>
           
            
        </tr>
        </tfoot>
        <tbody>
        <?php
            $fcontents = file ('come.txt');
            while (list ($line_num, $line) = each ($fcontents)) {
                $aun=explode ('()',$line) ;

                ?>
                <tr>
                    
                    <td><?php echo $aun[1] ?></td>
                    
                    <td><?php echo $aun[3] ?></td>
                    
                    <td><?php echo $aun[0] ?></td>

                    <td><?php echo $aun[2] ?></td>
                    
                    
                    
                   
                    
                </tr>

                <?php

            }

        ?>
        </tbody>
    </table>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.10/js/jquery.dataTables.min.js'></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/datatables/1.10.10/js/dataTables.bootstrap.min.js'></script>
<script>

    $(document).ready( function () {
        var table = $('#example').DataTable();
    } );


</script>

<td>
<br>
<br>


    <form>
        <input class="button" type="button" alt="Shells" value="Reload" onClick="history.go(0)">
    </form>
</td>
</body>
</html>
