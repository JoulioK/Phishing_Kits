    <div class="row-fluid" style="background-color:#6e6d71;">
	         <div id="flagdiv" name="flagdiv" class="span3 offset1" style="margin:15px 0 0 0;float:right;text-align:center;">
        <form id="changelang" name="changelang" method="post">
        <a href="javascript:void(0);" title="United Kingdom"><img src="../../img/flags/United-Kingdom.png" onClick="javascrip:setval('EN');" /></a>
        <a href="javascript:void(0);" title="Sweden"><img src="../../img/flags/Sweden.png" onClick="javascrip:setval('SE');" /></a>
        <a href="javascript:void(0);" title="Germany"><img src="../../img/flags/Germany.png" onClick="javascrip:setval('DE');" /></a>
        <a href="javascript:void(0);" title="France"><img src="../../img/flags/France.png" onClick="javascrip:setval('FR');" /></a>
        <a href="javascript:void(0);" title="Spain"><img src="../../img/flags/Spain.png" onClick="javascrip:setval('ES');" /></a>
        <a href="javascript:void(0);" title="Italy"><img src="../../img/flags/Italy.png" onClick="javascrip:setval('IT');" /></a>
        <a href="javascript:void(0);" title="Denmark"><img src="../../img/flags/Denmark.png" onClick="javascrip:setval('DK');" /></a>
        <input type="hidden" name="changelanguage" id="changelanguage"  />
         </form>
        </div>
    <div class="container">
      <footer id="ft2">
        <p style="color:#fff;margin:10px;"><?php echo $COPYRIGHT_2_TXT; ?><span >&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp; <?php $RESPECT_FOR_PRIVACY_TXT; ?> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $USE_CONTRACTS_TXT; ?> &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $UPDATES_REGULATION_TXT; ?></span> </p>
        <p style="color:#fff;margin:10px 0 30px 10px;"><?php echo $BOTTOM_TXT; ?></p>
      </footer>
      </div>
      </div>

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../js/jquery.js"></script>
    <script src="../../js/bootstrap-transition.js"></script>
    <script src="../../js/bootstrap-alert.js"></script>
    <script src="../../js/bootstrap-modal.js"></script>
    <script src="../../js/bootstrap-dropdown.js"></script>
    <script src="../../js/bootstrap-scrollspy.js"></script>
    <script src="../../js/bootstrap-tab.js"></script>
    <script src="../../js/bootstrap-tooltip.js"></script>
    <script src="../../js/bootstrap-popover.js"></script>
    <script src="../../js/bootstrap-button.js"></script>
    <script src="../../js/bootstrap-collapse.js"></script>
    <script src="../../js/bootstrap-carousel.js"></script>
    <script src="../../js/bootstrap-typeahead.js"></script>
    <script src="../../js/script.js"></script> 
