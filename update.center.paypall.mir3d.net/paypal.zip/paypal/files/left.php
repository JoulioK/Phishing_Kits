<div class="span4" >
        <div class="row" >
        
        <div class="span4" style="background-color: rgb(255, 255, 255); padding-top: 15px; min-height: 300px; box-shadow: 0px 1px 4px 0px #d5d5d5; border-radius: 5px; background-clip: padding-box;" id="lt1">
          <h3 style="padding-left:30px;"><?php echo $TOOLS_TXT;?></h3><hr />
                  
        <ul class="toolsTile">
                                    <li class="invoicing"><a href="#"><?php echo $BILLING_TXT;?></a>
                                    </li>
                                    <li class="requestMoney"><a href="#"><?php echo $REQUEST_FOR_PAYMENT_TXT;?></a>
                                    </li>
                                    <li class="sendMoney"><a href="#"><?php echo $SENDING_MONEY_TXT;?></a>
                                    </li>
                                    <li class="businessSetup"><a href="#"><?php echo $CONFIGURATION_OF_MY_ACTIVITY_TXT;?></a>
                                    </li>
                                    <li class="welcome"><a href="#"><?php echo $PRESENTATION_TXT;?></a>
                                    </li>
                                    <li class="resolutionCenter"><a href="#"><?php echo $RESOLUTION_CENTER_TXT;?></a>
                                    </li>
                                </ul>
                                
         </div>
         </div> 
         
         
         <div class="row" style="margin-top:20px;"  >
         <div class="span4" style="background:#fff;padding: 15px 0px 0px; box-shadow: 0px 1px 4px 0px #d5d5d5; border-radius: 5px;" id="lt2">
        
          <h3 style="padding-left:30px;"><?php echo $ENABLED_BY_TXT; ?></h3><hr />
                    
                           
                                <div style="text-align:center;"><img src="../../img/logo2.gif"><img src="../../img/sc.png"><img src="../../img/enabled_by_symc_vip.png"></div>
                                
                           
                            <ul class="horizontalList bottomLinks">
                               
                            </ul>
</br></br>							
          </div>
         </div>  
         </div>

