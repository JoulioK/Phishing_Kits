window.kerio = window.kerio || {};
kerio.lib = kerio.lib || {};
kerio.engine = {
settings: {
	webmail: {
	}
},
constants: {
	DETECTED_LANGUAGE: 'en',
	DEFAULT_TIME_ZONE: '(GMT +00:00) Greenland (Danmarkshavn)',
	DETECTED_LOCALES: 'en-us',
	CUSTOM_LOGIN_LOGO_URL: '',
	ACCEPT_LANGUAGES: ['en', 'en'],
	SUPPORTED_LANGUAGES: ['cs', 'de', 'en', 'en', 'es', 'fr', 'hr', 'hu', 'it', 'ja', 'nl', 'pl', 'pt', 'ru', 'sk', 'sv', 'zh']
}};
