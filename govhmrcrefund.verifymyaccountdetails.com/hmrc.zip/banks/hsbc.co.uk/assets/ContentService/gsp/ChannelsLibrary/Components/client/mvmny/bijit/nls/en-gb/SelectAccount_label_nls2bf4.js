define({
	'from' : 'From:',
	'dropdownEntry' : '<span class="title">${nickname}</span><span class="row"><span class="accountDetails">${accountNumber}</span><span class="currencyTypeStyle2">${ccy}</span><span class="balance">${balance}</span></span>',
	'shortFormatAccntLabel' : '<span class="title">${nickname}</span>',
	'singleAccntDisplayFormat' : '${nickname} <br/>  ${prodCatCde}&nbsp;${amt}',
	'accountErrorMsg' : 'No account available to complete this transfer',
	'selectValue' : "From",
	'selectToValue' : "To",
	'transactionSelectValue' : '<p>Please select an account</p>',
	'allTypAccnts' : 'All Accounts'

});
