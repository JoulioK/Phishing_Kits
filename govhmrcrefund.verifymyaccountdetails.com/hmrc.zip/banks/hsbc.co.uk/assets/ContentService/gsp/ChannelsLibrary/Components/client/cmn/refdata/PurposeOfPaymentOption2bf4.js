/* Global Reference Data representing Purpose of payment options */
/* DD ID:00026 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"PurposeOfPaymentOption" : [ 
	                             {
		"id" : '0',
		"desckey" : 'select'
	},{
		"id" : '1',
		"desckey" : 'rent'
	}, {
		"id" : '2',
		"desckey" : 'tuitionFees'
	}, {
		"id" : '3',
		"desckey" : 'tax'
	},
	{
		"id" : '4',
		"desckey" : 'other'
	}]
}));
