/* Global Reference Data representing payee charges List */
/* DD ID: 00072 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
    "PayeeChargesList": [
         {
            "id": "0",
            "desckey": "select",
            "defaultKey": "Y"
        },
        {
            "id": "1",
            "desckey": "iPay",
            "defaultKey": "N"
        },
        {
            "id": "2",
            "desckey": "youPay",
            "defaultKey": "N"
        },
        {
            "id": "3",
            "desckey": "wePay",
            "defaultKey": "N"
        } 
    ]
}));