define({
    root: ({
        "selectProduct": "Select Product",
        "downloadAsPDF": "Download as PDF",
        "close" 	   : "Close",
        "noPDF"        : "<h2><b>Terms & Condition are not present for the selected product</b></h2>",
        "title"			:"Account information, Terms & Conditions"
    }),
"es-ar": true,
"ar-sa" : true,
"en-sa" : true
});
