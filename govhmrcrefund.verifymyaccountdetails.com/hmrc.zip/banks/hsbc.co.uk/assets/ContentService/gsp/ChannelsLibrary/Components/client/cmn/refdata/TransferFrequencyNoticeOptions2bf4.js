/* Global Reference Data representing Payment Reason */
/* DD ID: 00064 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"TransferFrequencyNoticeOptions" : [ {
		"id" : '0',
		"desckey" : 'Select',
		"defaultKey" : 'Y'
	},{
		"id" : '1',
		"desckey" : 'untilFurther',
		"defaultKey" : 'Y'
	}, {
		"id" : '2',
		"desckey" : 'date'
	}, {
		"id" : '3',
		"desckey" : 'numPayments'
	},
	{
		"id" : 'SL',
		"desckey" : 'untilFurther'
	}, {
		"id" : 'DT',
		"desckey" : 'date'
	}, {
		"id" : 'CT',
		"desckey" : 'numPayments'
	}
	]
}));
