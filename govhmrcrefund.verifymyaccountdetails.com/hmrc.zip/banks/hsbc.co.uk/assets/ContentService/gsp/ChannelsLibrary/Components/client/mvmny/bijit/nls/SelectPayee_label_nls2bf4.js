define({
	root : ({
		'txnTypeToPayeeTypeMapping' : {
			"9" : 1,
			"2" : 2,
			"3" : 3,
			"4" : 4,
			"5" : 5
		},
		'enterAccntNumMsg' : 'Enter account number or payee name',
		'addNewPayee' : 'Add a new payee',
		'recentlyPaid' : 'Recently Paid',
		'myPayees' : 'My payees',
		'addToFav' : 'Add to favourites',
		'payeeSelectValue' : 'Start typing here to see your payee list',
		'NoPayeeSelectedValue' : 'Please select',
		'NoPayeeSelected' : 'You do not have any payees set up on this account',
		'NoPayeeSelectedUK' : 'You have currently no payee setup',
		'rmvFav' : 'Remove from favourite',
		'fullPayeeLst' : 'Full payee list',
		'error' : 'Error',
		'err_EnterTofld' : 'Please enter the To field',
		'to' : 'To',
		'singlePayee' : '<span>${payee}</span>',
		'dropdownEntry' : '<span class="title">${img} ${nickname}</span><span class="row"><span class="accountDetails">${accountNumber}</span><span class="currencyTypeStyle2">${ccy}</span></span>',
		'dropdownEntryCCY' : '<span class="title">${img} ${nickname}</span><span class="row"><span class="currencyTypeStyle2">${ccy}</span></span>',
		'accountErrorMsg' : 'No payee found.',
		'createSOLabel' : 'Create a new standing order'
	}),
	"es-ar" : true,
	"hi-in" : true,
	"en-ph" : true,
	"en-eg" : true,
	"en-hk" : true,
	"zh-cn" : true,
	"zh-hk" : true
});
