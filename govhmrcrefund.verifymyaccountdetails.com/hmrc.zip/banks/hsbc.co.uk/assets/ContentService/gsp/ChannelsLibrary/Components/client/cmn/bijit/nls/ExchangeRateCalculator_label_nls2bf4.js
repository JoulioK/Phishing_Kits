define({
	root : ({
		'disclaimer' : "<p>Exchange rates are subject to market changes and trading hours. The actual rate to be used has 6 decimal places and will be for your confirmation before you make the transaction.</p>",
		'ratesChange' : "Indicative rates only",
		'errorMessage' : "Sorry, there was a problem loading results. Please try again later.",
		'moveMoney' : "New transaction",
		'currencyCalculator' : "Currency converter",
		'from' : "Convert from",
		'to' : "Convert to",
		'switch' : "Currency Switch",
		'reset' : "Reset",
		'amtExceedErr' : "Max number of digits inputted is 13 excluding decimal places and separators.",
		'amtNegErr' : "A valid amount must be inputted.",
		'amtZeroErr' : "A valid amount must be inputted.",
		'amtDecErr' : "A valid number of decimal places for the currency must be inputted.",
		'openDialog' : "Opens a dialog",
		'amount' : "Amount",
		'accessibilityText_moveMoney' : "Move money",
		'ratesSubjectChange' : "Exchange rates are subject to market changes and trading hours.  The actual rate to be used has 6 decimal places and will be for your confirmation before you make the transaction."


	}),
	"es-ar" : true,
	"hi-in" : true,
	"en-je" : true,
	"en-hk" : true,
	"en-ph" : true,
	"en-eg" : true,
	"ar-sa" : true,
	"ar-ae" : true,
	"pt-br" : true,
	"zh-cn" : true,
	"zh-hk" : true
});