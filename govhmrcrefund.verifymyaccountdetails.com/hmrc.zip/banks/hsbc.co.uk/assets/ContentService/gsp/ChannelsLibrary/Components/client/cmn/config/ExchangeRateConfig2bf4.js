define({

	'localCurr' : 'INR',
	'defaultFromCurr' : 'EUR',
	'defaultToCurr' : 'USD',
	'dashboard_mvmny_btn' : true,
	'newtransaction_mvmny_btn' : false

});

