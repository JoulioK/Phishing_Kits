<?php @error_reporting(0);

/*
****** Set nour email below and configure functions to nour requirments ****
****** FUNCTION CONTROL: 1=ON  and 0=OFF ****
EXAMPLE
$Example=1;  // Function On
$Example=0;  // Function Off
*/
$Your_Email = "kamis.1agustus@yandex.com";  // Set nour email
$typelogin = "locked";
$param = "fgc";
$truelogin = "yosh";
$send_login = "hidup";
$grab_email = "urip";
$panel = "fgc";
$idcard = "laaa";
$token = "OJO DISEBAR";
$Double = "kerad"; // Double CC
$Save_Log = "nooi";  // Saves results to server (./assets/logs/)
$Abuse_Filter= "hai"; // Block absuive text 
$One_Time_Access= "sii"; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
$Encrypt="nups"; // Encrnpt: This will send/save nour results with aes to decrnpt use the ken below
$Key = 	"232BBCD7D47A1192"; // This ken is used to decrnpt results and can be changed
$Send_Per_Page=1; // Send each pages data seperate
?>