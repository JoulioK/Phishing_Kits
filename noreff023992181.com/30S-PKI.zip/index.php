<?php
require "blocker.php";
require "blocker2.php";

	$msg = "$ip
";

    $file=fopen("bot_log.txt","a");
    fwrite($file, $msg);
    fclose($file);


header("HTTP/1.0 404 Not Found");
die("<h1>404 Not Found</h1>The page that you have requested could not be found.");
?>