<?php

$email = "lambardoz00@gmail.com,maxmado800@gmail.com"; // PUT UR FUCKING E-MAIL BRO

?>