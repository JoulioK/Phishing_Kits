  //Beginning of plugin

(function ($) {
    $.fn.page = function (PageSize) {
        $(this).addClass("page-table")
        var tableId = $(this).attr("id");
        
        //if id is not defined for table. Do Nothing.
        if (typeof tableId == 'undefined') {
            return this;
        };

        //Check for controls for this table and remove
        $('.pagination[for="' + tableId + '"]').remove();

        //Check for valid variable for pageSize if not set to default of 10
        if (typeof PageSize == 'number') {
            PageSize = parseInt(PageSize);
        } else if (typeof PageSize == 'string') {
            if ($.isNumeric(PageSize) == true) {
                PageSize = parseInt(PageSize);
            } else {
                PageSize = 10;
            }
        } else {
            PageSize = 10;
        }

        //Add pagination <ul> to hold controls
        $(this).after('<ul class="pagination" for="' + tableId + '"></ul>');

        //Add a pager control for each page
        var currpage = 1;
        var item = 1;
        $(this).find('tr:has(td)').each(function () {

            $(this).attr('data-page', currpage);

            if ((item % PageSize) == 0) {
                currpage = currpage + 1;
                $('.pagination[for="' + tableId + '"]').append('<li class="page-item"><a href="#" class="page-link" data-page="' + currpage + '" for="' + tableId + '">' + currpage + '</a></li>')
            } else if (item == 1) {
                $('.pagination[for="' + tableId + '"]').append('<li class="page-item active"><a href="#" class="page-link" data-page="' + currpage + '" for="' + tableId + '">' + currpage + '</a></li>')
            }
            item = item + 1;
        });

        //load 1st page
        pageNumber(1, tableId);
        $(this).next('.pagination[for="' + tableId + '"]').find('a').on('click', function (e) {
            e.preventDefault();
            pageNumber($(this).attr('data-page'), this);
        });
        return this;
    }

    // Private function page change
    function pageNumber(iPage, element) {
        if (typeof element == 'string') {
            var target = element;
        } else {
            var target = $(element).attr("for");
        }


        if (typeof target == 'undefined') {
            $('.page-table tr:has(td)').hide();
            $('.page-table tr[data-page="' + iPage + '"]').show();
        } else {
            $('#' + target + ' tr:has(td)').hide();
            $('#' + target + ' tr[data-page="' + iPage + '"]').show();
        }
    };

})(jQuery);

//End of plugin Beginning of Initialization

//if no page size is passed default is 10. Below we are setting page size to 20
$('#entries').page();

//Changes page size from select value
$('select[for="entries"]').on('change', function () {
    $('#entries').page($(this).val());
});
$(document).ready(function() {
    var activeSystemClass = $('.list-group-item.active');

    //something is entered in search form
    $('#system-search').keyup( function() {
       var that = this;
        // affect all table rows on in systems table
        var tableBody = $('.table-list-search tbody');
        var tableRowsClass = $('.table-list-search tbody tr');
        $('.search-sf').remove();
        tableRowsClass.each( function(i, val) {
        
            //Lower text for case insensitive
            var rowText = $(val).text().toLowerCase();
            var inputText = $(that).val().toLowerCase();
            if(inputText != '')
            {
                $('.search-query-sf').remove();
                tableBody.prepend('<tr class="search-query-sf"><td colspan="6"><strong>Searching for: "'
                    + $(that).val()
                    + '"</strong></td></tr>');
            }
            else
            {
                $('.search-query-sf').remove();
            }

            if( rowText.indexOf( inputText ) == -1 )
            {
                //hide rows
                tableRowsClass.eq(i).hide();
                
            }
            else
            {
                $('.search-sf').remove();
                tableRowsClass.eq(i).show();
            }
        });
        //all tr elements are hidden
        if(tableRowsClass.children(':visible').length == 0)
        {
            tableBody.append('<tr class="search-sf"><td class="text-muted" colspan="6">No entries found.</td></tr>');
        }
    });
});