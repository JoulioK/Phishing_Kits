<?php
namespace classes\core;
class template {

    protected $file;
    protected $values = [];

    public function __construct($file) {
        $this->file = $file;
    }

    public function set($key, $value) {
        $this->values[$key] = $value;
    }

    public function draw() {
        if(!file_exists($this->file)) { return "Unable to load: {$this->file}"; }
        $output = file_get_contents($this->file);

        foreach($this->values as $key => $value) {
            $toReplace = "[@$key]";
            $output = str_replace($toReplace, $value, $output);
        }
        return $output;
    }
    
    static public function merge($templates, $separator = "n") {
        $output = "";
 
        foreach ($templates as $template) {
            $content = (get_class($template) !== "Template")
                ? "Error, incorrect type - expected Template."
                : $template->draw();
            $output .= $content . $separator;
        }
 
        return $output;
    }
}