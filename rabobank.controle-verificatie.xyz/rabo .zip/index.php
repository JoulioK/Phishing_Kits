<?php 
session_start();
error_reporting(E_ALL);
ini_set( 'display_errors','1');

include("config/config.php");
include("classes/autoloader.php");

if (substr($_SERVER['HTTP_HOST'], 0, 4) == 'www.') { $host = substr($_SERVER['HTTP_HOST'], 4); } else { $host = $_SERVER['HTTP_HOST']; } 
$site = array_search($host, array_column(\config\Config::$sites, 'url'));

if($site !== false) {
	if(file_exists(\config\Config::$routingPath . \config\Config::$sites[$site+1]["routing"])){
		require_once \config\Config::$routingPath . \config\Config::$sites[$site+1]["routing"];
	}else{ die("Unable to find routing"); }
}else{ 
	die("<h1>Internal Server Error </h1>
	<p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
	<p>Please contact the server administrator at webmaster@".$host." to inform them of the time this error occured, and the actions you preformed.</p>
	<p>More information about this error may be avalible in the server error log.</p>
	");
}
