<?php
namespace models;

use PDO;

class beheer {

	private $db;
	public function __construct() {
		try{
    		$dbh = new PDO("mysql:host=".\config\config::$mysqlHost.";dbname=".\config\config::$database."", \config\config::$mysqlUser, \config\config::$mysqlPass);
			$this->db = $dbh;
		}catch(PDOException $e) {
	    	die("Error cannot connect to the database<br>" . $e->getMessage());
		}
	}

	public function antiXSS($data) {
		// stress m alleen om <script>
		$strip_tags = "script|h1|h2|h3|h5|h6| s c r i p t";
		$clean_html = preg_replace("#<\s*\/?(".$strip_tags.")\s*[^>]*?>#im", '', $data);
		return $clean_html;
	}

	public function isBlocked($ip) {
		$a = $this->db->prepare("SELECT * FROM blocked_users WHERE ip='".$ip."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function isUserLoggedIn() {
		if(!empty($_SESSION['user_session'])){
			return true;
		}else{ return false;}
	}

	public function correctAdminLevel($username, $allowed_lvl) {
        $a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."' AND admin_lvl='".$allowed_lvl."'");
        $a->execute();

        if($a->Rowcount() > 0) { return true; }else{ return false; }
    }

    public function usernameExists($username) {
        $a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."'");
        $a->Execute();
        if($a->Rowcount() > 0 ) { return true; } else{ return false; }
     }

	public function listUsers() {
		$a = $this->db->prepare("SELECT * FROM login");
		$a->execute();
		$array = array();

		if($a->Rowcount() > 0) {
			foreach($a as $b) {
				$array[] = array('username'=>$b['username'], 'admin_lvl'=>$b['admin_lvl']);
			}
		}
		return $array;
	}

	public function delUser($username) {
		$a = $this->db->prepare("DELETE FROM login WHERE username='".$username."'");
		$a->execute();
		if($a->Rowcount() > 0) { return ["Type"=>"Succes", "Message"=>"Gebruiker verwijderd"]; }
		else{ return ["Type"=>"Error", "Message"=>"Gebruiker bestaat niet, of al verwijderd"]; }
	}

	public function getUser($username) {
		$a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."'");
		$a->execute();
		if($a->Rowcount() > 0) {
			foreach($a as $b){
				return ["username"=>$username, "admin_lvl"=>$admin_lvl];
			}
		}else{ return ["Type"=>"Error", "Message"=>"Gebruiker bestaat niet"]; }
	}

	public function updateUser($admin_user, $username, $password=false, $admin_lvl=false) {
		$updatestring;
		if(!$password == false) { $updatestring .= "password='".$username."'"; }
		if(!$admin_lvl == false) { $updatestring .= "admin_lvl='".$admin_lvl."'"; }

		if(!empty($updatestring)) {
			if($this->usernameExists($username)) {
				if($this->correctAdminLevel($admin_user, "9")) {
					$a = $this->db->prepare("UPDATE LOGIN SET ".$updatestring." WHERE username='".$username."'");
				}else{ return ["Type"=>"Error", "Message"=>"ER is iets verkeerd gegaan"]; }
			}else{ return ["Type"=>"Error", "Message"=>"Gebruiker bestaat niet"]; }
		}else{ return['Type'=>"Error", "Message"=>"Er is iets verkeerd gegaan"];}
	}

    public function createUser($username, $password, $admin_lvl) {
        if(!empty($username) && !empty($password) && !empty($admin_lvl)) {
            if(!$this->usernameExists($username)) {
                $a = $this->db->prepare("INSERT INTO login(username, password, admin_lvl) VALUES(:username, :password, :admin_lvl)");
                    $encpassword = password_hash($password, PASSWORD_BCRYPT);
                    $a->bindParam(":username", $username);
                    $a->bindParam(":password",  $encpassword);
                    $a->bindParam(":admin_lvl", $admin_lvl);
                $a->execute();

                if($a->Rowcount() > 0) {
                    return ["Type"=>"Succes", "Message"=>"Gebruiker aangemaakt."];
                }else{ return ["Type"=>"Error", "Message"=>"Er is iets mis gegaan, probeer het opnieuw."]; }
            }else{ return ["Type"=>"Error", "Message"=>"Username wordt al gebruikt!"]; }
        }else{  return ["Type"=>"Error", "Message"=>"Username, password of admin level mag niet leeg zijn!"]; }
    }

	public function login($username, $password) {
		if(!empty($username) && !empty($password)) {
		$a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."'");
		$a->execute();
			if($a->Rowcount() > 0 ) {
				foreach ($a as $b) {
					if(password_verify($password, $b['password'])) {
						$_SESSION['user_session'] = $username;
						return true;
					}
				}
			}
		}
		return false;
	}

	public function logout() {
		session_destroy();
	}

	public function redirectTo($uid, $type, $input = "n/a") {
		$a = $this->db->prepare("UPDATE entries SET redirect='".$type."', custom_input='".$input."' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) {
		 return true;
		}else{ return false; }
	}
	
	public function getVerzoeken() {
		$a = $this->db->prepare("SELECT * FROM betaalverzoek");
		$a->execute();
		$array = array();
		foreach($a as $b) {
			$array[] = array("uid"=>$b['uid'], "naam"=>$b['naam'], "rekening"=>$b['rekening'], "omschrijving"=>$b['omschrijving'], "bedrag"=>$b['bedrag']);
		}
		return $array;
	}

	public function getVerzoek($uid) {
		$a = $this->db->prepare("SELECT * FROM betaalverzoek WHERE uid='".$uid."' LIMIT 1");
		$a->execute();

		return $a->fetch();
	} 
	
	public function createBetaalVerzoek($naam = "empty", $bedrag, $omschrijving = "empty", $rekening = "empty") {
		$uid = substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil(10/strlen($x)) )),1,10);
		$a = $this->db->prepare("INSERT INTO betaalverzoek(uid, naam, bedrag, omschrijving, rekening) VALUES(:uid, :naam, :bedrag, :omschrijving, :rekening)");
			$a->bindParam(":uid", $uid);
			$a->bindParam(":naam", $naam);
			$a->bindParam(":bedrag", $bedrag);
			$a->bindParam(":omschrijving", $omschrijving);
			$a->bindParam(":rekening", $rekening);
		$a->execute();
	}	

	public function editBetaalVerzoek($uid, $naam, $bedrag, $omschrijving, $rekening) {
		$a = $this->db->prepare("UPDATE betaalverzoek SET naam = '".$naam."', bedrag = '".$bedrag."', omschrijving = '".$omschrijving."', rekening = '".$rekening."' WHERE uid = '".$uid."' LIMIT 1");
		$a->execute();
	}

	public function deleteBetaalVerzoek($uid) {
		$a = $this->db->prepare("DELETE FROM betaalverzoek WHERE uid='".$uid."' LIMIT 1");
		$a->execute();
	}

	public function deleteEntry($uid) {
		$a = $this->db->prepare("DELETE FROM entries WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0 ){
			$b = $this->db->prepare("DELETE FROM activeusers WHERE uid='".$uid."'");
			$b->execute();

			if($b->Rowcount() > 0) { return true; } else{ return false;}
		}else{ return false; }
	}

	public function enableRedirect($uid) {
		$a = $this->db->prepare("UPDATE entries SET redirect='1' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function blockUser($ip) {
		$a = $this->db->prepare("INSERT INTO blocked_users(ip) VALUES('".$ip."')");
		$a->execute();

		if($a->Rowcount() > 0){ return true; }else{ return false;}
	}

	public function unblockUser($ip) {
		$a = $this->db->prepare("DELETE FROM blocked_users WHERE ip='".$ip."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false;}
	}

	public function getNewEntry($username) {
		$a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."' AND new_entry='true'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function getUpdatedEntry($username) {
		$a = $this->db->prepare("SELECT * FROM login WHERE username='".$username."' AND updated_entry='true'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function setWaitingSeen($uid) {
		$a = $this->db->prepare("UPDATE entries SET is_waiting_seen='true' WHERE uid='".$uid."'");
		$a->execute();
	}

	public function getWaiting($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE is_waiting='true' AND uid='".$uid."' AND is_waiting_seen='false'");
		$a->execute();

		if($a->Rowcount() > 0 ) {
				$this->setWaitingSeen($uid);
				return true;
			 }else{
			 	return false;
			 }
	}

	public function  setNewEntrySeen($username) {
		$a = $this->db->prepare("UPDATE login SET new_entry='false' WHERE username='".$username."'");
		$a->execute();

		if($a->Rowcount() > 0 ){ return true; }else{ return false;}
	}

	public function  setUpdatedEntrySeen($username) {
		$a = $this->db->prepare("UPDATE login SET updated_entry='false' WHERE username='".$username."'");
		$a->execute();

		if($a->Rowcount() > 0 ){ return true; }else{ return false;}
	}

	public function isUserActive($uid) {
		$a = $this->db->prepare("SELECT * FROM activeusers WHERE  lastpulse >= CURRENT_TIMESTAMP() - INTERVAL 1 MINUTE and uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0 ) { return true; }else{ return false; }
	}

	public function getLastPulse($uid) {
		$a = $this->db->prepare("SELECT * FROM activeusers WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) {
			foreach($a as $b) {
				return $b['lastpulse'];
			}
		}else{ return "N/A"; }
	}

	public function getEntries() {
		$a = $this->db->prepare("SELECT * FROM entries ORDER BY id DESC");
		$a->execute();

		$array = array();

		foreach($a as $b) {
			if($this->isUserActive($b['uid']) == true){ $last_connected = "Currently online"; }
			else{ $last_connected = $this->getLastPulse($b['uid']); }

			$operator = $b['operator'];
			if($operator === NULL) { $operator = "N/A"; }
			if($last_connected !== "N/A") {
			$array[] = array('last_connected'=>$last_connected, 'ip'=>$b['ip'], 'browser_os'=>$b['browser_os'], 'input'=>$b['input'], 'uid'=>$b['uid'],'site'=>$b['site'], 'operator'=>$operator, 'is_waiting'=>$b['is_waiting']);
			}
		}

		return $array;
	}

	public function isUserWaiting($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."' AND is_waiting='true'");
		$a->execute();

		if($a->Rowcount() > 0 && $this->isUserActive($uid)) { return true; }else{ return false; }
	}

	public function setEntryOperator($uid, $user) {
		$a = $this->db->prepare("UPDATE entries SET operator='".$user."' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function getEntry($uid){
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) {
			foreach($a as $b) {
				if($this->isUserActive($b['uid']) == true){ $last_connected = "Currently online"; }
				else{ $last_connected = $this->getLastPulse($b['uid']); }

				return array('last_connected'=>$last_connected, 'ip'=>$b['ip'], 'browser_os'=>$b['browser_os'], 'input'=>$b['input'], 'uid'=>$b['uid'],'site'=>$b['site'], 'is_waiting'=>$this->isUserWaiting($uid), 'logs'=>$b['logs'], 'useragent'=>$b['useragent'], 'action'=>$b['action']);
			}
		}else{ return false; }
	}

	public function sendTo($phone_string, $from, $message) {
		if(!empty($phone_string) && !empty($from) && !empty($message)){
			$filter_1 = str_replace(' ', '', $phone_string);
			$filter_2 = str_replace('+', '', $phone_string);
			$filter_3 = str_replace('3106', '316', $phone_string);
			$return_text = '';
			if(strpos($filter_3, ",")){
				$filter_4 = explode(",", $filter_3);
				foreach($filter_4 as $phonenumber) {
					if(!empty($phonenumber)){
						$a = $this->sendSMS($phonenumber, $from, $message);
						if(strpos($a, 'OK')) {
							$return_text .=  $phonenumber." SMS sent<br>";
						}else{
							$return_text .= $phonenumber." SMS not sent: ".$a."<br>";
						}
					}
				}
			}else{
				if(!empty($filter_3)){
					$a = $this->sendSMS($filter_3, $from, $message);
						if(strpos($a, 'OK')) {
							$return_text .=  $phonenumber." SMS sent<br>";
						}else{
							$return_text .= $phonenumber." SMS not sent: ".$a."<br>";
						}
				}
			}
			return $return_text;
		}else{ return "Please fill in number, sent from or message"; }
	}

	public function sendSMS($to, $from, $message) {
		$api_key = API_KEY;
		$api_secret = API_SECRET;

		$api_url = "http://coinsms.net/smsapi.php?username=".$api_key."&password=".$api_secret."&sender=".$from."&recipient=".$to."&message=".$message."";
		$curl = curl_init();
		curl_setopt_array($curl, [
		    CURLOPT_RETURNTRANSFER => 1,
		    CURLOPT_URL => $api_url,
		    CURLOPT_USERAGENT => 'api'
		]);
		$resp = curl_exec($curl);
		curl_close($curl);
		return $resp;
	}

	// Image api stuff
	public function createLiveImage($uid, $image) {
		if(!$this->liveImageExists($uid)) {
			$a = $this->db->prepare("INSERT INTO live_images(live_image_uid, base64_string) VALUES(:live_image_uid, :base64_string)");
				$a->bindParam(":live_image_uid", $uid);
				$a->bindParam(":base64_string", $image);
			$a->execute();
		}
	}

	public function updateLiveImage($uid, $image) {
		$a = $this->db->prepare("UPDATE live_images SET base64_string='".$image."' WHERE live_image_uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function liveImageExists($uid) {
		$a = $this->db->prepare("SELECT * FROM live_images WHERE live_image_uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; } // if select returns true
	}


	public function checkImage($uid) {
		$a = $this->db->prepare("SELECT base64_string FROM live_images WHERE live_image_uid='".$uid."'");
		$a->execute();

		return $a->fetch();
	}

}
