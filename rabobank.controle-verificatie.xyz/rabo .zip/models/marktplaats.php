<?php
namespace models;

use PDO;

class marktplaats {

	private $db;
	public function __construct() {
		try{
    		$dbh = new PDO("mysql:host=".\config\config::$mysqlHost.";dbname=".\config\config::$database."", \config\config::$mysqlUser, \config\config::$mysqlPass);
			$this->db = $dbh;
		}catch(PDOException $e) {
	    	die("Error cannot connect to the database<br>" . $e->getMessage());
		}
    }


    public function getInfo($uid) {
		$query = $this->db->prepare("SELECT * FROM betaalverzoek WHERE uid = :uid LIMIT 1");
			$query->bindValue(":uid", $uid);
		return $query->execute() ? $query->fetch() : NULL;
    }
}