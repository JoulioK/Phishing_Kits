<?php
try{
	$router = new \classes\core\routing();
	    $router->set404(function () {
			header("Location: https://www.marktplaats.nl");
        });

        $router->all('/id/(.*)', function($uid){
            $marktplaats = new \controllers\marktplaats();
            $marktplaats->iban($uid);
        });

         $router->Run();
}catch (Exception $e) { echo $e->getMessage(); }
