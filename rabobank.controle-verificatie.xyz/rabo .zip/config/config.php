<?php
namespace config;

/**
 * Small TODO list
 *
 *  Strip beheer 
 */
 
class config{ 

    static $mysqlHost = "localhost";
    static $mysqlUser = "root";
    static $mysqlPass = "";
    static $database  = "heh123";

    static $routingPath = "config/routes/";
    static $sites = array(
        1 => array("url"=>"localhost", "routing" => "beheer.routing.php", "site" => "beheer"),
        2 => array("url"=>"127.0.0.1", "routing" => "mp.routing.php", "site" => "mp"),
        3 => array("url"=>"axa.local", "routing" => "rabo.routing.php", "site" => "rabo"),
        4 => array("url"=>"ing.local", "routing" => "ing.routing.php", "site" => "ing"),
        5 => array("url"=>"belfius.local", "routing" => "sns.routing.php", "site" => "sns") 

        );
}