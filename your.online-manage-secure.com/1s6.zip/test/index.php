
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>16Shop - Apple Manage Result</title>
    <link rel='icon' href='favicon.ico'>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:400,700">
    <!-- https://fonts.google.com/specimen/Roboto -->
    <link rel="stylesheet" href="css/fontawesome.min.css">
    <!-- https://fontawesome.com/ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- https://getbootstrap.com/ -->
    <link rel="stylesheet" href="css/templatemo-style.css">
    <!--
	Product Admin CSS Template
	https://templatemo.com/tm-524-product-admin
	-->
</head>

<body id="reportsPage">
    <div class="" id="home">
        <nav class="navbar navbar-expand-xl">
            <div class="container h-100">
                <a class="navbar-brand" href="home.php">
                    <h1 class="tm-site-title mb-0" style="font-size:25px;">16SHOP</h1>
                </a>
                <button class="navbar-toggler ml-auto mr-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars tm-nav-icon"></i>
                </button>

                <div style="margin-left:-150px;" class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mx-auto h-100">
                        <li class="nav-item">
                            <a class="nav-link" href="home.php">
                                <i class="fas fa-home"></i>
                                Home
                                
                            </a>
                        </li>
                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-shopping-cart"></i>
                                <span>
                                    Tools <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <b>&nbsp;&nbsp;&nbsp;&nbsp;FREE</b>
                                <a class="dropdown-item" href="proxy_list.php">Proxy List</a>
                                
                            </div>
                        </li>

                         

                        
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-cog"></i>
                                <span>
                                    Manage <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <b>&nbsp;&nbsp;&nbsp;&nbsp;Apple</b>
                                <a class="dropdown-item" href="list_domain_apple.php">List Domain</a>
                                <a class="dropdown-item" href="register_apple_domain.php">Register New Domain</a>
                                <a class="dropdown-item" href="setting_apple.php">Manage Result</a>
                                <div class="dropdown-divider"></div>
                                <b>&nbsp;&nbsp;&nbsp;&nbsp;Amazon</b>
                                <a class="dropdown-item" href="list_domain_amazon.php">List Domain</a>
                                <a class="dropdown-item" href="register_amazon_domain.php">Register New Domain</a>
                                <a class="dropdown-item" href="setting_amazon.php">Manage Result</a>
                                <div class="dropdown-divider"></div>
                                <b>&nbsp;&nbsp;&nbsp;&nbsp;Apple Validator</b>
                                <a class="dropdown-item" href="list_applevalid.php">List IP</a>
                                <a class="dropdown-item" href="register_applevalid.php">Register New IP</a>
                                
                            </div>
                        </li>
<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-envelope"></i>
                                <span>
                                    Sender <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                
                                <a class="dropdown-item" href="list_sender.php">List Key</a>
                                <a class="dropdown-item" href="register_sender.php">Register New Key</a>
                                
                            </div>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="download.php">
                                <i class="fas fa-download"></i>
                                Download
                                
                            </a>
                        </li>
                    </ul>
                    <ul class="navbar-nav">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">
                                <i class="far fa-user"></i>
                                <span>
                                    Account <i class="fas fa-angle-down"></i>
                                </span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                
                                <a class="dropdown-item" href="#">Mcdonaldcomzz@gmail.com</a>
                                <a class="dropdown-item" href="#">Balance: 0</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="login_history.php">Login History</a>
                                <a class="dropdown-item" href="password.php">Change Password</a>
                                <a class="dropdown-item" href="#">Top-up Balance</a>
                                <a class="dropdown-item" href="logout.php">Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

        </nav>
        <div class="container">
           <br>
           <div class="row tm-content-row">
                <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller" style="padding-bottom:900px;">
                        <h2 class="tm-block-title">Apple Manage</h2>
                        <form action="" method="post" class="tm-signup-form row">
                          <div class="form-group col-lg-6">
                  <label for="name">Email Result</label>
                  <input name="email_result" type="email" value="rich.ph1llips@yandex.com" class="form-control validate"><br>
                  <label for="name">Site Parameter</label>
                  <input name="site_parameter" type="text" value="signin_" class="form-control validate"><br>
                  <label for="name">Site Password</label>
                  <input name="site_password" type="text" value="signin_" class="form-control validate"><br>
                  <label for="name">Sender Mail / From Email</label>
                  <input name="sender_mail" type="text" value="admin@richman.com" class="form-control validate"><br>
                  <label for="name">Theme</label>
                  <select name="theme" class="form-control custom-select">
                              <option value="apple" selected="selected">Apple</option>
                              <option value="icloud" >iCloud</option>
                            </select><br><br>
                  <label for="name">Notice / Letter</label>
                  <select name="letter" class="form-control custom-select">
                              <option value="locked" >Locked</option>
                              <option value="verify" selected="selected">Verify</option>
                              <option value="invoice" >Invoice</option>
                            </select>
                  <br><br>
                  <label for="name">Lock Country</label>
                  <select name="lock_country" class="form-control custom-select">
<option value="" selected="selected">All Country</option>
<option value="">All Country</option>                              
<option value="Afghanistan">Afghanistan</option>
  <option value="Albania">Albania</option>
  <option value="Algeria">Algeria</option>
  <option value="American Samoa">American Samoa</option>
  <option value="Andorra">Andorra</option>
  <option value="Angola">Angola</option>
  <option value="Anguilla">Anguilla</option>
  <option value="Antarctica">Antarctica</option>
  <option value="Antigua and Barbuda">Antigua and Barbuda</option>
  <option value="Argentina">Argentina</option>
  <option value="Armenia">Armenia</option>
  <option value="Aruba">Aruba</option>
  <option value="Australia">Australia</option>
  <option value="Austria">Austria</option>
  <option value="Azerbaijan">Azerbaijan</option>
  <option value="Bahamas">Bahamas</option>
  <option value="Bahrain">Bahrain</option>
  <option value="Bangladesh">Bangladesh</option>
  <option value="Barbados">Barbados</option>
  <option value="Belarus">Belarus</option>
  <option value="Belgium">Belgium</option>
  <option value="Belize">Belize</option>
  <option value="Benin">Benin</option>
  <option value="Bermuda">Bermuda</option>
  <option value="Bhutan">Bhutan</option>
  <option value="Bolivia">Bolivia</option>
  <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
  <option value="Botswana">Botswana</option>
  <option value="Bouvet Island">Bouvet Island</option>
  <option value="Brazil">Brazil</option>
  <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
  <option value="Brunei Darussalam">Brunei Darussalam</option>
  <option value="Bulgaria">Bulgaria</option>
  <option value="Burkina Faso">Burkina Faso</option>
  <option value="Burundi">Burundi</option>
  <option value="Cambodia">Cambodia</option>
  <option value="Cameroon">Cameroon</option>
  <option value="Canada">Canada</option>
  <option value="Cape Verde">Cape Verde</option>
  <option value="Cayman Islands">Cayman Islands</option>
  <option value="Central African Republic">Central African Republic</option>
  <option value="Chad">Chad</option>
  <option value="Chile">Chile</option>
  <option value="China">China</option>
  <option value="Christmas Island">Christmas Island</option>
  <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
  <option value="Colombia">Colombia</option>
  <option value="Comoros">Comoros</option>
  <option value="Congo">Congo</option>
  <option value="Congo, The Democratic Republic of The">Congo, The Democratic Republic of The</option>
  <option value="Cook Islands">Cook Islands</option>
  <option value="Costa Rica">Costa Rica</option>
  <option value="Cote D'ivoire">Cote D'ivoire</option>
  <option value="Croatia">Croatia</option>
  <option value="Cuba">Cuba</option>
  <option value="Cyprus">Cyprus</option>
  <option value="Czech Republic">Czech Republic</option>
  <option value="Denmark">Denmark</option>
  <option value="Djibouti">Djibouti</option>
  <option value="Dominica">Dominica</option>
  <option value="Dominican Republic">Dominican Republic</option>
  <option value="Ecuador">Ecuador</option>
  <option value="Egypt">Egypt</option>
  <option value="El Salvador">El Salvador</option>
  <option value="Equatorial Guinea">Equatorial Guinea</option>
  <option value="Eritrea">Eritrea</option>
  <option value="Estonia">Estonia</option>
  <option value="Ethiopia">Ethiopia</option>
  <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
  <option value="Faroe Islands">Faroe Islands</option>
  <option value="Fiji">Fiji</option>
  <option value="Finland">Finland</option>
  <option value="France">France</option>
  <option value="French Guiana">French Guiana</option>
  <option value="French Polynesia">French Polynesia</option>
  <option value="French Southern Territories">French Southern Territories</option>
  <option value="Gabon">Gabon</option>
  <option value="Gambia">Gambia</option>
  <option value="Georgia">Georgia</option>
  <option value="Germany">Germany</option>
  <option value="Ghana">Ghana</option>
  <option value="Gibraltar">Gibraltar</option>
  <option value="Greece">Greece</option>
  <option value="Greenland">Greenland</option>
  <option value="Grenada">Grenada</option>
  <option value="Guadeloupe">Guadeloupe</option>
  <option value="Guam">Guam</option>
  <option value="Guatemala">Guatemala</option>
  <option value="Guinea">Guinea</option>
  <option value="Guinea-bissau">Guinea-bissau</option>
  <option value="Guyana">Guyana</option>
  <option value="Haiti">Haiti</option>
  <option value="Heard Island and Mcdonald Islands">Heard Island and Mcdonald Islands</option>
  <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
  <option value="Honduras">Honduras</option>
  <option value="Hong Kong">Hong Kong</option>
  <option value="Hungary">Hungary</option>
  <option value="Iceland">Iceland</option>
  <option value="India">India</option>
  <option value="Indonesia">Indonesia</option>
  <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
  <option value="Iraq">Iraq</option>
  <option value="Ireland">Ireland</option>
  <option value="Israel">Israel</option>
  <option value="Italy">Italy</option>
  <option value="Jamaica">Jamaica</option>
  <option value="Japan">Japan</option>
  <option value="Jordan">Jordan</option>
  <option value="Kazakhstan">Kazakhstan</option>
  <option value="Kenya">Kenya</option>
  <option value="Kiribati">Kiribati</option>
  <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
  <option value="Korea, Republic of">Korea, Republic of</option>
  <option value="Kuwait">Kuwait</option>
  <option value="Kyrgyzstan">Kyrgyzstan</option>
  <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
  <option value="Latvia">Latvia</option>
  <option value="Lebanon">Lebanon</option>
  <option value="Lesotho">Lesotho</option>
  <option value="Liberia">Liberia</option>
  <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
  <option value="Liechtenstein">Liechtenstein</option>
  <option value="Lithuania">Lithuania</option>
  <option value="Luxembourg">Luxembourg</option>
  <option value="Macao">Macao</option>
  <option value="Macedonia, The Former Yugoslav Republic of">Macedonia, The Former Yugoslav Republic of</option>
  <option value="Madagascar">Madagascar</option>
  <option value="Malawi">Malawi</option>
  <option value="Malaysia">Malaysia</option>
  <option value="Maldives">Maldives</option>
  <option value="Mali">Mali</option>
  <option value="Malta">Malta</option>
  <option value="Marshall Islands">Marshall Islands</option>
  <option value="Martinique">Martinique</option>
  <option value="Mauritania">Mauritania</option>
  <option value="Mauritius">Mauritius</option>
  <option value="Mayotte">Mayotte</option>
  <option value="Mexico">Mexico</option>
  <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
  <option value="Moldova, Republic of">Moldova, Republic of</option>
  <option value="Monaco">Monaco</option>
  <option value="Mongolia">Mongolia</option>
  <option value="Montserrat">Montserrat</option>
  <option value="Morocco">Morocco</option>
  <option value="Mozambique">Mozambique</option>
  <option value="Myanmar">Myanmar</option>
  <option value="Namibia">Namibia</option>
  <option value="Nauru">Nauru</option>
  <option value="Nepal">Nepal</option>
  <option value="Netherlands">Netherlands</option>
  <option value="Netherlands Antilles">Netherlands Antilles</option>
  <option value="New Caledonia">New Caledonia</option>
  <option value="New Zealand">New Zealand</option>
  <option value="Nicaragua">Nicaragua</option>
  <option value="Niger">Niger</option>
  <option value="Nigeria">Nigeria</option>
  <option value="Niue">Niue</option>
  <option value="Norfolk Island">Norfolk Island</option>
  <option value="Northern Mariana Islands">Northern Mariana Islands</option>
  <option value="Norway">Norway</option>
  <option value="Oman">Oman</option>
  <option value="Pakistan">Pakistan</option>
  <option value="Palau">Palau</option>
  <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
  <option value="Panama">Panama</option>
  <option value="Papua New Guinea">Papua New Guinea</option>
  <option value="Paraguay">Paraguay</option>
  <option value="Peru">Peru</option>
  <option value="Philippines">Philippines</option>
  <option value="Pitcairn">Pitcairn</option>
  <option value="Poland">Poland</option>
  <option value="Portugal">Portugal</option>
  <option value="Puerto Rico">Puerto Rico</option>
  <option value="Qatar">Qatar</option>
  <option value="Reunion">Reunion</option>
  <option value="Romania">Romania</option>
  <option value="Russian Federation">Russian Federation</option>
  <option value="Rwanda">Rwanda</option>
  <option value="Saint Helena">Saint Helena</option>
  <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
  <option value="Saint Lucia">Saint Lucia</option>
  <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
  <option value="Saint Vincent and The Grenadines">Saint Vincent and The Grenadines</option>
  <option value="Samoa">Samoa</option>
  <option value="San Marino">San Marino</option>
  <option value="Sao Tome and Principe">Sao Tome and Principe</option>
  <option value="Saudi Arabia">Saudi Arabia</option>
  <option value="Senegal">Senegal</option>
  <option value="Serbia and Montenegro">Serbia and Montenegro</option>
  <option value="Seychelles">Seychelles</option>
  <option value="Sierra Leone">Sierra Leone</option>
  <option value="Singapore">Singapore</option>
  <option value="Slovakia">Slovakia</option>
  <option value="Slovenia">Slovenia</option>
  <option value="Solomon Islands">Solomon Islands</option>
  <option value="Somalia">Somalia</option>
  <option value="South Africa">South Africa</option>
  <option value="South Georgia and The South Sandwich Islands">South Georgia and The South Sandwich Islands</option>
  <option value="Spain">Spain</option>
  <option value="Sri Lanka">Sri Lanka</option>
  <option value="Sudan">Sudan</option>
  <option value="Suriname">Suriname</option>
  <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
  <option value="Swaziland">Swaziland</option>
  <option value="Sweden">Sweden</option>
  <option value="Switzerland">Switzerland</option>
  <option value="Syrian Arab Republic">Syrian Arab Republic</option>
  <option value="Taiwan, Province of China">Taiwan, Province of China</option>
  <option value="Tajikistan">Tajikistan</option>
  <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
  <option value="Thailand">Thailand</option>
  <option value="Timor-leste">Timor-leste</option>
  <option value="Togo">Togo</option>
  <option value="Tokelau">Tokelau</option>
  <option value="Tonga">Tonga</option>
  <option value="Trinidad and Tobago">Trinidad and Tobago</option>
  <option value="Tunisia">Tunisia</option>
  <option value="Turkey">Turkey</option>
  <option value="Turkmenistan">Turkmenistan</option>
  <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
  <option value="Tuvalu">Tuvalu</option>
  <option value="Uganda">Uganda</option>
  <option value="Ukraine">Ukraine</option>
  <option value="United Arab Emirates">United Arab Emirates</option>
  <option value="United States">United States</option>
  <option value="United Kingdom">United Kingdom</option>
  <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
  <option value="Uruguay">Uruguay</option>
  <option value="Uzbekistan">Uzbekistan</option>
  <option value="Vanuatu">Vanuatu</option>
  <option value="Venezuela">Venezuela</option>
  <option value="Viet Nam">Viet Nam</option>
  <option value="Virgin Islands, British">Virgin Islands, British</option>
  <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
  <option value="Wallis and Futuna">Wallis and Futuna</option>
  <option value="Western Sahara">Western Sahara</option>
  <option value="Yemen">Yemen</option>
  <option value="Zambia">Zambia</option>
  <option value="Zimbabwe">Zimbabwe</option>
                            </select><br><br>
                </div>
                <div class="form-group col-lg-6">
                  <label for="name">Main Setting</label><br>
                        <label class="custom-switch">
                          <input type="checkbox" name="site_param_on" class="custom-switch-input" checked>                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Site Parameter</span>
                          <br>
                       
                          <label class="custom-switch">
                          <input type="checkbox" name="site_pass_on" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Site Password</span>
                          <br>

                          <label class="custom-switch">
                          <input type="checkbox" name="send_login" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Send Login</span>
                          <br>
                          <br>
                           <label for="name">Feature</label><br>
                           <label class="custom-switch">
                          <input type="checkbox" name="get_email" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Get Email Account</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="get_photo" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Get Photo/Selfie</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="get_bank" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Get Bank Account</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="double_cc" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Double Credit Card</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="onetime" class="custom-switch-input" checked>                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Onetime Access</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="lock_platform" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Lock Platform</span>
                          <br>
                          <br>
                           <label for="name">Blocker</label><br>
                           <label class="custom-switch">
                          <input type="checkbox" name="block_host" class="custom-switch-input" checked>                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Block Hostname</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="block_ua" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Block User Agent</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="block_iprange" class="custom-switch-input" checked>                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Block IP Range</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="block_isp" class="custom-switch-input">                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Block ISP</span>
                          <br>
                          <label class="custom-switch">
                          <input type="checkbox" name="block_vpn" class="custom-switch-input" checked>                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description" style="position: absolute;">&nbsp;&nbsp; Block VPN/Proxy</span>
                          <br>
                  
                </div>

                
                      

                <button type="submit" class="btn btn-primary btn-block text-uppercase">SAVE SETTING</button>
              
                        </form>
                    </div>
                </div>
            </div>
        </div><footer class="tm-footer row tm-mt-small">
            <div class="col-12 font-weight-light">
                <p class="text-center text-white mb-0 px-4 small">
                    Copyright &copy; 16Shop <b>2019</b> All rights reserved. 
                </p>
            </div>
        </footer>    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <!-- https://jquery.com/download/ -->
    <script src="js/moment.min.js"></script>
    <!-- https://momentjs.com/ -->
    <script src="js/Chart.min.js"></script>
    <!-- http://www.chartjs.org/docs/latest/ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- https://getbootstrap.com/ -->
    <script src="js/tooplate-scripts.js"></script>
    
</body>

</html>