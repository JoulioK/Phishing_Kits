<?php
date_default_timezone_set('Asia/Jakarta');

$_SERVER['REMOTE_ADDR'] = str_replace(['localhost', '::1'], '127.0.0.1', $_SERVER['REMOTE_ADDR']);

require 'config.php';
require 'functions.php';

if($blocker) {
    require 'blocker.php';
}

