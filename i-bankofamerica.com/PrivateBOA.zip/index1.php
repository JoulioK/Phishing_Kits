<?php
/*
* index.php
*/
require_once 'hostname_check.php'; // Check if hostname contain blocked word



$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="home";

header("location: $Logon");


?>
