<style>
.sidebarMain{    
font-family: "Verdana","Arial","Helvetica","Sans Serif";
    font-size: 1.25em;
    float: left;
    clear: both;
    color: #666;
    line-height: 150%;
	padding:10px;
}
</style>
<div class="right-info ftb">
<div class="help-centre">
<ul class="help-centre">
<li>
<h2>What we're doing to protect your account</h2>
</li>
<li>
<p class="sidebarMain">
When you use our Online Banking or Mobile Banking services, you&apos;re automatically protected 
by our Online and Mobile Banking Guarantee. This means we&apos;re always checking for any suspicious activity on your account
 and will automatically disable your access to Online Banking typical examples of why this may occur are: multiple failed login attempts, unusual account activity, login&apos;s from an unrecognised device or it may have been caused has we hold inaccurate personal and/or account information.
</p>
</li>
</ul>
</div>
<div class="right-info-snippet">
<div class="module-holder">
<div class="module-header">
<h2></h2>
</div>
<div class="module-content">
<div id="fscs-banner-snippet" class="snippet">
<div target="_blank"<p> <img src="assets/img/FSCS.jpg" height="46" width="228"></p></div>
</div>
</div>
<div class="module-footer">
<span></span>
</div>
</div>
</div>
</div>