define({
    root : {
        "NoDataForFilter" : "No transactions match those amounts. Please enter a different range.",
        "NoDataForSerarch" : "No transactions matching your search are available."
    },
        "es-ar": true,
        "ar-sa" : true,
    "hi-in":true,
    "ar-ae" : true,
    "zh-hk" : true,
    "zh-cn" : true
});
