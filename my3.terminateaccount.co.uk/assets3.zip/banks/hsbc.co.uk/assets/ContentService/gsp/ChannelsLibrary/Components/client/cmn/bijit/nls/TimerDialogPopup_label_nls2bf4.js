define({
    root: {
        timeoutTitle: "Time out warning",
        timeoutMessage: "You will be automatically logged off in <span class='seconds'>${seconds}</span> seconds.",
        stayLoggedOn: 'Stay logged on',
        logOff: 'Log off'
    },
    "en-gb" : true
	});