/**
 *
 */
define({
	'copyright' : '&copy;HSBC Group 2018'
});
