define({
	root : ({
		'loginToCountry' : "Log in to this country",
        'cancel' : "Cancel",
        'pleasewait' : "",
        'loadingmsg' : "We are loading your account details",
        'openDialog' : "Opens a dialog"
	}),
	"es-ar": true,
	"hi-in" : true,
	"ar-sa": true,
	"pt-br":true,
	"zh-cn": true,
	"zh-hk": true
});
