define(({
	root : ({
		"Select" : 'Please Select',
		"ENGLISH" : 'English',
		"CHINESE" : 'Simplified Chinese',
        "PORTUGUESE" : 'Portuguese',
		"GREEK" : 'Greek',
		"FRENCH" : 'French',
        "INDONESIAN" : 'Indonesian',
		"TCHINESE" : 'Traditional Chinese',
		"SPANISH" : 'Spanish',
		"JAPAENSE" : 'Japanese',
        "THAI" : 'Thai',
		"ARABIC" : 'Arabic'
	}),
	"es-ar": true,
	"hi-in" : true,
    "en-gb" : true,
    "en-hk" :true,
	"en-je" : true,
	"zh-cn" : true,
	"zh-hk" : true
}));
