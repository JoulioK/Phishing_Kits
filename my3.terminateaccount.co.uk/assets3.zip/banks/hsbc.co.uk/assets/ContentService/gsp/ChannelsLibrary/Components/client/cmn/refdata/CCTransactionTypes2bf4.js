/* Global Reference Data representing Transaction Types */
/* DD ID: */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
	"CreditCardTransactionTypes" : [ {
		"id" : 'U',
		"desckey" : 'Unbilled'
	}, {
		"id" : 'L',
		"desckey" : 'Billed'
	} ]
}));
