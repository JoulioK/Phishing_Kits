define({
    root: {
        accessibility: {
            dateFormat: "format : D D / M M / Y Y Y Y"
        },
        dateTextBoxErrorMsg: "Please select a date.",
        dateTextBoxMissingMsg:"Please select a date.",
        dateTextBoxRangegMsg:"Please select a date."
    },
	"zh-cn": true,
	"zh-hk": true,
	"en-gb": true,
	"en-hk": true,
    "es-ar":true
});