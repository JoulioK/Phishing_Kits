define({
	root : ({
		"sameEntityMessage" : "Further information on this investment can be viewed in My portfolio.",
		"crossEntityMessage" : "To view and manage accounts in ${countryName}, you must log on to ${countryName} online banking.",
		"message1" : "Non_GSP product",
		"message2" : "Non_GSP entity",
		"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
		"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
		"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt.",
		"login" : "Log in to this country ",
		"portfolio" : "My portfolio",
		"open" : "Opens in a new window",
		"balance" : "Balance",
		"currency" : "Currency",
		"penBalance" : "Valuation",
		"insBalance" : "Cover",
		"penBalanceMsg" : "Valuation as at",
		"insBalanceMsg" : "Cover as at",
		"balanceMsg" : "Balance as at ",
		"tooTipMsgBal" : "This field displays the balance available in account. It may be subject to change.",
		"toolTipMsgCurr" : "This is the currency in which your account is held.",
		"toolTipMsgPrdDesc" : "This is the type of account you hold",
		"toolTipMsgLstUpdtTime" : "This field displays when the balance was updated last time.",
		"balNtAvlbl" : "Balance not available",
		"titleMsg" : "You are now leaving the Global Site",
		"msgText" : "In order to view this information you will be taken out of this site and transferred to one of our partner websites",
		"proceed" : "Proceed",
		"cancel" : "Cancel",
		"buttonClose" : "Close",
		"CC" : {
			"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=creditcardview",
			"isSensitiveData" : true,
			"iscustSeg" : true,
			"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
			"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
			"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
		},

		"OTHER" : {
			"IVD" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=hssview",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			},
			"IVI" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=hssview",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			},
			"IVM" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=hssview",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			},
			"IVP" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/redirect-to-legacy-online-banking?functionName=hssview",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			},
			"RA0" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/global-investment-warning",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			}
		},
		"INV" : {
			"RB0" : {
				"linkAndLaunchUrl" : "{LEGACY_URL1}/1/3/personal/online-banking/global-investment-warning",
				"isSensitiveData" : "false",
				"iscustSeg" : "false",
				"openType" : "_blank",
				"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
				"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
				"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
			}
		},
		"INS" : {
			"linkAndLaunchUrl" : "#",
			"isSensitiveData" : "false",
			"iscustSeg" : "false",
			"nonGSPTxnMessageOne" : "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.",
			"nonGSPTxnMessageTwo" : " Nemo enim ipsam voluptatem qui voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt",
			"nonGSPTxnMessageThree" : "Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt."
		}
	}),
	"zh-hk" : true,
	"zh-cn" : true,
	"es-ar" : true,
	"en-je" : true,
	"ar-sa" : true,
	"hi-in" : true,
	"ar-ae" : true,
	"en-gb" : true,
	"en-hk" : true
});
