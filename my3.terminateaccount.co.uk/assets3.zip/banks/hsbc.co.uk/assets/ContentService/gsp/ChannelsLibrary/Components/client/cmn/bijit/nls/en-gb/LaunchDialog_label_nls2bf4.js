/**
 *
 */
define({
	'proceedWarningTitle' : '',
	'proceedWarningContent' : "Selecting Proceed will open a website in a new window, outside of the HSBC secure environment. Your Online Banking session will remain open in the background. <br><br>Take care not to leave your device unattended, and remember to log off when you have finished. If you don't return to Online Banking within 10 minutes you will be logged off automatically.",
	'acceptAndProceed' : 'Accept and proceed',
	'cancel' : 'Cancel',
	'proceedWarningContentMCAB' : "Book or manage appointment<br><br>Selecting 'Accept and proceed' will launch a new browser window where you can book or manage your appointment. Your online banking pages will remain open in the background. If you don't return to Online Banking within 10 minutes you will be logged out for security. Just log on again if you need to."
});
