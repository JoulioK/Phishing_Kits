/* Global Reference Data representing payee charges List */
/* DD ID: 00072 */
/* id=<value pass into BE>, desckey=<key to resolve NLS string> */
define(({
    "EcaCurrencyList": [
        {
            "id": "AED",
            "desckey": "AED",
            "defaultKey": "N"
        },
        {
            "id": "ALL",
            "desckey": "ALL",
            "defaultKey": "N"
        },
        {
            "id": "AMD",
            "desckey": "AMD",
            "defaultKey": "N"
        },
        {
            "id": "AUD",
            "desckey": "AUD",
            "defaultKey": "N"
        },
        {
            "id": "BBD",
            "desckey": "BBD",
            "defaultKey": "N"
        },
        {
            "id": "BDT",
            "desckey": "BDT",
            "defaultKey": "N"
        },
        {
            "id": "BGN",
            "desckey": "BGN",
            "defaultKey": "N"
        },
        {
            "id": "BHD",
            "desckey": "BHD",
            "defaultKey": "N"
        },
        {
            "id": "BMD",
            "desckey": "BMD",
            "defaultKey": "N"
        },
        {
            "id": "BND",
            "desckey": "BND",
            "defaultKey": "N"
        },
        {
            "id": "BSD",
            "desckey": "BSD",
            "defaultKey": "N"
        },
        {
            "id": "CAD",
            "desckey": "CAD",
            "defaultKey": "N"
        },
        {
            "id": "CHF",
            "desckey": "CHF",
            "defaultKey": "N"
        },
        {
            "id": "CZK",
            "desckey": "CZK",
            "defaultKey": "N"
        },
        {
            "id": "DKK",
            "desckey": "DKK",
            "defaultKey": "N"
        },
        {
            "id": "DZD",
            "desckey": "DZD",
            "defaultKey": "N"
        },
        {
            "id": "EGP",
            "desckey": "EGP",
            "defaultKey": "N"
        },
        
        {
            "id": "EUR",
            "desckey": "EUR",
            "defaultKey": "N"
        },
        {
            "id": "FJD",
            "desckey": "FJD",
            "defaultKey": "N"
        },
        {
            "id": "GBP",
            "desckey": "GBP",
            "defaultKey": "N"
        },
        {
            "id": "GHS",
            "desckey": "GHS",
            "defaultKey": "N"
        },
        {
            "id": "HKD",
            "desckey": "HKD",
            "defaultKey": "N"
        },
        {
            "id": "HRK",
            "desckey": "HRK",
            "defaultKey": "N"
        },
        {
            "id": "HUF",
            "desckey": "HUF",
            "defaultKey": "N"
        },
        {
            "id": "ILS",
            "desckey": "ILS",
            "defaultKey": "N"
        },
        {
            "id": "INR",
            "desckey": "INR",
            "defaultKey": "N"
        },
        {
            "id": "JMD",
            "desckey": "JMD",
            "defaultKey": "N"
        },
        {
            "id": "JOD",
            "desckey": "JOD",
            "defaultKey": "N"
        },
        {
            "id": "JPY",
            "desckey": "JPY",
            "defaultKey": "N"
        },
        {
            "id": "KWD",
            "desckey": "KWD",
            "defaultKey": "N"
        },
        {
            "id": "LKR",
            "desckey": "LKR",
            "defaultKey": "N"
        },
        {
            "id": "MAD",
            "desckey": "MAD",
            "defaultKey": "N"
        },
        {
            "id": "MOP",
            "desckey": "MOP",
            "defaultKey": "N"
        },
        {
            "id": "MWK",
            "desckey": "MWK",
            "defaultKey": "N"
        },
        {
            "id": "MXN",
            "desckey": "MXN",
            "defaultKey": "N"
        },
        {
            "id": "NAD",
            "desckey": "NAD",
            "defaultKey": "N"
        },
        {
            "id": "NOK",
            "desckey": "NOK",
            "defaultKey": "N"
        },
        {
            "id": "NZD",
            "desckey": "NZD",
            "defaultKey": "N"
        },
        {
            "id": "OMR",
            "desckey": "OMR",
            "defaultKey": "N"
        },
        {
            "id": "PHP",
            "desckey": "PHP",
            "defaultKey": "N"
        },
        {
            "id": "PKR",
            "desckey": "PKR",
            "defaultKey": "N"
        },
        {
            "id": "PLN",
            "desckey": "PLN",
            "defaultKey": "N"
        },
        {
            "id": "QAR",
            "desckey": "QAR",
            "defaultKey": "N"
        },
        {
            "id": "RON",
            "desckey": "RON",
            "defaultKey": "N"
        },
        {
            "id": "RSD",
            "desckey": "RSD",
            "defaultKey": "N"
        },
        {
            "id": "RUB",
            "desckey": "RUB",
            "defaultKey": "N"
        },
        {
            "id": "SAR",
            "desckey": "SAR",
            "defaultKey": "N"
        },
        {
            "id": "SEK",
            "desckey": "SEK",
            "defaultKey": "N"
        },
        {
            "id": "SGD",
            "desckey": "SGD",
            "defaultKey": "N"
        },
        {
            "id": "SZL",
            "desckey": "SZL",
            "defaultKey": "N"
        },
        {
            "id": "THB",
            "desckey": "THB",
            "defaultKey": "N"
        },
        {
            "id": "TND",
            "desckey": "TND",
            "defaultKey": "N"
        },
        {
            "id": "TRY",
            "desckey": "TRY",
            "defaultKey": "N"
        },
        {
            "id": "TTD",
            "desckey": "TTD",
            "defaultKey": "N"
        },
        {
            "id": "USD",
            "desckey": "USD",
            "defaultKey": "N"
        },
        {
            "id": "UYU",
            "desckey": "UYU",
            "defaultKey": "N"
        },
        {
            "id": "XAF",
            "desckey": "XAF",
            "defaultKey": "N"
        },
        {
            "id": "XCD",
            "desckey": "XCD",
            "defaultKey": "N"
        },
        {
            "id": "XOF",
            "desckey": "XOF",
            "defaultKey": "N"
        },
        {
            "id": "ZAR",
            "desckey": "ZAR",
            "defaultKey": "N"
        }
    ]
}));