_satellite.pushAsyncScript(function(event, target, $variables){
  function getCookie (name,value) {
    var found = false;
    var cookies = document.cookie.split(";");
    for (var i = 0,ilen = cookies.length;i<ilen;i++) {
         var cookie = cookies[i].split("=");
         if(name == cookie[0].trim() && (!value || value == cookie[1].trim())) {
              return found=true;
         }
     }
     return found;
};
var name = "_fsspl_"
var value = "a"
if (getCookie("_fsspl_")) {document.cookie = name + "=" + value + ";domain=.three.co.uk;path=/";}
});
