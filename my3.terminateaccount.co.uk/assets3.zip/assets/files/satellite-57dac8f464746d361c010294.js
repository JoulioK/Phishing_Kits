_satellite.pushAsyncScript(function(event, target, $variables){
  $(".notification-banner").css({"width": "80%", "height":"auto", "padding":"0px","margin-bottom": "30px", "margin-left":"auto", "margin-right": "auto", "font-size":"16px"});
$(".notification-banner ul").css({"padding":"20px","list-style": "none","margin-left":"0"});
$(".notification-banner ul li.icon-bell.pad-top1.has-link::before").css({"font-size":"2.5rem", "margin-top":"-10px"});
$(".notification-banner ul li.icon-bell.pad-top1 p").css({"padding-top":"0.5rem"});
$(".bullet-icons LI").css({"font-size":"16px"});
$(".clearBoth").css({ "clear": "both"});

if (window.matchMedia("(min-width: 270px) and (max-width: 670px)").matches)
{
   $(".notification-banner").css({"width": "80%"});
}
});
