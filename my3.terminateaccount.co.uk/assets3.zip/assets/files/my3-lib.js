/* Global vars for the image carousel
//	You can specify the speed & image pixel width and height of each item (big and small) using the variables below:
*/
var bigWidth = '140';
var bigHeight = '290';
var smallWidth = '63';
var smallHeight = '130';
var theSpeed = 300;	

var toggleCookieName = 'my3ToggleCookies';
/*** EDB starts********/

if (undefined == globalConfigHandler){
	var globalConfigHandler={
			prevUrl:null,
			canRender:function(curUrl){
				return (curUrl != globalConfigHandler.prevUrl);
			},
			renderPage:function(placeholder,url){
				if(globalConfigHandler.canRender(url)){
					 globalConfigHandler.prevUrl=url;
					 $('html, body').animate({ scrollTop: 0 }, 0);
					 $("#ajaxWait").css("display","block");
				getContent(url,function(data){
					$("#ajaxWait").css("display","none");
				  $("#" + placeholder).html(data);		
					});
				}
			}
	};
}

function printLog(logValue){
	  try{
	  console.log(logValue);
	  }catch(err) {
	  }
	}

/*function retreiveSessionStorage(key){
	if(typeof(Storage)!=="undefined"){
	  if (sessionStorage.getItem(key)) {
		  return JSON.parse((sessionStorage.getItem(key)));
	  }else{
		  return null;
	  }
	}
}	

function storeinSessionStorage(key, value){
	if(typeof(Storage)!=="undefined"){
		sessionStorage.setItem(key,JSON.stringify(value));
	}
}*/

//Changed for App

function retreiveSessionStorage(key){
	/*if(my3App)
	{
	 if (requestTempData(key)) {
		  return JSON.parse((sessionStorage.getItem(key)));
	  }else{
		  return null;
	  }
	}
	else*/
	if(typeof(Storage)!=="undefined"){
	  if (sessionStorage.getItem(key)) {
		  return JSON.parse((sessionStorage.getItem(key)));
	  }else{
		  return null;
	  }
	}
}	

function storeinSessionStorage(key, value){
	/*if(my3App)
	{
		storeTempData(key,value,-1,true);
	}
	else*/
	if(typeof(Storage)!=="undefined"){
		sessionStorage.setItem(key,JSON.stringify(value));
	}
}


function JsonHelper(obj) {
    this.obj = obj;
    this.extract = function (keyname) {
printLog("keyname: "+keyname);
        var keyList = keyname.split(".");
        var resultkeyName = keyList[keyList.length - 1];
        var jsonObj = {};
        var curObj = this.obj;
        $.each(keyList, function (index, value) {
            if (index != keyList.length - 1) {
                    printLog( value + "--" + index  + "---" + (keyList.length-1) )
                curObj = curObj[value];
            }
        });

        $.each(curObj, function (k, v) {
            printLog( k  + "****" +resultkeyName )
            if (k == resultkeyName) {
                jsonObj[resultkeyName] = v;

            }
        });
		printLog(jsonObj);
        return jsonObj;
    };
}

function getContent(pageUrl,callBack){
	$.ajax({
    dataType: "HTML",
	type: "GET",
	contentType: "application/html; charset=utf-8",
	url: pageUrl,
	success: function(data) {        
		 return callBack(data);		 
    }, 
	error: function(){
		printLog("401 - your session expired , click ok to relogin"); location.reload(true);
	}
	});
 }

function processHiddenDiv(){
	var $myDiv = $('#HiddenContainer');
	var $myDiv2 = $('#dummyHiddenContainer');
	var hiddendiv='<div id="HiddenContainer"></div>';
    if ( $myDiv.length){
    	printLog("if");
		if ( $myDiv2.length){
			printLog("if2");
	    	$( "#HiddenContainer" ).html($("#dummyHiddenContainer" ).html());
	    	$("#dummyHiddenContainer" ).remove();
		}
		printLog("Hidden"+$("#HiddenContainer").html());
    }else{
    	printLog("else");
    	$(hiddendiv).insertBefore($("#dummyHiddenContainer"));
		$("#HiddenContainer" ).html($("#dummyHiddenContainer" ).html());
		$("#dummyHiddenContainer" ).remove();
		printLog("Hidden"+$("#HiddenContainer").html());
    }
}

function createShowLoadingDiv(){
	var $myDiv = $('#ajaxWait');
	var loadingDiv="<div id='ajaxWait' class='my3ajaxLoadingFullPage' style='display:none'><div class='my3ajaxLoadingFullPageInner'><p><span>Please wait...</span></p><p class=''><img src='/static/images/my3/icons/Loading-2-1.gif' width='' height='' /></p><p>Do not refresh the page.<br />Your request is being processed.</p></div></div>";
	if ( $myDiv.length){
	}else{
		$(loadingDiv).insertBefore($("#dummyHiddenContainer"));	
	}
}
	
 //Chrome DoughNut fix
 (function( $ ) {
	 
	// First, check to see if cssHooks are supported
	if ( !$.cssHooks ) {
	  // If not, output an error message
	  throw( new Error( "jQuery 1.4.3 or above is required for this plugin to work" ) );
	}
	 
	// Wrap in a document ready call, because jQuery writes
	// cssHooks at this time and will blow away your functions
	// if they exist.
	$(function () {
	  $.cssHooks[ "transform" ] = {
	    get: function( elem, computed, extra ) {
	      // Handle getting the CSS property
		   return $.css( elem, "transform" );
	    },
	    set: function( elem, value ) {
		
	      // Handle setting the CSS value
		  elem.style[ "transform" ] = value;
		  elem.style[ "-ms-transform" ] = value;
		  elem.style[ "-webkit-transform" ] = value;
		  printLog("elem: "+elem);
	    }
	  };
	});
	 
	})( jQuery );
 
 
 var ScriptInjector={
			curScriptPos:0,
			totalScripts:0,
			scripts:new Array(),
			callback:null,
			
			startInjecting:function(appScripts,appcallback){
				//
				if(ScriptInjector.curScriptPos != 0){
					alert("Another Script Injection in process")
					return
				}
				ScriptInjector.scripts=appScripts
				ScriptInjector.callback=appcallback			
				ScriptInjector.curScriptPos=0;
				ScriptInjector.injectNextScript()

			},
			injectNextScript:function(){

			if(ScriptInjector.curScriptPos >= ScriptInjector.scripts.length){
				ScriptInjector.onCompleteInjection()
				return
				}
			
			includeJavascript(ScriptInjector.scripts[ScriptInjector.curScriptPos],function(){
				ScriptInjector.curScriptPos++
				ScriptInjector.injectNextScript();
			});

			},
			onCompleteInjection:function(){
				console.log("Completed All injections")
				if(null != ScriptInjector.callback)
					ScriptInjector.callback()
					
				ScriptInjector.curScriptPos=0;	
			}

		};

 function loadCSS(href) {
	    var head_node = document.getElementsByTagName('head')[0];
	    var link_tag = document.createElement('link');
	    link_tag.setAttribute('rel', 'stylesheet');
	    link_tag.setAttribute('type', 'text/css');
	    link_tag.setAttribute('href', href);
	    head_node.appendChild(link_tag);
	}


	function unloadCSS(file) {
	  var cssNode = document.getElementById(file);
	  cssNode && cssNode.parentNode.removeChild(cssNode);
	}

	function includeJavascript(src,callback) {
	    
		ScriptLoader.load(src, callback);
	}

	var ScriptLoader = {
	  load: function(src, callback) {
	    var script = document.createElement('script'),
	        loaded;
	    script.setAttribute('src', src);
	    if (callback) {
	      script.onreadystatechange = script.onload = function() {
	        if (!loaded) {
	          callback();
	        }
	        loaded = true;
	      };
	    }
	    document.getElementsByTagName('head')[0].appendChild(script);
	  }
	};


/*** EDB Ends********/


	
$(document).ready(function() {	

	//GLOBAL FUNCTION FOR POSITIVE BUTTONS
	$( function(){
	$('.global').hover( function(){
		$('.buttonInner14', this).css({'background-color' : '#000000', 'color' : '#ffffff', 'background-position' : 'right 0px'});
	},
    function(){

		$('.buttonInner14', this).css({'background-color' : '#c8de00', 'color' : '#000000', 'background-position' : 'right center'});
	 });
});

	//GLOBAL FUNCTION FOR NEGATIVE BUTTONS
	$( function(){
	$('.globalNegative').hover( function(){
		$('.buttonInner14negative', this).css({'background-color' : '#000000', 'color' : '#ffffff', 'background-position' : 'right 0px'});
	},
    function(){

		$('.buttonInner14negative', this).css({'background-color' : '#595758', 'color' : '#ffffff', 'background-position' : 'right bottom'});
	 });
});


			//GLOBAL FUNCTION FOR POSITIVE BUTTONS ORANGE AUTH CONTACT
	$( function(){
	$('.globalNegative').hover( function(){
		$('.buttonInner14Orange', this).css({'background-color' : '#000000', 'color' : '#ffffff', 'background-position' : 'right 0px'});
	},
    function(){

		$('.buttonInner14Orange', this).css({'background-color' : '#ffd001', 'color' : '#000000', 'background-position' : 'right bottom'});
	 });
});
	
	
	
	
	
	
	/*** Start of 20130819 My3 Tooltip Changes Part 1 - SKanza ***/
	my3.my3Tooltips();
	/*** End of 20130819 My3 Tooltip Changes Part 1 - SKanza ***/
	my3.toolTips();
	my3.tableSort();
	my3.floatHover();
	my3.vAlign();
	my3.buttonHover();
	my3.viewLightBox();
	/* ***RE-brand*** my3.checkCookies(); */
});



var slidervalue = 0;
var stepWidth = 0;
var itemsLength = 0;
var currentStep = 0;
var togglePortletheight = '61px';

	
var my3 = {

		tooltipTimeoutHandler: 0,
    
  	/*** START 2014 ANALYTICS TRACKING ***/

omniturePageTrack:function (portletStepTrack){
            s.prop51=s.pageName +":"+portletStepTrack;
             s.t();
},




/*** END 2014 ANALYTICS TRACKING ***/
	
		vAlign: function(){
			/* 	This function listens for clicks (A, BUTTON, IMG, TR). Clicks INSIDE the portlet container (with class threePortlet), will then result in a cookie being set (name: portlet)
				On page load this function will try and collect the 'portlet' cookie and find a element with a class name equal to the cookie value... it will then scroll the page to that element.
				If you need to disable the cookie from being set, you must add the class 'noCookie' to the clickable element - this could be usefull when moving between portlets for example:
				
				<a href="javascript:void(0)" class="noCookie" onclick="$.cookie('portlet', 'P25_id', { expires: 1, path: '/'});">PortletClick</a>
				
				This would disable the click listener from setting the cookie, instead setting the cookie via the onclick event.
				
				For this function to work correctly, the portlet naming convention needs to be followed... each portlet must have a div container with the class 'threePortlet', two other classes
				should then be added 'P25_id', then P25_SetMyDevice_1 would represent the first JSP in the P25 folder.
			*/

			// Fix My3 enhancements defect ROIMYTHREE-48
            var pl037 = document.getElementById('PL037');
            var elem = document.createElement("div");
            elem.setAttribute('class', 'clear');
            if (pl037) {
                pl037.appendChild(elem);
            }

			// Click listener - element is clicked
			$('.threePortlet a:not(.noCookie), .threePortlet button:not(.noCookie), .threePortlet img:not(.noCookie), .threePortlet tr:not(.noCookie)').click(function () {
				// find the first parent element with the class 'threePortlet' and store it's class names
				var portletName = $(this).parents(".threePortlet").attr("class");
				// remove the class 'threePortlet' from the list of class names
				portletName = portletName.replace("threePortlet ", "");
				// Explode the string at the '_' - provides the P number
				var portletParts = portletName.split("_");
				// Rebuild the actual class name required
				portletName = portletParts[0] + "_id";
				// Store the class name in the cookie
				//$.cookie('portlet', portletName, { expires: 1, path: '/'});
                my3.createCookie('portlet', portletName, 1);
			});
		   
		   	// collect portlet cookie
			//var portlet = $.cookie('portlet');
            var portlet = my3.readCookie('portlet');

			if (portlet != '' && portlet != null) {
				// Go to top left of the element with the class name stored in the cookie
				var portletEle = $("." + portlet );
				var offset = portletEle.offset();
                try{
                    if (offset != null && typeof(offset) != "undefined"){
                        if(offset.top==null) offset.top = 0;
                        var scollItTo = offset.top;
                        $.scrollTo(scollItTo);
                        // Kill the cookie
                        $.cookie('portlet', null, { path: '/'});
                    }
                }catch(err){console.log(err)};
			};
		
		},

		/*** Start of 20130819 My3 Tooltip Changes Part 3 - SKanza ***/
		my3Tooltips: function(){
			$('.my3TooltipBox').hide();

			$('.P12_ViewMyPreviousBills_w1 .info,.P12_ViewMyPreviousBills_w2 .info').each(function(){
				var my3Html = '<div style="display:none;" class="infoPop popOver" data-tracking="Bills:' + $(this).find('.my3TooltipLink').attr('href').replace('#my3Tooltip','')+ '">' +
                				'<div class="shadowTop shadow"></div>' +
                				'<div class="middle">' +
                    			'<div class="shadowLeftTop shadow"></div>' +
                    			'<div class="shadowLeft shadow"></div>' +
                    			'<div class="shadowLeftBottom shadow"></div>' +
                    			'<div class="p">' + $($(this).find('.my3TooltipLink').attr('href')).children('.my3TooltipMain').html() + '</div>' + 
		                        '<div class="shadowRightTop shadow"></div>' +
		                        '<div class="shadowRight shadow"></div>' +
		                        '<div class="shadowRightBottom shadow"></div>' +
		                    '</div><div class="shadowBottom shadow"></div></div>';

            	$(this).children('.my3TooltipLink').after(my3Html);
			});

			$('.no-touch .P12_ViewMyPreviousBills_w1 .my3TooltipLink, .no-touch .P12_ViewMyPreviousBills_w2 .my3TooltipLink').bind('mouseenter', function(){
				$(this).addClass('my3TooltipHover');
				var infoPop = $(this).siblings('.infoPop')
	            infoPop.show();
	            clearTimeout(my3.tooltipTimeoutHandler);
	            my3.tooltipTimeoutHandler = setTimeout(function(){trackTooltip(infoPop,true)}, 3000);
	        });

	        $('.no-touch .P12_ViewMyPreviousBills_w1 .my3TooltipLink, .no-touch .P12_ViewMyPreviousBills_w2 .my3TooltipLink').bind('mouseleave', function(){
	        	clearTimeout(my3.tooltipTimeoutHandler);
	        	$(this).removeClass('my3TooltipHover');
	            $(this).siblings('.infoPop').fadeOut();
	        });

	        $('.no-touch .P12_ViewMyPreviousBills_w1 .my3TooltipLink, .no-touch .P12_ViewMyPreviousBills_w2 .my3TooltipLink').bind('click', function(){
	        	e.preventDefault();
	        });

	        $('.touch .P12_ViewMyPreviousBills_w1 .my3TooltipLink, .touch .P12_ViewMyPreviousBills_w2 .my3TooltipLink').click(function(e){
	        	e.preventDefault();
	        	$(this).addClass('my3TooltipHover');
	            var infoPop = $(this).siblings('.infoPop');
	            if(infoPop.css('display') === 'none'){
	            	infoPop.show();
	            	trackTooltip(infoPop,false);
	            }else{
	            	$(this).removeClass('my3TooltipHover');
	            	infoPop.fadeOut();
	            }
	        });

			var trackTooltip = function(tooltip,hover){
		    	s.linkTrackVars='none';
		    	s.linkType='custom';
		    	s.linkName=$(tooltip).attr('data-tracking');
				s.tl(tooltip,'o',$(tooltip).attr('data-tracking'));
    		};
		},
		/*** End of 20130819 My3 Tooltip Changes Part 3 - SKanza ***/
		
		buttonHover: function(){
			// This function enables hover states on buttons elements in ie6			
			$("button.plet-frm-btn-green-69, button.plet-frm-btn-green-100, button.plet-frm-btn-green-135, button.plet-frm-btn-green-150").hover(
				function(){ $(this).css("background-position", "right -80px"); },
				function(){ $(this).css("background-position", "right 0px"); }
			)
			$("button.plet-frm-btn-grey-69, button.plet-frm-btn-grey-100, button.plet-frm-btn-grey-135").hover(
				function(){ $(this).css("background-position", "right -140px"); },
				function(){ $(this).css("background-position", "right -20px"); }
			)
		},
	
		toolTips: function(){
			// Declare the Elements class/id to activate the listener. In this case the class 'button_tooltip'
			// Plus options passed to the function to position the tooltip box and exclude URL visibility
			$('.button_tooltip').tooltip({top:-8,showURL: false});
			// the next line should be removed once drop 1 has been updated
			$('.tools').tooltip({top:-8,showURL: false});
		},
	
		floatHover: function(){
			// Hover function for IT5 add-ons and IT14 alerts
			$('.boxContainer .floatBox:not(.noclick)').hover(
				function() { $(this).addClass('hoverBox'); },
				function() { $(this).removeClass('hoverBox');
			});
		},
	
		tableSort: function(){
			
			$('.threePortlet table tr[class=hoverthis]').hover(
				function() { $(this).addClass('ieHover'); },
				function() { $(this).removeClass('ieHover');
			});
			
			$(".threePortlet .calls:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					null,
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .messages:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .content:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .data:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .searchMain:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ], [1,'asc']],
				"aoColumns": [
					{ "sType": "uk_date" },
					{ "sType": "uk_date" },
					null,
					null,
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .searchMSP:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .searchDL:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .searchData:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					null,
					{ "sType": "currency" }
				],
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});

			$(".threePortlet .billsAlt:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ bSortable: false },
					{ bSortable: false }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": false,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .stchargeDetails:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": true,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .tchargeDetails:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .stExtraCol:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ bSortable: false },
					{ "sType": "natural" },
					{ bSortable: false }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": true,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .tExtraCol:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ bSortable: false },
					{ "sType": "natural" },
					{ bSortable: false }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": false,
				"bAutoWidth": false
			});
			
			$(".threePortlet .stNoExtraCol:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ bSortable: false },
					{ bSortable: false }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": true,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .tNoExtraCol:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					null,
					{ "sType": "currency" },
					{ "sType": "currency" },
					{ bSortable: false },
					{ bSortable: false }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .stpaymentDetails:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					{ "sType": "currency" }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": true,
				"bInfo": true,
				"bAutoWidth": false
			});
			
			$(".threePortlet .tpaymentDetails:not(.sortDis)").dataTable({
				"aaSorting": [[0, "desc" ]],
				"iDisplayLength": 20,
				"aoColumns": [
					{ "sType": "uk_date" },
					null,
					{ "sType": "currency" }
				],
				"sPaginationType": "full_numbers",
				"bPaginate": true,
				"bLengthChange": false,
				"bFilter": false,
				"bInfo": true,
				"bAutoWidth": false
			});
		
		},
		
		trim: function(str) {
			// Trims whitespace from a given string
			str = str.replace(/(^\s+|\s+$)/, '');
			str = str.replace('(Draft)', '');
			for (var i = str.length - 1; i >= 0; i--) {
				if (/\S/.test(str.charAt(i))) {
					str = str.substring(0, i + 1);
					break;
				}
			}
			return str;
		},
	
		alertsValue: function(valueID){			
			//valueID = getElementById(valueID);
			
			$("#alertToRemove").val(valueID);
			$("#alertToRemoveText").text(valueID);
			
			$.fn.colorbox({width:"300px", height:"200px", iframe:false, inline:true, href:"#alertsConfirm", overlayClose: false})
			
		},

		//ColorBox FDP 2013 Nov
		cboxLoader: function (w, h) {
			$('.colorbox2').colorbox({
				width: w,
				height: h,
				iframe: true,
				inline: false,
				overlayClose: false,
				onLoad: function () {
					$("#colorbox").css("display", "");
					$("#colorbox2").addClass("threePortlet");
				}
			});
		},
		
		viewLightBox: function(){			
			// Calls the colorbox lightbox - this is listening for clicks on a link with the class "colorBox", then will collect the href value for inserting into the iframe.
			$('.colorBox').colorbox({
				width:"532px",
				height:"580px",
				iframe:true,
				inline:false,
				overlayClose: false,
				onLoad: function(){
					$("#colorbox").addClass("threePortlet")		
				}
			});
			
		},
				
		viewReceipt: function(){
			// Calls the colorBox to load an inline div containing an exmaple graphic for top-up by voucher
			$.fn.colorbox({
				width:"333px",
				height:"580px",
				iframe:false,
				inline:true,
				href:"#topUpEg",
				overlayClose: false
			});
		},
		
		/*Check if obsolete \/*/
		
		createCookie: function(name,value,days) {
			// This could be obsolete
			if (days) {
				var date = new Date();
				date.setTime(date.getTime()+(days*24*60*60*1000));
				var expires = "; expires="+date.toGMTString();
			}
			else var expires = "";
			document.cookie = name+"="+value+expires+"; path=/";
		},

		readCookie: function(name) {
			// This could be obsolete
			var nameEQ = name + "=";
			var ca = document.cookie.split(';');
			for(var i=0;i < ca.length;i++) {
				var c = ca[i];
				while (c.charAt(0)==' ') c = c.substring(1,c.length);
				if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
			}
			return null;
		},

		eraseCookie: function(name) {
			// This could be obsolete
			createCookie(name,"",-1);
		},
		
		checkCookies: function(){
			// This could be obsolete
			if(my3.readCookie(toggleCookieName)){	
				var toggleCookie = my3.readCookie(toggleCookieName);
				var toggleCookieArray = toggleCookie.split(",");
				my3.compareString2Array('noString' , toggleCookieArray);
				
				
				
				for(var i=0;i<toggleCookieArray.length;i++){
					
					var theCurrentStringParts = toggleCookieArray[i].split(":");
					var theCurrentID = theCurrentStringParts[0];
					var theCurrentToggleState = theCurrentStringParts[1];	
					
					var togglestate = (theCurrentToggleState=='close')?my3.displayElements(new Array(theCurrentID), new Array('')):my3.displayElements(new Array(''), new Array(theCurrentID));
					

				}

			}
		},
		
		compareString2Array: function(theString, theArray){
			// This could be obsolete
			if(theArray){
				for(var i=0;i<theArray.length;i++){
					if(theArray[i] == theString){ return true; }
				}
			}
			return false;
			
		},
		
		setCookieString: function(string2add){
			// This could be obsolete
			my3.createCookie(toggleCookieName, 'creditOpen:close,creditClose:open,creditBody:open', 60);
			
			if(my3.readCookie(toggleCookieName)){
				// check cookie exists and if so process it
						
				var toggleCookie = my3.readCookie(toggleCookieName);
				var toggleCookieArray = toggleCookie.split(",");
				var inArray = false;
				
				for(var i=0;i<toggleCookieArray.length;i++){
					
					var theCurrentStringParts = toggleCookieArray[i].split(":");
					var theCurrentID = theCurrentStringParts[0];
					//alert(theCurrentID);
					var theCurrentToggleState = theCurrentStringParts[1];
					
					var theAddStringParts = string2add.split(":");
					var theAddID = theAddStringParts[0];
					var theAddToggleState = theAddStringParts[1];
					//alert(theAddID + '==' + theCurrentID);
					if(theAddID == theCurrentID){
						// Id is in cookie but toggle property is different
						//toggleCookieArray[toggleCookieArray.length] = string2add;						
						var togglestate = (theCurrentStringParts[1]=='close')?'open':'close';
						theCurrentStringParts[1] = togglestate;
						toggleCookieArray[i] = theCurrentStringParts.join(':');
						var newCookieString = toggleCookieArray.join(',');
						//alert(toggleCookieArray);
						my3.createCookie(toggleCookieName, newCookieString, 60);
						
						inArray = true;
						
					}
				}
				
				if(inArray == false){ toggleCookieArray[toggleCookieArray.length] = string2add; }
				
				
			}
			else{
				// no cookie exists... set the cookie
				my3.createCookie(toggleCookieName, string2add, 60);
			}
		},
		
		addClosers: function(){
			// This could be obsolete
			$(".threePortlet").each(
					function(i){						
						
						var portletClassNames = this.className;
						var stripWords = eval("/cols1|cols2|cols3|cols8|threePortlet|  | /ig");
						portletClassNames = portletClassNames.replace(stripWords, "");
						var state = my3.readCookie(portletClassNames);
						
						if(state == 'open'){
							var theOpenClose = '<a href="javascript:void(0);" title="Open" id="' + portletClassNames + 'OpenPort" style="display:none;" class="openClosePortlet" onclick="my3.togglePortlet(\'' + portletClassNames + '\'); my3.toggle(new Array(\'' + portletClassNames + 'ClosePort\', \'' + portletClassNames + 'OpenPort\'));">Open</a><a href="javascript:void(0);" title="Close" id="' + portletClassNames + 'ClosePort"  class="openClosePortlet portletClose" onclick="my3.togglePortlet(\'' + portletClassNames + '\'); my3.toggle(new Array(\'' + portletClassNames + 'OpenPort\', \'' + portletClassNames + 'ClosePort\'));">Close</a>';
							$(this).append(theOpenClose);
							$(this).css({'height': ''});
						}
						else{
							var theOpenClose = '<a href="javascript:void(0);" title="Open" id="' + portletClassNames + 'OpenPort" class="openClosePortlet" onclick="my3.togglePortlet(\'' + portletClassNames + '\'); my3.toggle(new Array(\'' + portletClassNames + 'ClosePort\', \'' + portletClassNames + 'OpenPort\'));">Open</a><a href="javascript:void(0);" title="Close" id="' + portletClassNames + 'ClosePort" style="display:none;" class="openClosePortlet portletClose" onclick="my3.togglePortlet(\'' + portletClassNames + '\'); my3.toggle(new Array(\'' + portletClassNames + 'OpenPort\', \'' + portletClassNames + 'ClosePort\'));">Close</a>';	
							$(this).append(theOpenClose);
							$(this).css({'height': togglePortletheight});
						}	
					}
			)
		},
		
		togglePortlet: function(class2toggle){
			// This could be obsolete
			var class2toggleJquery = "." + class2toggle;
			
			if($(class2toggleJquery).css('height') == togglePortletheight){ 
				$(class2toggleJquery).css({'height': ''});
				my3.createCookie(class2toggle, 'open', 60);
			}
			else{
				$(class2toggleJquery).css({'height': togglePortletheight});
				my3.createCookie(class2toggle, 'closed', 60);
			}
			
		},
		
		/*Check if obsolete /\*/
		
		toggle: function(theIDs) {
		/* This function toggles any given ID - must have inline style of disply:none; */	  
			if(theIDs != ''){			
				
				for (var togI=0; togI<theIDs.length; togI++){
					var theEle = document.getElementById(theIDs[togI]);
					
					//my3.createCookie(toggleCookieName, 'creditOpen:close,creditClose:open,creditBody:open', 60);
					
					if(my3.readCookie(toggleCookieName)){
						
						var toggleCookie = my3.readCookie(toggleCookieName);
						var toggleCookieArray = toggleCookie.split(",");
						
					}
					
					
					if (theEle != null){	
						
						if(theEle.style.display == ''){
							theEle.style.display = 'none';
							var theCurrentToggle = theIDs[togI] + ":close";
							my3.compareString2Array(theCurrentToggle , toggleCookieArray);
							
							if(!my3.compareString2Array(theCurrentToggle, toggleCookieArray)){
								my3.setCookieString(theCurrentToggle);	
							}
							
							
						}
						else{
							theEle.style.display = '';
							var theCurrentToggle = theIDs[togI] + ":open";
							//my3.compareString2Array(theCurrentToggle , toggleCookieArray);
							
							if(!my3.compareString2Array(theCurrentToggle , toggleCookieArray)){
								my3.setCookieString(theCurrentToggle);	
							}
						}
					}
				}
				//loopend /\
			}
		},
		
		displayElements: function(arrayOn, arrayOff) {
		/* This function turns divs ON/OFF by ID using the display CSS property - it requires an array of IDs to switch on & another array of IDs to switch off */
			if(arrayOn != ''){
				for (var onI=0; onI<arrayOn.length; onI++){
					var theElement = document.getElementById(arrayOn[onI]);
					if (theElement != null){ theElement.style.display = ""; }
				}
			}
			if(arrayOff != ''){
				for (var offI=0; offI<arrayOff.length; offI++){
					var theElement = document.getElementById(arrayOff[offI]);
					if (theElement != null){ theElement.style.display = "none"; }
				}
			}
		},
		
		tbodyToggle: function(theID) {
		/* This function toggles any given ID */
			  var theEle=document.getElementById(theID)
			  theEle.style.display = (theEle.style.display=='')?'none':'';
		},
		
		alterErrors: function(theID) {
			// This funtion removes the 'errors' class from the parent element of the ID passed. Form elements which have been validated as invalid have had the 'errors' class added to the "form-fields" div.
			if(document.getElementById(theID).parentNode.className != "form-fields errors"){
				var theEle = document.getElementById(theID).parentNode;
				theEle.parentNode.className = "form-fields";
			}
			else{
				document.getElementById(theID).parentNode.className = "form-fields";
				document.getElementById(theID).parentNode.style = "position:relative;";
			}
			
		},
		
		enableSave: function(theID){
			var theID = document.getElementById(theID)
			if($(theID).hasClass('plet-frm-btn-green-69-dis')){
				$(theID).removeClass("plet-frm-btn-green-69-dis");
				$(theID).addClass("plet-frm-btn-green-69");
			}
			if($(theID).hasClass('plet-frm-btn-grey-69-dis')){
				$(theID).removeClass("plet-frm-btn-grey-69-dis");
				$(theID).addClass("plet-frm-btn-grey-69");
			}
			if($(theID).hasClass('plet-frm-btn-green-100-dis')){
				$(theID).removeClass("plet-frm-btn-green-100-dis");
				$(theID).addClass("plet-frm-btn-green-100");
			}
			if($(theID).hasClass('plet-frm-btn-grey-100-dis')){
				$(theID).removeClass("plet-frm-btn-grey-100-dis");
				$(theID).addClass("plet-frm-btn-grey-100");
			}
			if($(theID).hasClass('plet-frm-btn-green-135-dis')){
				$(theID).removeClass("plet-frm-btn-green-135-dis");
				$(theID).addClass("plet-frm-btn-green-135");
			}
			if($(theID).hasClass('plet-frm-btn-grey-135-dis')){
				$(theID).removeClass("plet-frm-btn-grey-135-dis");
				$(theID).addClass("plet-frm-btn-grey-135");
			}
			if($(theID).hasClass('plet-frm-btn-green-150-dis')){
				$(theID).removeClass("plet-frm-btn-green-150-dis");
				$(theID).addClass("plet-frm-btn-green-150");
			}
			if($(theID).hasClass('plet-frm-btn-grey-150-dis')){
				$(theID).removeClass("plet-frm-btn-grey-150-dis");
				$(theID).addClass("plet-frm-btn-grey-150");
			}
			$(theID).removeAttr('disabled');
		},
		
		rowClick: function(theURL){
			window.location = theURL;
		},
		
		
		footyForm: function(){
			$("#teamSelect").show();
		},
		
		submitAlertsForm: function(alertName, formName){
			$("#alert2submit").val(alertName);
			my3.submitForm(formName);
		},
		
		submitTopUpForm: function(topUpName, formName){
			$("#topUp2submit").val(topUpName);
			my3.submitForm(formName);
		},
		
		submitAddonForm: function(addonName, formName){
			$("#addon2submit").val(addonName);
			//my3.submitForm(formName);
		},
		
		/*////////////
		//	This JavaScript will provide the Carousel Slider animation
		*/////////////
			
		animateIT: function(theWidth2use, theSpeed){
			my3.scaleIT(theSpeed);
			$(".content-conveyor").stop().animate(
				{ left: "-" + theWidth2use + "px" },
				{ complete:function() {  } },
				theSpeed,
				"swing"
			);
			my3.showHideNavIcons();
		},	
				
		scaleIT: function(theScaleSpeed){
			$("img.previewGraphic").each(
				function(i){	
					
					if (i == currentStep){	
						if ($(this).hasClass("scaledDown")) {
							$(this).parent().children(".detail").show();
							$(this).stop().animate({
								height: bigHeight + "px",
								width: bigWidth + "px",
								marginTop: '0px',
								marginBottom: '0px',
								marginRight: '0px',
								marginLeft: '0px'
							}, theScaleSpeed+80);
							$(this).removeClass("scaledDown");
							$(this).addClass("scaledUp");
							var hidID = "#hid" + i;
							$("#currentItem").val($(hidID).val());
						}
					}
					else if(i != currentStep){
						if ($(this).hasClass("scaledUp")) {
							$(this).parent().children(".detail").hide();
							$(this).stop().animate({
								height: smallHeight + "px",
								width: smallWidth + "px",
								marginTop: '60px',
								marginBottom: '0px',
								marginRight: '41px',
								marginLeft: '41px'								
							}, theScaleSpeed+80);
							$(this).removeClass("scaledUp");
							$(this).addClass("scaledDown");
						}		
					}
				}
			)	
		},
		
		doSlider: function(){
			var conveyor = $(".content-conveyor", $("#sliderContent")),
			item = $(".item", $("#sliderContent"));
			conveyor.css("width", item.length * parseInt(item.css("width")));
			itemsLength = item.length;
			stepWidth = parseInt(item.css("width")) * currentStep;
			var sliderOpts = {
				max: ((item.length + 2) * parseInt(item.css("width"))) - parseInt($(".viewer", $("#sliderContent")).css("width")),
				value: slidervalue,
				step: parseInt(item.css("width")),
				animate: true,
				slide: function(e, ui) {
					currentStep = ui.value / parseInt(item.css("width"));
					my3.animateIT(ui.value, 0);
				},
				stop: function(e, ui){
					parseInt($("#slider a").css("left"));
				}
			};
			$("#slider").slider(sliderOpts);
			my3.sliderButtonListers();
		},
		
		preloadImages: function(preloadIMGarray){
			var theArraySize = preloadIMGarray.length
			var theItem = 0;
			$.each(preloadIMGarray, function(i, theIMG) {			
				$('<img />').attr({ src: theIMG[0] })
					.load(function(){
						$('#hideLoad').append( $(this) );
						theItem++;
						if(theItem == theArraySize){ my3.buildCarousel(preloadIMGarray); }					
				});
			});
			if(theArraySize == 0){ $("#loadGif").html('<div class="my3_notice portlet-msg-alert positionRelative"><div class="my3_baloon_icon25">Warning...</div><p>Sorry - there are no images to load.</p></div>'); }
		},
		
		showHideNavIcons: function(){			
			// Hides and reveals the previous and next buttons when at the beggining or end of the carousel
			if(currentStep == 0){ $("#sliderContent .previous").css("visibility", "hidden"); }
			else{ $("#sliderContent .previous").css("visibility", "visible"); }
			
			if(currentStep == (itemsLength-1)){ $("#sliderContent .next").css("visibility", "hidden"); }
			else{ $("#sliderContent .next").css("visibility", "visible"); }
		},

		buildCarousel: function(imageArray){
			var whichSelected;
			for (var li=0; li<imageArray.length; li++){
				var theURL = imageArray[li][0];
				var theMake = imageArray[li][1];
				var theModel = imageArray[li][2];
				var theAssetID = imageArray[li][3];
				var theSelected = imageArray[li][4];
				if(theSelected == "selected"){ whichSelected = li; }
				if(li==0){ $("#currentItem").val(theAssetID); }
				var newEle = document.getElementById("contentConveyor");
				var itemContainer = document.createElement('div');			
				var theItemImg = document.createElement('img');
				var theDetailsList = document.createElement('dl');
				var theDetailsDefinition = document.createElement('dd');
				var theDetailText = document.createTextNode(theMake + " " + theModel);
				var theHiddenField = '<input type="hidden" value="'+ theAssetID +'" id="hid'+ li +'" />';
				
				
				
				$(itemContainer).addClass("item");
				$(theDetailsList).addClass("detail");
				
				if (li == 0){
					var theImgClass = "previewGraphic scaledUp";
					var theImgWidth = bigWidth;
					var theImgHeight = bigHeight;
					var theDetailsStyle = "display:block;";
					var theImgStyle = "margin:0px 0px 0px 0px";
				}
				else{
					var theImgStyle = "margin:60px 0px 0px 0px";
					var theImgClass = "previewGraphic scaledDown";
					var theImgWidth = smallWidth;
					var theImgHeight = smallHeight;
					var theDetailsStyle = "display:none;";
				}
				
				if(newEle != null){
					newEle.appendChild(itemContainer);
					$(itemContainer).addClass("item");
					$(itemContainer).append(theItemImg);
					$(theItemImg).attr({ 
						  width: theImgWidth,
						  height: theImgHeight,
						  src: theURL,
						  alt: theMake + " " + theModel,
						  style: theImgStyle
					});
					$(theItemImg).addClass(theImgClass);
					$(itemContainer).append(theDetailsList);
					$(theDetailsList).attr({ 
						  style: theDetailsStyle
					});
					$(theDetailsList).append(theDetailsDefinition);
					$(theDetailsDefinition).append(theDetailText);
					$(itemContainer).append(theHiddenField);
					
				}
				
				if(li == imageArray.length-1){ $('#loadGif').hide(); }
			}
			my3.doSlider();
			currentStep = whichSelected;
			my3.animateIT(bigWidth * whichSelected, theSpeed);
			
			$("#slider").slider( "option", "value",  (bigWidth * currentStep));
		},
			
		jumpMenu: function(targ,selObj,restore){
			// Jump menu
			eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
			if (restore) selObj.selectedIndex=0;
		},
		
		submitForm: function(formName){
			document.forms[formName].submit();
		},
		
		clickFunctionality: function(switchIt){
			if (switchIt == 'left'){
				if (currentStep == 0){ return false; }
				else{		
					$("#slider").slider("previous");
					slidervalue =  parseInt($("#slider a").css("left"));
					if(currentStep >= 1){ currentStep--; }
					my3.animateIT(bigWidth * currentStep, theSpeed);
				}
			}
			else{
				if (currentStep == itemsLength-1){ return false; }
				else{
					$("#slider").slider("next");
					slidervalue =  parseInt($("#slider a").css("left"));
					if(currentStep < itemsLength ){ currentStep++; }
					my3.animateIT(bigWidth * currentStep, theSpeed);
				}
			}
		},
		
		sliderButtonListers: function(){
			$(".previous").click(function() { my3.clickFunctionality('left'); });
			$(".next").click(function() { my3.clickFunctionality('right'); });	
		},
			
		keyCheck: function(e){
			// Identify Keypress and action it
			var KeyID = (window.event) ? event.keyCode : e.keyCode;	
			switch(KeyID){
				/* This has been disabled. For accessibilty reasons we should not capture the enter key.
				case 13:
					// Enter key pressed	
					my3.submitForm(theFormName);
				break;
				*/
				case 37:
					// Left arrow key pressed	
					my3.clickFunctionality('left');
				break;
				case 39:
					// Right arrow key pressed
					my3.clickFunctionality('right');
				break;
			}
		
		},
		
		/*////////////
		// End Carousel JavaScript
		*/////////////
		
		setDivertIfOptions: function(callerId, medium) {
          	// Enable/disable the only if checkboxes
          	var fieldList = new Array("NotAvailable", "NoAnswer", "AnotherCall");
            //Added for My3Further Enhancement Defect No ROIMYTHREE-33 -Sharanya
			my3.disableDiverts();
          	
          	for (i = 0; i < fieldList.length; i++) {
			try{
            	var optionId = "divertIf" + fieldList[i] + medium;
				my3.setDivertDestinations(optionId,medium);
            	my3.setDivertDestinations("divertAll"+medium,medium);
            	my3.setFieldStyle(optionId, onlyIf.checked);
            	my3.setFieldStyle(optionId + "Label", onlyIf.checked);
            	// NoAnswer has a "seconds" label.
            	if (fieldList[i] == "NoAnswer"){
	            	my3.setFieldStyle(optionId + "SecondsLabel", onlyIf.checked);
				}
			}catch(err){console.log(err);}
          	}
			
			var divertIfNotAvailable = document.getElementById("divertIfNotAvailable");
			if(divertIfNotAvailable!=null && divertIfNotAvailable.checked)
			{
				var availto=document.getElementById("divertIfNotAvailableTo");
				availto.disabled=false;
				console.log("divertIfNotAvailable "+divertIfNotAvailable.checked+""+availto.disabled);
			}

			var divertAll = document.getElementById("divertAll");
			if(divertAll!=null && divertAll.checked)
			{
				var availto=document.getElementById("divertAllTo");
				availto.disabled=false;
				console.log("Divert All "+divertAll.checked+""+availto.disabled);
			}
        },
		
		//Added for My3Further Enhancement Defect No ROIMYTHREE-33 -Sharanya
		disableDiverts: function(){
		
				document.getElementById("divertAllTo").disabled =true ;
				document.getElementById("divertAllToOther").disabled =true ;
				document.getElementById("divertIfNotAvailableTo").disabled =true ;
				document.getElementById("divertIfNotAvailableToOther").disabled =true ;
		},
		setDivertDestinations: function(callerId,medium) {
        	// Enable/disable the destination dropdown 

			var caller = document.getElementById(callerId);

			var destinationId = callerId + "To";
			var destination = document.getElementById(destinationId);
		//Added for My3Further Enhancement Defect No ROIMYTHREE-33 -Sharanya			
			my3.disableDiverts();
			if ((caller.checked) && (caller.disabled != true)) {
				my3.setFieldStyle(destinationId, true);
			    my3.setOtherNumber(destinationId);
			} else {
				my3.setFieldStyle(destinationId, false);
			    my3.setOtherNumber(destinationId);
			}
			
			var noAnswerId = "divertIfNoAnswer";
			if (callerId.indexOf('VDO') != -1) {
				noAnswerId = noAnswerId + "VDO";
			}
				try{
			if(document.getElementById("onlyIf"+medium).checked){
	        	if (document.getElementById(noAnswerId).checked) {
	            	document.getElementById(noAnswerId + "Time").disabled = false;
				} else {
	            	document.getElementById(noAnswerId + "Time").disabled = true;
				}
			}else{
				document.getElementById(noAnswerId + "Time").disabled = true;
			}
			}catch(err){console.log(err);}
        },
		
		setOtherNumber: function(callerId) {
        	// Enable/disable the "other" option for divert to
          	var caller = document.getElementById(callerId);
		  
          	var otherId = callerId + "Other";
          	var other = document.getElementById(otherId);

	        if (((caller.options[caller.selectedIndex].value) == "other") && (caller.disabled != true)) {
            	my3.setFieldStyle(otherId, true);
          	} else {
            	my3.setFieldStyle(otherId, false);
          	}
        },
		
		setDefaultAccess: function() {
			my3.setDivertIfOptions("onlyIf","");
			my3.setDivertIfOptions("onlyIf","VDO");
			my3.enableDisableOptions("networkDivert",false);
			my3.enableDisableOptions("cliRestriction",false);
			my3.enableDisableOptions("callWaiting",false);
			my3.setPersonalDivert("personalDivert");
			my3.setVideoDivert("videoDivert");
        },
		
		setFieldStyle: function(fieldName, state) {
			  var field = document.getElementById(fieldName);
			  if (state) {
	
				try {
				  field.disabled = false;
				} catch (e) {
				  alert ("Missing field: " + fieldName);
				}
	
				var fieldType = (field.tagName.toUpperCase() == "LABEL") ? "label" : field.type;
	
				switch(fieldType) {
				  case "checkbox":
					break;
				  case "select-one":
					field.parentNode.className = "";
					break;
				  case "text":
					field.parentNode.className = "";
					break;
				  case "label":
					field.parentNode.className = "";
					break;              
				}
	  
			  } else {
				field.disabled = true;
				
				var fieldType = (field.tagName.toUpperCase() == "LABEL") ? "label" : field.type;
				
				switch(fieldType) {
				  case "checkbox":
					break;
				  case "select-one":
					field.parentNode.className = "disabledField";
					break;
				  case "text":
					field.parentNode.className = "disabledField";
					break;
				  case "label":
					field.parentNode.className = "disabledField";
					break;
				}
			  }
			},
		
		enableDisableOptions: function(idStem, checked){
			var uncheck = document.getElementById(idStem+"Check");
			var prefList = new Array("OptionLabel","Option1","Option1Label","Option2","Option2Label");
			for(i = 0; i < prefList.length; i++) {
				my3.setFieldStyle(idStem + prefList[i],uncheck.checked);
			}
		},
			
		setVideoDivert: function(callerId){
			var videoList = new Array("sameAsVoiceLabel","showvideo");
			var caller = document.getElementById(callerId);		
			for(i = 0; i < videoList.length; i++) {
				if ((caller.checked) && (caller.disabled != true)) {
					my3.setFieldStyle(videoList[i],true);
				}else{
					my3.setFieldStyle(videoList[i],false);
				}
			}
			my3.disableVoiceOrVideo(callerId, 'VDO');	
		},
				
		setPersonalDivert: function(callerId){
			my3.disableVoiceOrVideo(callerId,'');
			checkVoice();
		},
		
		disableVoiceOrVideo: function(callerId,callerType ){

			var caller = document.getElementById(callerId);
			//check the radio button - clear my diverts to uncheck other radio buttons.
			if(!caller.checked){
				var uncheckId = document.getElementById("doNotDivert"+callerType);
				uncheckId.checked = true;
				my3.setDivertIfOptions("doNotDivert"+callerType,callerType);
			}
		
			//Disable the radio buttons and coressponding labels.
			var personalList = new Array("doNotDivert", "doNotDivertLabel", "divertAll", "divertAllLabel", "onlyIf", "onlyIfLabel");	
			for(i = 0; i < personalList.length; i++) {
				if ((caller.checked) && (caller.disabled != true)) {
					my3.setFieldStyle(personalList[i]+callerType,true);
				}else{
					my3.setFieldStyle(personalList[i]+callerType,false);
				}
			}
		},
		
		gaClickTrack:function (my3Country,category,action,label){
			try {
            
				/* Debug vars */
				var my3GacDebug = false;
				var my3GacDebugCode = "UA-12812324-1";
				/* The my3GacDebugCode should be replaced with your desired debug code according to your domain
               		            "UA-12812324-1" -> should be considerd as an example and not testing against it
                                  		        it was created only for dev purpose
               		            If my3GacDebug is set to false the my3GacDebugCode value is ignored                                  
				 */ 
            
				/* Page tracker object */
				var my3PageTracker;
   
				/* Country constants used over the application */
				var country_COM01='COM01';
				var country_COM05='COM05';
				var country_UK='UK';
				var country_ROI='ROI';
            
				/* Local country var, set by default to UK */
				var country=country_UK;
            
				/* Switching from COM01/COM05 to UK/ROI */
				if(my3Country && my3Country==country_COM01)country=country_UK;
				if(my3Country && my3Country==country_COM05)country=country_ROI;
                        
				/* Debug switch */
				if(my3GacDebug){
					//my3PageTracker = _gat._getTracker(my3GacDebugCode);
					_gaq.push(['_setAccount', my3GacDebugCode]);
					alert("GA event debug params: \n [Category-> "+category+"] \n [Country  -> "+country+"] \n [Action     -> "+action+"] \n [Label       -> "+label+"] ");
				} //else my3PageTracker = pageTracker;
				/* Prerequisite: pageTracker -> should exist and should be created by Detica's portal */
            
				/* Tracker init and call */
				//my3PageTracker._initData();
				//my3PageTracker._trackEvent(category+'_'+country, action, label);

				_gaq.push(['_trackEvent', category+'_'+country, action, label]);

				/* According to HLSD [ v1.2 / page 94 / section 10.1.7.2 / paragraph 7 ] 
               		            the pageTracker object should exist and it will be aware of:
               		            Web UK, Web ROI and Agent google analytics 3's accounts 
				 */
			} catch(err){if(my3GacDebug)alert(err.message);}
		},
		
		submitMPI: function(formName){
            
			try{
                document.forms[formName].submit();
            }catch(err){
                alert(err.description);
            }
						
        },
		
		// Moved here from P17ManageRegisteredCards > viewBillPayment.jsp
		checkAmount: function(){			
			var amountToPayInitial = $("#amountInitial").val();
			var amountToPayUpdated = $("#amount").val();
			var result = parseFloat(amountToPayUpdated) - parseFloat(amountToPayInitial);
			if(parseFloat(amountToPayUpdated) > parseFloat(amountToPayInitial) )
				$("#warningDiv").css("display", "block");
			else 
				$("#warningDiv").css("display", "none");
			var divContent= '<div class="my3_baloon_icon25">Warning...</div>' +
				'<p>You&#39;re about to pay &pound;' + (result.toFixed(2)).toString() +
				' more than you need to.</p>';
			$("#warningDiv").html(divContent); 
		},
		// END - Moved here from P17ManageRegisteredCards > viewBillPayment.jsp


		// SSO Server functions moved here from login / logout
		setService: function(service){
            self.parent.location.href=service;
        }
		// END - SSO Sever function

	
}// End my3 namespace


// Extend slider ui to allow for previous and next buttons
$.extend($.ui.slider.prototype, {
	next: function() { this.value(this.value() + this.options.step); },
	previous: function() { this.value(this.value() - this.options.step); }
});

/* Drop 1 JS */
// These functions have been duplicated outside the namespace as a temporary solution


function setDivertIfOptions(callerId, medium) {
          // Enable/disable the only if checkboxes
          var fieldList = new Array("NotAvailable", "NoAnswer", "AnotherCall");

          var onlyIf = document.getElementById("onlyIf"+ medium);
          for (i = 0; i < fieldList.length; i++) {
            var optionId = "divertIf" + fieldList[i] + medium;
            setFieldStyle(optionId, onlyIf.checked);
            setFieldStyle(optionId + "Label", onlyIf.checked);
            // NoAnswer has a "seconds" label.
            if (fieldList[i] == "NoAnswer"){
	            setFieldStyle(optionId + "SecondsLabel", onlyIf.checked);
			}
			setDivertDestinations(optionId,medium);
            setDivertDestinations("divertAll"+medium,medium);
          }
        }
        
		function setDivertDestinations(callerId,medium) {
        	// Enable/disable the destination dropdown 

			var caller = document.getElementById(callerId);

			var destinationId = callerId + "To";
			var destination = document.getElementById(destinationId);
			
			if ((caller.checked) && (caller.disabled != true)) {
				setFieldStyle(destinationId, true);
			    setOtherNumber(destinationId);
			} else {
				setFieldStyle(destinationId, false);
			    setOtherNumber(destinationId);
			}
			
			var noAnswerId = "divertIfNoAnswer";
			if (callerId.indexOf('VDO') != -1) {
				noAnswerId = noAnswerId + "VDO";
			}
			if(document.getElementById("onlyIf"+medium).checked){
	        	if (document.getElementById(noAnswerId).checked) {
	            	document.getElementById(noAnswerId + "Time").disabled = false;
				} else {
	            	document.getElementById(noAnswerId + "Time").disabled = true;
				}			
			}else{
				document.getElementById(noAnswerId + "Time").disabled = true;
			}
        }
        
        function setOtherNumber(callerId) {
          // Enable/disable the "other" option for divert to
          var caller = document.getElementById(callerId);
		  
          var otherId = callerId + "Other";
          var other = document.getElementById(otherId);

          if (((caller.options[caller.selectedIndex].value) == "other") && (caller.disabled != true)) {
            setFieldStyle(otherId, true);
          } else {
            setFieldStyle(otherId, false);
          }
        }
        
        function setDefaultAccess() {

          setDivertIfOptions("onlyIf","");
          setDivertIfOptions("onlyIf","VDO");
          enableDisableOptions("networkDivert",false);
          enableDisableOptions("cliRestriction",false);
          enableDisableOptions("callWaiting",false);
          setPersonalDivert("personalDivert");
          setVideoDivert("videoDivert");
        }
        
        function setFieldStyle(fieldName, state) {
          var field = document.getElementById(fieldName);
          if (state) {

            try {
              field.disabled = false;
            } catch (e) {
              alert ("Missing field: " + fieldName);
            }

            var fieldType = (field.tagName.toUpperCase() == "LABEL") ? "label" : field.type;

            switch(fieldType) {
              case "checkbox":
                break;
              case "select-one":
                field.parentNode.className = "";
                break;
              case "text":
                field.parentNode.className = "";
                break;
              case "label":
                field.parentNode.className = "";
                break;              
            }
  
          } else {
            field.disabled = true;
            
            var fieldType = (field.tagName.toUpperCase() == "LABEL") ? "label" : field.type;
            
            switch(fieldType) {
              case "checkbox":
                break;
              case "select-one":
                field.parentNode.className = "disabledField";
                break;
              case "text":
                field.parentNode.className = "disabledField";
                break;
              case "label":
                field.parentNode.className = "disabledField";
                break;
            }
          }
        } 

	function enableDisableOptions(idStem, checked){
		var uncheck = document.getElementById(idStem+"Check");
		var prefList = new Array("OptionLabel","Option1","Option1Label","Option2","Option2Label");
		for(i = 0; i < prefList.length; i++) {
			setFieldStyle(idStem + prefList[i],uncheck.checked);
		}
	}
		
	function setVideoDivert(callerId){
		var videoList = new Array("sameAsVoiceLabel","showvideo");
		var caller = document.getElementById(callerId);		
		for(i = 0; i < videoList.length; i++) {
			if ((caller.checked) && (caller.disabled != true)) {
				setFieldStyle(videoList[i],true);
			}else{
				setFieldStyle(videoList[i],false);
			}
		}
		disableVoiceOrVideo(callerId, 'VDO');	
	}
	

	function setPersonalDivert(callerId){
		disableVoiceOrVideo(callerId,'');
		checkVoice();
	}	

	function disableVoiceOrVideo(callerId,callerType ){

		var caller = document.getElementById(callerId);
		//check the radio button - clear my diverts to uncheck other radio buttons.
		if(!caller.checked){
			var uncheckId = document.getElementById("doNotDivert"+callerType);
			uncheckId.checked = true;
			setDivertIfOptions("doNotDivert"+callerType,callerType);
		}
	
		//Disable the radio buttons and coressponding labels.
		var personalList = new Array("doNotDivert", "doNotDivertLabel", "divertAll", "divertAllLabel", "onlyIf", "onlyIfLabel");	
		for(i = 0; i < personalList.length; i++) {
			if ((caller.checked) && (caller.disabled != true)) {
				setFieldStyle(personalList[i]+callerType,true);
			}else{
				setFieldStyle(personalList[i]+callerType,false);
			}
		}
	}

window.onReceiveContacts = function(data)
{
 printLog('contact list received');
 contactsData = parseData(data);
}

window.onStorePreference = function(data)
{
printLog('Preference stored');
}
/* Methods added for EDB Hybrid App - Start */

	function isHybridApp(channel)
	{	
		var hybridApp = false;
		try
		{
			if(channel.toUpperCase() == "HANDSET")
			{
				hybridApp = isInEDBContainer();
				printLog('Running in EDB Container');
			}
		}
		catch (err)
		{
			printLog(err);
		}
		return hybridApp;
	}

	function showPDF(invoiceId,msisdn) {
	 
	 printLog("my3_app_url "+my3_app_url);
		var viewPrintableBillUrl = my3_app_url+'/viewPreviousBill/printableBill/';   
		if(my3App)
		{
		printLog("showPDF my3app is true  "+ my3App);
			openURL(viewPrintableBillUrl + '?msisdn=' + msisdn + '&invoiceId=' + invoiceId, true,true);
		}
		else
		{
		printLog("showPDF my3app is false  "+ my3App);
		var w = window.open(viewPrintableBillUrl + '?msisdn=' + msisdn + '&invoiceId=' + invoiceId, '_billWindow', 'fullscreen=no,toolbar=no,status=no,menubar=no,scrollbars=no,resizable=yes,directories=no,location=no,width=850,height=640');
    	if (w) {
        	w.focus();
    	}
		}
	}

/* Methods added for EDB Hybrid App - End */
	function getContent(pageUrl,callBack){
	$.ajax({
    dataType: "HTML",
	type: "GET",
	contentType: "application/html; charset=utf-8",
	url: pageUrl,
	success: function(data) {        
		 return callBack(data);		 
    }, 
	error: function(){
		alert("401 - your session expired , click ok to relogin"); location.reload(true);
	}
	});
 }
 
function renderPage(placeholder,url)
 {
    getContent(url,function(data){
      var div = document.getElementById(placeholder);  
	   div.innerHTML = data;  
	   jQuery.each($(div).find("script"), function(idx, val) {
			eval(val.text); 
	    });
	});
 }
function getProperty(property)
	{
		return $.parseJSON(properties)[property];
	}

function handlerError(key)
	{
	  var error='{"statusCode":-1,"propertyList":{"ux.exception.error.title":"'+getProperty("ux.exception.error.title").trim()+'"},"serviceMessages":[{"messageType":"Error","messageText":"'+getProperty(key).trim()+'","messageLocation":null}]}';
	  return error;
	}

       function handlerDirectError(message)
	{
	  var error='{"statusCode":-1,"propertyList":{"ux.exception.error.title":"There is a problem:"},"serviceMessages":[{"messageType":"Error","messageText":"'+message+'","messageLocation":null}]}';
	  return error;
	}
function getCopy(portlet,copyUrl, callBack){
	$.ajax({
   	dataType: "JSON",
	type: "GET",
	contentType: "application/JSON",
	url: copyUrl,
	data: {"portlet": portlet},
	beforeSend:	function(request){
		  request.setRequestHeader('X-H3G-ORG-ID',my3_rest_org);
		  request.setRequestHeader('X-Channel-Header',my3_rest_channel);
	},
	success: function(data) {        
		 return callBack(data);		 
	}
	});
 }

function CheckPassword(inputtxt){
	//This is for one number and  atleast
	//var decimal= /\d{1}[A-z]|[A-z]{1}\d/;  
	//"This is for one number and one special character atleast" 
	var decimal=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,30}$/  
	if(inputtxt.match(decimal)){
	  console.log('Correct password');
	return true;  
	}  
  	else {   
	console.log('Wrong! password');
	return false;  
   } 
} 
	