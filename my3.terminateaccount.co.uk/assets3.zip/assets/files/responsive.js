;(function (factory) {

  /* jshint laxcomma:true, asi:true, debug:true, curly:false, camelcase:true, browser:true */
  /* global define */

  // Register as an anonymous AMD module if relevant, otherwise assume oldskool browser globals:
  if (typeof window.define === "function" && define.amd)
    define(["jquery"], factory)
  else
    factory( jQuery )

})(function( $ ) {
  /* jshint laxcomma:true, asi:true, debug:true, curly:false, camelcase:true, browser:true */

  var ResponsiveController = function() {
    this.notificationCookieName = "tuk_ack_ck";
    this.initCookieMessage();
    this.initToggleSearch();
    this.initMobileMenu();
    this.setSearchType();

    $("input[name=search-type]").on("change", this.setSearchType);
  };

  
  ResponsiveController.prototype.initCookieMessage = function() {
    var self = this;
    var cookie = this.readCookie( this.notificationCookieName );
    
    $("#rwd-cookie-message a[data-function=close]").click(function(e) {
      e.preventDefault();
      self.createCookie( self.notificationCookieName, 2, 3650, "three.co.uk");//3650 == 10 years
      $(this).parents('.notification').hide();
    });
    
    if (cookie === null || cookie < 2) {
      self.createCookie( self.notificationCookieName, 2, 3650, "three.co.uk");
      $('#rwd-cookie-message').show();
    }

  }
  
  ResponsiveController.prototype.initToggleSearch = function() {
    var self = this;
    $("#toggle-search").on("change", this.toggleSearch);
    
    // $('label[for=toggle-search]').parents('li').keydown(function(e) {
    //   e.preventDefault();
    //   self.toggleSearch();
    // })
  };
  
  ResponsiveController.prototype.toggleSearch = function(e) {
    e.preventDefault();
    $('#toggle-search').parents('li').toggleClass('active');
    $("#main-search").toggleClass('hide');
    
    if ( $('#toggle-search').parents('li').hasClass('active') ) {
      $('#search-query').focus();
    }
  }
  
  ResponsiveController.prototype.initMobileMenu = function() {
    $('#toggle-menu').on("click", function(e) {
      e.preventDefault();
      $('body').toggleClass('show-menu');
    })
  }
  
  ResponsiveController.prototype.setSearchType = function(e) {
    var form = e && e.target ? $(e.target).parents('form') : $('.search-form');
    
    console.log(form);

    form.attr("action", form.find("input[name=search-type]:checked").val());
    form.find("input[name=q]").attr("placeholder", "Search " + form.find("input[name=search-type]:checked").data("placeholder") + "...");
    if( form.find("input[name=search-type]:checked").data("placeholder") === "the Web" ) form.find("fieldset.input img").show(); else form.find("fieldset.input img").hide();
  };
  
  ResponsiveController.prototype.createCookie = function(name, value, days, domain, path) {
    var expires = "";
    path = (typeof(path) != "undefined") ? ";path="+path : ";path=/";

    if (days) {
      var date = new Date();
      date.setTime(date.getTime()+(days*24*60*60*1000));
      console.log('cookie set expiry ',date.toGMTString());
      expires = "; expires="+date.toGMTString();
    }
    domain = ";domain="+domain;
    var cookie = name+"="+value+expires+path+domain;
    console.log(cookie);
    document.cookie = cookie;
  }
  
  ResponsiveController.prototype.readCookie = function(name) {
  	var nameEQ = name + "=";
  	var ca = document.cookie.split(';');
  	for(var i=0;i < ca.length;i++) {
  		var c = ca[i];
  		while (c.charAt(0)==' ') c = c.substring(1,c.length);
  		if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length,c.length);
  	}

  	return null;
  }
  
  ResponsiveController.prototype.eraseCookie = function(name) {
    this.createCookie(name,"",-1);
  }
  
  window.gup = function (name) {
  	name = name.replace(/[\[]/,"\\[").replace(/[\]]/,"\\]");
  	var regexS = "[\\?&]"+name+"=([^&#]*)";
  	var regex = new RegExp( regexS );
  	var results = regex.exec( window.location.href );
  	if( results === null ){
  		return "";
  	}else{
  		return results[1];
  	}
  }
  
  window.h3g = window.h3g || {};
  window.h3g.responsiveController = new ResponsiveController();
});
