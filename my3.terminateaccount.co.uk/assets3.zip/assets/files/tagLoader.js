/*global h3g_loader_vars:true, escape:true*/
;(function($, window, document, undefined){
    'use strict';

    var desktopsToExcludeForForesee=new Array("handset", "standalone"),
        desktopsToExcludeForMindshare=new Array("selfcare","my3");

    $(function() {
		/*** FORESEE TRIGGER ***/
		if(showInDesktop(desktopsToExcludeForForesee)){
            (function(d, t){ 
                    var g = d.createElement(t), 
                    s = d.getElementsByTagName(t)[0]; 
                    g.src = '/static/html/foresee/foresee-analytics-j1380.js';      
                    s.parentNode.insertBefore(g, s); 
            }(document, 'script'));
		}

        /*** MINDSHARE SCRIPT ***/
        if(showInDesktop(desktopsToExcludeForMindshare)){
            (function(d, t){ 
                var g = d.createElement(t), 
                s = d.getElementsByTagName(t)[0]; 
                g.src = '/static/script/mindshareZapTag.js';     
                s.parentNode.insertBefore(g, s); 
            }(document, 'script')); 
        }

        /*** COOKIES ***/
        var tuk_value = getCookie("tuk_ack_ck");
       
        /* Check if we should show cookie message */
        if (tuk_value === null || tuk_value < 2) {
            /* If cookie value is null or less than one, create cookie and show message, if it's one then increment cookie value but hide message (this implies acceptance) */
            if (tuk_value === null || tuk_value < 1) {
                var divToAttach = "#innerCenter";
                var cookieHtmlPath = "/static/html/cookie/cookie.html";

                if($(divToAttach).length === 0){
                    divToAttach = "#mobile-container";
                    cookieHtmlPath = "/static/html/cookie/cookie_mobile.html"
                }

                /* retrieves html for cookie message */
                $.ajax({
                    url: cookieHtmlPath,
                    type: 'GET',
                    dataType: 'html',
                    async: false,
                    success: function(data){
                        $(divToAttach).prepend(data);
                        $("#cookie-message").slideDown('slow');
                        /* Add event to close button */
                        $('#cookie-message .close-image').bind("click", function(){
                            $('#cookie-message').slideUp('slow');
                            $(".socialBanner").trigger({type:"repositionSocialBannerForCookies", cookieHeightNumber:-90});
                            setCookie("tuk_ack_ck", 2, 3650, "/",".three.co.uk");
                        });
                    }
                });

                $(document).ready(function(){
                    $(".socialBanner").trigger({type:"repositionSocialBannerForCookies", cookieHeightNumber:90});
                });
            }
            setCookie("tuk_ack_ck", Number(tuk_value) + 1, 3650, "/",".three.co.uk");
        }
    });

    var setCookie = function(c_name,value,exdays,path,domain){
        var exdate=new Date();
        exdate.setDate(exdate.getDate() + exdays);
        var c_value=escape(value) + 
        ((exdays === null) ? "" : "; expires="+exdate.toUTCString())  + 
        ((path === null) ? "" : "; path=" + path) +  
        ((domain === null) ? "" : "; domain=" + domain);
        document.cookie=c_name + "=" + c_value;
    },
    getCookie = function(name){
        var cookieVal = null;
        var cookieArray1 = document.cookie.split(name + "=");
        if(cookieArray1.length > 1){
            cookieVal = cookieArray1[1].split(";")[0];
        }
        return cookieVal;
    },
    showInDesktop = function(desktopArray){
        var showInDesktop = true;
        for(var i = 0; i < desktopArray.length; i++){
            if(h3g_loader_vars.desktopName.toLowerCase().indexOf(desktopArray[i]) !== -1){
                showInDesktop = false;
            }
        }
        return showInDesktop;
    };
})(jQuery, window, document);
