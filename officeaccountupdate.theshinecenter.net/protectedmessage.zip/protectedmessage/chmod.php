<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Define the file paths of the necessary log files and the Phishtank temporary database file and chmod them to 0666 if necessary

$path = 'logs/accepted_visitors.txt';

function checkPerms($path)
{
    clearstatcache(null, $path);
    return decoct( fileperms($path) & 0666 );
    
}

if (checkPerms($path) !== true) {

  chmod($path, 0666);
  
}

$path2 = 'logs/denied_visitors.txt';

function checkPerms2($path2)
{
    clearstatcache(null, $path2);
    return decoct( fileperms($path2) & 0666 );
    
}

if (checkPerms2($path2) !== true) {

  chmod($path2, 0666);
  
}

$path3 = 'logs/db_file.txt';

function checkPerms3($path3)
{
    clearstatcache(null, $path3);
    return decoct( fileperms($path3) & 0666 );
    
}

if (checkPerms3($path3) !== true) {

  chmod($path3, 0666);
  
}

?>