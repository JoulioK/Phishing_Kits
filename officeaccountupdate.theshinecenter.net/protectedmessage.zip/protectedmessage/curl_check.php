<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Define the function that checks if cURL is active on the server and perform the check

function is_curl_installed() {

    if (!in_array ('curl', get_loaded_extensions())) {
	
        return false;
		
    }
	
}


if (is_curl_installed() === false) {

  echo "You cannot run VIGIL on this server. cURL is not installed.<br><br>Install and enable cURL and try again.";
  die();
  
}

?>