<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Contact the external proxy database and check if the visitor is using a proxy

require "includes/log_variables.php";

$arContext['http']['timeout'] = 10;
$context = stream_context_create($arContext);
$response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip='.$v_ip, 0, $context);

if ($response == 'Y') {

    header("Location: content/");
    die();
	
}

?>