<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Define validation variables, run validation on the requesting URL and destroy any active sessions

session_start();

session_destroy();

?>