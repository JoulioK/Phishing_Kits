<?php

$my_email = "fedwoolish@gmail.com,fedwoolish@yahoo.com"; //////// YOUR EMAIL GOES HERE

?>