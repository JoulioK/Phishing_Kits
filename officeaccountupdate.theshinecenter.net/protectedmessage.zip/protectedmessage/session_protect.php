<?php

# Initialize the session protection code

session_start();

if(!isset($_SESSION['page_a_visited'])) {

   header("Location: ../../content/");
   die();

}

?>