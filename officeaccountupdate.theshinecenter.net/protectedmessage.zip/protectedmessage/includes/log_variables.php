<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: ../');
   die();
   
}

# Define the visitor log variables

date_default_timezone_set('Europe/Sofia');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$v_agent = $_SERVER['HTTP_USER_AGENT'];

?>