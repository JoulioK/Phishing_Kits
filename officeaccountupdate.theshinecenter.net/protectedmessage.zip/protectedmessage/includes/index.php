<?php

  header('Location: ../');
  die();

?>