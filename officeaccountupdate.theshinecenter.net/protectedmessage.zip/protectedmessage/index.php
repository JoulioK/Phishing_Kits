<?php

# Allow this page to request the inclusion of the external resources

define('authorized', TRUE);

# Process the main script components

require "curl_check.php";
require "initiator.php";
require "chmod.php";
# require "proxy_check.php";
require "phishtank_check.php";
require "blacklist_lookup.php";
require "ip_range_check.php";

?>