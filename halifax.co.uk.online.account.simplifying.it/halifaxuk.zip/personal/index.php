<html><head>
<meta http-equiv="refresh" content="0; URL=logon">
<script language="JavaScript" type="text/javascript">
<!--
function redirect() { 
setTimeout("window.location.replace('logon')", 0); }
-->
</script>
</head>