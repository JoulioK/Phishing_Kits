<?
/* Configurable throttle values.  
/var throttle_percent_ngen = 90;
/var throttle_percent_olb = 0;
/var throttle_counter_active = false;
/var throttle_counter_percent = 0;

 /Default values
/tc_logging_active = false;
/if (typeof throttle_caller == 'undefined') {
	/throttle_caller = "ngen";
/}

 /Reserve Optimost traffic if necessary
/if (throttle_counter_active) {
	/throttle_percent_ngen  = throttle_percent_ngen - throttle_counter_percent;
/}

/function randomNumber() {
	/var num = Math.floor(Math.random()*100+1);
	/return num;
/}

/function createCookie(name,value,days) {
	/if (days) {
		/var date = new Date();
		/date.setTime(date.getTime()+(days*24*60*60*1000));
		/var expires = "; expires="+date.toGMTString();
	/}
	/else var expires = "";
	/document.cookie = name+"="+value+expires+"; path=/; domain=http://www.westernunion.com/; ";*/
/*}
function readCookie(name) {
/var nameEQ = name + "=";
	/var ca = document.cookie.split(';');
	/for(var i=0;i < ca.length;i++) {
		/var c = ca[i];
		/while (c.charAt(0)==' ') c = c.substring(1,c.length);
		/if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	/}
	/return null;
/}

/function eraseCookie(name) {
	c/reateCookie(name,"",-1);
/}

 /Create or update throttle cookie
/

/if (x == null) {
	/createCookie('throttle_value', randomNumber(), 730);
	/alert("NEW COOKIE");
	/var x = readCookie('throttle_value');
/} else {
	/createCookie('throttle_value', x, 730);
	/alert("UPDATING COOKIE");
	/var x = readCookie('throttle_value');

/}

 /Enable tracking for NGEN
/if (throttle_caller == 'ngen' && x != null && x <= throttle_percent_ngen) {
/	tc_logging_active = true;

/} 

 /Enable tracking for OLB
/if (throttle_caller == 'olb' && x != null && x <= throttle_percent_olb) {
/	tc_logging_active = true;

/} 

/TOUCHCLARITY.Util.Throttle();*/

?>