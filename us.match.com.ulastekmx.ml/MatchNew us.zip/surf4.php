<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>&#77;&#97;&#116;&#99;&#104;&#174;&#32;&#124;&#32;&#32;&#84;&#104;&#101;&#32;&#76;&#101;&#97;&#100;&#105;&#110;&#103;&#32;&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#68;&#97;&#116;&#105;&#110;&#103;&#32;&#83;&#105;&#116;&#101;&#32;&#102;&#111;&#114;&#32;&#83;&#105;&#110;&#103;&#108;&#101;&#115;&#32;&#38;&#32;&#80;&#101;&#114;&#115;&#111;&#110;&#97;&#108;&#115;</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon"
              href="images/favicon.ico"/>
<html><meta http-equiv="Refresh" content="05; url=http://www.match.com/international/interstitial.aspx?pc=367&url=usa.match.com%3Ftcid=1094"></html>
<style type="text/css">
div#container
{
	position:relative;
	width: 1365px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>
<style>
p{font-size: 40px;}
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('https://smallenvelop.com/wp-content/uploads/2014/08/Preloader_11.gif') 50% 50% no-repeat rgb(249,249,249);
    opacity: .8;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<script type="text/javascript">
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
</script>
</head>
<body>
<div class="loader"></div>
<div id="container">
<div id="image1" style="position:absolute; overflow:hidden; left:0px; top:0px; width:1365px; height:604px; z-index:0"><img src="images/mc6.png" alt="" title="" border=0 width=1365 height=604></div>

<div id="image3" style="position:absolute; overflow:hidden; left:171px; top:3px; width:676px; height:47px; z-index:1"><a href="#"><img src="images/mc3.png" alt="" title="" border=0 width=676 height=47></a></div>

<div id="image2" style="position:absolute; overflow:hidden; left:449px; top:252px; width:77px; height:77px; z-index:2"><img src="images/mt.gif" alt="" title="" border=0 width=77 height=77></div>

</div>

</body>
</html>
