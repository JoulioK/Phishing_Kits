This Page Coded by #SH33NZ0#
Please Open Config.php File and Change the variables which stated with $ change the value which between ""
Thanks for reading
Happy Cashout and Shopping