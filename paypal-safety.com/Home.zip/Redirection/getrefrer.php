<?php
// This File Help you to get HTTP_REFERER 
$ref = $_SERVER['HTTP_REFERER'];
$refData = parse_url($ref);
echo "HTTP REFERER -->  ".$refData['host']."";
?>