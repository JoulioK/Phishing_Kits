<?php
	$lg_captcha = [
		"title" => "Sfida di sicurezza",
		"head" => "Sfida di sicurezza",
		"body" => "Digita i caratteri che vedi nell'immagine per motivi di sicurezza",
		"bt_secure" => "Io non sono un robot",
		"code" => "Digita il codice visualizzato"
	];

?>