<?php
	$lg_captcha = [
		"title" => "Sicherheitsherausforderung",
		"head" => "Sicherheitsherausforderung",
		"body" => "Bitte geben Sie aus Sicherheitsgründen die im Bild angezeigten Zeichen ein.",
		"bt_secure" => "Ich bin kein Roboter",
		"code" => "Geben Sie den angezeigten Code ein"
	];
	?>