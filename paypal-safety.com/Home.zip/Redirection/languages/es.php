<?php
	$lg_captcha = [
		"title" => "Sicherheitsherausforderung",
		"head" => "Sicherheitsherausforderung",
		"body" => "Escriba los caracteres que ve en la imagen por motivos de seguridad",
		"bt_secure" => "No soy un robot",
		"code" => "Introduzca el código mostrado"
	];
?>