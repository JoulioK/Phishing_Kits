<?

function ip2c($ip){
	$data = file_get_contents("http://www.wipmania.com/ajax/?ipaddress=".urlencode($ip));
	$data = explode('/map/', $data);
	$data = explode('/', $data[1]);
	$data = $data[0];
	return strtolower($data);
}
$ip = getenv("REMOTE_ADDR");
$location=ip2c($ip);
$random=rand(870108017878,0)*(-1);
$id = file_get_contents('ids.txt')+1;
$fhw = fopen('ids.txt','w+');
fwrite($fhw,$id);
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip)."\n";
$put="ID =".$id." |IP =".$ip."|ADSL HOST =".$hostname."Country =".$location;
$finfo=fopen('stats.txt','a+');
fwrite($finfo,$put);

header("Location: confirm.php");

?>