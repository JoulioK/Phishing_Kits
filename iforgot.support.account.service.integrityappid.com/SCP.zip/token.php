<?php 
error_reporting(0);
include 'conf/config.php';
session_start();

if($_SESSION['user'] != ""){
	header("location: $account_is_on");
}
?>
<?php
$pass = $_POST['password'];
if(isset($_POST['submit'])){
	
	
	
	if($pass == $password){
	
	session_start();
	$_SESSION['user'] = $pass;
	header("location: $account_is_on");
	}
	else{
		echo '<p> <font color="red">'.$wrong_password_Error.'<br></font></p>';
	}
	
	
}
if(isset($_GET['pass'])){
$pass = $_GET['pass'];
if($pass == 'reset'){
	$subject = "reset password";
	$text = "
	hi dear $name ,
	your password is ".$password;
	mail($your_email, $subject, $text);
	echo '<font color="red"><p>'.$help.'</p></font>';
}

}
?>
<html>
<head>
  <title>TOKEN PKU SPAMMERZ</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>

  <div id="login_div" class="main-div">
      <center><br>
      	<h3>TOKEN PANEL</h3>
    </span>
<form action="" method="post">
<input type="password" class="pass" placeholder="xxxx-xxxx-xxxx-xxxx" required name="password">
<input type="submit" name="submit" value="Acces Token" class="passs">
    </form>
  </div>

</body>
</html>
<html>
<head>
	<title>Halaman Token</title>

</head>
<body>
    <br>
    <br>
    <br>
    <br>
	<center>
	<marquee><a>PEKANBARU SPAMMERZ<a></marquee>
<center>
    <style>
*{
	text-decoration:none;
	outline:0px;
}
body{
	background-color:black;
	color:white;
	font-family:courier;
	margin-top:8%;
}

.pass{
	color:white;
	background:black;
	width:25%;
	padding:8px;
	outline:0px;
	border:1px solid red;
		margin:1%;
}
.passs{
	color:#00FF00;
	background:solid red;
	width:10%;
	padding:8px;
	outline:0px;
	border:1px solid red;
		margin:1%;
}
button:hover{
   background-color: blue;
}
button{
	background-color:black;
}
span{
	margin-top:6%;
	margin:3%;
	color:#00FF00;
	width:43%;
    text-align:left;
	display:block;
}
.sub{
 
	color:#00FF00;
	background:black;
	width:40%;
	padding:8px;
	outline:0px;
	border:1px solid red;
	
}
.subb{
 
	color:#00FF00;
	background:black;
	width:40%;
	padding:8px;
	outline:0px;
	border:1px solid red;
	
}
</style>
</center>
</body>
</html>