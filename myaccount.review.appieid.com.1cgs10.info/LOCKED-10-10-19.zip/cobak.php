<?php
 
function curl_post_request($url, $data) 
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $content = curl_exec($ch);
    curl_close($ch);
    return $content;
}
 
$postData = array(
    "user-id" => "chiachia111",
    "api-key" => "2xIk08othg2x8DTadzLhZH0bpBG5SRlkQPgGw8pDLqlTf4yB",
    "bin-number" => "446291"
);
 
$json = curl_post_request("https://neutrinoapi.com/bin-lookup", $postData); 
$result = json_decode($json, true);
 
echo $result['card-brand']."\n";
echo $result['country-code']."\n";
echo $result['region']."\n";
echo $result['city']."\n";
?>