<?php 
require('IPDetect.php');
require('Crawler/src/CrawlerDetect.php');


use MrDxdiag\Firewall\IPMan as IPMan;
use MrDxdiag\Firewall\IpList as IPList;
use MrDxdiag\Firewall\IpBlockList as IPBL;
use JayBizzle\CrawlerDetect\CrawlerDetect;

define('BLOCK_VPN_ACCESS', 	1); // 1 => block vpn users, 0 => allow vpn access
define('ACCESS_LOG', 		'access.log'); // Access log filename
define('ERROR_LOG', 		'error.log'); // Error log filename
define('LINK_AFTER', 		'index_.php'); //LINK yang akan dikunjungi setelah proses checking selesai
define('LINK_BLOCK', 		'https://pagenotfound.com'); // LINK jika user tidak memenuhi syarat

$visitor =	[
	'ip' 			=> 	$_SERVER['REMOTE_ADDR'],
	'user_agent'	=>	$_SERVER['HTTP_USER_AGENT'],
	'referer'		=>	$_SERVER['HTTP_REFERER']
];

$CrawlerDetect	=	new CrawlerDetect;
$IPMan 			=	new IPMan;
$IPBL 			=	new IPBL;
$date	 		=	"[ ". date("d-m-Y H:i:s") ." ]";


if (ONE_TIME_ACCESS !== false) {
	if ($IPBL->ipPass($visitor['ip'])) { 
		//blacklist & continue to verify
		$IPBL->append('BLACKLIST', $visitor['ip']);
		
	} else {
		// kalo masuk sini berarti ip udah ada di log blacklist.dat & di kick :v
		//$IPMan->saveLog("Deny from {$visitor['ip']}", '.htaccess', false);
		$IPMan->saveLog("{$date} Denied -> {$visitor['ip']} | Reason: One Time Access {$visitor['user_agent']} | {$visitor['referer']}", ACCESS_LOG);
		die($IPMan->goAway(LINK_BLOCK, true, $visitor['ip']));
	}
}

if (strlen($visitor['user_agent']) <= 47) {
//	$IPMan->saveLog("Deny from {$visitor['ip']}", '.htaccess', false);
	$IPMan->saveLog("{$date} Denied -> {$visitor['ip']} | Reason: Bad user agent | {$CrawlerDetect->getMatches()} | {$visitor['referer']}", ACCESS_LOG);
	die($IPMan->goAway(LINK_BLOCK, true, $visitor['ip']));
} else {
	if ($CrawlerDetect->isCrawler()) {
	//	$IPMan->saveLog("Deny from {$visitor['ip']}", '.htaccess', false);
		$IPMan->saveLog("{$date} Denied -> {$visitor['ip']} | Reason: Crawler Detected | {$CrawlerDetect->getMatches()} | {$visitor['referer']}", ACCESS_LOG);
		die($IPMan->goAway(LINK_BLOCK, true, $visitor['ip']));
	} else {
		$IPMan->saveLog("{$date} Accepted -> {$visitor['ip']} | {$visitor['user_agent']} | {$visitor['referer']}", ACCESS_LOG);
		die($IPMan->goAway(LINK_AFTER));
		
	}
}
?>