<footer>
<div class="container">
<div class="footer">
<div class="footer-wrap">
<div class="FooterLine1">
<div class="line-level"><?php echo $bhs['login8']; ?></div>
</div>
<div class="FooterLine2" align="right">
<ul class="menu">
<li class="item"><a class="choose" href="#"><img height="22" src="<?php echo $lang['FLAG'];?>" width="22">&nbsp;&nbsp;<?php echo $lang['COUNTRY'];?></a></li>
</ul>
</div>
<div class="FooterLine3"><?php echo $bhs['login9']; ?>
<ul class="menu">
<li class="item" style="margin-left: 30px; margin-right: 10px; padding-right: 12px;"><a href="#"><?php echo $bhs['login10']; ?></a></li>
<li class="item" style="margin-right: 10px; padding-right: 12px;"><a href="#"><?php echo $bhs['login11']; ?></a></li>
<li class="item" style="margin-right: 10px; padding-right: 12px;"><a href="#"><?php echo $bhs['login12']; ?></a></li>
<li class="item" style="margin-right: 10px; padding-right: 12px;"><a href="#"><?php echo $bhs['login13']; ?></a></li>
<li class="item" style="margin-right: 10px; padding-right: 12px;"><a href="#"><?php echo $bhs['login14']; ?></a></li>
</ul>
</div>
</div>
</div>
</div>
</footer>