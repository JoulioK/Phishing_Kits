<?php
require "functions.php";
$v_ip     = $_SERVER['REMOTE_ADDR'];
$response = curl('http://proxy.mind-media.com/block/proxycheck.php?ip=' . $v_ip);
if($response == 'Y') {
  header("Location: https://t.co/AppRJ4IEWA");
  die();
}
?>