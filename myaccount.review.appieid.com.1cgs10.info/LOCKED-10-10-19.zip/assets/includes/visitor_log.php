<?php
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');
$ip      = $_SERVER['REMOTE_ADDR'];
$details = json_decode(file_get_contents('https://freegeoip.net/json/'. $ip), true);
if(!empty($details['country_name'])) {
  $v_country = $details['country_name'];
} else {
  $v_country = "UnKnown";
}
$v_isp      = gethostbyaddr($v_ip);
$v_date     = date("D d M H:i:s");
$v_agent    = $_SERVER['HTTP_USER_AGENT'];
$v_referrer = $_SERVER['HTTP_REFERER'];
$fp         = fopen("assets/logs/ips.txt", "a");
fputs($fp, "[ $v_date ] $v_country - IP: $v_ip - HOST: $v_isp - Referer: $v_referrer - Browser: $v_agent\r\n");
fclose($fp);
?>