<?php
$json = json_decode(file_get_contents("assets/logs/address/" . $_SESSION['user'] . ".dat"), true);
$codes = json_decode(file_get_contents("assets/includes/iso.dat"), true);
if (!empty($json['c_code'])) {
  $nama_negara  = $json['c_name'];
  $country_code = $codes[$json['c_code']];
} else {
  $ip           = $_SERVER['REMOTE_ADDR'];
  $details      = json_decode(file_get_contents('https://get.geojs.io/v1/ip/geo/' . $ip . '.json'), true);
  $nama_negara  = $details['country'];
  $country_code = $details['country_code'];
}

$lang = ['AU' => 'au', 'GB' => 'gb', 'US' => 'usa', 'CA' => 'ca', 'GR' => 'gr', 'CY' => 'cy', 'HK' => 'hk', 'IE' => 'ie', 'IN' => 'in', 'KW' => 'kw', 'NZ' => 'nz', 'SA' => 'sa', 'QA' => 'qa', 'TH' => 'th'];
	if (array_key_exists($country_code, $lang)) {
		$a=$lang[$country_code];
	} else {
		$a='other';
	}
$lang_file = 'lang.' . $a . '.php';
include_once 'languages/' . $lang_file;