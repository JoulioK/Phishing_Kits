<?php
/**
Script Source URI: http://techpatterns.com/downloads/php_language_detection.php
**/
function get_languages( $feature, $spare='' )
{
	$a_languages = load_language_data();
	$index = '';
	$complete = '';
	$b_found = false;
	$a_user_languages = array();
	$b_debugger_1 = false;
	$b_debugger_2 = false;
	
	if ( isset( $_SERVER["HTTP_ACCEPT_LANGUAGE"] ) ) {
		$languages = strtolower( $_SERVER["HTTP_ACCEPT_LANGUAGE"] );
		if ($b_debugger_2 === true){
			$languages = ' fr-ch;q=0.3, da, en-us;q=0.8, en;q=0.5, fr;q=0.3';
		}
		$languages = str_replace( ' ', '', $languages );
		$a_languages_working = explode( ',', $languages );
		foreach ( $a_languages_working as $language_list ) {
			$a_temp = array();
			$a_temp[0] = substr( $language_list, 0, strcspn( $language_list, ';' ) );
			$a_temp[1] = substr( $language_list, 0, 2 );
			if ( array_key_exists($a_temp[0], $a_languages ) === true ) {
				$a_temp[2] = $a_languages[$a_temp[0]];
				$a_temp[3] = substr( $a_temp[2], 0, strcspn( $a_temp[2], ' (' ) );
			}
			else {
				$a_temp[2] = '';
				$a_temp[3] = '';
			}
			$a_user_languages[] = $a_temp;
		}
	}
	else {
		$a_user_languages[0] = array( '','','','' );
	}
	if ( $b_debugger_1 === true ){
		echo '<pre>';
		print_r($a_user_languages);
		echo '</pre>';
	}
	if ( $feature == 'data' ) {
		return $a_user_languages;
	}
	elseif ( $feature == 'header' ) {
		$bhs = array('ja' => 'jp', 'ja-jp' => 'jp', 'id' => 'id', 'id-id' => 'id', 'en-us' => 'en', 'en-ca' => 'en', 'en-gb' => 'gb', 'en-ie' => 'gb', 'fr-ca' => 'ca', 'zh' => 'hk', 'zh-hk' => 'hk', 'zh-tw'=> 'hk', 'de' => 'de', 'de-de' => 'de', 'de-ch' => 'de', 'de-at' => 'de', 'de-li' => 'de', 'de-lu' => 'de', 'es' => 'es', 'es-es' => 'es', 'es-mx' => 'es', 'es-ar' => 'es', 'es-bo' => 'es', 'es-cl' => 'es', 'es-co' => 'es', 'es-cr' => 'es', 'es-do' => 'es', 'es-ec' => 'es', 'es-sv' => 'es', 'es-gt' => 'es', 'es-hn' => 'es', 'es-ni' => 'es', 'es-pa' => 'es', 'es-py' => 'es', 'es-pe' => 'es', 'es-pr' => 'es', 'es-uy' => 'es', 'es-ve' => 'es');
		if (array_key_exists($a_user_languages[0][0], $bhs)) {
		    $a=$bhs[$a_user_languages[0][0]];
		} else {
		    $a='all';
		}
		return 'bhs.' . $a . '.php';
	}
}

function load_language_data()
{
	$a_languages = array(
	'af' => 'Afrikaans',
	'sq' => 'Albanian',
	'am' => 'Amharic',
	'ar' => 'Arabic (Standard)',
	'ar-dz' => 'Arabic (Algeria)',
	'ar-bh' => 'Arabic (Bahrain)',
	'ar-eg' => 'Arabic (Egypt)',
	'ar-iq' => 'Arabic (Iraq)',
	'ar-jo' => 'Arabic (Jordan)',
	'ar-kw' => 'Arabic (Kuwait)',
	'ar-lb' => 'Arabic (Lebanon)',
	'ar-ly' => 'Arabic (Libya)',
	'ar-ma' => 'Arabic (Morocco)',
	'ar-om' => 'Arabic (Oman)',
	'ar-qa' => 'Arabic (Qatar)',
	'ar-sa' => 'Arabic (Saudi Arabia)',
	'ar-sy' => 'Arabic (Syria)',
	'ar-tn' => 'Arabic (Tunisia)',
	'ar-ae' => 'Arabic (U.A.E.)',
	'ar-ye' => 'Arabic (Yemen)',
	'hy' => 'Armenian',
	'as' => 'Assamese',
	'ast' => 'Asturian',
	'az' => 'Azerbaijani',
	'eu' => 'Basque',
	'be' => 'Belarusian',
	'bn' => 'Bengali',
	'bs' => 'Bosnian',
	'bg' => 'Bulgarian',
	'my' => 'Burmese',
	'ca' => 'Catalan',
	'ch' => 'Chamorro',
	'ce' => 'Chechen',
	'zh' => 'Chinese',
	'zh-hk' => 'Chinese (Hong Kong SAR)',
	'zh-cn' => 'Chinese (China)',
	'zh-sg' => 'Chinese (Singapore)',
	'zh-tw' => 'Chinese (Taiwan)',
	'zh-mo' => 'Chinese (Macau SAR)',
	'cv' => 'Chuvash',
	'hr' => 'Croatian',
	'cs' => 'Czech',
	'da' => 'Danish',
	'div' => 'Divehi',
	'nl-be' => 'Dutch (Belgium)',
	'nl' => 'Dutch (Netherlands)',
	'en-au' => 'English (Australia)',
	'en-bz' => 'English (Belize)',
	'en-ca' => 'English (Canada)',
	'en-cb' => 'English (Caribbean)',
	'en-in' => 'English (India)',
	'en-ie' => 'English (Ireland)',
	'en-jm' => 'English (Jamaica)',
	'en-nz' => 'English (New Zealand)',
	'en-ph' => 'English (Philippines)',
	'en-za' => 'English (South Africa)',
	'en-tt' => 'English (Trinidad)',
	'en-gb' => 'English (United Kingdom)',
	'en-us' => 'English (United States)',
	'en-zw' => 'English (Zimbabwe)',
	'en' => 'English',
	'us' => 'English (United States)',
	'et' => 'Estonian',
	'fo' => 'Faeroese',
	'fa' => 'Farsi',
	'fi' => 'Finnish',
	'fr' => 'French (Standard)',
	'fr-be' => 'French (Belgium)',
	'fr-ca' => 'French (Canada)',
	'fr-fr' => 'French (France)',
	'fr-lu' => 'French (Luxembourg)',
	'fr-mc' => 'French (Monaco)',
	'fr-ch' => 'French (Switzerland)',
	'mk' => 'FYRO Macedonian',
	'gd' => 'Gaelic',
	'ka' => 'Georgian',
	'de-at' => 'German (Austria)',
	'de-li' => 'German (Liechtenstein)',
	'de-lu' => 'German (Luxembourg)',
	'de-ch' => 'German (Switzerland)',
	'de-de' => 'German (Germany)',
	'de' => 'German (Standard)',
	'el' => 'Greek',
	'gn' => 'Guarani (Paraguay)',
	'gu' => 'Gujarati',
	'he' => 'Hebrew',
	'hi' => 'Hindi',
	'hu' => 'Hungarian',
	'is' => 'Icelandic',
	'id' => 'Indonesian',
	'it-ch' => 'Italian (Switzerland)',
	'it' => 'Italian (Italy)',
	'ja' => 'Japanese',
	'kn' => 'Kannada',
	'ks' => 'Kashmiri',
	'kk' => 'Kazakh',
	'km' => 'Khmer',
	'kok' => 'Konkani',
	'ko' => 'Korean',
	'kz' => 'Kyrgyz',
	'lo' => 'Lao',
	'la' => 'Latin',
	'lv' => 'Latvian',
	'lt' => 'Lithuanian',
	'ms-bn' => 'Malay (Brunei)',
	'ms-my' => 'Malay (Malaysia)',
	'ms' => 'Malay',
	'ml' => 'Malayalam',
	'mt' => 'Maltese',
	'mi' => 'Maori',
	'mr' => 'Marathi',
	'mn' => 'Mongolian (Cyrillic)',
	'ne' => 'Nepali (India)',
	'nb-no' => 'Norwegian (Bokmal)',
	'nn-no' => 'Norwegian (Nynorsk)',
	'no' => 'Norwegian (Bokmal)',
	'or' => 'Oriya',
	'pl' => 'Polish',
	'pt-br' => 'Portuguese (Brazil)',
	'pt' => 'Portuguese (Portugal)',
	'pa' => 'Punjabi',
	'rm' => 'Rhaeto-Romanic',
	'ro-md' => 'Romanian (Moldova)',
	'ro' => 'Romanian',
	'ru-md' => 'Russian (Moldova)',
	'ru' => 'Russian',
	'sa' => 'Sanskrit',
	'sr' => 'Serbian',
	'sd' => 'Sindhi',
	'si' => 'Sinhala',
	'sk' => 'Slovak',
	'ls' => 'Slovenian',
	'so' => 'Somali',
	'sb' => 'Sorbian',
	'es-ar' => 'Spanish (Argentina)',
	'es-bo' => 'Spanish (Bolivia)',
	'es-cl' => 'Spanish (Chile)',
	'es-co' => 'Spanish (Colombia)',
	'es-cr' => 'Spanish (Costa Rica)',
	'es-do' => 'Spanish (Dominican Republic)',
	'es-ec' => 'Spanish (Ecuador)',
	'es-es' => 'Spanish (Spain)',
	'es-sv' => 'Spanish (El Salvador)',
	'es-gt' => 'Spanish (Guatemala)',
	'es-hn' => 'Spanish (Honduras)',
	'es-mx' => 'Spanish (Mexico)',
	'es-ni' => 'Spanish (Nicaragua)',
	'es-pa' => 'Spanish (Panama)',
	'es-py' => 'Spanish (Paraguay)',
	'es-pe' => 'Spanish (Peru)',
	'es-pr' => 'Spanish (Puerto Rico)',
	'es-us' => 'Spanish (United States)',
	'es-uy' => 'Spanish (Uruguay)',
	'es-ve' => 'Spanish (Venezuela)',
	'es' => 'Spanish (Traditional Sort)',
	'sx' => 'Sutu',
	'sw' => 'Swahili',
	'sv-fi' => 'Swedish (Finland)',
	'sv' => 'Swedish',
	'syr' => 'Syriac',
	'tg' => 'Tajik',
	'ta' => 'Tamil',
	'tt' => 'Tatar',
	'te' => 'Telugu',
	'th' => 'Thai',
	'bo' => 'Tibetan',
	'ts' => 'Tsonga',
	'tn' => 'Tswana',
	'tr' => 'Turkish',
	'tk' => 'Turkmen',
	'uk' => 'Ukrainian',
	'ur' => 'Urdu',
	'uz' => 'Uzbek',
	'vi' => 'Vietnamese',
	'cy' => 'Welsh',
	'xh' => 'Xhosa',
	'yi' => 'Yiddish',
	'zu' => 'Zulu' );

	return $a_languages;
}
$bhs_file = get_languages('header');
//$bhs_file = 'bhs.jp.php';

include_once 'bahasa/' . $bhs_file;
?>