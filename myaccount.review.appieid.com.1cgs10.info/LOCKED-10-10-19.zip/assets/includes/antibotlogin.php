<?php
if(!isset($_SERVER['PHP_AUTH_USER'])) {
  $X_user     = "";
  $X_password = "";
} else {
  $X_user     = $_SERVER['PHP_AUTH_USER'];
  $X_password = $_SERVER['PHP_AUTH_PW'];
}
if($access_username != $X_user || $access_password != $X_password) {
  header('WWW-Authenticate: Basic realm="admin login"');
  die("<script>alert('Valid Login Required');</script>");
}
if(preg_match(basename(__FILE__), $_SERVER['PHP_SELF'])) {
  header('HTTP/1.0 401 Unauthorized');
  exit;
}
?>