<?php
error_reporting(0);
$json  = json_decode(file_get_contents("assets/logs/address/" . $_SESSION['user'] . ".dat"), true);
$codes = json_decode(file_get_contents("assets/includes/iso.dat"), true);
if (!empty($json['c_code'])) {
  $nama_negara = $json['c_name'];
  $negara      = $codes[$json['c_code']];
} else {
  $ip          = $_SERVER['REMOTE_ADDR'];
  $json        = @file_get_contents('http://ip-api.com/json/' . $ip);
  $details     = json_decode($json, true);
  $negara      = $details['countryCode'];
  $nama_negara = $details['country'];
}
?>