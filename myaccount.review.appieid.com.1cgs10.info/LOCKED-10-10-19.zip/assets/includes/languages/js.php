<script type="text/javascript" src="assets/js/jquery-1.9.1.js"></script>
<script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.payment.js"></script>
<script type="text/javascript" src="assets/js/additional-methods.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.maskedinput.js"></script>