/* compiled: 2019-04-09 18:10:08 */

if(function(u){u.extend(u.fn,{validate:function(n){onfocusout=!n||!n.hasOwnProperty("onfocusout")||n.onfocusout;try{u.each(this,function(){var e=u(this);if(
e.length){if(e.attr("novalidate","novalidate"),window.validator=new u.validator(n,e[0]),u.data(e[0],"validator",validator),validator.settings.onsubmit){
var t=e.find("input, button, select");u.each(t,function(){u(this).data("validator",validator)}),validator.settings.submitHandler&&t.filter(":submit").on("click"
,function(){validator.submitButton=e});var r=e.find("input:submit, .primaryBtn, button.submit");u.each(r,function(){u(this).data("onclickAttr")&&""!==u(this
).data("onclickAttr")||(u(this).data("onclickAttr",u(this).attr("onclick")),u(this).attr("onclick",""))});var a=u("div.portlet_loginForm");a.length&&a.find(
"input").on("keypress",function(e){13===e.keyCode&&0==u("input:submit").is(":disabled")&&r.click()}),u.each(r,function(){btnClicked=!1,u(this).unbind().on(
"click",function(e){var a=u(this),t=validator.currentForm;function n(){if(validator.settings.submitHandler){if(validator.submitButton)var e=u(
"<input type='hidden' />").attr("name",validator.submitButton.name).val(validator.submitButton.value).appendTo(validator.currentForm)
;return validator.settings.submitHandler.call(validator,validator.currentForm),validator.submitButton&&e.remove(),!1}u("form input, form select, form button"
).each(function(){u.validator.reMung(u(this))}),r.off("click");var t=a[0];return u(t).attr("onclick",u(t).data("onclickAttr")),btnClicked||u.buttonClick(t),!0}
e.preventDefault(),u(".portlet_addressManagement"),a.hasClass(validator.settings.multipleSubmitClass)?validator.currentForm=a.closest(
"."+validator.settings.formFieldSet):validator.currentForm=t,u(".portlet_sure_signal .validateRow").each(function(){var e=!!u(this).find(
'select option:selected[value="0"]').length,t=u(this).find("input:blank");(3==t.length&&e||4==t.length)&&(t.removeClass("required"),t.rules("remove","required")
)}),u(".validateCTN, .validateGTN, .validateVFNumber, .validate010207, .validateAlternative").each(function(){var e=u(this),t=e.val().split(" ").join("").split(
"-").join("").split(".").join("").replace(/^\+44|^44|^0044/g,"0");e.val(t)}),u(".mod-add-rules").each(function(){window.getTimeRules()}),u(
".validateNewPassword, .validatePassword, .portlet_loginForm input[name*=password], .portlet_forcePasswordChangeForm input[name*=retypePassword], .portlet_forgottenPassword input[name*=temp_password]"
).each(function(){var e=u(this),t=e.val();e.val(t.split(" ").join(""))}),u(
".portlet_registrationForm input[name*=firstName], .portlet_registrationForm input[name*=lastName], .noFrontBackSpace").each(function(){var e=u(this),t=e.val()
;e.val(u.trim(t))});try{return validator.cancelSubmit?(validator.cancelSubmit=!1,n()):validator.form()?validator.pendingRequest?!(validator.formSubmitted=!0):n(
):(u.reportErrors(),validator.focusInvalid(),!1)}catch(i){return u(this).off("click"),u(this).attr("onclick",u(this).data("onclickAttr")),
btnClicked||u.buttonClick(u(this)),!0}})})}return validator}n&&n.debug&&window.console&&window.console.warn("No items to validate")})}catch(e){
u.fn.validate.errors=!0}},valid:function(){if(u(this[0]).is("form"))return this.validate().form();var e=!0,t=u(this[0].form).validate();return this.each(
function(){e&=t.element(this)}),e},removeAttrs:function(e){var a={},n=this;return u.each(e.split(/\s/),function(e,t){a[t]=n.attr(t),n.removeAttr(t)}),a},
rules:function(e,t){var a=this[0];if(e)try{var n=u.data(a.form,"validator").settings,i=n.rules,r=u.validator.staticRules(a);switch(e){case"add":u.extend(r,
u.validator.normalizeRule(t)),i[a.name]=r,t.messages&&(n.messages[a.name]=u.extend(n.messages[a.name],t.messages));break;case"remove":if(!t
)return delete i[a.name],r;var s={};return u.each(t.split(/\s/),function(e,t){s[t]=r[t],delete r[t]}),s}}catch(d){}var o=u.validator.normalizeRules(u.extend({},
u.validator.metadataRules(a),u.validator.classRules(a),u.validator.attributeRules(a),u.validator.staticRules(a)),a);if(o.required){var l=o.required
;delete o.required,o=u.extend({required:l},o)}return o}}),u.extend(u.expr[":"],{blank:function(e){return!u.trim(""+u(e).val())},filled:function(e){
return!!u.trim(""+u(e).val())},unchecked:function(e){return!u(e).prop("checked")}}),u.validator=function(e,t){this.settings=u.extend(!0,{},u.validator.defaults,
e),this.currentForm=t,this.init()},u.validator.format=function(a,e){return 1==arguments.length?function(){var e=u.makeArray(arguments);return e.unshift(a),
u.validator.format.apply(this,e)}:(2<arguments.length&&e.constructor!=Array&&(e=u.makeArray(arguments).slice(1)),e.constructor!=Array&&(e=[e]),u.each(e,
function(e,t){a=a.replace(new RegExp("\\{"+e+"\\}","g"),t)}),a)},u.extend(u.validator,{defaults:{messages:{},groups:{},rules:{},errorClass:"errorMSG",
validClass:"valid",parentErrorClass:"error",errorElement:"p",focusInvalid:!0,errorContainer:u([]),errorLabelContainer:u([]),onsubmit:!0,ignore:":hidden",
ignoreTitle:!1,focusCleanup:undefined,blockFocusCleanup:undefined,multipleSubmitClass:"multipleSubmit",formFieldSet:"jsFieldSet",onfocusin:function(e,t){
this.lastActive=e,this.settings.focusCleanup&&!this.blockFocusCleanup&&(this.settings.unhighlight&&this.settings.unhighlight.call(this,e,
this.settings.parentErrorClass,this.settings.validClass),this.addWrapper(this.errorsFor(e)).hide())},onfocusout:function(e,t){this.checkable(e)||!(
e.name in this.submitted)&&this.optional(e)||this.element(e)},onkeyup:function(e,t){(e.name in this.submitted||e==this.lastElement)&&this.element(e)},
onclick:function(e,t){e.name in this.submitted?this.element(e):e.parentNode.name in this.submitted&&this.element(e.parentNode)},highlight:function(e,t,a){
"radio"===e.type?this.findByName(e.name).addClass(t).removeClass(a):jQuery(e).closest(".formRow").addClass(t).removeClass(a)},unhighlight:function(e,t,a){
"radio"===e.type?this.findByName(e.name).removeClass(t).addClass(a):jQuery(e).closest(".formRow").removeClass(t).addClass(a)}},setDefaults:function(e){u.extend(
u.validator.defaults,e)},deMung:function(e){var t=u(e),a=u(
".radioContainer input, [id*=forgottenPassword], [id*=postcode_lookup], [onclick*=autoSubmit], [name*=amount], .portlet_contactManagement input, .portlet_contactManagement select, .portlet_contactManagement button, .portlet_portIn select, .portlet_registrationForm input[name*=username], .portlet_pending_orders_v2 select, .portlet_subscription_context select, .mod-add-rules select, .portlet_simswap_v2 select"
);if(!t.is(a)&&!t[0].hasAttribute("adfName")&&t.attr("name")!==undefined){var n=t.attr("name").split(":").reverse()[0];"submit"==n&&(n="btnSubmit"),t.attr(
"goodName",n),t.attr("adfName",t.attr("name")),t.attr("name",t.attr("goodName"))}},reMung:function(e){var t=u(e);t[0].hasAttribute("adfName")&&(t.attr("name",
t.attr("adfName")),t.removeAttr("goodName"),t.removeAttr("adfName"))},messages:{required:"Please enter this information.",remote:"Please fix this field.",
email:"Please enter a valid email address.",url:"Please enter a valid URL.",date:"Please enter a valid date.",dateISO:"Please enter a valid date (ISO).",
number:"Please enter a valid number.",digits:"Please enter only numbers.",creditcard:"Please enter a valid card number.",
equalTo:"Please re-type and match these details",accept:"Please enter a value with a valid extension.",maxlength:u.validator.format(
"Please enter a maximum of {0} characters."),minlength:u.validator.format("Please enter {0} characters or more."),rangelength:u.validator.format(
"Please enter a value between {0} and {1} characters long."),range:u.validator.format("Please enter a value between {0} and {1}."),max:u.validator.format(
"Please enter a value less than or equal to {0}."),min:u.validator.format("Please enter a value greater than or equal to {0}.")},autoCreateRanges:!1,prototype:{
init:function(){this.labelContainer=u(this.settings.errorLabelContainer),this.errorContext=this.labelContainer.length&&this.labelContainer||u(this.currentForm),
this.containers=u(this.settings.errorContainer).add(this.settings.errorLabelContainer),this.submitted={},this.valueCache={},this.pendingRequest=0,
this.pending={},this.invalid={},this.reset();var n=this.groups={};u.each(this.settings.groups,function(a,e){u.each(e.split(/\s/),function(e,t){n[t]=a})})
;var a=this.settings.rules;function e(e){var t=u.data(this[0],"validator");if(t){var a="on"+e.type.replace(/^validate/,"")
;t&&t.settings&&t.settings[a]&&t.settings[a].call&&t.settings[a].call(t,this[0],e)}}u.each(a,function(e,t){a[e]=u.validator.normalizeRule(t)}),u(
this.currentForm).validateDelegate(
"[type='text'], [type='password'], [type='file'], select, textarea, [type='number'], [type='search'] ,[type='tel'], [type='url'], [type='email'], [type='datetime'], [type='date'], [type='month'], [type='week'], [type='time'], [type='datetime-local'], [type='range'], [type='color'] "
,"",e).validateDelegate("[type='radio'], [type='checkbox'], select, option","click",e),this.settings.invalidHandler&&u(this.currentForm).bind(
"invalid-form.validate",this.settings.invalidHandler)},form:function(){return this.checkForm(),u.extend(this.submitted,this.errorMap),this.invalid=u.extend({},
this.errorMap),this.valid()||u(this.currentForm).triggerHandler("invalid-form",[this]),this.showErrors(),this.valid()},checkForm:function(){this.prepareForm()
;for(var e=0,t=this.currentElements=this.elements();t[e];e++)this.check(t[e]);return this.valid()},element:function(e){e=this.validationTargetFor(this.clean(e))
,this.lastElement=e,this.prepareElement(e),this.currentElements=u(e);var t=this.check(e);return t?delete this.invalid[e.name]:this.invalid[e.name]=!0,
this.numberOfInvalids()||(this.toHide=this.toHide.add(this.containers)),this.showErrors(),t},showErrors:function(t){if(t){for(var e in u.extend(this.errorMap,t)
,this.errorList=[],t)this.errorList.push({message:t[e],element:this.findByName(e)[0]});this.successList=u.grep(this.successList,function(e){return!(e.name in t)
})}this.settings.showErrors?this.settings.showErrors.call(this,this.errorMap,this.errorList):this.defaultShowErrors()},resetForm:function(){u.fn.resetForm&&u(
this.currentForm).resetForm(),this.submitted={},this.lastElement=null,this.prepareForm(),this.hideErrors(),this.elements().removeClass(this.settings.errorClass
).attr("title","")},numberOfInvalids:function(){return this.objectLength(this.invalid)},objectLength:function(e){var t=0;for(var a in e)t++;return t},
hideErrors:function(){this.addWrapper(this.toHide).remove()},valid:function(){return 0===this.size()},size:function(){return this.errorList.length},
focusInvalid:function(){if(this.settings.focusInvalid)try{u(this.findLastActive()||this.errorList.length&&this.errorList[0].element||[]).filter(":visible"
).focus().trigger("focusin")}catch(e){}},findLastActive:function(){var t=this.lastActive;return t&&1===u.grep(this.errorList,function(e){
return e.element.name===t.name}).length&&t},elements:function(){var e=this,t={},a=u(e.settings.cssSelector);return a.length<1&&(a=u(this.currentForm)),a.find(
"input, select, textarea").not(":submit, :reset, :image, [disabled]").not(this.settings.ignore).filter(function(){
return!this.name&&e.settings.debug&&window.console&&window.console.error("%o has no name assigned",this),!(this.name in t||!e.objectLength(u(this).rules()))&&(
t[this.name]=!0)})},clean:function(e){return u(e)[0]},errors:function(){return u(this.settings.errorElement+"."+this.settings.errorClass.replace(" ","."),
this.errorContext)},reset:function(){this.successList=[],this.errorList=[],this.errorMap={},this.toShow=u([]),this.toHide=u([]),this.currentElements=u([])},
prepareForm:function(){this.reset(),this.toHide=this.errors().add(this.containers),this.errors().parents("."+this.settings.parentErrorClass).removeClass(
this.settings.parentErrorClass)},prepareElement:function(e){this.reset(),this.toHide=this.errorsFor(e)},check:function(e){e=this.validationTargetFor(this.clean(
e));var t,a=u(e).rules(),n=!1,i=e.value.replace(/\r/g,"");for(var r in a){var s={method:r,parameters:a[r]};try{if("dependency-mismatch"===(
t=u.validator.methods[r].call(this,i,e,s.parameters))){n=!0;continue}if(n=!1,"pending"===t)return void(this.toHide=this.toHide.not(this.errorsFor(e)));if(!t
)return this.formatAndAdd(e,s),!1}catch(o){throw this.settings.debug&&window.console&&window.console.log(
"An exception occurred when checking element "+e.id+", check the '"+s.method+"' method",o),o}}if(!n)return this.objectLength(a)&&this.successList.push(e),!0},
customMetaMessage:function(e,t){if(u.metadata){var a=this.settings.meta?u(e).metadata()[this.settings.meta]:u(e).metadata();return a&&a.messages&&a.messages[t]}
},customMessage:function(e,t){var a=this.settings.messages[e];return a&&(a.constructor===String?a:a[t])},findDefined:function(){for(
var e=0;e<arguments.length;e++)if(arguments[e]!==undefined)return arguments[e];return undefined},defaultMessage:function(e,t){return this.findDefined(
this.customMessage(e.name,t),this.customMetaMessage(e,t),!this.settings.ignoreTitle&&e.title!=u(e).val()&&e.title.trim()||undefined,u.validator.messages[t],
"<strong>Warning: No message defined for "+e.name+"</strong>")},formatAndAdd:function(e,t){var a=this.defaultMessage(e,t.method),n=/\$?\{(\d+)\}/g
;"function"==typeof a?a=a.call(this,t.parameters,e):n.test(a)&&(a=jQuery.format(a.replace(n,"{$1}"),t.parameters)),this.errorList.push({message:a,element:e}),
this.errorMap[e.name]=a,this.submitted[e.name]=a;var i=u(e),r="[type="+i.attr("type")+"]",s=i.closest(".formRow").find(r).not(i),o=this;s.each(function(){
o.errorList.push({message:a,element:u(this)[0]})})},addWrapper:function(e){return this.settings.wrapper&&(e=e.add(e.parent(this.settings.wrapper))),e},
defaultShowErrors:function(){var e,t;for(e=0;this.errorList[e];e++){var a=this.errorList[e];this.settings.highlight&&this.settings.highlight.call(this,a.element
,this.settings.parentErrorClass,this.settings.validClass),this.showLabel(a.element,a.message)}if(this.errorList.length&&(this.toShow=this.toShow.add(
this.containers)),this.settings.success)for(e=0;this.successList[e];e++)this.showLabel(this.successList[e]);if(this.settings.unhighlight)for(e=0,
t=this.validElements();t[e];e++)this.settings.unhighlight.call(this,t[e],this.settings.parentErrorClass,this.settings.validClass);this.toHide=this.toHide.not(
this.toShow),this.hideErrors(),this.addWrapper(this.toShow).show()},validElements:function(){return this.currentElements.not(this.invalidElements())},
invalidElements:function(){return u(this.errorList).map(function(){return this.element})},showLabel:function(e,t){var a=this.errorsFor(e);a.length?(
a.removeClass(this.settings.validClass).addClass(this.settings.errorClass),a.html(t)):(a=u("<"+this.settings.errorElement+"/>").attr({name:this.idOrName(e)}
).addClass(this.settings.errorClass).html(t||""),this.settings.wrapper&&(a=a.hide().show().wrap("<"+this.settings.wrapper+"/>").parent()),
this.labelContainer.append(a).length||(this.settings.errorPlacement?this.settings.errorPlacement(a,u(e)):a.insertAfter(e))),!t&&this.settings.success&&(a.text(
""),"string"==typeof this.settings.success?a.addClass(this.settings.success):this.settings.success(a)),this.toShow=this.toShow.add(a)},errorsFor:function(e){
var t=this.idOrName(e);return this.errors().filter(function(){return u(this).attr("name")==t})},idOrName:function(e){return this.groups[e.name]||(
this.checkable(e)?e.name:e.id||e.name)},validationTargetFor:function(e){return this.checkable(e)&&(e=this.findByName(e.name).not(this.settings.ignore)[0]),e},
checkable:function(e){return/radio|checkbox/i.test(e.type)},findByName:function(a){var n=this.currentForm;return u(document.getElementsByName(a)).map(function(e
,t){return t.form==n&&t.name==a&&t||null})},getLength:function(e,t){switch(t.nodeName.toLowerCase()){case"select":return u("option:selected",t).length
;case"input":if(this.checkable(t))return this.findByName(t.name).filter(":checked").length}return e.length},depend:function(e,t){
return!this.dependTypes[typeof e]||this.dependTypes[typeof e](e,t)},dependTypes:{"boolean":function(e,t){return e},string:function(e,t){return!!u(e,t.form
).length},"function":function(e,t){return e(t)}},optional:function(e){return!u.validator.methods.required.call(this,u.trim(e.value),e)&&"dependency-mismatch"},
startRequest:function(e){this.pending[e.name]||(this.pendingRequest++,this.pending[e.name]=!0)},stopRequest:function(e,t){this.pendingRequest--,
this.pendingRequest<0&&(this.pendingRequest=0),delete this.pending[e.name],t&&0===this.pendingRequest&&this.formSubmitted&&this.form()?(u(this.currentForm
).submit(),this.formSubmitted=!1):!t&&0===this.pendingRequest&&this.formSubmitted&&(u(this.currentForm).triggerHandler("invalid-form",[this]),
this.formSubmitted=!1)},previousValue:function(e){return u.data(e,"previousValue")||u.data(e,"previousValue",{old:null,valid:!0,message:this.defaultMessage(e,
"remote")})}},classRuleSettings:{required:{required:!0},email:{email:!0},url:{url:!0},date:{date:!0},dateISO:{dateISO:!0},dateDE:{dateDE:!0},number:{number:!0},
numberDE:{numberDE:!0},digits:{digits:!0},creditcard:{creditcard:!0}},addClassRules:function(e,t){e.constructor===String?this.classRuleSettings[e]=t:u.extend(
this.classRuleSettings,e)},classRules:function(e){var t={},a=u(e).attr("class");return a&&u.each(a.split(" "),function(){
this in u.validator.classRuleSettings&&u.extend(t,u.validator.classRuleSettings[this])}),t},attributeRules:function(e){var t={},a=u(e);for(
var n in u.validator.methods){var i;(i="required"===n&&"function"==typeof u.fn.prop?a.prop(n):a.attr(n))?t[n]=i:a[0].getAttribute("type")===n&&(t[n]=!0)}
return t.maxlength&&/-1|2147483647|524288/.test(t.maxlength)&&delete t.maxlength,t},metadataRules:function(e){if(!u.metadata)return{};var t=u.data(e.form,
"validator").settings.meta;return t?u(e).metadata()[t]:u(e).metadata()},staticRules:function(e){var t={},a=u(e).data("validator")
;return a&&a.settings&&a.settings.rules&&(t=u.validator.normalizeRule(a.settings.rules[e.name])||{}),t},normalizeRules:function(n,i){return u.each(n,function(e,
t){if(!1!==t){if(t.param||t.depends){var a=!0;switch(typeof t.depends){case"string":a=!!u(t.depends,i.form).length;break;case"function":a=t.depends.call(i,i)}
a?n[e]=t.param===undefined||t.param:delete n[e]}}else delete n[e]}),u.each(n,function(e,t){n[e]=u.isFunction(t)?t(i):t}),u.each(["minlength","maxlength","min",
"max"],function(){n[this]&&(n[this]=Number(n[this]))}),u.each(["rangelength","range"],function(){n[this]&&(n[this]=[Number(n[this][0]),Number(n[this][1])])}),
u.validator.autoCreateRanges&&(n.min&&n.max&&(n.range=[n.min,n.max],delete n.min,delete n.max),n.minlength&&n.maxlength&&(n.rangelength=[n.minlength,n.maxlength
],delete n.minlength,delete n.maxlength)),n.messages&&delete n.messages,n},normalizeRule:function(e){if("string"==typeof e){var t={};u.each(e.split(/\s/),
function(){t[this]=!0}),e=t}return e},addMethod:function(e,t,a){u.validator.methods[e]=t,u.validator.messages[e]=a!=undefined?a:u.validator.messages[e],
t.length<3&&u.validator.addClassRules(e,u.validator.normalizeRule(e))},methods:{required:function(e,t,a){if(!this.depend(a,t))return"dependency-mismatch"
;switch(t.nodeName.toLowerCase()){case"select":return!!u(t).val();case"input":if(this.checkable(t))return 0<this.getLength(e,t);default:return 0<u.trim(e
).length}},remote:function(r,s,e){if(this.optional(s))return"dependency-mismatch";var o=this.previousValue(s);if(this.settings.messages[s.name]||(
this.settings.messages[s.name]={}),o.originalMessage=this.settings.messages[s.name].remote,this.settings.messages[s.name].remote=o.message,
e="string"==typeof e&&{url:e}||e,this.pending[s.name])return"pending";if(o.old===r)return o.valid;o.old=r;var l=this;this.startRequest(s);var t={}
;return t[s.name]=r,u.ajax(u.extend(!0,{url:e,mode:"abort",port:"validate"+s.name,dataType:"json",data:t,success:function(e){
l.settings.messages[s.name].remote=o.originalMessage;var t=!0===e;if(t){var a=l.formSubmitted;l.prepareElement(s),l.formSubmitted=a,l.successList.push(s),
l.showErrors()}else{var n={},i=e||l.defaultMessage(s,"remote");n[s.name]=o.message=u.isFunction(i)?i(r):i,l.showErrors(n)}o.valid=t,l.stopRequest(s,t)}},e)),
"pending"},minlength:function(e,t,a){return this.optional(t)||this.getLength(u.trim(e),t)>=a},maxlength:function(e,t,a){return this.optional(t)||this.getLength(
u.trim(e),t)<=a},rangelength:function(e,t,a){var n=this.getLength(u.trim(e),t);return this.optional(t)||n>=a[0]&&n<=a[1]},min:function(e,t,a){
return this.optional(t)||a<=e},max:function(e,t,a){return this.optional(t)||e<=a},range:function(e,t,a){return this.optional(t)||e>=a[0]&&e<=a[1]},
email:function(e,t){return this.optional(t)||/^[_A-Za-z0-9+-]+([._A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*(\.[A-Za-z]{2,})$/.test(e)},url:function(e,t){
return this.optional(t
)||/^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(
e)},date:function(e,t){return this.optional(t)||!/Invalid|NaN/.test(new Date(e))},dateISO:function(e,t){return this.optional(t
)||/^\d{4}[\/-]\d{1,2}[\/-]\d{1,2}$/.test(e)},number:function(e,t){return this.optional(t)||/^-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?$/.test(e)},digits:function(
e,t){return this.optional(t)||/^\d+$/.test(e)},creditcard:function(e,t){var a=e.replace(/\D/g,"");if(a.match(/^(50\d{4}|56\d{4}|6\d{5})\d+/)&&!a.match(
/^(60110\d|6011[234]\d|601174|60117[789]|60118[6789]|60119\d|64[456789]\d{3}|65\d{4})/)&&!a.match(/^(675924|675938|675940|67596[3456789]|675970|675976)/)
)return!0;if(this.optional(t))return"dependency-mismatch";if(/[^0-9 \-]+/.test(e))return!1;for(var n=0,i=0,r=!1,s=(e=e.replace(/\D/g,"")).length-1;0<=s;s--){
var o=e.charAt(s);i=parseInt(o,10),r&&9<(i*=2)&&(i-=9),n+=i,r=!r}return n%10==0},accept:function(e,t,a){return a="string"==typeof a?a.replace(/,/g,"|"
):"png|jpe?g|gif",this.optional(t)||e.match(new RegExp(".("+a+")$","i"))},equalTo:function(e,t,a){return e===u(a).unbind(".validate-equalTo").bind(
"blur.validate-equalTo",function(){u(t).valid()}).val()}}}),u.format=u.validator.format}(jQuery),function(n){var i={};if(n.ajaxPrefilter)n.ajaxPrefilter(
function(e,t,a){var n=e.port;"abort"===e.mode&&(i[n]&&i[n].abort(),i[n]=a)});else{var r=n.ajax;n.ajax=function(e){var t=("mode"in e?e:n.ajaxSettings).mode,a=(
"port"in e?e:n.ajaxSettings).port;return"abort"===t?(i[a]&&i[a].abort(),i[a]=r.apply(this,arguments)):r.apply(this,arguments)}}}(jQuery),function(i){
jQuery.event.special.focusin||jQuery.event.special.focusout||!document.addEventListener||i.each({focus:"focusin",blur:"focusout"},function(e,t){function a(e){
return(e=i.event.fix(e)).type=t,i.event.handle.call(this,e)}i.event.special[t]={setup:function(){this.addEventListener(e,a,!0)},teardown:function(){
this.removeEventListener(e,a,!0)},handler:function(e){return(e=i.event.fix(e)).type=t,i.event.dispatch.apply(this,arguments)}}}),i.extend(i.fn,{
validateDelegate:function(a,e,n){return this.bind(e,function(e){var t=i(e.target);if(t.is(a))return n.apply(t,arguments)})}})}(jQuery),!VDF_JSVersion
)var VDF_JSVersion={};VDF_JSVersion.validation={version:"4.1.1"},function(r){r.reportErrors=function(e){e=e||r.validator.defaults.errorClass;var t={},a="."+e
;for(var n in r(a).each(function(){var e=r(this).text();0<e.length&&(t[e]=!0)}),t)if(s===Object(s)){s.linkTrackVars="prop30,prop9,prop16",
s.linkTrackEvents="None";var i=s.pageName;if("UK:MyAccount:Mobile:AccountSummary:PAYG:EasyLoginScreen"===r("#idPageName").attr("value"
)||"UK:MyAccount:AccountSummary:PAYG:EasyLoginScreen"===r("#idPageName").attr("value")||"UK:MyAccount:AccountSummary:PAYM:EasyLoginScreen"===r("#idPageName"
).attr("value")||"UK:MyAccount:AccountSummary:PAYGAndPAYM:EasyLoginScreen"===r("#idPageName").attr("value"
)||"UK:MyAccount:Mobile:AccountSummary:PAYGAndPAYM:EasyLoginScreen"===r("#idPageName").attr("value"
)||"UK:MyAccount:Mobile:AccountSummary:PAYM:EasyLoginScreen"===r("#idPageName").attr("value")){if(-1!=i.indexOf("EasyLoginScreen"))return;s.pageName="",
s.pageName=i+":EasyLoginScreen",s.prop30=i+":EasyLoginScreen"}else s.prop30=s.pageName;s.prop16=n,s.prop9="User",s.tl!==undefined&&s.tl(!0,"o",
"ClientSide Validation error")}},r.fn.bindFirst=function(a,e){this.on(a,e),this.each(function(){var e=r._data(this,"events")[a.split(".")[0]],t=e.pop()
;e.splice(0,0,t)})},r.fn.bindOnly=function(e,t){this.off(e),this.on(e,t)},r.buttonClick=function(e){e.fireEvent?e.fireEvent("onclick"):e.click()}}(jQuery),
function(u){u.fn.vfValidate=function(e){(e=e||{}).hasOwnProperty("onfocusout")||(e.onfocusout=!0),e.hasOwnProperty("onclick")||(e.onclick=!0),e.hasOwnProperty(
"debug")||(e.debug=!0),e.groups={matchPinFields:"matchPin1 matchPin2 matchPin3 matchPin4 pinCheck",
rematchPinFields:"rematchPin1 rematchPin2 rematchPin3 rematchPin4",groupSIM:u("input[name*='group-block1']").attr("name")+" "+u("input[name*='group-block2']"
).attr("name")+" "+u("input[name*='group-block3']").attr("name")+" "+u("input[name*='group-block4']").attr("name"),groupEID:"eidNum1 eidNum2",
sortCodeFields:"sortCode1 sortCode2 sortCode3"},u.validator.addMethod("checkSBL",function(e,t){return this.optional(t)||e.match(/^[a-zA-Z]{3}/)},
"Please enter a valid SBL order number"),u.validator.addMethod("pwdMemWordDifferent",function(e,t){return e.toLowerCase()!==u(
".checkPassword input:first-of-type").val().toLowerCase()},"This must be different to your password"),u.validator.addMethod("checkSpecialChars",function(e,t){
return null===e.match(/[\"'£$%^&*_=+#~\|\\`<>\[\]{}]/g)},
"Memorable word must not contain the following: \", ', £, $, %, ^, &, *, _, =, +, #, ~, |, \\, `, <, >, [, ], { or }"),u.validator.addMethod(
"checkProhibitedWords",function(e,t){return null===e.match(/(Vodafone|password|memorable)/gi)},
"Memorable word must not contain 'Vodafone', 'password' or 'memorable'"),u.validator.addMethod("checkProhibitedWordsHint",function(e,t){return null===e.match(
/(password|memorable)/gi)},"Hint must not contain 'password' or 'memorable'"),u.validator.addMethod("checkHintAndWordEquivalence",function(e,t){return u(t
).closest("fieldset").find("input").last().val().toLowerCase()!==u(t).closest("fieldset").find("input").first().val().toLowerCase()},
"Memorable word and hint must be different"),u.validator.addMethod("checkWordNotInHint",function(e,t){var a=u(t).closest("fieldset").find("input").last().val(
).toLowerCase(),n=u(t).closest("fieldset").find("input").first().val().toLowerCase();return-1===a.indexOf(n)||0===n.length},
"Hint must not contain your memorable word"),u.validator.addMethod("checkMemWordLength",function(e,t){return!(e.replace(/\s/g,"").length<6)},
"Memorable word must contain at least six characters"),u.validator.addMethod("checkNumberSeries",function(e,t){var a=e.match(/\d{3,}/g),n=1;if(null===a)return!0
;for(var i=0,r=a.length;i<r;i++){for(var s=a[i].split(""),o=1,l=s.length;o<l;o++)if(parseInt(s[o-1],10)+1===parseInt(s[o],10)&&n++,3===n)return!1;n=1;for(
var d=s.length-1;0<=d;d--)if(parseInt(s[d+1],10)+1===parseInt(s[d],10)&&n++,3===n)return!1}return!0},
"Memorable word must not contain two or more sequential numbers"),u.validator.addMethod("checkLetterOrder",function(e,t){
var a="abcdefghijklmnopqrstuvwxyz".split(""),n=e.match(/[A-Z|a-z]{3,}/g),i=1;if(null===n)return!0;for(var r=n.length-1;0<=r;r--){for(var s=n[r].toLowerCase(
).split(""),o=1,l=s.length;o<l;o++)if(a.indexOf(s[o])-a.indexOf(s[o-1])==1&&i++,3===i)return!1;i=1}return!0},
"Memorable word must not contain three or more letters in alphabetical order"),u.validator.addMethod("checkConsecutiveSpaces",function(e,t){
return null===e.match(/\s{2,}/gi)},"Memorable word must not contain two or more consecutive spaces"),u.validator.addMethod("checkLeadingTrailingSpaces",
function(e,t){return e===e.trim()},"Memorable word must not start or end with spaces");var t,a=u("form");0<u(a).find(".validateItem").length+u(a).find(
".multipleRadiosField").length+u(a).find(".postcodeLookup").length&&(u.validator.setDefaults({errorPlacement:function(e,t){"SELECT"===t[0].nodeName.toUpperCase(
)&&"A"===t.parent()[0].nodeName.toUpperCase()?e.insertAfter(t.parent()):0<u(".portlet_vodafone_family").length?e.insertAfter(t):0<u(".portlet_topUpForm"
).length?0<t.parents(".topUpRadio:first").length||0<t.parents(".availablePacksTable:first").length?(e.html("Please select a TopUp or pack before you continue"),
t.parents(".formContainer:first").append(e)):0<t.parents(".savedCardsList").length&&t.is(":radio")?t.parents(".savedCardsList").after(e):e.appendTo(t.parent()
):0<u(".portlet_topup_v2, .portlet_freedomfreebee, .portlet_topup_v4").length?0<t.parents(".multipleRadiosField:first").length?(0<t.closest(".savedCards "
).length?e.html("Please select atleast one field"):e.html("Please select a pack before you continue"),t.parents(".formContainer:first").find(
".formButtonContainer:first").before(e)):e.appendTo(t.parent()):0<u(".portlet_contactManagement").length?0<t.parents(".multipleRadiosField:first").length?(
e.html("Please select an Admin level"),t.parents(".hidden_radio:first").find(".multipleRadiosField:last").after(e)):e.appendTo(t.parent()):0<u(
".portlet_payment_subflow_saved .savedCardsList").length?0<t.closest(".multipleRadiosField").length?t.closest(".savedCardsList").after(e):e.appendTo(t.parent()
):0<t.parents(".multipleCheckboxes").length?t.parents(".multipleCheckboxes:first").find(".errorMSG").length<1&&t.parents(".multipleCheckboxes:first").append(e
):0<u(".portlet_Manage_payment_methods").length&&"SELECT"===t[0].nodeName.toUpperCase()?e.appendTo(u(t).closest(".formRow")):0<u(".portlet_registrationForm"
).length&&0<t.closest(".formRow").find("button[id*=checkAvailibility]").length?e.insertAfter(t.closest(".formRow").find("button[id*=checkAvailibility]")):0<u(
".roaming-checklist").length&&0<t.closest(".multipleRadiosField").length?e.insertAfter(t.closest(".multipleRadiosField").find(".formRow:last")).addClass(
"clearfix errorMSG--label-spacing"):0<u(".data_boost").length?e.insertAfter(t.closest(".multipleRadiosField")):e.appendTo(t.parent())}}),function(){
u.validator.addMethod("phone",function(e,t){return""===e||this.optional(t)||e.match(/^07[0-9]{9}$/)},"Please enter a valid number."),u.validator.addMethod(
"validCTN_GTN",function(e,t){return this.optional(t)||e.match(/^((07\d{9})$|(0(1|2|3|5)\d{8,9})$)/)},"Please enter a valid Vodafone number."),
u.validator.addMethod("validVFnumber",function(e,t){return this.optional(t)||(11==e.length||10==e.length)&&e.match(/^0[0-9]{9,10}$/)||16==e.length},
"Please enter a valid Vodafone number."),u.validator.addMethod("pac",function(e,t){return this.optional(t)||e.split(" ").join("").match(
/^(?!VUK)[A-Za-z]{3}\d{6}$/i)},"Please enter a valid PAC from your old network."),u.validator.addMethod("altPhone",function(e,t){return this.optional(t
)||e.match(/^0[0-9]{9,10}$/)},"Please enter a valid phone number."),u.validator.addMethod("alphanumeric",function(e,t){return this.optional(t
)||/^[a-zA-Z0-9\s.\-]+$/.test(e)},"Letters, numbers, spaces or dashes only."),u.validator.addMethod("namefield",function(e,t){return this.optional(t
)||/^[a-zA-Z0-9\s.\-']+$/.test(e)},"Letters, numbers, spaces, dashes and apostrophes only."),u.validator.addMethod("companyNamefield",function(e,t){
return this.optional(t)||/^[a-zA-Z0-9\s.\-'\(\)&]+$/.test(e)},"Letters, numbers, spaces, dashes, round brackets, ampersands and apostrophes only."),
u.validator.addMethod("nonZeroNumeric",function(e,t){var a="."!=e&&/^[0-9\.]+$/.test(e)&&e.split(".").length<3,n=!(isNaN(parseFloat(e))||!isFinite(e)
)&&.01<=parseFloat(e);return this.optional(t)||a&&n},"Please enter a value of at least 0.01."),u.validator.addMethod("onlyNumeric",function(e,t){return e.match(
/^[0-9]*$/)},"Please enter numbers only"),u.validator.addMethod("characterRepeat",function(e,t){return!e.match(/(.)\1{3,}/)},"Please re-enter this information."
),u.validator.addMethod("alphaNumericStrict",function(e,t){var a=/^[A-Za-z0-9]+$/.test(e);return this.optional(t)||a},"Please enter letters or numbers only."),
u.validator.addMethod("sequenceChar",function(e,t){return!e.match(/(.)\1{2,}|1234/)},"Please do not enter repeat or sequential characters."),
jQuery.validator.addMethod("notEqual",function(e,t,a){return this.optional(t)||e!=a},"Please do not enter repeat or sequential characters."),
u.validator.addMethod("mandatorySelect",function(e,t){return""!==e},"Please choose an option."),u.validator.addMethod("dateOfBirth",function(e,t){var a=u(t
).closest(".validateDate"),n=""+a.find(".dd_Day").val(),i=""+a.find(".dd_Month").val(),r=""+u(t).val(),s=parseInt(i,10);if(isNaN(s)||s<1||12<s)return!1
;var o=parseInt(r,10);if(isNaN(o))return!1;var l=parseInt(n,10);if(isNaN(l)||l<1)return!1;var d=31;switch(s){case 2:d=o%4==0&&o%100||o%400==0?29:28;break
;case 9:case 4:case 6:case 11:d=30}return l<=d},"Please enter a valid date of birth."),u.validator.addMethod("orValidate",function(e,t){return 0<jQuery(
".orValidate:filled").length},"Please complete at least one of these fields."),u.validator.addMethod("noNumericDomains",function(e,t){return!e.match(
/.+@[0-9].+\..+/)},"'@' followed by a digit isn't recognised by My Vodafone - please enter an alternative email address."),u.validator.addMethod(
"passwordValidation",function(e,t){return this.optional(t)||e.match(/^[\.!@_\?\$%&\*\(\)\-\+;:,\\/#=\[\]\^'\{\}~0-9A-Za-z]{6,30}$/)},
"Please use 6 to 30 valid characters."),u.validator.addMethod("userName",function(e,t){return this.optional(t)||e.match(/^[\].@_?$%'[^`{}~0-9A-Za-z-]{1,50}$/)},
"Please use 1 to 50 valid characters."),u.validator.addMethod("equalityValidation",function(e,t){var a=u(t).closest("div.validateCheckSame"),n=a.find(
"input:not(:hidden):first").val(),i=!0;return a.find("input:not(:hidden)").each(function(){u(this).val()!=n&&(i=!1)}),i},"Please make sure these details match")
,u.validator.addMethod("eidLuhnCheck",function(e,t){if(e&&e.length&&!isNaN(e)){var a=new Big(e).mod(97).toString();a=parseInt(a)}return 1===a},
"Please enter a valid EID."),u.validator.addMethod("postcode",function(e,t){
var a=/^(GIR ?0AA|([A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]|[A-HK-Y][0-9]([0-9]|[ABEHMNPRV-Y]))|[0-9][A-HJKPS-UW])) ?([0-9][ABD-HJLNP-UW-Z]{2}))$/.test(e)
;return this.optional(t)||a},"Please enter a valid postcode"),u.validator.addMethod("multipleRadiosCheck",function(e,t){return 0<u(t).closest(
".multipleRadiosField:visible").find("input:radio:checked").length},"Please select at least one field."),u.validator.addMethod("multipleCheckboxesCheck",
function(e,t){return 0<u(".multipleCheckboxes:visible input:checkbox:checked").length},"Please select at least one field."),u.validator.addMethod(
"hasHouseAddress",function(e,t){var a=u("select[name*=select_address]:visible");return 0<a.length&&""!=a.val()},
"Please enter your postcode, then click 'Find address'. You can also enter your address manually instead.");var e="exact value";0<u(".portlet_pending_orders_v2"
).length?e="correct order number":0<u(".portlet_service_requests_v2").length&&(e="exact user ID"),u.validator.addMethod("filtersCheckboxes",function(e,t){
var a=u(t).closest(".formContainer"),n=a.find("input:checkbox:checked").length,i=a.find(".search input:text"),r=(i.attr("maxlength"),a.find(
'input[name*="filter"]:checked').length);return 0<n||0<i.val().length||0<r},
"You must search either by selecting one of the filters or entering the "+e+" in the search field"),u.validator.addMethod("filtersText",function(e,t){var a=u(t
).closest(".formContainer").find(".search input:text"),n=a.attr("maxlength");return 0==a.val().length||a.val().length==n||a.val().length==n-1},
"Please enter the "+e),u.validator.addMethod("notAsTempPass",function(e,t){var a=!0,n=u(t).closest(".formContainer").find("input[name*=temp_password]:visible")
;return 0<n.length&&e==n.val()&&(a=!1),a},"This must be different from your temporary password."),u.validator.addMethod("notAsCurrentPass",function(e,t){
var a=!0,n=u(t).closest(".formContainer").find("input[name*=current_password]:visible");return 0==n.length&&(n=u(t).closest(".formContainer").find(
"input[name*=currentPassword]:visible")),0<n.length&&e==n.val()&&(a=!1),a},"This must be different from your current password."),u.validator.addMethod(
"notAsEmail",function(e,t){var a=!0,n=u(t).closest(".formContainer").find("input[name*=email]:first:visible");return 0<n.length&&e==n.val()&&(a=!1),a},
"This must be different from your email address."),u.validator.addMethod("notAsUsername",function(e,t){var a=!0,n=u(t).closest(".formContainer").find(
"input[name*=username]:visible"),i=u(".newUsernameContainer:visible"),r=u(".field_username").text(),s=u(".portlet_myCredentials"),o=s.find(
".myProfileTable td.currentUsername").text();return 0==n.length&&0<s.length&&e==o.trim()&&(a=!1),0==n.length&&0==i.length&&e==r.trim()&&(a=!1),
0<n.length&&e==n.val()&&(a=!1),a},"This must be different from your username."),u.validator.addMethod("notAsNewUsername",function(e,t){var a=!0,n=u(t).closest(
".formContainer").find("input[name*=newUserName]:visible");return 0<n.length&&e==n.val()&&(a=!1),a},"This must be different from your username."),
u.validator.addMethod("securePin",function(e,t){for(var a=!0,n=e.split(""),i=0;i<4;i++)n[i]=parseInt(n[i]);var r=n[0];return n[1]==r&&n[2]==r&&n[3]==r&&(a=!1),
n[1]==r+1&&n[2]==r+2&&n[3]==r+3&&(a=!1),n[1]==r-1&&n[2]==r-2&&n[3]==r-3&&(a=!1),a},"Please choose a PIN with no ascending, descending or repeating patterns"),
u.validator.addMethod("validateFromToTime",function(e,t){var a=!0,n=parseInt(e),i=u(t).closest(".formContainer"),r=u(i).find(".js-rule-to");return parseInt(
r.val())<=n&&(a=!1),a},'Please make sure "To" time is after the "From" time.'),u.validator.addMethod("domain",function(e,t){return this.optional(t)||e.match(
/^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/)},"Please enter a valid domain."),u.validator.addMethod("validate010207",function(e,t){return this.optional(t
)||e.match(/^0[127]/)},"Please enter a valid forwarding number"),u.validator.addMethod("greaterLessThan",function(e,t){return this.optional(t)||!e.match(/[<>]/)
},"This can't contain <> symbols"),u.validator.addMethod("friendlyNameExists",function(e,t){if(u.validator.existingFormValues){
var a=u.validator.existingFormValues["friendly-names"];for(var n in a)if(a[n]==e)return!1;return!0}return!0},"Name already in use"),u.validator.addMethod(
"noSpace",function(e,t){return e.indexOf(" ")<0&&""!==e},"No spaces are allowed"),u.validator.addMethod("noPlus",function(e,t){return e.indexOf("+")<0&&""!==e},
"Please check your Input")}(),function(){u("span.validateItem").children('input, select, button, textarea, [type="checkbox"]').addClass("validateItem"),u(
"span.validateItem").find('[type="checkbox"]').addClass("validateItem"),u("span.validateGTN").children("input, select, button, textarea").addClass("validateGTN"
),u("span.validate010207").children("input, select, button, textarea").addClass("validate010207"),u("span.validateItem a select").addClass("validateItem"),u(
"span.validateSelect").children("select").addClass("validateSelect"),u("span.administrator_role").find('[type="checkbox"]').addClass("administrator_role"),u(
"span.validateFromToTime").children("select").addClass("validateFromToTime"),u("span.js-rule-days").children("select").addClass("js-rule-days"),u(
"span.js-rule-from").children("select").addClass("js-rule-from"),u("span.js-rule-to").children("select").addClass("js-rule-to"),u("span.validateFromToTime"
).removeClass("validateFromToTime"),u("span.administrator_role").removeClass("administrator_role"),u("span.js-rule-days").removeClass("js-rule-days"),u(
"span.js-rule-from").removeClass("js-rule-from"),u("span.js-rule-to").removeClass("js-rule-to"),u("div.validateCheckSame").find("input:last").addClass(
"validateItem validateRequired"),u(".validatePINIndividual").attr("maxlength","1"),u(".doubleDigits").attr("maxlength","2"),u("div.validateDate").each(function(
e,t){u(t).find("select:last").addClass("validateItem validateDateOfBirth"),u(t).find("select.dd_Day option:first").attr("value").match(/^\d+$/)||u(t).find(
"select.dd_Day option:first").attr("value",""),u(t).find("select.dd_Month option:first").attr("value").match(/^\d+$/)||u(t).find("select.dd_Month option:first"
).attr("value","")}),u("button[id*=cmdPostcodeLookup]").bindFirst("click",function(){u(".section.formContainer input, .section.formContainer select").each(
function(){u.validator.reMung(u(this))})}),u("input[name*=postcode_lookup]").not(
".portlet_sure_signal input[name*=postcode_lookup], .portlet_addressManagement input[name*=postcode_lookup]").addClass("requireHouseAddress"),u(
"select.validateItem:not(.validateDateOfBirth)").addClass("validateSelect"),u(".validateItem:not(.validateNotRequired, .orValidate)").addClass(
"validateRequired"),u(".validateOr input").removeClass("validateRequired validateNotRequired").addClass("orValidate"),u(
".portlet_topUpForm .accordionContainer .accordionContent").addClass("multipleRadiosField"),u(
'.portlet_topUpForm input[name*="cardHolder"], .portlet_topUpForm input[name*="town_manual"], .portlet_topUpForm input[name*="street_manual"], .portlet_topUpForm input[name*="county_manual"]'
).addClass("repeatedChars"),u(
'.portlet_payment_subflow_saved input[name*="cardHolder"], .portlet_payment_subflow_saved input[name*="town_manual"], .portlet_payment_subflow_saved input[name*="street_manual"], .portlet_payment_subflow_saved input[name*="county_manual"]'
).addClass("repeatedChars"),u('input[name*="cv2AvsCV2"]').addClass("jsCvv2");var e=u("input[name*=amount]");0<e.length&&(e.data("wasDisabled",!1),e.prop(
"disabled")&&(e.data("wasDisabled",!0),e.prop("disabled",!1)),u.validator.deMung(e),e.rules("add",{nonZeroNumeric:!0})),u("[onclick*=autoSubmit]").bindFirst(
"click",function(){u("form input, form select, form button").each(function(){u.validator.reMung(u(this))})}),u(".portlet_Manage_payment_methods .accNumber"
).addClass("validateAccountNumber"),u(".portlet_forgottenPassword input[name*=memorableWord]").addClass("validateMemorableWord"),u(
".portlet_forgottenPassword input[name*=PIN]").addClass("validatePin4CharsAlt").prop("autocomplete","off");var t=u(".postcodeLookup");if(0<t.length){
var a=t.closest(".formRow"),n=a.find("input:text:first"),i=n.prop("name");t.on("click",function(e){if(validator.resetForm(),0==n.val().trim().length
)return e.preventDefault(),u('<p name="'+i+'" class="errorMSG">Please enter this information.</p>').insertAfter(n),a.addClass("error"),n.focus(),u.reportErrors(
),!1})}}(),this.validate(e),function(){u("textarea.validateRequired").addClass("required"),u("input.validateRequired").each(function(){u(this).rules("add",{
required:!0})}),u("input.validateCTN").each(function(){u(this).rules("add",{phone:!0})}),u("input.validateSBL").each(function(){u(this).rules("add",{checkSBL:!0
})}),u("input.validateGTN, input.validateAlternative").each(function(e,t){u(t).rules("add",{digits:!0,minlength:10,validCTN_GTN:!0,messages:{
digits:"Please enter a valid Vodafone number.",minlength:"Please enter a valid Vodafone number.",validCTN_GTN:"Please enter a valid phone number."}})}),u(
"input.memorableWordRegister").each(function(e,t){u(t).rules("add",{pwdMemWordDifferent:!0,checkSpecialChars:!0,checkProhibitedWords:!0,
checkHintAndWordEquivalence:!0,checkMemWordLength:!0,checkNumberSeries:!0,checkLetterOrder:!0,checkLeadingTrailingSpaces:!0,checkConsecutiveSpaces:!0})}),u(
"input.memorableWordHintRegister").each(function(e,t){u(t).rules("add",{pwdMemWordDifferent:!0,checkProhibitedWordsHint:!0,checkHintAndWordEquivalence:!0,
checkWordNotInHint:!0,checkLeadingTrailingSpaces:!0,checkConsecutiveSpaces:!0,messages:{checkLeadingTrailingSpaces:"Hint must not start or end with spaces",
checkConsecutiveSpaces:"Hint must not contain two or more consecutive spaces"}})}),u("input.memorableWordUpdate").each(function(e,t){u(t).rules("add",{
checkSpecialChars:!0,checkProhibitedWords:!0,checkHintAndWordEquivalence:!0,checkMemWordLength:!0,checkNumberSeries:!0,checkLetterOrder:!0,
checkLeadingTrailingSpaces:!0,checkConsecutiveSpaces:!0})}),u("input.memorableWordHintUpdate").each(function(e,t){u(t).rules("add",{checkProhibitedWordsHint:!0,
checkHintAndWordEquivalence:!0,checkWordNotInHint:!0,checkLeadingTrailingSpaces:!0,checkConsecutiveSpaces:!0,messages:{
checkLeadingTrailingSpaces:"Hint must not start or end with spaces",checkConsecutiveSpaces:"Hint must not contain two or more consecutive spaces"}})}),u(
"input.validate010207").each(function(e,t){u(t).rules("add",{validate010207:!0,digits:!0,minlength:11,maxlength:11,messages:{digits:"Please enter digits only.",
minlength:"Number must be at least 10 digits long.",maxlength:"Number can't be longer than 11 digits.",
validate010207:"Number must begin with either 01, 02 or 07."}})}),u("input.friendlyName").each(function(e,t){u(t).rules("add",{greaterLessThan:!0,maxlength:30,
friendlyNameExists:!0,messages:{maxlength:"Cannot be over 30 characters.",greaterLessThan:"This can't contain <> symbols.",
friendlyNameExists:"Name already in use."}})}),u("input.validateVFNumber").each(function(e,t){u(t).rules("add",{digits:!0,minlength:11,maxlength:16,
validVFnumber:!0,messages:{digits:"Please enter a valid Vodafone number.",minlength:"Please enter a valid Vodafone number.",
maxlength:"Please enter a valid Vodafone number.",validVFnumber:"Please enter a valid Vodafone number."}})}),u("input.validatePAC").each(function(){u(this
).rules("add",{pac:!0})}),u("input.houseNumberValidate").each(function(e,t){u(t).rules("add",{maxlength:5,messages:{maxlength:"Limited to 5 characters"}})}),u(
"input.flatNumberValidate").each(function(e,t){u(t).rules("add",{maxlength:5,messages:{maxlength:"Limited to 5 characters"}})}),u("input.validateAlternative"
).each(function(){u(this).rules("add",{altPhone:!0})}),u("[name*=voucher_code]").each(function(){u(this).rules("add",{digits:!0})}),u("input.validateSIM").each(
function(){u(this).rules("add",{required:!0,digits:!0,minlength:5,maxlength:5,messages:{minlength:"Please enter 5 digits in each box."}})}),u(
"input.validateESIM4").each(function(){u(this).rules("add",{required:!0,digits:!0,minlength:4,maxlength:4,messages:{
minlength:"Please enter 4 digits in each box."}})}),u("input.validateESIM32").each(function(){u(this).rules("add",{required:!0,digits:!0,minlength:32,
maxlength:32,messages:{minlength:"Please enter no less than 32 digits in this box.",maxlength:"Please enter no more than 32 digits in this box."}})}),u(
"input.validateEmail").each(function(){u(this).rules("add",{email:!0,noNumericDomains:!0})}),u("input.validateSureSignal").each(function(){u(this).rules("add",{
digits:!0,minlength:11,maxlength:11})}),u("input.validatePostcode").each(function(){u(this).rules("add",{postcode:!0})}),u("input.validatePINIndividual").each(
function(){u(this).rules("add",{minlength:1,maxlength:1,required:!0})}),u("input.validatePin4Chars").each(function(){u(this).rules("add",{minlength:4,digits:!0,
maxlength:4,sequenceChar:!0})}),u("input.validatePin4CharsAlt").each(function(){u(this).rules("add",{minlength:4,digits:!0,maxlength:4})}),u(
"select.validateFromToTime").each(function(){u(this).rules("add",{validateFromToTime:!0})}),u("input.doubleDigits").each(function(){u(this).rules("add",{
minlength:2,maxlength:2,required:!0})}),u('.portlet_sim_swap .formContainer input[name^="block"]').each(function(){switch(u(this).attr("name")){case"block5":u(
this).rules("add",{required:!0,digits:!0,minlength:5,maxlength:5,equalTo:'input[name="block1"]'});break;case"block6":u(this).rules("add",{required:!0,digits:!0,
minlength:5,maxlength:5,equalTo:'input[name="block2"]'});break;case"block7":u(this).rules("add",{required:!0,digits:!0,minlength:5,maxlength:5,
equalTo:'input[name="block3"]'});break;case"block8":u(this).rules("add",{required:!0,digits:!0,minlength:5,maxlength:5,equalTo:'input[name="block4"]'});break
;default:u(this).rules("add",{required:!0,digits:!0,minlength:5,maxlength:5})}}),u("select.validateSelect").each(function(){u(this).rules("add",{
mandatorySelect:!0})}),u("select.validateDateOfBirth").each(function(){u(this).rules("add",{dateOfBirth:!0})}),u("input.singleDigit").each(function(e,t){u(t
).rules("remove"),u(t).rules("add",{required:!0,digits:!0,minlength:1,maxlength:1,messages:{required:"Please only enter digits in these fields.",
digits:"Please only enter digits in these fields.",minlength:"Please only enter digits in these fields.",maxlength:"Please only enter digits in these fields."}}
)}),u("input.pinSingleDigit").each(function(e,t){u(t).rules("remove"),u(t).rules("add",{required:!1,digits:!0,minlength:1,maxlength:1,messages:{
required:"Please only enter digits in these fields.",digits:"Please only enter digits in these fields.",minlength:"Please only enter digits in these fields.",
maxlength:"Please only enter digits in these fields."}})}),u(".portlet_sim_swap input.singleDigit").each(function(e,t){u(t).rules("add",{digits:!1,
alphaNumericStrict:!0,messages:{required:"Please enter letters or numbers only in these fields.",
alphaNumericStrict:"Please enter letters or numbers only in these fields.",minlength:"Please enter letters or numbers only in these fields.",
maxlength:"Please enter letters or numbers only in these fields."}})});var a=["","","","","","","",""];u(".matchPin .singleDigit").each(function(e,t){switch(u(t
).rules("remove"),u(t).rules("add",{required:!0,digits:!0,minlength:1,maxlength:1,securePin:!0,messages:{required:"Please enter your 4 digit code.",
digits:"Please enter your 4 digit code.",minlength:"Please enter your 4 digit code.",maxlength:"Please enter your 4 digit code.",
equalTo:"The PIN numbers are not the same."}}),a[e]='input[name="'+u(t).attr("name")+'"]',e){case 0:case 1:case 2:case 3:break;case 4:u(t).rules("add",{
equalTo:a[0]});break;case 5:u(t).rules("add",{equalTo:a[1]});break;case 6:u(t).rules("add",{equalTo:a[2]});break;case 7:u(t).rules("add",{equalTo:a[3]})}})
;var e=a.join(" ");u(".portlet_simswap_v2 .eidLuhn").each(function(){u(this).rules("add",{eidLuhnCheck:!0})}),u(
".portlet_forgottenPassword .validateOr .matchPin .singleDigit").each(function(e,t){u(t).rules("remove","required")}),u(".sortcode .doubleDigits").each(
function(e,t){u(t).rules("remove"),u(t).rules("add",{required:!0,digits:!0,minlength:2,maxlength:2,messages:{required:"Please enter your 6 digit sort code.",
digits:"Please enter your 6 digit sort code.",minlength:"Please enter your 6 digit sort code.",maxlength:"Please enter your 6 digit sort code."}})}),
u.validator.setDefaults({groups:{pinGroup:e}}),u("input.orValidate").each(function(){u(this).rules("add",{orValidate:!0})}),u(
".portlet_registrationForm .checkPassword input:password, .portlet_forgottenPassword .checkPassword input:password, .validatePassword").each(function(){u(this
).rules("add",{passwordValidation:!0})}),u("input.validatePassword").each(function(e,t){u(t).rules("add",{notAsEmail:!0,notAsUsername:!0,messages:{
notAsEmail:"Please enter your password. This must be different from your email address.",
notAsUsername:"Please enter your password. This must be different from your username."}})}),u("input.validateNewPassword").each(function(e,t){u(t).rules("add",{
notAsTempPass:!0,notAsCurrentPass:!0,notAsEmail:!0,notAsUsername:!0,notAsNewUsername:!0,messages:{
notAsTempPass:"Please enter your new password. This must be different from your temporary password.",
notAsCurrentPass:"Please enter your new password. This must be different from your current password.",
notAsEmail:"Please enter your new password. This must be different from your email address.",
notAsUsername:"Please enter your new password. This must be different from your username.",
notAsNewUsername:"Please enter your new password. This must be different from your username."}})}),u("input.alphaNumericStrict").each(function(){u(this).rules(
"add",{alphaNumericStrict:!0})}),u("div.validateCheckSame input").each(function(){u(this).rules("add",{equalityValidation:!0})}),u(
"div.validateCheckSame input.SameNumber").each(function(){u(this).rules("add",{equalityValidation:!0,messages:{
equalityValidation:"The phone numbers don’t match – please check and try again"}})}),u("input.validateName").each(function(){u(this).rules("add",{
alphaNumericStrict:!0,minlength:1,maxlength:50})}),u("input.validateMemorableWord").each(function(){u(this).rules("add",{alphaNumericStrict:!0,minlength:1,
maxlength:12})}),u("input.validateMemorableWordNew").each(function(){u(this).rules("add",{alphaNumericStrict:!0,minlength:6,maxlength:100})}),u(
"input.validateUsername ").each(function(){u(this).rules("add",{userName:!0})}),u(".multipleRadiosField input:radio").each(function(){u(this).rules("add",{
multipleRadiosCheck:!0})}),u(".multipleCheckboxes input:checkbox").each(function(){u(this).rules("add",{multipleCheckboxesCheck:!0})}),u(
".validateNonZeroNumeric").each(function(){u(this).rules("add",{nonZeroNumeric:!0})}),u(".requireHouseAddress").each(function(){u(this).rules("add",{
hasHouseAddress:!0})}),u(".jsCvv2").each(function(){u(this).rules("add",{onlyNumeric:!0,minlength:3,maxlength:3}),u(this).attr("autocomplete","off")}),u(
"input.validateVoucher").each(function(e,t){u(t).rules("add",{onlyNumeric:!0,minlength:12,maxlength:12,messages:{onlyNumeric:"Please enter 12 digits.",
minlength:"Please enter 12 digits.",maxlength:"Please enter 12 digits."}})}),u(".repeatedChars").each(function(){u(this).rules("add",{characterRepeat:!0})}),u(
".validateAccountNumber").each(function(){u(this).rules("add",{onlyNumeric:!0,minlength:7,maxlength:9})}),u(".validateAccountNumber").each(function(e,t){u(t
).rules("add",{required:!0,onlyNumeric:!0,minlength:7,maxlength:9,messages:{required:"Please enter your account number.",
onlyNumeric:"Please enter a valid account number.",minlength:"Please enter a valid account number.",maxlength:"Please enter a valid account number."}})}),u(
".validateOTAC").each(function(e,t){u(t).rules("remove"),u(t).rules("add",{required:!0,alphaNumericStrict:!0,minlength:6,maxlength:6,messages:{
required:"Please enter your 6 character code.",digits:"Please enter your 6 character code.",minlength:"Please enter your 6 character code.",
maxlength:"Please enter your 6 character code."}})}),u(".filter_box input:text").each(function(e,t){u(t).rules("remove"),u(t).rules("add",{filtersCheckboxes:!0,
filtersText:!0})}),u("input.validateDigits").each(function(){u(this).rules("add",{digits:!0})}),u("input.securePin").each(function(){u(this).rules("add",{
securePin:!0,onlyNumeric:!0,messages:{onlyNumeric:"Please enter only numbers"}})}),u(".portlet_smart_divert_pin input.securePin").each(function(e,t){u(t).rules(
"add",{minlength:4,messages:{minlength:"Please enter a 4 digit PIN."}})}),u("input.validateDeviceName").each(function(){u(this).rules("add",{minlength:1,
maxlength:20,messages:{maxlength:"Enter a name no longer than 20 characters."}})}),u("input.validateDomain").each(function(){u(this).rules("add",{domain:!0})})
}(),0<(t=u("input[name*=amount]")).length&&t.data("wasDisabled")&&!0===t.data("wasDisabled")&&(t.prop("disabled",!0),t.data("wasDisabled",undefined)))},u(
document).ready(function(){if(u(".portlet_sim_swap .formContainer").find(".formRow input.fourDigit").addClass("validateItem validateRequired").attr("maxlength",
"5"),u(".portlet_payment_subflow_saved .savedCardsList").addClass("multipleRadiosField"),u(".validateItem").length+u(".multipleRadiosField").length+u(
".postcodeLookup").length!=0){u("form input, form select, form button").each(function(){u.validator.deMung(u(this))});try{var e=!0;0<u(
".portlet_Manage_payment_methods").length&&(e=!1,u("form").vfValidate({cssSelector:"fieldset:first",groups:{
sortcodeGroup:"sortcode1 sortcode2 sortcode3 sortcode4 sortcode5 sortcode6"}})),0<u(".portlet_top17").length&&(e=!1,u("form").vfValidate({groups:{
sortCodeFields:"sortCode1 sortCode2 sortCode3"}}));var t=u(".myPackageManage");0<t.length&&(e=!1,t.vfValidate({cssSelector:".productGroup li"})),t=null;var a=u(
".formContainer.myEmailAddressDetails");0<a.length&&(e=!1,a.vfValidate({rules:{required:!0,email:!0,noNumericDomains:!0,equalTo:u("input.validateEmail:first"
).vfGetGroupNameAttributes()},messages:{email:"Please enter a valid email.",equalTo:"Emails do not match."},groups:{}})),a=null;var n=u(".roaming-checklist"),
i=n.find(".roaming-checklist__step2");0<n.length&&(e=!1,u("form").vfValidate({submitHandler:function(e){return i.hasClass("hide")||n.trigger(
"validation:roaming-checklist:passed"),!1}}));var l=u('input[name*="pinCheck"]');0<l.length&&(u('input[name*="matchPin"]').each(function(e){var t=u(this).attr(
"name"),a=t.lastIndexOf(":"),n=t.substring(a,t.length);u(this).attr("name",n)}),u(
'.formRow input[name*="matchPin1"], input[name*="matchPin2"], input[name*="matchPin3"], input[name*="matchPin4"]').focusout(function(){var e=u(
'input[name*="matchPin1"]').val();u('input[name*="matchPin1"]').first().attr("value",e);var t=u('input[name*="matchPin2"]').val();u('input[name*="matchPin2"]'
).first().attr("value",t);var a=u('input[name*="matchPin3"]').val();u('input[name*="matchPin3"]').first().attr("value",a);var n=u('input[name*="matchPin4"]'
).val();u('input[name*="matchPin4"]').first().attr("value",n);var i=u('input[name*="rematchPin1"]').val();u('input[name*="rematchPin1"]').attr("value",i)
;var r=u('input[name*="rematchPin2"]').val();u('input[name*="rematchPin2"]').attr("value",r);var s=u('input[name*="rematchPin3"]').val();u(
'input[name*="rematchPin3"]').attr("value",s);var o=u('input[name*="rematchPin4"]').val();u('input[name*="rematchPin4"]').attr("value",o),l.val(e+t+a+n)}),u(
"form").vfValidate({invalidHandler:function(e,t){window.setTimeout(function(){var e=u('p[name="pinCheck"]');0<e.length&&u(e).hasClass("errorMSG")&&u(e).closest(
".formRow").removeClass("valid").addClass("error")},50)}})),e&&u("form").vfValidate()}catch(r){}}})}(jQuery),function(n){n.fn.vfGetGroupNameAttributes=function(
){var a=[];return this.each(function(e,t){a.push(n(t).attr("name"))}),a.join(" ").replace(/(:|\.|\[|\])/g,"\\$1")},window.getNameQuery=function(e){
return'input[name="'+e+'"]'}}(jQuery);