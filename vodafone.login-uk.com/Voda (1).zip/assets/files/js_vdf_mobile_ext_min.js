/* compiled: 2019-04-09 18:10:08 */

if(function(e,t){"use strict";"function"==typeof define&&define.amd?define(t):"object"==typeof exports?module.exports=t():e.returnExports=t()}(this,function(){
var f,h,s=Array,e=s.prototype,c=Object,t=c.prototype,l=Function,n=l.prototype,b=String,i=b.prototype,y=Number,o=y.prototype,d=e.slice,r=e.splice,p=e.push,
a=e.unshift,u=e.concat,v=e.join,g=n.call,m=n.apply,C=Math.max,w=Math.min,_=t.toString,k="function"==typeof Symbol&&"symbol"==typeof Symbol.toStringTag,
x=Function.prototype.toString,$=/^\s*class /,O=function O(e){try{var t=x.call(e).replace(/\/\/.*\n/g,"").replace(/\/\*[.\s\S]*\*\//g,"").replace(/\n/gm," "
).replace(/ {2}/g," ");return $.test(t)}catch(n){return!1}},j=function j(e){try{return!O(e)&&(x.call(e),!0)}catch(t){return!1}},S=function S(e){if(!e)return!1
;if("function"!=typeof e&&"object"!=typeof e)return!1;if(k)return j(e);if(O(e))return!1;var t=_.call(e)
;return"[object Function]"===t||"[object GeneratorFunction]"===t},I=RegExp.prototype.exec,T=function T(e){try{return I.call(e),!0}catch(t){return!1}}
;f=function f(e){return"object"==typeof e&&(k?T(e):"[object RegExp]"===_.call(e))};var D=String.prototype.valueOf,E=function E(e){try{return D.call(e),!0}catch(
t){return!1}};h=function h(e){return"string"==typeof e||"object"==typeof e&&(k?E(e):"[object String]"===_.call(e))};var A,P,M=c.defineProperty&&function(){try{
var e={};for(var t in c.defineProperty(e,"x",{enumerable:!1,value:e}),e)return!1;return e.x===e}catch(n){return!1}}(),N=(A=t.hasOwnProperty,P=M?function(e,t,n,i
){!i&&t in e||c.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:!0,value:n})}:function(e,t,n,i){!i&&t in e||(e[t]=n)},function(e,t,n){for(var i in t
)A.call(t,i)&&P(e,i,t[i],n)}),R=function R(e){var t=typeof e;return null===e||"object"!==t&&"function"!==t},L=y.isNaN||function L(e){return e!=e},B=function(e){
var t=+e;return L(t)?t=0:0!==t&&t!==1/0&&t!==-1/0&&(t=(0<t||-1)*Math.floor(Math.abs(t))),t},F=function(e){if(null==e)throw new TypeError(
"can't convert "+e+" to object");return c(e)},U=function(e){return e>>>0},H=function H(){};N(n,{bind:function(t){var n=this;if(!S(n))throw new TypeError(
"Function.prototype.bind called on incompatible "+n);for(var i,o=d.call(arguments,1),e=C(0,n.length-o.length),r=[],a=0;a<e;a++)p.call(r,"$"+a);return i=l(
"binder","return function ("+v.call(r,",")+"){ return binder.apply(this, arguments); }")(function(){if(this instanceof i){var e=m.call(n,this,u.call(o,d.call(
arguments)));return c(e)===e?e:this}return m.call(n,t,u.call(o,d.call(arguments)))}),n.prototype&&(H.prototype=n.prototype,i.prototype=new H,H.prototype=null),i
}});var V=g.bind(t.hasOwnProperty),q=g.bind(t.toString),z=g.bind(d),G=m.bind(d);if("object"==typeof document&&document&&document.documentElement)try{z(
document.documentElement.childNodes)}catch(Ft){var J=z,W=G;z=function Ld(t){for(var n=[],i=t.length;0<i--;)n[i]=t[i];return W(n,J(arguments,1))},G=function Pd(t
,n){return W(z(t),n)}}var Q=g.bind(i.slice),Z=g.bind(i.split),Y=g.bind(i.indexOf),K=g.bind(p),X=g.bind(t.propertyIsEnumerable),ee=g.bind(e.sort),
te=s.isArray||function te(e){return"[object Array]"===q(e)},ne=1!==[].unshift(0);N(e,{unshift:function(){return a.apply(this,arguments),this.length}},ne),N(s,{
isArray:te});var ie=c("a"),oe="a"!==ie[0]||!(0 in ie),re=function(e){var i=!0,t=!0,n=!1;if(e)try{e.call("foo",function(e,t,n){"object"!=typeof n&&(i=!1)}),
e.call([1],function(){"use strict";t="string"==typeof this},"x")}catch(Ft){n=!0}return!!e&&!n&&i&&t};N(e,{forEach:function(e){var t,n=F(this),i=oe&&h(this)?Z(
this,""):n,o=-1,r=U(i.length);if(1<arguments.length&&(t=arguments[1]),!S(e))throw new TypeError("Array.prototype.forEach callback must be a function");for(
;++o<r;)o in i&&("undefined"==typeof t?e(i[o],o,n):e.call(t,i[o],o,n))}},!re(e.forEach)),N(e,{map:function(e){var t,n=F(this),i=oe&&h(this)?Z(this,""):n,o=U(
i.length),r=s(o);if(1<arguments.length&&(t=arguments[1]),!S(e))throw new TypeError("Array.prototype.map callback must be a function");for(var a=0;a<o;a++
)a in i&&(r[a]="undefined"==typeof t?e(i[a],a,n):e.call(t,i[a],a,n));return r}},!re(e.map)),N(e,{filter:function(e){var t,n,i=F(this),o=oe&&h(this)?Z(this,""):i
,r=U(o.length),a=[];if(1<arguments.length&&(n=arguments[1]),!S(e))throw new TypeError("Array.prototype.filter callback must be a function");for(var s=0;s<r;s++
)s in o&&(t=o[s],("undefined"==typeof n?e(t,s,i):e.call(n,t,s,i))&&K(a,t));return a}},!re(e.filter)),N(e,{every:function(e){var t,n=F(this),i=oe&&h(this)?Z(this
,""):n,o=U(i.length);if(1<arguments.length&&(t=arguments[1]),!S(e))throw new TypeError("Array.prototype.every callback must be a function");for(var r=0;r<o;r++
)if(r in i&&!("undefined"==typeof t?e(i[r],r,n):e.call(t,i[r],r,n)))return!1;return!0}},!re(e.every)),N(e,{some:function(e){var t,n=F(this),i=oe&&h(this)?Z(this
,""):n,o=U(i.length);if(1<arguments.length&&(t=arguments[1]),!S(e))throw new TypeError("Array.prototype.some callback must be a function");for(var r=0;r<o;r++
)if(r in i&&("undefined"==typeof t?e(i[r],r,n):e.call(t,i[r],r,n)))return!0;return!1}},!re(e.some));var ae=!1;e.reduce&&(ae="object"==typeof e.reduce.call("es5"
,function(e,t,n,i){return i})),N(e,{reduce:function(e){var t=F(this),n=oe&&h(this)?Z(this,""):t,i=U(n.length);if(!S(e))throw new TypeError(
"Array.prototype.reduce callback must be a function");if(0===i&&1===arguments.length)throw new TypeError("reduce of empty array with no initial value");var o,
r=0;if(2<=arguments.length)o=arguments[1];else for(;;){if(r in n){o=n[r++];break}if(++r>=i)throw new TypeError("reduce of empty array with no initial value")}
for(;r<i;r++)r in n&&(o=e(o,n[r],r,t));return o}},!ae);var se=!1;e.reduceRight&&(se="object"==typeof e.reduceRight.call("es5",function(e,t,n,i){return i})),N(e,
{reduceRight:function(e){var t,n=F(this),i=oe&&h(this)?Z(this,""):n,o=U(i.length);if(!S(e))throw new TypeError(
"Array.prototype.reduceRight callback must be a function");if(0===o&&1===arguments.length)throw new TypeError("reduceRight of empty array with no initial value"
);var r=o-1;if(2<=arguments.length)t=arguments[1];else for(;;){if(r in i){t=i[r--];break}if(--r<0)throw new TypeError(
"reduceRight of empty array with no initial value")}if(r<0)return t;for(;r in i&&(t=e(t,i[r],r,n)),r--;);return t}},!se);var ce=e.indexOf&&-1!==[0,1].indexOf(1,
2);N(e,{indexOf:function(e){var t=oe&&h(this)?Z(this,""):F(this),n=U(t.length);if(0===n)return-1;var i=0;for(1<arguments.length&&(i=B(arguments[1])),i=0<=i?i:C(
0,n+i);i<n;i++)if(i in t&&t[i]===e)return i;return-1}},ce);var le=e.lastIndexOf&&-1!==[0,1].lastIndexOf(0,-3);N(e,{lastIndexOf:function(e){var t=oe&&h(this)?Z(
this,""):F(this),n=U(t.length);if(0===n)return-1;var i=n-1;for(1<arguments.length&&(i=w(i,B(arguments[1]))),i=0<=i?i:n-Math.abs(i);0<=i;i--)if(i in t&&e===t[i]
)return i;return-1}},le);var de,ue,fe=(ue=(de=[1,2]).splice(),2===de.length&&te(ue)&&0===ue.length);N(e,{splice:function(e,t){return 0===arguments.length?[
]:r.apply(this,arguments)}},!fe);var he,pe=(he={},e.splice.call(he,0,0,1),1===he.length);N(e,{splice:function(e,t){if(0===arguments.length)return[]
;var n=arguments;return this.length=C(B(this.length),0),0<arguments.length&&"number"!=typeof t&&((n=z(arguments)).length<2?K(n,this.length-e):n[1]=B(t)),
r.apply(this,n)}},!pe);var ve,ge,me=((ve=new s(1e5))[8]="x",ve.splice(1,1),7===ve.indexOf("x")),be=((ge=[])[256]="a",ge.splice(257,0,"b"),"a"===ge[256]);N(e,{
splice:function(e,t){for(var n,i=F(this),o=[],r=U(i.length),a=B(e),s=a<0?C(r+a,0):w(a,r),c=w(C(B(t),0),r-s),l=0;l<c;)n=b(s+l),V(i,n)&&(o[l]=i[n]),l+=1;var d,
u=z(arguments,2),f=u.length;if(f<c){l=s;for(var h=r-c;l<h;)n=b(l+c),d=b(l+f),V(i,n)?i[d]=i[n]:delete i[d],l+=1;for(var p=(l=r)-c+f;p<l;)delete i[l-1],l-=1
}else if(c<f)for(l=r-c;s<l;)n=b(l+c-1),d=b(l+f-1),V(i,n)?i[d]=i[n]:delete i[d],l-=1;l=s;for(var v=0;v<u.length;++v)i[l]=u[v],l+=1;return i.length=r-c+f,o}},
!me||!be);var ye,Ce=e.join;try{ye="1,2,3"!==Array.prototype.join.call("123",",")}catch(Ft){ye=!0}ye&&N(e,{join:function(e){var t="undefined"==typeof e?",":e
;return Ce.call(h(this)?Z(this,""):this,t)}},ye);var we="1,2"!==[1,2].join(undefined);we&&N(e,{join:function(e){var t="undefined"==typeof e?",":e
;return Ce.call(this,t)}},we);var _e,ke=function(e){for(var t=F(this),n=U(t.length),i=0;i<arguments.length;)t[n+i]=arguments[i],i+=1;return t.length=n+i,n+i},
xe=(_e={},1!==Array.prototype.push.call(_e,undefined)||1!==_e.length||"undefined"!=typeof _e[0]||!V(_e,0));N(e,{push:function(e){return te(this)?p.apply(this,
arguments):ke.apply(this,arguments)}},xe);var $e,Oe=1!==($e=[]).push(undefined)||1!==$e.length||"undefined"!=typeof $e[0]||!V($e,0);N(e,{push:ke},Oe),N(e,{
slice:function(e,t){var n=h(this)?Z(this,""):this;return G(n,arguments)}},oe);var je=function(){try{[1,2].sort(null)}catch(Ft){try{[1,2].sort({})}catch(e){
return!1}}return!0}(),Se=function(){try{return[1,2].sort(/a/),!1}catch(Ft){}return!0}(),Ie=function(){try{return[1,2].sort(undefined),!0}catch(Ft){}return!1}()
;N(e,{sort:function(e){if("undefined"==typeof e)return ee(this);if(!S(e))throw new TypeError("Array.prototype.sort callback must be a function");return ee(this,
e)}},je||!Ie||!Se);var Te=!X({toString:null},"toString"),De=X(function(){},"prototype"),Ee=!V("x","0"),Ae=function(e){var t=e.constructor
;return t&&t.prototype===e},Pe={$applicationCache:!0,$console:!0,$external:!0,$frame:!0,$frameElement:!0,$frames:!0,$innerHeight:!0,$innerWidth:!0,
$outerHeight:!0,$outerWidth:!0,$pageXOffset:!0,$pageYOffset:!0,$parent:!0,$scrollLeft:!0,$scrollTop:!0,$scrollX:!0,$scrollY:!0,$self:!0,$webkitIndexedDB:!0,
$webkitStorageInfo:!0,$window:!0,$width:!0,$height:!0,$top:!0,$localStorage:!0},Me=function(){if("undefined"==typeof window)return!1;for(var e in window)try{
!Pe["$"+e]&&V(window,e)&&null!==window[e]&&"object"==typeof window[e]&&Ae(window[e])}catch(Ft){return!0}return!1}(),Ne=["toString","toLocaleString","valueOf",
"hasOwnProperty","isPrototypeOf","propertyIsEnumerable","constructor"],Re=Ne.length,Le=function Be(e){return"[object Arguments]"===q(e)},Be=(function Be(e){
return null!==e&&"object"==typeof e&&"number"==typeof e.length&&0<=e.length&&!te(e)&&S(e.callee)},Le(arguments)?Le:function Be(e){
return null!==e&&"object"==typeof e&&"number"==typeof e.length&&0<=e.length&&!te(e)&&S(e.callee)});N(c,{keys:function(e){var t=S(e),n=Be(e),
i=null!==e&&"object"==typeof e,o=i&&h(e);if(!i&&!t&&!n)throw new TypeError("Object.keys called on a non-object");var r=[],a=De&&t;if(o&&Ee||n)for(
var s=0;s<e.length;++s)K(r,b(s));if(!n)for(var c in e)a&&"prototype"===c||!V(e,c)||K(r,b(c));if(Te)for(var l=function(e){if("undefined"==typeof window||!Me
)return Ae(e);try{return Ae(e)}catch(Ft){return!1}}(e),d=0;d<Re;d++){var u=Ne[d];l&&"constructor"===u||!V(e,u)||K(r,u)}return r}});var Fe=c.keys&&function(){
return 2===c.keys(arguments).length}(1,2),Ue=c.keys&&function(){var e=c.keys(arguments);return 1!==arguments.length||1!==e.length||1!==e[0]}(1),He=c.keys;N(c,{
keys:function(e){return Be(e)?He(z(e)):He(e)}},!Fe||Ue);var Ve,qe,ze=0!==new Date(-0xc782b5b342b24).getUTCMonth(),Ge=new Date(-0x55d318d56a724),Je=new Date(
14496624e5),We="Mon, 01 Jan -45875 11:59:59 GMT"!==Ge.toUTCString();qe=Ge.getTimezoneOffset()<-720?(Ve="Tue Jan 02 -45875"!==Ge.toDateString(),
!/^Thu Dec 10 2015 \d\d:\d\d:\d\d GMT[-+]\d\d\d\d(?: |$)/.test(String(Je))):(Ve="Mon Jan 01 -45875"!==Ge.toDateString(),
!/^Wed Dec 09 2015 \d\d:\d\d:\d\d GMT[-+]\d\d\d\d(?: |$)/.test(String(Je)));var Qe=g.bind(Date.prototype.getFullYear),Ze=g.bind(Date.prototype.getMonth),
Ye=g.bind(Date.prototype.getDate),Ke=g.bind(Date.prototype.getUTCFullYear),Xe=g.bind(Date.prototype.getUTCMonth),et=g.bind(Date.prototype.getUTCDate),tt=g.bind(
Date.prototype.getUTCDay),nt=g.bind(Date.prototype.getUTCHours),it=g.bind(Date.prototype.getUTCMinutes),ot=g.bind(Date.prototype.getUTCSeconds),rt=g.bind(
Date.prototype.getUTCMilliseconds),at=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],st=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
ct=function ct(e,t){return Ye(new Date(t,e,0))};N(Date.prototype,{getFullYear:function(){if(!(this&&this instanceof Date))throw new TypeError(
"this is not a Date object.");var e=Qe(this);return e<0&&11<Ze(this)?e+1:e},getMonth:function(){if(!(this&&this instanceof Date))throw new TypeError(
"this is not a Date object.");var e=Qe(this),t=Ze(this);return e<0&&11<t?0:t},getDate:function(){if(!(this&&this instanceof Date))throw new TypeError(
"this is not a Date object.");var e=Qe(this),t=Ze(this),n=Ye(this);return e<0&&11<t?12===t?n:ct(0,e+1)-n+1:n},getUTCFullYear:function(){if(!(
this&&this instanceof Date))throw new TypeError("this is not a Date object.");var e=Ke(this);return e<0&&11<Xe(this)?e+1:e},getUTCMonth:function(){if(!(
this&&this instanceof Date))throw new TypeError("this is not a Date object.");var e=Ke(this),t=Xe(this);return e<0&&11<t?0:t},getUTCDate:function(){if(!(
this&&this instanceof Date))throw new TypeError("this is not a Date object.");var e=Ke(this),t=Xe(this),n=et(this);return e<0&&11<t?12===t?n:ct(0,e+1)-n+1:n}},
ze),N(Date.prototype,{toUTCString:function(){if(!(this&&this instanceof Date))throw new TypeError("this is not a Date object.");var e=tt(this),t=et(this),n=Xe(
this),i=Ke(this),o=nt(this),r=it(this),a=ot(this);return at[e]+", "+(t<10?"0"+t:t)+" "+st[n]+" "+i+" "+(o<10?"0"+o:o)+":"+(r<10?"0"+r:r)+":"+(a<10?"0"+a:a
)+" GMT"}},ze||We),N(Date.prototype,{toDateString:function(){if(!(this&&this instanceof Date))throw new TypeError("this is not a Date object.")
;var e=this.getDay(),t=this.getDate(),n=this.getMonth(),i=this.getFullYear();return at[e]+" "+st[n]+" "+(t<10?"0"+t:t)+" "+i}},ze||Ve),(ze||qe)&&(
Date.prototype.toString=function(){if(!(this&&this instanceof Date))throw new TypeError("this is not a Date object.");var e=this.getDay(),t=this.getDate(),
n=this.getMonth(),i=this.getFullYear(),o=this.getHours(),r=this.getMinutes(),a=this.getSeconds(),s=this.getTimezoneOffset(),c=Math.floor(Math.abs(s)/60),
l=Math.floor(Math.abs(s)%60);return at[e]+" "+st[n]+" "+(t<10?"0"+t:t)+" "+i+" "+(o<10?"0"+o:o)+":"+(r<10?"0"+r:r)+":"+(a<10?"0"+a:a)+" GMT"+(0<s?"-":"+")+(
c<10?"0"+c:c)+(l<10?"0"+l:l)},M&&c.defineProperty(Date.prototype,"toString",{configurable:!0,enumerable:!1,writable:!0}));var lt=-621987552e5,dt="-000001",
ut=Date.prototype.toISOString&&-1===new Date(lt).toISOString().indexOf(dt),ft=Date.prototype.toISOString&&"1969-12-31T23:59:59.999Z"!==new Date(-1).toISOString(
),ht=g.bind(Date.prototype.getTime);N(Date.prototype,{toISOString:function(){if(!isFinite(this)||!isFinite(ht(this)))throw new RangeError(
"Date.prototype.toISOString called on non-finite value.");var e=Ke(this),t=Xe(this);e+=Math.floor(t/12);var n=[1+(t=(t%12+12)%12),et(this),nt(this),it(this),ot(
this)];e=(e<0?"-":9999<e?"+":"")+Q("00000"+Math.abs(e),0<=e&&e<=9999?-4:-6);for(var i=0;i<n.length;++i)n[i]=Q("00"+n[i],-2);return e+"-"+z(n,0,2).join("-"
)+"T"+z(n,2).join(":")+"."+Q("000"+rt(this),-3)+"Z"}},ut||ft),function(){try{return Date.prototype.toJSON&&null===new Date(NaN).toJSON()&&-1!==new Date(lt
).toJSON().indexOf(dt)&&Date.prototype.toJSON.call({toISOString:function(){return!0}})}catch(Ft){return!1}}()||(Date.prototype.toJSON=function(e){var t=c(this),
n=function(e){var t,n,i;if(R(e))return e;if(n=e.valueOf,S(n)&&(t=n.call(e),R(t)))return t;if(i=e.toString,S(i)&&(t=i.call(e),R(t)))return t;throw new TypeError
}(t);if("number"==typeof n&&!isFinite(n))return null;var i=t.toISOString;if(!S(i))throw new TypeError("toISOString property is not callable");return i.call(t)})
;var pt=1e15===Date.parse("+033658-09-27T01:46:40.000Z"),vt=!isNaN(Date.parse("2012-04-04T24:00:00.500Z"))||!isNaN(Date.parse("2012-11-31T23:59:59.000Z")
)||!isNaN(Date.parse("2012-12-31T23:59:60.000Z"));if(isNaN(Date.parse("2000-01-01T00:00:00.000Z"))||vt||!pt){var gt=Math.pow(2,31)-1,mt=L(new Date(1970,0,1,0,0,
0,gt+1).getTime());Date=function(p){var h=function(e,t,n,i,o,r,a){var s,c=arguments.length;if(this instanceof p){var l=r,d=a;if(mt&&7<=c&&gt<a){
var u=Math.floor(a/gt)*gt,f=Math.floor(u/1e3);l+=f,d-=1e3*f}s=1===c&&b(e)===e?new p(h.parse(e)):7<=c?new p(e,t,n,i,o,l,d):6<=c?new p(e,t,n,i,o,l):5<=c?new p(e,t
,n,i,o):4<=c?new p(e,t,n,i):3<=c?new p(e,t,n):2<=c?new p(e,t):1<=c?new p(e instanceof p?+e:e):new p}else s=p.apply(this,arguments);return R(s)||N(s,{
constructor:h},!0),s},v=new RegExp(
"^(\\d{4}|[+-]\\d{6})(?:-(\\d{2})(?:-(\\d{2})(?:T(\\d{2}):(\\d{2})(?::(\\d{2})(?:(\\.\\d{1,}))?)?(Z|(?:([-+])(\\d{2}):(\\d{2})))?)?)?)?$"),i=[0,31,59,90,120,151
,181,212,243,273,304,334,365],g=function g(e,t){var n=1<t?1:0;return i[t]+Math.floor((e-1969+n)/4)-Math.floor((e-1901+n)/100)+Math.floor((e-1601+n)/400)+365*(
e-1970)},m=function m(e){var t=0,n=e;if(mt&&gt<n){var i=Math.floor(n/gt)*gt,o=Math.floor(i/1e3);t+=o,n-=1e3*o}return y(new p(1970,0,1,0,0,t,n))};for(var e in p
)V(p,e)&&(h[e]=p[e]);return N(h,{now:p.now,UTC:p.UTC},!0),h.prototype=p.prototype,N(h.prototype,{constructor:h},!0),N(h,{parse:function(e){var t=v.exec(e);if(t
){var n,i=y(t[1]),o=y(t[2]||1)-1,r=y(t[3]||1)-1,a=y(t[4]||0),s=y(t[5]||0),c=y(t[6]||0),l=Math.floor(1e3*y(t[7]||0)),d=Boolean(t[4]&&!t[8]),u="-"===t[9]?1:-1,
f=y(t[10]||0),h=y(t[11]||0);return a<(0<s||0<c||0<l?24:25)&&s<60&&c<60&&l<1e3&&-1<o&&o<12&&f<24&&h<60&&-1<r&&r<g(i,o+1)-g(i,o)&&(n=1e3*(60*((n=60*(24*(g(i,o)+r
)+a+f*u))+s+h*u)+c)+l,d&&(n=m(n)),-864e13<=n&&n<=864e13)?n:NaN}return p.parse.apply(this,arguments)}}),h}(Date)}Date.now||(Date.now=function(){return(new Date
).getTime()});var bt=o.toFixed&&("0.000"!==8e-5.toFixed(3)||"1"!==.9.toFixed(0)||"1.25"!==1.255.toFixed(2)||"1000000000000000128"!==(0xde0b6b3a7640080).toFixed(
0)),yt={base:1e7,size:6,data:[0,0,0,0,0,0],multiply:function(e,t){for(var n=-1,i=t;++n<yt.size;)i+=e*yt.data[n],yt.data[n]=i%yt.base,i=Math.floor(i/yt.base)},
divide:function(e){for(var t=yt.size,n=0;0<=--t;)n+=yt.data[t],yt.data[t]=Math.floor(n/e),n=n%e*yt.base},numToString:function(){for(var e=yt.size,t="";0<=--e;
)if(""!==t||0===e||0!==yt.data[e]){var n=b(yt.data[e]);""===t?t=n:t+=Q("0000000",0,7-n.length)+n}return t},pow:function Ut(e,t,n){return 0===t?n:t%2==1?Ut(e,t-1
,n*e):Ut(e*e,t/2,n)},log:function(e){for(var t=0,n=e;4096<=n;)t+=12,n/=4096;for(;2<=n;)t+=1,n/=2;return t}};N(o,{toFixed:function(e){var t,n,i,o,r,a,s,c;if(t=y(
e),(t=L(t)?0:Math.floor(t))<0||20<t)throw new RangeError("Number.toFixed called with invalid number of decimals");if(n=y(this),L(n))return"NaN";if(
n<=-1e21||1e21<=n)return b(n);if(i="",n<0&&(i="-",n=-n),o="0",1e-21<n)if(a=(r=yt.log(n*yt.pow(2,69,1))-69)<0?n*yt.pow(2,-r,1):n/yt.pow(2,r,1),
a*=4503599627370496,0<(r=52-r)){for(yt.multiply(0,a),s=t;7<=s;)yt.multiply(1e7,0),s-=7;for(yt.multiply(yt.pow(10,s,1),0),s=r-1;23<=s;)yt.divide(1<<23),s-=23
;yt.divide(1<<s),yt.multiply(1,1),yt.divide(2),o=yt.numToString()}else yt.multiply(0,a),yt.multiply(1<<-r,0),o=yt.numToString()+Q("0.00000000000000000000",2,2+t
);return 0<t?(c=o.length)<=t?i+Q("0.0000000000000000000",0,t-c+2)+o:i+Q(o,0,c-t)+"."+Q(o,c-t):i+o}},bt);var Ct,wt,_t=function(){try{return"1"===1..toPrecision(
undefined)}catch(Ft){return!0}}(),kt=o.toPrecision;N(o,{toPrecision:function(e){return"undefined"==typeof e?kt.call(this):kt.call(this,e)}},_t),2!=="ab".split(
/(?:ab)*/).length||4!==".".split(/(.?)(.?)/).length||"t"==="tesst".split(/(s)*/)[1]||4!=="test".split(/(?:)/,-1).length||"".split(/.?/).length||1<".".split(
/()()/).length?(Ct="undefined"==typeof/()??/.exec("")[1],wt=Math.pow(2,32)-1,i.split=function(e,t){var n=String(this);if("undefined"==typeof e&&0===t)return[]
;if(!f(e))return Z(this,e,t);var i,o,r,a,s=[],c=(e.ignoreCase?"i":"")+(e.multiline?"m":"")+(e.unicode?"u":"")+(e.sticky?"y":""),l=0,d=new RegExp(e.source,c+"g")
;Ct||(i=new RegExp("^"+d.source+"$(?!\\s)",c));var u="undefined"==typeof t?wt:U(t);for(o=d.exec(n);o&&!(l<(r=o.index+o[0].length)&&(K(s,Q(n,l,o.index)),
!Ct&&1<o.length&&o[0].replace(i,function(){for(var e=1;e<arguments.length-2;e++)"undefined"==typeof arguments[e]&&(o[e]=void 0)}),
1<o.length&&o.index<n.length&&p.apply(s,z(o,1)),a=o[0].length,l=r,u<=s.length));)d.lastIndex===o.index&&d.lastIndex++,o=d.exec(n)
;return l===n.length?!a&&d.test("")||K(s,""):K(s,Q(n,l)),u<s.length?z(s,0,u):s}):"0".split(void 0,0).length&&(i.split=function(e,t){
return"undefined"==typeof e&&0===t?[]:Z(this,e,t)});var xt,$t=i.replace;xt=[],"x".replace(/x(.)?/g,function(e,t){K(xt,t)}),
1===xt.length&&"undefined"==typeof xt[0]||(i.replace=function(o,r){var e=S(r),t=f(o)&&/\)[*?]/.test(o.source);return e&&t?$t.call(this,o,function(e){
var t=arguments.length,n=o.lastIndex;o.lastIndex=0;var i=o.exec(e)||[];return o.lastIndex=n,K(i,arguments[t-2],arguments[t-1]),r.apply(this,i)}):$t.call(this,o,
r)});var Ot=i.substr,jt="".substr&&"b"!=="0b".substr(-1);N(i,{substr:function(e,t){var n=e;return e<0&&(n=C(this.length+e,0)),Ot.call(this,n,t)}},jt)
;var St="\t\n\x0B\f\r   ᠎             　\u2028\u2029\ufeff",It="["+St+"]",Tt=new RegExp("^"+It+It+"*"),Dt=new RegExp(It+It+"*$"),Et=i.trim&&(St.trim(
)||!"​".trim());N(i,{trim:function At(){if("undefined"==typeof this||null===this)throw new TypeError("can't convert "+this+" to object");return b(this).replace(
Tt,"").replace(Dt,"")}},Et);var At=g.bind(String.prototype.trim),Pt=i.lastIndexOf&&-1!=="abcあい".lastIndexOf("あい",2);N(i,{lastIndexOf:function(e){if(
"undefined"==typeof this||null===this)throw new TypeError("can't convert "+this+" to object");for(var t=b(this),n=b(e),i=1<arguments.length?y(arguments[1]):NaN,
o=L(i)?Infinity:B(i),r=w(C(o,0),t.length),a=n.length,s=r+a;0<s;){s=C(0,s-a);var c=Y(Q(t,s,r+a),n);if(-1!==c)return s+c}return-1}},Pt);var Mt,Nt,Rt,
Lt=i.lastIndexOf;if(N(i,{lastIndexOf:function(e){return Lt.apply(this,arguments)}},1!==i.lastIndexOf.length),8===parseInt(St+"08")&&22===parseInt(St+"0x16")||(
parseInt=(Mt=parseInt,Nt=/^[-+]?0[xX]/,function(e,t){var n=At(String(e)),i=y(t)||(Nt.test(n)?16:10);return Mt(n,i)})),1/parseFloat("-0")!=-Infinity&&(
parseFloat=(Rt=parseFloat,function(e){var t=At(String(e)),n=Rt(t);return 0===n&&"-"===Q(t,0,1)?-0:n})),"RangeError: test"!==String(new RangeError("test"))&&(
Error.prototype.toString=function(){if("undefined"==typeof this||null===this)throw new TypeError("can't convert "+this+" to object");var e=this.name
;"undefined"==typeof e?e="Error":"string"!=typeof e&&(e=b(e));var t=this.message;return"undefined"==typeof t?t="":"string"!=typeof t&&(t=b(t)),e?t?e+": "+t:e:t}
),M){var Bt=function(e,t){if(X(e,t)){var n=Object.getOwnPropertyDescriptor(e,t);n.configurable&&(n.enumerable=!1,Object.defineProperty(e,t,n))}};Bt(
Error.prototype,"message"),""!==Error.prototype.message&&(Error.prototype.message=""),Bt(Error.prototype,"name")}"/a/gim"!==String(/a/gim)&&(
RegExp.prototype.toString=function(){var e="/"+this.source+"/";return this.global&&(e+="g"),this.ignoreCase&&(e+="i"),this.multiline&&(e+="m"),e})}),function(e,
t){"function"==typeof define&&define.amd?define(t):"object"==typeof exports?module.exports=t():e.returnExports=t()}(this,function(){"use strict";var e,r,
i=Function.call.bind(Function.apply),w=Function.call.bind(Function.call),c=Array.isArray,s=Object.keys,t=function(e){try{return e(),!1}catch(t){return!0}},
o=function o(e){try{return e()}catch(t){return!1}},n=(e=t,function(){return!i(e,this,arguments)}),a=!!Object.defineProperty&&!t(function(){
return Object.defineProperty({},"x",{get:function(){}})}),l="foo"===function(){}.name,d=Function.call.bind(Array.prototype.forEach),u=Function.call.bind(
Array.prototype.reduce),f=Function.call.bind(Array.prototype.filter),h=Function.call.bind(Array.prototype.some),p=function(e,t,n,i){!i&&t in e||(
a?Object.defineProperty(e,t,{configurable:!0,enumerable:!1,writable:!0,value:n}):e[t]=n)},_=function(n,i,o){d(s(i),function(e){var t=i[e];p(n,e,t,!!o)})},
v=Function.call.bind(Object.prototype.toString),g="function"==typeof/abc/?function(e){return"function"==typeof e&&"[object Function]"===v(e)}:function(e){
return"function"==typeof e},m=function(e,t,n){if(!a)throw new TypeError("getters require true ES5 support");Object.defineProperty(e,t,{configurable:!0,
enumerable:!1,get:n})},b=function(e,t,n){if(a){var i=Object.getOwnPropertyDescriptor(e,t);i.value=n,Object.defineProperty(e,t,i)}else e[t]=n},y=function(e,t){
t&&g(t.toString)&&p(e,"toString",t.toString.bind(t),!0)},C=Object.create||function(e,o){var t=function t(){};t.prototype=e;var r=new t
;return"undefined"!=typeof o&&s(o).forEach(function(e){var t,n,i;t=r,i=o[n=e],a?Object.defineProperty(t,n,i):"value"in i&&(t[n]=i.value)}),r},k=function(i,t){
return!!Object.setPrototypeOf&&o(function(){var e=function n(e){var t=new i(e);return Object.setPrototypeOf(t,n.prototype),t};return Object.setPrototypeOf(e,i),
e.prototype=C(i.prototype,{constructor:{value:e}}),t(e)})},x=function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if(
"undefined"!=typeof global)return global;throw new Error("unable to locate global object")}(),$=x.isFinite,O=Function.call.bind(String.prototype.indexOf),
j=Function.apply.bind(Array.prototype.indexOf),S=Function.call.bind(Array.prototype.concat),I=Function.call.bind(String.prototype.slice),T=Function.call.bind(
Array.prototype.push),D=Function.apply.bind(Array.prototype.push),E=Function.call.bind(Array.prototype.shift),A=Math.max,P=Math.min,M=Math.floor,N=Math.abs,
R=Math.exp,L=Math.log,B=Math.sqrt,F=Function.call.bind(Object.prototype.hasOwnProperty),U=function(){},H=x.Map,V=H&&H.prototype["delete"],q=H&&H.prototype.get,
z=H&&H.prototype.has,G=H&&H.prototype.set,J=x.Symbol||{},W=J.species||"@@species",Q=Number.isNaN||function(e){return e!=e},Z=Number.isFinite||function(e){
return"number"==typeof e&&$(e)},Y=g(Math.sign)?Math.sign:function(e){var t=Number(e);return 0===t?t:Q(t)?t:t<0?-1:1},K=function(e){var t=Number(e)
;return t<-1||Q(t)?NaN:0===t||t===Infinity?t:-1===t?-Infinity:1+t-1==0?t:t*(L(1+t)/(1+t-1))},X=function ee(e){return"[object Arguments]"===v(e)},ee=(
function ee(e){return null!==e&&"object"==typeof e&&"number"==typeof e.length&&0<=e.length&&"[object Array]"!==v(e)&&"[object Function]"===v(e.callee)},X(
arguments)?X:function ee(e){return null!==e&&"object"==typeof e&&"number"==typeof e.length&&0<=e.length&&"[object Array]"!==v(e)&&"[object Function]"===v(
e.callee)}),te=function(e){return null===e||"function"!=typeof e&&"object"!=typeof e},ne=function(e){return"[object String]"===v(e)},ie=function(e){
return"[object RegExp]"===v(e)},oe=function(e){return"function"==typeof x.Symbol&&"symbol"==typeof e},re=function re(e,t,n){var i=e[t];p(e,t,n,!0),y(e[t],i)},
ae="function"==typeof J&&"function"==typeof J["for"]&&oe(J()),se=oe(J.iterator)?J.iterator:"_es6-shim iterator_";x.Set&&"function"==typeof(new x.Set
)["@@iterator"]&&(se="@@iterator"),x.Reflect||p(x,"Reflect",{},!0);var ce,le=x.Reflect,de=String,ue="undefined"!=typeof document&&document?document.all:null,
fe=null==ue?function fe(e){return null==e}:function(e){return null==e&&e!==ue},he={Call:function(e,t){var n=2<arguments.length?arguments[2]:[];if(
!he.IsCallable(e))throw new TypeError(e+" is not a function");return i(e,t,n)},RequireObjectCoercible:function(e,t){if(fe(e))throw new TypeError(
t||"Cannot call method on "+e);return e},TypeIsObject:function(e){return null!=e&&!0!==e&&!1!==e&&("function"==typeof e||"object"==typeof e||e===ue)},
ToObject:function(e,t){return Object(he.RequireObjectCoercible(e,t))},IsCallable:g,IsConstructor:function(e){return he.IsCallable(e)},ToInt32:function(e){
return he.ToNumber(e)>>0},ToUint32:function(e){return he.ToNumber(e)>>>0},ToNumber:function(e){if("[object Symbol]"===v(e))throw new TypeError(
"Cannot convert a Symbol value to a number");return+e},ToInteger:function(e){var t=he.ToNumber(e);return Q(t)?0:0!==t&&Z(t)?(0<t?1:-1)*M(N(t)):t},
ToLength:function(e){var t=he.ToInteger(e);return t<=0?0:t>Number.MAX_SAFE_INTEGER?Number.MAX_SAFE_INTEGER:t},SameValue:function(e,t){
return e===t?0!==e||1/e==1/t:Q(e)&&Q(t)},SameValueZero:function(e,t){return e===t||Q(e)&&Q(t)},IsIterable:function(e){return he.TypeIsObject(e)&&(
"undefined"!=typeof e[se]||ee(e))},GetIterator:function(e){if(ee(e))return new r(e,"value");var t=he.GetMethod(e,se);if(!he.IsCallable(t))throw new TypeError(
"value is not an iterable");var n=he.Call(t,e);if(!he.TypeIsObject(n))throw new TypeError("bad iterator");return n},GetMethod:function(e,t){var n=he.ToObject(e
)[t];if(!fe(n)){if(!he.IsCallable(n))throw new TypeError("Method not callable: "+t);return n}},IteratorComplete:function(e){return!!e.done},
IteratorClose:function(e,t){var n=he.GetMethod(e,"return");if(void 0!==n){var i,o;try{i=he.Call(n,e)}catch(r){o=r}if(!t){if(o)throw o;if(!he.TypeIsObject(i)
)throw new TypeError("Iterator's return method returned a non-object.")}}},IteratorNext:function(e){var t=1<arguments.length?e.next(arguments[1]):e.next();if(
!he.TypeIsObject(t))throw new TypeError("bad iterator");return t},IteratorStep:function(e){var t=he.IteratorNext(e);return!he.IteratorComplete(t)&&t},
Construct:function(e,t,n,i){var o="undefined"==typeof n?e:n;if(!i&&le.construct)return le.construct(e,t,o);var r=o.prototype;he.TypeIsObject(r)||(
r=Object.prototype);var a=C(r),s=he.Call(e,a,t);return he.TypeIsObject(s)?s:a},SpeciesConstructor:function(e,t){var n=e.constructor;if(void 0===n)return t;if(
!he.TypeIsObject(n))throw new TypeError("Bad constructor");var i=n[W];if(fe(i))return t;if(!he.IsConstructor(i))throw new TypeError("Bad @@species");return i},
CreateHTML:function(e,t,n,i){var o=he.ToString(e),r="<"+t;return""!==n&&(r+=" "+n+'="'+he.ToString(i).replace(/"/g,"&quot;")+'"'),r+">"+o+"</"+t+">"},
IsRegExp:function(e){if(!he.TypeIsObject(e))return!1;var t=e[J.match];return"undefined"!=typeof t?!!t:ie(e)},ToString:function(e){return de(e)}};if(a&&ae){
var pe=function pe(e){if(oe(J[e]))return J[e];var t=J["for"]("Symbol."+e);return Object.defineProperty(J,e,{configurable:!1,enumerable:!1,writable:!1,value:t}),
t};if(!oe(J.search)){var ve=pe("search"),ge=String.prototype.search;p(RegExp.prototype,ve,function(e){return he.Call(ge,e,[this])}),re(String.prototype,"search"
,function(e){var t=he.RequireObjectCoercible(this);if(!fe(e)){var n=he.GetMethod(e,ve);if("undefined"!=typeof n)return he.Call(n,e,[t])}return he.Call(ge,t,[
he.ToString(e)])})}if(!oe(J.replace)){var me=pe("replace"),be=String.prototype.replace;p(RegExp.prototype,me,function(e,t){return he.Call(be,e,[this,t])}),re(
String.prototype,"replace",function(e,t){var n=he.RequireObjectCoercible(this);if(!fe(e)){var i=he.GetMethod(e,me);if("undefined"!=typeof i)return he.Call(i,e,[
n,t])}return he.Call(be,n,[he.ToString(e),t])})}if(!oe(J.split)){var ye=pe("split"),Ce=String.prototype.split;p(RegExp.prototype,ye,function(e,t){
return he.Call(Ce,e,[this,t])}),re(String.prototype,"split",function(e,t){var n=he.RequireObjectCoercible(this);if(!fe(e)){var i=he.GetMethod(e,ye);if(
"undefined"!=typeof i)return he.Call(i,e,[n,t])}return he.Call(Ce,n,[he.ToString(e),t])})}var we=oe(J.match),_e=we&&((ce={})[J.match]=function(){return 42},
42!=="a".match(ce));if(!we||_e){var ke=pe("match"),xe=String.prototype.match;p(RegExp.prototype,ke,function(e){return he.Call(xe,e,[this])}),re(String.prototype
,"match",function(e){var t=he.RequireObjectCoercible(this);if(!fe(e)){var n=he.GetMethod(e,ke);if("undefined"!=typeof n)return he.Call(n,e,[t])}return he.Call(
xe,t,[he.ToString(e)])})}}var $e=function $e(t,n,i){y(n,t),Object.setPrototypeOf&&Object.setPrototypeOf(t,n),a?d(Object.getOwnPropertyNames(t),function(e){
e in U||i[e]||function(t,n,e){if(!a)throw new TypeError("getters require true ES5 support");var i=Object.getOwnPropertyDescriptor(t,n);Object.defineProperty(e,n
,{configurable:i.configurable,enumerable:i.enumerable,get:function(){return t[n]},set:function(e){t[n]=e}})}(t,e,n)}):d(Object.keys(t),function(e){
e in U||i[e]||(n[e]=t[e])}),n.prototype=t.prototype,b(t.prototype,"constructor",n)},Oe=function(){return this},je=function(e){a&&!F(e,W)&&m(e,W,Oe)},
Se=function(e,t){var n=t||function(){return this};p(e,se,n),!e[se]&&oe(se)&&(e[se]=n)},Ie=function Ie(e,t,n){a?Object.defineProperty(e,t,{configurable:!0,
enumerable:!0,writable:!0,value:n}):e[t]=n},Te=function Te(e,t,n){if(Ie(e,t,n),!he.SameValue(e[t],n))throw new TypeError("property is nonconfigurable")},
De=function(e,t,n,i){if(!he.TypeIsObject(e))throw new TypeError("Constructor requires `new`: "+t.name);var o=t.prototype;he.TypeIsObject(o)||(o=n);var r=C(o)
;for(var a in i)if(F(i,a)){var s=i[a];p(r,a,s,!0)}return r};if(String.fromCodePoint&&1!==String.fromCodePoint.length){var Ee=String.fromCodePoint;re(String,
"fromCodePoint",function(e){return he.Call(Ee,this,arguments)})}var Ae={fromCodePoint:function(e){for(var t,n=[],i=0,o=arguments.length;i<o;i++){if(t=Number(
arguments[i]),!he.SameValue(t,he.ToInteger(t))||t<0||1114111<t)throw new RangeError("Invalid code point "+t);t<65536?T(n,String.fromCharCode(t)):(t-=65536,T(n,
String.fromCharCode(55296+(t>>10))),T(n,String.fromCharCode(t%1024+56320)))}return n.join("")},raw:function(e){var t=he.ToObject(e,"bad callSite"),
n=he.ToObject(t.raw,"bad raw value"),i=n.length,o=he.ToLength(i);if(o<=0)return"";for(var r,a,s,c,l=[],d=0;d<o&&(r=he.ToString(d),s=he.ToString(n[r]),T(l,s),!(
o<=d+1));)a=d+1<arguments.length?arguments[d+1]:"",c=he.ToString(a),T(l,c),d+=1;return l.join("")}};String.raw&&"xy"!==String.raw({raw:{0:"x",1:"y",length:2}}
)&&re(String,"raw",Ae.raw),_(String,Ae),function _i(e,t){if(t<1)return"";if(t%2)return _i(e,t-1)+e;var n=_i(e,t/2);return n+n};var Pe=Infinity,Me={
repeat:function _i(e){var t=he.ToString(he.RequireObjectCoercible(this)),n=he.ToInteger(e);if(n<0||Pe<=n)throw new RangeError(
"repeat count must be less than infinity and not overflow maximum string size");return function Vo(e,t){if(t<1)return"";if(t%2)return Vo(e,t-1)+e;var n=Vo(e,t/2
);return n+n}(t,n)},startsWith:function(e){var t=he.ToString(he.RequireObjectCoercible(this));if(he.IsRegExp(e))throw new TypeError(
'Cannot call method "startsWith" with a regex');var n,i=he.ToString(e);1<arguments.length&&(n=arguments[1]);var o=A(he.ToInteger(n),0);return I(t,o,o+i.length
)===i},endsWith:function(e){var t=he.ToString(he.RequireObjectCoercible(this));if(he.IsRegExp(e))throw new TypeError(
'Cannot call method "endsWith" with a regex');var n,i=he.ToString(e),o=t.length;1<arguments.length&&(n=arguments[1]);var r="undefined"==typeof n?o:he.ToInteger(
n),a=P(A(r,0),o);return I(t,a-i.length,a)===i},includes:function(e){if(he.IsRegExp(e))throw new TypeError('"includes" does not accept a RegExp');var t,
n=he.ToString(e);return 1<arguments.length&&(t=arguments[1]),-1!==O(this,n,t)},codePointAt:function(e){var t=he.ToString(he.RequireObjectCoercible(this)),
n=he.ToInteger(e),i=t.length;if(0<=n&&n<i){var o=t.charCodeAt(n);if(o<55296||56319<o||n+1===i)return o;var r=t.charCodeAt(n+1);return r<56320||57343<r?o:1024*(
o-55296)+(r-56320)+65536}}};if(String.prototype.includes&&!1!=="a".includes("a",Infinity)&&re(String.prototype,"includes",Me.includes),
String.prototype.startsWith&&String.prototype.endsWith){var Ne=t(function(){return"/a/".startsWith(/a/)}),Re=o(function(){return!1==="abc".startsWith("a",
Infinity)});Ne&&Re||(re(String.prototype,"startsWith",Me.startsWith),re(String.prototype,"endsWith",Me.endsWith))}ae&&(o(function(){var e=/a/
;return e[J.match]=!1,"/a/".startsWith(e)})||re(String.prototype,"startsWith",Me.startsWith),o(function(){var e=/a/;return e[J.match]=!1,"/a/".endsWith(e)}
)||re(String.prototype,"endsWith",Me.endsWith),o(function(){var e=/a/;return e[J.match]=!1,"/a/".includes(e)})||re(String.prototype,"includes",Me.includes)),_(
String.prototype,Me);var Le=["\t\n\x0B\f\r   ᠎    ","         　\u2028","\u2029\ufeff"].join(""),Be=new RegExp("(^["+Le+"]+)|(["+Le+"]+$)","g"),Fe=function(){
return he.ToString(he.RequireObjectCoercible(this)).replace(Be,"")},Ue=["","​","￾"].join(""),He=new RegExp("["+Ue+"]","g"),Ve=/^[-+]0x[0-9a-f]+$/i,qe=Ue.trim(
).length!==Ue.length;p(String.prototype,"trim",Fe,qe);var ze=function(e){return{value:e,done:0===arguments.length}},Ge=function(e){he.RequireObjectCoercible(e),
this._s=he.ToString(e),this._i=0};Ge.prototype.next=function(){var e=this._s,t=this._i;if("undefined"==typeof e||t>=e.length)return this._s=void 0,ze();var n,i,
o=e.charCodeAt(t);return i=o<55296||56319<o||t+1===e.length?1:(n=e.charCodeAt(t+1))<56320||57343<n?1:2,this._i=t+i,ze(e.substr(t,i))},Se(Ge.prototype),Se(
String.prototype,function(){return new Ge(this)});var Je={from:function(e){var t,n,i,o,r,a;if(1<arguments.length&&(t=arguments[1]),"undefined"==typeof t
)n=!1;else{if(!he.IsCallable(t))throw new TypeError("Array.from: when provided, the second argument must be a function");2<arguments.length&&(i=arguments[2]),
n=!0}if("undefined"!=typeof(ee(e)||he.GetMethod(e,se))){r=he.IsConstructor(this)?Object(new this):[];var s,c,l=he.GetIterator(e);for(a=0;!1!==(
s=he.IteratorStep(l));){c=s.value;try{n&&(c="undefined"==typeof i?t(c,a):w(t,i,c,a)),r[a]=c}catch(f){throw he.IteratorClose(l,!0),f}a+=1}o=a}else{var d,
u=he.ToObject(e);for(o=he.ToLength(u.length),r=he.IsConstructor(this)?Object(new this(o)):new Array(o),a=0;a<o;++a)d=u[a],n&&(d="undefined"==typeof i?t(d,a):w(t
,i,d,a)),Te(r,a,d)}return r.length=o,r},of:function(){for(var e=arguments.length,t=c(this)||!he.IsCallable(this)?new Array(e):he.Construct(this,[e]),n=0;n<e;++n
)Te(t,n,arguments[n]);return t.length=e,t}};_(Array,Je),je(Array),_((r=function(e,t){this.i=0,this.array=e,this.kind=t}).prototype,{next:function(){var e=this.i
,t=this.array;if(!(this instanceof r))throw new TypeError("Not an ArrayIterator");if("undefined"!=typeof t)for(var n=he.ToLength(t.length);e<n;e++){var i,
o=this.kind;return"key"===o?i=e:"value"===o?i=t[e]:"entry"===o&&(i=[e,t[e]]),this.i=e+1,ze(i)}return this.array=void 0,ze()}}),Se(r.prototype),
Array.of===Je.of||function(){var t=function t(e){this.length=e};t.prototype=[];var e=Array.of.apply(t,[1,2]);return e instanceof t&&2===e.length}()||re(Array,
"of",Je.of);var We={copyWithin:function(e,t){var n,i=he.ToObject(this),o=he.ToLength(i.length),r=he.ToInteger(e),a=he.ToInteger(t),s=r<0?A(o+r,0):P(r,o),
c=a<0?A(o+a,0):P(a,o);2<arguments.length&&(n=arguments[2]);var l="undefined"==typeof n?o:he.ToInteger(n),d=l<0?A(o+l,0):P(l,o),u=P(d-c,o-s),f=1;for(
c<s&&s<c+u&&(f=-1,c+=u-1,s+=u-1);0<u;)c in i?i[s]=i[c]:delete i[s],c+=f,s+=f,u-=1;return i},fill:function(e){var t,n;1<arguments.length&&(t=arguments[1]),
2<arguments.length&&(n=arguments[2]);var i=he.ToObject(this),o=he.ToLength(i.length);t=he.ToInteger("undefined"==typeof t?0:t);for(var r=(n=he.ToInteger(
"undefined"==typeof n?o:n))<0?o+n:n,a=t<0?A(o+t,0):P(t,o);a<o&&a<r;++a)i[a]=e;return i},find:function(e){var t=he.ToObject(this),n=he.ToLength(t.length);if(
!he.IsCallable(e))throw new TypeError("Array#find: predicate must be a function");for(var i,o=1<arguments.length?arguments[1]:null,r=0;r<n;r++)if(i=t[r],o){if(
w(e,o,i,r,t))return i}else if(e(i,r,t))return i},findIndex:function(e){var t=he.ToObject(this),n=he.ToLength(t.length);if(!he.IsCallable(e))throw new TypeError(
"Array#findIndex: predicate must be a function");for(var i=1<arguments.length?arguments[1]:null,o=0;o<n;o++)if(i){if(w(e,i,t[o],o,t))return o}else if(e(t[o],o,t
))return o;return-1},keys:function s(){return new r(this,"key")},values:function(){return new r(this,"value")},entries:function(){return new r(this,"entry")}}
;if(Array.prototype.keys&&!he.IsCallable([1].keys().next)&&delete Array.prototype.keys,Array.prototype.entries&&!he.IsCallable([1].entries().next
)&&delete Array.prototype.entries,Array.prototype.keys&&Array.prototype.entries&&!Array.prototype.values&&Array.prototype[se]&&(_(Array.prototype,{
values:Array.prototype[se]}),oe(J.unscopables)&&(Array.prototype[J.unscopables].values=!0)),l&&Array.prototype.values&&"values"!==Array.prototype.values.name){
var Qe=Array.prototype.values;re(Array.prototype,"values",function(){return he.Call(Qe,this,arguments)}),p(Array.prototype,se,Array.prototype.values,!0)}_(
Array.prototype,We),1/[!0].indexOf(!0,-0)<0&&p(Array.prototype,"indexOf",function(e){var t=j(this,arguments);return 0===t&&1/t<0?0:t},!0),Se(Array.prototype,
function(){return this.values()}),Object.getPrototypeOf&&Se(Object.getPrototypeOf([].values()));var Ze,Ye=o(function(){return 0===Array.from({length:-1}).length
}),Ke=1===(Ze=Array.from([0].entries())).length&&c(Ze[0])&&0===Ze[0][0]&&0===Ze[0][1];if(Ye&&Ke||re(Array,"from",Je.from),!o(function(){return Array.from([0],
void 0)})){var Xe=Array.from;re(Array,"from",function(e){return 1<arguments.length&&"undefined"!=typeof arguments[1]?he.Call(Xe,this,arguments):w(Xe,this,e)})}
var et=-(Math.pow(2,32)-1),tt=function(e,t){var n={length:et};return n[t?(n.length>>>0)-1:0]=!0,o(function(){return w(e,n,function(){throw new RangeError(
"should not reach here")},[]),!0})};if(!tt(Array.prototype.forEach)){var nt=Array.prototype.forEach;re(Array.prototype,"forEach",function(e){return he.Call(nt,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.map)){var it=Array.prototype.map;re(Array.prototype,"map",function(e){return he.Call(it,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.filter)){var ot=Array.prototype.filter;re(Array.prototype,"filter",function(e){return he.Call(ot,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.some)){var rt=Array.prototype.some;re(Array.prototype,"some",function(e){return he.Call(rt,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.every)){var at=Array.prototype.every;re(Array.prototype,"every",function(e){return he.Call(at,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.reduce)){var st=Array.prototype.reduce;re(Array.prototype,"reduce",function(e){return he.Call(st,
0<=this.length?this:[],arguments)},!0)}if(!tt(Array.prototype.reduceRight,!0)){var ct=Array.prototype.reduceRight;re(Array.prototype,"reduceRight",function(e){
return he.Call(ct,0<=this.length?this:[],arguments)},!0)}var lt,dt=8!==Number("0o10"),ut=2!==Number("0b10"),ft=h(Ue,function(e){return 0===Number(e+0+e)});if(
dt||ut||ft){var ht=Number,pt=/^0b[01]+$/i,vt=/^0o[0-7]+$/i,gt=pt.test.bind(pt),mt=vt.test.bind(vt),bt=He.test.bind(He),yt=Ve.test.bind(Ve),Ct=lt=function(e){
var t;"string"==typeof(t=0<arguments.length?te(e)?e:function(e){var t;if("function"==typeof e.valueOf&&(t=e.valueOf(),te(t)))return t;if(
"function"==typeof e.toString&&(t=e.toString(),te(t)))return t;throw new TypeError("No default value")}(e):0)&&(t=he.Call(Fe,t),gt(t)?t=parseInt(I(t,2),2):mt(t
)?t=parseInt(I(t,2),8):(bt(t)||yt(t))&&(t=NaN));var n=this,i=o(function(){return ht.prototype.valueOf.call(n),!0});return n instanceof lt&&!i?new ht(t):ht(t)}
;$e(ht,Ct,{}),_(Ct,{NaN:ht.NaN,MAX_VALUE:ht.MAX_VALUE,MIN_VALUE:ht.MIN_VALUE,NEGATIVE_INFINITY:ht.NEGATIVE_INFINITY,POSITIVE_INFINITY:ht.POSITIVE_INFINITY}),
Number=Ct,b(x,"Number",Ct)}var wt=Math.pow(2,53)-1;_(Number,{MAX_SAFE_INTEGER:wt,MIN_SAFE_INTEGER:-wt,EPSILON:2220446049250313e-31,parseInt:x.parseInt,
parseFloat:x.parseFloat,isFinite:Z,isInteger:function(e){return Z(e)&&he.ToInteger(e)===e},isSafeInteger:function(e){return Number.isInteger(e)&&N(e
)<=Number.MAX_SAFE_INTEGER},isNaN:Q}),p(Number,"parseInt",x.parseInt,Number.parseInt!==x.parseInt),1===[,1].find(function(){return!0})&&re(Array.prototype,
"find",We.find),0!==[,1].findIndex(function(){return!0})&&re(Array.prototype,"findIndex",We.findIndex);var _t,kt,xt,$t=Function.bind.call(Function.bind,
Object.prototype.propertyIsEnumerable),Ot=function Ot(e,t){a&&$t(e,t)&&Object.defineProperty(e,t,{enumerable:!1})},jt=function jt(){for(var e=Number(this),
t=arguments.length,n=t-e,i=new Array(n<0?0:n),o=e;o<t;++o)i[o-e]=arguments[o];return i},St=function St(n){return function(e,t){return e[t]=n[t],e}},It=function(
e,t){var n,i=s(Object(t));return he.IsCallable(Object.getOwnPropertySymbols)&&(n=f(Object.getOwnPropertySymbols(Object(t)),$t(t))),u(S(i,n||[]),St(t),e)},Tt={
assign:function(e,t){var n=he.ToObject(e,"Cannot convert undefined or null to object");return u(he.Call(jt,1,arguments),It,n)},is:function(e,t){
return he.SameValue(e,t)}};if(Object.assign&&Object.preventExtensions&&function(){var e=Object.preventExtensions({1:2});try{Object.assign(e,"xy")}catch(t){
return"y"===e[1]}}()&&re(Object,"assign",Tt.assign),_(Object,Tt),a){var Dt={setPrototypeOf:function(e,t){var n,i=function(e,t){return function(e,t){if(
!he.TypeIsObject(e))throw new TypeError("cannot set prototype on a non-object");if(null!==t&&!he.TypeIsObject(t))throw new TypeError(
"can only set prototype to an object or null"+t)}(e,t),w(n,e,t),e};try{n=e.getOwnPropertyDescriptor(e.prototype,t).set,w(n,{},null)}catch(o){if(
e.prototype!=={}[t])return;n=function(e){this[t]=e},i.polyfill=i(i({},null),e.prototype)instanceof e}return i}(Object,"__proto__")};_(Object,Dt)}if(
Object.setPrototypeOf&&Object.getPrototypeOf&&null!==Object.getPrototypeOf(Object.setPrototypeOf({},null))&&null===Object.getPrototypeOf(Object.create(null))&&(
_t=Object.create(null),kt=Object.getPrototypeOf,xt=Object.setPrototypeOf,Object.getPrototypeOf=function(e){var t=kt(e);return t===_t?null:t},
Object.setPrototypeOf=function(e,t){return xt(e,null===t?_t:t)},Object.setPrototypeOf.polyfill=!1),t(function(){return Object.keys("foo")})){var Et=Object.keys
;re(Object,"keys",function s(e){return Et(he.ToObject(e))}),s=Object.keys}if(t(function(){return Object.keys(/a/g)})){var At=Object.keys;re(Object,"keys",
function s(e){if(ie(e)){var t=[];for(var n in e)F(e,n)&&T(t,n);return t}return At(e)}),s=Object.keys}if(Object.getOwnPropertyNames&&t(function(){
return Object.getOwnPropertyNames("foo")})){var Pt="object"==typeof window?Object.getOwnPropertyNames(window):[],Mt=Object.getOwnPropertyNames;re(Object,
"getOwnPropertyNames",function(e){var t=he.ToObject(e);if("[object Window]"===v(t))try{return Mt(t)}catch(n){return S([],Pt)}return Mt(t)})}if(
Object.getOwnPropertyDescriptor&&t(function(){return Object.getOwnPropertyDescriptor("foo","bar")})){var Nt=Object.getOwnPropertyDescriptor;re(Object,
"getOwnPropertyDescriptor",function(e,t){return Nt(he.ToObject(e),t)})}if(Object.seal&&t(function(){return Object.seal("foo")})){var Rt=Object.seal;re(Object,
"seal",function(e){return he.TypeIsObject(e)?Rt(e):e})}if(Object.isSealed&&t(function(){return Object.isSealed("foo")})){var Lt=Object.isSealed;re(Object,
"isSealed",function(e){return!he.TypeIsObject(e)||Lt(e)})}if(Object.freeze&&t(function(){return Object.freeze("foo")})){var Bt=Object.freeze;re(Object,"freeze",
function(e){return he.TypeIsObject(e)?Bt(e):e})}if(Object.isFrozen&&t(function(){return Object.isFrozen("foo")})){var Ft=Object.isFrozen;re(Object,"isFrozen",
function(e){return!he.TypeIsObject(e)||Ft(e)})}if(Object.preventExtensions&&t(function(){return Object.preventExtensions("foo")})){
var Ut=Object.preventExtensions;re(Object,"preventExtensions",function(e){return he.TypeIsObject(e)?Ut(e):e})}if(Object.isExtensible&&t(function(){
return Object.isExtensible("foo")})){var Ht=Object.isExtensible;re(Object,"isExtensible",function(e){return!!he.TypeIsObject(e)&&Ht(e)})}if(
Object.getPrototypeOf&&t(function(){return Object.getPrototypeOf("foo")})){var Vt=Object.getPrototypeOf;re(Object,"getPrototypeOf",function(e){return Vt(
he.ToObject(e))})}var qt,zt=a&&(qt=Object.getOwnPropertyDescriptor(RegExp.prototype,"flags"))&&he.IsCallable(qt.get);a&&!zt&&m(RegExp.prototype,"flags",
function(){if(!he.TypeIsObject(this))throw new TypeError("Method called on incompatible type: must be an object.");var e="";return this.global&&(e+="g"),
this.ignoreCase&&(e+="i"),this.multiline&&(e+="m"),this.unicode&&(e+="u"),this.sticky&&(e+="y"),e});var Gt,Jt=a&&o(function(){return"/a/i"===String(new RegExp(
/a/g,"i"))}),Wt=ae&&a&&((Gt=/./)[J.match]=!1,RegExp(Gt)===Gt),Qt=o(function(){return"/abc/"===RegExp.prototype.toString.call({source:"abc"})}),Zt=Qt&&o(
function(){return"/a/b"===RegExp.prototype.toString.call({source:"a",flags:"b"})});if(!Qt||!Zt){var Yt=RegExp.prototype.toString;p(RegExp.prototype,"toString",
function(){var e=he.RequireObjectCoercible(this);return ie(e)?w(Yt,e):"/"+de(e.source)+"/"+de(e.flags)},!0),y(RegExp.prototype.toString,Yt)}if(a&&(!Jt||Wt)){
var Kt=Object.getOwnPropertyDescriptor(RegExp.prototype,"flags").get,Xt=Object.getOwnPropertyDescriptor(RegExp.prototype,"source")||{},en=he.IsCallable(Xt.get
)?Xt.get:function(){return this.source},tn=RegExp,nn=function ki(e,t){var n=he.IsRegExp(e);if(!(this instanceof ki
)&&n&&"undefined"==typeof t&&e.constructor===ki)return e;var i=e,o=t;return ie(e)?(i=he.Call(en,e),o="undefined"==typeof t?he.Call(Kt,e):t,new ki(i,o)):(n&&(
i=e.source,o="undefined"==typeof t?e.flags:t),new tn(e,t))};$e(tn,nn,{$input:!0}),RegExp=nn,b(x,"RegExp",nn)}if(a){var on={input:"$_",lastMatch:"$&",
lastParen:"$+",leftContext:"$`",rightContext:"$'"};d(s(on),function(e){e in RegExp&&!(on[e]in RegExp)&&m(RegExp,on[e],function(){return RegExp[e]})})}je(RegExp)
;var rn=1/Number.EPSILON,an=function an(e){return e+rn-rn},sn=Math.pow(2,-23),cn=Math.pow(2,127)*(2-sn),ln=Math.pow(2,-126),dn=Math.E,un=Math.LOG2E,
fn=Math.LOG10E,hn=Number.prototype.clz;delete Number.prototype.clz;var pn={acosh:function(e){var t=Number(e);if(Q(t)||e<1)return NaN;if(1===t)return 0;if(
t===Infinity)return t;var n=1/(t*t);if(t<2)return K(t-1+B(1-n)*t);var i=t/2;return K(i+B(1-n)*i-1)+1/un},asinh:function(e){var t=Number(e);if(0===t||!$(t)
)return t;var n=N(t),i=n*n,o=Y(t);return n<1?o*K(n+i/(B(i+1)+1)):o*(K(n/2+B(1+1/i)*n/2-1)+1/un)},atanh:function(e){var t=Number(e);if(0===t)return t;if(-1===t
)return-Infinity;if(1===t)return Infinity;if(Q(t)||t<-1||1<t)return NaN;var n=N(t);return Y(t)*K(2*n/(1-n))/2},cbrt:function(e){var t=Number(e);if(0===t
)return t;var n,i=t<0;return i&&(t=-t),n=t===Infinity?Infinity:(t/((n=R(L(t)/3))*n)+2*n)/3,i?-n:n},clz32:function(e){var t=Number(e),n=he.ToUint32(t)
;return 0===n?32:hn?he.Call(hn,n):31-M(L(n+.5)*un)},cosh:function(e){var t=Number(e);if(0===t)return 1;if(Q(t))return NaN;if(!$(t))return Infinity;var n=R(N(t
)-1);return(n+1/(n*dn*dn))*(dn/2)},expm1:function(e){var t=Number(e);if(t===-Infinity)return-1;if(!$(t)||0===t)return t;if(.5<N(t))return R(t)-1;for(var n=t,i=0
,o=1;i+n!==i;)i+=n,n*=t/(o+=1);return i},hypot:function(e,t){for(var n=0,i=0,o=0;o<arguments.length;++o){var r=N(Number(arguments[o]));i<r?(n*=i/r*(i/r),n+=1,
i=r):n+=0<r?r/i*(r/i):r}return i===Infinity?Infinity:i*B(n)},log2:function(e){return L(e)*un},log10:function(e){return L(e)*fn},log1p:K,sign:Y,sinh:function(e){
var t=Number(e);if(!$(t)||0===t)return t;var n=N(t);if(n<1){var i=Math.expm1(n);return Y(t)*i*(1+1/(i+1))/2}var o=R(n-1);return Y(t)*(o-1/(o*dn*dn))*(dn/2)},
tanh:function(e){var t=Number(e);return Q(t)||0===t?t:20<=t?1:t<=-20?-1:(Math.expm1(t)-Math.expm1(-t))/(R(t)+R(-t))},trunc:function(e){var t=Number(e)
;return t<0?-M(-t):M(t)},imul:function(e,t){var n=he.ToUint32(e),i=he.ToUint32(t),o=65535&n,r=65535&i;return o*r+((n>>>16&65535)*r+o*(i>>>16&65535)<<16>>>0)|0},
fround:function(e){var t=Number(e);if(0===t||t===Infinity||t===-Infinity||Q(t))return t;var n=Y(t),i=N(t);if(i<ln)return n*an(i/ln/sn)*ln*sn;var o=(
1+sn/Number.EPSILON)*i,r=o-(o-i);return cn<r||Q(r)?n*Infinity:n*r}},vn=function vn(e,t,n){return N(1-e/t)/Number.EPSILON<(n||8)};_(Math,pn),p(Math,"sinh",
pn.sinh,Math.sinh(710)===Infinity),p(Math,"cosh",pn.cosh,Math.cosh(710)===Infinity),p(Math,"log1p",pn.log1p,-1e-17!==Math.log1p(-1e-17)),p(Math,"asinh",pn.asinh
,Math.asinh(-1e7)!==-Math.asinh(1e7)),p(Math,"asinh",pn.asinh,Math.asinh(1e300)===Infinity),p(Math,"atanh",pn.atanh,0===Math.atanh(1e-300)),p(Math,"tanh",
pn.tanh,-2e-17!==Math.tanh(-2e-17)),p(Math,"acosh",pn.acosh,Math.acosh(Number.MAX_VALUE)===Infinity),p(Math,"acosh",pn.acosh,!vn(Math.acosh(1+Number.EPSILON),
Math.sqrt(2*Number.EPSILON))),p(Math,"cbrt",pn.cbrt,!vn(Math.cbrt(1e-300),1e-100)),p(Math,"sinh",pn.sinh,-2e-17!==Math.sinh(-2e-17));var gn=Math.expm1(10);p(
Math,"expm1",pn.expm1,22025.465794806718<gn||gn<22025.465794806718);var mn=Math.round,bn=0===Math.round(.5-Number.EPSILON/4)&&1===Math.round(
Number.EPSILON/3.99-.5),yn=[rn+1,2*rn-1].every(function(e){return Math.round(e)===e});p(Math,"round",function(e){var t=M(e);return e-t<.5?t:-1===t?-0:t+1},
!bn||!yn),y(Math.round,mn);var Cn=Math.imul;-5!==Math.imul(4294967295,5)&&(Math.imul=pn.imul,y(Math.imul,Cn)),2!==Math.imul.length&&re(Math,"imul",function(e,t
){return he.Call(Cn,Math,arguments)});var wn,_n,kn=function(){var t=x.setTimeout;if("function"==typeof t||"object"==typeof t){he.IsPromise=function(e){
return!!he.TypeIsObject(e)&&"undefined"!=typeof e._promise};var e,l=function(e){if(!he.IsConstructor(e))throw new TypeError("Bad promise constructor")
;var n=this;if(n.resolve=void 0,n.reject=void 0,n.promise=new e(function(e,t){if(void 0!==n.resolve||void 0!==n.reject)throw new TypeError(
"Bad Promise implementation!");n.resolve=e,n.reject=t}),!he.IsCallable(n.resolve)||!he.IsCallable(n.reject))throw new TypeError("Bad promise constructor")}
;"undefined"!=typeof window&&he.IsCallable(window.postMessage)&&(e=function(){var t=[],n="zero-timeout-message";return window.addEventListener("message",
function(e){if(e.source===window&&e.data===n){if(e.stopPropagation(),0===t.length)return;E(t)()}},!0),function(e){T(t,e),window.postMessage(n,"*")}});var n,i,r,
o,a,s=he.IsCallable(x.setImmediate)?x.setImmediate:"object"==typeof process&&process.nextTick?process.nextTick:(n=x.Promise,(i=n&&n.resolve&&n.resolve()
)&&function(e){return i.then(e)}||(he.IsCallable(e)?e():function(e){t(e,0)})),d=function(e){return e},u=function(e){throw e},f={},h=function(e,t,n){s(function(
){c(e,t,n)})},c=function(e,t,n){var i,o;if(t===f)return e(n);try{i=e(n),o=t.resolve}catch(r){i=r,o=t.reject}o(i)},p=function(e,t){var n=e._promise,
i=n.reactionLength;if(0<i&&(h(n.fulfillReactionHandler0,n.reactionCapability0,t),n.fulfillReactionHandler0=void 0,n.rejectReactions0=void 0,
n.reactionCapability0=void 0,1<i))for(var o=1,r=0;o<i;o++,r+=3)h(n[r+0],n[r+2],t),e[r+0]=void 0,e[r+1]=void 0,e[r+2]=void 0;n.result=t,n.state=1,
n.reactionLength=0},v=function(e,t){var n=e._promise,i=n.reactionLength;if(0<i&&(h(n.rejectReactionHandler0,n.reactionCapability0,t),
n.fulfillReactionHandler0=void 0,n.rejectReactions0=void 0,n.reactionCapability0=void 0,1<i))for(var o=1,r=0;o<i;o++,r+=3)h(n[r+1],n[r+2],t),e[r+0]=void 0,
e[r+1]=void 0,e[r+2]=void 0;n.result=t,n.state=2,n.reactionLength=0},g=function(i){var o=!1;return{resolve:function(e){var t;if(!o){if(o=!0,e===i)return v(i,
new TypeError("Self resolution"));if(!he.TypeIsObject(e))return p(i,e);try{t=e.then}catch(n){return v(i,n)}if(!he.IsCallable(t))return p(i,e);s(function(){b(i,e
,t)})}},reject:function(e){if(!o)return o=!0,v(i,e)}}},m=function(e,t,n,i){e===o?w(e,t,n,i,f):w(e,t,n,i)},b=function(e,t,n){var i=g(e),o=i.resolve,r=i.reject
;try{m(n,t,o,r)}catch(a){r(a)}},y=a=function(e){if(!(this instanceof a))throw new TypeError('Constructor Promise requires "new"');if(this&&this._promise
)throw new TypeError("Bad construction");if(!he.IsCallable(e))throw new TypeError("not a valid resolver");var t=De(this,a,r,{_promise:{result:void 0,state:0,
reactionLength:0,fulfillReactionHandler0:void 0,rejectReactionHandler0:void 0,reactionCapability0:void 0}}),n=g(t),i=n.reject;try{e(n.resolve,i)}catch(o){i(o)}
return t};r=y.prototype;var C=function(t,n,i,o){var r=!1;return function(e){r||(r=!0,n[t]=e,0==--o.count&&(0,i.resolve)(n))}};return _(y,{all:function(e){if(
!he.TypeIsObject(this))throw new TypeError("Promise is not object");var t,n,i=new l(this);try{return function(e,t,n){for(var i,o,r=e.iterator,a=[],s={count:1},
c=0;;){try{if(!1===(i=he.IteratorStep(r))){e.done=!0;break}o=i.value}catch(u){throw e.done=!0,u}a[c]=void 0;var l=t.resolve(o),d=C(c,a,n,s);s.count+=1,m(l.then,
l,d,n.reject),c+=1}return 0==--s.count&&(0,n.resolve)(a),n.promise}(n={iterator:t=he.GetIterator(e),done:!1},this,i)}catch(r){var o=r;if(n&&!n.done)try{
he.IteratorClose(t,!0)}catch(a){o=a}return(0,i.reject)(o),i.promise}},race:function(e){if(!he.TypeIsObject(this))throw new TypeError("Promise is not object")
;var t,n,i=new l(this);try{return function(e,t,n){for(var i,o,r,a=e.iterator;;){try{if(!1===(i=he.IteratorStep(a))){e.done=!0;break}o=i.value}catch(s){
throw e.done=!0,s}r=t.resolve(o),m(r.then,r,n.resolve,n.reject)}return n.promise}(n={iterator:t=he.GetIterator(e),done:!1},this,i)}catch(r){var o=r;if(
n&&!n.done)try{he.IteratorClose(t,!0)}catch(a){o=a}return(0,i.reject)(o),i.promise}},reject:function(e){if(!he.TypeIsObject(this))throw new TypeError(
"Bad promise constructor");var t=new l(this);return(0,t.reject)(e),t.promise},resolve:function(e){if(!he.TypeIsObject(this))throw new TypeError(
"Bad promise constructor");if(he.IsPromise(e)&&e.constructor===this)return e;var t=new l(this);return(0,t.resolve)(e),t.promise}}),_(r,{"catch":function(e){
return this.then(null,e)},then:function(e,t){if(!he.IsPromise(this))throw new TypeError("not a promise");var n,i=he.SpeciesConstructor(this,y)
;n=2<arguments.length&&arguments[2]===f&&i===y?f:new l(i);var o,r=he.IsCallable(e)?e:d,a=he.IsCallable(t)?t:u,s=this._promise;if(0===s.state){if(
0===s.reactionLength)s.fulfillReactionHandler0=r,s.rejectReactionHandler0=a,s.reactionCapability0=n;else{var c=3*(s.reactionLength-1);s[c+0]=r,s[c+1]=a,s[c+2]=n
}s.reactionLength+=1}else if(1===s.state)o=s.result,h(r,n,o);else{if(2!==s.state)throw new TypeError("unexpected Promise state");o=s.result,h(a,n,o)}
return n.promise}}),f=new l(y),o=r.then,y}}();if(x.Promise&&(delete x.Promise.accept,delete x.Promise.defer,delete x.Promise.prototype.chain),
"function"==typeof kn){_(x,{Promise:kn});var xn=k(x.Promise,function(e){return e.resolve(42).then(function(){})instanceof e}),$n=!t(function(){
return x.Promise.reject(42).then(null,5).then(null,U)}),On=t(function(){return x.Promise.call(3,U)}),jn=function(e){var t=e.resolve(5);t.constructor={}
;var n=e.resolve(t);try{n.then(null,U).then(null,U)}catch(i){return!0}return t===n}(x.Promise),Sn=a&&(wn=0,_n=Object.defineProperty({},"then",{get:function(){
wn+=1}}),Promise.resolve(_n),1===wn),In=function In(e){var t=new Promise(e);e(3,function(){}),this.then=t.then,this.constructor=In}
;In.prototype=Promise.prototype,In.all=Promise.all;var Tn=o(function(){return!!In.all([1,2])});if(xn&&$n&&On&&!jn&&Sn&&!Tn||(Promise=kn,re(x,"Promise",kn)),
1!==Promise.all.length){var Dn=Promise.all;re(Promise,"all",function(e){return he.Call(Dn,this,arguments)})}if(1!==Promise.race.length){var En=Promise.race;re(
Promise,"race",function(e){return he.Call(En,this,arguments)})}if(1!==Promise.resolve.length){var An=Promise.resolve;re(Promise,"resolve",function(e){
return he.Call(An,this,arguments)})}if(1!==Promise.reject.length){var Pn=Promise.reject;re(Promise,"reject",function(e){return he.Call(Pn,this,arguments)})}Ot(
Promise,"all"),Ot(Promise,"race"),Ot(Promise,"resolve"),Ot(Promise,"reject"),je(Promise)}var Mn,Nn,Rn=function(e){var t=s(u(e,function(e,t){return e[t]=!0,e},{}
));return e.join(":")===t.join(":")},Ln=Rn(["z","a","bb"]),Bn=Rn(["z",1,"a","3",2]);if(a){var Fn=function Fn(e,t){return t||Ln?fe(e)?"^"+he.ToString(e
):"string"==typeof e?"$"+e:"number"==typeof e?Bn?e:"n"+e:"boolean"==typeof e?"b"+e:null:null},Un=function Un(){return Object.create?Object.create(null):{}},
Hn=function Hn(e,n,t){if(c(t)||ne(t))d(t,function(e){if(!he.TypeIsObject(e))throw new TypeError("Iterator value "+e+" is not an entry object");n.set(e[0],e[1])}
);else if(t instanceof e)w(e.prototype.forEach,t,function(e,t){n.set(t,e)});else{var i,o;if(!fe(t)){if(o=n.set,!he.IsCallable(o))throw new TypeError("bad map")
;i=he.GetIterator(t)}if("undefined"!=typeof i)for(;;){var r=he.IteratorStep(i);if(!1===r)break;var a=r.value;try{if(!he.TypeIsObject(a))throw new TypeError(
"Iterator value "+a+" is not an entry object");w(o,n,a[0],a[1])}catch(s){throw he.IteratorClose(i,!0),s}}}},Vn=function Vn(e,t,n){if(c(n)||ne(n))d(n,function(e
){t.add(e)});else if(n instanceof e)w(e.prototype.forEach,n,function(e){t.add(e)});else{var i,o;if(!fe(n)){if(o=t.add,!he.IsCallable(o))throw new TypeError(
"bad set");i=he.GetIterator(n)}if("undefined"!=typeof i)for(;;){var r=he.IteratorStep(i);if(!1===r)break;var a=r.value;try{w(o,t,a)}catch(s){
throw he.IteratorClose(i,!0),s}}}},qn={Map:function(){var o={},a=function a(e,t){this.key=e,this.value=t,this.next=null,this.prev=null}
;a.prototype.isRemoved=function(){return this.key===o};var n,i=function i(e){return!!e._es6map},s=function s(e,t){if(!he.TypeIsObject(e)||!i(e)
)throw new TypeError("Method Map.prototype."+t+" called on incompatible receiver "+he.ToString(e))},r=function r(e,t){s(e,"[[MapIterator]]"),this.head=e._head,
this.i=this.head,this.kind=t};r.prototype={isMapIterator:!0,next:function(){if(!this.isMapIterator)throw new TypeError("Not a MapIterator");var e,t=this.i,
n=this.kind,i=this.head;if("undefined"==typeof this.i)return ze();for(;t.isRemoved()&&t!==i;)t=t.prev;for(;t.next!==i;)if(!(t=t.next).isRemoved()
)return e="key"===n?t.key:"value"===n?t.value:[t.key,t.value],this.i=t,ze(e);return this.i=void 0,ze()}},Se(r.prototype);var e=function c(){if(!(
this instanceof c))throw new TypeError('Constructor Map requires "new"');if(this&&this._es6map)throw new TypeError("Bad construction");var e=De(this,c,n,{
_es6map:!0,_head:null,_map:H?new H:null,_size:0,_storage:Un()}),t=new a(null,null);return t.next=t.prev=t,e._head=t,0<arguments.length&&Hn(c,e,arguments[0]),e}
;return m(n=e.prototype,"size",function(){if("undefined"==typeof this._size)throw new TypeError("size method called on incompatible Map");return this._size}),_(
n,{get:function(e){var t;s(this,"get");var n=Fn(e,!0);if(null!==n)return(t=this._storage[n])?t.value:void 0;if(this._map)return(t=q.call(this._map,e)
)?t.value:void 0;for(var i=this._head,o=i;(o=o.next)!==i;)if(he.SameValueZero(o.key,e))return o.value},has:function(e){s(this,"has");var t=Fn(e,!0);if(null!==t
)return"undefined"!=typeof this._storage[t];if(this._map)return z.call(this._map,e);for(var n=this._head,i=n;(i=i.next)!==n;)if(he.SameValueZero(i.key,e)
)return!0;return!1},set:function(e,t){s(this,"set");var n,i=this._head,o=i,r=Fn(e,!0);if(null!==r){if("undefined"!=typeof this._storage[r]
)return this._storage[r].value=t,this;n=this._storage[r]=new a(e,t),o=i.prev}else this._map&&(z.call(this._map,e)?q.call(this._map,e).value=t:(n=new a(e,t),
G.call(this._map,e,n),o=i.prev));for(;(o=o.next)!==i;)if(he.SameValueZero(o.key,e))return o.value=t,this;return n=n||new a(e,t),he.SameValue(-0,e)&&(n.key=0),
n.next=this._head,n.prev=this._head.prev,(n.prev.next=n).next.prev=n,this._size+=1,this},"delete":function(e){s(this,"delete");var t=this._head,n=t,i=Fn(e,!0)
;if(null!==i){if("undefined"==typeof this._storage[i])return!1;n=this._storage[i].prev,delete this._storage[i]}else if(this._map){if(!z.call(this._map,e)
)return!1;n=q.call(this._map,e).prev,V.call(this._map,e)}for(;(n=n.next)!==t;)if(he.SameValueZero(n.key,e))return n.key=o,n.value=o,n.prev.next=n.next,
n.next.prev=n.prev,this._size-=1,!0;return!1},clear:function(){s(this,"clear"),this._map=H?new H:null,this._size=0,this._storage=Un();for(var e=this._head,t=e,
n=t.next;(t=n)!==e;)t.key=o,t.value=o,n=t.next,t.next=t.prev=e;e.next=e.prev=e},keys:function(){return s(this,"keys"),new r(this,"key")},values:function(){
return s(this,"values"),new r(this,"value")},entries:function(){return s(this,"entries"),new r(this,"key+value")},forEach:function(e){s(this,"forEach");for(
var t=1<arguments.length?arguments[1]:null,n=this.entries(),i=n.next();!i.done;i=n.next())t?w(e,t,i.value[1],i.value[0],this):e(i.value[1],i.value[0],this)}}),
Se(n,n.entries),e}(),Set:function(){var t,n=function n(e){return e._es6set&&"undefined"!=typeof e._storage},r=function r(e,t){if(!he.TypeIsObject(e)||!n(e)
)throw new TypeError("Set.prototype."+t+" called on incompatible receiver "+he.ToString(e))},e=function o(){if(!(this instanceof o))throw new TypeError(
'Constructor Set requires "new"');if(this&&this._es6set)throw new TypeError("Bad construction");var e=De(this,o,t,{_es6set:!0,"[[SetData]]":null,_storage:Un()})
;if(!e._es6set)throw new TypeError("bad set");return 0<arguments.length&&Vn(o,e,arguments[0]),e},a=function a(e){if(!e["[[SetData]]"]){var t=new qn.Map
;e["[[SetData]]"]=t,d(s(e._storage),function(i){var e=function(e){var t=i;if("^null"===t)return null;if("^undefined"!==t){var n=t.charAt(0);return"$"===n?I(t,1
):"n"===n?+I(t,1):"b"===n?"btrue"===t:+t}}();t.set(e,e)}),e["[[SetData]]"]=t}e._storage=null};m(t=e.prototype,"size",function(){return r(this,"size"),
this._storage?s(this._storage).length:(a(this),this["[[SetData]]"].size)}),_(e.prototype,{has:function(e){var t;return r(this,"has"),this._storage&&null!==(
t=Fn(e))?!!this._storage[t]:(a(this),this["[[SetData]]"].has(e))},add:function(e){var t;return r(this,"add"),this._storage&&null!==(t=Fn(e)
)?this._storage[t]=!0:(a(this),this["[[SetData]]"].set(e,e)),this},"delete":function(e){var t;if(r(this,"delete"),this._storage&&null!==(t=Fn(e))){var n=F(
this._storage,t);return delete this._storage[t]&&n}return a(this),this["[[SetData]]"]["delete"](e)},clear:function(){r(this,"clear"),this._storage&&(
this._storage=Un()),this["[[SetData]]"]&&this["[[SetData]]"].clear()},values:function(){return r(this,"values"),a(this),new i(this["[[SetData]]"].values())},
entries:function(){return r(this,"entries"),a(this),new i(this["[[SetData]]"].entries())},forEach:function(n){r(this,"forEach")
;var i=1<arguments.length?arguments[1]:null,o=this;a(o),this["[[SetData]]"].forEach(function(e,t){i?w(n,i,t,t,o):n(t,t,o)})}}),p(e.prototype,"keys",
e.prototype.values,!0),Se(e.prototype,e.prototype.values);var i=function i(e){this.it=e};return i.prototype={isSetIterator:!0,next:function(){if(
!this.isSetIterator)throw new TypeError("Not a SetIterator");return this.it.next()}},Se(i.prototype),e}()};if(
x.Set&&!Set.prototype["delete"]&&Set.prototype.remove&&Set.prototype.items&&Set.prototype.map&&Array.isArray((new Set).keys)&&(x.Set=qn.Set),x.Map||x.Set){o(
function(){return 2===new Map([[1,2]]).get(1)})||(x.Map=function xi(){if(!(this instanceof xi))throw new TypeError('Constructor Map requires "new"');var e=new H
;return 0<arguments.length&&Hn(xi,e,arguments[0]),delete e.constructor,Object.setPrototypeOf(e,x.Map.prototype),e},x.Map.prototype=C(H.prototype),p(
x.Map.prototype,"constructor",x.Map,!0),y(x.Map,H));var zn=new Map,Gn=((Nn=new Map([[1,0],[2,0],[3,0],[4,0]])).set(-0,Nn),Nn.get(0)===Nn&&Nn.get(-0
)===Nn&&Nn.has(0)&&Nn.has(-0)),Jn=zn.set(1,2)===zn;Gn&&Jn||re(Map.prototype,"set",function(e,t){return w(G,this,0===e?0:e,t),this}),Gn||(_(Map.prototype,{
get:function(e){return w(q,this,0===e?0:e)},has:function(e){return w(z,this,0===e?0:e)}},!0),y(Map.prototype.get,q),y(Map.prototype.has,z));var Wn=new Set,
Qn=Set.prototype["delete"]&&Set.prototype.add&&Set.prototype.has&&((Mn=Wn)["delete"](0),Mn.add(-0),!Mn.has(0)),Zn=Wn.add(1)===Wn;if(!Qn||!Zn){
var Yn=Set.prototype.add;Set.prototype.add=function(e){return w(Yn,this,0===e?0:e),this},y(Set.prototype.add,Yn)}if(!Qn){var Kn=Set.prototype.has
;Set.prototype.has=function(e){return w(Kn,this,0===e?0:e)},y(Set.prototype.has,Kn);var Xn=Set.prototype["delete"];Set.prototype["delete"]=function(e){return w(
Xn,this,0===e?0:e)},y(Set.prototype["delete"],Xn)}var ei=k(x.Map,function(e){var t=new e([]);return t.set(42,42),t instanceof e}),ti=Object.setPrototypeOf&&!ei,
ni=function(){try{return!(x.Map()instanceof x.Map)}catch(e){return e instanceof TypeError}}();0===x.Map.length&&!ti&&ni||(x.Map=function $i(){if(!(
this instanceof $i))throw new TypeError('Constructor Map requires "new"');var e=new H;return 0<arguments.length&&Hn($i,e,arguments[0]),delete e.constructor,
Object.setPrototypeOf(e,$i.prototype),e},x.Map.prototype=H.prototype,p(x.Map.prototype,"constructor",x.Map,!0),y(x.Map,H));var ii=k(x.Set,function(e){
var t=new e([]);return t.add(42,42),t instanceof e}),oi=Object.setPrototypeOf&&!ii,ri=function(){try{return!(x.Set()instanceof x.Set)}catch(e){
return e instanceof TypeError}}();if(0!==x.Set.length||oi||!ri){var ai=x.Set;x.Set=function Oi(){if(!(this instanceof Oi))throw new TypeError(
'Constructor Set requires "new"');var e=new ai;return 0<arguments.length&&Vn(Oi,e,arguments[0]),delete e.constructor,Object.setPrototypeOf(e,Oi.prototype),e},
x.Set.prototype=ai.prototype,p(x.Set.prototype,"constructor",x.Set,!0),y(x.Set,ai)}var si=new x.Map,ci=!o(function(){return si.keys().next().done});if((
"function"!=typeof x.Map.prototype.clear||0!==(new x.Set
).size||0!==si.size||"function"!=typeof x.Map.prototype.keys||"function"!=typeof x.Set.prototype.keys||"function"!=typeof x.Map.prototype.forEach||"function"!=typeof x.Set.prototype.forEach||n(
x.Map)||n(x.Set)||"function"!=typeof si.keys().next||ci||!ei)&&_(x,{Map:qn.Map,Set:qn.Set},!0),x.Set.prototype.keys!==x.Set.prototype.values&&p(x.Set.prototype,
"keys",x.Set.prototype.values,!0),Se(Object.getPrototypeOf((new x.Map).keys())),Se(Object.getPrototypeOf((new x.Set).keys())),
l&&"has"!==x.Set.prototype.has.name){var li=x.Set.prototype.has;re(x.Set.prototype,"has",function(e){return w(li,this,e)})}}_(x,qn),je(x.Map),je(x.Set)}
var di=function di(e){if(!he.TypeIsObject(e))throw new TypeError("target must be an object")},ui={apply:function(){return he.Call(he.Call,null,arguments)},
construct:function(e,t){if(!he.IsConstructor(e))throw new TypeError("First argument must be a constructor.");var n=2<arguments.length?arguments[2]:e;if(
!he.IsConstructor(n))throw new TypeError("new.target must be a constructor.");return he.Construct(e,t,n,"internal")},deleteProperty:function(e,t){if(di(e),a){
var n=Object.getOwnPropertyDescriptor(e,t);if(n&&!n.configurable)return!1}return delete e[t]},has:function(e,t){return di(e),t in e}}
;Object.getOwnPropertyNames&&Object.assign(ui,{ownKeys:function(e){di(e);var t=Object.getOwnPropertyNames(e);return he.IsCallable(Object.getOwnPropertySymbols
)&&D(t,Object.getOwnPropertySymbols(e)),t}});var fi=function(e){return!t(e)};if(Object.preventExtensions&&Object.assign(ui,{isExtensible:function(e){return di(e
),Object.isExtensible(e)},preventExtensions:function(e){return di(e),fi(function(){return Object.preventExtensions(e)})}}),a){var hi=function(e,t,n){
var i=Object.getOwnPropertyDescriptor(e,t);if(i)return"value"in i?i.value:i.get?he.Call(i.get,n):void 0;var o=Object.getPrototypeOf(e);return null!==o?hi(o,t,n
):void 0},pi=function(e,t,n,i){var o=Object.getOwnPropertyDescriptor(e,t);if(!o){var r=Object.getPrototypeOf(e);if(null!==r)return pi(r,t,n,i);o={value:void 0,
writable:!0,enumerable:!0,configurable:!0}}return"value"in o?!!o.writable&&!!he.TypeIsObject(i)&&(Object.getOwnPropertyDescriptor(i,t)?le.defineProperty(i,t,{
value:n}):le.defineProperty(i,t,{value:n,writable:!0,enumerable:!0,configurable:!0})):!!o.set&&(w(o.set,i,n),!0)};Object.assign(ui,{defineProperty:function p(e,
t,n){return di(e),fi(function(){return Object.defineProperty(e,t,n)})},getOwnPropertyDescriptor:function(e,t){return di(e),Object.getOwnPropertyDescriptor(e,t)
},get:function(e,t){di(e);var n=2<arguments.length?arguments[2]:e;return hi(e,t,n)},set:function(e,t,n){di(e);var i=3<arguments.length?arguments[3]:e;return pi(
e,t,n,i)}})}if(Object.getPrototypeOf){var vi=Object.getPrototypeOf;ui.getPrototypeOf=function(e){return di(e),vi(e)}}
Object.setPrototypeOf&&ui.getPrototypeOf&&Object.assign(ui,{setPrototypeOf:function(e,i){if(di(e),null!==i&&!he.TypeIsObject(i))throw new TypeError(
"proto must be an object or null");return i===le.getPrototypeOf(e)||!(le.isExtensible&&!le.isExtensible(e))&&!function(e,t){for(var n=i;n;){if(e===n)return!0
;n=ui.getPrototypeOf(n)}return!1}(e)&&(Object.setPrototypeOf(e,i),!0)}}),Object.keys(ui).forEach(function(e){var t,n;n=ui[t=e],he.IsCallable(x.Reflect[t])?o(
function(){return x.Reflect[t](1),x.Reflect[t](NaN),x.Reflect[t](!0),!0})&&re(x.Reflect,t,n):p(x.Reflect,t,n)});var gi=x.Reflect.getPrototypeOf;if(
l&&gi&&"getPrototypeOf"!==gi.name&&re(x.Reflect,"getPrototypeOf",function(e){return w(gi,x.Reflect,e)}),x.Reflect.setPrototypeOf&&o(function(){
return x.Reflect.setPrototypeOf(1,{}),!0})&&re(x.Reflect,"setPrototypeOf",ui.setPrototypeOf),x.Reflect.defineProperty&&(o(function(){
var e=!x.Reflect.defineProperty(1,"test",{value:1}),t="function"!=typeof Object.preventExtensions||!x.Reflect.defineProperty(Object.preventExtensions({}),"test"
,{});return e&&t})||re(x.Reflect,"defineProperty",ui.defineProperty)),x.Reflect.construct&&(o(function(){var e=function e(){};return x.Reflect.construct(
function(){},[],e)instanceof e})||re(x.Reflect,"construct",ui.construct)),"Invalid Date"!==String(new Date(NaN))){var mi=Date.prototype.toString;re(
Date.prototype,"toString",function(){var e=+this;return e!=e?"Invalid Date":he.Call(mi,this)})}var bi={anchor:function(e){return he.CreateHTML(this,"a","name",e
)},big:function(){return he.CreateHTML(this,"big","","")},blink:function(){return he.CreateHTML(this,"blink","","")},bold:function(){return he.CreateHTML(this,
"b","","")},fixed:function(){return he.CreateHTML(this,"tt","","")},fontcolor:function(e){return he.CreateHTML(this,"font","color",e)},fontsize:function(e){
return he.CreateHTML(this,"font","size",e)},italics:function(){return he.CreateHTML(this,"i","","")},link:function(e){return he.CreateHTML(this,"a","href",e)},
small:function(){return he.CreateHTML(this,"small","","")},strike:function(){return he.CreateHTML(this,"strike","","")},sub:function(){return he.CreateHTML(this
,"sub","","")},sup:function(){return he.CreateHTML(this,"sup","","")}};d(Object.keys(bi),function(e){var t=String.prototype[e],n=!1;if(he.IsCallable(t)){
var i=w(t,"",' " '),o=S([],i.match(/"/g)).length;n=i!==i.toLowerCase()||2<o}else n=!0;n&&re(String.prototype,e,bi[e])});var yi=function(){if(!ae)return!1
;var e="object"==typeof JSON&&"function"==typeof JSON.stringify?JSON.stringify:null;if(!e)return!1;if("undefined"!=typeof e(J()))return!0;if("[null]"!==e([J()])
)return!0;var t={a:J()};return t[J()]=!0,"{}"!==e(t)}(),Ci=o(function(){return!ae||"{}"===JSON.stringify(Object(J()))&&"[{}]"===JSON.stringify([Object(J())])})
;if(yi||!Ci){var wi=JSON.stringify;re(JSON,"stringify",function(e){if("symbol"!=typeof e){var t;1<arguments.length&&(t=arguments[1]);var n=[e];if(c(t))n.push(t
);else{var i=he.IsCallable(t)?t:null;n.push(function(e,t){var n=i?w(i,this,e,t):t;if("symbol"!=typeof n)return oe(n)?St({})(n):n})}
return 2<arguments.length&&n.push(arguments[2]),wi.apply(this,n)}})}return x}),function(e){"use strict";var t,c="[big.js] ",l=c+"Invalid ",C=l+"decimal places",
a=l+"rounding mode",w=c+"Division by zero",i={},_=void 0,r=/^-?(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;function k(e,t,n,i){var o=e.c,r=e.e+t+1;if(r<o.length){if(
1===n)i=5<=o[r];else if(2===n)i=5<o[r]||5==o[r]&&(i||r<0||o[r+1]!==_||1&o[r-1]);else if(3===n)i=i||o[r]!==_||r<0;else if(i=!1,0!==n)throw Error(a);if(r<1
)o.length=1,o[0]=i?(e.e=-t,1):e.e=0;else{if(o.length=r--,i)for(;9<++o[r];)o[r]=0,r--||(++e.e,o.unshift(1));for(r=o.length;!o[--r];)o.pop()}}else if(
n<0||3<n||n!==~~n)throw Error(a);return e}function n(e,t,n,i){var o,r,a=e.constructor,s=!e.c[0];if(n!==_){if(n!==~~n||n<(3==t)||1e6<n)throw Error(
3==t?l+"precision":C);for(n=i-(e=new a(e)).e,e.c.length>++i&&k(e,n,a.RM),2==t&&(i=e.e+n+1);e.c.length<i;)e.c.push(0)}if(o=e.e,n=(r=e.c.join("")).length,2!=t&&(
1==t||3==t&&i<=o||o<=a.NE||o>=a.PE))r=r.charAt(0)+(1<n?"."+r.slice(1):"")+(o<0?"e":"e+")+o;else if(o<0){for(;++o;)r="0"+r;r="0."+r}else if(0<o)if(++o>n)for(
o-=n;o--;)r+="0";else o<n&&(r=r.slice(0,o)+"."+r.slice(o));else 1<n&&(r=r.charAt(0)+"."+r.slice(1));return e.s<0&&(!s||4==t)?"-"+r:r}i.abs=function(){
var e=new this.constructor(this);return e.s=1,e},i.cmp=function(e){var t,n=this.c,i=(e=new this.constructor(e)).c,o=this.s,r=e.s,a=this.e,s=e.e;if(!n[0]||!i[0]
)return n[0]?o:i[0]?-r:0;if(o!=r)return o;if(t=o<0,a!=s)return s<a^t?1:-1;for(r=(a=n.length)<(s=i.length)?a:s,o=-1;++o<r;)if(n[o]!=i[o])return n[o]>i[o]^t?1:-1
;return a==s?0:s<a^t?1:-1},i.div=function(e){var t=this.constructor,n=this.c,i=(e=new t(e)).c,o=this.s==e.s?1:-1,r=t.DP;if(r!==~~r||r<0||1e6<r)throw Error(C)
;if(!i[0])throw Error(w);if(!n[0])return new t(0*o);var a,s,c,l,d,u=i.slice(),f=a=i.length,h=n.length,p=n.slice(0,a),v=p.length,g=e,m=g.c=[],b=0,y=r+(
g.e=this.e-e.e)+1;for(g.s=o,o=y<0?0:y,u.unshift(0);v++<a;)p.push(0);do{for(c=0;c<10;c++){if(a!=(v=p.length))l=v<a?1:-1;else for(d=-1,l=0;++d<a;)if(i[d]!=p[d]){
l=i[d]>p[d]?1:-1;break}if(!(l<0))break;for(s=v==a?i:u;v;){if(p[--v]<s[v]){for(d=v;d&&!p[--d];)p[d]=9;--p[d],p[v]+=10}p[v]-=s[v]}for(;!p[0];)p.shift()}
m[b++]=l?c:++c,p[0]&&l?p[v]=n[f]||0:p=[n[f]]}while((f++<h||p[0]!==_)&&o--);return m[0]||1==b||(m.shift(),g.e--),y<b&&k(g,r,t.RM,p[0]!==_),g},i.eq=function(e){
return!this.cmp(e)},i.gt=function(e){return 0<this.cmp(e)},i.gte=function(e){return-1<this.cmp(e)},i.lt=function(e){return this.cmp(e)<0},i.lte=function(e){
return this.cmp(e)<1},i.minus=i.sub=function(e){var t,n,i,o,r=this,a=r.constructor,s=r.s,c=(e=new a(e)).s;if(s!=c)return e.s=-c,r.plus(e);var l=r.c.slice(),
d=r.e,u=e.c,f=e.e;if(!l[0]||!u[0])return u[0]?(e.s=-c,e):new a(l[0]?r:0);if(s=d-f){for((i=(o=s<0)?(s=-s,l):(f=d,u)).reverse(),c=s;c--;)i.push(0);i.reverse()
}else for(n=((o=l.length<u.length)?l:u).length,s=c=0;c<n;c++)if(l[c]!=u[c]){o=l[c]<u[c];break}if(o&&(i=l,l=u,u=i,e.s=-e.s),0<(c=(n=u.length)-(t=l.length)))for(
;c--;)l[t++]=0;for(c=t;s<n;){if(l[--n]<u[n]){for(t=n;t&&!l[--t];)l[t]=9;--l[t],l[n]+=10}l[n]-=u[n]}for(;0===l[--c];)l.pop();for(;0===l[0];)l.shift(),--f
;return l[0]||(e.s=1,l=[f=0]),e.c=l,e.e=f,e},i.mod=function(e){var t,n=this,i=n.constructor,o=n.s,r=(e=new i(e)).s;if(!e.c[0])throw Error(w);return n.s=e.s=1,
t=1==e.cmp(n),n.s=o,e.s=r,t?new i(n):(o=i.DP,r=i.RM,i.DP=i.RM=0,n=n.div(e),i.DP=o,i.RM=r,this.minus(n.times(e)))},i.plus=i.add=function(e){var t,n=this,
i=n.constructor,o=n.s,r=(e=new i(e)).s;if(o!=r)return e.s=-r,n.minus(e);var a=n.e,s=n.c,c=e.e,l=e.c;if(!s[0]||!l[0])return l[0]?e:new i(s[0]?n:0*o);if(
s=s.slice(),o=a-c){for((t=0<o?(c=a,l):(o=-o,s)).reverse();o--;)t.push(0);t.reverse()}for(s.length-l.length<0&&(t=l,l=s,s=t),o=l.length,r=0;o;s[o]%=10)r=(
s[--o]=s[o]+l[o]+r)/10|0;for(r&&(s.unshift(r),++c),o=s.length;0===s[--o];)s.pop();return e.c=s,e.e=c,e},i.pow=function(e){var t=this,n=new t.constructor(1),i=n,
o=e<0;if(e!==~~e||e<-1e6||1e6<e)throw Error(l+"exponent");for(o&&(e=-e);1&e&&(i=i.times(t)),e>>=1;)t=t.times(t);return o?n.div(i):i},i.round=function(e,t){
var n=this.constructor;if(e===_)e=0;else if(e!==~~e||e<0||1e6<e)throw Error(C);return k(new n(this),e,t===_?n.RM:t)},i.sqrt=function(){var e,t,n,i=this,
o=i.constructor,r=i.s,a=i.e,s=new o(.5);if(!i.c[0])return new o(i);if(r<0)throw Error(c+"No square root");for(0===(r=Math.sqrt(i.toString()))||r===1/0?((
t=i.c.join("")).length+a&1||(t+="0"),(e=new o(Math.sqrt(t).toString())).e=((a+1)/2|0)-(a<0||1&a)):e=new o(r.toString()),a=e.e+(o.DP+=4);n=e,e=s.times(n.plus(
i.div(n))),n.c.slice(0,a).join("")!==e.c.slice(0,a).join(""););return k(e,o.DP-=4,o.RM)},i.times=i.mul=function(e){var t,n=this.constructor,i=this.c,o=(e=new n(
e)).c,r=i.length,a=o.length,s=this.e,c=e.e;if(e.s=this.s==e.s?1:-1,!i[0]||!o[0])return new n(0*e.s);for(e.e=s+c,r<a&&(t=i,i=o,o=t,c=r,r=a,a=c),t=new Array(c=r+a
);c--;)t[c]=0;for(s=a;s--;){for(a=0,c=r+s;s<c;)a=t[c]+o[s]*i[c-s-1]+a,t[c--]=a%10,a=a/10|0;t[c]=(t[c]+a)%10}for(a?++e.e:t.shift(),s=t.length;!t[--s];)t.pop()
;return e.c=t,e},i.toExponential=function(e){return n(this,1,e,e)},i.toFixed=function(e){return n(this,2,e,this.e+e)},i.toPrecision=function(e){return n(this,3,
e,e-1)},i.toString=function(){return n(this)},i.valueOf=i.toJSON=function(){return n(this,4)},(t=function o(){function n(e){var t=this;if(!(t instanceof n)
)return e===_?o():new n(e);e instanceof n?(t.s=e.s,t.e=e.e,t.c=e.c.slice()):function(e,t){var n,i,o;if(0===t&&1/t<0)t="-0";else if(!r.test(t+=""))throw Error(
l+"number");for(e.s="-"==t.charAt(0)?(t=t.slice(1),-1):1,-1<(n=t.indexOf("."))&&(t=t.replace(".","")),0<(i=t.search(/e/i))?(n<0&&(n=i),n+=+t.slice(i+1),
t=t.substring(0,i)):n<0&&(n=t.length),o=t.length,i=0;i<o&&"0"==t.charAt(i);)++i;if(i==o)e.c=[e.e=0];else{for(;0<o&&"0"==t.charAt(--o););for(e.e=n-i-1,e.c=[],
n=0;i<=o;)e.c[n++]=+t.charAt(i++)}}(t,e),t.constructor=n}return n.prototype=i,n.DP=20,n.RM=1,n.NE=-7,n.PE=21,n.version="5.0.2",n}())["default"]=t.Big=t,
"function"==typeof define&&define.amd?define(function(){return t}):"undefined"!=typeof module&&module.exports?module.exports=t:e.Big=t}(this),!VDF_JSVersion
)var VDF_JSVersion={};function VF_checkCookie(){var e=!!navigator.cookieEnabled;return"undefined"!=typeof navigator.cookieEnabled||e||(
document.cookie="testcookie",e=-1!=document.cookie.indexOf("testcookie")),!!e||VF_showCookieFail()}function VF_showCookieFail(){
document.location.href="http://www.vodafone.co.uk/cookiesdisabled/index.htm"}function VF_parseURL(e){"use strict";var r=document.createElement("a")
;return r.href=e||document.location.href,{source:e,protocol:r.protocol.replace(":",""),host:r.hostname,port:r.port,query:r.search,params:function(){var e,t={},
n=r.search.replace(/^\?/,"").split("&"),i=n.length,o=0;for(o=0;o<i;o++)n[o]&&(t[(e=n[o].split("="))[0]]=e[1]);return t}(),file:(r.pathname.match(
/\/([^\/?#]+)$/i)||[0,""])[1],hash:r.hash.replace("#",""),path:r.pathname.replace(/^([^\/])/,"/$1"),relative:(r.href.match(/tps?:\/\/[^\/]+(.+)/)||[0,""])[1],
segments:r.pathname.replace(/^\//,"").split("/")}}VDF_JSVersion.common={version:"3.10.1"},function(T){T.fn.vfCardExpiry=function(){var a;if(T(this).is("table")
)var e=(a=T(this).find("tr")).find("td:eq(1)"),t=T("#expired").val(),s=(T("#expires_soon").val()," <span>"+t+"</span>");else e=(a=T(this).find("li")).find(
".expiry"),s=" <span>"+(t="Expired")+"</span>";e.each(function(e){var t=T(this).text().replace(/\//,"/01/20"),n=new Date,i=n.getMonth()+1+"",o=n.getFullYear(
)+"",r=new Date(t).getTime();1===i.length&&(i="0"+i),r<new Date(i+"/01/"+o).getTime()&&(T(this).parent().addClass("expired-card"),T(this).addClass("expired"
).append(s)),a.hasClass("expired-card")&&T(".expired-card").find("input").prop("disabled",!0).prop("checked",!1)})},T.fn.togglePackageDetails=function(){
var e=T(this),n="openContainer";function i(){e.find("."+n+":first .contentInfo").slideUp("fast"),e.find("."+n+":first").removeClass(n)}e.find(".moreLessLink a"
).unbind().bind("click",function(e){e.preventDefault();var t=T(this);t.hasClass("moreInfo")?(i(),t.closest(".contentInfoContainer").addClass(n),t.closest(
".contentInfoContainer").find(".contentInfo").slideDown("fast")):t.hasClass("lessInfo")&&i()}),e.find(".contentTitle").click(function(){i()}),e.find(
".contentDetails").each(function(){var e=T(this),t="",n=e.find(".contentPrice:first"),i=n.text();if(0<n.length&&0<i.length){i.indexOf("£")<0&&(t="&pound;")
;var o='<span class="contentCost">'+t+i+"</span>";0==e.find("label:first .contentCost").length&&e.find("label:first").prepend(o)}})},T.fn.moreDetails=function(
){var e=T(this),t=e.closest(".moreDetailsContainer").find(".moreDetailsOuter .close");e.click(function(e){e.preventDefault(),T(this).closest(
".moreDetailsContainer").find(".moreDetailsOuter").show()}),t.click(function(e){e.preventDefault(),T(this).closest(".moreDetailsOuter").hide()})},
T.fn.vfNoThanks=function(){return T.each(this,function(){T(this).find(".declineOffer").on("click",function(e){e.preventDefault(),T(this).closest(
".individualOfferWrapper").hide()})})},T.fn.vfHideParentContainer=function(){return T.each(this,function(){T(this).click(function(e){T(this).parent().slideUp(),
e.preventDefault()})})},T.fn.vfAutoProceed=function(){var e="";0<(e=T("input.singleDigit,input.pinSingleDigit")).length&&e.vfAutoProceedInput({length:1}),0<(
e=T("input.fourDigit")).length&&e.vfAutoProceedInput({length:5}),0<(e=T("input.doubleDigits")).length&&e.vfAutoProceedInput({length:2}),e=null},
T.fn.vfAutoProceedInput=function(e){var i=T.extend({length:1,exact:!0},e);return this.data("vfAutoProceedInput",i),T.each(this,function(e,t){var o=T(this),
n=o.attr("maxlength");typeof n!=typeof undefined&&!1!==n||o.attr("maxlength",i.length),n=null,o.on("keydown",function(e){var t=o.val().length,
n=e.keyCode||e.which;t==i.length&&i.exact&&(48<=n&&n<=57||96<=n&&n<=105||65<=n&&n<=90||186==n)?o.val(""):8==n&&0==t&&i.exact&&o.parent().find("input").not(
"[disabled]").each(function(){T(this).val("")}).first().focus()}),o.on("keyup",function(e){var t=e.keyCode||e.which,n=o.data("vfAutoProceedInput"),i=o.val()
;i.length==n.length&&n.exact&&9!=t&&16!=t&&(40<t||t<37)?o.nextAll("input").first().focus():i.length>n.length&&!n.exact&&o.nextAll("input").first().focus()})})},
T.fn.vfContainerSlider=function(e){var t=T.extend({openLinkClazz:"openLink",closeLinkClazz:"closeLink",headerClazz:"slideContainerHeader",
contentClazz:"slideContainerContent"},e);return this.data("vfContainerSlider",t),T.each(this,function(){var e=T(this),t=e.data("vfContainerSlider");e.find(
"."+t.openLinkClazz).data("vfContainerSlider",t),e.siblings("."+t.contentClazz).find("."+t.closeLinkClazz).data("vfContainerSlider",t),e.find(
"."+t.openLinkClazz).click(function(e){var t=T(this).data("vfContainerSlider");T("."+t.contentClazz).slideUp(),T(this).closest("."+t.headerClazz).next(
"."+t.contentClazz).slideDown(),e.preventDefault()}),e.siblings("."+t.contentClazz).find("."+t.closeLinkClazz).click(function(e){var t=T(this).data(
"vfContainerSlider");T(this).closest("."+t.contentClazz).slideUp(),e.preventDefault()})})},T.fn.changeUsername=function(){T(".changeUsernameBtn").click(
function(e){e.preventDefault(),T(this).addClass("hidden"),T(".newUsernameContainer").slideDown("fast",function(){T(this).removeClass("hidden")})}),T(
".newUsernameContainer a.cancel").click(function(e){e.preventDefault(),T(".newUsernameContainer").slideUp("fast",function(){T(this).addClass("hidden"),T(
".changeUsernameBtn").removeClass("hidden"),T(".emailToUsernameSwitch").prop("checked",!1).change(),T.fn.clearformFieldMSG(T(".newUsernameContainer"))})}),T(
".newUsernameContainer input.setEmailToUsername").on("input",function(){T.fn.clearformFieldMSG(T(".newUsernameContainer"))})},T.fn.useEmailAsUsername=function(
){var e=T(".emailToUsernameSwitch"),t=T(".setEmailToUsername"),n=T(".checkAvailabilityBtn");e.change(function(){t.val("").prop("disabled",T(this).is(":checked")
),T(this).is(":checked")?n.addClass("hidden"):n.removeClass("hidden"),T.fn.clearformFieldMSG(T(".newUsernameContainer"))})},T.fn.clearformFieldMSG=function(e){
var t=e.children(".formFieldMSG:first"),n=e.children(".formRow:first");0<t.length&&(t.remove(),n.removeClass("success").removeClass("error"))},
T.fn.transactionAllowedCheck=function(){var e=T(".portlet_top17"),t=e.find(".bank_check_radios"),n=t.find(".formRow.radio"),i=e.find(".bank_details"),o=e.find(
".transaction_not_allowed");t.find("input:radio").change(function(){T(".allowed:checked").length==n.length?i.hasClass("active")||o.removeClass("active"
).slideUp(250,function(){i.addClass("active").slideDown(250)}):o.hasClass("active")||i.removeClass("active").slideUp(250,function(){o.addClass("active"
).slideDown(250)})})},T.fn.togglePackServiceDetails=function(){var e=T(this),n="openContainer";function i(){e.find("."+n+":first .serviceInfo").slideUp("fast"),
e.find("."+n+":first").removeClass(n)}e.find(".moreLessLink").unbind().bind("click",function(e){e.preventDefault();var t=T(this);t.hasClass("moreInfo")?(i(),
t.closest(".serviceInfoContainer").addClass(n),t.closest(".serviceInfoContainer").find(".serviceInfo").slideDown("fast")):t.hasClass("lessInfo")&&i()}),e.find(
".serviceTitle").click(function(){i()}),e.find(".serviceDetails").each(function(){var e=T(this),t="",n=e.find(".servicePrice:first").text();n.indexOf("£")<0&&(
t="&pound;");var i='<span class="serviceCost">'+t+n+"</span>";0==e.find("label:first .serviceCost").length&&e.find("label:first").prepend(i)}),e.find(
".serviceInfo").each(function(){T(this).find("p:even").addClass("even")})},T.fn.sortCodeFormat=function(){var e=T(
".portlet_manageBillingProfile .currentMethodTable .lastRow .important"),t=e.text();if(T.isNumeric(t)&&6<=t.length){var n=t.substring(0,2),i=t.substring(2,4),
o=t.substring(4);out=n+"-"+i+"-"+o,T(e).text(out)}return!1},T.fn.singleAccordion=function(){var n=T(this),e=n.find(".accordionAnchor"),i=n.find(
".accordionContent"),o="js_open",r="js_close";e.click(function(e){e.preventDefault();var t=T(this);t.hasClass(r)?i.slideUp(230,function(){t.removeClass(r
).addClass(o),n.removeClass(o).addClass(r)}):t.hasClass(o)&&i.slideDown(230,function(){t.removeClass(o).addClass(r),n.removeClass(r).addClass(o)})})},
T.fn.myOffersSetup=function(){T(".portlet_myOffers .individualOfferWrapper .offerContainer").each(function(){var e=T(this),t=e.find(".individualOffer");e.is(
".offerTV, .offerOffers, .offerBroadband, .offerTablet, .offerDongle, .offerSim, .offerHandset, .offerUpgrade, .offerApp, .offerExtra, .offerBusinessBroadband, .offerBusinessTablets, .offerBusinessSimOnly"
)&&0==e.find(".offerIcon").length&&t.prepend('<div class="offerIcon"></div>')})},T.fn.vfMemorableWordHint=function(){var e=T(this),i="jsMemWord";e.each(
function(){var e=T(this);if(!e.hasClass("js")){e.addClass("js"),e.wrap('<div class="'+i+'"></div>');var t=T(
'<a href="#" class="memWordHintLink showHint">Need a hint?</a>'),n=T('<a href="#" class="memWordHintLink hideHint">Hide your hint</a>');e.before(t),e.before(
n.hide()),e.hide()}}),T(".memWordHintLink").on("click",function(e){e.preventDefault();var t=T(this),n=t.closest("."+i);t.hasClass("showHint")?(n.find(
".memWordHint").slideDown(200),n.find(".memWordHintLink.hideHint").show()):(n.find(".memWordHint").slideUp(200),n.find(".memWordHintLink.showHint").show()),
t.hide()})},T.fn.paymentMethodSelection=function(){var e=T(".portlet_payment_subflow_v4"),t=e.find(".new-card-info"),n=e.find(".saved-card-info"),i=e.find(
"label.contentTitle");T(i).each(function(){if(0==T(this).parents(".card_expired").length)return 0<T(this).parents(".new-card").length?t.css("display","block"
):n.css("display","block"),T(this).click(),!1}),T(i).on("click",function(){0==T(this).parents(".card_expired").length&&(0<T(this).parents(".new-card").length?(
n.css("display","none"),t.css("display","block")):(t.css("display","none"),n.css("display","block")))})},T.fn.vfRadioToggles=function(r){function a(e,t,n){
var i=t?"left ":"right ";i+=n?"bottom":"top",!0===n?(T(e).css({"background-position":i,"pointer-events":"none"}),T(e).closest(".modal--enjoymore").css(
"pointer-events","none"),T(e).parents().hasClass("in-progress")&&T(e).parents(".product").children(".dates").children(".endDate").remove()):T(e).css({
"background-position":i})}function n(e,t){var n={used:!1,immediate:!(t===undefined||t.immediate===undefined||!0!==t.immediate),isOn:!T(e[1]).prop("checked")},
i=e[0].attr("name");if("undefined"!=typeof e){T(document).data(i)||T(document).data(i,n),T.each(e,function(e,t){T(t).addClass("hiddenRadio"),T('label[for="'+T(t
).attr("id")+'"]').hide()});var o=T('<div class="here_'+T(e[0]).attr("id")+'" tabindex="0"></div>').insertAfter(e[0]);o.addClass("radioToggle"),o.data("dataKey"
,i),n.used&&!n.immediate||t!==undefined&&t.disableClickEvent,T(e[0]).parents().hasClass("in-progress")?a(o,n.isOn,!0):a(o,n.isOn,!1),
"undefined"!=typeof t&&"undefined"!=typeof t.disableClickEvent&&0!=t.disableClickEvent||!(0==n.used||n.used&&n.immediate)||function(o){var t=T(document).data(
o.data("dataKey"));function n(e){var t=T(e).closest(".toggleContainer").find('input[value="0"]'),n=T(e).closest(".toggleContainer").find('input[value="1"]'),
i=T(document).data(o.data("dataKey"));t.prop("checked",!0),n.prop("checked",!1),i.isOn=!0,i.used=!0,i.used&&!i.immediate||r!==undefined&&r.disableClickEvent,T(e
).parents().hasClass("in-progress")?a(o,i.isOn,!0):a(o,i.isOn,!1),t.fireEvent?t.fireEvent("onclick"):t.click()}function i(e){var t=T(e).closest(
".toggleContainer").find('input[value="0"]'),n=T(e).closest(".toggleContainer").find('input[value="1"]'),i=T(document).data(o.data("dataKey"));t.prop("checked",
!1),n.prop("checked",!0),i.isOn=!1,i.used=!0,i.used&&!i.immediate||r!==undefined&&r.disableClickEvent,T(e).parents().hasClass("in-progress")?a(o,i.isOn,!0):a(o,
i.isOn,!1),n.fireEvent?n.fireEvent("onclick"):n.click()}T(o).on("click",function(e){t.isOn&&!t.used?i(o):n(o),T(o).off("click")}),T(o).on("keydown",function(e){
9!=e.keyCode&&e.preventDefault(),37==e.keyCode&&t.isOn&&!t.used?i(o):39!=e.keyCode||t.isOn||t.used||n(o)})}(o)}}0!=T(this).length&&(T(this).is("div")?(T.each(T(
this),function(e,t){n([T(t).find('input:radio[value="0"]'),T(t).find('input:radio[value="1"]')],r)}),T(this).addClass("js")):n(T(this),r))},
T.fn.vfToggleEmailUsername=function(){T(this).each(function(){var e=T(this).find("input:radio"),t=e[0],n=e[1],i=T(this).parent().next("span").children();i.hide(
),e.eq(1).next("label").removeClass("checked"),e.eq(1).prop("checked",!1),e.eq(0).next("label").addClass("checked"),e.eq(0).prop("checked",!0),T(t).on("click",
function(e){i.slideUp(200)}),T(n).on("click",function(e){i.slideDown(200)})})},T.fn.vfClickRegistration=function(){T("label").filter(".checked").prev("span"
).find("[type=radio]").click()},T.fn.vfShowAndHidePaymentDetails=function(e){var t=T.extend({secCodeContClass:"secCodeContainer",
newCardDetailsContClass:"newCardContainer",newCardContClass:"newCardListContainer",savedCardListClass:"savedCardsList"},e),n=T("."+t.secCodeContClass);n.hide()
;var i=T("div."+t.newCardDetailsContClass);i.hide();var o=T(".use-new-card");T("."+t.savedCardListClass+" li input:radio").on("click",function(){n.slideUp(200),
i.slideUp(200),T(this).closest("li").hasClass(t.newCardContClass)?T(this).closest(".formContainer").find("."+t.newCardDetailsContClass).slideDown(200):(T(this
).closest(".radioContainer").next("."+t.secCodeContClass).slideDown(200),T(".newCardListContainer input:radio").is(":checked")?o.slideDown(200):o.slideUp(200))}
)},T.fn.vfMoveDate=function(){T(document).on("change",".movedate_select select",function(){T(".movedate_value").text(T(this).val())}),T(".movedate_value").text(
T(".movedate_select select").val())},T.fn.jsExtendContainerDropdown=function(){var r,a,t=T(this),e=t.find(".jsListTrigger"),n=e.find(".selected"),s=T(
".subscriptionContainer.multi.jsExtendContainer"),i=s.find("ul li"),c=s.find(".subscriptionList"),l=s.find(".subscriptionSearch"),o=s.find(".errorMSG"),
d=s.find(".scrollDown"),u=s.find(".scrollUp"),f=parseInt(s.find(T("input[class*='ContainerConfigValue']")).attr("value")),h=i.size(),p=h-f,v="expanded",g=0,m={
"background-color":"#3d3d3d",cursor:"default","pointer-events":"none"},b={"background-color":"#6e6e6e","pointer-events":"auto",cursor:"pointer"};n.prependTo(e),
n.unbind().on("click",function(e){C(),o.parent().hide(),s.hasClass(v)?y():(e.preventDefault(),f+4<h?(l.parent().show(),d.parent().show(),c.css("height",104+38*f
)):(l.parent().hide(),d.parent().hide(),c.css("height","auto")),t.toggleClass(v),l.focus())}),d.unbind().on("click",function(){if(null==l.val()||""==l.val()){
if(listSize=h,a<p){for(var e=0;e<f;e++)s.find("ul li:eq("+a+++")").slideUp(100);u.css(b)}p<=a&&d.css(m),p<a&&a!=p&&c.css("height","auto")}else{if(g<r-f)for(
var t=0,n=4;n<h;n++){var i=s.find("ul li:eq("+n+")"),o=l.val().toLowerCase().replace(/\s/g,"");if("block"==i.css("display")&&-1<i.text().toLowerCase().replace(
/\s/g,"").indexOf(o)&&(i.slideUp(100),g++,t++,u.css(b),f<=t))break}r-f<=g&&d.css(m),r-f<g&&g!=r-f&&c.css("height","auto")}}),u.unbind().on("click",function(){
if(null==l.val()||""==l.val()){if(4<a){c.css("height",104+38*f);for(var e=0;e<f;e++)a--,s.find("ul li:eq("+a+")").slideDown(100);d.css(b)}4===a&&u.css(m)}else{
var t=0;c.css("height",104+38*f);for(var n=h;4<=n;n--){var i=s.find("ul li:eq("+n+")"),o=l.val().toLowerCase().replace(/\s/g,"");if("none"==i.css("display"
)&&-1<i.text().toLowerCase().replace(/\s/g,"").indexOf(o)&&(i.slideDown(100),t++,g--,d.css(b),f<=t))break}g<=0&&u.css(m)}}),l.keyup(function(e){C();var t=T(this
).val().toLowerCase().replace(/\s/g,"");r=0,i.each(function(){var e=T(this);!e.hasClass("selected")&&e.find(".subscriptionSearch").length<=0&&e.find(
".scrollControl").length<=0&&(-1<e.find(".subscription").text().toLowerCase().replace(/\s/g,"").indexOf(t)?(e.show(),r++):e.hide())}),4===a&&u.css(m),r<=f?(
0===r&&o.parent().show(),d.parent().hide(),c.css("height","auto")):(o.parent().hide(),d.parent().show(),c.css("height",104+38*f))}),T("html").click(function(e){
T(e.target).parents(".jsListTrigger").length||y()});var y=function(){l.val(""),s.hasClass("multi")&&(i.each(function(){T(this).show()}),c.css("height",41)),
t.removeClass(v),l.parent().hide(),o.parent().hide()},C=function(){u.css(m),d.css(b),a=4,g=0}},T.fn.savedCardsLabels=function(){T(this).find(".formRow").each(
function(){var e=T(this),t=e.find(".card_details");e.find("label").append(t.html()),t.remove()})},T.fn.infoBox=function(){var t=T(this),e=t.find(".info_link"),
n=t.find(".info_content"),i="close";e.on("click",function(e){e.preventDefault(),t.hasClass(i)?(n.slideDown(250),t.removeClass(i)):(n.slideUp(250),t.addClass(i))
})},T.fn.cancelOptions=function(){var t=T(this),e=t.find(".trigger"),n=t.find(".close");e.click(function(e){e.preventDefault(),t.addClass("open")}),n.unbind(
).click(function(e){e.preventDefault(),t.removeClass("open")})},T.fn.dateTimeConverter=function(){var e=T(this),t=e.find(".js-date-convert-values"),n=e.find(
".js-date-convert"),v="font-red",g=t.find(".current-datetime").text(),m=t.find(".ends").text(),b=t.find(".renews").text(),y=t.find(".in").text(),C=t.find(".on"
).text(),w=parseInt(t.find(".threshold").text()),_=t.find(".days_singular").text(),k=t.find(".days_plural").text(),x=t.find(".hours_singular").text(),$=t.find(
".hours_plural").text(),O=t.find(".mins_singular").text(),j=t.find(".mins_plural").text(),S=t.find(".less-than-min").text(),I=["Jan","Feb","Mar","Apr","May",
"Jun","Jul","Aug","Sep","Oct","Nov","Dec"];n.each(function(){var e=T(this),t=e.text(),n=m;e.hasClass("renewal-date")&&(n=b);var i=n;function o(e,t){if(isNaN(e
)&&t){var n=t.replace(/-/g,"/");n=n.replace("T"," "),e=new Date(n)}return e}var r=new Date(g);r=(r=o(r,g)).getTime();var a=(l=o(l=new Date(t),t)).getDate(),
s=l.getMonth(),c=l.getFullYear(),l=l.getTime(),d=Math.round((l-r)/1e3),u=86400*w;if(u<=d)i+=" "+C+" "+a+" "+I[s]+" "+c;else if(d<=u&&u/w<d){i+=" "+y
;var f=Math.floor(d/86400),h=Math.floor(24*(d/86400-f));1==f?i+=" "+f+" "+_:1<f&&(i+=" "+f+" "+k),1==h?i+=" "+h+" "+x:1<h&&(i+=" "+h+" "+$)}else if(d<=u/w&&59<d
){e.addClass(v),i+=" "+y,h=Math.floor(d/3600);var p=Math.floor(60*(d/3600-h));1==h?i+=" "+h+" "+x:1<h&&(i+=" "+h+" "+$),1==p?i+=" "+p+" "+O:1<p&&(i+=" "+p+" "+j
)}else e.addClass(v),i+=" "+y+" "+S;e.text(i).css("visibility","visible")})},T.fn.vfReadMore=function(e){var t=T.extend({singular:!0,contentClass:""},e);if(
""!=t.contentClass)return this.data("vfReadMore",t),T.each(this,function(){var t=T(this).data("vfReadMore"),e=T(this).find("ul.link-list li a.read-more"),n=T(
".moreDetails a.close");t.singular&&e.on("click",function(e){T(".moreDetailsOuter:visible").hide()}),e.on("click",function(e){e.preventDefault(),T(this
).closest("."+t.contentClass).next().show()}),n.on("click",function(e){e.preventDefault(),T(this).parent().parent().hide()})});T.error(
"You must provide a content class for plugin 'vfReadMore' - nothing todo")}}(jQuery),$(document).ready(function(){var t;$("input:checkbox").each(function(){$(
this).vfCheckboxes()}),$("input:radio").each(function(){$(this).vfRadios()}),$(".alt_shades").each(function(){$(this).find("li:odd").addClass("even")}),$(
"[autocomplete=off]").prop("autocomplete","off"),$("label a").click(function(e){e.stopPropagation()}),$(".js-remove-global").each(function(){$(this).remove()}),
$(".manualAddress a").click(function(e){$(".addressInputs").slideDown(),e.preventDefault()}),$(".ukDrivingLicence").click(function(e){$(".ppDetails").slideUp(),
$(".cardDetails").slideUp(),$(".dlDetails").slideDown()}),$(".passport").click(function(e){$(".dlDetails").slideUp(),$(".cardDetails").slideUp(),$(".ppDetails"
).slideDown()}),$(".paymentCard").click(function(e){$(".dlDetails").slideUp(),$(".ppDetails").slideUp(),$(".cardDetails").slideDown()}),$(".noCCP").bind(
"cut copy paste",function(e){e.preventDefault()}),$(".portlet_viewPricePlan .hero").each(function(){var e=$(this).find("p").text()
;/You'll be able to upgrade on this number from $/.test(e)&&$(this).hide()}),$(".productGroup").each(function(){if("Vodafone Family"===$(this).find("h3").text(
).trim()){var e=$(this).find("button");$(e).each(function(){$(this).hide()})}}),$.fn.reveal=function(e,t){e=e===undefined?"button":e;var n=$(this),i=(
t=t===undefined?n.attr("class").split(/\s+/):t,null),o=/^(?:js\-data\-reveal\_)([a-z0-9\-\_]+)$/;for(var r in t)if(t.hasOwnProperty(r)){var a=t[r].match(o)
;null!=a&&""!=a[1]&&(i=$("."+a[1]))}if(!i||0==i.length)return!1;switch(e){case"button":var s=n.find(".more"),c=n.find(".less");0<s.length&&0<c.length&&(
0<i.filter(":visible").length?c.show():s.show(),i=i.add(s).add(c)),n.unbind().on("click",function(e){e.preventDefault(),i.toggle()});break;case"select-last":
var l=n.find("select");l.length||(l=n);var d=l.find("option:last");(h=function(){0<d.filter(":selected").length?i.removeClass("hide"):i.addClass("hide")})(),
l.unbind("change",h).on("change",h);break;case"radio":var u=$("input[name="+n.attr("name")+"]").closest(".formRow").find("input"),f=n.closest(".formRow").find(
"input");f.prop("checked")&&i.removeClass("hide");var h=function(){f.prop("checked")?i.removeClass("hide"):i.addClass("hide")};u.unbind("change",h).on("change",
h)}},$.fn.populateLabelContent=function(){var e=$(this),t=e.find(".label-content"),n=t.html();e.find("label").prepend(n),t.remove()},
$.fn.selectAllCheckboxes=function(){var e=$(this),t=e.find('[type="checkbox"]'),n=e.find("label"),i=e.find(".js-list-selector-switch input"),o=e.find(
".js-list-selector-switch label");t=t.not(i),n=n.not(o),o.on("click",function(){o.hasClass("checked")&&(n.not(".checked").addClass("checked"),t.prop("checked",
!0))}),n.on("click",function(){!$(this).prop("checked")&&o.hasClass("checked")&&(o.removeClass("checked"),i.prop("checked",!1))})},
$.fn.countdownStyling=function(){$(this).each(function(){for(var e=$(this),t=e.text(),n=0;n<t.length&&n<3;)e.before('<span class="countdown-digit">'+t.charAt(n
)+"</span>"),n++;e.remove()})},$.fn.addressAdvancedOptions=function(){var e=$(".portlet_addressManagement .advancedOptions"),t=e.find(".currentAddress"),
n=e.find(".futureAddress");e.find("input:radio").change(function(){0<$(this).parents(".currentAddress").length?(n.removeClass("on"),t.addClass("on"),t.find(
"input:checkbox").each(function(){$(this).prop("disabled",!1).prop("checked",!0),$(this).closest(".checkbox").find("label").addClass("checked").removeClass(
"disabled")})):(t.removeClass("on"),n.addClass("on"),t.find("input:checkbox").each(function(){$(this).prop("disabled",!0).prop("checked",!1),$(this).closest(
".checkbox").find("label").addClass("disabled").removeClass("checked")}))})},$.fn.tvManageDevices=function(){var e=$(this),t=e.closest(".mod-device"),n=t.find(
".mod-device__content"),i=t.find(".mod-device__rename"),o=n.add(i),r=i.find(".js-rename-device-cancel"),a=e.add(r),s=n.find(".mod-device__remove");if(0<s.length
){var c=n.find(".mod-device__remove-confirm"),l=n.find(".js-remove-device-cancel"),d=n.find(".mod-device__actions"),u=l.add(s),f=c.add(d);u.unbind().on("click",
function(e){e.preventDefault(),f.toggle()})}a.unbind().on("click",function(e){e.preventDefault(),o.toggle(),0<s.length&&c.is(":visible")&&f.toggle()})},
$.fn.tvManageDevices1=function(){var e=$(this),t=e.closest(".mod-device"),n=t.find(".mod-device__content"),i=t.find(".mod-device__rename"),o=n.add(i),r=i.find(
".js-rename-device-cancel"),a=e.add(r),s=n.find(".mod-device__remove");if(0<s.length)var c=n.find(".mod-device__remove-confirm"),l=n.find(
".js-remove-device-cancel"),d=n.find(".mod-device__actions"),u=l.add(s),f=c.add(d);u.unbind().on("click",function(e){e.preventDefault(),f.toggle()});var h=$(
this).closest(".mod-device__container"),p=(h.find(".mod-device__content"),h.find(".mod-device__rename").find("input")),v="";a.unbind().on("click",function(e){
e.preventDefault(),$(e.target).hasClass("js-rename-device")&&(v&&p.val(v),v=p.prop("defaultValue"),$(this).closest("ul").find(".mod-device__rename").each(
function(){"block"===$(this).css("display")&&$(this).hide().closest(".mod-device__container").find(".mod-device__content").show()})),$(e.target).hasClass(
"js-rename-device-cancel")&&p.val(v),o.toggle(),0<s.length&&c.is(":visible")&&f.toggle()})},$.fn.autocomplete=function(){new function(e){this.el=$(e).find(
".js-auto-complete-input")[0],this.stdResponse=$(e).find(".js-auto-complete__standart-response").text(),this.$body=$("body"),this.$window=$(window),
this.attrs={},this.attrs.resultscontainer=$(e).find(".auto-complete")[0],this.create=function(e,t){this.attrs.data=window[e.getAttribute("data-vf-source")],
this.attrs.data&&(this.bindevents(),this.attrs.screen=$(window).width())},this.bindevents=function(){var n=this;$(this.el).on("focus",function(e){if(
n.attrs.screen<500){var t=(t=$(this).parent()).offset();$(window).scrollTop(t.top)}this.value="",$(n.el).trigger("autcomplete:value-cleared")}),$(this.el).on(
"keyup",function(e){40==e.keyCode?$(n.attrs.resultscontainer).find("li a:first").focus():n.show(this)}),$(this.attrs.resultscontainer).on({click:function(){
n.set(this)},keydown:function(e){40==e.keyCode?($(this).parent().next().find("a").focus(),e.preventDefault()):38==e.keyCode?($(this).parent().prev().find("a"
).focus(),e.preventDefault()):13==e.keyCode&&(n.set(this),e.preventDefault())}},"a")},this.search=function(e){for(var t,n=[],i=this.attrs.data,
o=0;o<this.attrs.data.length;o++)t=i[o].Name.toLowerCase(),1==e.length?t.charAt(0)==e.charAt(0)&&n.push(i[o].Name):-1!==t.indexOf(e)&&n.push(i[o].Name);return n
},this.show=function(e){if(this.attrs.resultscontainer){$(this.attrs.resultscontainer).empty().hide();var t="",n=e.value.toLowerCase();if(""!=e.value){if(
results=this.search(n),0<results.length){var i=5;this.attrs.screen<500&&(i=3),results.length<i&&(i=results.length);for(var o=0;o<i;o++
)t+='<li><a href="javascript: void(0);" data-vf-selected="'+results[o]+'">'+results[o]+"</a></li>"}
t+="<li class='std-response'><a href='#a' class='no-results'>"+this.stdResponse+"</a></span></li>",this.attrs.resultscontainer.innerHTML=t,$(
this.attrs.resultscontainer).show()}}},this.set=function(e){e&&(-1!=e.className.indexOf("no-results")?(this.el.value=$(e).text(),$(this.el).trigger(
"autcomplete:no-value-selected")):(this.el.value=$(e).text(),$(this.el).trigger("autcomplete:value-selected")),$(this.attrs.resultscontainer).empty().hide())},
this.create(this.el)}(this)},$.fn.roamingChecklist=function(){var e=$(this).closest(".roaming-checklist"),s=($("form"),$(this)),c=e.find(
".roaming-checklist__summary"),t=c.find(".roaming-checklist__start-again"),n=(s.find(".primaryBtn"),s.find("input:radio")),l=s.find(".js-auto-complete-input"),
i=l.closest(".formRow"),d=window[l[0].getAttribute("data-vf-source")],u=n.filter("input[name=4g]"),f=n.filter("input[name=iphone]"),h=n.filter("input[name=ios]"
),p="N",v=e.find(".roaming-checklist__results"),g=e.find(".roaming-checklist__summary-placeholder"),m=_.template($(".js-roaming-checklist__template").html()),
b=_.template($(".js-roaming-checklist__template--summary").html()),o=_.template($(".js-roaming-checklist__template--noval").html()),y=null,C=null,w=e.find(
".roaming-checklist__copy"),r=s.find(".roaming-checklist__step2");w=$.parseJSON(w.text()),t.on("click",function(e){e.preventDefault(),c.addClass("hide"),
r.addClass("hide"),v.empty(),s.removeClass("hide"),l.focus()}),l.on("autcomplete:value-cleared",function(){r.addClass("hide")}),l.on(
"autcomplete:value-selected",function(){i.removeClass("error"),i.find(".errorMSG").remove(),l.closest("fomR"),r.removeClass("hide"),u.first()[0].focus()}),e.on(
"autcomplete:no-value-selected",function(){o=o({copy:{heading_cant_find:RoamingChecklistCopy.heading_cant_find,
desc_cant_find:RoamingChecklistCopy.desc_cant_find}}),v.empty().append(o)}),e.on("validation:roaming-checklist:passed",function(){if(
"undefined"==typeof Zones||"undefined"==typeof d||"undefined"==typeof User||"undefined"==typeof w)return!1;var e=l.val(),t=u.filter(":checked").val(),
n=f.filter(":checked").val();"Y"==n&&(p=h.filter(":checked").val());for(var i=0;i<d.length;i++)if(d[i].Name.toLowerCase()==e.toLowerCase()){var o=d[i];break}
for(i=0;i<Zones.length;i++)if(Zones[i].Internal_Zone==o.Internal_Zone){var r=Zones[i];break}var a={country:o,user:User,form:{"4GReady":t,iPhone:n,iOS8:p},
zone:r,copy:RoamingChecklistCopy};if(
"object"!=typeof a.country||"object"!=typeof a.user||"object"!=typeof a.form||"object"!=typeof a.zone||"object"!=typeof a.copy)return!1;y=m(a),y=$(y),C=b(a),
$.isFunction($.fn.vfDesktopAccordion)?y.find('a[data-vf-plugin="accordion"]').vfDesktopAccordion():$.isFunction($.fn.vfMobileAccordion)&&y.find(
'a[data-vf-plugin="accordion"]').vfMobileAccordion(),v.empty().append(y),g.empty().text(C),y.find(".accordionAnchor").first().trigger("click"),s.addClass("hide"
),c.removeClass("hide")})},$.fn.popup=function(){var e=function(e){this.opts={contentClass:null,content:null,
modalTemplate:'<div class="popup"><a href="" class="popup__close"><span class="sub-i sub-i-close"></span></a><div class="js-popup__content-hook"></div></div>',
modalObj:null,backdropTemplate:'<div class="popup__backdrop"></div>',backdropObj:null,contentHook:null},this.el=e,this.body=$("body"),this.form=this.body.find(
"form"),this.opts.contentClass=$(e).attr("data-vf-content"),this.opts.content=$("."+this.opts.contentClass).detach().removeClass("hide"),this.modalObj=$(
this.opts.modalTemplate),this.backdropObj=$(this.opts.backdropTemplate),this.contentHook=this.modalObj.find(".js-popup__content-hook"),this.contentHook.append(
this.opts.content),this.closeButton=this.modalObj.find(".popup__close"),this.atlCloseButtons=this.modalObj.find(".js-popup__close_alt"),this.init()}
;e.prototype.openPopup=function(){this.modalObj.show(),this.backdropObj.show()},e.prototype.closePopup=function(){this.modalObj.hide(),this.backdropObj.hide()},
e.prototype.init=function(){var t=this;t.modalObj.css("visibility","hidden"),t.body.append(t.backdropObj.hide()),t.form.append(t.modalObj),
t.modalHeight=t.modalObj.height()/2+50,t.modalObj.css({visibility:"visible","margin-top":"-"+t.modalHeight+"px",display:"none"}),$(t.el).on("click",function(e){
e.preventDefault(),t.openPopup()}),$(t.backdropObj).on("click",function(e){e.preventDefault(),t.closePopup()}),$(t.closeButton).on("click",function(e){
e.preventDefault(),t.closePopup()}),$(document).keyup(function(e){27==e.keyCode&&(e.preventDefault(),t.closePopup())}),
0<t.atlCloseButtons.length&&t.atlCloseButtons.on("click",function(e){e.preventDefault(),t.closePopup()})},new e(this)},$.fn.notifications=function(){var e=$(
".portlet_subscription_context");if(notifications=this,0<e.length){e.find(".subscriptionContainer").find(".subscriptionLabel");var t=notifications.find(
".notifications__popup"),n=notifications.find(".notifications__button"),i=$("html");notifications.removeClass("hide"),n.on("click",function(e){t.toggle(),
e.stopPropagation(),t.is(":visible")?i.on("click",function(e){$(e.target).closest(t).length||(t.hide(),$(this).unbind(e))}):i.off("click")})}},
$.fn.friendlyNamesConsole=function(){var n=[],e=function(e){this.container=e,this.name=this.container.find(".js-friendly-names__name").text(),
this.changeBtn=this.container.find(".js-friendly-names__change button:not(.disabled)"),this.disableBtn=this.container.find(
".js-friendly-names__change button.disabled"),this.form=this.container.find(".js-friendly-names__form"),this.toHide=this.container.find(
".js-friendly-names__to-hide"),this.cancelBtn=this.form.find(".js-friendly-names__cancel"),this.input=this.form.find(".friendlyName"),
this.submit=this.form.find(".primaryBtn");var t=this;n.push(this.name),this.disableBtn.on("click",function(e){e.preventDefault()}),this.changeBtn.on("click",
function(e){e.preventDefault(),t.form.find(".error").removeClass("error"),t.form.find(".errorMSG").remove(),t.form.removeClass("hide"),t.toHide.addClass("hide")
}),this.cancelBtn.on("click",function(e){e.preventDefault(),t.toHide.removeClass("hide"),t.form.addClass("hide")}),this.input.keydown(function(e){
13==e.keyCode&&(e.preventDefault(),t.submit.trigger("click"))})};this.each(function(){new e($(this))}),$.validator.existingFormValues={"friendly-names":n}},
$.fn.vfScrollToTop=function(){var e=$(this);$("html, body").animate({scrollTop:e.offset()-10},1e3)},$.fn.accountControlToggle=function(){$(
".accountControl_v1 .apply_changes").addClass("disabled"),$(".undo_changes").hide(),$(".on_off").prop("checked",!0);var e=$(".accountControl_v1 .link_class a")
;$(".deselectAll,.selectAll,.on_off").on("change",function(){$(".undo_changes").show(),$(".accountControl_v1 .apply_changes").removeClass("disabled")}),$(
".selectAll").click(function(){$(".switch-field").hasClass("Blocked")&&($(".switch-field").removeClass("Blocked"),$(".switch-field").addClass("Authorised"
).find("input.changevalue").val("Authorised")),$(".deselectAll").prop("checked",!1),$(".on_off").prop("checked",!1)}),$(".deselectAll").click(function(){$(
".switch-field").hasClass("Authorised")&&($(".switch-field").removeClass("Authorised"),$(".switch-field").addClass("Blocked").find("input.changevalue").val(
"Blocked")),$(".selectAll").prop("checked",!1),$(".on_off").prop("checked",!1)}),e.click(function(e){e.preventDefault();var t=$(this);t.closest(".switch-field"
).hasClass("Authorised")?(t.closest(".switch-field").removeClass("Authorised"),t.closest(".switch-field").addClass("Blocked").find("input.changevalue").val(
"Blocked")):t.closest(".switch-field").hasClass("Blocked")&&(t.closest(".switch-field").removeClass("Blocked"),t.closest(".switch-field").addClass("Authorised"
).find("input.changevalue").val("Authorised"));var n=$("li.user_status").length,i=$("div.Authorised").length,o=$("div.Blocked").length;n==i?($(".selectAll"
).prop("checked",!0),$(".deselectAll").prop("checked",!1),$(".on_off").prop("checked",!1)):n==o?($(".selectAll").prop("checked",!1),$(".deselectAll").prop(
"checked",!0),$(".on_off").prop("checked",!1)):($(".on_off").prop("checked",!0),$(".selectAll").prop("checked",!1),$(".deselectAll").prop("checked",!1)),$(
".undo_changes").show(),$(".accountControl_v1 .apply_changes").removeClass("disabled")}),$(".on_off").on("click",function(){$(".on_off").prop("checked",!0),$(
".deselectAll").prop("checked",!1),$(".selectAll").prop("checked",!1)})},$.fn.contact_radios=function(){$(".hidden_radio").hide(),$(".open_section").hide(),$(
".available_numbers").hide(),$(".edit_save, .edit_cancel").addClass("disabled"),1==$(".owner_contact").hasClass("checked")&&$(".edit_accordion").addClass(
"disabled"),$(".radio_contact").on("click",function(){if(1==$(".owner_contact").hasClass("checked")){var e=$(".edit_accordion");e.addClass("disabled"),e.find(
"h3").hasClass("open")&&e.find(".accordion_content").slideUp()}else 0==$(".owner_contact").hasClass("checked")&&$(".edit_accordion").removeClass("disabled")}),
$(".checkboxInput").on("click",function(){$(".edit_save, .edit_cancel").removeClass("disabled")});var t=$(this),e=t.find("input.administrator_role"),n=t.find(
".link_simple_view"),i=t.find(".link_expanded_view"),o=t.find(".assign_payfor"),r=t.find(".cancel_payfor");$(e).on("change",function(){e.is(":checked")?$(
".hidden_radio").show():1==$(".checkboxInput").hasClass("checked")?$(".hidden_radio").show():($(".checkboxInput").hasClass("checked"),$(".hidden_radio").hide())
}),$(n).on("click",function(){$(".expanded_view").show(),$(".simple_view").hide()}),$(i).on("click",function(){$(".expanded_view").hide(),$(".simple_view"
).show()}),$(o).on("click",function(){$(".assign_payfor").hide(),$(".available_numbers").show()}),$(r).on("click",function(){$(".assign_payfor").show(),$(
".available_numbers").hide()}),$(".cancel_payfor",t).click(function(e){t.find(".close_payfor").hasClass("checked")&&t.find(".close_payfor").removeClass(
"checked")}),$("div.one_set").each(function(){var t=$(this);$(".assign_number",t).click(function(e){return $div=$("div.open_section",t),$btn=$(".assign_number",
t),e.preventDefault(),$div.show(),$btn.hide(),$(".assign_number").not($btn).addClass("disabled").show(),$("div.open_section").not($div).hide(),!1}),$(
".cancel_button",t).click(function(e){return t.find(".close_check").hasClass("checked")&&t.find(".close_check").removeClass("checked"),$(".close_check").prop(
"checked",!1),$div=$("div.open_section",t),$btn=$(".assign_number",t),e.preventDefault(),$div.hide(),$btn.show(),$(".assign_number").not($btn).removeClass(
"disabled").show(),!1})})},(t=jQuery).fn.vfAdminLevelDescription=function(){t(".openMoreDetails").on("click",function(e){e.preventDefault(),t(
".moreDetailsOuter").show(),t(".moreDetailsOuter .moreDetails").css("display","block"),t(".openMoreDetails").vfAdminLevelDescription()}),t(
".moreDetailsOuter .moreDetails .close").on("click",function(e){e.preventDefault(),t(".moreDetailsOuter").hide()})},$(".portlet_contactManagement").each(
function(){$(this).contact_radios(),$(this).vfAdminLevelDescription()}),$(".accountControl_v1").each(function(){$(this).accountControlToggle()}),$(
".multiplePackages").each(function(){$(this).togglePackageDetails()}),$(".moreDetailsContainer .more_details_link").each(function(){$(this).moreDetails()}),$(
".toggleInputs").vfToggleInputs(),$(".tabbedInputs").vfTabbedInput(),$(".individualOfferWrapper").vfNoThanks(),$(".hideParentContainer").vfHideParentContainer()
,$(document).vfAutoProceed(),$(".slideContainerHeader").vfContainerSlider();var e,n=$(".portlet_forcePasswordChangeForm");n.changeUsername(),
n.useEmailAsUsername(),$(".portlet_top17").each(function(){$(this).transactionAllowedCheck()}),$(".portlet_topup_v2, .portlet_topup_v4").each(function(){$(this
).togglePackServiceDetails()}),$(".portlet_manageBillingProfile").each(function(){$(this).sortCodeFormat()}),$(".portlet_myOffers").each(function(){$(this
).myOffersSetup()}),$(".memWordHint").vfMemorableWordHint(),$(".toggleContainer").vfRadioToggles(),$(".toggleUseOwnUsername").vfToggleEmailUsername(),$(
".radioContainer.toggleUseOwnUsername").vfClickRegistration(),$(".portlet_Manage_payment_methods table, ul.savedCardsList").each(function(){$(this
).vfCardExpiry()}),$(".portlet_payment_subflow_saved .savedCardsList").vfShowAndHidePaymentDetails(),$(".portlet_portIn").vfMoveDate(),$(".jsExtendContainer"
).each(function(){$(this).jsExtendContainerDropdown()}),$(".portlet_payment_subflow_v4 .savedCards").each(function(){$(this).savedCardsLabels()}),$(
".portlet_availability_checker .info_box").each(function(){$(this).infoBox()}),$(".cancel-options").each(function(){$(this).cancelOptions()}),$(
".js-date-convert-container").each(function(){$(this).dateTimeConverter()}),$(".js-reveal-container").each(function(){$(this).reveal()}),$(".js-friendly-names"
).each(function(){$(this).friendlyNamesConsole()}),$(".js-reveal-checkbox").each(function(){var e=$(this);e.is("input")?e.reveal("radio"):e.find("input"
).reveal("radio",e.attr("class").split(/\s+/))}),$(".js-label-container").each(function(){$(this).populateLabelContent()}),$(".js-list-selector-group").each(
function(){$(this).selectAllCheckboxes()}),$(".countdown-number").each(function(){$(this).countdownStyling()}),$(".deregister_devices .js-rename-device").each(
function(){$(this).tvManageDevices()}),$(".portlet_manage_devices .js-rename-device").each(function(){$(this).tvManageDevices1()}),$(".roaming-checklist__form"
).each(function(){$(this).roamingChecklist()}),$(".js-auto-complete").each(function(){$(this).autocomplete()}),$(".js-popup").each(function(){$(this).popup()}),
$(".offerContainer").vfReadMore({contentClass:"offerContainer"}),$(".product").vfReadMore({singular:!1,contentClass:"product"}),$(".portlet_balance_checker_v2"
).each(function(){$(this).setupAllowances()}),$(".filter_box").each(function(){$(this).filterBox()}),$(".portlet_pay_bill_v2").each(function(){$(this
).previousBillSelectDropdown()}),$(".tariff_migration").each(function(){$(this).showalllists()}),$(".tariff_migration_v2").each(function(){$(this).showalllists(
)}),$(".tariff_migration_v2").each(function(){$(this).vfScrollToTop()}),$(".portlet_payment_subflow_v4").each(function(){$(this).paymentMethodSelection()}),0<$(
".portlet_accountsummary_v3").length&&($(".portlet_accountsummary_v3 .accordionDetails .items li .info").each(function(e){$(this).toggleInfoBox()}),$(
".portlet_accountsummary_v3 .search").each(function(){$(this).searchAccounts()}),$(".portlet_accountsummary_v3 .accordionWrapper").each(function(){$(this
).ctnFilter()}),0<(e=$(".portlet_accountsummary_v3 .individualContainer.js_open")).length&&!e.closest(".individualWrapper").hasClass("single_account")&&e.each(
function(){$(this).singleAccordion()})),0<$(".accountsummary_v4").length&&($(".accountsummary_v4 .accordionContent .infoController").each(function(e){$(this
).showhideinfobox()}),0<(e=$(".accountsummary_v4 .individualContainer.js_open")).length&&!e.closest(".individualWrapper").hasClass("single_account")&&e.each(
function(){$(this).singleAccordion()})),$(".portlet_Manage_payment_methods table tbody tr:not(.hidden)").vfManagePaymentTable(),$(".helpText").each(function(){
$(this).vfToolTips()}),$(".text_alert").each(function(){$(this).vfToolTips("text_alert")}),$(
".portlet_payment_subflow .formContainer, .portlet_payment_subflow_saved .formContainer, .portlet_Manage_payment_methods .formContainer").each(function(){$(this
).vfCardSelect()}),window.getTimeRules=$(".mod-add-rules").first().modAddRules();var i=$(".list-add-remove");if(0<i.length){var o=[],r={};i.each(function(){
o.push($(this).listAddRemove(o,r))})}if(0<$(".portlet_myOffers").length&&null!=document.querySelector(".portlet_myOffers"))for(
var a=document.getElementsByClassName("individualOfferWrapper"),s=0;s<a.length;s++){var c=a[s].getElementsByClassName("offerContainer"),
l=c[0].getElementsByTagName("h3")[0].innerText;0===l.indexOf("Recently upgraded?")?c[0].className+=" offerRecentlyUpgraded":0===l.indexOf(
"100 international minutes")||0===l.indexOf("500 international minutes")?c[0].className+=" offerInternationalMins":0===l.indexOf("1GB UK Data")||0===l.indexOf(
"2GB UK Data")?c[0].className+=" offerUKData":0===l.indexOf("100 International Texts")?c[0].className+=" offer100IntTexts":0===l.indexOf("100 Picture Messages"
)?c[0].className+=" offer100PictureMessages":0===l.indexOf("300 minutes to 08 numbers")&&(c[0].className+=" offer300MinsTo08Numbers")}}),VF_checkCookie(),$(
document).ready(function(){$(document).vfEbillingPageLoad()}),function(d){d.fn.vfEbillingPageLoad=function(){d(".portlet_pay_bill_v2 .makePaymentForm").hide(),
d(".portlet_pay_bill_v2 .box.other input[name*=otherPayment]").addClass("validateItem validateNonZeroNumeric").prop("disabled",!0),d(
".portlet_billItemisation_v2").width50equalise(),d(".portlet_billDetails_v2 .accordionWrapper").each(function(){d(this).vfBillBreakdownAccordion()}),d(
".portlet_pay_bill_v2 .billContainer .makePayment").click(function(e){d(this).hide()})},d.fn.vfMakePayment=function(){var n=d(".portlet_pay_bill_v2");n.find(
".makePaymentForm").show(),n.find(".box label:first").click();var i=n.find(".box.other input[name*=otherPayment]");i.prop("disabled",!0).addClass(
"validateItem validateNonZeroNumeric"),n.find(".box .radio label").on("click",function(e){validator.resetForm(),n.find(".box").removeClass("on");var t=d(this
).closest(".box");t.addClass("on"),t.hasClass("other")?i.prop("disabled",!1):i.prop("disabled",!0)}),n.find(".cancelMakePayment").on("click",function(e){
e.preventDefault();var t=d(".portlet_pay_bill_v2");t.find(".box.other input[name*=otherPayment]").val(""),t.find(".makePaymentForm").hide(),t.find(
".billContainer .makePayment").show()})},d.fn.width50equalise=function(){var e=0,t=d(".width50.alpha, .width50.omega");t.each(function(){e=Math.max(d(this
).height(),e)}),t.each(function(){d(this).height(e)})},d.fn.vfBillBreakdownAccordion=function(){var e=d(this),s="closed",c="open",l=d(
".portlet_billItemisation_v2");e.find(".individualWrapper .accordionAnchor").on("click",function(e){e.preventDefault();var t=d(this),n=t.closest(
".accordionWrapper"),i=t.closest(".individualWrapper").find(".individualContainer"),o=i.find(".accordionDetails"),r=n.find(".individualContainer."+c),a=r.find(
".accordionDetails");a.slideUp(200,function(){a.hide(),r.addClass(s).removeClass(c),0<l.length&&l.hide()}),i.hasClass(s)&&(i.addClass(c).removeClass(s),
o.slideDown(200,function(){o.show(),0<l.length&&(t.hasClass("closeItemised")||t.hasClass("openItemised"))&&l.show()}))})}}(jQuery),VDF_JSVersion||(
VDF_JSVersion={}),VDF_JSVersion.paybill={version:"3.10.2"},$(document).ready(function(){$(document).vfEbillingPageLoad1(),$(document).loadBill()}),function(r){
r.fn.loadBill=function(){r(".withTable").show(),r(".withoutTable").hide()},r.fn.vfEbillingPageLoad1=function(){r(".portlet_pay_bill .makePaymentForm").hide(),r(
".portlet_pay_bill").vfPayOtherInput(),r(".portlet_billItemisation").width50equalise(),r(".portlet_billDetails .accordionWrapper").each(function(){r(this
).vfBillBreakdownAccordion1()}),r(".portlet_pay_bill .billPaymentContainer .makePayment").click(function(e){r(this).hide()})},r.fn.vfPayOtherInput=function(){
var e=r(".portlet_pay_bill .billContainer .bill-amount input"),t=r('.portlet_pay_bill .billContainer input[type="radio"][name="paybill"]')
;t.length&&-1!==t.attr("id").indexOf("pay-other")?e.prop("disabled",!1):e.prop("disabled",!0),t.on("click keypress",function(){-1!==r(this).attr("id").indexOf(
"pay-other")?e.prop("disabled",!1):e.prop("disabled",!0)}),r(".billContainer button").on("click",function(){r(".portlet_pay_bill").vfScrollToTop()})},
r.fn.vfMakePayment1=function(){event.preventDefault();var n=r(".portlet_pay_bill");n.find(".makePaymentForm").show(),n.find(".box label:first").click()
;var i=n.find(".box.other input[name*=otherPayment]");i.prop("disabled",!0).addClass("validateItem validateNonZeroNumeric"),n.find(".box .radio label").on(
"click",function(e){validator.resetForm(),n.find(".box").removeClass("on");var t=r(this).closest(".box");t.addClass("on"),t.hasClass("other")?i.prop("disabled",
!1):i.prop("disabled",!0)}),n.find(".cancelMakePayment").on("click",function(e){e.preventDefault();var t=r(".portlet_pay_bill");t.find(
".box.other input[name*=otherPayment]").val(""),t.find(".makePaymentForm").hide(),t.find(".billPaymentContainer .makePayment").show()})},
r.fn.width50equalise=function(){var e=0,t=r(".width50.alpha, .width50.omega");t.each(function(){e=Math.max(r(this).height(),e)}),t.each(function(){r(this
).height(e)})},r.fn.vfBillBreakdownAccordion1=function(){r("#myMenu").show(),r(".accordionWrapper"),r(".accordionAnchor").click(function(e){e.preventDefault()
;var t,n,i,o=r(this);o.parent().parent().hasClass("open")?((i=o.parent()).parents().hasClass("non-adf")||0<i.find(" > .accordionAnchor-adf").length&&(i.find(
".accordionAnchor-html").hide(),i.find(".accordionAnchor-adf").show()),o.parent().parent().removeClass("open"),o.parent().next().slideUp(350),o.parent().parent(
).find(".individualContainer").removeClass("open").find(".accordionDetails").slideUp(350)):(t=o.parent(),(n=r(".third-level")).find(".accordionAnchor-html"
).hide(),n.find(".accordionAnchor-adf").show().css("display","block"),r(".withoutTable").show().css("display","block"),r(".withTable").hide(),0<t.find(
" > .accordionAnchor-adf").length&&(t.find(".accordionAnchor-html").show().css("display","block"),t.find(".accordionAnchor-adf").hide()),o.parent().parent(
).parent().parent().find(".individualContainer").removeClass("open"),o.parent().parent().parent().parent().find(".accordionDetails").slideUp(350),o.parent(
).parent().toggleClass("open"),o.parent().next().slideToggle(350))})}}(jQuery),VDF_JSVersion||(VDF_JSVersion={}),VDF_JSVersion.Mobile={version:"3.10.1"}
;var css_doc_links=document.getElementsByTagName("link");for(var i in css_doc_links)if(css_doc_links[i].href&&-1!==css_doc_links[i].href.indexOf(
"/adf/styles/cache")){document.getElementsByTagName("head")[0].removeChild(css_doc_links[i]);break}function submitPCIForm(){var e,t,n,i,o;e=$(".house_number"
).val(),t=$(".street_manual").val(),n=$(".town_manual").val(),i=$(".county_manual").val(),o=$(".postcode_manual").val(),cardNumber=$(".cardNo").val(),
"null"!=cardNumber&&undefined!=cardNumber&&(document.getElementById("cardNumber").value=cardNumber),"null"!=e&&undefined!=e&&(document.getElementById(
"houseNameNumber").value=e),"null"!=t&&undefined!=t&&(document.getElementById("street").value=t),"null"!=n&&undefined!=n&&(document.getElementById("town"
).value=n),"null"!=i&&undefined!=i&&(document.getElementById("county").value=i),"null"!=o&&undefined!=o&&(document.getElementById("postcode").value=o),
document.forms[0].action=document.getElementById("pciURL").value,document.forms[0].submit()}function dummy(e){}function submitTopupSuccess(){
document.forms[0].action=document.getElementById("authenticatedSuccessURL").value,document.forms[0].submit()}function submitTo3DSecure(){
document.forms[0].action=document.getElementById("submitURL").value,document.forms[0].submit()}function pageErrorReload(){var e=document.location.href.split(
"&amp;");"loaded=true"!=e[e.length-1]&&(window.location.href=window.location.href+"&amp;loaded=true")}function hardFix(){}function submitToSourceTF(){
top.location!=self.location&&(top.location=document.getElementById("sourceTFUrl").value)}function submitToSourceTF(){top.location!=self.location&&(
top.location=document.getElementById("sourceTFUrl").value)}if("function"!=typeof String.prototype.trim&&(String.prototype.trim=function(){return this.replace(
/^\s+|\s+$/g,"")}),Ext={},Ext.is={init:function(e){var t,n,i=this.platforms,o=i.length;for(e=e||window.navigator,t=0;t<o;t++)this[(n=i[t]
).identity]=n.regex.test(e[n.property]);this.Desktop=this.Mac||this.Windows||this.Linux&&!this.Android,this.Tablet=this.iPad,
this.Phone=!this.Desktop&&!this.Tablet,this.iOS=this.iPhone||this.iPad||this.iPod,this.Standalone=!!window.navigator.standalone},platforms:[{
property:"platform",regex:/iPhone/i,identity:"iPhone"},{property:"platform",regex:/iPod/i,identity:"iPod"},{property:"userAgent",regex:/iPad/i,identity:"iPad"},
{property:"userAgent",regex:/Blackberry/i,identity:"Blackberry"},{property:"appVersion",regex:/Blackberry.*?Version\/6./i,identity:"Blackberry6"},{
property:"userAgent",regex:/BlackBerry.*?(9300|9360)/i,identity:"BlackberryNonTouch"},{property:"userAgent",regex:/Android/i,identity:"Android"},{
property:"platform",regex:/Mac/i,identity:"Mac"},{property:"platform",regex:/Win/i,identity:"Windows"},{property:"userAgent",regex:/IEMobile/i,
identity:"IEMobile"},{property:"platform",regex:/Linux/i,identity:"Linux"}]},Ext.is.init(),Ext.cssTranform={init:function(e){
prefixes=" ,-webkit-,-moz-,-o-,-ms-".split(","),duration="300ms",
this.IsCssTranform="WebkitTransform"in document.body.style||"MozTransform"in document.body.style||"msTransform"in document.body.style||"OTransform"in document.body.style||"transform"in document.body.style
,this.IsCssTranform&&($(".cssTranform").css("display","block"),$(prefixes).each(function(e){var t=$(".cssTranform");t.css(this+"transition-duration","0ms"),
t.css(this+"transform","translate(0px,-600px)")}))},slideUp:function(t,e){this.IsCssTranform?($(prefixes).each(function(e){$(t).css(this+"transition-duration",
duration),$(t).css(this+"transform","translate(0px,-600px)")}),setTimeout(function(){$(t).hide()},300)):$(t).hide(),$(e)&&$(e).hide()},slideDown:function(t,e){
$(e)&&$(e).show(),this.IsCssTranform?($(t).hide(),$(prefixes).each(function(e){$(t).css(this+"transition-duration","0ms"),$(t).css(this+"transform",
"translate(0px,-600px)")}),$(t).show(),setTimeout(function(){$(prefixes).each(function(e){$(t).css(this+"transition-duration",duration),$(t).css(
this+"transform","translate(0px,0px)")})},100)):$(t).show()},slideFromRight:function(t){this.IsCssTranform?($(t).hide(),$(prefixes).each(function(e){$(t).css(
this+"transition-duration","0ms"),$(t).css(this+"transform","translate(2000px,0px)")}),$(t).show(),setTimeout(function(){$(prefixes).each(function(e){$(t).css(
this+"transition-duration",duration),$(t).css(this+"transform","translate(0px,0px)")})},100)):$(t).show()},slideToLeft:function(t){this.IsCssTranform?($(
prefixes).each(function(e){$(t).css(this+"transition-duration",duration),$(t).css(this+"transition-timing-function","cubic-bezier(1.000, 0.0, 1.000, 1.000)"),$(
t).css(this+"transform","translate(-2000px,0px)")}),setTimeout(function(){$(t).hide()},300)):$(t).hide()}},Ext.touchUtils={isScrolling:!1,eventFinished:!1,
eventInitiator:[],startEvent:"touchstart",endEvent:"touchend",isInitiatedCollapse:!1,initTouchState:function(){(Ext.is.IEMobile||Ext.is.Desktop)&&(
this.startEvent="mousedown",this.endEvent="mouseup"),this.bindTouchState(
".btn,.formButtonContainer input[type='submit'],.voda-list-view li.btn-item,.voda-list-view li.lnk-item, div.topUpValueContainer, table.availablePacksTable span.price-container, .radioInput, a.primaryBtn, a.secondaryBtn, a.strongBtn, a.change_CTN, .portlet_pay_bill .leftClear a, .portlet_pay_bill .paymentsMade a, .portlet_pay_bill button.primaryBtn, .portlet_pay_bill button.secondaryBtn, .portlet_billItemisation button.buttonSm, .portlet_myPackageManageUnblocking button.buttonLrg"
);var e=this;$(document).on(this.endEvent,function(){e.eventFinished=!0,0!==e.eventInitiator.length&&setTimeout(function(){$(e.eventInitiator).removeClass(
"active"),e.eventInitiator=[]},100)})},bindTouchState:function(e){(Ext.is.IEMobile||Ext.is.Desktop)&&(this.startEvent="mousedown",this.endEvent="mouseup")
;var t=this;$(e).on("touchmove",function(e){t.isScrolling=!0,$(t.eventInitiator).removeClass("active"),t.eventInitiator=[]}),$(e).on(this.startEvent,function(){
t.isScrolling=!1;var e=this;setTimeout(function(){!1===t.isScrolling&&(t.eventInitiator.push(e),$(e).addClass("active"))},100)})},addActiveFunc:function(){$(
this).addClass("active")},removeActiveFunc:function(){$(this).removeClass("active")},initExpandableItems:function(){this.isInitiatedCollapse||($(
".voda-list-view .expand a.item-link").bind("click",function(){$(this).find(".item-icon").toggleClass("plus-icon"),$(this).find(".item-icon").toggleClass(
"minus-icon"),$(this).parent().find(".item-data").toggleClass("close").toggleClass("open")}),this.isInitiatedCollapse=!0)}},Ext.tabUtils={init:function(){$(
"#tabs-content div#tab_"+$("#tabs li.selected a").attr("id")).toggleClass("visible").show(),$("#tabs li.unselected a").on("click",function(){$(
"#tabs li.selected").toggleClass("unselected").toggleClass("selected"),$(this).parent().toggleClass("unselected").toggleClass("selected"),$(
"#tabs-content div.tabContent.visible").toggleClass("visible").hide(),$("#tabs-content div#tab_"+$(this).attr("id")).toggleClass("visible").show();var e=$(this
).text();e=e.replace(/ /gi,"").replace(/&/gi,"And"),Ext.Analitics.LogNav("prop49","None","mSales_Tab_"+e)})}},Ext.mainMenu={init:function(){$("#button-back"
).show(),$("#button-back").bind("click",function(){history.go(-1)}),$("#button-main-menu").bind("click",function(){$(".main-menu-overlay").height($(document
).height()),Ext.cssTranform.slideDown("#mainMenu",".main-menu-overlay"),$(".mainmenu-button-container").hide(),Ext.Analitics.LogNav("prop49","None",
"mSales_GridMenu_Open"),window.onresize=function(){$(".main-menu-overlay").height($(document).height())}}),$(".button-main-menu-close").bind("click",function(){
Ext.cssTranform.slideUp("#mainMenu",".main-menu-overlay"),$(".mainmenu-button-container").show()}),$(".main-menu-overlay").bind("click",function(){
Ext.cssTranform.slideUp("#mainMenu",".main-menu-overlay"),$(".mainmenu-button-container").show()}),$(".menu-grid .voda-list-view a").bind("click",function(){
var e=$(this).find(".item-title").text();e=e.replace(/ /gi,"").replace(/&/gi,"And"),Ext.Analitics.LogExtNav(this,"prop49","None","mSales_GridMenu_"+e)}),
Ext.touchUtils.bindTouchState(".menu-grid .menu-grid-item")}},Ext.Analitics={enabled:!0,LogNav:function(e,t,n){"undefined"!=typeof s&&this.enabled&&(
s.linkTrackVars=e,s.linkTrackEvents=t,s.prop49=s.pageName,s.tl(!0,"o",n))},LogExtNav:function(e,t,n,i){"undefined"!=typeof s&&this.enabled&&(s.linkTrackVars=t,
s.linkTrackEvents=n,s.prop49=s.pageName,s.tl(e,"e",i))},LogProd:function(e,t,n,i,o){"undefined"!=typeof s&&this.enabled&&(s.linkTrackVars=e,s.linkTrackEvents=t,
s.events=n,s.products=i,s.prop49=s.pageName,s.tl(!0,"o",o))},LogCampaign:function(e,t,n,i,o){"undefined"!=typeof s&&this.enabled&&(s.linkTrackVars=t,
s.linkTrackEvents=n,s.eVar37=i,s.prop49=s.pageName,s.tl(e,"o",o))}},function(c){c.fn.vfPasswordStrength=function(){var e=c(".passwordStrengthTexts");if(
0!==e.length){var t=c(".checkPassword").find("input[type='password']"),n=c('<div class="passwordContainer"></div>'),i=c(
'<div class="passwordStrengthText">Password strength - </div>'),o=c('<div class="passwordStrength">Weak</div>'),r=c('<div class="passwordBar"></div>'),a=c(
'<div class="weakPassword"></div>');r.append(a),n.append(i),n.append(o),n.append(r),t.on("focus",function(e){n.show(100)}),t.on("focusout",function(e){n.hide(
100)}),t.on("keyup",s),e.append(n),s(),n.hide()}function s(e){switch(n=t.val(),i=0,6<=n.length&&n.length<=30&&jQuery.each([/[^a-zA-Z0-9]/,/[a-z]+/,/[0-9]+/,
/[A-Z]+/],function(e,t){n.match(t)&&i++}),30<n.length?-1:0!==i&&1!==i?i-1:i){case-1:o.html("Error, password too long"),a.removeClass();break;case 0:o.html(
"Error, password too short"),a.removeClass();break;case 1:o.html("Weak"),a.removeClass(),a.addClass("weakPassword");break;case 2:o.html("Medium"),a.removeClass(
),a.addClass("mediumPassword");break;default:o.html("Strong"),a.removeClass(),a.addClass("strongPassword")}var n,i}}}(jQuery),function($){$.fn.vfmTabs=function(
x){return this.each(function(t,e){var c=this;if(!$(c).hasClass("JSTabbed")){var n;$(c).addClass("JSTabbed"),n=$(this).find("h3").not(
".infoMsgContainer h3, .errorMsgContainer h3, .successMsgContainer h3, .notATabHeader").length?"h3":"h4",jQuery.each($(this).find(n).not(
".infoMsgContainer h3, .errorMsgContainer h3, .successMsgContainer h3, .notATabHeader"),function(e){$(this).attr("id","tabContentHeader"+t+e).addClass(
"tabHeader")});var l=$(".portlet_payg1").find(".accordionSlide .icon_step").add($(".slide2")),d=$.extend({},{activeState:"selected",
tabContainerSelect:".tabbedContainer",tabListClass:"tabList",tabContent:"tab",setHeight:!1,updateFromHash:!0,tabbedContentItem:null,tabListElement:null,
tabBoxHeightArray:[],tabListItemArray:[],tabBoxArray:[],previousItem:-1,tabId:""},x);tabbedContentItemElements=$(e),d.tabId=tabbedContentItemElements.attr("id")
,""!==d.tabId&&"undefined"!=typeof d.tabId||(d.tabId="tabsItem"+t,tabbedContentItemElements.attr("id",d.tabId)),d.tabbedContentItem=tabbedContentItemElements
;var i=tabbedContentItemElements.attr("class").match(/tabbedContentHeight_[A-Za-z0-9]*/);i&&(d.setHeight=i[0].replace("tabbedContentHeight_","")),
d.tabListElement=$('<ul id="tabList_'+d.tabId+'" class="'+d.tabListClass+' JSTabs "></ul>');for(var o=tabbedContentItemElements.find(".tabLead, .tabHeader"),r=0
,a=o.length;r<a;r++){var s=o[r],u=$('<li id="tab_'+s.id+'"><a href="#'+s.id+'"><span>'+s.innerHTML+"</span></a></li>");0===r?u.addClass("firstTab"
):r===o.length-1&&u.addClass("lastTab"),d.tabListElement.append(u),$(s).hide()}d.tabListElement.addClass("contains"+o.length+"Tabs"),
tabbedContentItemElements.prepend(d.tabListElement);var f="ul."+d.tabListClass+" li, div."+d.tabContent,h=tabbedContentItemElements.find(f),p=h.length/2
;d.tabListItemArray=h.slice(0,p),d.tabBoxArray=h.slice(p);for(var v=0,g=d.tabBoxArray.length;v<g;v++
)d.setHeight?d.tabBoxHeightArray[v]=d.setHeight:d.tabBoxHeightArray[v]=$(d.tabBoxArray[v]).outerHeight();var m=0;if(d.updateFromHash)for(var b=location.hash,
y=d.tabListItemArray.length,C=0;C<y;C++)"#"+d.tabListItemArray[C].id==b&&(m=C,C=y);var w=$.makeArray($(c).find($(".tab"))),_=$(c).find($(".defaultTab"))
;m=-1!==$.inArray(_[0],w)?$.inArray(_[0],w):0,"undefined"!=typeof pageDefaultTab&&(m=pageDefaultTab),k.call(d.tabListItemArray[m],m),d.tabListItemArray.each(
function(t,e){$(e).bind("click",d,function(e){return $(this).trigger("tabActionEvent",[t,d]),e.preventDefault(),k.call(this,t)})})}function k(e,t){var n=!!t;$(
d.tabListElement).find("."+d.activeState).removeClass(d.activeState);var i,o,r,a,s=n?$(d.tabListItemArray[e]):s=$(this);s.addClass(d.activeState),0<s.closest(
".portlet_payg1").length&&(1==e?l.addClass("hidden"):l.removeClass("hidden")),s.children("a").addClass(d.activeState),d.tabBoxArray.hide(),i=e,o=n,
r=d.tabBoxHeightArray[i],a=$(d.tabBoxArray[i]),!1===d.setHeight?(a.css({height:d.tabBoxHeightArray[d.previousItem],display:""}),a.animate({height:r},200,
function(){a.css("height","auto"),o||$("body").trigger("tabOpenedEvent",[c,i])})):(a.css({display:"",height:d.setHeight+"px"}),o||$("body").trigger(
"tabOpenedEvent",[c,i])),d.previousItem=e}})}}(jQuery),function(c){c.fn.vfToolTips=function(a){var s=c.extend({iconClass:"helpIcon"},a);c(this).each(function(){
var e=c(this);e.hide();var t=c(e.parent(".staticHelpText"));if(t.length||(t=c(e.closest(".formRow"))),t.length||(t=c(e.parent())),t.find("."+s.iconClass
).length<1){var n=c(t.find("label")[0]);if(n.length||(n=c(t.find(".label")[0])),"text_alert"==a)var i=c('<div class="helpTextOff">'+e.html()+"</div>"),o=c(
'<div class="see_hint">See your hint</div>');else i=c('<div class="helpTextOff">'+e.html()+"</div>"),o=c('<span class="'+s.iconClass+'"></span>')
;n.length?n.after(o,i):t.append(o,i),t.addClass("js");var r=!1;o.add(i).on("touchstart click",function(e){e.preventDefault(),r=r?(i.removeClass("helpText"),
i.addClass("helpTextOff"),!1):(i.removeClass("helpTextOff"),i.addClass("helpText"),!0)})}})}}(jQuery),function(r){r.fn.vfSelectDropdown=function(){this.each(
function(e,t){if(!r(t).parent().is("a")){var n=r(t).attr("disabled")?" disabled":"",i=r(
'<a class="btn gray-button select'+n+'"><span class="select-label"></span><span class="button-icon drop-down-icon"></span></a>').append(r(t).clone());r(t
).replaceWith(i);var o=function(e){r(e).find(".select-label",e).text(e.find(":selected").text())};o(i),i.change(function(){o(r(this))})}})}}(jQuery),function(o
){o.fn.vfCheckboxes=function(e){o(this).each(function(){var t=o(this);0<t.parents(".portlet_addressManagement").length&&o(
".portlet_addressManagement .jsFormRowContainer input:checkbox").each(function(){o(this).parents("div:first").addClass("formRow checkbox")});var n=o(
'label[for="'+t.attr("id")+'"]'),e=o(this).closest(".formRow");if(0==n.length){var i=e.find("label");1==i.length&&(n=i).addClass("jsNotMatched")}t.hasClass(
"jsStyled")||(t.is("")?n.addClass("checkbox js"):(t.css({opacity:0}).addClass("jsStyled"),0!=t.closest(".parental-controls").length&&0==n.find("span.radio"
).length?n.prepend('<span class="radio"></span>'):n.addClass("checkboxInput"),(e=o(this).closest(".formRow")).addClass("checkbox js custom_checkbox"),t.prop(
"checked")&&n.addClass("checked"),t.prop("disabled")&&n.addClass("disabled"),n.on("click",function(e){e.preventDefault(),o(this).hasClass("disabled")||(
n.toggleClass("checked"),t.click())})))})}}(jQuery),function(a){a.fn.vfRadios=function(){a(this).each(function(){var i=a(this),o="";o=a(i).parent().is("td"
)?i.parent("td"):a(i).parent().is("li")?i.parent("li"):0<a(i).parents(".radioContainer").length?i.closest(".radioContainer"):i.closest(".formRow");var e=a(
'label[for="'+i.attr("id")+'"]');if(0==e.length){var t=o.find("label");1==t.length&&(e=t).addClass("jsNotMatched")}var n="radioInput",r=a(
".portlet_payment_subflow_saved .savedCardsList input:radio, .portlet_Manage_payment_methods .zebraTable input:radio");i.hasClass("jsStyled")||(i.is(r
)||0==e.length?(e.addClass("radio js"),i.addClass("css-radio")):(i.css({opacity:0}).addClass("jsStyled"),e.hasClass(n)||e.addClass(n),0==e.find("span.radio"
).length&&e.prepend('<span class="radio"></span>'),o.addClass("radio js jsRadio"),i.prop("checked")&&e.addClass("checked"),i.prop("disabled")&&e.addClass(
"disabled"),e.on("click",function(e){if(e.preventDefault(),a(this),!a(this).hasClass("disabled")){var t=i.attr("name"),n=a('input[name="'+t+'"]');a.each(n,
function(){var e=a(this),t=a('label[for="'+e.attr("id")+'"]');0==t.length&&1==(o=e.parent().is("td")?e.parent("td"):e.parent().is("li")?e.parent("li"
):0<e.parents(".radioContainer").length?e.closest(".radioContainer"):e.closest(".formRow")).find("label").length&&(t=o.find("label")),t.removeClass("checked")})
,a(this).addClass("checked"),i.focus(),i.prop("checked",!0).click().change()}}),i.on("click",function(){e.hasClass("checked")||e.trigger("click")})))})}}(jQuery
),function(n){n.fn.vfStickyFooter=function(){function e(){var e=n(".footer").outerHeight();n(".vodafone-header").css("border-top",e+"px solid"),n(".wrapper"
).css("margin-top","-"+e+"px")}e();var t="onorientationchange"in window?"orientationchange":"resize";window.addEventListener?window.addEventListener(t,e,!1
):window.attachEvent&&window.attachEvent(t,function(){e()})}}(jQuery),function(i){"use strict";var e="[data-toggle=dropdown]",t=function(e){var t=i(e).on(
"click.dropdown.data-api",this.toggle);i("html").on("click.dropdown.data-api",function(){t.parent().removeClass("open")})};function o(){i(e).each(function(){r(
i(this)).removeClass("open")})}function r(e){var t,n=e.attr("data-target");return n||(n=(n=e.attr("href"))&&/#/.test(n)&&n.replace(/.*(?=#[^\s]*$)/,"")),(t=i(n)
).length||(t=e.parent()),t}t.prototype={constructor:t,toggle:function(){var e,t,n=i(this);if(!n.is(".disabled, :disabled"))return t=(e=r(n)).hasClass("open"),o(
),t||e.toggleClass("open"),n.focus(),!1}},i(document).on("click.dropdown.data-api touchstart.dropdown.data-api",o).on(
"click.dropdown touchstart.dropdown.data-api",".dropdown form",function(e){e.stopPropagation()}).on("touchstart.dropdown.data-api",".dropdown-menu",function(e){
e.stopPropagation()}).on("click.dropdown.data-api touchstart.dropdown.data-api",e,t.prototype.toggle)}(window.jQuery),function(c){"use strict"
;var l="[data-toggle=account-dropdown]",d="Select an option",u='<span class="button-icon drop-down-icon"></span>',i=function(e){var t=c(e).find(".active"),n=c(e
).find("a.btn");n.html(t.find("a").text()+'<span class="button-icon drop-down-icon"></span>'),n.attr("href",t.find("a").attr("href")),t=n.on(
"click.account-dropdown.data-api .btn",this.toggle),c("html").on("click.account-dropdown.data-api",function(){var e=t.parent().find("a.btn");-1!==e.text(
).indexOf(d)&&(e.html(t.parent().find("ul.nav-items li.active a").text()+'<span class="button-icon drop-down-icon"></span>'),e.attr("href",t.parent().find(
"ul.nav-items li.active a").attr("href")),e.removeClass("nonselect"))})};i.prototype={constructor:i,toggle:function(){var e,t,n,i,o,r=c(this);t=(n=r,o=n.attr(
"data-target"),o||(o=(o=n.attr("href"))&&/#/.test(o)&&o.replace(/.*(?=#[^\s]*$)/,"")),(i=c(o)).length||(i=n.parent()),e=i).hasClass("open"),c(l).hasClass(
"account-dropdown")||c(l).each(function(){c(this).removeClass("open")}),e.toggleClass("open");var a=e.find("a.btn"),s=e.find(".nav-items li.active a")
;return t?(a.html(s.text()+u),a.attr("href",s.attr("href")),a.removeClass("nonselect")):-1===e.find("a.btn").text().indexOf(d)&&(a.html(d+u),a.attr("href",
"javascript:void(0)"),a.addClass("nonselect")),r.focus(),!1}};var e=c.fn.accountDropdown;c.fn.accountDropdown=function(n){return this.each(function(){var e=c(
this),t=e.data("account-dropdown");t||e.data("account-dropdown",t=new i(this)),"string"==typeof n&&t[n].call(e)})},c.fn.accountDropdown.Constructor=i,
c.fn.accountDropdown.noConflict=function(){return c.fn.accountDropdown=e,this},c.fn.accountDropDownMenuHighLight=function(){c(this).on("touchstart mousedown",
"li",function(){c(this).addClass("activemenu")}),c(this).on("touchend mouseup","li",function(){c(this).closest(".account-dropdown").length||c(this).removeClass(
"activemenu"),c(this).find("a").click()})}}(window.jQuery),function(i){i.fn.vfModalLightbox=function(){i(this).each(function(){var n=i(this);n.click(function(e
){i(document).append('<div class="modal-backdrop fade in"></div>');var t=n.attr("data-container");i(t).addClass("modal-dialog").fadeIn(),e.preventDefault()})})}
}(jQuery),function(l){l.fn.vfMobileAccordion=function(){var e=l(this),s=e.not(".accordion-indie").closest("h3"),c=l(".accordion.accordion-content")
;return e.each(function(){var e=l(this).addClass("accordionAnchor"),t=e.closest("h3"),n=e.attr("data-accordian-content"),i=t.next(n),o=e.hasClass(
"accordion-indie"),r=t.hasClass("open"),a=function(){t.addClass("open"),i.slideDown()};r&&a(),e.unbind().on("click",function(e){if(e.preventDefault(),l(e.target
).parents(".mod-accordion__item").hasClass("disabled"))return!0;i.is(":visible")?(t.removeClass("open"),i.slideUp()):(o||(s.removeClass("open"),s.next(n
).slideUp(),c.slideUp()),a())})})}}(jQuery),VDF_JSVersion||(VDF_JSVersion={}),VDF_JSVersion.vfPlusMinus={version:"1.2.1"},function(v){v.extend(v.fn,{
vfPlusMinus:function(){return this.each(function(){var e=v(this),r=parseInt(e.find(".maxCardinality").text()),t=e.find(".numberInstalled"),n=0,i=r-n,o=e.find(
".plusMinusInput"),a=o.find(".plus"),s=o.find(".minus"),c=o.find("input"),l=undefined;t.each(function(){0<parseInt(v(this).text(),10)&&v(this).closest(
".product").find(".formBtnInlineContainer").css("display","none"),n+=parseInt(v(this).text(),10)});var d=function(e){var t=parseInt(e.siblings(
".productMaxCardinality").text(),10)-parseInt(e.closest(".product").find(".numberInstalled").text(),10);return isNaN(t)?r:t},u=function(){e.closest(
".myPackageManage").find(".plusMinusInput").each(function(){var e=v(this).siblings("button.submit");v(this).find('input[type="text"]').val()<1?e.prop("disabled"
,!0).addClass("disabled"):e.prop("disabled",!1).removeClass("disabled")})},f=function(t){e.closest(".myPackageManage").find('.plusMinusInput input[type="text"]'
).each(function(){var e=t.val();v(this).val("0"),t.attr("value",e)})};u();var h=function(){var t=n;return e.find('.plusMinusInput input[type="text"]').each(
function(){var e=parseInt(v(this).val());t+=Number.NaN===e?0:e}),t},p=function(){i=r-n,c.attr("maxlength",i.toString())};p(),a.on("click",function(e){var t=v(
this).siblings("input"),n=parseInt(t.val());f(t),h()<r&&n<d(v(this))&&(n++,t.attr("value",n.toString())),u()}),s.on("click",function(e){var t=v(this).siblings(
"input"),n=parseInt(t.val());0<n&&(n--,t.attr("value",n.toString())),f(t),u()}),c.on("focus",function(e){l=v(this).attr("value")}),c.on("blur",function(e){
var t=v(this).parent(),n=t.find("input"),i=n.val(),o=v(t).closest(".prodDesc");(!/^[0-9]+$/.test(i)||i<0||h()>r||i>d(v(this)))&&(n.attr("value",l),v(
'<span class="value-error"> You have entered an invalid value, please try again.</span>').appendTo(o),v("span.value-error").delay(2e3).fadeOut(500)),f(n),u(),p(
)})})}})}(jQuery),function(i){i.fn.mmpAccordion=function(){return i.each(this,function(){var e=i(this);e.append("<span class='plus-minus'></span>"),e.parent(
).siblings("ul").slideUp(),e.click(function(e){var t=i(this),n=t.parent().siblings("ul").slideDown();t.toggleClass("open"),t.hasClass("open")?i(n).slideDown(
):i(n).slideUp()})})}}(jQuery),function(i){i.fn.billingProfilesSelect=function(e){return this.find(".billingProfile").click(function(e){i(
".billingProfile.selected").removeClass("selected"),i(this).addClass("selected")}),i.each(this,function(){i(this).click(function(e){i(this).toggleClass("active"
)})})},i.fn.billingProfilesSelectV2=function(e){return i(this).on("touchstart mousedown","li",function(){i(this).addClass("activemenu")}),i(this).on(
"touchend mouseup","li",function(){i(this).removeClass("activemenu")}),i.each(this,function(){i(this).click(function(e){i(this).toggleClass("active")})})},
i.fn.vfEbillAccountChargesAccordion=function(){this.find(".plus-minus").length||(this.each(function(e,t){var n=i(t).find("ul");n.length&&(n.hide(),i(t).find(
"h4").append("<span class='plus-minus'></span>"),i(t).find("h4").removeClass(""))}),i(this).bind("click",function(){i(this).find("h4").toggleClass("open"
).toggleClass(""),i(this).find("ul").toggle(100)}))}}(jQuery),function(o){o.fn.vfManagePaymentTable=function(){o(this).each(function(e){var t=o(this),n=t.next(
"tr").find("td.tableAlertMsg").length?t.next("tr"):o();0!==e&&e%2!=0||(t.addClass("zebra"),n.addClass("zebra")),t.find(".action_delete a").on("click",function(e
){e.preventDefault(),n.slideDown("200")}),n.find("a.cancelLink").on("click",function(e){e.preventDefault(),n.slideUp("200")})});var t=o("div.deleteAll"),
n=t.prev(".zebraTable"),i=o("a.deleteAll");i.on("click",function(e){e.preventDefault(),i.hide(),n.slideUp("200"),t.slideDown("200")}),o("div.deleteAll a").on(
"click",function(e){e.preventDefault(),i.show(),t.slideUp("200"),n.slideDown("200")})}}(jQuery),function(o){o.fn.vfCardSelect=function(){var e=o(this),n=e.find(
"select:eq(0)"),i=e.find("#selectedCard");n.on("change",function(e){var t=o(e.target).find("option:selected").val().toLowerCase();switch(t.length?n.parent(
).parent().find(".errorMSG").hide():n.parent().parent().find(".errorMSG").show(),t){case"":i.css("background-position","0 0");break;case"mastercard":i.css(
"background-position","0 -63px");break;case"maestro":i.css("background-position","0 -128px");break;case"visa credit":i.css("background-position","0 -32px")
;break;case"visa debit":i.css("background-position","0 -226px");break;case"visa electron":i.css("background-position","0 -96px")}})}}(jQuery),function(t){
t.fn.vfScrollToTop=function(){var e=t(this);t("html, body").animate({scrollTop:e.offset()-10},1e3)}}(jQuery),$.fn.setupAllowances=function(){
window.select_product=$(".portlet_balance_checker_v2 .select_product"),0<$(".portlet_balance_checker_v2").length&&0==$(
".portlet_balance_checker_v2 .carousel-ind").length&&$(".select_product_wrapper").after('<div class="carousel-ind"><ul class="carousel-ind"></ul></div>')
;var n=$(".portlet_balance_checker_v2 ul.carousel-ind"),i=0,t=select_product.find("li").length;if(0<select_product.length&&0==$(".portlet_balance_checker_v2"
).find(".carousel-ind li").length&&select_product.find("li").each(function(){n.append('<li><div class="circle"></div></li>')}),0<select_product.length){
0==select_product.find(".selected").length&&select_product.find("li:first").addClass("selected");var e=select_product.find(".selected"),o="."+e.data("report")
;$(o).addClass("active").show(),i=select_product.find("li").index(e),n.find("li").eq(i).addClass("active")}else $("ul.reports li:first").addClass("active"
).slideDown();window.prevButton=$(".select_product_btn.prev"),window.nextButton=$(".select_product_btn.next"),window.updateButtons=function(){
0==i?prevButton.addClass("disabled"):prevButton.removeClass("disabled"),i==t-1?nextButton.addClass("disabled"):nextButton.removeClass("disabled")},
nextButton.click(function(e){if(e.preventDefault(),$(this).hasClass("disabled"))return!1;i<t-1&&(i++,updateReports())}),prevButton.click(function(e){if(
e.preventDefault(),$(this).hasClass("disabled"))return!1;0<i&&(i--,updateReports())}),window.updateReports=function(){n.find("li.active").removeClass("active"),
n.find("li").eq(i).addClass("active");var e="."+select_product.find("li").eq(i).data("report"),t=$(".portlet_balance_checker_v2 .reports .active")
;select_product.find(".selected").removeClass("selected"),select_product.find("li").eq(i).addClass("selected"),t.removeClass("active"),t.slideUp(250,function(){
$(e).addClass("active").slideDown(400)}),updateButtons()},updateButtons()},$.fn.filterBox=function(){var t=$(this),n=t.find(".formContainer"),i="flt_close",
o="flt_open";t.find("h3").click(function(e){e.preventDefault(),$(this),t.hasClass(i)?n.slideDown(250,function(){t.removeClass(i).addClass(o)}):n.slideUp(250,
function(){t.removeClass(o).addClass(i)})}),t.find(".switch").click(function(e){e.preventDefault(),$(this).hasClass("sw_show")?t.hasClass(i)&&n.slideDown(250,
function(){t.removeClass(i).addClass(o)}):t.hasClass(o)&&n.slideUp(250,function(){t.removeClass(o).addClass(i)})})},$.fn.previousBillSelectDropdown=function(){
var e=$(".portlet_pay_bill_v2 .billContainer .width50.alpha select"),t=$(".portlet_pay_bill_v2 .billContainer .width50.alpha .select-label");if(0<e.length){
var n=e.find("option");t.text(t.text().split(" - ")[0]),e.prop("title",e.prop("title").split(" - ")[0]),n.each(function(){var e=$(this),t=e.text().split(" - "
)[0];e.text(t),e.prop("title",t)})}},$.fn.toggleInfoBox=function(){var t=$(this),n=t.closest("li"),i=".moreDetailsContainer",o="show_info",e=t.find(".show"),
r=n.find(".moreDetails .close, .info .hide");e.click(function(e){e.preventDefault(),n.find(i).show(),t.addClass(o)}),r.click(function(e){e.preventDefault(),
n.find(i).hide(),t.removeClass(o)})},$.fn.showhideinfobox=function(){var e=$(this),t=e.closest(".accordionContent"),n=".infoContainer",i=e.find(".show"),
o=e.find(".hide"),r=t.find(".moreDetails .close, .infoController .hide");i.on("click",function(e){e.preventDefault(),t.find(n).show(),t.find(o).show(),t.find(i
).hide()}),o.click(function(e){e.preventDefault(),t.find(i).show(),t.find(o).hide(),t.find(n).hide()}),r.click(function(e){e.preventDefault(),t.find(n).hide(),
t.find(i).show(),t.find(o).hide()})},$.fn.searchAccounts=function(){var e=$(this),a="js_search",s=e.closest(".individualContainer"),c=e.find(".search_box"),
l=e.find(".search_clear"),t=e.find(".search_submit"),d=s.find(".box_title"),u=s.find(".bill"),f=s.find(".box"),h=s.find(".items li"),p=s.find(
".search_noresults"),v=s.find(".accordionDetails"),g=s.find(".show-types"),n=$(".accordionWrapper"),m=$(n).find(".show-types input[type=checkbox]"),b=!0
;t.removeClass("primaryBtn"),l.removeClass("secondaryBtn"),t.on("click",function(e){e.preventDefault(),f.show();var n=$(this).closest(".formRow").find(
".search_box").val().toLowerCase(),i=h.length;$(".show-types input:checkbox:checked").length,s.addClass(a),""!=c.val()&&(d.add(u).hide(),l.show());for(
var t=document.querySelectorAll(".subscription_plan"),o=0,r=t.length;o<r;o++)t[o].style.display="none";h.each(function(){var e=$(this),t=e.find(".account .name"
).text().toLowerCase();-2<e.find(".account .number").text().toLowerCase().replace(/\s+/g,"").indexOf(n.replace(/\s+/g,""))+t.replace(/\s+/g,"").indexOf(
n.replace(/\s+/g,""))&&(b||e.hasClass("ctn_visible"))?(e.slideDown(0),e.addClass("ctn_visible"),e.addClass("ctn_slideDown"),e.parent().parent().prev().css(
"display","block"),p.slideUp(0),v.slideDown(0)):(e.slideUp(0),e.removeClass("ctn_slideDown"),--i<1&&(p.slideDown(0),v.slideUp(0),g.slideDown(0))),y(0)}),f.each(
function(e){var t=$(this);0==t.find("li:visible").length&&t.hide()})}),c.keyup(function(e){null!=c.val()&&""!=c.val()||(0===filter_count?(e.preventDefault(),
s.removeClass(a),h.each(function(){var e=$(this);e.hasClass("ctn_visible")&&e.slideDown(0)}),p.slideUp(0),d.add(u).add(v).slideDown(0)):0<$(
".show-types input:checkbox:checked").length&&($(".show-types input").each(function(){$(this).is(":checked")&&$(this).click().click()}),y(1)))}),$(
".show-types input[type=checkbox]").on("change",function(){b=!(0<$(".show-types input:checkbox:checked").length)}),l.click(function(e){e.preventDefault(),
s.removeClass(a),c.val(""),p.slideUp(0),0<$(".show-types input:checkbox:checked").length?(v.slideDown(0),h.each(function(){var e=$(this);e.hasClass(
"ctn_visible")&&e.slideDown(0)}),$(".show-types input").each(function(){$(this).is(":checked")&&$(this).click().click()})):(d.add(u).add(h).add(v).slideDown(0),
t.click()),l.hide(),y(1)});var y=function(e){for(var t=0,n=m.length;t<n;t++){for(var i=!1,o=$(m[t]).attr("name"),r=0,a=h.length;r<a;r++)if($(h[r]).hasClass(o
)&&($(h[r]).hasClass("ctn_slideDown")||1===e)){i=!0;break}i||$(o).is(":checked")?($(m[t]).prop("disabled",!1),$(m[t]).next().removeClass("inactiveCtn")):($(m[t]
).prop("disabled",!0),$(m[t]).next().addClass("inactiveCtn"))}}},$.fn.modAddRules=function(){var e=$(this),t=e.closest("form");t.vfValidate();var n=e.find(
".js-add-rule"),i=n.closest(".formButtonContainer"),o=e.find(".js-hidden-rules"),r=e.find(".mod-add-rules__rule").detach(),a=r.last().clone(),s=0,c=0,l={},
d=function(){var t="";return e.find("select").each(function(){var e=$(this).val();""==e&&(e="nil"),t+=e+","}),l["custom-rules"]=t.substring(0,t.length-1),o.val(
l["custom-rules"]),l},u=function(e){var t=(this.self=this).self;t.obj=e,t.days=t.obj.find("select.js-rule-days"),t.from=t.obj.find("select.js-rule-from"),
t.to=t.obj.find("select.js-rule-to"),t.remove=t.obj.find(".js-remove-rule"),t.remove.unbind().on("click",function(e){e.preventDefault(),s--,t.removeItself()}),
s++,c++,t.reSetInputIds(),t.addItself(),d()};return u.prototype.reSetInputIds=function(){var e=this.days.attr("id")+"_"+c,t=this.from.attr("id")+"_"+c,
n=this.to.attr("id")+"_"+c;this.days.attr("id",e).attr("name",e).closest(".formRow").find("label").attr("for",e),this.from.attr("id",t).attr("name",t).closest(
".formRow").find("label").attr("for",t),this.to.attr("id",n).attr("name",n).closest(".formRow").find("label").attr("for",n)},u.prototype.removeItself=function(
){this.obj.remove(),s<=1&&e.removeClass("js-show-remove-buttons")},u.prototype.addItself=function(){i.before(this.obj),this.obj.find("select").vfSelectDropdown(
),t.vfValidate(),1<s&&e.addClass("js-show-remove-buttons")},r.each(function(){new u($(this))}),n.unbind().on("click",function(e){e.preventDefault(),new u(
a.clone())}),d},$.fn.listAddRemove=function(o,n){var e=$(this),t=e.find(".js-add-domain"),r=t.find(".js-domain"),a=r.closest(".formRow"),i=e.find(".js-add"),
s=e.closest(".mod-accordion__item"),c=s.find(".js-added"),l=s.find(".js-max-items"),d=parseInt(l.text()),u=e.find(".js-msg-list-full"),f=e.find(".js-list_csv"),
h=f.attr("name"),p=e.find(".js-confirm"),v=p.find(".js-add-confirm"),g=p.find(".js-cancel"),m=p.find(".js-domain"),b=i.add(v),y=e.find(".errorMSG"),C=e.find(
"ul"),w=C.find(".js-template").removeClass("hide").detach(),_=function(e){return y.text(e).show(),a.addClass("error"),!1},k=function(e){var t=w.clone();t.find(
".js-name").text(e),t.find(".js-remove").unbind().on("click",function(){I.splice(I.indexOf(e),1),O(),t.remove()}),I.push(e),C.append(t),r.val(""),O()},x=!0,
O=function(){c.text(I.length),T(),I.length>=d?(j(),u.show()):(S(),u.hide()),0==I.length?C.hide():C.show()},j=function(){t.hide(),x=!1},S=function(){t.show(),
x=!0},I=[],T=function(){var e="";for(var t in I)I.hasOwnProperty(t)&&(e+=I[t]+",");f.val(e.substring(0,e.length-1)),n[h]=e.substring(0,e.length-1)};return O(),
g.unbind().on("click",function(){m.text(""),p.hide(),r.val(""),S()}),C.find("li").each(function(){var e=$(this),t=e.find(".js-name").text();k(t),e.remove()}),
r.keydown(function(e){if(13==e.keyCode)return e.preventDefault(),i.trigger("click"),!1}),b.unbind().on("click",function(e){var t=function(e){y.text("").hide(),
a.removeClass("error"),x||S(),p.hide();var t=r.val(),n=t.match(/^(?:https?:\/\/)?([a-zA-Z0-9-\.]+(?:\.[a-zA-Z]{2,}))(?:\/)?(\/.+)?$/);if(""==t)return _(
"Please enter this information.");if(null==n)return _("Please enter a valid domain.");if(I.length>=d||0==x)return _("Domain list is full");for(var i in o)if(
o.hasOwnProperty(i)&&-1!=o[i].indexOf(n[1]))return _("Domain is already in one of the lists");return"undefined"!=typeof n[2]&&e[0]!=v[0]&&n[1]!=m.text()?(
m.text(n[1]),p.show(),j(),!1):n[1]}($(this));return t?k(t):($.reportErrors("errorMSG"),!1)}),I},$.fn.showalllists=function(){var o=$(this),r=$(".shownumber"
).val(),a=r-1,e=o.find("ul.showallone li.showone");o.find("ul.showallone li.showone:gt("+a+")").hide();var s=e.length;$(".no_of_bundles p").text(function(e,t){
var n=$("ul.showallone li.showone:visible").length;return n==s&&$(".no_of_bundles").hide(),"Showing "+n+" of "+s+" plans"}),$(".next").click(function(e){
e.preventDefault();var t=$("ul.showallone").children("li.showone"),n=$("ul.showallone").children("li.showone:visible:last"),i=o.find(n.nextAll(":lt("+r+")"))
;i.length<r?($(".no_of_bundles").hide(),t.show()):i.show(),$(".no_of_bundles p").text(function(e,t){var n=$("ul.showallone li.showone:visible").length
;return n==s&&$(".no_of_bundles").hide(),"Showing "+n+" of "+s+" plans"}),$(".reptext").text(function(e,t){return 0!==$(
"ul.showallone li.showone:hidden:gt("+a+")").length?t.replace("Show all plans","Show next "+r+" plans"):t.replace("Show next "+r+" plans","Show remaining plans"
)})}),$(".reptext").text(function(e,t){return 0===$("ul.showallone li.showone:hidden:gt("+a+")").length?t.replace("Show next "+r+" plans","Show remaining plans"
):t.replace("Show all plans","Show next "+r+" plans")}),$(".reptext").addClass("secondaryBtn buttonLrg")},$(document).ready(function(){Ext.cssTranform.init(),
Ext.touchUtils.initTouchState(),Ext.mainMenu.init("mdch-det-dev01"),$(".view-only-subscription .jsExtendContainer.multi").removeClass("jsExtendContainer multi")
,$("#button-back").click(function(){history.go(-1)}),$(".account-dropdown").accountDropdown(),$(
"fieldset select, .selectContainer select, .formRow select, .paginationContainer_v2 select, .portlet_subscription_context .salutation select").not(
".mod-add-rules select").each(function(){$(this).vfSelectDropdown()}),$(".js-reveal-select-last").each(function(){$(this).reveal("select-last")}),$(
".tabbedContainer").vfmTabs({tabListClass:"navigation-tabs"}),$(".portlet_addressManagement .advancedOptions").hide(),$(
".portlet_addressManagement .openadvancedOptions").on("click",function(e){$(".portlet_addressManagement .advancedOptions").show()}),$(document).vfStickyFooter()
;var e=$(".portlet_forgottenpassword .formcontainer .validateOr .memWordHint");0<e.length&&e.html('<span style="font-weight:bold;">HINT: </span>'+e.html())
;var t=$(".portlet_forgottenpassword .or");t&&"or"==t.text().trim().toLowerCase()&&t.html('<hr><div class="orr">'+t.html()+"</div>"),$(
".portlet_Manage_payment_methods .zebraTable")&&2===$(".portlet_Manage_payment_methods .zebraTable tfoot tr td").length&&($(
".portlet_Manage_payment_methods .zebraTable tfoot tr td:first-child").attr("colspan","4"),$(
".portlet_Manage_payment_methods .zebraTable tfoot tr td:nth-child(2)").remove()),$(".portlet_manage_payment_methods .myprofiletable")&&$(
".portlet_manage_payment_methods .myprofiletable").prev("h4").css("font-weight","bold"),$(".account-dropdown .nav-items").accountDropDownMenuHighLight(),""==$(
".currentAddress").text()&&($(".AddressSearch").show(),$(".populatedAddress").hide()),$("input[name='enterPostcode']").click(function(e){$(".selectAddressDD"
).slideDown(),e.preventDefault()}),$("a.modal-link").vfModalLightbox(),$("a[data-vf-plugin='accordion']").vfMobileAccordion(),$(".productGroup").vfPlusMinus(),
$(".myPackageManage .productGroup h3, .product-group h3").mmpAccordion(),$(".profiles").billingProfilesSelect(),0<$(".portlet_pay_bill_v2 .billingProfileOuter"
).length?$(".portlet_pay_bill_v2 .billingProfileOuter").billingProfilesSelectV2():$(".portlet_pay_bill_v2 .profileContext h3").show(),$(
".showItemisation.accountCharges").vfEbillAccountChargesAccordion();var n=$(".portlet_addressManagement");if(0<n.length){n.find(".billingProfileOuter"
).billingProfilesSelectV2();var i=n.find(".advancedOptions"),o=n.find(".openadvancedOptions");0<o.length&&(i.hide(),o.on("click",function(e){i.is(":visible"
)||i.show()})),i.addressAdvancedOptions()}$(".printButton").hide()}),function(i){i.fn.vfAccountDetails=function(){return this.off().on("click",function(e){
var t=i(this),n=t.closest(".info").siblings(".moreDetailsContainer");e.preventDefault(),t.hide().siblings("a").show(),t.hasClass("show")?n.slideDown(500).find(
"a.close").hide():n.slideUp(500)})},i.fn.vfModal=function(){return!i(this).closest(".bd-modal-display").length&&this.wrap(
'<div class="bd-modal-body bd-modal-display"><div class="bd-modal-inner-body"></div></div>')},i.fn.vfModalClick=function(){return this.on("click",function(){
var e=".lightbox .portlet_2la_v3_open";return!i(""+e).closest(".bd-modal-display").length&&i(""+e).wrap(
'<div class="bd-modal-body bd-modal-display"><div class="bd-modal-inner-body"></div></div>')})},i.fn.vfCloseModal=function(){return this.on("click",function(e){
e.preventDefault(),window.location.reload(!0)})},i.fn.vfLHNDropdown=function(){return this.each(function(){var e=i(this),t=e.closest("li");e.off().on("click",
function(e){e.preventDefault(),t.toggleClass("open")})})}}(jQuery),function(e){e(document).ready(function(){e(".portlet_accountsummary_v3 .info a"
).vfAccountDetails(),e(".lightbox .portlet_easyLogin, .lightbox .portlet_registrationForm, .lightbox .portlet_2la_v3").vfModal(),e(".open-modal").vfModalClick()
,e(".lightbox.close a.close").vfCloseModal()})}(jQuery),function(e){e.fn.vfModal=function(){return!e(this).closest(".bd-modal-display").length&&this.wrap(
'<div class="bd-modal-body bd-modal-display"><div class="bd-modal-inner-body"></div></div>')}}(jQuery),function(e){e(document).ready(function(){e(
".info-panel .lightbox .portlet_easyLogin, .info-panel .lightbox .portlet_2la_v3").vfModal()})}(jQuery),"undefined"==typeof VF_BEVM)var VF_BEVM={
devnotes:"BEVM = block__element[--variant][--modifier]"};function consoleLogLevel(e,t,n){"use strict";if("undefined"==typeof console)return undefined;var i=0
;i=-1!==[3,"3","err","error"].indexOf(t)?3:i,i=-1!==[2,"2","warn","warning"].indexOf(t)?2:i,i=-1!==[1,"1","info","information"].indexOf(t)?1:i}
"undefined"==typeof VF_BEVM.classes&&(VF_BEVM.classes={}),"undefined"==typeof VF_BEVM.classes.portlets&&(VF_BEVM.classes.portlets={}),
Date.inMilliseconds=function(e){"use strict";switch(e){case"second":return 1e3;case"minute":return 6e4;case"hour":return 36e5;case"day":return 864e5;default:
return 1e3}},Object.toBoolean=function(e){"use strict";switch(typeof e){case"boolean":return e;case"number":return 0<e;case"string":return-1<["true","1","yes",
"on","checked","selected"].indexOf(e.trim());default:return!1}},String.quotify=function(e,t){"use strict";var n=2===t?'"':"'";return[n,-1<["string","number",
"boolean"].indexOf(typeof e)?e.toString():"",n].join("")},JSON.stringifyQuoted=function(e){"use strict";return JSON.stringify(e,function(e,t){return-1<[
"boolean","number"].indexOf(typeof t)?t.toString():t})},JSON.parseCasted=function(e){"use strict";function t(e,t){if("string"==typeof t){if(-1<["true","false"
].indexOf(t.trim()))return"true"===t||"false"!==t&&t;if(0!==(t.match(/^[1-9]/)||[]).length)return Number.parseFloat(t)}return t}
return"string"==typeof e?JSON.parse(e,t):JSON.parse(JSON.stringify(e),t)},$.fn.switchClass=function(e,t){"use strict";this.removeClass(e).addClass(t)},
$.fn.hasAnyClass=function(e){"use strict";e="string"==typeof e?e.split(","):"";for(var t=0;t<e.length;t++){var n=e[t].trim();if(n="."===n[0]?n.slice(1):n,
this.hasClass(n))return!0}return!1},function(y){"use strict";var r,C=VF_BEVM.classes.portlets.gdpr={portlet:{root:"portlet_gdpr",
root_changed:"portlet_gdpr--changed"},accountSwitcher:{root:"gdpr-account-switcher",root_single:"gdpr-account-switcher--single",
root_multiple:"gdpr-account-switcher--multiple",trigger:"gdpr-account-switcher--trigger",indicator:"gdpr-account-switcher__indicator",
header:"gdpr-account-switcher__header",headerCtn:"gdpr-account-switcher__header__accnum",items:"gdpr-account-switcher__items",
item:"gdpr-account-switcher__item",itemTrigger:"gdpr-account-switcher__item--trigger",itemCtn:"gdpr-account-switcher__item__accnum"},accordion:{
root:"accordion",item:"accordion__item",item_disabled:"accordion__item--disabled",item_opened:"accordion__item--opened",item_closed:"accordion__item--closed",
item_opening:"accordion__item--opening",item_closing:"accordion__item--closing",trigger:"accordion__item--trigger",indicator:"accordion__indicator",
header:"accordion__item__header",content:"accordion__item__content",svcnum:"service-group__header__svcnum",name:"service-group__header__name"},section:{
root:"section",root_changed:"section--changed",root_disabled:"section--disabled",container:"sections",container_changed:"sections--changed"},toggle:{
root:"toggle",root_changed:"toggle--changed",button:"toggle__button",button_checked:"toggle__button--checked",trigger:"toggle__button--trigger",
input:"toggle__checkbox",input_changed:"toggle__checkbox--changed"},submit:{root:"sections__submit",button:"submit__button",
button_disabled:"submit__button--disabled disabled",trigger:"submit--trigger"},message:{root:"gdpr-message"},lightbox:{root:"modal-dialog",
root_hidden:"modal-dialog--hidden",toggleInfo:"toggle-info",toggleInfo_hidden:"toggle-info--hidden",button_continue:"modal-dialog__button--continue",
button_cancel:"modal-dialog__button--cancel"}},f={json:{original:{},current:{}},domrefs:{},test:{}};y.fn.gdprInit=function(e){if(!(r=y(this[0])).hasClass(
C.portlet.root)){var t="ERROR: plugin must be run on "+String.quotify("."+C.portlet.root,2);throw new Error(t)}f.domrefs.ppr=y("div#pageContent, div#r1").get(0)
,f.domrefs.portlet=r.get(0),c.init(),i.init(),d.init(),l.init(),o.init(),s.init(),function(){var e=VF_parseURL(),t=(e&&e.params&&e.params.pref||"").trim();if(
t&&t.length){var n=y(".toggle--pref_"+t).eq(0);if(n.length){var i=n.parents("."+C.accordion.item);i.length?i.hasClass(C.accordion.item_opened)?o(n):r.on(
"accordion_initial_animation_finished",function(){r.off("accordion_initial_animation_finished"),o(n)}):o(n)}}function o(e){y("html, body").animate({
scrollTop:e.offset().top-25},1e3)}}();var n=r.find("."+C.message.root).eq(0);return n.length&&y("html, body").animate({scrollTop:n.offset().top},1e3),f};var c={
settings:{selectorGdprDataContent:":input[id$='gdprData::content']",selectorPreferenceSubmit:"button[id$='preferenceSubmit']",
selectorGdprCheckbox:"input[id^='gdprCheckBx_']",idGdprCheckboxBase:"gdprCheckBx",jsonGlobalNodeKey:"Global"},init:function(){this.settings,
f.domrefs.gdprDataContent=r.find(c.settings.selectorGdprDataContent).get(0),f.domrefs.preferenceSubmit=r.find(c.settings.selectorPreferenceSubmit).get(0),
f.json.editingCtn="",this.loadJson()},hiddenInputValue:function(e,t){var n=this.settings;e="string"==typeof e?e:"get",t="string"==typeof t?t:""
;var i=f.domrefs.gdprDataContent;if(!i)return consoleLogLevel("cannot find hidden input "+String.quotify(n.selectorGdprDataContent,2),3),undefined;switch(e){
case"get":return(i.value||"").trim();case"set":-1!==["string","number","boolean"].indexOf(typeof t)&&(t=(t.toString()||"").trim(),i.value=t)}},
loadJson:function(e){var t=this,n=t.settings;e="undefined"==typeof e||Object.toBoolean(e);var i=t.hiddenInputValue("get");if(!i.length)return consoleLogLevel(
"no json data found in "+String.quotify(n.selectorGdprDataContent,2),2),undefined;try{f.json.original=JSON.parseCasted(i),f.json.current=JSON.parseCasted(i)
}catch(u){return consoleLogLevel("cannot parse json from "+String.quotify(n.selectorGdprDataContent,2),3,u),undefined}f.json.editingCtn="",t.checkIsJsonEdited()
;var o=f.json.current;for(var r in o)if(t.isNode(r,o)){var a=o[r];for(var s in a)if(t.isNode(s,a)){var c=a[s];if(c.parentCtn=r,e){var l=[n.idGdprCheckboxBase,r,
s].join("_"),d=document.getElementById(l);d&&(c.domref=d)}}}},saveJson:function(e){var t=this,n=t.settings;e="object"==typeof e?e:f.json.current;try{
var i=JSON.parseCasted(JSON.stringify(e));delete i.isEdited,delete i.currentCtn,t.deletePropertyFromCtnNodes("isEdited",i),t.deletePropertyFromCtnNodes("domref"
,i),t.deletePropertyFromPrefNodes("parentCtn",i),t.deletePropertyFromPrefNodes("parentNode",i),t.deletePropertyFromPrefNodes("domref",i),t.hiddenInputValue(
"set",JSON.stringifyQuoted(i))}catch(o){return consoleLogLevel("cannot save json into "+String.quotify(n.selectorGdprDataContent,2),2,o),undefined}},
getNodeByCtn:function(e,t){this.settings;var n="string"==typeof e?e:"";return t="object"==typeof t?t:f.json.current,this.isNode(n,t)?t[n]:(String.quotify(n,2),
undefined)},getNodeByInputId:function(e,t){var n=this.settings;e="string"==typeof e?e:"",t="object"==typeof t?t:f.json.current;var i=new RegExp(
"(?:"+n.idGdprCheckboxBase+"_)(.*?)_(.*)").exec(e);if(!i||2===i.length)return consoleLogLevel("not a valid checkboxID "+String.quotify(e,2),2),undefined
;var o=i[1],r=i[2];if(this.isNode(o,t)){var a=t[o];return this.isNode(r,a)?a[r]:(String.quotify(o+"."+r,2),undefined)}return String.quotify(o,2),undefined},
updateNodesFromInputs:function(){var e=this.settings,t=f.json.current;for(var n in t)if(this.isNode(n,t)){var i=t[n];for(var o in i)if(this.isNode(o,i)){var r,
a=i[o];if(a.domref&&"object"==typeof a.domref)r=a.domref;else{var s=[e.idGdprCheckboxBase,n,o].join("_");"object"==typeof(r=document.getElementById(s))&&(
a.domref=r)}"object"==typeof r&&(a.state=r.checked)}}},updateInputsFromNodes:function(e){var t=this.settings;for(var n in e="object"==typeof e?e:f.json.current
)if(this.isNode(n,e)){var i=e[n];for(var o in i)if(this.isNode(o,i)){var r,a=i[o];if(a.domref&&"object"==typeof a.domref)r=a.domref;else{var s=[
t.idGdprCheckboxBase,n,o].join("_");"object"==typeof(r=document.getElementById(s))&&(a.domref=r)}"object"==typeof r&&l.setInputState(r,a.state,!1)}}},
checkIsJsonEdited:function(){this.settings;var e=f.json.current,t=f.json.original,n=!1;for(var i in e)if(this.isNode(i,e)){var o=e[i],r=!1;for(var a in o)if(
this.isNode(a,o)){var s=o[a],c=t[i][a];c&&"object"==typeof c&&(r=(s.edited=s.state!==c.state)||r)}n=(o.isEdited=r)||n}return e.isEdited=n},
countPrefsInCtn:function(e,t){this.settings;var n="string"==typeof e?e:"";t=(-1!==["boolean","number"].indexOf(t)?Object.toBoolean(t):t||"total").toString(
)||"total";var i=0,o=0,r=0,a=0,s=this.getNodeByCtn(n);if(s&&"object"==typeof s)for(var c in s)if(this.isNode(c,s)){var l=s[c];i++,l.state?o++:r++,
l.edited?a++:undefined}switch(t){case"true":return o;case"false":return r;case"edited":return a;case"total":return i}},deletePropertyFromCtnNodes:function(e,t){
this.settings;var n="string"==typeof e?e:"";for(var i in t="object"==typeof t?t:f.json.current)this.isNode(i,t)&&delete t[i][n]},
deletePropertyFromPrefNodes:function(e,t){this.settings;var n="string"==typeof e?e:"";for(var i in t="object"==typeof t?t:f.json.current)if(this.isNode(i,t)){
var o=t[i];for(var r in o)this.isNode(r,o)&&delete o[r][n]}},resetJson:function(){this.settings;try{f.json.current=JSON.parseCasted(JSON.stringify(
f.json.original)),this.saveJson()}catch(e){return consoleLogLevel("cannot reset json from "+String.quotify("__Json.original",2),2,e),undefined}},
submitJson:function(){this.settings,this.saveJson();try{var e=r.find("."+C.submit.button),t=C.submit.button_disabled;e.addClass(t)
;var n=f.domrefs.preferenceSubmit.id,i=AdfPage.PAGE.findComponentByAbsoluteId(n);AdfActionEvent.queue(i,!0)}catch(o){return consoleLogLevel(
"submitJson(): AdfPage or AdfActionEvent not found",3,o),undefined}},isNode:function(e,t){return t.hasOwnProperty(e)&&"object"==typeof t[e]}},d={settings:{
selectorCurrentCtnContent:"input[id$='currentCTN::content']",selectorAccordionSubmit:"button[id$='accordianSubmit']",dataServiceNumber:"data-service-number",
maxTime:.75*Date.inMilliseconds("second"),easing:"linear",allowMultipleItemsOpen:!1,allowAllItemsClosed:!0,allowTriggerDuringAnimation:!1,
closeOtherItemsBeforeOpen:!1},init:function(){this.settings,f.domrefs.currentCtnContent=r.find(d.settings.selectorCurrentCtnContent).get(0),
f.domrefs.accordionSubmit=r.find(d.settings.selectorAccordionSubmit).get(0);var e=this.hiddenInputValue("get");if(!e.length){var t=r.find(".service-group").eq(0
);e=this.getCtnFromItem(t)}f.json.currentCtn=e,this.prepItems()},hiddenInputValue:function(e,t){var n=this.settings;e="string"==typeof e?e:"get",
t="string"==typeof t?t:"";var i=f.domrefs.currentCtnContent;if(!i)return consoleLogLevel("cannot find hidden input "+String.quotify(n.selectorCurrentCtnContent,
2),3),undefined;switch(e){case"get":return(i.value||"").trim();case"set":-1!==["string","number","boolean"].indexOf(typeof t)&&(t=(t.toString()||"").trim(),
i.value=t)}},getCtnFromItem:function(e,t){var n=this.settings;t=Object.toBoolean(t);var i=(y(e).attr(n.dataServiceNumber)||"").trim();if(i.length)return i+(
t?" &ndash; "+this.getCtnNameFromItem(e):"");var o=y(e).find("."+C.accordion.svcnum);return o.length&&(i=(o.html()||"").trim()).length?i+(
t?" &ndash; "+this.getCtnNameFromItem(e):""):(i="Global")+(t?" &ndash; "+this.getCtnNameFromItem(e):"")},getCtnNameFromItem:function(e){this.settings;var t="",
n=y(e).find("."+C.accordion.name);return n.length&&(t=(n.html()||"").trim()),t},prepItems:function(){var n=this,i=n.settings,o=C.accordion.item_opened
;C.accordion.item_closed,[C.accordion.item_opening,C.accordion.item_closing].join(" "),f.json.current.Global.domref=y(".global-group").get(0),r.find(
"."+C.accordion.item).each(function(){var e=y(this),t=n.getCtnFromItem(e);e.attr(i.dataServiceNumber,t),c.isNode(t,f.json.current)&&(
f.json.current[t].domref=this),t!==f.json.currentCtn||e.hasClass(o)||window.setTimeout(function(){n.toggleItem(e)},1e3)})},toggleItem:function(e){
var t=this.settings,i=y(e).hasClass(C.accordion.item)?y(e):undefined;if(i&&i.length){var o=i.parents("."+C.accordion.root).eq(0),n=(o.find(
"."+C.accordion.indicator),o.find("."+C.accordion.item).not(i),o.find("."+C.accordion.item_opened)),r=o.find("."+C.accordion.item_opening),a=o.find(
"."+C.accordion.item_closed),s=o.find("."+C.accordion.item_closing),c=n.add(r),l=(a.add(s),r.add(s));o.hasClass(C.accordion.root_disabled),i.hasClass(
C.accordion.item_disabled),!t.allowTriggerDuringAnimation&&l.length,1===c.filter(i).length?t.allowAllItemsClosed?d.animateItems(i,{state:0}):c.not(i
).length&&d.animateItems(i,{state:0}):t.allowMultipleItemsOpen?d.animateItems(i,{state:1}):c.not(i).length?t.closeOtherItemsBeforeOpen?d.animateItems(c.not(i),{
state:0,complete:function(){var e=o.find("."+C.accordion.item_opened),t=o.find("."+C.accordion.item_opening),n=e.add(t);n&&n.length||d.animateItems(i,{state:1})
}}):(d.animateItems(c.not(i),{state:0}),d.animateItems(i,{state:1})):d.animateItems(i,{state:1})}},animateItems:function(e,t){var s,c=this,l=c.settings,
d=t.state,u=t.maxTime||l.maxTime,f=0,h=C.accordion.item_opened,p=C.accordion.item_opening,v=C.accordion.item_closed,g=C.accordion.item_closing,m=h+" "+p,
b=v+" "+g,n=window.setInterval(function(){f===i.length&&(window.clearInterval(n),r.trigger("accordion_initial_animation_finished"),
"function"==typeof t.complete&&t.complete())},75),i=y(e);i.each(function(e,t){var n=y(t),i=n.find("."+C.accordion.content).eq(0);if(!i||!i.length){
var o=c.getCtnFromItem(n);return consoleLogLevel("no content section found for accordion_item "+String.quotify(o,2),2),undefined}var r=i.get(0).scrollHeight,
a=100*parseFloat(i.css("height"))/r;0===d?(s=u/100*a,n.switchClass(m,g),i.stop(!0).animate({height:0},{duration:s,easing:l.easing,complete:function(){
n.switchClass(g,v),i.css({height:""}),f++}})):1===d&&(s=u/100*(100-a),n.switchClass(b,p),i.stop(!0).animate({height:r},{duration:s,easing:l.easing,
complete:function(){n.switchClass(p,h),i.css({height:""}),f++}}))})},submitAccordion:function(){this.settings;try{var e=f.domrefs.accordionSubmit.id,
t=AdfPage.PAGE.findComponentByAbsoluteId(e);AdfActionEvent.queue(t,!0)}catch(n){return consoleLogLevel("submitAccordion(): AdfPage or AdfActionEvent not found",
3,n),undefined}}},l={settings:{selectorGdprCheckbox:"input[id^='gdprCheckBx_']",idGdprCheckboxBase:"gdprCheckBx",doToggleAfterRevert:!0},init:function(){
this.settings,this.prepInputs()},prepInputs:function(){var e=this,t=e.settings;c.updateInputsFromNodes(),r.find(t.selectorGdprCheckbox).each(function(){
e.setInputState(this,this.checked,!0)}),y(".global-group, .service-group").each(function(){e.setSubmitButton(this,!1)})},setInputState:function(e,t,n){
this.settings,t=Object.toBoolean(t),n=Object.toBoolean(n);var i=y(e);if(i&&i.length&&i.hasClass(C.toggle.input)&&(!0===t?i.prop("checked",!0).attr("checked",
"checked").val("on"):i.prop("checked",!1).removeAttr("checked").val("off"),n)){var o=C.toggle.button_checked,r=i.parents("."+C.toggle.button)
;r&&r.length&&r.toggleClass(o,t)}},setSubmitButton:function(e,t){if(this.settings,t=Object.toBoolean(t),!y(e).hasAnyClass("global-group, service-group")
)return undefined;var n=y(e).find("."+C.submit.button);n.length&&n.toggleClass(C.submit.button_disabled,!t)},toggleInput:function(e){this.settings;var t=y(e),
n=t.attr("id"),i=c.getNodeByInputId(n);if(i&&"object"==typeof i){var o=i.parentCtn,r=f.json.current[o],a=c.getNodeByInputId(n,c.original),s=t.prop("checked")
;i.state=!s,i.edited=i.state!==a.state,this.setInputState(t,i.state,!0),c.checkIsJsonEdited(),f.json.editingCtn=r.isEdited?o:"",this.setSubmitButton(r.domref,
r.isEdited)}}},i={settings:{selectorAccountSelect:"select[id$='chooseAccount::content']"},init:function(){this.settings,this.prepSwitcher()},
prepSwitcher:function(){var e=this.settings,t=r.find("."+C.accountSwitcher.root);if(t&&t.length){var n=C.accountSwitcher.root_single,
i=C.accountSwitcher.root_multiple,o=t.find(e.selectorAccountSelect);o&&o.length?t.switchClass(n,i):t.addClass(i,n),t.find("label").attr("for",o.attr("id"))}}},
s={settings:{selectorModalSaveChanges:"div#modal-dialog__unsaved-changes"},init:function(){var e=this.settings,t=r.find(e.selectorModalSaveChanges)
;f.domrefs.modalUnsavedChanges=t.get(0);var n=t.find(".toggle-notice--global > p"),i=n.html()||"";n.html(i);var o=t.find(".toggle-notice--service > p");i=(
i=o.html()||"").replace("another account","another section"),e.serviceMessageOriginal=i,o.html(e.serviceMessageOriginal),this.prepLightboxes()},
prepLightboxes:function(){this.settings;var e=y(f.domrefs.modalUnsavedChanges);e&&e.length&&(f.domrefs.modalButtonCancel=e.find("."+C.lightbox.button_cancel),
f.domrefs.modalButtonContinue=e.find("."+C.lightbox.button_continue),e.addClass(C.lightbox.root_hidden),e.find("."+C.lightbox.toggleInfo).addClass(
C.lightbox.toggleInfo_hidden),e.find(".toggle-notice--global, .toggle-notice--service").addClass(C.lightbox.toggleInfo_hidden))},showModal:function(e){
var t=this.settings,n=y(f.domrefs.modalUnsavedChanges),i=n.find(".toggle-notice--global"),o=n.find(".toggle-notice--service");if("Global"===f.json.editingCtn
)i.removeClass(C.lightbox.toggleInfo_hidden);else{var r=c.getNodeByCtn(f.json.editingCtn);if(r&&"object"==typeof r){var a=d.getCtnFromItem(r.domref,!0),s=(
t.serviceMessageOriginal||"").replace("{current_accordion_item}",a);n.find(".toggle-notice--service > p").html(s)}o.removeClass(C.lightbox.toggleInfo_hidden)}
e.source,y(f.domrefs.modalButtonContinue).one("click",e.continueBtn),y(f.domrefs.modalButtonCancel).one("click",e.cancelBtn),n.removeClass(
C.lightbox.root_hidden)},hideModal:function(){var e=this.settings,t=y(f.domrefs.modalUnsavedChanges);t.addClass(C.lightbox.root_hidden),t.find(
"."+C.lightbox.toggleInfo).addClass(C.lightbox.toggleInfo_hidden),t.find(".toggle-notice--global, .toggle-notice--service").addClass(
C.lightbox.toggleInfo_hidden),t.find(".toggle-notice--service > p").html(e.serviceMessageOriginal)}},o={settings:{},init:function(){this.settings;var e=[
"."+C.toggle.trigger,"."+C.accordion.trigger,"."+C.submit.trigger,".global-group",".service-group",".modal-dialog__body"].join(", ");r.off(".gdpr",e),r.on(
"click.gdpr",e,{continueBtn:"[continue]",cancelBtn:"[cancel]"},this.handleClick)},handleClick:function(e){var t=o,n=(t.settings,y(this));return n.hasClass(
C.toggle.trigger)?(e.preventDefault(),e.stopPropagation(),void t.handleToggle(n,e)):n.hasClass(C.accordion.trigger)?(e.preventDefault(),e.stopPropagation(),
void t.handleAccordion(n,e)):n.hasClass(C.submit.trigger)?(e.preventDefault(),e.stopPropagation(),void t.handleSubmit(n,e)):void 0},handleToggle:function(e,t){
this.settings,t.data;var n,i=y(e);if(i.hasClass(C.toggle.input)?n=i:i.hasClass(C.toggle.button)&&(n=y(e).find("."+C.toggle.input)),!n||!n.length
)return undefined;var o=c.getNodeByInputId(n.attr("id"));if(o&&"object"==typeof o){var r=o.parentCtn;if(0===f.json.editingCtn.length||f.json.editingCtn===r
)l.toggleInput(n);else{var a={source:"toggle",el:n.get(0),continueBtn:function(){s.hideModal(),c.submitJson()},cancelBtn:function(){(function(){
var e=utag_data||{};e.page_channel="self service",e.page_market="UK",e.page_name="uk:myaccount:gdpr:confirmation",e.page_type="my account",
e.site_section_lvl_1="uk:my account",e.site_section_lvl_2="uk:my account:personal_details",e.site_section_lvl_3="";try{var t={page_name:e.page_name,
link_name:"uk:myaccount:gdpr:confirmation:GDPR cancel changes"};utag.link(t,null,[129])}catch(n){return consoleLogLevel("cannot find function utag.link()",3,n),
undefined}})(),c.resetJson(),c.init(),d.init(),l.init(),s.hideModal()}};s.showModal(a)}}},handleAccordion:function(e,t){this.settings,t.data;var n=y(e
).hasClass(C.accordion.item)?y(e):y(e).parents("."+C.accordion.item).eq(0);if(!n||!n.length)return undefined;var i=d.getCtnFromItem(n),o=c.getNodeByCtn(i);if(
o&&"object"==typeof o)d.hiddenInputValue("set",i),d.toggleItem(n);else if(f.json.editingCtn.length){var r={source:"accordion",thisCtn:i,el:n.get(0),
continueBtn:function(){s.hideModal(),d.hiddenInputValue("set",i),c.submitJson()},cancelBtn:function(){c.resetJson(),c.init(),l.init(),s.hideModal(),
d.hiddenInputValue("set",i),d.submitAccordion()}};s.showModal(r)}else d.hiddenInputValue("set",i),d.submitAccordion()},handleSubmit:function(e,t){this.settings,
t.data,c.submitJson()}}}(jQuery),function(v){v.fn.spendCap=function(){var o=v(".portlet_spendcap"),i=v(".portlet_spendcap-wrapper"),e=v(
".portlet_spendcap .info a"),t=v(".portlet_spendcap-amount"),n=v(".portlet_spendcap-amount select"),r=null,a=v(".portlet_spendcap-ctn"),s=null,c=v(".buttonLrg")
,l=v("[name*='spend_cap_json']"),d=v(".portlet_spendcap-nospend"),u=JSON.parse(l.val()),f=v(o).find(".upgrade-btn");if(v(o).find(
"button[id*='spendCapHiddenButton']"),t.length){function h(){s=v(this).closest(i).find(a).text()}function p(){try{var e=v("[id$='spendCapDataButton']").attr(
"id"),t=AdfPage.PAGE.findComponentByAbsoluteId(e);AdfActionEvent.queue(t,!0)}catch(n){return undefined}}n.each(function(e,t){for(var n in h.call(v(this)),u
)u.hasOwnProperty(n)&&n===s&&u[n].spendCapValue&&v(this).find("option").each(function(e,t){v(this).val()===u[n].spendCapValue&&v(this).attr("selected",
"selected")})}),n.change(function(){for(var e in h.call(v(this)),r=v(this).val(),u)if(u.hasOwnProperty(e)&&e===s){var t=v(this).closest(i).find(c);if(
r!==u[e].spendCapValue&&""!==r?t.removeClass("disabled secondaryBtn").addClass("primaryBtn"):t.removeClass("primaryBtn").addClass("disabled secondaryBtn"),
"0"!==u[e].spendCapValue){var n=v(this).closest(i).find(d);"0"===r.replace(/[^\d\.]/g,"")?n.removeClass("hidden"):n.addClass("hidden")}}}),c.on("click",
function(){for(var e in h.call(v(this)),u)u.hasOwnProperty(e)&&e===s&&(u[e].edited=!0,u[e].spendCapValue=r,l.val(JSON.stringify(u)),p())})}e.vfAccountDetails(),
f.on("click",function(){var e=v(this).parents(".portlet_spendcap-wrapper").find(".portlet_spendcap-ctn"),t=v(o).find("input[id*='spend_cap_hiddenCtn']"),n=v(o
).find("input[id*='spend_cap_hiddenUrl']");t.attr("value",e.text()),n.attr("value",v(this).attr("href")),v(this).attr("href","#")
;var i=AdfPage.PAGE.findComponentByAbsoluteId(v("button[id*='spendCapHiddenButton']").attr("id"));AdfActionEvent.queue(i,!0)})}}(jQuery),
$.fn.payg1Modal=function(){var e,t=$(this),n=t.attr("class"),i=/(?:modal\-target\-)([a-z0-9A-Z\-\_]+)/gi,o=t.find(".radioToggle"),r=o.closest(".toggleContainer"
);if($(".enjoyMore").length&&r.hasClass("off")&&r.addClass("disabled"),r.hasClass("disabled"))return!1;for(var a=0;a<n.length;a++){var s=i.exec(n);s&&(e=s[1])
;break}if(!e)return!1;var c=$("."+e),l=c.find(".closeModal"),d=c.find(".ctr13-modal-content");function u(e,t,n){var i=t?"left ":"right ";i+=n?"bottom":"top",
!0===n?($(e).css({"background-position":i,"pointer-events":"none"}),$(e).closest(".modal--enjoymore").css("pointer-events","none")):$(e).css({
"background-position":i})}function f(e){var t=$(e).closest(".toggleContainer").find('input[value="0"]'),n=$(e).closest(".toggleContainer").find(
'input[value="1"]'),i=$(document).data(o.data("dataKey"));t.prop("checked",!0),n.prop("checked",!1),i.isOn=!0,i.used=!1,$(e).parents().hasClass("in-progress"
)?u(o,i.isOn,!0):(u(o,i.isOn,!1),$(o).one("click",$.proxy(h,this,o)))}function h(e){var t=$(e).closest(".toggleContainer").find('input[value="0"]'),n=$(e
).closest(".toggleContainer").find('input[value="1"]'),i=$(document).data(o.data("dataKey"));t.prop("checked",!1),n.prop("checked",!0),i.isOn=!1,i.used=!1,$(e
).parents().hasClass("in-progress")?u(o,i.isOn,!0):(u(o,i.isOn,!1),$(o).one("click",$.proxy(f,this,o)))}0===d.closest(".bd-modal-display").length&&d.wrap(
'<div class="bd-modal-body bd-modal-display"><div class="bd-modal-inner-body"></div></div>'),0<t.find("button").length&&t.closest("form").on("submit",function(e
){e.preventDefault()}),function p(){var e=$(document).data(o.data("dataKey"));e.used=!1,t.one("click",function(){t.hasClass("modal--payg1")&&(
e.isOn?window.buildOmnitureStringOn&&buildOmnitureStringOn():window.buildOmnitureStringOFF&&buildOmnitureStringOFF()),t.hasClass("modal--enjoymore"
)&&window.onSuccessfulSlider&&onSuccessfulSlider(this),c.removeClass("hidden"),l.one("click.ctr13",function(e){0<o.length&&($(document).data(o.data("dataKey")
).isOn?h(o):f(o)),l.off(),e.preventDefault(),c.addClass("hidden"),p()})})}()},$(document).on("ready",function(){0<$(".portlet_pay_bill").add(".portlet_payg1"
).add(".portlet_enjoy").add(".portlet_gdpr").length&&$(".open-ctr13-modal").each(function(){$(this).payg1Modal()})}),$(document).on("ready",function(){$(
".disableClicks").each(function(){this.addEventListener("click",function(e){e.stopPropagation()},!0)})}),$.fn.inputDeselectRadio=function(){for(var e=$(this),
t=e.attr("class"),n=null,i=e.closest(".filter_box").find(".secondaryBtn"),o=0;o<t.length;o++){
var r=/(?:js-input-deselect-radio-target--)([a-z0-9A-Z\-\_]+)/gi.exec(t);r&&(n=$("."+r[1]));break}if(!n)return!1;var a=n.find("input"),s=n.find("label"),
c=function(){a.prop("checked",!1),s.removeClass("checked")},l=function(){e.val("")};e.on("focus",c),a.on("click",l),i.on("click",l),i.on("click",c)},$(document
).on("ready",function(){$(".js-input-deselect-radio").each(function(){$(this).inputDeselectRadio()})}),$.fn.vfToggleInputs=function(){var a=$(this),e=$(this
).find("a");function t(e,t){var n,i;(function o(e){e.find("input").each(function(){$(this).attr("disabled",!0)})})(e),function r(e){var t;e.find("input").each(
function(){$(this).attr("disabled",!1),$(this).val("")}),(t=e).hasClass("error")&&t.removeClass("error"),window.validator.resetForm()}(t),n=a.children(
"div.hidden"),i=a.children("div:not(.hidden)"),n.removeClass("hidden"),i.addClass("hidden")}$(e).on({click:function(){var e=a.children("div.hidden");t(
a.children("div:not(.hidden)"),e)}})},$.fn.vfTabbedInput=function(){$.keyCodes={UP_ARROW:38,DOWN_ARROW:40,LEFT_ARROW:37,RIGHT_ARROW:39,SPACE:32,TAB:9,ESCAPE:27,
RETURN:13};var n={};n.inputs=$(this).find("input[type=text]:not(.hidden)"),n.last=$(this).find("input").last(),n.hidden=$(this).find("input.hidden");var e=$(
this).find("input").not("input.hidden"),t=e.attr("maxlength"),i=e.length*parseInt(t);n.last.addClass("last"),n.inputs.on("keyup",function(e){if(
e.keyCode===$.keyCodes.TAB|e.keyCode===$.keyCodes.SHIFT|e.keyCode===$.keyCodes.CAPS_LOCK|n.last)return!1;$(this).attr("maxlength")<=$(this).val().length&&$(this
).nextAll("input").first().focus()}),n.inputs.on("focus",function(e){$(this).select()}),n.inputs.on("blur",function(e){var t=[];return e.target.value&&($(
n.inputs).each(function(){t.push($(this).val())}),result=t.join(""),result.length===i&&$(n.hidden).attr("value",result)),!1}),n.inputs.on("change",function(e){
var t=[];return e.target.value&&($(n.inputs).each(function(){t.push($(this).val()),$(e.target).attr("value",e.target.value)}),result=t.join(""),
result.length===i&&$(n.hidden).val(result)),!1})},function(k){k.fn.ctnFilter=function(){return this.each(function(){for(var f=this,e=[],t=k(f).find(
".show-types input[type=checkbox]"),h=k(f).find(".items li"),p=k(f).find(".box_title"),v=k(f).find(".bill"),g=k(f).find(".items li"),m=k(f).find(
".accordionDetails"),b=k(f).find(".search_box"),y=k(f).find(".search_noresults"),C=k(f).find(".search_submit"),n=parseInt(k(f).find(k(
"input[class*='filter-ctn-type-config-value']")).attr("value")),i=parseInt(k(f).find(k("input[class*='filter-ctn-config-value']")).attr("value")),o=k(f).find(
".show-types"),r=(k(o).find("label"),0),a=h.length;r<a;r++)k(h[r]).find(".account_details a span").hasClass("sub-i-smartphone-mid-secondary")&&(k(h[r]
).removeClass(),k(h[r]).addClass("ctn_secondary")),k(h[r]).attr("id","ctn_filter_id"+r),e.push("ctn_filter_id"+r);for(var s=0,c=0,l=t.length;c<l;c++){var d=!1,
u=k(t[c]).attr("name");for(r=0,a=h.length;r<a;r++)if(k(h[r]).hasClass(u)){d=!0,s++;break}d||(k(t[c]).prop("disabled",!0),k(t[c]).next().addClass("inactiveCtn"))
}if(s<=n||g.length<i)o.remove();else{var w=navigator.userAgent;if(-1<w.indexOf("MSIE ")||-1<w.indexOf("Trident/")){o.css("display","block");var _={1:"0",2:"15",
3:"19.2",4:"11.9",5:"8",6:"5.7",7:"4.1",8:"3.5"};for(label_index=0;label_index<=t.length;label_index++)0===label_index?o.find("label:eq("+label_index+")").css(
"margin","0 "+_[t.length]+"% 0 0"):label_index===t.length-1?o.find("label:eq("+label_index+")").css("margin","0 0 0 "+_[t.length]+"%"):o.find(
"label:eq("+label_index+")").css("margin","0 "+_[t.length]+"%")}else o.css("display","flex")}k(t).on("change",function(){k(this).next().toggleClass(
"ctnSelected");var e=k(f).find(".show-types input[type=checkbox]:checked"),t=b.val().toLowerCase(),n=0;if(0===e.length)k(f).find(".subscription_plan"
).slideDown(0),null==b.val()||""!=b.val()?p.add(v).slideUp(0):p.add(v).add(g).add(m).slideDown(0),k(h).slideDown(0),y.slideUp(0),"none"!=C.css("display"
)?C.click():b.keyup();else{k(f).find(".subscription_plan").slideUp(0),p.add(v).slideUp(0),y.slideUp(0);for(var i=0,o=h.length;i<o;i++){for(var r=!1,a=0,
s=e.length;a<s;a++){var c=k(h[i]),l=c.find(".account .name").text().toLowerCase(),d=c.find(".account .number").text().toLowerCase(),u=c.find(".subscription"
).text().toLowerCase();if(k(h[i]).hasClass(k(e[a]).val())&&-3<d.replace(/\s+/g,"").indexOf(t.replace(/\s+/g,""))+l.replace(/\s+/g,"").indexOf(t.replace(/\s+/g,
""))+u.replace(/\s+/g,"").indexOf(t.replace(/\s+/g,""))){r=!0,n++;break}}r?(k(h[i]).slideDown(0),k(h[i]).addClass("ctn_visible"),k(h[i]).addClass(
"ctn_slideDown"),n++,k(h[i]).parent().parent().prev().hasClass("subscription_plan")&&k(h[i]).parent().parent().prev().slideDown(0)):(k(h[i]).slideUp(0),k(h[i]
).removeClass("ctn_visible"),k(h[i]).removeClass("ctn_slideDown"))}n<=0&&(y.slideDown(0),k(f).find(".subscription_plan").slideUp(0),p.add(v).slideUp(0))}})})}}(
jQuery),$(document).ready(function(){$(".portlet_accountsummary_v3 .accordionWrapper").ctnFilter()}),function(d){d.fn.eSim=function(){var t=d(".toggleDivs"),
e=d(".swapDiv");function n(e){0===e?(t.eq(0).hide(),t.eq(1).show()):(t.eq(0).show(),t.eq(1).hide()),window.validator.resetForm(),d(this).closest("form").find(
"input[type=text]").attr("value","")}d("form")[0],e.on("click",function(){d(this).attr("id")===e.eq(0).attr("id")?n(0):n(1)}),d.keyCodes={UP_ARROW:38,
DOWN_ARROW:40,LEFT_ARROW:37,RIGHT_ARROW:39,SPACE:32,TAB:9,ESCAPE:27,RETURN:13,SHIFT:16,CAPS_LOCK:20,PAGE_UP:33,PAGE_DOWN:34,CTRL:17,HOME:36,END:35},d(
"input.esim32").on("input, keyup",function(e){var t=e.target;outputData=i(t),outputData.input=d(t),outputData.key=e.which,d(t).prop("value",outputData.array),d(
t).siblings("input.hidden").prop("value",c(t)),8!==e.which&&46!==e.which&&37!==e.which&&39!==e.which||o(outputData),window.validator.resetForm(),d(this
).closest("form").find(".valid").removeClass("valid")});var i=function(e){var t=d('input[id$="delimiter"]').val(),n=c(e),i={};32<n.length&&(n=n.substring(0,32))
;for(var o="",r=0,a=[],s=0;s<n.length;s++)0<s&&s%4==0&&(a.push(o),o="",r=s),o+=n[s];return a.push(n.slice(r)),i.array=a.join(t),i.cursorPosition=l(e),
i.delimiterSymbol=t,i},c=function(e){return d(e).prop("value").replace(/\D/g,"")},o=function(e){var t={};t.input=e.input,t.cursorPosition=e.cursorPosition,
key=e.key,t.delimiterSymbol=e.delimiterSymbol,t.charAtCursorPosition=t.input[0].value[t.cursorPosition],37===key||8===key?(t.direction="left",
t.charAtCursorPosition=t.input[0].value[t.cursorPosition-1]):39!==key&&46!==key||(t.direction="right"),t.charAtCursorPosition===t.delimiterSymbol&&(
t.cursorPosition=a(t)),r(t)},l=function(e){if(e){if("selectionStart"in e)return e.selectionStart;if(document.selection){e.focus()
;var t=document.selection.createRange(),n=document.selection.createRange().text.length;return t.moveStart("character",-e.value.length),t.text.length-n}}},
r=function(e){if("selectionStart"in e.input[0])e.input[0].focus(),window.setTimeout(function(){e.input[0].setSelectionRange(e.cursorPosition,e.cursorPosition)},
0);else if(document.selection){e.input[0].focus();var t=document.selection.createRange(),n=document.selection.createRange().text.length;return t.moveStart(
"character",e.cursorPosition),t.text.length-n}},a=function(e){var t=e.cursorPosition;return"left"===e.direction?e.cursorPosition=t-1:"right"===e.direction&&(
e.cursorPosition=t+1),e.cursorPosition}}}(jQuery),function(n){n.fn.scrollToPDFDownload=function(){return this.each(function(){n(this).on("click",function(e){
var t="";e.preventDefault(),n(".portlet_ebillingdownloadPDF").length?(t=n(".portlet_ebillingdownloadPDF").first().offset().top,n("html,body").animate({
scrollTop:t},1e3)):alert("Sorry, we can't find your PDF bill right now. Please try again later.")})})},n(document).ready(function(){n(
".portlet_pay_bill p.disclaimer a.payBillScrollToPDF").scrollToPDFDownload()})}(jQuery),function(H){H.fn.autoServiceSwitching=function(){return this.each(
function(){var o=H(".portlet-auto-service-switching"),e=H(o).find(".selection-list"),r=H(e).find(".ctn-item-container"),t=H(o).find(".ctn-item-container"),i=H(r
).find(".ctn-container"),n=H(t).find(".ctn-container"),a=H(o).find(H("button[class*='cancel-contract-submit-btn']")),s=H(o).find(H(
"button[class*='cancel-contract-next-btn-1']")),c=H(o).find(".selected-ctn-count-container"),l=H(c).find(".selected-ctn-count"),d=navigator.userAgent,
u=-1<d.indexOf("MSIE ")||-1<d.indexOf("Trident/"),f=H(o).find(".trash-icon"),h=H(o).find(".confirm-button-container"),p=H(h).find(".cancel"),v=H(h).find(
".confirm"),g=H(o).find(".terms-and-conditions"),m=H(o).find(".request-code"),b=H(o).find("[class*='multi-request-type']"),y=H(o).find(
".ctn_selection_config input").val(),C=H(c).find(".total-count"),w=H(o).find(".text-clear-btn"),_=H(o).find(".search-panel-container"),k=H(_).find(
".search-panel-configuration input").val(),x=H(_).find(H("input[class*='search-ctn']")),$=H(_).find(".search_noresults"),O=H(_).find(".select-all-ctn-check"),
j=H(o).find(H(".delete-tracker-config input")),S=(H(o).find(".popup__model_container"),H(o).find(".popup__model_box")),I=H(S).find(".close-icon"),T=H(o).find(
".popup-hyperlink"),D=H(o).find(".helpTextOff"),E=H(o).find(".selected_ctn_tracker input"),A=0,P=H(o).find(".tooltip-over-button"),M=H(n).find(
".lead-account-details");if(0<r.length){var N=H(o).find(".disabled-items-tooltip-text p").text(),R=H(o).find(".bar-product-items-tooltip-text p").text(),L=H(o
).find(".open-upgrade-plan-items-tooltip-text p").text();r.each(function(){H(this).hasClass("product-bar")?(H(this).find(".tooltip-span").text(R),H(this).find(
".ctn-container").addClass("product-bar").addClass("disabled")):H(this).hasClass("open-upgrade-plan")?(H(this).find(".tooltip-span").text(L),H(this).find(
".ctn-container").addClass("open-upgrade-plan").addClass("disabled")):H(this).find(".tooltip-span").text(N)}),H(C).text(r.length),H(l).text(H(
".ctn-item-container .checked").length),u&&x.addClass("search-ctn-ie"),r.length>k?_.show():_.hide(),H(i).hasClass("checked")?(s.removeAttr("disabled"),
s.removeClass("disabled")):s.attr("disabled",!0),E.attr("value",""),H(i).each(function(){var e;e=0<H(this).find(".number").length?H(this).find(".number").text(
):H(this).find(".h-number").text(),H(this).hasClass("checked")&&(H(this).parents(".ctn-item-container").addClass("checked"),E.attr("value",E.val()+e+","))})}if(
0<t.length){for(var B=0;B<n.length;B++)H(n[B]).find("input:radio").each(function(e){H(this).attr("id",H(this).prev("label").attr("for"))});M.parents(
".ctn-container").addClass("lead-account")}function F(){var e=H(o).find(H("[class*='early-termination-fee']")),t=0,n=H(o).find(".total-fee");e.each(function(){
var e=parseFloat(H(this).text().replace("£",""));t+=e}),n.text("£"+t)}function U(){var e=H(".portlet-auto-service-switching").find(".ctn-item-container"),t=H(e
).find("input[type=radio]").length,n=H(e).find("input[type=radio]:checked").length;H(g).hasClass("checked")&&0!==t&&t/2===n?(a.removeClass("disabled"),a.attr(
"disabled",!1),P.addClass("invisible")):(a.addClass("disabled"),a.attr("disabled",!0),P.removeClass("invisible"))}0<H(o).find(H(
"[class*='early-termination-fee']")).length&&F(),a.attr("disabled",!0),P.removeClass("invisible"),j.attr("value",""),D.each(function(){H(this).next().hasClass(
"helpTextOff")&&H(this).remove()}),H(i).on("click",function(e){if(!H(this).hasClass("disabled")&&!H(this).hasClass("product-bar")&&!H(this).hasClass(
"open-upgrade-plan")){H(this).toggleClass("checked");var t,n=H(i).hasClass("checked");t=0<H(this).find(".number").length?H(this).find(".number").text():H(this
).find(".h-number").text(),H(this).hasClass("checked")?(H(this).parents(".ctn-item-container").addClass("checked"),E.attr("value",E.val()+t+",")):(H(this
).parents(".ctn-item-container").removeClass("checked"),E.attr("value",E.val().replace(t+",",""))),H(l).text(H(".ctn-item-container .checked").length),n?(
s.removeClass("disabled"),s.removeAttr("disabled")):(s.addClass("disabled"),s.attr("disabled",!0)),H(".ctn-item-container .checked").length<y?(r.each(function(
){!H(this).find(".ctn-container").hasClass("disabled")||H(this).find(".ctn-container").hasClass("product-bar")||H(this).find(".ctn-container").hasClass(
"open-upgrade-plan")||H(this).removeClass("disabled").find(".ctn-container").removeClass("disabled")}),H(O).hasClass("checked")&&0===A&&H(O).removeClass(
"checked")):r.each(function(){H(this).hasClass("checked")||H(this).addClass("disabled").find(".ctn-container").addClass("disabled")})}}),H(r).mousemove(
function(e){var t=e.clientX,n=e.clientY,i=H(this).find(".tooltip-span");i.css("top",n+-10+"px"),i.css("left",t+20+"px")}),H(g).on("click",function(){var e=H(o
).find(".hide-on-load-wrapper");if(0<e.length)H(this).hasClass("checked")?(e.show(),m.hasClass("checked")&&(a.removeClass("disabled"),a.attr("disabled",!1),
P.addClass("invisible"))):(e.hide(),a.addClass("disabled"),a.attr("disabled",!0),P.removeClass("invisible"));else{var t=H(".portlet-auto-service-switching"
).find(".ctn-item-container").find(".ctn-container"),n=t.find("input[type=radio]").length,i=t.find("input[type=radio]:checked").length;H(this).hasClass(
"checked")&&0!==n&&n/2===i?(a.removeClass("disabled"),a.attr("disabled",!1),P.addClass("invisible")):(a.addClass("disabled"),a.attr("disabled",!0),
P.removeClass("invisible"))}}),H(m).on("click",function(){a.removeClass("disabled"),a.attr("disabled",!1),P.addClass("invisible")}),H(x).bind("keyup",function(e
){var n=H(this).val().toLowerCase(),i=r.length;w.css("display","inline"),u||""==n?w.css({opacity:"0"}):w.css({opacity:"1"}),r.each(function(){var e=H(this),
t=e.find(".account .name").text().toLowerCase();-2<(0<e.find(".number").length?e.find(".account .number").text():e.find(".account .h-number").text()).replace(
/\s+/g,"").indexOf(n.replace(/\s+/g,""))+t.replace(/\s+/g,"").indexOf(n.replace(/\s+/g,""))?(e.slideDown(0),i++,$.slideUp(0)):(e.slideUp(0),--i<1&&$.slideDown(0
))})}),H(w).on("click",function(){H(x).val(""),$.slideUp(0),w.hide(),r.each(function(){H(this).slideDown(0)})}),H(O).on("click",function(e){if(H(this
).toggleClass("checked"),H(this).hasClass("checked")){var t=0;A=1,r.each(function(){H(this).hasClass("product-bar")||H(this).hasClass("open-upgrade-plan")||(
t<y&&!H(this).hasClass("checked")&&!H(this).hasClass("disabled")?(H(this).find(".ctn-container").click(),t++):H(this).hasClass("checked")?t++:H(this).addClass(
"disabled").find(".ctn-container").addClass("disabled"))}),A=0}else A=1,r.each(function(){H(this).hasClass("product-bar")||H(this).hasClass("open-upgrade-plan"
)||(H(this).find(".ctn-container").hasClass("disabled")?H(this).removeClass("disabled").find(".ctn-container").removeClass("disabled"):H(this).hasClass(
"checked")&&H(this).find(".ctn-container").click())}),A=0}),H(f).on("click",function(e){var t=H(this).parent().find(".delete-confirmation-panel"),n=H(this
).parents(".ctn-item-container"),i=H(n).find(".mod-css-table"),o=H(n).find(".ctn-container"),r=H(n).find(".error-wrapper");"none"==t.css("display")&&(t.show(),
i.addClass("__blur"),o.addClass("__blur"),r.addClass("__blur"),H(this).addClass("__blur"))}),H(v).on("click",function(e){var t,n=H(this).parents(
".ctn-item-container");n.slideUp(400),n.remove(),F(),U(),t=0<n.children(".ctn-container").find(".number").length?n.children(".ctn-container").find(
".account .number").text():n.children(".ctn-container").find(".account .h-number").text(),j.attr("value",H(j).val()+t+","),0===H(o).find(".ctn-item-container"
).length&&H(o).find(H("[class*='total-fee']")).parent().remove()}),H(p).on("click",function(e){var t=H(this).parents(".delete-confirmation-panel"),n=H(this
).parents(".ctn-item-container"),i=H(n).find(".mod-css-table"),o=H(n).find(".ctn-container"),r=H(n).find(".error-wrapper"),a=H(this).parents().find(
".trash-icon");"none"!=t.css("display")&&(t.hide(),i.removeClass("__blur"),o.removeClass("__blur"),r.removeClass("__blur"),a.removeClass("__blur"))}),H(b).on(
"click",function(e){U()}),H(T).on("click",function(e){var n=H(o).find(".popup__model_container"),t=H(this).attr("class").split(" ");H(t).each(function(e,t){
~t.indexOf("-popup")&&H(n).show().find("."+t).show()})}),H(I).on("click",function(e){"none"!==H(this).parents(".popup__model_box").css("display")&&(H(this
).parents(".popup__model_box").hide(),H(this).parents(".popup__model_container").hide())})})}}(jQuery),$(document).ready(function(){$(
".portlet-auto-service-switching").autoServiceSwitching()}),function(o){o.fn.vfAccordion=function(){var e=o(this),t=e.find(".categoryContent"),n=e.find(
".categoryHeading h3").find("a");function i(e){e.hasClass("iconOpen")?e.removeClass("iconOpen").addClass("iconClosed"):e.hasClass("iconClosed")&&e.removeClass(
"iconClosed").addClass("iconOpen")}n.find("span.icon"),t.hide(),o(n).on("click",function(e){e.preventDefault();var t=o(this).parent().parent().next(),n=o(this
).find("span.icon");n.hasClass("iconClosed")?o(t).stop(!0,!0).slideDown(300,function(){i(n)}):o(t).stop(!0,!0).slideUp(300,function(){i(n)})})}}(jQuery),
function(t){t.fn.vfOpenAccordion=function(){var e=t(this).first();first=e.find(".categoryHeading h3 a"),first.click()}}(jQuery),function(i){
i.fn.vfFaqAccordion=function(){return this.each(function(){var e=i(this),t=i(e).find(".faq-list-item"),n=i(t).find(".faq-item");i(n).unbind().on("click",
function(){var e=i(this).parents(".faq-list-item").children(".faq-details-container"),t=i(this).find(".arrow-icon");e.slideToggle(500),t.hasClass("down"
)?t.removeClass("down").addClass("up"):t.removeClass("up").addClass("down")})})}}(jQuery),function(e){e(document).ready(function(){e(".expandingCategory"
).vfAccordion(),e(".myPackageView").vfOpenAccordion(),e(".faq-items-container").vfFaqAccordion()})}(jQuery);