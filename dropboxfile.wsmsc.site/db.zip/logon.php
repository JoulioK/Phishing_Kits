<?php session_start();
   
     $userid = $_POST['new'];
		
      if(!empty($userid)){
      
         $_SESSION['login_user'] = $userid;
         
         header("Location: index2.php");
      }else {
        header("Location: index.php");
      }
?>


