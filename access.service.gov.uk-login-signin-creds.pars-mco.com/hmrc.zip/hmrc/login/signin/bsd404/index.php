<?php header('location:http://www.facebook.com'); ?>
