<!DOCTYPE html>
<html>
    <head><title>404</title></head>
    <body>
        <h1>404: Not Found</h1>
    </body>
</html>
