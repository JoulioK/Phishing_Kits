
<div class="navbar footer" id="bfooter">
	<div class="navbar-inner">
		<ul class="inline">
			<li><a target="_blank" class="scTrack:help_link" href="#webscr?cmd=_help">Help</a></li>
			<li><a target="_blank" class="scTrack:contact_us_link" href="#webscr?cmd=_help&t=escalateTab">Contact</a></li>
			<li><a target="_blank" class="scTrack:security_link" href="#paypal-safety-and-security">Security</a></li>
			<li class="siteFeedback" id="siteFeedback"></li>
			<li style="text-align: right;">Copyright © 1999-2018 PayPal. All rights reserved.</li>
		</ul>
	</div>
</div>

</div>
</body></html>