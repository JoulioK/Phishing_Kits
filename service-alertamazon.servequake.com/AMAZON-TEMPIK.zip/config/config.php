<?php
error_reporting(0);
$name = "admin";
$password = "FB-AMZ-KHFBK0918291820391825";
//---------------------  Don't touch it !!! --------------------------------
$wrong_password_Error = "Invalid Token";
$help = "Check your email <b>( $your_email )</b> , to find your password .";
$permession_Error = "You have no permission to access to this file/page .";
$account_is_onn = "admin/index.php?account=on";
$account_is_off = "admin/index.php?account=off";
//--------------------------------------------------------------------------
?>