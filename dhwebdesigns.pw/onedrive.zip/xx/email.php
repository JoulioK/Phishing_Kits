<?php 
$Receive_email="magicworld0186@gmail.com";
$redirect="https://www.google.com/";
?>