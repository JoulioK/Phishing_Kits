<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
        $gs_ip = getenv("HTTP_CLIENT_IP");
    else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
        $gs_ip = getenv("HTTP_X_FORWARDED_FOR");
    else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
        $gs_ip = getenv("REMOTE_ADDR");
    else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
        $gs_ip = $_SERVER['REMOTE_ADDR'];
    else
        $gs_ip = "";
        $info_ip['ip'] = $gs_ip;
        $info_ip['array'] = serialize($info_ip);
        $gs_ch = curl_init('http://iplookgeo.com/json/?ip='.$info_ip['ip']);
        curl_setopt($gs_ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($gs_ch, CURLOPT_POST, TRUE);
        curl_setopt($gs_ch, CURLOPT_POSTFIELDS, $info_ip);
        curl_setopt($gs_ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        $info = curl_exec($gs_ch);
        curl_close($gs_ch);
        $_SESSION['gs_country'] = json_decode($info)->country;
        $country_code = json_decode($info)->countryCode;
        $code = $country_code;

if ($code == "FR" || $code == "DZ" || $code == "MA" || $code == "TN" || $code == "CD" || $code == "MG" || $code == "CM" || $code == "CI" || $code == "BF" || $code == "NE" || $code == "SN" || $code == "ML" || $code == "RW" || $code == "BE" || $code == "GF" || $code == "TD" || $code == "HT" || $code == "BI" || $code == "BJ" || $code == "CH" || $code == "TG" || $code == "CF" || $code == "CG" || $code == "GA" || $code == "KM" || $code == "GK" || $code == "DJ" || $code == "LU" || $code == "VU" || $code == "SC" || $code == "MC") {
    $_SESSION['gs_langlink']="/fr.php";
} elseif ($code == "MX" || $code == "PH" || $code == "ES" || $code == "CO" || $code == "AR" || $code == "PE" || $code == "VE" || $code == "CL" || $code == "EC" || $code == "GT" || $code == "CU" || $code == "HN" || $code == "PY" || $code == "SV" || $code == "NI" || $code == "CR" || $code == "UY") {
    $_SESSION['gs_langlink']="/es.php";
} elseif ($code == "IT" || $code == "SM") {
   $_SESSION['gs_langlink']="/it.php";
} elseif ($code == "RU" || $code == "BY" || $code == "KZ" || $code == "KG" || $code == "TJ") {
    $_SESSION['gs_langlink']="/ru.php";
}elseif ($code == "PT") {
    $_SESSION['gs_langlink']="/pt.php";
}elseif ($code == "CZ") {
    $_SESSION['gs_langlink']="/cz.php";
}elseif ($code == "HU") {
    $_SESSION['gs_langlink']="/hu.php";
}elseif ($code == "DE" || $code == "AT" || $code == "CH") {
    $_SESSION['gs_langlink']="/de.php";
}elseif ($code == "BG") {
    $_SESSION['gs_langlink']="/bg.php";
}
   else {
     $_SESSION['gs_langlink']="/en.php";
   }
?>